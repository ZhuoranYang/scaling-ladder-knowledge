# Hero training loss-spike alert

`TrainingLossSpike` is a critical Grafana alert for active Iris hero roots. It posts one Slack message per logical run. It uses the same `notification=hero-run` route as [`TrainingProgressStalled`](training-stall-alert-contract.md). The alert does not kick, restart, or configure a job. An operator decides whether to continue training or resume from an earlier checkpoint.

It pages because a hero run diverging unwatched costs more than a false page does, and a silence answers a false page. Expect benign firings at mixture stage boundaries; silence the run for that window rather than widening the band for every run.

Enrollment uses the [`TrainingProgressStalled`](training-stall-alert-contract.md) contract. A root matches `/marin/hero-%-coord` or `/marin/hero-%-coord-%`. The two rules share one `iris.task_state` query in each bridge cache interval.

## What fires it

The bridge reads `train_loss` from `levanter.metrics` for the enrolled run IDs over one bounded hour and reduces it, in SQL, to two windows per run: a baseline covering `[now-60m, now-5m)` and a recent window covering the last five minutes.

The run alerts when either condition holds:

- The lowest `train_loss` in the recent window exceeds `mean(baseline) + max(0.05, 6 * stddev(baseline))`. Labeled `spiking`.
- Any reduction of the recent window is not finite, which is how a loss that has gone to NaN or infinity arrives. Labeled `not_finite`.

Six standard deviations is the band Levanter's `SkipStepConfig` rejects an individual step on, so a run with skip-step enabled and a run without it are judged against the same shape. The absolute floor of 0.05 keeps a very stable run from alerting on a rise too small to act on.

Reducing the recent window to its floor is the load-bearing choice. A single excursion, which skip-step already handles by discarding the step, raises the window's peak and its mean and leaves its minimum where it was. A level that shifts up and stays raises all three. The alert is therefore quiet for transients and fires for sustained divergence, at the cost of staying quiet for a loss that oscillates in and out of the band.

The baseline is the run's own trailing history, so the band moves with training. Early in a run, loss falls quickly and its trailing standard deviation is wide, which is when a lone excursion means least. Late in a run the band tightens and a smaller persistent rise clears it.

A run reports `warming_up` with fewer than 20 baseline or 5 recent samples, and `healthy` when enough samples show no spike. Both are zero-valued rows, which resolves a firing instance. With no eligible roots the bridge returns an explicit zero-valued `fleet` row. A retryable Finelog query failure also returns a non-firing row; `FinelogFleetUnhealthy` reports the shared query-path failure. Grafana's `noDataState: Alerting` and `execErrState: Alerting` cover empty and invalid bridge responses.

`spiking` and `not_finite` are separate alert instances. The route groups by logical run. Thus, retries and reason changes use one notification group.

## When it fires

1. Open the [Training run dashboard](https://grafana.oa.dev/d/marin-training) and select the run in the alert. The step panel shows the continuous curve. The attempt panel shows restart gaps. The spike panel compares the peak, rejection threshold, and skipped-step count.
2. Separate a data cause from a numerical one. A mixture stage boundary, a resumed run reading a different config, or a checkpoint restore all shift the level legitimately, and the run progress and optimizer panels date the change. A gradient norm climbing into the spike points at the optimizer.
3. Check whether the optimizer absorbed it. Steps skipped during the window mean the update was rejected and the weights did not take the spike; a spike with no skipped steps entered the weights.
4. Decide. Resuming from the last checkpoint before the rise costs the steps since it; letting a diverged run continue costs everything after it. `manage-hero-run` covers the rollback.

Check the rule's baseline and recent windows for the alert's cluster and run ID:

```sql
WITH samples AS (
  SELECT
    value,
    timestamp_ms,
    CAST(EXTRACT(EPOCH FROM now() - INTERVAL '5 minutes') * 1000 AS BIGINT) AS recent_start
  FROM "levanter.metrics"
  WHERE name = 'train_loss'
    AND run_id = '<hero-run-id>'
    AND COALESCE(NULLIF(cluster, ''), 'unknown') = '<cluster>'
    AND timestamp_ms >= CAST(EXTRACT(EPOCH FROM now() - INTERVAL '60 minutes') * 1000 AS BIGINT)
    AND timestamp_ms < CAST(EXTRACT(EPOCH FROM now()) * 1000 AS BIGINT)
)
SELECT
  SUM(CASE WHEN timestamp_ms < recent_start THEN 1 ELSE 0 END) AS baseline_samples,
  AVG(CASE WHEN timestamp_ms < recent_start THEN value END) AS baseline_mean,
  STDDEV(CASE WHEN timestamp_ms < recent_start THEN value END) AS baseline_stddev,
  SUM(CASE WHEN timestamp_ms >= recent_start THEN 1 ELSE 0 END) AS recent_samples,
  AVG(CASE WHEN timestamp_ms >= recent_start THEN value END) AS recent_mean,
  MIN(CASE WHEN timestamp_ms >= recent_start THEN value END) AS recent_floor,
  MAX(CASE WHEN timestamp_ms >= recent_start THEN value END) AS recent_peak
FROM samples;
```

With at least 20 baseline and 5 recent samples, the rule fires when `recent_floor`
exceeds `baseline_mean + max(0.05, 6 * baseline_stddev)`. It treats a missing or
non-finite standard deviation as zero and also fires when `recent_mean` or
`recent_peak` is non-finite. Retries keep the same run ID, so these windows can
include samples from multiple attempts within the hour.

## Tuning

The windows, the sigma factor, the absolute floor, and the sample minimums are constants at the top of `infra/grafana/src/loss_spikes.py`. Changing one takes a redeploy of the Grafana service.

A benign firing that repeats across runs, rather than at one run's stage boundary, is the case for changing a constant. One run's boundary is a case for silencing that run.
