# Hardware Resource Configuration

Marin uses Fray for scheduling and resource management (dispatching to Iris on shared clusters, or to a local backend for laptop runs). The `fray` library provides unified resource configuration types that translate to concrete cluster resource requests.

## ResourceConfig

The main entry point for resource configuration. Use the static factory methods to create configurations:

```python
from fray.cluster import ResourceConfig

# TPU configuration
tpu_config = ResourceConfig.with_tpu("v4-8")
tpu_multislice = ResourceConfig.with_tpu("v4-8", slice_count=2)

# GPU configuration
gpu_config = ResourceConfig.with_gpu("H100", count=8)
single_gpu = ResourceConfig.with_gpu("H100")  # count defaults to 1

# CPU-only configuration
cpu_config = ResourceConfig.with_cpu()
```

::: fray.types.ResourceConfig

## Device Configurations

These are the underlying device types wrapped by `ResourceConfig`:

### CPU

::: fray.types.CpuConfig

### GPU

::: fray.types.GpuConfig

### TPU

::: fray.types.TpuConfig
