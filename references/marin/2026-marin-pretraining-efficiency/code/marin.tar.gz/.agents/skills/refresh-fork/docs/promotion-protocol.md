# Prepare and promote `main-next`

For descriptor and isolated-project pins, run the fork's e2e on `main-next`,
create immutable tags for the old and new tips, and open a draft Marin PR. An
admin reviews that PR before replacing the protected stable branch.

A refresh rebases our patches onto a new upstream base, so `main-next` does not
descend from the current `main` — their upstream bases differ. The promotion is
therefore a **hard swap** (a backed-up force-update), not a merge or fast-forward. A
PR/merge would splice two upstream bases into a merge commit and break the linear
history the fork depends on.

Marin pins exact SHAs and wheels, never a bare branch name, so the branch pointer can
move without changing what Marin resolves. That is what makes the swap safe.

GPU source approval happens before wheel builds and Marin tests. See
[the shared vLLM source branch](#the-shared-vllm-source-branch) for that order.

## Prepare the refs

For each pin in the refresh after its e2e passes:

- Confirm `main-next` is exactly the tip the e2e ran against.
- Record the current remote `main` SHA. Tag it as
  `main-backup/YYYYMMDD/pre-<old-shortsha>` and tag the validated staged tip as
  `main-YYYYMMDD`. Reuse a tag that already points at the expected SHA; stop and
  inspect if either name points elsewhere.
- Push both tags and verify the remote tags resolve to the recorded SHAs.
- Leave `main` unchanged and keep `main-next` available for admin review.

Pin Marin at the exact staged SHA and regenerate
`external_dependencies.py`. The draft PR must list the staged and stable SHAs, both
tags, and the pending admin hard swap. For an `isolated_project`, keep its uv source
on `main-next` in this draft so regenerating the lock cannot move it back to the old
`main` tip. The date tag keeps the staged SHA reachable. Do not mark the PR ready or
merge it in this state.

## Admin promotion

After reviewing the fork overlay and the draft Marin PR, an admin with ruleset bypass
promotes each pin:

- Confirm `main-next` still resolves to the validated and date-tagged tip.
- Confirm `main` still resolves to the SHA recorded by the rollback tag.
- Hard-swap with a lease so a concurrent move is caught:
  `git push --force-with-lease=main:<old-sha> origin main-next:main`.
- Verify remote `main` resolves to the validated tip. Delete `main-next` or
  leave it for the next cycle; the next refresh force-updates it.

Descriptor pins need no edit after this swap because they already record the
exact validated SHA. For an `isolated_project`, restore the uv source from
`main-next` to `main`, rerun `uv run config/update-external.py <fork>`, and verify
the lock still records the validated SHA. Commit and push the follow-up to the
draft Marin PR before marking it ready or merging it.

## The shared vLLM source branch

The vLLM fork has one maintained source branch, `main`. For an upstream GPU
refresh, prepare `main-next` and review the source overlay. Record and push the
rollback tag for the old `main` and the date tag for the reviewed `main-next`
tip. An admin checks those refs and performs the leased hard swap shown above
before building wheels. For an ordinary fork patch, merge its reviewed PR to
`main`.

After source approval, follow [the GPU guide](vllm.md#source-release-and-adoption)
for the wheel build and Marin adoption.
A source swap alone does not change Marin's wheel pin.

The TPU group selects an exact commit already on the shared lineage and never
creates or promotes `tpu` or `tpu-next`. Only its tpu-inference rebase needs the
usual post-e2e `main-next` to `main` hard swap. GPU and TPU artifacts retain
independent qualification and adoption.

## Partial failure

If one pin's admin promotion succeeds and another fails, Marin stays correct because
it pins exact SHAs. Record the mismatch and ask whether to retry the failed promotion.
If the retry still fails, file a
`marin-community/marin` issue assigned to the descriptor's `blocker_assignee` with the
pinned SHAs, the promoted and failed branches, the rollback tags, the commands
attempted, and the error output.
