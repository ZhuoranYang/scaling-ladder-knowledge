# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Post-normalize by-provenance sampler for the Datakit Testbed.

For each source, copy a subset of its *normalized* parquet shards.

Why post-normalize rather than pre:

* Normalize already targets ``target_partition_bytes`` per output shard, so
  the post-normalize shards are **uniform in size**. "First K by filename"
  becomes byte-fair by construction — no hash ordering needed.
* Normalize's ``group_by`` redistributes records across shards by
  ``hash(id)``, so output shards are content-decorrelated from input
  ordering. First-K is also content-fair.
* Row counts are exact (parquet footer), so in-shard row-level targets are
  possible later if we want finer granularity.

Design choices:

* **Deterministic, no RNG.** Sort by filename, take first K. Reproducible
  across ferry reruns.
* **Copy, not manifest.** GCS has no symlinks; a manifest would force a
  downstream API change. Intra-region GCS copy has no network egress — only
  the storage of the sampled subset.
* **Fraction per source** is computed upstream from ``rough_token_count_b``
  against ``RAW_TARGET_TOTAL_TOKENS_B`` via :func:`proportional_sample_fractions`.
"""

import logging
import math
import os
from collections.abc import Sequence
from concurrent.futures import ThreadPoolExecutor

import pyarrow.parquet as pq
from fray.types import ResourceConfig
from marin.datakit.normalize import NormalizedData
from marin.datakit.sources import DatakitSource, all_sources
from marin.execution.artifact import read_artifact
from marin.execution.remote import remote
from marin.execution.step_spec import StepSpec
from rigging.filesystem.buckets import filesystem_for
from rigging.filesystem.factory import url_to_fs
from rigging.filesystem.storage_path import StoragePath
from rigging.filesystem.transfer import copy_plan, execute_copy_plan

from experiments.datakit.testbed.settings import RAW_TARGET_TOTAL_TOKENS_B

_SAMPLE_REMOTE_RESOURCES = ResourceConfig(cpu=1, ram="5g")

logger = logging.getLogger(__name__)

_COPY_PARALLELISM = 32


def proportional_sample_fractions(
    sources: Sequence[DatakitSource],
    target_total_tokens_b: float,
) -> dict[str, float]:
    """Per-source ``sample_fraction`` to hit ``target_total_tokens_b``.

    Each source's ``rough_token_count_b`` determines its share of the
    target; the fraction is ``target_share / its own count``, clamped to
    ``[0.0, 1.0]`` so a source whose target exceeds its known count
    simply contributes all of itself.
    """
    total_count = sum(s.rough_token_count_b for s in sources)
    fractions = {
        src.name: min(1.0, target_total_tokens_b * (src.rough_token_count_b / total_count) / src.rough_token_count_b)
        for src in sources
    }
    clamped = sum(1 for f in fractions.values() if f >= 1.0)
    logger.info(
        "sampler: %d sources, total %.1fB tokens, target %.1fB → fractions range [%.4f, %.4f]"
        " (%d sources clamped to 1.0)",
        len(sources),
        total_count,
        target_total_tokens_b,
        min(fractions.values()),
        max(fractions.values()),
        clamped,
    )
    return fractions


def _part_name(idx: int, total: int) -> str:
    """``part-{idx}-of-{total}.parquet`` — matches normalize's zephyr writer."""
    return f"part-{idx:05d}-of-{total:05d}.parquet"


def _copy_shard(src: str, dst: str) -> int:
    """Copy a non-empty shard to ``dst`` and return its byte size."""
    src_fs, src_path = filesystem_for(src)
    dst_fs, dst_path = filesystem_for(dst)

    src_backend = getattr(src_fs, "_fs", src_fs)
    dst_backend = getattr(dst_fs, "_fs", dst_fs)
    if src_backend is dst_backend:
        parent = os.path.dirname(dst_path)
        if parent:
            dst_fs.makedirs(parent, exist_ok=True)
        src_fs.copy(src_path, dst_path)
    else:
        execute_copy_plan(copy_plan((src,), dst, recursive=False, no_clobber=False))

    size = int(src_fs.size(src_path) or 0)
    assert size > 0, f"sampler: source shard has zero size: {src}"
    return size


def _sample_rows_within_shard(src: str, dst: str, sample_fraction: float) -> tuple[int, int]:
    """Read *src* parquet, take the first ``ceil(rows * sample_fraction)`` rows, write to *dst*.

    Returns ``(rows_in, rows_out)``. First-K is deterministic (no RNG) and
    matches the cross-shard "first K by filename" selection rule.
    """
    logger.info("sampler: row-level sampling %s → %s (fraction=%.4f)", src, dst, sample_fraction)
    src_fs, src_path = url_to_fs(src)
    dst_fs, dst_path = url_to_fs(dst)
    parent = os.path.dirname(dst_path)
    if parent:
        StoragePath(parent).mkdirs(exist_ok=True)

    with src_fs.open(src_path, "rb") as sf:
        pf = pq.ParquetFile(sf)
        rows_in = pf.metadata.num_rows
        rows_out = max(1, math.ceil(rows_in * sample_fraction))
        rows_out = min(rows_out, rows_in)

        logger.info(
            "sampler: streaming %d/%d rows from %s across %d source row groups",
            rows_out,
            rows_in,
            src,
            pf.num_row_groups,
        )

        # Stream source row groups through as-is; slice the last one if it
        # would overshoot the budget. Each input table becomes one output
        # row group (ParquetWriter's default), so the source's row-group
        # layout is preserved.
        remaining = rows_out
        with dst_fs.open(dst_path, "wb") as df, pq.ParquetWriter(df, pf.schema_arrow) as writer:
            for i in range(pf.num_row_groups):
                if remaining <= 0:
                    break
                rg = pf.read_row_group(i)
                if rg.num_rows > remaining:
                    rg = rg.slice(0, remaining)
                writer.write_table(rg)
                remaining -= rg.num_rows
    logger.info("sampler: wrote %d rows to %s (%d bytes)", rows_out, dst, dst_fs.size(dst_path) or 0)

    return rows_in, rows_out


def _parquet_num_rows(path: str) -> int:
    """Read the parquet footer at *path* and return its row count."""
    with StoragePath(path).open("rb") as f:
        return pq.ParquetFile(f).metadata.num_rows


def sample_normalized_shards(
    *,
    source: NormalizedData,
    output_path: str,
    sample_fraction: float,
) -> NormalizedData:
    """Sample ``source``'s normalized shards to a target row count.

    Probes a single shard for rows-per-file, then computes a total row
    budget ``target_rows = N * rows_per_file * sample_fraction``. Takes
    as many whole shards as fit in that budget (cheap server-side copy)
    and, if there's a row-level remainder, row-samples the next shard
    for the tail. When the budget fits inside one shard, skips the copy
    path entirely and row-samples a single file.

    Shards are enumerated under ``source.main_output_dir``, sorted
    lexicographically, and written to ``{output_path}/outputs/main/``
    preserving the relative path so the co-partition invariant
    downstream is satisfied.

    Args:
        source: Upstream normalize output.
        output_path: Step output root; the new ``main_output_dir``
            becomes ``{output_path}/outputs/main``.
        sample_fraction: Fraction of rows to keep, in ``(0.0, 1.0]``.

    Returns:
        A fresh ``NormalizedData`` pointing at the sampled directory.
        ``dup_output_dir`` is passed through unchanged.

    Raises:
        ValueError: If ``sample_fraction`` is out of range or no shards found.
    """
    if not 0.0 < sample_fraction <= 1.0:
        raise ValueError(f"sample_fraction must be in (0.0, 1.0]; got {sample_fraction}")

    input_base = source.main_output_dir.rstrip("/")
    logger.info("sampler: starting (fraction=%.4f) %s → %s", sample_fraction, input_base, output_path)
    shards = sorted(str(m) for m in StoragePath(f"{input_base}/**/*.parquet").glob())
    if not shards:
        raise ValueError(f"No parquet shards under {input_base}")
    total = len(shards)
    main_out = f"{output_path.rstrip('/')}/outputs/main"
    logger.info("sampler: discovered %d parquet shards under %s", total, input_base)

    # Fraction==1.0 short-circuit: take everything as-is.
    if sample_fraction >= 1.0:
        logger.info("sampler: fraction=1.0, copying all %d shards", total)
        tasks = [(s, f"{main_out}/{_part_name(i, total)}") for i, s in enumerate(shards)]
        total_bytes = 0
        with ThreadPoolExecutor(max_workers=_COPY_PARALLELISM) as pool:
            for nbytes in pool.map(lambda args: _copy_shard(*args), tasks):
                total_bytes += nbytes
        logger.info("sampler: copied %d shards, %.1f GiB total", total, total_bytes / (1024**3))
        return NormalizedData(
            main_output_dir=main_out,
            dup_output_dir=source.dup_output_dir,
            counters={"sampler/selected_shards": total, "sampler/total_shards": total},
        )

    # Probe one shard for rows-per-file; normalize's target_partition_bytes
    # keeps shards roughly uniform so this is a good estimate.
    rows_per_file = _parquet_num_rows(shards[0])
    est_total_rows = rows_per_file * total
    target_rows = max(1, math.ceil(est_total_rows * sample_fraction))
    logger.info(
        "sampler: probed rows/shard=%d from %s; est total=%d rows, target=%d rows",
        rows_per_file,
        shards[0],
        est_total_rows,
        target_rows,
    )

    # Case 1: target fits in one file — row-sample from the first shard only.
    if target_rows <= rows_per_file:
        src = shards[0]
        dst = f"{main_out}/{_part_name(0, 1)}"
        row_fraction = target_rows / rows_per_file
        rows_in, rows_out = _sample_rows_within_shard(src, dst, row_fraction)
        logger.info(
            "sampler: target fits in one shard — sampled %d / %d rows from %s",
            rows_out,
            rows_in,
            src,
        )
        return NormalizedData(
            main_output_dir=main_out,
            dup_output_dir=source.dup_output_dir,
            counters={
                "sampler/selected_shards": 1,
                "sampler/total_shards": total,
                "sampler/rows_out": rows_out,
                "sampler/target_rows": target_rows,
            },
        )

    # Case 2: target spans multiple shards — take whole shards for as much
    # as fits, row-sample the next shard for the remainder.
    n_whole = min(target_rows // rows_per_file, total)
    remainder = target_rows - n_whole * rows_per_file
    has_tail = remainder > 0 and n_whole < total
    output_total = n_whole + (1 if has_tail else 0)
    whole_shards = shards[:n_whole]
    logger.info(
        "sampler: %d whole shards + %d remainder rows (from shard #%d if any)",
        n_whole,
        remainder,
        n_whole,
    )

    tasks = [(s, f"{main_out}/{_part_name(i, output_total)}") for i, s in enumerate(whole_shards)]
    total_bytes = 0
    with ThreadPoolExecutor(max_workers=_COPY_PARALLELISM) as pool:
        for nbytes in pool.map(lambda args: _copy_shard(*args), tasks):
            total_bytes += nbytes
    logger.info("sampler: copied %d whole shards, %.1f GiB", n_whole, total_bytes / (1024**3))

    rows_out_total = n_whole * rows_per_file
    if has_tail:
        src = shards[n_whole]
        dst = f"{main_out}/{_part_name(n_whole, output_total)}"
        row_fraction = remainder / rows_per_file
        _, rows_out = _sample_rows_within_shard(src, dst, row_fraction)
        rows_out_total += rows_out

    return NormalizedData(
        main_output_dir=main_out,
        dup_output_dir=source.dup_output_dir,
        counters={
            "sampler/selected_shards": output_total,
            "sampler/total_shards": total,
            "sampler/rows_out": rows_out_total,
            "sampler/target_rows": target_rows,
        },
    )


def sample_normalized_shards_step(
    *,
    name: str,
    normalized: StepSpec,
    sample_fraction: float,
    override_output_path: str | None = None,
) -> StepSpec:
    """Create a StepSpec that samples ``normalized``'s output shards.

    The step loads the upstream ``NormalizedData`` artifact at execution time,
    so the sampled shard set reflects whatever normalize actually emitted.
    Runs remotely via Fray with :data:`_SAMPLE_REMOTE_RESOURCES` so the
    entrypoint doesn't OOM when orchestrating many sources concurrently.
    """
    # Resolve the normalize output path once at factory time so the remote
    # fn's closure only captures strings + a float (cleanly picklable).
    normalized_path = normalized.output_path

    def sample(output_path: str) -> NormalizedData:
        return sample_normalized_shards(
            source=read_artifact(normalized_path, NormalizedData),
            output_path=output_path,
            sample_fraction=sample_fraction,
        )

    return StepSpec(
        name=name,
        deps=[normalized],
        hash_attrs={"sample_fraction": sample_fraction},
        fn=remote(sample, resources=_SAMPLE_REMOTE_RESOURCES),
        override_output_path=override_output_path,
    )


def _sample_step_for(
    src: DatakitSource,
    normalized: StepSpec,
    sample_fraction: float,
) -> StepSpec:
    """Per-source post-normalize sampler. Copies first ceil(N * fraction) shards."""
    return sample_normalized_shards_step(
        name=f"data/datakit/normalized/{src.name}",
        normalized=normalized,
        sample_fraction=sample_fraction,
    )


def build_testbed_steps(
    sources: Sequence[DatakitSource] | None = None,
    target_total_tokens_b: float = RAW_TARGET_TOTAL_TOKENS_B,
) -> list[StepSpec]:
    """Build the full Datakit Testbed ferry DAG.

    Composes the canonical Datakit stages into one multi-source pipeline:
    ``<source.normalize_steps> ─► sample[source]``.

    Each :class:`DatakitSource` already carries its full
    ``(download, ..., normalize)`` :class:`StepSpec` chain; this function
    appends the testbed-specific sample stage on top of every source's
    terminal normalize step. Sample outputs land at hashed paths
    (``data/datakit/normalized/{src.name}-{hash}/``) — the hash incorporates
    ``sample_fraction`` so different fractions don't collide. Tokenize
    runs in the training executor graph (see
    :mod:`experiments.datakit.testbed.train`), not the ferry.

    Args:
        sources: DatakitSource list to ferry. ``None`` selects every entry
            from :func:`all_sources`. The executor will skip sources whose
            normalize output is already cached, so unconditionally including
            them is safe; not-yet-ready sources will be normalized on demand.
        target_total_tokens_b: Target total token count (in billions)
            across the sampled set. Drives per-source sample fractions
            via :func:`proportional_sample_fractions`. Default is
            :data:`RAW_TARGET_TOTAL_TOKENS_B`.

    Returns:
        Flat list of :class:`StepSpec` covering every normalize chain plus
        one sample step per source. Ready to hand to ``StepRunner().run()``.
    """
    if sources is None:
        sources = tuple(all_sources().values())
    if not sources:
        raise ValueError("build_testbed_steps requires at least one source")

    fractions = proportional_sample_fractions(sources, target_total_tokens_b=target_total_tokens_b)

    # Flat list of every source's normalize chain + terminal sample step.
    # StepRunner walks transitive deps and dedupes by output_path, so shared
    # family downloads (e.g. Nemotron v2 subsets) are safe to emit more than
    # once; hidden deps reached only through a step's ``.deps`` resolve too.
    all_steps: list[StepSpec] = []
    for src in sources:
        all_steps.extend(src.normalize_steps)
        all_steps.append(_sample_step_for(src, src.normalized, fractions[src.name]))

    logger.info(
        "Built testbed DAG: %d sources, %d steps (normalize chains + sample), target %.0fB tokens",
        len(sources),
        len(all_steps),
        target_total_tokens_b,
    )
    return all_steps
