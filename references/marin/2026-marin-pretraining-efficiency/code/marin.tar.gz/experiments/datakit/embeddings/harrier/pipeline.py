# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Map normalized documents to co-partitioned int8 Harrier embeddings."""

import logging
import os
import shutil
import tarfile
import tempfile
from collections.abc import Iterator
from functools import cache
from pathlib import Path

import numpy as np
import pyarrow as pa
from fray.types import ResourceConfig
from huggingface_hub import snapshot_download
from marin.datakit.normalize import NormalizedData
from marin.datakit.source_key import DatakitArtifactPath, datakit_source_key
from marin.execution.artifact import write_artifact
from marin.processing.embeddings.harrier import HARRIER_DIM, HARRIER_REPO, HARRIER_REVISION
from marin.processing.embeddings.read_chunks import rows_per_chunk
from pydantic import BaseModel, Field
from rigging.filesystem.cluster_config import marin_temp_bucket
from rigging.filesystem.storage_path import StoragePath
from zephyr import counters
from zephyr.context import ZephyrContext
from zephyr.dataset import Dataset, ShardInfo
from zephyr.input_file import InputFileSpec
from zephyr.reader import Reader, flat_map_reader
from zephyr.readers import load_file, load_parquet_batch
from zephyr.runners import InlineRunner
from zephyr.worker_context import zephyr_worker_ctx

from experiments.datakit.embeddings.harrier.tei_client import TeiEmbeddingClient

logger = logging.getLogger(__name__)

EMBEDDING_ATTR_DATA_VERSION = "2026.08.11"
HARRIER_MAX_TOKENS = 8_192
HARRIER_MAX_RAW_TEXT_CHARS = 100_000
HARRIER_MAX_WORKERS = 256
TEMP_TTL_DAYS = 1

DEFAULT_BATCH_SIZE = 4_096

_MODEL_ARCHIVE_NAME = "model.tar"
_MODEL_DIRECTORY_NAME = "model"
_TEI_ENDPOINT_SHARED_KEY = "harrier_tei_endpoint_name"


def harrier_hash_attrs(dedup: str) -> dict[str, str | int]:
    """Return the artifact identity for a Harrier embedding step."""
    return {
        "dedup": dedup,
        "model": HARRIER_REPO,
        "revision": HARRIER_REVISION,
        "batch_size": DEFAULT_BATCH_SIZE,
        "v": EMBEDDING_ATTR_DATA_VERSION,
    }


# A sweep over 9,733 completed Harrier embeddings sampled across 100 shards of
# datakit/samples/harrier-50m found mean cosine 0.99976, minimum cosine 0.99909,
# and 0.00012% coordinate clipping at +/-0.3.
QUANT_RANGE = 0.3
QUANT_SCALE: float = QUANT_RANGE / 127

_EMBEDDING_SCHEMA = pa.schema(
    [
        pa.field("id", pa.string()),
        pa.field("embedding", pa.list_(pa.int8(), HARRIER_DIM)),
    ]
)


class EmbeddingAttrData(BaseModel):
    """Co-partitioned per-source embedding shards."""

    version: str = EMBEDDING_ATTR_DATA_VERSION
    output_dir: DatakitArtifactPath
    source_key: str
    dedup_attr_dir: DatakitArtifactPath | None = None
    model_name: str
    model_revision: str = ""
    embedding_dim: int
    quantization_scale: float
    quantization_range: float
    batch_size: int
    counters: dict[str, int | float] = Field(default_factory=dict)

    def shard_paths(self) -> list[str]:
        return sorted(str(path) for path in (StoragePath(self.output_dir) / "*.parquet").glob())


def quantize_to_int8(arr: np.ndarray) -> np.ndarray:
    """Quantize fp32 values into the calibrated Harrier int8 range."""
    return np.clip(np.round(arr / QUANT_SCALE), -127, 127).astype(np.int8)


def dequantize_to_fp32(arr: np.ndarray, scale: float = QUANT_SCALE) -> np.ndarray:
    """Restore approximate normalized vectors from int8 storage."""
    return arr.astype(np.float32) * scale


def stage_harrier(repo_id: str, revision: str, destination_path: str) -> str:
    """Download and archive a pinned model in the output region."""
    archive_url = str(
        StoragePath(marin_temp_bucket(ttl_days=TEMP_TTL_DAYS, prefix="harrier-staging", source_prefix=destination_path))
        / repo_id.replace("/", "__")
        / revision
        / _MODEL_ARCHIVE_NAME
    )
    staged_archive = StoragePath(archive_url)
    if staged_archive.exists() and staged_archive.size() > 0:
        logger.info("Harrier model already staged at %s", archive_url)
        return archive_url

    logger.info("Fetching Harrier model %s@%s", repo_id, revision)
    with tempfile.TemporaryDirectory() as temporary_directory:
        model_path = Path(temporary_directory) / _MODEL_DIRECTORY_NAME
        snapshot_download(repo_id=repo_id, revision=revision, local_dir=model_path)
        archive_path = Path(temporary_directory) / _MODEL_ARCHIVE_NAME
        with tarfile.open(archive_path, "w", dereference=True) as archive:
            archive.add(model_path, arcname=_MODEL_DIRECTORY_NAME)

        staged_archive.parent.mkdirs()
        with archive_path.open("rb") as source, staged_archive.open("wb") as destination:
            shutil.copyfileobj(source, destination)
        if staged_archive.size() != archive_path.stat().st_size:
            raise ValueError(f"Staged Harrier archive at {archive_url} has the wrong size")
    return archive_url


@cache
def _load_tei_embedder(endpoint_name: str) -> TeiEmbeddingClient:
    return TeiEmbeddingClient(endpoint_name, HARRIER_DIM)


def _truncated_records(batch: pa.RecordBatch) -> Iterator[dict]:
    # Slicing first keeps to_pylist from turning a whole row group of untruncated text into
    # Python objects; the Arrow row group itself is still read whole.
    per_chunk = rows_per_chunk(batch.num_rows, batch.nbytes)
    for offset in range(0, batch.num_rows, per_chunk):
        for record in batch.slice(offset, per_chunk).to_pylist():
            record["text"] = record["text"][:HARRIER_MAX_RAW_TEXT_CHARS]
            yield record


def _load_truncated_documents(spec: InputFileSpec) -> Reader[dict]:
    """Read ``id``/``text`` records, keeping the first HARRIER_MAX_RAW_TEXT_CHARS of each text.

    Truncating before ``window`` bounds the window and the TEI call by the cap rather than
    by raw document size.
    """
    return flat_map_reader(load_parquet_batch(spec), _truncated_records)


def _embed_shard(batches: Iterator[list[dict]], shard: ShardInfo) -> Iterator[dict]:
    endpoint_name: str = zephyr_worker_ctx().get_shared(_TEI_ENDPOINT_SHARED_KEY)
    embedder = _load_tei_embedder(endpoint_name)
    document_count = 0
    byte_count = 0
    for batch in batches:
        ids = [record["id"] for record in batch]
        texts = [record["text"] for record in batch]
        document_count += len(ids)
        byte_count += sum(len(text.encode()) for text in texts)
        embeddings = embedder.embed(texts)
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        embeddings = quantize_to_int8(embeddings / norms)
        for document_id, embedding in zip(ids, embeddings, strict=True):
            yield {"id": document_id, "embedding": embedding.tolist()}

    counters.pipeline.update_counter("embed/docs_in", document_count)
    counters.pipeline.update_counter("embed/bytes_in", byte_count)
    counters.pipeline.update_counter("embed/shards_in", 1)
    logger.info(
        "shard %d/%d: %d docs (%.1f MB) encoded",
        shard.shard_idx,
        shard.total_shards,
        document_count,
        byte_count / 1024 / 1024,
    )


def _drop_dedup_duplicate(document: dict, dedup: dict | None) -> dict | None:
    if dedup is None or dedup["is_cluster_canonical"]:
        return document
    counters.pipeline.update_counter("embed/docs_dedup_dropped", 1)
    return None


def embed_source(
    output_path: str,
    normalized: NormalizedData,
    *,
    endpoint_name: str,
    batch_size: int = DEFAULT_BATCH_SIZE,
    max_shards: int | None = None,
    dedup_attr_dir: str | None = None,
    worker_resources: ResourceConfig | None = None,
    max_workers: int = HARRIER_MAX_WORKERS,
) -> EmbeddingAttrData:
    """Embed the parquet shards in a normalized source."""
    source_shards = sorted(str(path) for path in (StoragePath(normalized.main_output_dir) / "**" / "*.parquet").glob())
    if max_shards is not None:
        source_shards = source_shards[:max_shards]
    if not source_shards:
        raise RuntimeError(f"No source parquet shards under {normalized.main_output_dir}")

    output_basenames = tuple(os.path.basename(path) for path in source_shards)

    def _output_path(shard_index: int, _total: int, basenames: tuple[str, ...] = output_basenames) -> str:
        return str(StoragePath(output_path) / basenames[shard_index])

    source_specs = [InputFileSpec(path=path, columns=["id", "text"]) for path in source_shards]
    documents = Dataset.from_list(source_specs).flat_map(_load_truncated_documents)
    if dedup_attr_dir is not None:
        dedup_specs = [
            InputFileSpec(
                path=str(StoragePath(dedup_attr_dir) / os.path.basename(path)),
                columns=["id", "is_cluster_canonical"],
            )
            for path in source_shards
        ]
        dedup_attrs = Dataset.from_list(dedup_specs).flat_map(load_file)
        documents = documents.sorted_merge_join(
            dedup_attrs,
            left_key=lambda record: record["id"],
            right_key=lambda record: record["id"],
            combiner=_drop_dedup_duplicate,
            how="left",
        ).filter(lambda record: record is not None)

    dataset = (
        documents.window(batch_size)
        .map_shard(_embed_shard)
        .write_parquet(_output_path, schema=_EMBEDDING_SCHEMA, skip_existing=True)
    )
    resources = worker_resources or ResourceConfig.with_cpu(cpu=1, ram="16g", disk="16g")
    context = ZephyrContext(
        resources=resources,
        coordinator_resources=ResourceConfig(cpu=1, ram="8g", preemptible=False),
        max_workers=min(max_workers, HARRIER_MAX_WORKERS, len(source_shards)),
        chunk_storage_prefix=marin_temp_bucket(ttl_days=TEMP_TTL_DAYS, prefix="zephyr", source_prefix=output_path),
        name=f"embed-harrier-{os.path.basename(normalized.main_output_dir)[:8]}",
        stage_runner_factory=InlineRunner,
    )
    context.put(_TEI_ENDPOINT_SHARED_KEY, endpoint_name)
    outcome = context.execute(dataset, verbose=True)

    artifact = EmbeddingAttrData(
        output_dir=output_path,
        source_key=datakit_source_key(normalized.main_output_dir),
        dedup_attr_dir=dedup_attr_dir,
        model_name=HARRIER_REPO,
        model_revision=HARRIER_REVISION,
        embedding_dim=HARRIER_DIM,
        quantization_scale=QUANT_SCALE,
        quantization_range=QUANT_RANGE,
        batch_size=batch_size,
        counters=dict(outcome.counters),
    )
    write_artifact(artifact, output_path)
    return artifact
