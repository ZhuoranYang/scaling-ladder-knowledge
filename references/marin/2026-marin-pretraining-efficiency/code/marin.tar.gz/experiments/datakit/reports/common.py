# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Shared plumbing for the per-stage datakit reports.

Every stage report is one StepSpec whose fn aggregates that stage's per-source
artifacts (counters + a bounded read of site/sample parquet), renders a single
self-contained HTML page from a template in ``templates/``, and returns a
:class:`StageReport`. Templates embed their data as JSON via the ``__DATA__``
placeholder, so a report works offline and can be hosted anywhere.
"""

import html
import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any

import pyarrow as pa
import pyarrow.parquet as pq
from marin.datakit.source_key import DatakitArtifactPath
from pydantic import BaseModel
from rigging.filesystem.storage_path import StoragePath

TEMPLATES = Path(__file__).parent / "templates"
REPORT_FILE = "report.html"


class StageReport(BaseModel):
    """Outcome of a stage-report step: the rendered page plus its headline stats.

    Persisted as the step's ``.artifact``; ``stats`` mirrors the numbers shown
    on the page so downstream tooling can read them without parsing HTML.
    """

    version: str = "v1"
    html_path: DatakitArtifactPath
    stats: dict[str, Any]


def render_template(template_name: str, *, title: str, data: dict) -> str:
    """Render ``templates/<template_name>`` with ``__TITLE__`` and ``__DATA__`` filled in."""
    blob = json.dumps(data).replace("</", "<\\/")
    return (TEMPLATES / template_name).read_text().replace("__TITLE__", html.escape(title)).replace("__DATA__", blob)


def write_report(output_path: str, page: str) -> str:
    """Write the rendered page to ``<output_path>/report.html`` and return its path."""
    path = f"{output_path.rstrip('/')}/{REPORT_FILE}"
    with StoragePath(path).open("w") as fh:
        fh.write(page)
    return path


def parquet_files(directory: str) -> list[str]:
    """The parquet files directly under ``directory``, sorted.

    A single-level ``*.parquet`` glob: a recursive glob makes s3fs ``HeadObject``
    the prefix, which the CW object store rejects.
    """
    return sorted(str(m) for m in (StoragePath(directory) / "*.parquet").glob())


def iter_batches(directory: str, columns: list[str], batch_size: int) -> Iterator[pa.RecordBatch]:
    """Stream ``columns`` from the parquet files under ``directory`` in sorted file order."""
    for f in parquet_files(directory):
        with StoragePath(f).open("rb") as fh:
            yield from pq.ParquetFile(fh).iter_batches(batch_size=batch_size, columns=columns)


def head_rows(path: str, columns: list[str], limit: int) -> list[dict]:
    """Read the first ``limit`` rows of ``columns`` from one parquet file, streaming batches."""
    out: list[dict] = []
    with StoragePath(path).open("rb") as fh:
        for batch in pq.ParquetFile(fh).iter_batches(batch_size=min(limit, 4096), columns=columns):
            out.extend(batch.to_pylist()[: limit - len(out)])
            if len(out) >= limit:
                break
    return out


def sample_rows(directory: str, columns: list[str], limit: int) -> list[dict]:
    """Read up to ``limit`` rows of ``columns`` from the parquet files under ``directory``, in file order."""
    out: list[dict] = []
    for f in parquet_files(directory):
        out.extend(head_rows(f, columns, limit - len(out)))
        if len(out) >= limit:
            break
    return out
