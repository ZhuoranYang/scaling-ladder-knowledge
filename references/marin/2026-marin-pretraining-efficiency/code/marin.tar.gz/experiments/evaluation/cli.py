# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0

"""Command-line entry point for the eval launcher.

``uv run python -m experiments.evaluation.cli launch --model qwen3-8b --evals smoke``.
``launch`` submits runs and optionally waits for their object-store records. Fleet-wide archive
sweeps are administrative and live in :mod:`experiments.evaluation.migrations.cli`.
"""

from __future__ import annotations

import logging
from pathlib import Path

import click
from iris.cli.connect import open_iris_client
from iris.rpc import job_pb2
from iris.rpc.proto_display import PRIORITY_BAND_NAMES, priority_band_name, priority_band_value
from marin.evaluation.harbor.runner import canonical_served_name
from marin.evaluation.hardware import Platform, default_platform
from marin.evaluation.model_config import ModelConfig, load_model_config
from marin.evaluation.runner import EvaluationBatch, wait_and_report
from rigging.config_discovery import find_project_root

from experiments.evaluation.evals import EvalchemyDefinition, HarborDefinition, resolve_eval_keys
from experiments.evaluation.launch import (
    DEFAULT_EVAL_CONCURRENCY,
    EVALUATION_CONTROLLER_CLUSTER,
    LaunchSpec,
    launch_group,
    prepare_evaluation_batch,
)
from experiments.evaluation.models import models
from experiments.evaluation.policy_finalization import load_policy_finalization

logger = logging.getLogger(__name__)


def _resolve_eval_keys(evals_arg: str) -> tuple[str, ...]:
    try:
        return resolve_eval_keys(evals_arg)
    except ValueError as error:
        raise click.BadParameter(str(error)) from error


def _load_selected_model(
    model_key: str | None,
    config_path: Path | None,
    *,
    key_hint: str,
    config_hint: str,
    label: str,
) -> ModelConfig:
    if config_path is not None:
        try:
            return load_model_config(config_path)
        except Exception as exc:
            raise click.BadParameter(str(exc), param_hint=config_hint) from exc
    if model_key is None:
        raise click.BadParameter(f"missing {label} selector", param_hint=f"{key_hint}/{config_hint}")
    catalog = models()
    if model_key not in catalog:
        raise click.BadParameter(
            f"unknown {label} {model_key!r}; known: {sorted(catalog)}",
            param_hint=key_hint,
        )
    return catalog[model_key]


def resolve_model_config(model_key: str | None, config_path: Path | None) -> ModelConfig:
    """Resolve exactly one model registry key or catalog-schema file."""
    if (model_key is None) == (config_path is None):
        raise click.BadParameter(
            "specify exactly one of --model or --model-config",
            param_hint="--model/--model-config",
        )
    return _load_selected_model(
        model_key,
        config_path,
        key_hint="--model",
        config_hint="--model-config",
        label="model",
    )


def resolve_judge_model_config(model_key: str | None, config_path: Path | None) -> ModelConfig | None:
    """Resolve an optional hosted judge from the same model catalog schema."""
    if model_key is None and config_path is None:
        return None
    if model_key is not None and config_path is not None:
        raise click.BadParameter(
            "specify at most one of --judge-model or --judge-model-config",
            param_hint="--judge-model/--judge-model-config",
        )
    return _load_selected_model(
        model_key,
        config_path,
        key_hint="--judge-model",
        config_hint="--judge-model-config",
        label="judge model",
    )


def _print_plan(spec: LaunchSpec, batch: EvaluationBatch) -> None:
    geometry = batch.accelerator.geometry
    serving = geometry.label if geometry is not None else "worker-resolved"
    serving = f"{serving} instances={batch.model.serve.instances}"
    task_count = (geometry.task_count if geometry is not None else 1) * batch.model.serve.instances
    click.echo(
        f"model: {spec.model.name}  platform: {spec.platform.value}  "
        f"controller_cluster={EVALUATION_CONTROLLER_CLUSTER}  "
        f"target_cluster={batch.accelerator.target_cluster or 'none'}  "
        f"priority={priority_band_name(batch.priority_band)}  instances={batch.instances}  "
        f"max_concurrent={batch.max_concurrent}"
    )
    if batch.judge is not None:
        click.echo(
            f"judge: {batch.judge.model.name}  location={batch.judge.model.location}  "
            f"accel={batch.judge.accelerator.label}  "
            f"region_or_cluster={batch.judge.accelerator.target_cluster or batch.judge.accelerator.region}"
        )
    for evaluation in batch.evaluations:
        eval_ref = evaluation.identity.eval_ref
        tasks = [task.name for task in eval_ref.tasks]
        harbor = eval_ref.harbor
        agent_context = ""
        if harbor is not None:
            agent_context = f"max_input_tokens={harbor.max_input_tokens}  max_output_tokens={harbor.max_output_tokens}  "
        click.echo(
            f"  eval={eval_ref.name}  location={batch.model.location}  "
            f"backend={batch.model.serve.backend.value}  accel={batch.accelerator.label}  "
            f"serve={serving} tasks={task_count} x {batch.accelerator.label}  "
            f"region_or_cluster={batch.accelerator.target_cluster or batch.accelerator.region}  "
            f"tasks={tasks}  "
            f"{agent_context}"
            f"records={batch.records_prefix}  "
            f"results={evaluation.identity.output_dir}"
        )


@click.group()
def cli() -> None:
    """Launch and track model evaluations."""


@cli.command()
@click.option("--model", default=None, help="Model registry key. Mutually exclusive with --model-config.")
@click.option(
    "--model-config",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help="Model catalog YAML or JSON. Mutually exclusive with --model.",
)
@click.option("--judge-model", default=None, help="Optional hosted judge model registry key.")
@click.option(
    "--judge-model-config",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help="Optional hosted judge model catalog YAML or JSON.",
)
@click.option("--judge-accelerator", default=None, help="Hosted judge slice override, e.g. 'H100x8'.")
@click.option(
    "--evals",
    "evals_arg",
    default=None,
    help="Suite name (e.g. 'smoke') or comma-separated eval keys; defaults to smoke.",
)
@click.option(
    "--evalchemy-config",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    multiple=True,
    help="Portable Evalchemy YAML or JSON. Repeatable and additive with --evals and --harbor-config.",
)
@click.option(
    "--harbor-config",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    multiple=True,
    help="Harbor JobConfig YAML or JSON. Repeatable and additive with --evals.",
)
@click.option(
    "--retry-unscored-harbor-trials",
    is_flag=True,
    help="Retry known unscored Harbor trials in --resume-results-path; preserve scored and unknown-error outcomes.",
)
@click.option(
    "--platform",
    type=click.Choice([p.value for p in Platform]),
    default=None,
    help="Force tpu or gpu; defaults from the model.",
)
@click.option("--accelerator", default=None, help="Slice override, e.g. 'v6e-8' or 'H100x8'.")
@click.option("--limit", type=int, default=None, help="Override max eval instances per task.")
@click.option(
    "--instances",
    type=click.IntRange(min=1),
    default=1,
    show_default=True,
    help="Candidate serving instances, each using the selected accelerator; multiple instances share a broker.",
)
@click.option(
    "--max-concurrent",
    type=click.IntRange(min=1),
    default=DEFAULT_EVAL_CONCURRENCY,
    show_default=True,
    help="Maximum concurrent evaluators sharing inference.",
)
@click.option("--seed", type=int, default=None, help="Override the Evalchemy sampling seed for this launch.")
@click.option(
    "--version",
    "version",
    default=None,
    help=(
        "Submitter-controlled cohort label, e.g. '2026.07.20' or 'rl-fix-sweep'. "
        "This is provenance metadata, not an eval-policy conformance claim."
    ),
)
@click.option("--description", default=None, help="Free-text note on why this launch was run.")
@click.option(
    "--resume-results-path",
    default=None,
    help=(
        "Existing object-store results path for a single Harbor evaluation. "
        "Use only after every earlier driver for that path has ended."
    ),
)
@click.option(
    "--run-id", default=None, help="Stable launch ID; repeat the command with this ID to reuse completed evals."
)
@click.option("--no-wait", is_flag=True, help="Submit and return without waiting for results.")
@click.option("--dry-run", is_flag=True, help="Print the resolved plan without submitting.")
@click.option(
    "--records-prefix",
    default=None,
    help="Object-store prefix for run records; defaults to GCS, or CW S3 for CoreWeave-routed runs.",
)
@click.option(
    "--federated_cluster",
    default=None,
    help="Override the federated cluster for GPU serving; defaults to the fleet profile.",
)
@click.option(
    "--priority",
    type=click.Choice(PRIORITY_BAND_NAMES, case_sensitive=False),
    default=None,
    help="Iris priority band for the orchestrator and serve jobs; defaults to inherit.",
)
@click.option(
    "--policy-finalization-config",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    help="Frozen judge and SOTOPIA cohort configuration; enabled by the policy campaign launcher.",
)
def launch(
    model: str | None,
    model_config: Path | None,
    judge_model: str | None,
    judge_model_config: Path | None,
    judge_accelerator: str | None,
    policy_finalization_config: Path | None,
    evals_arg: str | None,
    evalchemy_config: tuple[Path, ...],
    harbor_config: tuple[Path, ...],
    retry_unscored_harbor_trials: bool,
    platform: str | None,
    accelerator: str | None,
    limit: int | None,
    max_concurrent: int,
    instances: int,
    seed: int | None,
    version: str | None,
    description: str | None,
    resume_results_path: str | None,
    run_id: str | None,
    no_wait: bool,
    dry_run: bool,
    records_prefix: str | None,
    federated_cluster: str | None,
    priority: str | None,
) -> None:
    """Submit evaluations against a shared candidate endpoint for MODEL."""
    selected_model = resolve_model_config(model, model_config)
    selected_judge = resolve_judge_model_config(judge_model, judge_model_config)
    resolved_platform = Platform(platform) if platform else default_platform(selected_model)
    evalchemy_definitions = [
        EvalchemyDefinition(
            name=canonical_served_name(path.stem),
            config_path=path,
        )
        for path in evalchemy_config
    ]
    harbor_definitions = [
        HarborDefinition(
            name=canonical_served_name(path.stem),
            config_path=path,
        )
        for path in harbor_config
    ]
    evals = (
        _resolve_eval_keys(evals_arg)
        if evals_arg is not None
        else (() if evalchemy_definitions or harbor_definitions else _resolve_eval_keys("smoke"))
    )
    spec = LaunchSpec(
        model=selected_model,
        evals=evals,
        evalchemy_definitions=tuple(evalchemy_definitions),
        harbor_definitions=tuple(harbor_definitions),
        platform=resolved_platform,
        accelerator=accelerator,
        limit=limit,
        max_concurrent=max_concurrent,
        instances=instances,
        seed=seed,
        records_prefix=records_prefix,
        submission_cluster=EVALUATION_CONTROLLER_CLUSTER,
        federated_cluster=federated_cluster,
        priority_band=(job_pb2.PRIORITY_BAND_INHERIT if priority is None else priority_band_value(priority)),
        judge_model=selected_judge,
        judge_accelerator=judge_accelerator,
        retry_unscored_harbor_trials=retry_unscored_harbor_trials,
        version=version,
        description=description,
        resume_results_path=resume_results_path,
        run_id=run_id,
        policy_finalization=load_policy_finalization(policy_finalization_config) if policy_finalization_config else None,
    )
    try:
        batch = prepare_evaluation_batch(spec)
    except ValueError as exc:
        if resume_results_path is not None:
            param_hint = "--resume-results-path"
        else:
            param_hint = "--evalchemy-config/--harbor-config" if evalchemy_config or harbor_config else "--evals"
        raise click.BadParameter(str(exc), param_hint=param_hint) from exc
    if dry_run:
        _print_plan(spec, batch)
        return
    with open_iris_client(cluster_name=EVALUATION_CONTROLLER_CLUSTER, workspace=find_project_root()) as client:
        group = launch_group(batch, client)
        click.echo(
            f"submitted group {group.group_id} ({len(group.evaluations)} evals sharing inference) "
            f"through cluster {EVALUATION_CONTROLLER_CLUSTER!r}"
        )
        for evaluation in group.evaluations:
            click.echo(f"  {evaluation.run_id}  ({group.model_name} / {evaluation.eval_name})")
        if no_wait:
            return
        wait_and_report([group])


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
