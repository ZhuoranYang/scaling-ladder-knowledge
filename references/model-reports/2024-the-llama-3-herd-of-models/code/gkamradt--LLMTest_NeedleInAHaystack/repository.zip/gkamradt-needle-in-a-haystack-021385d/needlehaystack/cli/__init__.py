"""`niah` CLI entry points."""
