/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree.
 */

// clang-format off
{% set wdesc =  "weighted" if weighted else "unweighted" %}

#include <algorithm>
#include <ATen/ATen.h>
#include <ATen/Context.h>
#include <ATen/Parallel.h>

#include "fbgemm_gpu/utils/cpu_utils.h"
#include "fbgemm_gpu/utils/embedding_cpu_threading.h"
#include "fbgemm_gpu/utils/dispatch_macros.h"
#include "fbgemm_gpu/embedding_common.h"
#include "fbgemm/FbgemmEmbedding.h"
#include "fbgemm/Types.h"
#include "fbgemm/Utils.h"
#include "fbgemm_gpu/utils/tensor_utils.h"
#include "fbgemm_gpu/config/feature_gates.h"

#if defined(__x86_64__) || defined(__i386__) || (defined(_MSC_VER) && (defined(_M_X64) || defined(_M_IX86)))
#include <immintrin.h>
#include <emmintrin.h>
#endif
#include <cstring>
#include <exception>
#include <optional>
#include <ATen/ThreadLocalState.h>
#include <ATen/record_function.h>

using namespace fbgemm_gpu;

namespace {

using Tensor = at::Tensor;

C10_NOINLINE void check_fp8_params(int64_t fp8_exponent_bits, int64_t fp8_exponent_bias) {
  TORCH_CHECK(fp8_exponent_bits > 0 && fp8_exponent_bias > 0, "FP8 requires fp8_exponent_bits > 0 (got ", fp8_exponent_bits, ") and fp8_exponent_bias > 0 (got ", fp8_exponent_bias, ")");
}

// kPropagateTls: raw OpenMP does not carry the caller's ThreadLocalState
// (dispatch keys, grad/inference mode, autocast, ...) to worker threads the way
// at::parallel_for does, so when `f` makes ATen calls (e.g. at::arange in the
// nobag path) it is captured here and restored on each worker. Restoring it is
// not free: the guard's ctor and dtor both snapshot the RecordFunction
// callbacks under one process-global mutex, which serializes every worker of
// every region. Callers whose `f` makes no ATen calls pass false.
template <bool kPropagateTls = true, typename F>
inline void parallel_for_table_threads(
    int begin,
    int end,
    const F& f) {

  const int num_threads = choose_num_threads(end - begin);

  // Short-cut, no need to invoke openmp
  if (num_threads == 1) {
    f(begin, end);
    return;
  }

  std::optional<at::ThreadLocalState> tls;
  if constexpr (kPropagateTls) {
    tls.emplace();
  }

  bool have_err = false;
  std::exception_ptr eptr;

  #ifdef _OPENMP
  #pragma omp parallel num_threads(num_threads)
  #endif
  {
    try {
        std::optional<at::ThreadLocalStateGuard> tls_guard;
        if constexpr (kPropagateTls) {
          tls_guard.emplace(*tls);
        }
        #ifdef _OPENMP
        #pragma omp for schedule(dynamic) nowait
        #endif
        for (int t = begin; t < end; ++t) {
            try {
                f(t, t + 1);
            } catch (...) {
                // std::exception_ptr is not atomic,
                // hence we need a critical section here in case multiple threads have exceptions
                #ifdef _OPENMP
                #pragma omp critical(tbe_table_threads_err)
                #endif
                {
                    if (!have_err) {
                        have_err = true;
                        eptr = std::current_exception();
                    }
                }
            }
        }
    } catch (...) {
        #ifdef _OPENMP
        #pragma omp critical(tbe_table_threads_err)
        #endif
        {
            if (!have_err) {
                have_err = true;
                eptr = std::current_exception();
            }
        }
    }
  }
  if (eptr) {
    std::rethrow_exception(eptr);
  }
}

// Same contract as parallel_for_table_threads, but the unit of work is a
// (table, row-range) chunk instead of a whole table. Used by the NOBAG path,
// where splitting a table's rows is safe because each output row is an
// independent gather writing a disjoint output slice. See
// parallel_for_table_threads for kPropagateTls.
template <bool kPropagateTls = true, typename F>
inline void parallel_for_row_chunks(
    const std::vector<fbgemm_gpu::RowChunk>& chunks,
    int num_threads,
    const F& f) {
  if (num_threads <= 1 || chunks.size() <= 1) {
    for (const auto& c : chunks) {
      f(c.t, c.r0, c.r1);
    }
    return;
  }

  std::optional<at::ThreadLocalState> tls;
  if constexpr (kPropagateTls) {
    tls.emplace();
  }

  bool have_err = false;
  std::exception_ptr eptr;
  const int64_t n_chunks = static_cast<int64_t>(chunks.size());

  #ifdef _OPENMP
  #pragma omp parallel num_threads(num_threads)
  #endif
  {
    try {
        std::optional<at::ThreadLocalStateGuard> tls_guard;
        if constexpr (kPropagateTls) {
          tls_guard.emplace(*tls);
        }
        #ifdef _OPENMP
        #pragma omp for schedule(dynamic) nowait
        #endif
        for (int64_t i = 0; i < n_chunks; ++i) {
            try {
                f(chunks[i].t, chunks[i].r0, chunks[i].r1);
            } catch (...) {
                // std::exception_ptr is not atomic,
                // hence we need a critical section here in case multiple threads have exceptions
                #ifdef _OPENMP
                #pragma omp critical(tbe_row_chunks_err)
                #endif
                {
                    if (!have_err) {
                        have_err = true;
                        eptr = std::current_exception();
                    }
                }
            }
        }
    } catch (...) {
        #ifdef _OPENMP
        #pragma omp critical(tbe_row_chunks_err)
        #endif
        {
            if (!have_err) {
                have_err = true;
                eptr = std::current_exception();
            }
        }
    }
  }
  if (eptr) {
    std::rethrow_exception(eptr);
  }
}

inline uint32_t pruned_hash_function(uint32_t h) {
    // MurmorHash3 32-bit mixing function.
    h ^= h >> 16;
    h *= 0x85ebca6b;
    h ^= h >> 13;
    h *= 0xc2b2ae35;
    h ^= h >> 16;
    return h;
}

inline uint64_t pruned_hash_function(uint64_t k) {
  // MurmorHash3 64-bit mixing function.
  k ^= k >> 33;
  k *= (0xff51afd7ed558ccd);
  k ^= k >> 33;
  k *= (0xc4ceb9fe1a85ec53);
  k ^= k >> 33;
  return k;
}

} // namespace

void pruned_hashmap_insert_{{ wdesc }}_cpu(
    Tensor indices,
    Tensor dense_indices,
    Tensor offsets,
    Tensor hash_table,
    Tensor hash_table_offsets) {
    TENSOR_ON_CPU(indices);
    TENSOR_ON_CPU(dense_indices);
    TENSOR_ON_CPU(offsets);
    TENSOR_ON_CPU(hash_table);
    TENSOR_ON_CPU(hash_table_offsets);
    TENSORS_HAVE_SAME_SCALAR_TYPE(indices, offsets);

    const int32_t T = hash_table_offsets.size(0) - 1;
    const int32_t B = (offsets.size(0) - 1) / T;
    TORCH_CHECK(B > 0);

    AT_DISPATCH_INDEX_TYPES(hash_table.scalar_type(), "pruned_hashmap_insert_{{ wdesc }}_cpu_0", [&] {
        using hash_t = index_t;

        AT_DISPATCH_INDEX_TYPES(indices.scalar_type(), "pruned_hashmap_insert_{{ wdesc }}_cpu_1", [&] {
            using uidx_t =
                std::conditional_t<std::is_same_v<index_t, int64_t>, uint64_t, uint32_t>;

            const auto* indices_acc = indices.const_data_ptr<index_t>();
            const auto* dense_indices_acc = dense_indices.const_data_ptr<index_t>();
            const auto* offsets_acc = offsets.const_data_ptr<index_t>();

            auto hash_table_acc = hash_table.accessor<hash_t, 2>();
            const auto hash_table_offsets_acc = hash_table_offsets.accessor<int64_t, 1>();

            for (const auto t : c10::irange(T)) {
                const auto table_start = hash_table_offsets_acc[t];
                const auto table_end = hash_table_offsets_acc[t + 1];
                if (table_start == table_end) {
                    continue;
                }
                const auto capacity = table_end - table_start;

                for (const auto b : c10::irange(B)) {
                    const auto indices_start = offsets_acc[t * B + b];
                    const auto indices_end = offsets_acc[t * B + b + 1];
                    const auto L = indices_end - indices_start;

                    for (const auto l : c10::irange(L)) {
                        const auto idx = indices_acc[indices_start + l];
                        const auto dense_idx = dense_indices_acc[indices_start + l];
                        if (dense_idx == -1) {
                            // -1 means this row has been pruned, do not insert it.
                            continue;
                        }

                        auto slot = pruned_hash_function(static_cast<uidx_t>(idx)) % capacity;
                        while (true) {
                            const auto ht_idx = table_start + static_cast<int64_t>(slot);
                            const auto slot_sparse_idx = hash_table_acc[ht_idx][0];

                            // Empty slot
                            if (slot_sparse_idx == -1) {
                                hash_table_acc[ht_idx][0] = static_cast<hash_t>(idx);
                                hash_table_acc[ht_idx][1] = static_cast<hash_t>(dense_idx);
                                break;
                            }

                            // Already exists (shouldn't happen in practice)
                            if (slot_sparse_idx == idx) {
                                hash_table_acc[ht_idx][1] = static_cast<hash_t>(dense_idx);
                                break;
                            }

                            // Linear probe
                            slot = (slot + 1) % capacity;
                        }
                    }
                }
            }
        });
    });

    return;
}

{% for nobag in [True, False] %}
{% if not nobag or not weighted %}
Tensor int_nbit_split_embedding{{ "_nobag" if nobag else "" }}_codegen_forward_{{ wdesc }}_cpu(
    Tensor dev_weights,
    Tensor uvm_weights,
    Tensor weights_placements,
    Tensor weights_offsets,
    Tensor weights_tys,
    {% if not nobag %}
    Tensor D_offsets,
    int64_t total_D,
    {% else %}
    const int64_t D,
    {% endif %}
    Tensor indices,
    Tensor offsets,
    int64_t pooling_mode,
    int64_t row_alignment,
    {% if weighted %}
    Tensor indice_weights,
    {% endif %}
    int64_t output_dtype,
    int64_t fp8_exponent_bits,
    int64_t fp8_exponent_bias,
    bool scale_bias_last
) {
    TENSOR_ON_CPU(dev_weights);
    TENSOR_ON_CPU(uvm_weights);
    TENSOR_ON_CPU(weights_placements);
    TENSOR_ON_CPU(weights_offsets);
    TENSOR_ON_CPU(weights_tys);
    {% if not nobag %}
    TENSOR_ON_CPU(D_offsets);
    {% endif %}
    TENSOR_ON_CPU(indices);
    TENSOR_ON_CPU(offsets);
    {% if weighted %}
    TENSOR_EMPTY_OR_ON_CPU(indice_weights);
    {% endif %}

    {% if not nobag %}
    const int32_t T = D_offsets.numel() - 1;
    {% else %}
    const int32_t total_L = indices.numel();
    const int32_t T = weights_offsets.numel();
    {% endif %}
    TORCH_CHECK(T > 0);
    // offsets = [B x T  + 1]
    int32_t B = (offsets.size(0) - 1) / T;
    TORCH_CHECK(B >= 0);
    {% if not nobag %}
    TORCH_CHECK(total_D > 0);
    {% else %}
    TORCH_CHECK(D > 0);
    {% endif %}
    const static bool disablePinnedMemory = fbgemm_gpu::config::is_feature_enabled(fbgemm_gpu::config::FeatureGateName::TBE_CPU_OUTPUT_DISABLE_PINNED_MEMORY);
    bool pinned_memory = false;
    if (!disablePinnedMemory && at::Context::hasCUDA() && at::getNumGPUs() > 0) {
      pinned_memory = true;
    }

    Tensor output;
    SparseType o_dtype = static_cast<SparseType>(output_dtype);
    TORCH_CHECK(o_dtype == SparseType::FP32 || o_dtype == SparseType::FP16 || o_dtype == SparseType::INT8 || o_dtype == SparseType::BF16 || o_dtype == SparseType::INT4);
    bool output_is_int8 = o_dtype == SparseType::INT8;
    bool output_is_int4 = o_dtype == SparseType::INT4;
    {% if nobag %}
    constexpr int kINT8QparamsBytes = 4; // no bag int8 output aligns with fbgemm weights storage size and layout
    constexpr int kINT4QparamsElems = 8; // scale + bias takes 4 bytes which are 8 int4 elements
    int64_t adjusted_D = D;
    if (o_dtype == SparseType::INT8) {
      adjusted_D += kINT8QparamsBytes;
    } else if (o_dtype == SparseType::INT4) {
      adjusted_D += kINT4QparamsElems;
      TORCH_CHECK(
          adjusted_D % 2 == 0,
          "INT4 no-bag output requires an even embedding dimension, got D=",
          D);
    }
    output = at::empty({total_L, adjusted_D}, dev_weights.options().dtype(getScalarType(o_dtype)).pinned_memory(pinned_memory));
    if (!output_is_int8 && !output_is_int4) {
      output.fill_(0);
    }

    {% else %}
    constexpr int kINT8QparamsBytes = 8;
    int64_t total_adjusted_D = total_D;
    if (o_dtype == SparseType::INT8) {
      total_adjusted_D += T * kINT8QparamsBytes;
    }
    output = at::empty({B, total_adjusted_D}, dev_weights.options().dtype(getScalarType(o_dtype)).pinned_memory(pinned_memory));
    // No pre-zero: when D_offsets partitions [0, total_D) the kernel overwrites
    // every element (empty bags via fillZero); the !success path zeroes before
    // throwing. The op does not enforce that, so fill when it does not hold.
    // int8/int4 were never pre-zeroed.
    const auto* D_offsets_ptr = D_offsets.const_data_ptr<int32_t>();
    if (!output_is_int8 && !output_is_int4 &&
        (D_offsets_ptr[0] != 0 || D_offsets_ptr[T] != total_D)) {
      output.fill_(0);
    }
    // Flattened (table x bag) threading. Stats keep the whole-table path, as
    // on NOBAG (chunking would split a table-level sample). See
    // calculate_bag_threads for the serial cases.
    // Log a mistyped enable once; the gate stays off.
    static const bool bag_parallelism_env_checked = [] {
      if (const char* v =
              fbgemm_gpu::take_unrecognized_bag_parallelism_value()) {
        LOG(WARNING) << "FBGEMM_TBE_BAG_PARALLELISM=" << v
                     << " is not a recognised boolean (1/0, true/false, "
                        "on/off, yes/no); bag parallelism stays off.";
      }
      return true;
    }();
    (void)bag_parallelism_env_checked;
    const bool bag_parallelism_on =
        fbgemm_gpu::tbe_bag_parallelism_enabled() && !fbgemm::is_stats_enabled();
    const int bag_threads =
        bag_parallelism_on ? fbgemm_gpu::choose_bag_threads(T, B) : 1;
    {% endif %}


    if (B == 0) {
        return output;
    }

    const int32_t* weights_placements_ptr = weights_placements.const_data_ptr<int32_t>();
    const auto* weights_tys_acc = weights_tys.const_data_ptr<uint8_t>();

    fbgemm_gpu::dispatch_output_types(output.scalar_type(), "intn_split_embedding{{ "_nobag" if nobag else "" }}_codegen_forward_kernel", [&]<typename output_t>() {
        {% if weighted %}
        const float* indice_weights_acc = indice_weights.const_data_ptr<float>();
        {% endif %}

        using float16 = fbgemm::float16;
        using bfloat16 = fbgemm::bfloat16;
        using int8 = uint8_t;
        using base_fbgemm_out_t = std::conditional_t<
            std::is_same_v<output_t, at::Half>,
            float16,
            std::conditional_t<std::is_same_v<output_t, at::BFloat16>, bfloat16, std::conditional_t<std::is_same_v<output_t, float>, float, int8>>>;
        using other_fbgemm_out_t = std::conditional_t<
            std::is_same_v<output_t, at::Half>,
            float16,
            std::conditional_t<std::is_same_v<output_t, at::BFloat16>, bfloat16, float>>;
        AT_DISPATCH_INDEX_TYPES(indices.scalar_type(), "int_nbit_split_embedding{{ "_nobag" if nobag else "" }}_codegen_forward_", [&] {
            const auto* indices_acc = indices.const_data_ptr<index_t>();
            const auto* offsets_acc = offsets.const_data_ptr<index_t>();
            const auto* weights_offsets_acc = weights_offsets.const_data_ptr<int64_t>();

            auto* output_acc = output.mutable_data_ptr<output_t>();

            // Reconstruct sorted unique physical offsets so we can
            // correctly compute num_rows for each table.
            // weights_offsets may be non-monotonic when feature_table_map
            // reorders features vs physical tables.
            std::vector<int64_t> physical_offsets;
            for (int32_t i = 0; i < T; ++i) {
                physical_offsets.push_back(weights_offsets_acc[i]);
            }
            std::ranges::sort(physical_offsets);
            physical_offsets.erase(
                std::ranges::unique(physical_offsets).begin(),
                physical_offsets.end());

            // Output rows produced by table t: one row per index in NOBAG, one
            // row per bag in the pooled path.
            const auto rows_of = [&](int t) -> int64_t {
                {% if nobag %}
                return static_cast<int64_t>(offsets_acc[(t + 1) * B]) -
                    static_cast<int64_t>(offsets_acc[t * B]);
                {% else %}
                (void)t;
                return B;
                {% endif %}
            };

            // Processes rows [r0, r1) of table t -- indices in NOBAG, bags in
            // the pooled path. The whole-table call is the special case r0=0,
            // r1=rows_of(t), which is all the pooled path ever passes unless
            // the call takes the flattened path.
            const auto run_chunk = [&](int t, int64_t r0, int64_t r1) {
                {% if nobag %}
                // int64: a large batch can push the output byte offset past 2^31.
                const int64_t elems_D = (o_dtype == SparseType::INT4) ? adjusted_D / 2 : adjusted_D;
                {% else %}
                const auto* D_offsets_acc = D_offsets.const_data_ptr<int32_t>();
                const int32_t D_start = D_offsets_acc[t];
                const int32_t D_end = D_offsets_acc[t + 1];
                const int32_t D = D_end - D_start;
                {% endif %}

                const auto placement = static_cast<PlacementType>(weights_placements_ptr[t]);
                TORCH_CHECK(placement != PlacementType::DEVICE);
                const auto& weight_tensor = (placement == PlacementType::HOST) ? dev_weights : uvm_weights;
                const uint8_t* weights = weight_tensor.const_data_ptr<uint8_t>() + weights_offsets_acc[t];
                const auto weight_ty = static_cast<SparseType>(weights_tys_acc[t]);
                if (output_is_int8) {
                    TORCH_CHECK(weight_ty == SparseType::INT8, "int8 output are only supported for int8 weights");
                }
                const int32_t scale_bias_size = (weight_ty == SparseType::INT8 && scale_bias_last) ? 8 : 4;
                // default to 1 byte alignment for CPU TBE
                const int32_t D_bytes = nbit::padded_row_size_in_bytes(D, weight_ty, row_alignment, scale_bias_size);

                // Use reconstructed physical offsets to find the next
                // physical boundary for this table's weights, then compute
                // num_rows. The original heuristic of scanning forward in
                // weights_offsets breaks when feature_table_map makes them
                // non-monotonic.
                const auto it = std::upper_bound(
                    physical_offsets.begin(),
                    physical_offsets.end(),
                    weights_offsets_acc[t]);
                const int64_t next_offset =
                    (it != physical_offsets.end())
                    ? *it : weight_tensor.numel();
                const size_t num_rows =
                    (next_offset - weights_offsets_acc[t]) / D_bytes;
                {% if nobag %}
                const index_t* offsets_begin_ptr = offsets_acc + t * B;
                {% else %}
                // Rebased to bag r0, so a chunk sees exactly what a whole-table
                // call would, shifted: offsets, indices, per-sample weights and
                // the output row all key off this pointer. r0 is 0 unless bag
                // parallelism is on, which makes this the existing expression.
                const index_t* offsets_begin_ptr = offsets_acc + t * B + r0;
                {% endif %}

                bool success = true;
                constexpr bool has_weight = {{ "true" if weighted else "false" }};
                const bool normalize_by_lengths = static_cast<PoolingMode>(pooling_mode) == PoolingMode::MEAN;

                {% if nobag %}
                // Chunked: the kernel is invoked on rows [r0, r1) of this table
                // exactly as it would be on the whole table, just rebased. The
                // whole-table call is the special case r0=0, r1=rows_of(t).
                const index_t chunk_first_row =
                    *offsets_begin_ptr + static_cast<index_t>(r0);
                const index_t index_size = static_cast<index_t>(r1 - r0);
                const int64_t D_start = static_cast<int64_t>(chunk_first_row) * elems_D;
                {% else %}
                const int64_t n_bags = r1 - r0;
                const index_t index_size = offsets_begin_ptr[n_bags] - offsets_begin_ptr[0];
                {% endif %}
                const int32_t output_stride = {{ "total_D" if not nobag else "elems_D" }};

                {% if nobag %}
                output_t* const chunk_out = output_acc + D_start;
                {% else %}
                // Row r0, column D_start. int64 product: r0 * total_D can pass
                // 2^31. output_stride is int32, so total_D is capped there.
                output_t* const chunk_out =
                    output_acc + D_start + r0 * static_cast<int64_t>(output_stride);
                {% endif %}

                {% if nobag %}
                TORCH_CHECK(index_size >= 0, "offsets must be non-decreasing, got index_size ", index_size, " for table ", t);
                // Virtual offsets for the nobag case. Lengths are all ones. Materialized
                // lazily: a kernel generated with no_bag gathers rows straight from
                // `indices` and never dereferences offsets, so building them for those
                // kernels is an allocation plus an index_size-sized fill of pure overhead.
                Tensor offsets_nobag;
                const auto make_virtual_offsets = [&]() {
                  offsets_nobag = at::arange(chunk_first_row, chunk_first_row + index_size + 1, offsets.options());
                  const index_t* offsets_nobag_ptr = offsets_nobag.const_data_ptr<index_t>();
                  TORCH_CHECK(offsets_nobag.numel() == index_size + 1);
                  TORCH_CHECK(offsets_nobag_ptr[index_size] - offsets_nobag_ptr[0] == index_size);
                  return offsets_nobag_ptr;
                };
                {% endif %}

                const float* indice_weights_ptr = nullptr;
                // int8/int4 output only enabled for nobag case
                const bool nobag_op = {{ "false" if not nobag else "output_is_int8 || output_is_int4" }};
                {% if weighted %}
                indice_weights_ptr = indice_weights_acc + *offsets_begin_ptr;
                {% endif %}

                {% macro generate_and_exec_kernel(weight_type, use_base, use_nbit, use_fp8) %}
                {% set has_asmjit = use_base or use_nbit %}
                {% set kernel_name = "GenerateEmbeddingSpMDMWithStrides"
                    if use_base else ("GenerateEmbeddingSpMDMNBitWithStrides"
                    if use_nbit else "detail::GenerateEmbeddingSpMDMFP8WithStridesBytes")
                 %}
                using fbgemm_out_t = {{ "base_fbgemm_out_t" if use_base or use_nbit else "other_fbgemm_out_t" }};
                {% if use_nbit %}
                const int output_bit_rate = output_is_int4 ? 4 : sizeof(fbgemm_out_t) * 8;
                {% endif %}
                // TODO: merge nobag int8 path with normal asmjit dispatch
                {% if nobag %}
                    {% if use_fp8 %}
                    // {{ kernel_name }} takes no no_bag argument, so it always runs the
                    // bagged path and always dereferences offsets.
                    const index_t* offset_ptr = make_virtual_offsets();
                    {% else %}
                    // {{ kernel_name }} is generated with /*no_bag=*/nobag_op below. Under
                    // no_bag it ignores offsets, so hand it the real (unused) ones rather
                    // than paying to build the virtual ones.
                    const index_t* offset_ptr = nobag_op ? offsets_begin_ptr : make_virtual_offsets();
                    {% endif %}
                {% else %}
                    const index_t* offset_ptr = offsets_begin_ptr;
                {% endif %}
                const auto kernel = fbgemm::{{ kernel_name }}<
                    {% if use_base %}
                    {{ weight_type }},
                    {% endif %}
                    index_t,
                    index_t,
                    {% if has_asmjit %}
                    fbgemm_out_t,
                    /*THREAD_LOCAL=*/true
                    {% else %}
                    fbgemm_out_t
                    {% endif %}
                >(
                    {% if use_nbit %}
                    /*input_bit_rate=*/bit_rate,
                    {% endif %}
                    D,
                    {% if has_asmjit %}
                    has_weight,
                    {% endif %}
                    normalize_by_lengths,
                    {% if has_asmjit %}
                    /*prefetch=*/16,
                    {% endif %}
                    /*is_weight_positional=*/false,
                    /*use_offsets=*/true,
                    /*output_stride=*/output_stride,
                    /*input_stride=*/D_bytes / sizeof({{ weight_type }})
                    {% if use_fp8 %}
                    ,/*exponent_bits=*/fp8_exponent_bits,
                    /*exponent_bias=*/fp8_exponent_bias
                    {% endif %}
                    {% if has_asmjit %}
                    ,/*scale_bias_last=*/scale_bias_last
                    {% endif %}
                    {% if use_base %}
                    ,/*no_bag=*/nobag_op
                    {% elif use_nbit %}
                    ,/*no_bag=*/nobag_op,
                    /*output_bit_rate=*/output_bit_rate
                    {% endif %}
                );
                success = kernel(
                    {{ "static_cast<int>(n_bags)" if not nobag else "index_size"}},
                    index_size,
                    num_rows,
                    reinterpret_cast<const {{ weight_type }}*>(weights),
                    {{ "indices_acc + chunk_first_row" if nobag else "indices_acc + *offsets_begin_ptr" }},
                    offset_ptr,
                    indice_weights_ptr,
                    reinterpret_cast<fbgemm_out_t*>(chunk_out));
                {% endmacro %}

                if (weight_ty == SparseType::FP32) {
                    {{ generate_and_exec_kernel("float", True, False, False) }}
                } else if (weight_ty == SparseType::FP16) {
                    {{ generate_and_exec_kernel("float16", True, False, False) }}
                } else if (weight_ty == SparseType::INT8) {
                    {{ generate_and_exec_kernel("uint8_t", True, False, False) }}
                } else if (weight_ty == SparseType::FP8) {
                    check_fp8_params(fp8_exponent_bits, fp8_exponent_bias);
                    {{ generate_and_exec_kernel("uint8_t", False, False, True) }}
                } else if (weight_ty == SparseType::INT4 || weight_ty == SparseType::INT2) {
                    int bit_rate;
                    switch (weight_ty) {
                        case SparseType::INT4 :
                          bit_rate = 4;
                          break;
                        case SparseType::INT2 :
                          bit_rate = 2;
                          break;
                        default:
                          throw std::logic_error(
                              "Unsupported SparseType: " + std::to_string(static_cast<int>(weight_ty)));
                    }
                    {{ generate_and_exec_kernel("uint8_t", False, True, False) }}
                } else {
                    throw std::logic_error(
                        "Unsupported SparseType: " + std::to_string(static_cast<int>(weight_ty)));
                }
                if (!success) {
                    {% if not nobag %}
                    // Zero only this chunk's slice (rows [r0, r1) of this table):
                    // anything wider races with other chunks in this parallel
                    // region. This also covers corrupt offsets, which
                    // report_embedding_error may not throw on. Skipped for int8/int4,
                    // whose inline qparam bytes a raw zero-fill can't represent.
                    if (!output_is_int8 && !output_is_int4) {
                      for (const auto b : c10::irange(n_bags)) {
                        std::memset(
                            chunk_out + b * output_stride,
                            0,
                            static_cast<size_t>(D) * sizeof(output_t));
                      }
                    }
                    {% endif %}
                    // Scan only the bags this chunk owns. Reporting [0, B) from
                    // a chunked call would walk bags another thread is handling
                    // and point at the wrong index. Equals [0, B) except on the
                    // flattened path.
                    fbgemm_gpu::report_embedding_error(
                        t,
                        B,
                        {{ "static_cast<int>(r0)" if not nobag else "0" }},
                        {{ "static_cast<int>(r1)" if not nobag else "B" }},
                        offsets_acc,
                        indices_acc,
                        num_rows,
                        /*allow_minus_one=*/true);
                }
            };

            {% if nobag %}
            // NOBAG: parallelise over row ranges rather than tables, so a
            // single dominant table cannot cap the speedup at
            // sum(rows) / max(rows in one table). int8 output consumes the
            // per-bag offsets pointer rather than the synthesised unit-stride
            // one, so it stays on the whole-table path.
            //
            // With FBGEMM_STATS_ENABLE=1 each kernel invocation records one
            // EmbeddingStatsTracker sample as recordPattern(..., output_size,
            // 1). Splitting a logical table into row chunks would turn that one
            // table-level sample into one sample per chunk and report chunk
            // sizes instead of the table's row count, inflating frequencies and
            // making telemetry depend on the thread/grain settings. Keep
            // whole-table execution while stats are enabled to preserve the
            // per-table semantics.
            const static bool nobag_row_parallelism_enabled =
                fbgemm_gpu::config::is_feature_enabled(
                    fbgemm_gpu::config::FeatureGateName::
                        TBE_NOBAG_ROW_PARALLELISM);
            if (output_is_int8 || fbgemm::is_stats_enabled() ||
                !nobag_row_parallelism_enabled) {
              parallel_for_table_threads(0, T, [&](int begin, int end) {
                for (int t = begin; t < end; ++t) {
                  run_chunk(t, 0, rows_of(t));
                }
              });
            } else {
              int64_t total_rows = 0;
              for (int t = 0; t < T; ++t) {
                total_rows += rows_of(t);
              }
              const int num_threads =
                  fbgemm_gpu::choose_num_threads_for_rows(total_rows);
              if (num_threads <= 1) {
                for (int t = 0; t < T; ++t) {
                  run_chunk(t, 0, rows_of(t));
                }
              } else {
                const auto chunks = fbgemm_gpu::build_row_chunks(
                    T, total_rows, num_threads, rows_of);
                parallel_for_row_chunks(chunks, num_threads, run_chunk);
              }
            }
            {% else %}
            // Paths decided at allocation (see bag_threads). Gate off keeps TLS
            // propagation. The flattened path skips it: pooled run_chunk makes
            // no dispatched ATen calls (raw pointers, fbgemm kernels,
            // TORCH_CHECK). Restore it if one is added.
            if (!bag_parallelism_on) {
              parallel_for_table_threads(0, T, [&](int begin, int end) {
                for (int t = begin; t < end; ++t) {
                  run_chunk(t, 0, rows_of(t));
                }
              });
            } else if (bag_threads <= 1) {
              for (int t = 0; t < T; ++t) {
                run_chunk(t, 0, rows_of(t));
              }
            } else {
              // Profiler marker; tests assert this path ran.
              RECORD_USER_SCOPE("fbgemm::tbe_cpu_flattened_bags");
              // rows_of(t) == B here, so the work space is T*B bags.
              const auto chunks = fbgemm_gpu::build_row_chunks(
                  T, static_cast<int64_t>(T) * B, bag_threads, rows_of,
                  fbgemm_gpu::MIN_CHUNK_BAGS);
              parallel_for_row_chunks</*kPropagateTls=*/false>(
                  chunks, bag_threads, run_chunk);
            }
            {% endif %}
            return;
        });
    });
    return output;
}
{% endif %} // if not nobag or not weighted
{% endfor %} // for nobag in [True, False]

Tensor pruned_hashmap_lookup_{{ wdesc }}_cpu(
    Tensor indices,
    Tensor offsets,
    Tensor hash_table,
    Tensor hash_table_offsets) {
    TENSOR_ON_CPU(indices);
    TENSOR_ON_CPU(offsets);
    TENSOR_ON_CPU(hash_table);
    TENSOR_ON_CPU(hash_table_offsets);
    TENSORS_HAVE_SAME_SCALAR_TYPE(indices, offsets);

    int32_t T = hash_table_offsets.size(0) - 1;
    int32_t B = (offsets.size(0) - 1) / T;
    TORCH_CHECK(B > 0);

    auto dense_indices = empty_like(indices);

    AT_DISPATCH_INDEX_TYPES(hash_table.scalar_type(), "pruned_hashmap_lookup_{{ wdesc }}_cpu_0", [&] {
        using hash_t = index_t;

        AT_DISPATCH_INDEX_TYPES(indices.scalar_type(), "pruned_hashmap_lookup_{{ wdesc }}_cpu_1", [&] {
            using utdx_t =
                std::conditional_t<std::is_same_v<index_t, int64_t>, uint64_t, uint32_t>;

            const auto* indices_acc = indices.const_data_ptr<index_t>();
            auto* dense_indices_acc = dense_indices.mutable_data_ptr<index_t>();
            const auto* offsets_acc = offsets.const_data_ptr<index_t>();

            const auto hash_table_acc = hash_table.accessor<hash_t, 2>();
            const auto hash_table_offsets_acc = hash_table_offsets.accessor<int64_t, 1>();

            for (const auto t : c10::irange(T)) {
                const auto table_start = hash_table_offsets_acc[t];
                const auto table_end = hash_table_offsets_acc[t + 1];
                const auto capacity = table_end - table_start;

                for (const auto b : c10::irange(B)) {
                    const auto indices_start = offsets_acc[t * B + b];
                    const auto indices_end = offsets_acc[t * B + b + 1];
                    const auto L = indices_end - indices_start;

                    if (table_start == table_end) {
                        for (const auto l : c10::irange(L)) {
                            dense_indices_acc[indices_start + l] = indices_acc[indices_start + l];
                        }

                    } else {
                        for (const auto l : c10::irange(L)) {
                            const auto idx = indices_acc[indices_start + l];
                            auto slot = pruned_hash_function(static_cast<utdx_t>(idx)) % capacity;

                            while (true) {
                                const auto ht_idx = table_start + static_cast<int64_t>(slot);
                                const auto slot_sparse_idx = hash_table_acc[ht_idx][0];

                                // Empty slot
                                if (slot_sparse_idx == -1) {
                                    dense_indices_acc[indices_start + l] = -1;
                                    break;
                                }
                                // Already exists
                                if (slot_sparse_idx == idx) {
                                    dense_indices_acc[indices_start + l] = static_cast<index_t>(hash_table_acc[ht_idx][1]);
                                    break;
                                }

                                // Linear probe
                                slot = (slot + 1) % capacity;
                            }
                        }
                    }
                }
            }
        });
    });

    return dense_indices;
}

{% if not weighted %}

Tensor pruned_array_lookup_cpu(
    Tensor indices,
    Tensor offsets,
    Tensor index_remappings,
    Tensor index_remappings_offsets) {
    TENSOR_ON_CPU(indices);
    TENSOR_ON_CPU(offsets);
    TENSOR_ON_CPU(index_remappings);
    TENSOR_ON_CPU(index_remappings_offsets);
    TENSORS_HAVE_SAME_SCALAR_TYPE(indices, offsets);

    int32_t T = index_remappings_offsets.size(0) - 1;
    int32_t B = (offsets.size(0) - 1) / T;
    TORCH_CHECK(B > 0);

    auto dense_indices = empty_like(indices);

    AT_DISPATCH_INDEX_TYPES(index_remappings.scalar_type(), "pruned_array_lookup_cpu_0", [&] {
        using remap_t = index_t;

        AT_DISPATCH_INDEX_TYPES(indices.scalar_type(), "pruned_array_lookup_cpu_1", [&] {
            const auto* indices_acc = indices.const_data_ptr<index_t>();
            auto* dense_indices_acc = dense_indices.mutable_data_ptr<index_t>();
            const auto* offsets_acc = offsets.const_data_ptr<index_t>();

            const auto index_remappings_acc = index_remappings.const_data_ptr<remap_t>();
            const auto index_remappings_offsets_acc = index_remappings_offsets.const_data_ptr<int64_t>();

            at::parallel_for(0, T, 1, [&](int64_t begin, int64_t end) {
            for (const auto t : c10::irange(begin, end)) {
                const auto index_remappings_start = index_remappings_offsets_acc[t];
                const auto index_remappings_end = index_remappings_offsets_acc[t + 1];
                const auto capacity = index_remappings_end - index_remappings_start;

                const auto indices_start = offsets_acc[t * B];
                const auto indices_end = offsets_acc[(t + 1) * B];

                if (capacity > 0) {
                    for (const auto i : c10::irange(indices_start, indices_end)) {
                        auto idx = indices_acc[i];
                        dense_indices_acc[i] = static_cast<index_t>(index_remappings_acc[index_remappings_start + idx]);
                    }
                } else {
                    std::memcpy(
                        dense_indices_acc + indices_start,
                        indices_acc + indices_start,
                        (indices_end - indices_start) * sizeof(index_t));
                }
            }
            });
        });
    });

    return dense_indices;
}

{% endif %}
// clang-format on
