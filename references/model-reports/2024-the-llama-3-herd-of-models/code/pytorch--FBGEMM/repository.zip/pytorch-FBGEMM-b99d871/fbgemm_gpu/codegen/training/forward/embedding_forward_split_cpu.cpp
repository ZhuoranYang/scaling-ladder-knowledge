/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree.
 */

#include "fbgemm_gpu/embedding_forward_split_cpu.h"
#include "fbgemm/FbgemmEmbedding.h"
#include "fbgemm/Types.h"
#include "fbgemm/Utils.h"
#include "fbgemm_gpu/embedding_common.h"
#include "fbgemm_gpu/utils/cpu_utils.h"
#include "fbgemm_gpu/utils/dispatch_macros.h"
#include "fbgemm_gpu/utils/ops_utils.h"
#include "fbgemm_gpu/utils/tensor_accessor_builder.h"

#include <ATen/ATen.h>
#include <ATen/AccumulateType.h>
#include <ATen/Parallel.h>
#include <ATen/core/op_registration/op_registration.h>
#include <torch/script.h>

#if FBGEMM_GPU_MEMCHECK
#define FBGEMM_MEM_CHECK_ONLY
#else
#define FBGEMM_MEM_CHECK_ONLY maybe_unused
#endif

using Tensor = at::Tensor;
using namespace fbgemm_gpu;

template <
    typename weights_t,
    typename ind_weights_t,
    typename index_t,
    typename offset_t,
    typename output_t>
static void split_embedding_forward_cpu_kernel(
    Tensor weights,
    Tensor weights_offsets,
    Tensor D_offsets,
    Tensor hash_size_cumsum,
    Tensor indices,
    Tensor offsets,
    int64_t pooling_mode,
    Tensor indice_weights,
    Tensor output) {
  int64_t T = D_offsets.numel() - 1;
  TORCH_CHECK_GT(T, 0);
  // offsets = [T x B  + 1]
  int64_t B = (offsets.size(0) - 1) / T;
  TORCH_CHECK_GE(B, 0);

  TORCH_CHECK(weights.is_contiguous());
  indices = indices.contiguous();
  offsets = offsets.contiguous();
  if (indice_weights.defined()) {
    indice_weights = indice_weights.contiguous();
  }

  const auto D_offsets_data = D_offsets.accessor<int, 1>();
  const auto weights_offsets_data = weights_offsets.accessor<int64_t, 1>();
  const auto indices_data = indices.const_data_ptr<index_t>();
  const auto offsets_data = offsets.const_data_ptr<offset_t>();
  const auto hash_size_cumsum_data = hash_size_cumsum.accessor<int64_t, 1>();

  const auto weights_data = weights.const_data_ptr<weights_t>();
  // If indice_weights not defined, then this accessor won't be used.
  // The else condition is just to make compiler happy
  const auto indice_weights_data = indice_weights.defined()
      ? indice_weights.const_data_ptr<ind_weights_t>()
      : nullptr;

  auto output_data = output.mutable_data_ptr<output_t>();
  auto output_stride = output.size(1);

  constexpr bool use_fbgemm = (std::is_same_v<weights_t, float> ||
                               std::is_same_v<weights_t, at::Half> ||
                               std::is_same_v<weights_t, uint8_t>) &&
      std::is_same_v<output_t, float> && std::is_same_v<ind_weights_t, float>;

  at::parallel_for(0, B, 0, [&](int64_t b_begin, int64_t b_end) {
    for (const auto t : c10::irange(T)) {
      const auto D_begin = D_offsets_data[t];
      const auto D = D_offsets_data[t + 1] - D_offsets_data[t];
      const auto table_begin = weights_offsets_data[t];

      int64_t hash_size;
      int t_temp = t + 1;
      do {
        hash_size = hash_size_cumsum_data[t_temp] - hash_size_cumsum_data[t];
        ++t_temp;
      } while (hash_size == 0);

      bool success = true;
      if (use_fbgemm) {
        using fbgemm_weight_t = std::conditional_t<
            std::is_same_v<weights_t, at::Half>,
            fbgemm::float16,
            weights_t>;
        auto kernel = fbgemm::GenerateEmbeddingSpMDMWithStrides<
            fbgemm_weight_t,
            /*IndexType=*/index_t,
            /*OffsetType=*/offset_t>(
            D,
            indice_weights.defined(),
            static_cast<PoolingMode>(pooling_mode) == PoolingMode::MEAN,
            /*prefetch=*/16,
            /*is_weight_positional=*/false,
            /*use_offsets=*/true,
            output_stride);
        auto offsets_begin_ptr = offsets_data + t * B + b_begin;
        auto indices_size = offsets_data[t * B + b_end] - *offsets_begin_ptr;
        success = kernel(
            b_end - b_begin,
            indices_size,
            hash_size,
            reinterpret_cast<const fbgemm_weight_t*>(
                weights_data + table_begin),
            indices_data + *offsets_begin_ptr,
            offsets_begin_ptr,
            indice_weights.defined()
                ? reinterpret_cast<const float*>(
                      indice_weights_data + *offsets_begin_ptr)
                : nullptr,
            reinterpret_cast<float*>(
                output_data + b_begin * output_stride + D_begin));
      } else {
        at::acc_type<output_t, true> output_buf[D];
        for (const auto b : c10::irange(b_begin, b_end)) {
          const auto pool_begin = offsets_data[t * B + b];
          const auto pool_end = offsets_data[t * B + b + 1];
          const auto L = pool_end - pool_begin;
          memset(output_buf, 0, D * sizeof(at::acc_type<output_t, true>));
          for (const auto p : c10::irange(pool_begin, pool_end)) {
            int64_t idx = indices_data[p];
            if (idx < 0 || idx >= hash_size) {
              success = false;
              break;
            }
            const int64_t embedding_begin = table_begin + idx * D;
            for (const auto d : c10::irange(D)) {
              output_buf[d] +=
                  (indice_weights.defined()
                       ? static_cast<at::acc_type<output_t, true>>(
                             weights_data[embedding_begin + d]) *
                           static_cast<at::acc_type<output_t, true>>(
                               indice_weights_data[p])
                       : static_cast<at::acc_type<output_t, true>>(
                             weights_data[embedding_begin + d]));
            }
          }
          const double scale_factor =
              // NOTE: MEAN pooling will not work with indice_weights!
              (static_cast<PoolingMode>(pooling_mode) == PoolingMode::MEAN &&
               !indice_weights.defined() && L > 0)
              ? 1.0 / L
              : 1.0;
          for (const auto d : c10::irange(D)) {
            output_data[b * output_stride + D_begin + d] =
                scale_factor * output_buf[d];
          }
          if (!success) {
            break;
          }
        } // for each b
      } // !use_fbgemm

      if (!success) {
        fbgemm_gpu::report_embedding_error(
            t, B, b_begin, b_end, offsets_data, indices_data, hash_size);
      } // !success
    } // for each t
  }); // parallel for
}

Tensor split_embedding_codegen_forward_cpu(
    Tensor weights,
    Tensor weights_offsets,
    Tensor D_offsets,
    c10::SymInt total_D_,
    Tensor hash_size_cumsum,
    Tensor indices,
    Tensor offsets,
    int64_t pooling_mode,
    Tensor indice_weights,
    int64_t output_dtype) {
  const int64_t total_D = total_D_.guard_int(__FILE__, __LINE__);
  int64_t T = D_offsets.numel() - 1;
  TORCH_CHECK_GT(T, 0);
  // offsets = [T x B  + 1]
  int64_t B = (offsets.size(0) - 1) / T;
  TORCH_CHECK_GE(B, 0);

  Tensor output;
  if (output_dtype == static_cast<int64_t>(SparseType::FP32)) {
    output = at::empty({B, total_D}, weights.options().dtype(at::kFloat));
  } else if (output_dtype == static_cast<int64_t>(SparseType::FP16)) {
    output = at::empty({B, total_D}, weights.options().dtype(at::kHalf));
  } else if (output_dtype == static_cast<int64_t>(SparseType::BF16)) {
    output = at::empty({B, total_D}, weights.options().dtype(at::kBFloat16));
  } else {
    output = at::empty({B, total_D}, weights.options());
  }

  // It is assumed that the indice_weights will always be float
  TORCH_CHECK(
      !indice_weights.defined() || indice_weights.scalar_type() != at::kHalf);

  FBGEMM_DISPATCH_FLOAT_AND_HALF(
      output.scalar_type(), "split_embedding_cpu_forward_1", [&]() {
        using output_t = scalar_t;

        FBGEMM_DISPATCH_FLOAT_HALF_AND_BYTE(
            weights.scalar_type(), "split_embedding_cpu_forward_2", [&] {
              using ind_weights_t = std::conditional_t<
                  std::is_same_v<scalar_t, double>,
                  double,
                  float>;

              AT_DISPATCH_INDEX_TYPES(
                  offsets.scalar_type(), "split_embedding_cpu_forward_3", [&] {
                    using offset_t = index_t;

                    AT_DISPATCH_INDEX_TYPES(
                        indices.scalar_type(),
                        "split_embedding_cpu_forward_4",
                        [&] {
                          split_embedding_forward_cpu_kernel<
                              scalar_t,
                              ind_weights_t,
                              index_t,
                              offset_t,
                              output_t>(
                              weights,
                              weights_offsets,
                              D_offsets,
                              hash_size_cumsum,
                              indices,
                              offsets,
                              pooling_mode,
                              indice_weights,
                              output);
                        });
                  });
            });
      });
  return output;
}

Tensor split_embedding_codegen_forward_cpu_meta(
    Tensor weights,
    [[maybe_unused]] Tensor weights_offsets,
    Tensor D_offsets,
    c10::SymInt total_D,
    [[maybe_unused]] Tensor hash_size_cumsum,
    [[maybe_unused]] Tensor indices,
    Tensor offsets,
    [[maybe_unused]] int64_t pooling_mode,
    Tensor indice_weights,
    int64_t output_dtype) {
  c10::SymInt T = D_offsets.sym_numel() - 1;
  TORCH_CHECK_GT(T, 0);
  // offsets = [T x B  + 1]
  c10::SymInt B = (offsets.sym_size(0) - 1) / T;
  TORCH_CHECK_GE(B, 0);

  Tensor output;
  if (output_dtype == static_cast<int64_t>(SparseType::FP32)) {
    output =
        at::empty_symint({B, total_D}, weights.options().dtype(at::kFloat));
  } else if (output_dtype == static_cast<int64_t>(SparseType::FP16)) {
    output = at::empty_symint({B, total_D}, weights.options().dtype(at::kHalf));
  } else if (output_dtype == static_cast<int64_t>(SparseType::BF16)) {
    output =
        at::empty_symint({B, total_D}, weights.options().dtype(at::kBFloat16));
  } else {
    output = at::empty_symint({B, total_D}, weights.options());
  }

  // It is assumed that the indice_weights will always be float
  TORCH_CHECK(
      !indice_weights.defined() || indice_weights.scalar_type() != at::kHalf);
  return output;
}

template <typename index_t, typename weights_t, typename grad_t>
static void split_embedding_grad_indice_weights_cpu_kernel(
    Tensor grad_output,
    Tensor weights,
    Tensor weights_offsets,
    Tensor D_offsets,
    Tensor indices,
    Tensor offsets,
    Tensor feature_requires_grad,
    Tensor grad_indice_weights) {
  int64_t T = D_offsets.numel() - 1;
  TORCH_CHECK_GT(T, 0);
  // offsets = [T x B  + 1]
  int64_t B = (offsets.size(0) - 1) / T;
  TORCH_CHECK_GE(B, 0);

  const auto D_offsets_data = D_offsets.accessor<int, 1>();
  const auto weights_offsets_data = weights_offsets.accessor<int64_t, 1>();

  [[FBGEMM_MEM_CHECK_ONLY]] const auto func_name =
      "split_embedding_grad_indice_weights_cpu_kernel";
  const auto indices_data = MAKE_TA_WITH_NAME(func_name, indices, index_t, 1);
  const auto offsets_data = MAKE_TA_WITH_NAME(func_name, offsets, index_t, 1);

  const auto weights_data = weights.accessor<weights_t, 1>();
  const auto grad_output_data = grad_output.accessor<grad_t, 2>();
  auto grad_indice_weights_data =
      grad_indice_weights.accessor<at::acc_type<grad_t, true>, 1>();

  at::parallel_for(0, B, 0, [&](int64_t b_begin, int64_t b_end) {
    for (const auto t : c10::irange(T)) {
      if (feature_requires_grad.defined() &&
          !feature_requires_grad[t].is_nonzero()) {
        // NOTE: skip if the table does not require gradient computation!
        continue;
      }
      const auto D_begin = D_offsets_data[t];
      const auto D = D_offsets_data[t + 1] - D_offsets_data[t];
      const auto table_begin = weights_offsets_data[t];
      for (const auto b : c10::irange(b_begin, b_end)) {
        const auto pool_begin = offsets_data[t * B + b];
        const auto pool_end = offsets_data[t * B + b + 1];
        for (const auto p : c10::irange(pool_begin, pool_end)) {
          const int64_t embedding_begin = table_begin + indices_data[p] * D;
          for (const auto d : c10::irange(D)) {
            grad_indice_weights_data[p] +=
                static_cast<at::acc_type<weights_t, true>>(
                    grad_output_data[b][D_begin + d]) *
                weights_data[embedding_begin + d];
          }
        }
      }
    } // for each t
  }); // parallel for
}

Tensor split_embedding_codegen_grad_indice_weights_cpu(
    Tensor grad_output,
    Tensor weights,
    Tensor weights_offsets,
    Tensor D_offsets,
    Tensor indices,
    Tensor offsets,
    Tensor feature_requires_grad) {
  auto grad_indice_weights = zeros_like(
      indices,
      indices.options().dtype(
          at::toAccumulateType(grad_output.scalar_type(), true)));

  AT_DISPATCH_INDEX_TYPES(
      indices.scalar_type(),
      "split_embedding_grad_indice_weights_cpu_kernel_1",
      [&] {
        FBGEMM_DISPATCH_FLOAT_AND_HALF(
            grad_output.scalar_type(),
            "split_embedding_grad_indice_weights_cpu_kernel_2",
            [&] {
              using grad_t = scalar_t;
              FBGEMM_DISPATCH_FLOAT_AND_HALF(
                  weights.scalar_type(),
                  "split_embedding_grad_indice_weights_cpu_kernel_3",
                  [&] {
                    using weights_t = scalar_t;
                    split_embedding_grad_indice_weights_cpu_kernel<
                        index_t,
                        weights_t,
                        grad_t>(
                        grad_output,
                        weights,
                        weights_offsets,
                        D_offsets,
                        indices,
                        offsets,
                        feature_requires_grad,
                        grad_indice_weights);
                  });
            });
      });

  return grad_indice_weights;
}

namespace {

TORCH_LIBRARY_FRAGMENT(fbgemm, m) {
  m.def(
      "split_embedding_codegen_grad_indice_weights_cpu(Tensor grad_output, Tensor weights, Tensor weights_offsets, Tensor D_offsets, Tensor indices, Tensor offsets, Tensor feature_requires_grad) -> Tensor");
  DISPATCH_TO_CPU(
      "split_embedding_codegen_grad_indice_weights_cpu",
      split_embedding_codegen_grad_indice_weights_cpu);
}

TORCH_LIBRARY_FRAGMENT(fbgemm, m) {
  m.def(
      "split_embedding_codegen_forward_cpu(Tensor weights, Tensor weights_offsets, Tensor D_offsets, SymInt total_D, Tensor hash_size_cumsum, Tensor indices, Tensor offsets, int pooling_mode, Tensor indice_weights, int output_dtype) -> Tensor");
  DISPATCH_TO_CPU(
      "split_embedding_codegen_forward_cpu",
      split_embedding_codegen_forward_cpu);
}

TORCH_LIBRARY_IMPL(fbgemm, Meta, m) {
  m.impl(
      "split_embedding_codegen_forward_cpu",
      &split_embedding_codegen_forward_cpu_meta);
}

} // namespace
