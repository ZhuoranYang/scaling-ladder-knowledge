# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

set(FBGEMM_HAVE_HIP FALSE)

# Locate ROCm from ROCM_PATH, else /opt/rocm if it exists, else hipconfig.
# hipconfig comes last because PyTorch's ROCm wheels can install a hipconfig of
# their own, for a ROCm runtime that is not a full ROCm installation.
if(NOT "$ENV{ROCM_PATH}" STREQUAL "")
  set(ROCM_PATH $ENV{ROCM_PATH})
elseif(EXISTS "/opt/rocm")
  set(ROCM_PATH /opt/rocm)
else()
  find_program(FBGEMM_HIPCONFIG_EXECUTABLE hipconfig)
  if(FBGEMM_HIPCONFIG_EXECUTABLE)
    execute_process(
      COMMAND ${FBGEMM_HIPCONFIG_EXECUTABLE} --rocmpath
      OUTPUT_VARIABLE ROCM_PATH
      OUTPUT_STRIP_TRAILING_WHITESPACE
      RESULT_VARIABLE _hipconfig_result)
    if(NOT _hipconfig_result EQUAL 0)
      unset(ROCM_PATH)
    endif()
  endif()
  if(NOT ROCM_PATH)
    message(FATAL_ERROR
      "Unable to locate ROCm: ROCM_PATH is not set, /opt/rocm does not exist, "
      "and hipconfig is not on PATH")
  endif()
endif()
if(NOT EXISTS "${ROCM_PATH}/lib/cmake/hip")
  message(FATAL_ERROR
    "Located ROCm path does not contain lib/cmake/hip: ${ROCM_PATH}")
endif()
message(STATUS "ROCm path: ${ROCM_PATH}")

macro(torch_hip_get_arch_list store_var)
  if(DEFINED ENV{PYTORCH_ROCM_ARCH})
    set(_TMP $ENV{PYTORCH_ROCM_ARCH})
  else()
    # Use arch of installed GPUs as default
    execute_process(COMMAND "rocm_agent_enumerator" COMMAND bash "-c" "grep -v gfx000 | sort -u | xargs | tr -d '\n'"
                    RESULT_VARIABLE ROCM_AGENT_ENUMERATOR_RESULT
                    OUTPUT_VARIABLE ROCM_ARCH_INSTALLED)
    if(NOT ROCM_AGENT_ENUMERATOR_RESULT EQUAL 0)
      message(FATAL_ERROR " Could not detect ROCm arch for GPUs on machine. Result: '${ROCM_AGENT_ENUMERATOR_RESULT}'")
    endif()
    set(_TMP ${ROCM_ARCH_INSTALLED})
  endif()
  string(REPLACE " " ";" ${store_var} "${_TMP}")
endmacro()

torch_hip_get_arch_list(PYTORCH_ROCM_ARCH)
if(PYTORCH_ROCM_ARCH STREQUAL "")
  message(FATAL_ERROR "No GPU arch specified for ROCm build. Please use PYTORCH_ROCM_ARCH environment variable to specify GPU archs to build for.")
endif()
message("Building FBGEMM for GPU arch: ${PYTORCH_ROCM_ARCH}")

# Derive the wave-size set in scope for this build from PYTORCH_ROCM_ARCH.
# gfx9* archs (CDNA: gfx90a, gfx940/941/942, gfx950) run wave64; gfx10/11/12
# archs (RDNA3/4: gfx1100, gfx1200, ...) run wave32. The codegen uses these
# to emit only the host-side dispatch branches needed by this wheel, so
# single-arch wheels stay free of the wrong wave's bracket table.
set(FBGEMM_HAS_WAVE32 OFF)
set(FBGEMM_HAS_WAVE64 OFF)
foreach(fbgemm_rocm_arch ${PYTORCH_ROCM_ARCH})
  if(fbgemm_rocm_arch MATCHES "^gfx9")
    set(FBGEMM_HAS_WAVE64 ON)
  else()
    set(FBGEMM_HAS_WAVE32 ON)
  endif()
endforeach()
message("FBGEMM wave-size set: WAVE32=${FBGEMM_HAS_WAVE32} WAVE64=${FBGEMM_HAS_WAVE64}")

ADD_DEFINITIONS(-DNDEBUG)
# USE_ROCM flag is used inside FBGEMM_GPU C++ code
ADD_DEFINITIONS(-DUSE_ROCM)

# Add HIP to the CMAKE Module Path
set(CMAKE_MODULE_PATH ${ROCM_PATH}/lib/cmake/hip ${CMAKE_MODULE_PATH})

macro(find_package_and_print_version PACKAGE_NAME)
  find_package("${PACKAGE_NAME}" ${ARGN})
  message("${PACKAGE_NAME} VERSION: ${${PACKAGE_NAME}_VERSION}")
endmacro()

# Find the HIP Package
find_package_and_print_version(HIP 1.0)

if(HIP_FOUND)
  set(FBGEMM_HAVE_HIP TRUE)
  set(PROJECT_RANDOM_BINARY_DIR "${PROJECT_BINARY_DIR}")

  # Enabling HIP language support
  enable_language(HIP)

  if(HIP_COMPILER STREQUAL clang)
    set(hip_library_name amdhip64)
  else()
    set(hip_library_name hip_hcc)
  endif()
  message("HIP library name: ${hip_library_name}")

  # TODO: hip_hcc has an interface include flag "-hc" which is only
  # recognizable by hcc, but not gcc and clang. Right now in our
  # setup, hcc is only used for linking, but it should be used to
  # compile the *_hip.cc files as well.
  find_library(FBGEMM_HIP_HCC_LIBRARIES ${hip_library_name} HINTS ${ROCM_PATH}/lib)
  find_library(FBGEMM_AMDSMI_LIB amd_smi HINTS ${ROCM_PATH}/lib)
  if(FBGEMM_AMDSMI_LIB)
    message(STATUS "Found AMD SMI library: ${FBGEMM_AMDSMI_LIB}")
  endif()

  list(APPEND HIP_CXX_FLAGS -D__HIP_NO_HALF_OPERATORS__=1)
  # list(APPEND HIP_CXX_FLAGS -D__HIP_NO_HALF_CONVERSIONS__=1)
  list(APPEND HIP_CXX_FLAGS -D__HIP_NO_BFLOAT16_CONVERSIONS__=1)
  list(APPEND HIP_CXX_FLAGS -D__HIP_NO_HALF2_OPERATORS__=1)
  list(APPEND HIP_CXX_FLAGS "${CMAKE_CXX_FLAGS}")
  list(APPEND HIP_CXX_FLAGS -mavx2)
  list(APPEND HIP_CXX_FLAGS -mf16c)
  list(APPEND HIP_CXX_FLAGS -mfma)
  list(APPEND HIP_CXX_FLAGS -std=c++20)

  # In Nova CI, we need to explicitly specify the GCC toolchain for HIP/Clang
  # so it uses GCC 13 headers (which have std::atomic_ref for C++20).
  # This flag is Clang-specific and must NOT be added to CMAKE_CXX_FLAGS
  # (which would also be used by GCC).
  if(DEFINED FBGEMM_HIP_GCC_TOOLCHAIN AND EXISTS "${FBGEMM_HIP_GCC_TOOLCHAIN}")
    message(STATUS "Using GCC toolchain for HIP: ${FBGEMM_HIP_GCC_TOOLCHAIN}")
    list(APPEND HIP_CXX_FLAGS "--gcc-toolchain=${FBGEMM_HIP_GCC_TOOLCHAIN}")
  endif()

  set(HIP_HCC_FLAGS ${HIP_CXX_FLAGS})
  # Ask hcc to generate device code during compilation so we can use
  # host linker to link.
  list(APPEND HIP_HCC_FLAGS -fno-gpu-rdc)
  list(APPEND HIP_HCC_FLAGS -Wno-defaulted-function-deleted)
  foreach(fbgemm_rocm_arch ${PYTORCH_ROCM_ARCH})
    list(APPEND HIP_HCC_FLAGS --offload-arch=${fbgemm_rocm_arch})
  endforeach()

  set(FBGEMM_HIP_INCLUDE ${ROCM_PATH}/include ${FBGEMM_HIP_INCLUDE})
  set(FBGEMM_HIP_INCLUDE ${hip_INCLUDE_DIRS} $<BUILD_INTERFACE:${PROJECT_SOURCE_DIR}> $<INSTALL_INTERFACE:include> ${FBGEMM_HIP_INCLUDE})

  hip_include_directories(${FBGEMM_HIP_INCLUDE})

  list (APPEND CMAKE_PREFIX_PATH ${HIP_PATH} ${ROCM_PATH})
endif()
