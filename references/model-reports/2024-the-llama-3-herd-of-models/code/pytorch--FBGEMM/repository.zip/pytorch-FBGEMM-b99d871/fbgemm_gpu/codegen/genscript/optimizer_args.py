#!/usr/bin/env python3
# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

# pyre-ignore-all-errors[29]
# pyre-ignore-all-errors[53]
# flake8: noqa F401


import itertools
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


try:
    from .torch_type_utils import arg_type_to_tensor_type, ArgType, TensorType

except ImportError:
    # pyre-ignore[21]
    from torch_type_utils import arg_type_to_tensor_type, ArgType, TensorType


######################################################################
# Declaration Surfaces
######################################################################


class DeclSurface(str, Enum):
    """The C++ declaration surfaces an optimizer argument is projected onto.

    One optimizer argument spec is rendered into several different C++
    declarations, and an argument that a contract requires is not necessarily
    read by every one of them: a meta function must accept the same arguments
    as the CUDA op it shadows without touching optimizer state, and the PT2
    CUDA wrapper accepts the host-side tensors of the unified argument list
    without forwarding them. Naming the surfaces makes that difference
    expressible in the argument metadata instead of in per-template text.
    """

    CPU_KERNEL = "cpu_kernel"
    GPU_KERNEL = "gpu_kernel"
    HOST_FUNCTION = "host_function"
    META = "meta"
    AUTOGRAD = "autograd"
    PT2_CPU = "pt2_cpu"
    PT2_CUDA = "pt2_cuda"


def decl_surfaces(
    values: Iterable[DeclSurface | str] | None,
) -> frozenset[DeclSurface]:
    """Normalize a declaration-surface policy, rejecting unknown surfaces."""
    if values is None:
        return frozenset()
    known = {surface.value: surface for surface in DeclSurface}
    resolved = set()
    for value in values:
        if isinstance(value, DeclSurface):
            resolved.add(value)
            continue
        if value not in known:
            raise ValueError(
                f"unknown declaration surface {value!r}; "
                f"expected one of {sorted(known)}"
            )
        resolved.add(known[value])
    return frozenset(resolved)


# A meta function shadows a CUDA op so that shape propagation can run without a
# device. It must accept the op's whole argument list, including the optimizer
# state, but it only computes output shapes and never reads an optimizer
# argument. That is a property of the declaration surface rather than of any one
# argument, so it is stated once here instead of on every optimizer spec.
SURFACES_NOT_READING_OPTIMIZER_ARGS: frozenset[DeclSurface] = frozenset(
    {DeclSurface.META}
)


def annotate_unused_declaration(
    declaration: str,
    unused_on: frozenset[DeclSurface],
    surface: DeclSurface,
) -> str:
    """Prefix a C++ optimizer-argument declaration that `surface` does not read.

    Either the argument's own policy names the surface, or the surface reads no
    optimizer argument at all.
    """
    unused = surface in unused_on or surface in SURFACES_NOT_READING_OPTIMIZER_ARGS
    return f"[[maybe_unused]] {declaration}" if unused else declaration


def maybe_unused_args(args_str: str, apply: bool = True) -> str:
    """Prefix every parameter of an already-rendered argument list.

    The V1 optimizer argument lists reach the templates as one pre-joined
    string, so a declaration that reads none of them -- a deprecation stub --
    cannot annotate them individually. `apply` is the generated variant's
    predicate, so a variant that does read the arguments renders unchanged.
    """
    if not apply:
        return args_str
    return ", ".join(f"[[maybe_unused]] {arg.strip()}" for arg in args_str.split(","))


######################################################################
# Optimizer Args Set Item
######################################################################


@dataclass
class OptimizerArgsSetItem:
    # pyre-fixme[11]: Annotation `ArgType` is not defined as a type.
    ty: ArgType  # type
    name: str
    default: float | ArgType = 0  # DEFAULT_ARG_VAL
    ph_tys: list[ArgType] | None = None  # placeholder types
    is_optional: bool = False  # optional variable
    # Declaration surfaces on which this argument is intentionally not read.
    # Empty (the default) means the argument is used everywhere it appears.
    unused_on: frozenset[DeclSurface] = field(default_factory=frozenset)

    def __post_init__(self) -> None:
        self.unused_on = decl_surfaces(self.unused_on)

    def is_unused_on(self, surface: DeclSurface) -> bool:
        return surface in self.unused_on


# Alias b/c the name is too long
OptimItem = OptimizerArgsSetItem


######################################################################
## Data Dict for the code generator script                   ##
######################################################################
# a dict of tensor name and annotation to mark whether the tensor is mutable.
# this is use to annotate the tensor in the defintion schema.
annotation_dict: dict[str, str] = {
    "weights": "(a!)",
    "weights_host": "(a!)",
    "weights_dev": "(b!)",
    "weights_uvm": "(c!)",
    "weights_lxu_cache": "(d!)",
    "aux_tensor": "(e!)",
    "uvm_cache_stats": "(f!)",
    "momentum1": "(g!)",
    "momentum1_host": "(g!)",
    "momentum1_dev": "(h!)",
    "momentum1_uvm": "(i!)",
    "momentum2": "(j!)",
    "momentum2_host": "(j!)",
    "momentum2_dev": "(k!)",
    "momentum2_uvm": "(l!)",
    "prev_iter": "(m!)",
    "prev_iter_host": "(m!)",
    "prev_iter_dev": "(n!)",
    "prev_iter_uvm": "(o!)",
    "row_counter": "(p!)",
    "row_counter_host": "(p!)",
    "row_counter_dev": "(q!)",
    "row_counter_uvm": "(r!)",
    "optim_tensor": "(s!)",
    "vbe_output": "(t!)",
}

######################################################################
## Helper functions for the code generator script                   ##
######################################################################


def _arg_constructor(
    type: str, name: str, gpu: bool = True, precision: int = 32
) -> str:
    return (
        f"{name}.packed_accessor{precision}<{type}, 1, at::RestrictPtrTraits>()"
        if gpu
        else f"{name}.accessor<{type}, 1>()"
    )


def _arg(
    type: str,
    name: str,
    gpu: bool = True,
    precision: int = 32,
    pass_by_ref: bool = False,
) -> str:
    ref = "&" if pass_by_ref else ""
    return (
        f"at::PackedTensorAccessor{precision}<{type}, 1, at::RestrictPtrTraits>{ref} {name}"
        if gpu
        else f"at::TensorAccessor<{type}, 1>{ref} {name}"
    )


def demangle_name(name: str) -> str:
    return name.replace("_dev", "").replace("_uvm", "")


def acc_cache_tensor_arg_constructor(name: str, gpu: bool = True) -> str:
    return _arg_constructor(
        "at::acc_type<" + ("cache_t" if gpu else "scalar_t") + ", true>",
        name,
        gpu=gpu,
        precision=64,
    )


def acc_placeholder_tensor_arg_constructor(name: str, gpu: bool = True) -> str:
    return _arg_constructor(
        demangle_name(name) + "_ph_t",
        name,
        gpu=gpu,
        precision=64,
    )


def acc_cache_tensor_arg(name: str, gpu: bool = True, pass_by_ref: bool = False) -> str:
    return _arg(
        "at::acc_type<" + ("cache_t" if gpu else "scalar_t") + ", true>",
        name,
        gpu=gpu,
        precision=64,
        pass_by_ref=pass_by_ref,
    )


def acc_placeholder_tensor_arg(
    name: str, gpu: bool = True, pass_by_ref: bool = False
) -> str:
    return _arg(
        demangle_name(name) + "_ph_t",
        name,
        gpu=gpu,
        precision=64,
        pass_by_ref=pass_by_ref,
    )


def long_tensor_arg_constructor(name: str, gpu: bool = True) -> str:
    return _arg_constructor("int64_t", name, gpu=gpu)


def long_tensor_arg(name: str, gpu: bool = True, pass_by_ref: bool = False) -> str:
    return _arg("int64_t", name, gpu=gpu, pass_by_ref=pass_by_ref)


def int_tensor_arg_constructor(name: str, gpu: bool = True) -> str:
    return _arg_constructor("int32_t", name, gpu=gpu)


def int_tensor_arg(name: str, gpu: bool = True, pass_by_ref: bool = False) -> str:
    return _arg("int32_t", name, gpu=gpu, pass_by_ref=pass_by_ref)


def tensor_list_arg_no_default(name: str, pass_by_ref: bool) -> str:
    ref = "&" if pass_by_ref else ""
    return f"at::TensorList{ref} {name}"


def tensor_arg(name: str) -> str:
    return f"Tensor {name}"


def tensor_arg_annotate(name: str) -> str:
    annotate = annotation_dict[name] if name in annotation_dict else ""
    return f"Tensor{annotate} {name}"


def double_arg(name: str, default: float = 0.0) -> str:
    return f"double {name} = {default}"


def double_arg_no_default(name: str) -> str:
    return f"double {name}"


def float_arg(name: str, default: float = 0.0) -> str:
    return f"float {name} = {default}"


def float_arg_no_default(name: str) -> str:
    return f"float {name}"


def int64_arg(name: str, default: int = 0) -> str:
    return f"int64_t {name} = {default}"


def int64_arg_no_default(name: str) -> str:
    return f"int64_t {name}"


def int_arg(name: str, default: int = 0) -> str:
    return f"int {name} = {default}"


def sym_int_arg(name: str, default: int = 0) -> str:
    return f"c10::SymInt {name} = {default}"


def sym_int_arg_no_default(name: str) -> str:
    return f"c10::SymInt {name}"


def schema_sym_int_arg(name: str, default: int = 0) -> str:
    return f"SymInt {name} = {default}"


def schema_sym_int_arg_no_default(name: str) -> str:
    return f"SymInt {name}"


def schema_tensor_list_arg_no_default(name: str) -> str:
    annotate = annotation_dict[name] if name in annotation_dict else ""
    return f"Tensor[]{annotate} {name}"


def bool_arg(name: str, default: bool = False) -> str:
    return f"bool {name} = {'true' if default else 'false'}"


def bool_arg_no_default(name: str) -> str:
    return f"bool {name}"


def schema_bool_arg(name: str, default: bool = False) -> str:
    return f"bool {name} = {default}"


def list_arg(ty: str) -> str:
    """
    Returns a C++ argument for a list of optimizer arguments the given type.

    Parameters:
        ty (str) - type of the list e.g., "int", "float", "tensor"
    Returns:
        C++ arguemnt for a list of the given type e.g., for a list of int returns "std::vector<int> optim_int",
    """
    return {
        "tensor": "std::vector<std::optional<at::Tensor>> optim_tensor",
        "int": "std::vector<int64_t> optim_int",
        "float": "std::vector<double> optim_float",
        "bool": "c10::List<bool> optim_bool",
    }[ty]


def schema_list_arg(ty: str) -> str:
    """
    Returns a C++ schema for a list of optimizer arguments the given type.

    Parameters:
        ty (str) - type of the list e.g., "int", "float", "tensor"
    Returns:
        C++ arguemnt for a list of the given type e.g., for a list of int returns "int[] optim_int",
    """
    return {
        "tensor": "Tensor?[] optim_tensor",
        "int": "int[] optim_int",
        "float": "float[] optim_float",
        "bool": "bool[] optim_bool",
    }[ty]


def optional_tensor_arg(name: str) -> str:
    return f"std::optional<Tensor> {name} = std::nullopt"


def optional_tensor_arg_no_default(name: str) -> str:
    return f"std::optional<Tensor> {name}"


def schema_optional_tensor_arg(name: str) -> str:
    return f"Tensor? {name} = None"


def optional_tensorlist_arg(name: str) -> str:
    return f"std::optional<at::TensorList> {name} = std::nullopt"


def optional_tensorlist_arg_no_default(name: str) -> str:
    return f"std::optional<at::TensorList> {name}"


def schema_optional_tensorlist_arg(name: str) -> str:
    return f"Tensor[]? {name} = None"


def make_kernel_arg(
    ty: ArgType,
    name: str,
    default: int | float | None,
    pass_by_ref: bool = False,
    *,
    unused_on: frozenset[DeclSurface] = frozenset(),
    surface: DeclSurface = DeclSurface.GPU_KERNEL,
) -> str:
    return annotate_unused_declaration(
        _kernel_arg(ty, name, default, pass_by_ref), unused_on, surface
    )


def _kernel_arg(
    ty: ArgType,
    name: str,
    default: int | float | None,
    pass_by_ref: bool = False,
) -> str:
    return {
        ArgType.TENSOR: lambda x: acc_cache_tensor_arg(x, pass_by_ref=pass_by_ref),
        ArgType.INT_TENSOR: lambda x: int_tensor_arg(x, pass_by_ref=pass_by_ref),
        ArgType.LONG_TENSOR: lambda x: long_tensor_arg(x, pass_by_ref=pass_by_ref),
        ArgType.PLACEHOLDER_TENSOR: lambda x: acc_placeholder_tensor_arg(
            x, pass_by_ref=pass_by_ref
        ),
        ArgType.INT: (
            (lambda x: int64_arg(x, default=int(default)))
            if default is not None
            else int64_arg_no_default
        ),
        ArgType.SYM_INT: (
            (lambda x: sym_int_arg(x, default=int(default)))
            if default is not None
            else sym_int_arg_no_default
        ),
        ArgType.FLOAT: (
            (lambda x: float_arg(x, default=default))
            if default is not None
            else float_arg_no_default
        ),
        ArgType.BOOL: (
            (lambda x: bool_arg(x, default=bool(default)))
            if default is not None
            else bool_arg_no_default
        ),
    }[ty](name)


def make_kernel_arg_constructor(ty: ArgType, name: str) -> str:
    return {
        ArgType.TENSOR: acc_cache_tensor_arg_constructor,
        ArgType.INT_TENSOR: int_tensor_arg_constructor,
        ArgType.LONG_TENSOR: long_tensor_arg_constructor,
        ArgType.PLACEHOLDER_TENSOR: acc_placeholder_tensor_arg_constructor,
        ArgType.INT: lambda x: x,
        ArgType.FLOAT: lambda x: x,
        ArgType.SYM_INT: lambda x: x,
        ArgType.BOOL: lambda x: x,
    }[ty](name)


def make_cpu_kernel_arg(
    ty: ArgType,
    name: str,
    default: int | float,
    *,
    unused_on: frozenset[DeclSurface] = frozenset(),
    surface: DeclSurface = DeclSurface.CPU_KERNEL,
) -> str:
    return annotate_unused_declaration(
        _cpu_kernel_arg(ty, name, default), unused_on, surface
    )


def _cpu_kernel_arg(ty: ArgType, name: str, default: int | float) -> str:
    return {
        ArgType.TENSOR: lambda x: acc_cache_tensor_arg(x, gpu=False),
        ArgType.INT_TENSOR: lambda x: int_tensor_arg(x, gpu=False),
        ArgType.LONG_TENSOR: lambda x: long_tensor_arg(x, gpu=False),
        ArgType.PLACEHOLDER_TENSOR: acc_cache_tensor_arg_constructor,
        ArgType.INT: lambda x: int64_arg(x, default=int(default)),
        ArgType.FLOAT: lambda x: float_arg(x, default=default),
        ArgType.SYM_INT: lambda x: sym_int_arg(x, default=int(default)),
        ArgType.BOOL: lambda x: bool_arg(x, default=bool(default)),
    }[ty](name)


def make_cpu_kernel_arg_constructor(ty: ArgType, name: str) -> str:
    return {
        ArgType.TENSOR: lambda x: acc_cache_tensor_arg_constructor(x, gpu=False),
        ArgType.INT_TENSOR: lambda x: int_tensor_arg_constructor(x, gpu=False),
        ArgType.LONG_TENSOR: lambda x: long_tensor_arg_constructor(x, gpu=False),
        ArgType.PLACEHOLDER_TENSOR: lambda x: acc_cache_tensor_arg_constructor(
            x, gpu=False
        ),
        ArgType.INT: lambda x: x,
        ArgType.FLOAT: lambda x: x,
        ArgType.SYM_INT: lambda x: x,
        ArgType.BOOL: lambda x: x,
    }[ty](name)


def make_function_arg(
    ty: ArgType,
    name: str,
    default: int | float | None,
    is_optional: bool = False,
    *,
    unused_on: frozenset[DeclSurface] = frozenset(),
    surface: DeclSurface = DeclSurface.HOST_FUNCTION,
) -> str:
    return annotate_unused_declaration(
        _function_arg(ty, name, default, is_optional), unused_on, surface
    )


def _function_arg(
    ty: ArgType,
    name: str,
    default: int | float | None,
    is_optional: bool = False,
) -> str:
    return {
        ArgType.TENSOR: (
            (lambda x: tensor_arg(x))
            if not is_optional
            else (
                optional_tensor_arg
                if default is not None
                else optional_tensor_arg_no_default
            )
        ),
        ArgType.INT_TENSOR: (
            (lambda x: tensor_arg(x))
            if not is_optional
            else (
                optional_tensor_arg
                if default is not None
                else optional_tensor_arg_no_default
            )
        ),
        ArgType.LONG_TENSOR: (
            (lambda x: tensor_arg(x))
            if not is_optional
            else (
                optional_tensor_arg
                if default is not None
                else optional_tensor_arg_no_default
            )
        ),
        ArgType.PLACEHOLDER_TENSOR: (
            (lambda x: tensor_arg(x))
            if not is_optional
            else (
                optional_tensor_arg
                if default is not None
                else optional_tensor_arg_no_default
            )
        ),
        ArgType.INT: (
            (lambda x: int64_arg(x, default=int(default)))
            if default is not None
            else int64_arg_no_default
        ),
        ArgType.FLOAT: (
            (lambda x: double_arg(x, default=default))
            if default is not None
            else double_arg_no_default
        ),
        ArgType.SYM_INT: (
            (lambda x: sym_int_arg(x, default=int(default)))
            if default is not None
            else sym_int_arg_no_default
        ),
        ArgType.BOOL: (
            (lambda x: bool_arg(x, default=bool(default)))
            if default is not None
            else bool_arg_no_default
        ),
    }[ty](name)


def make_function_schema_arg(ty: ArgType, name: str, default: int | float) -> str:
    return {
        ArgType.TENSOR: tensor_arg_annotate,
        ArgType.INT_TENSOR: tensor_arg,
        ArgType.LONG_TENSOR: tensor_arg,
        ArgType.PLACEHOLDER_TENSOR: tensor_arg,
        ArgType.INT: lambda x: int_arg(x, default=int(default)),
        ArgType.FLOAT: lambda x: float_arg(x, default=default),
        # pyre-fixme[6]: For 2nd argument expected `int` but got `float | int`.
        ArgType.SYM_INT: lambda x: schema_sym_int_arg(x, default=default),
        ArgType.BOOL: lambda x: schema_bool_arg(x, default=bool(default)),
    }[ty](name)


def _extend_tensor_str(name: str, is_cuda: bool, optional: bool) -> str:
    """
    Take a tensor name and extend for cpu or cuda

    Parameters:
    name (str)  - tensor name e.g., "momentum1"
    is_cuda (bool) - If True, extend for cuda tensors. Otherwise, extend for cpu tensors

    Returns:
    String of extended tensors
    """
    opt = "?" if optional else ""
    default = " = None" if optional else ""
    if is_cuda:
        return f"Tensor{opt} {name}_dev {default}, Tensor{opt} {name}_uvm {default}, Tensor{opt} {name}_placements {default}, Tensor{opt} {name}_offsets {default}"
    else:
        return f"Tensor{opt} {name}_host {default}, Tensor{opt} {name}_placements {default}, Tensor{opt} {name}_offsets {default}"


def extend_tensors_args_from_str(args_str: str, example_tensor: str) -> str:
    """
    Extend tensor name for cuda/cpu if tensor args exist.
    For example, if `args_str` contains 'Tensor x', it needs to be extended to
    'Tensor x_host' for cpu, and 'Tensor x_dev, Tensor x_uvm, ...' for cuda

    Parameters:
        args: str - function args e.g., "Tensor momentum1, float eps"
        example_tensor: str - a tensor name already extended
                e.g., "momentum1_dev" for cuda or "momentum1_host" for cpu

    Returns:
        function args where tensor args are extended
    """
    num_tensors = args_str.count("Tensor")
    if num_tensors > 0:
        is_cuda = "_dev" in example_tensor
        args = args_str.split(", ")
        extended_tensors_args = []
        for arg in args:
            ty = arg.split(" ")[0]
            name = arg.split(" ")[1]
            if ty == "Tensor":
                extended_tensors_args.append(_extend_tensor_str(name, is_cuda, False))
            elif ty == "Tensor?":
                extended_tensors_args.append(_extend_tensor_str(name, is_cuda, True))
            else:
                extended_tensors_args.append(arg)
        return ", ".join(extended_tensors_args)
    else:
        return args_str


def make_split_function_args_v1(args_str: str) -> str:
    """
    Create function args for V1 interface from the args_str

    Parameters:
    args: str - function args e.g., "Tensor momentum1_host, float eps"

    Returns:
    function args in string where
        int -> int64_t
        SymInt -> c10::SymInt
        float -> double
    """
    return (
        args_str.replace("int", "int64_t")
        .replace("SymInt", "c10::SymInt")
        .replace("float", "double")
        .replace("Tensor?", "std::optional<Tensor>")
        .replace("None", "std::nullopt")
        .replace("False", "false")
    )


def make_ivalue_cast(ty: ArgType) -> str:
    return {
        ArgType.INT: "toInt",
        ArgType.FLOAT: "toDouble",
        ArgType.SYM_INT: "toSymInt",
        ArgType.BOOL: "toBool",
    }[ty]


def make_default_literal(default: int | float | bool) -> str:
    """Format a packed optimizer default as a C++ scalar literal."""
    return str(default).lower() if isinstance(default, bool) else str(default)


def reorder_args(split_arg_spec: list[OptimItem]) -> list[OptimItem]:
    """
    Reorder such that tensor arguments come first. This is used in backend, wrapper and kernels where tensors are no longer optional.
    We need to pass tensor arguments before other types which have default arguments.

    Parameters:
        split_arg_spec (list[OptimItem]): List of argument items

    Return:
        reordered of split_arg_spec
    """
    tensor_args = []
    non_tensor_args = []
    for s in split_arg_spec:
        if s.ty in (
            ArgType.TENSOR,
            ArgType.INT_TENSOR,
            ArgType.LONG_TENSOR,
            ArgType.PLACEHOLDER_TENSOR,
        ):
            tensor_args.append(s)
        else:
            non_tensor_args.append(s)

    return tensor_args + non_tensor_args


@dataclass
class PT2ArgsSet:
    split_function_args: list[str]
    split_function_arg_names: list[str]
    split_function_schemas: list[str]
    split_saved_tensorlist: list[str]
    split_saved_tensorlist_optional: list[str]
    split_saved_data: list[dict[str, str]]
    split_variables: list[str]
    split_unpacked_arg_names: list[str]
    split_args_dict: dict[str, list[str]]
    split_args_defaults: dict[str, dict[str, int | float | bool]]

    @staticmethod
    # pyre-ignore[3]
    def create(
        arg_spec: list[OptimItem],
    ):
        """
        PT2ArgsSet.create() is a method that creates different formats given the optimization arguments
        to be used in TBE codegen PT2 templates.

        Mainly, PT2 unified interface packs tensors to tensor list
        due to limited number of arguments for registered torch ops
        e.g., instead of passing `momentum_host, `momentum_dev`, etc, we pass `momentum`

        Parameters:
        arg_spec: list[OptimItem] - list of argument specs

        Returns:
            PT2ArgsSet object with the following attributes:
            split_function_args: list[str] - List of function arguments used in unified lookup and autograd functions
                                            Tensors will be packed and pass as TensorList. Auxillary arguments will be packed in dict.
                                            e.g., ['at::TensorList momentum1', 'at::Dict<std:string, int> optim_int'].
            split_function_arg_names: list[str] - List of argument names used in unified lookup and autograd functions
                                            e.g., ['momentum1', 'optim_int', 'optim_float'].
            split_function_schemas: list[str] - List of arguments used in unified lookup and autograd functions in the schema format
                                            e.g., ['Tensor[] momentum1', 'float eps', 'float weight_decay'].
            split_saved_tensorlist: list[str] - List of tensor names that are packed into tensorlist and will be unpacked in
                                            PT2 autograd function. e.g., ['momentum1'].
            split_saved_tensorlist_optional: list[str] - List of tensor names that are packed into tensorlist but are optional
                                            and will be unpacked in PT2 autograd function e.g., ['row_counter'].
            split_saved_data: list[dict[str, str]] - List of non-tensor arguments that are saved for backward
            split_unpacked_arg_names: list[str] - List of argument names, unrolled from list
                                            e.g., ['momentum1', 'eps', 'weight_decay', 'iter'].
            split_args_dict: dict[str, list[str]] - Dict of optim arguments' types containing the argument names of that type.
                                            e.g., if an optimizer only has an int argument called iter, the dict will look like:
                                            {'optim_tensor': [], 'optim_int': ['iter'], 'optim_float': [], 'optim_bool': []}
            split_args_defaults: Default values for packed optimizer scalars, keyed by list type and argument name.
                                            The generated Python invoker uses them when frontend wiring does not
                                            provide a value defined by the backend optimizer specification.
        """
        split_function_arg_names = []
        split_function_args = []
        split_function_schemas = []
        split_saved_tensorlist = []
        split_saved_tensorlist_optional = []
        split_saved_data = []
        split_variables = []
        split_unpacked_arg_names = []
        has_optim_tensor = False  # optim tensors here are optional tensor
        has_optim_int = False
        has_optim_float = False
        has_optim_bool = False
        split_args_dict = {
            "optim_tensor": [],
            "optim_int": [],
            "optim_float": [],
            "optim_bool": [],
        }
        split_args_defaults: dict[str, dict[str, int | float | bool]] = {
            "optim_int": {},
            "optim_float": {},
            "optim_bool": {},
        }
        # list of symint args to be appended after optim_xxx args
        # since they have default values
        symint_list: list[OptimItem] = []

        # Packed scalar arguments are append-only across package versions. A
        # newer backend can receive a shorter list from an older frontend, so
        # every generated C++ read checks the runtime length and falls back to
        # the declared default. An older backend already ignores values that a
        # newer frontend appends after its known prefix.
        for s in arg_spec:
            if s.name == "learning_rate_tensor":
                split_function_arg_names.append(s.name)
                split_unpacked_arg_names.append(s.name)
                split_function_args.append(tensor_arg(s.name))
                split_function_schemas.append(tensor_arg(s.name))
                split_variables.append(f"ret.push_back(Variable()); // {s.name}")
            elif s.ty in (
                ArgType.TENSOR,
                ArgType.INT_TENSOR,
                ArgType.LONG_TENSOR,
                ArgType.PLACEHOLDER_TENSOR,
            ):
                name = s.name
                split_unpacked_arg_names.append(name)
                if s.is_optional:
                    # An omitted optional state gets a float placeholder in the
                    # PT2 autograd, which only matches TENSOR's acc_type accessor.
                    assert (
                        s.ty == ArgType.TENSOR
                    ), f"optional optimizer arg {name} must be ArgType.TENSOR, got {s.ty}"
                    split_saved_tensorlist_optional.append(name)
                    split_args_dict["optim_tensor"].append(s.name)
                    has_optim_tensor = True
                else:
                    split_function_args.append(
                        tensor_list_arg_no_default(name, pass_by_ref=False)
                    )
                    split_function_arg_names.append(name)
                    split_function_schemas.append(
                        schema_tensor_list_arg_no_default(name)
                    )
                    split_saved_tensorlist.append(name)
                    split_variables.append(
                        f"ret.push_back(Variable()); // {s.name}_dev or host"
                    )
                    split_variables.append(
                        f"ret.push_back(Variable()); // {s.name}_placements"
                    )
                    split_variables.append(
                        f"ret.push_back(Variable()); // {s.name}_offsets"
                    )
                    split_variables.append("if (" + name + "_host.sym_numel() == 0) {")
                    split_variables.append(
                        f"ret.push_back(Variable()); // {s.name}_uvm"
                    )
                    split_variables.append("}")
            else:
                if s.ty == ArgType.INT:
                    # iter is passed in aux_int
                    if s.name != "iter":
                        int_default = int(s.default)
                        split_args_dict["optim_int"].append(s.name)
                        int_index = len(split_args_dict["optim_int"]) - 1
                        split_args_defaults["optim_int"][s.name] = int_default
                        split_saved_data.append(
                            (
                                s.name,
                                (
                                    f"optim_int.size() > {int_index} ? "
                                    f"optim_int[{int_index}] : "
                                    f"{make_default_literal(int_default)}"
                                ),
                                make_ivalue_cast(s.ty),
                                "int64_t",
                            )
                        )
                        has_optim_int = True
                elif s.ty == ArgType.SYM_INT:
                    symint_list.append(s)
                    split_saved_data.append(
                        (
                            s.name,
                            "",
                            make_ivalue_cast(s.ty),
                            "c10::SymInt",
                        )
                    )
                elif s.ty == ArgType.FLOAT:
                    float_default = float(s.default)
                    split_args_dict["optim_float"].append(s.name)
                    float_index = len(split_args_dict["optim_float"]) - 1
                    split_args_defaults["optim_float"][s.name] = float_default
                    split_saved_data.append(
                        (
                            s.name,
                            (
                                f"optim_float.size() > {float_index} ? "
                                f"optim_float[{float_index}] : "
                                f"{make_default_literal(float_default)}"
                            ),
                            make_ivalue_cast(s.ty),
                            "double",
                        )
                    )
                    has_optim_float = True
                elif s.ty == ArgType.BOOL:
                    bool_default = bool(s.default)
                    split_args_dict["optim_bool"].append(s.name)
                    bool_index = len(split_args_dict["optim_bool"]) - 1
                    split_args_defaults["optim_bool"][s.name] = bool_default
                    split_saved_data.append(
                        (
                            s.name,
                            (
                                f"optim_bool.size() > {bool_index} ? "
                                f"optim_bool[{bool_index}] : "
                                f"{make_default_literal(bool_default)}"
                            ),
                            make_ivalue_cast(s.ty),
                            "bool",
                        )
                    )
                    has_optim_bool = True
                else:
                    raise ValueError(f"Unsupported type {s.ty}")
                split_unpacked_arg_names.append(s.name)

        def append_lists(type_name: str) -> None:
            """
            Append the list as one argument to the list of function arguments, schemas, names and saved_variables.
            e.g., if type_name is "tensor", optim_tensor will be appended with the corresponding syntax.

            Parameters:
                type_name (str) - type name of the list to be appended

            Returns:
                None
            """
            split_function_args.append(list_arg(type_name))
            split_function_schemas.append(schema_list_arg(type_name))
            split_function_arg_names.append(f"optim_{type_name}")
            split_variables.append(f"ret.push_back(Variable()); // optim_{type_name}")

        if has_optim_tensor:
            append_lists("tensor")
        if has_optim_int:
            append_lists("int")
        if has_optim_float:
            append_lists("float")
        if has_optim_bool:
            append_lists("bool")
        for s in symint_list:
            split_function_arg_names.append(s.name)
            split_function_args.append(make_function_arg(s.ty, s.name, s.default))
            split_function_schemas.append(
                make_function_schema_arg(s.ty, s.name, s.default)
            )
            split_variables.append(f"ret.push_back(Variable()); // {s.name}")
        return PT2ArgsSet(
            split_function_args=split_function_args,
            split_function_arg_names=split_function_arg_names,
            split_function_schemas=split_function_schemas,
            split_saved_tensorlist=split_saved_tensorlist,
            split_saved_tensorlist_optional=split_saved_tensorlist_optional,
            split_saved_data=split_saved_data,
            split_variables=split_variables,
            split_unpacked_arg_names=split_unpacked_arg_names,
            split_args_dict=split_args_dict,
            split_args_defaults=split_args_defaults,
        )


######################################################################
# Optimizer Args
######################################################################


# Required positional lists are part of each published lookup schema. Keep this
# contract fixed when optimizer specs gain arguments: other lists belong after
# every existing lookup parameter, with None defaults for older frontends.
LOOKUP_REQUIRED_OPTIMIZER_LISTS: dict[str, tuple[str, ...]] = {
    "adagrad": ("optim_float",),
    "adam": ("optim_tensor", "optim_float", "optim_bool"),
    "lamb": ("optim_float",),
    "lars_sgd": ("optim_float",),
    "partial_rowwise_adam": ("optim_float",),
    "partial_rowwise_lamb": ("optim_float",),
    "rowwise_adagrad": ("optim_int", "optim_float"),
    "rowwise_adagrad_with_counter": ("optim_int", "optim_float"),
    "rowwise_rmsprop_ar": ("optim_float",),
    "sgd": (),
    "none": ("optim_int",),
}


def make_lookup_function_args(args: PT2ArgsSet, optimizer: str) -> dict[str, list[str]]:
    """Preserve published lookup slots and reserve defaulted optimizer lists.

    Python frontend and C++ backend packages upgrade independently. Lists that
    already occupy required positional slots retain their declarations and
    order. Other lists are appended after all existing lookup parameters as
    optional lists defaulting to None, so older frontends can omit them. Lookup
    converts None to an empty list for reserved lists used by autograd; unused
    reserved parameters are ignored. Positions remain unchanged when an
    optimizer starts using a list. Frontends must not supply reserved lists to
    backends that predate these parameters.

    Optimizers without a published PT2 lookup schema reserve all four lists.
    Internal autograd arguments remain driven by the optimizer specification.
    """
    required = LOOKUP_REQUIRED_OPTIMIZER_LISTS.get(optimizer, ())
    indices = [
        index
        for index, name in enumerate(args.split_function_arg_names)
        if name not in args.split_args_dict or name in required
    ]
    default_names = [name for name in args.split_args_dict if name not in required]
    result = {
        "args": [args.split_function_args[index] for index in indices],
        "schemas": [args.split_function_schemas[index] for index in indices],
        "default_args": [],
        "default_schemas": [],
        "default_initializers": [],
    }
    for name in default_names:
        ty = name.removeprefix("optim_")
        cpp_type = list_arg(ty).rsplit(" ", 1)[0]
        schema_type = schema_list_arg(ty).rsplit(" ", 1)[0]
        used = name in args.split_function_arg_names
        unused = "" if used else "[[maybe_unused]] "
        result["default_args"].append(
            f"{unused}std::optional<{cpp_type}> {name}_optional = std::nullopt"
        )
        result["default_schemas"].append(f"{schema_type}? {name}=None")
        if used:
            result["default_initializers"].append(
                f"[[maybe_unused]] auto {name} = "
                f"{name}_optional.value_or({cpp_type}{{}});"
            )
    return result


@dataclass
class OptimizerArgs:
    split_kernel_args: list[str]
    split_kernel_args_no_defaults: list[str]
    split_kernel_arg_constructors: list[str]
    split_cpu_kernel_args: list[str]
    split_cpu_kernel_arg_constructors: list[str]
    split_function_args: list[str]
    split_function_args_no_defaults: list[str]
    split_saved_tensors: list[str]
    split_tensors: list[str]
    split_tensor_types: dict[str, str]
    saved_data: list[tuple[str, str]]
    split_function_arg_names: list[str]
    split_function_schemas: list[str]
    split_variables: list[str]
    split_ref_kernel_args: list[str]
    placeholder_tensor_names: list[str]
    # pyre-fixme[11]: Annotation `TensorType` is not defined as a type.
    placeholder_type_combos: list[dict[str, TensorType]] | list[None]
    unified_pt2: PT2ArgsSet
    split_kernel_arg_names: list[str]
    split_function_args_autograd: list[str]
    split_function_arg_names_autograd: list[str]
    split_saved_tensors_optional: list[str]
    # `split_function_args` / `split_function_args_no_defaults` rendered once
    # per DeclSurface, keyed by the surface's value. A template that shares a
    # projection with another surface -- the meta shadow of the CUDA host
    # function, or the PT2 CPU and CUDA wrappers over the unified argument list
    # -- reads its own entry here so the two can annotate differently.
    split_function_args_by_surface: dict[str, list[str]]
    split_function_args_no_defaults_by_surface: dict[str, list[str]]
    split_function_args_v1: str | None = None
    split_function_schemas_v1: str | None = None

    @staticmethod
    # pyre-ignore[3]
    def create(
        split_arg_spec: list[OptimItem],
        arg_spec: list[OptimItem],
        gpu: bool,
        additional_spec: dict[str, Any] | None = None,
    ):
        # Keep the argument order for forward/backward compatibility
        # Arg order: non-optional tensors, learning_rate_tensor, non-tensors, optional tensors
        # This is used in lookup and autograd functions
        frontend_split_arg_spec = split_arg_spec.copy()

        has_optional_tensors: bool = False
        # Create another spec for kernels where learning_rate is float
        # This is used in kernels
        kernel_split_arg_spec = split_arg_spec.copy()
        for i, s in enumerate(kernel_split_arg_spec):
            if s.name == "learning_rate_tensor":
                # pyre-ignore[6]
                kernel_split_arg_spec[i] = OptimItem(
                    ArgType.FLOAT, "learning_rate", unused_on=s.unused_on
                )
            if s.is_optional:
                has_optional_tensors = True

        # Optim arg order: non-optional tensors, learning_rate_tensor, non-tensors, optional tensors
        # The optional tensors are converted to Tensor in autograd functions
        # Hence, need to reorganize such that the tensors come before non-tensors which have default values values
        # This is used in wrapper, backend and kernel functions
        if has_optional_tensors:
            # reordered args for split_arg_spec: non-optional tensors, learning_rate_tensor, optional tensors as tensors, non-tensors
            split_arg_spec = reorder_args(split_arg_spec)
            # reordered args for kernel_split_arg_spec: non-optional tensors, optional tensors as tensors, learning rate (float), non-tensors
            kernel_split_arg_spec = reorder_args(kernel_split_arg_spec)

        # Compute placeholder tensor combinations
        ph_tensor_names = [
            s.name for s in arg_spec if s.ty == ArgType.PLACEHOLDER_TENSOR
        ]
        ph_tensor_types = [
            # pyre-ignore[16]
            [arg_type_to_tensor_type[t] for t in s.ph_tys]
            for s in arg_spec
            if s.ty == ArgType.PLACEHOLDER_TENSOR
        ]
        if len(ph_tensor_names) > 0:
            ph_combos_list = itertools.product(*ph_tensor_types)
            ph_combos = [
                {k: ph for k, ph in zip(ph_tensor_names, combo)}
                for combo in ph_combos_list
            ]
        else:
            ph_combos = [None]

        split_saved_tensors = [
            s.name
            for s in split_arg_spec
            if s.ty
            in (
                ArgType.TENSOR,
                ArgType.INT_TENSOR,
                ArgType.LONG_TENSOR,
                ArgType.PLACEHOLDER_TENSOR,
            )
        ]
        # Create empty tensors based on weights
        # weights name convention is different between v1 and pt2 unified interface (v2)
        # i.e., host_weights, dev_weights uvm_weights, weights_placements, weights_offsets in v1 and weights_{} in v2
        # This is only used in v1, so we fix the name based on v1
        create_empty_tensor = {
            "host": "host_weights.options()",
            "dev": "dev_weights.options()",
            "uvm": "uvm_weights.options()",
            "placements": "weights_placements.options()",
            "offsets": "weights_offsets.options()",
        }
        split_saved_tensors_optional = [
            (
                f"{s.name}.has_value() ? {s.name}.value() : at::empty("
                + "{0}, "
                + create_empty_tensor[s.name.rsplit("_", 1)[1]]
                + ")"
                if s.is_optional
                else s.name
            )
            for s in split_arg_spec
            if s.ty
            in (
                ArgType.TENSOR,
                ArgType.INT_TENSOR,
                ArgType.LONG_TENSOR,
                ArgType.PLACEHOLDER_TENSOR,
            )
        ]

        # Create function args and schemas for V1 interface for backward compatibility
        # V1 interface refers to separate CPU/CUDA lookup functions
        # e.g., split_embedding_codegen_lookup_{}_funtion and split_embedding_codegen_lookup_{}_funtion_cpu)
        # An optimizer opts out of V1 by either omitting `additional_spec` or
        # setting an empty `v1` spec. Both are normalized to None here so the
        # downstream templates (which gate V1 codegen on `split_function_args_v1
        # is not none`) skip V1 entirely instead of emitting an empty arg list.
        split_function_args_v1 = None
        split_function_schemas_v1 = None
        if additional_spec is not None and additional_spec.get("v1"):
            if len(split_saved_tensors) > 0:
                extended_args_str = extend_tensors_args_from_str(
                    additional_spec["v1"], split_saved_tensors[0]
                )
            else:
                extended_args_str = additional_spec["v1"]
            split_function_args_v1 = make_split_function_args_v1(extended_args_str)
            split_function_schemas_v1 = extended_args_str

        # pyre-fixme[28]: Unexpected keyword argument `placeholder_type_combos`.
        return OptimizerArgs(
            # GPU kernel args
            split_kernel_args=[
                make_kernel_arg(s.ty, s.name, s.default, unused_on=s.unused_on)
                for s in kernel_split_arg_spec
            ],
            split_kernel_args_no_defaults=[
                make_kernel_arg(s.ty, s.name, None, unused_on=s.unused_on)
                for s in kernel_split_arg_spec
            ],
            split_kernel_arg_constructors=[
                make_kernel_arg_constructor(s.ty, s.name) for s in kernel_split_arg_spec
            ],
            # CPU kernel args
            split_cpu_kernel_args=[
                make_cpu_kernel_arg(s.ty, s.name, s.default, unused_on=s.unused_on)
                for s in kernel_split_arg_spec
            ],
            split_cpu_kernel_arg_constructors=[
                make_cpu_kernel_arg_constructor(s.ty, s.name)
                for s in kernel_split_arg_spec
            ],
            # Function args
            split_function_args=[
                make_function_arg(s.ty, s.name, s.default, unused_on=s.unused_on)
                for s in split_arg_spec
            ],
            split_function_args_no_defaults=[
                make_function_arg(s.ty, s.name, None, unused_on=s.unused_on)
                for s in split_arg_spec
            ],
            split_function_args_by_surface={
                surface.value: [
                    make_function_arg(
                        s.ty,
                        s.name,
                        s.default,
                        unused_on=s.unused_on,
                        surface=surface,
                    )
                    for s in split_arg_spec
                ]
                for surface in DeclSurface
            },
            split_function_args_no_defaults_by_surface={
                surface.value: [
                    make_function_arg(
                        s.ty, s.name, None, unused_on=s.unused_on, surface=surface
                    )
                    for s in split_arg_spec
                ]
                for surface in DeclSurface
            },
            # Helper values
            split_tensors=[
                s.name
                for s in arg_spec
                if (
                    s.ty in (ArgType.TENSOR, ArgType.PLACEHOLDER_TENSOR)
                    and s.name != "learning_rate_tensor"
                    and not s.is_optional
                )
            ],
            split_tensor_types={
                s.name: (
                    "at::acc_type<" + ("cache_t" if gpu else "scalar_t") + ", true>"
                    if s.ty == ArgType.TENSOR
                    else (s.name + "_ph_t")
                )
                for s in arg_spec
                if (
                    s.ty in (ArgType.TENSOR, ArgType.PLACEHOLDER_TENSOR)
                    and s.name != "learning_rate_tensor"
                    and not s.is_optional
                )
            },
            split_saved_tensors=split_saved_tensors,
            saved_data=[
                (s.name, make_ivalue_cast(s.ty))
                for s in arg_spec
                if s.ty not in (ArgType.TENSOR, ArgType.PLACEHOLDER_TENSOR)
            ],
            split_function_arg_names=[s.name for s in split_arg_spec],
            split_function_schemas=[
                make_function_schema_arg(s.ty, s.name, s.default)
                for s in split_arg_spec
            ],
            split_variables=["Variable()" for _ in split_arg_spec],
            split_ref_kernel_args=[
                make_kernel_arg(
                    s.ty, s.name, s.default, pass_by_ref=True, unused_on=s.unused_on
                )
                for s in kernel_split_arg_spec
            ],
            placeholder_tensor_names=ph_tensor_names,
            placeholder_type_combos=ph_combos,
            unified_pt2=PT2ArgsSet.create(arg_spec),
            # learning rate remains float in kernels
            split_kernel_arg_names=[
                "learning_rate" if s.name == "learning_rate_tensor" else s.name
                for s in kernel_split_arg_spec
            ],
            split_function_args_autograd=[
                make_function_arg(
                    s.ty,
                    s.name,
                    s.default,
                    s.is_optional,
                    unused_on=s.unused_on,
                    surface=DeclSurface.AUTOGRAD,
                )
                for s in frontend_split_arg_spec
            ],
            split_function_arg_names_autograd=[s.name for s in frontend_split_arg_spec],
            split_saved_tensors_optional=split_saved_tensors_optional,
            split_function_args_v1=split_function_args_v1,
            split_function_schemas_v1=split_function_schemas_v1,
        )


######################################################################
# Optimizer Args Set
######################################################################


@dataclass
class OptimizerArgsSet:
    cpu: OptimizerArgs
    cuda: OptimizerArgs
    any: OptimizerArgs

    @staticmethod
    def create_optim_args(
        arg_spec: list[OptimItem],
        ext_fn: Callable[[OptimItem], list[OptimItem]],
        gpu: bool,
        additional_spec: dict[str, Any] | None = None,
    ) -> OptimizerArgs:
        split_arg_spec = []
        for s in arg_spec:
            # no cpu/cuda extension for learning_rate
            if (
                s.ty in (ArgType.FLOAT, ArgType.INT, ArgType.SYM_INT, ArgType.BOOL)
                or s.name == "learning_rate_tensor"
            ):
                # pyre-fixme[19]: Expected 1 positional argument.
                split_arg_spec.append(
                    OptimItem(s.ty, s.name, s.default, unused_on=s.unused_on)
                )
            else:
                assert s.ty in (ArgType.TENSOR, ArgType.PLACEHOLDER_TENSOR)
                # Treat PLACEHOLDER_TENSOR as TENSOR for CPU
                split_arg_spec.extend(ext_fn(s))
        return OptimizerArgs.create(split_arg_spec, arg_spec, gpu, additional_spec)

    @staticmethod
    def extend_for_cpu(spec: OptimItem) -> list[OptimItem]:
        name = spec.name
        default = spec.default
        is_optional = spec.is_optional
        unused_on = spec.unused_on
        return [
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(
                ArgType.TENSOR,
                f"{name}_host",
                default,
                is_optional=is_optional,
                unused_on=unused_on,
            ),
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(
                ArgType.INT_TENSOR,
                f"{name}_placements",
                default,
                is_optional=is_optional,
                # A placements tensor tells the CUDA path which of the device,
                # UVM, or cache copies to read. The CPU kernel only ever has
                # the host copy, so it forwards the tensor to keep the
                # signature uniform and never dereferences it.
                unused_on=unused_on | {DeclSurface.CPU_KERNEL},
            ),
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(
                ArgType.LONG_TENSOR,
                f"{name}_offsets",
                default,
                is_optional=is_optional,
                unused_on=unused_on,
            ),
        ]

    @staticmethod
    def extend_for_cuda(spec: OptimItem) -> list[OptimItem]:
        name = spec.name
        default = spec.default
        ty = spec.ty
        ph_tys = spec.ph_tys
        is_optional = spec.is_optional
        unused_on = spec.unused_on
        return [
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(ty, f"{name}_dev", default, ph_tys, is_optional, unused_on),
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(ty, f"{name}_uvm", default, ph_tys, is_optional, unused_on),
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(
                ArgType.INT_TENSOR,
                f"{name}_placements",
                default,
                is_optional=is_optional,
                unused_on=unused_on,
            ),
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(
                ArgType.LONG_TENSOR,
                f"{name}_offsets",
                default,
                is_optional=is_optional,
                unused_on=unused_on,
            ),
        ]

    @staticmethod
    def extend_for_any(spec: OptimItem) -> list[OptimItem]:
        name = spec.name
        default = spec.default
        ty = spec.ty
        ph_tys = spec.ph_tys
        is_optional = spec.is_optional
        unused_on = spec.unused_on
        return [
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(
                ArgType.TENSOR,
                f"{name}_host",
                default,
                is_optional=is_optional,
                unused_on=unused_on | {DeclSurface.PT2_CUDA},
            ),
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(
                ty,
                f"{name}_dev",
                default,
                ph_tys,
                is_optional=is_optional,
                unused_on=unused_on | {DeclSurface.PT2_CPU},
            ),
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(
                ty,
                f"{name}_uvm",
                default,
                ph_tys,
                is_optional=is_optional,
                unused_on=unused_on | {DeclSurface.PT2_CPU},
            ),
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(
                ArgType.INT_TENSOR,
                f"{name}_placements",
                default,
                is_optional=is_optional,
                unused_on=unused_on,
            ),
            # pyre-fixme[19]: Expected 1 positional argument.
            OptimItem(
                ArgType.LONG_TENSOR,
                f"{name}_offsets",
                default,
                is_optional=is_optional,
                unused_on=unused_on,
            ),
        ]

    @staticmethod
    # pyre-ignore[3]
    def create(
        arg_spec: list[OptimItem], additional_spec: dict[str, Any] | None = None
    ):
        return OptimizerArgsSet(
            *(
                OptimizerArgsSet.create_optim_args(
                    arg_spec, ext_fn, gpu, additional_spec
                )
                for ext_fn, gpu in (
                    (OptimizerArgsSet.extend_for_cpu, False),
                    (OptimizerArgsSet.extend_for_cuda, True),
                    (OptimizerArgsSet.extend_for_any, True),
                )
            )
        )
