# Copyright (c) 2025, NVIDIA CORPORATION & AFFILIATES.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Define MMAU-Pro as a benchmark group with three separate evaluation types
REQUIRES_DATA_DIR = True
IS_BENCHMARK_GROUP = True
SCORE_MODULE = "nemo_skills.dataset.mmau-pro.mmau_pro_score"

# Three separate benchmark subgroups for different evaluation approaches
BENCHMARKS = {
    "mmau-pro.closed_form": {},
    "mmau-pro.open_ended": {},
    "mmau-pro.instruction_following": {},
}
