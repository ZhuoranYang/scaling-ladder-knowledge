# Tau2-bench-revised

This repository contains a revised version of the [τ²-bench](https://github.com/sierra-research/tau2-bench) evaluation dataset with important fixes and improvements to ensure reliable and reproducible evaluation results.

## Background

The original [τ²-bench](https://github.com/sierra-research/tau2-bench) configuration has several known issues that have led different research groups and model developers to make various modifications during evaluation. To ensure transparency, reproducibility, and credibility of our evaluation results, we are publicly releasing our revised version of the benchmark with all modifications clearly documented.

## Modifications

We have made the following three critical improvements to the tau2-bench dataset:

### 1. Airline Domain Task Fixes

For the Airline domain we adopt the fixes to the domain as proposed in the Claude Opus 4.5 release report.

- **Location**: `data/tau2/domains/airline/tasks.json`
- **Details**: See [task_revisions.md](data/tau2/domains/airline/task_revisions.md)

### 2. Retail User Simulation Prompt Improvements

Improved the Retail User simulation prompt to avoid failure modes from premature task termination. These improvements are based on the approach described in the [GLM-4.5 technical report](https://arxiv.org/abs/2508.06471).

- **Location**: `data/tau2/user_simulator/simulation_guidelines_retail.md`
- **Reference**: [arXiv:2508.06471](https://arxiv.org/abs/2508.06471)

### 3. Telecom User Simulation Prompt Improvements

Similarly improved the Telecom User prompt to avoid failure modes from premature task termination, especially for transfer handling scenarios.

- **Location**: `data/tau2/user_simulator/simulation_guidelines_tools.md`

## Repository Structure

```
data/
└── tau2/
    ├── domains/
    │   └── airline/
    │       └── tasks.json          # Fixed airline domain tasks
    └── user_simulator/
        ├── simulation_guidelines_retail.md    # Improved retail user simulation prompt
        └── simulation_guidelines_tools.md     # Improved telecom user simulation prompt
```

## Usage

This revised benchmark can be used as a drop-in replacement for the original [τ²-bench](https://github.com/sierra-research/tau2-bench) dataset. Simply replace the corresponding files in your τ²-bench evaluation pipeline with the versions provided in this repository.

For detailed instructions on running evaluations with τ²-bench, please refer to the [official τ²-bench documentation](https://github.com/sierra-research/tau2-bench).

## Citation

If you use the resources from this project, please cite as follows:

```bibtex
@misc{tau2-bench-revised2026,
  author       = {AGI-Eval},
  title        = {tau2-bench-revised},
  year         = {2026},
  url          = {https://github.com/AGI-Eval-Official/tau2-bench-revised}
}
```
