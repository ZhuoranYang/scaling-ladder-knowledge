.. _Install-Page-Windows:

========================
Installation for Windows
========================

**System Requirements**

The following system requirements are necessary to install and use Model Optimizer - Windows:

+-------------------------+-----------------------------+
| OS                      |  Windows                    |
+-------------------------+-----------------------------+
| Architecture            |  amd64 (x86_64), ARM64*     |
+-------------------------+-----------------------------+
| Python                  |  >=3.11,<3.14               |
+-------------------------+-----------------------------+
| CUDA                    |  >=12.0                     |
+-------------------------+-----------------------------+
| ONNX Runtime            |  1.20.0                     |
+-------------------------+-----------------------------+
| Nvidia Driver           |  565.90 or newer            |
+-------------------------+-----------------------------+
| Nvidia GPU              |  RTX 40 and 50 series       |
+-------------------------+-----------------------------+

.. note::
   - Make sure to use GPU-compatible driver and other dependencies (e.g. torch etc.). For instance, support for Blackwell GPU might be present in Nvidia 570+ driver, and CUDA-12.8+.
   - We currently support *Single-GPU* configuration.
   - Windows ARM64 support is experimental and requires native ARM64 dependencies. Follow the
     :ref:`Windows on Arm installation guide <Install-Page-Windows-ARM64>` for the tested Python
     environment and any required source builds.

The Model Optimizer - Windows can be used in following ways:

.. note::
   Model Optimizer will download and install additional third-party open source software projects.
   Review the license terms of these open source projects before use.

.. toctree::
   :glob:
   :maxdepth: 1

   ./_installation_standalone.rst
   ./_installation_windows_arm64.rst
   ./_installation_with_olive.rst
