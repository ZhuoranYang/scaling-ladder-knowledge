# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import dataclasses
import warnings
from collections.abc import Callable
from pathlib import Path
from typing import Any

import torch
import yaml
from torch.utils.data import DataLoader
from tqdm import tqdm
from vllm.sampling_params import SamplingParams
from vllm.v1.core.sched.output import CachedRequestData, NewRequestData, SchedulerOutput

import modelopt.torch.quantization as mtq
from modelopt.recipe import ModelOptPTQRecipe, load_recipe
from modelopt.torch.export.plugins.vllm_fakequant_hf import (
    QUANTIZER_RECIPE_FORMAT,
    QUANTIZER_RECIPE_VERSION,
)
from modelopt.torch.quantization.plugins.vllm import VllmMLAAttention


def _create_new_data_cls(data_cls, **kwargs):
    """vLLM's low-level API changes frequently. This function creates a class with parameters
    compatible with the different vLLM versions."""
    valid_params = {field.name for field in dataclasses.fields(data_cls)}
    filtered_kwargs = {k: v for k, v in kwargs.items() if k in valid_params}
    return data_cls(**filtered_kwargs)


def _get_calibration_block_count(
    model_runner: Any,
) -> Callable[[int, Any], int] | None:
    """Return the block reservation policy supported by the installed vLLM."""
    vllm_config = model_runner.vllm_config

    try:
        from vllm.v1.worker.gpu.warmup import _reserved_block_count
    except ImportError:
        try:
            from vllm.utils.math_utils import cdiv
            from vllm.v1.kv_cache_interface import CrossAttentionSpec, MambaSpec
        except ImportError:
            return None

        def block_count(num_tokens: int, kv_cache_spec: Any) -> int:
            """Calculate the vLLM 0.26 warmup block reservation."""
            # vLLM 0.26's warmup reservation policy.
            if isinstance(kv_cache_spec, CrossAttentionSpec):
                num_tokens = 0
            num_blocks = cdiv(num_tokens, kv_cache_spec.block_size)
            if isinstance(kv_cache_spec, MambaSpec) and kv_cache_spec.mamba_cache_mode == "align":
                num_blocks += kv_cache_spec.num_speculative_blocks
            return num_blocks

    else:
        try:
            from vllm.v1.kv_cache_interface import KpoolTailSpec, UniformTypeKVCacheSpecs
        except ImportError:
            kpool_tail_spec_types = ()
            uniform_kv_cache_spec_types = ()
        else:
            kpool_tail_spec_types = (KpoolTailSpec,)
            uniform_kv_cache_spec_types = (UniformTypeKVCacheSpecs,)

        def block_count(num_tokens: int, kv_cache_spec: Any) -> int:
            """Calculate the current vLLM warmup block reservation."""
            # KpoolTailSpec is a one-block circular scratch cache. The generic
            # vLLM warmup helper sees its SlidingWindowSpec base and reserves
            # one block per block_size tokens, overflowing the one-block table.
            unwrapped_spec = (
                kv_cache_spec.first_spec
                if isinstance(kv_cache_spec, uniform_kv_cache_spec_types)
                else kv_cache_spec
            )
            if isinstance(unwrapped_spec, kpool_tail_spec_types):
                return 1

            # Calibration runs before model_state is initialized, so call the
            # underlying reservation policy rather than _warmup_block_counter.
            return _reserved_block_count(
                num_tokens,
                kv_cache_spec,
                num_lookahead_tokens=vllm_config.num_lookahead_tokens,
                max_model_len=model_runner.max_model_len,
                max_encoder_len=0,
            )

    return block_count


def _allocate_calibration_blocks(
    self: Any, sequence_lengths: list[int]
) -> tuple[list[tuple[list[int], ...]], list[int] | None]:
    """Allocate scheduler-compatible scratch blocks for calibration requests.

    vLLM 0.28 treats block 0 as the null block. Its GPU runner expects real block
    tables for hybrid attention/Mamba models, even for one-shot prefill requests.
    Use vLLM's warmup reservation policy so this stays aligned with each cache
    group's KVCacheSpec.
    """
    kv_cache_config = self.model_runner.kv_cache_config
    kv_cache_groups = kv_cache_config.kv_cache_groups
    block_count = _get_calibration_block_count(self.model_runner)

    if block_count is None:
        warnings.warn(
            "vLLM warmup block reservation helpers were not found; falling back to "
            "empty block tables. Hybrid attention/Mamba models may produce NaNs.",
            stacklevel=2,
        )
        return [tuple([] for _ in kv_cache_groups) for _ in sequence_lengths], None

    next_block_id = 1  # Block 0 is reserved as the null block.
    block_ids_batch: list[tuple[list[int], ...]] = []
    allocated_block_ids: list[int] = []

    for sequence_length in sequence_lengths:
        request_block_ids = []
        for group in kv_cache_groups:
            num_blocks = block_count(sequence_length, group.kv_cache_spec)
            block_ids = list(range(next_block_id, next_block_id + num_blocks))
            next_block_id += num_blocks
            allocated_block_ids.extend(block_ids)
            request_block_ids.append(block_ids)
        block_ids_batch.append(tuple(request_block_ids))

    if next_block_id > kv_cache_config.num_blocks:
        raise RuntimeError(
            "Calibration batch requires "
            f"{next_block_id - 1} KV cache blocks, but only "
            f"{kv_cache_config.num_blocks - 1} non-null blocks are available."
        )

    scheduler_fields = {field.name for field in dataclasses.fields(SchedulerOutput)}
    if "new_block_ids_to_zero" in scheduler_fields:
        blocks_to_zero = (
            allocated_block_ids if getattr(kv_cache_config, "needs_kv_cache_zeroing", False) else []
        )
    else:
        blocks_to_zero = None
    return block_ids_batch, blocks_to_zero


def _cleanup_calibration_requests(
    self: Any,
    cleanup_output: SchedulerOutput,
    calibration_error: BaseException | None,
) -> None:
    """Clean request state without hiding an active calibration error."""
    try:
        # Zero-token steps return before forward/sampling, so no sample_tokens call is needed.
        self.execute_model(cleanup_output)
    except Exception as execute_error:
        finish_requests = getattr(self.model_runner, "finish_requests", None)
        if finish_requests is None:
            if calibration_error is not None:
                raise calibration_error from execute_error
            raise

        try:
            finish_requests(cleanup_output)
        except Exception as finish_error:
            if calibration_error is not None:
                finish_error.__cause__ = execute_error
                raise calibration_error from finish_error
            raise finish_error from execute_error


def calibrate_fun(calib_dataloader: DataLoader, self: Any) -> Callable[[Any], None]:
    """Create a calibration loop backed by the vLLM worker scheduler."""

    def calibrate_loop(model: Any) -> None:
        """Calibrate the model with batches submitted through the scheduler."""
        for batch_idx, batch in tqdm(enumerate(calib_dataloader)):
            input_ids_batch = batch["input_ids"]

            # Convert to list of flat token id lists (one per sequence in batch)
            if torch.is_tensor(input_ids_batch):
                input_ids_batch = input_ids_batch.cpu()
                # Handle both [batch_size, seq_len] and [seq_len]
                if input_ids_batch.dim() == 1:
                    input_ids_batch = input_ids_batch.unsqueeze(0)
                input_ids_list_batch = [seq.tolist() for seq in input_ids_batch]
            else:
                input_ids_list_batch = [
                    list(seq) if not isinstance(seq, list) else seq for seq in input_ids_batch
                ]
                if input_ids_list_batch and isinstance(input_ids_list_batch[0], int):
                    input_ids_list_batch = [input_ids_list_batch]

            num_groups = len(self.model_runner.kv_cache_config.kv_cache_groups)
            block_ids_batch, new_block_ids_to_zero = _allocate_calibration_blocks(
                self, [len(input_ids) for input_ids in input_ids_list_batch]
            )

            scheduled_new_reqs = []
            num_scheduled_tokens = {}
            total_tokens = 0
            for seq_idx, input_ids_list in enumerate(input_ids_list_batch):
                req_id = f"req-{batch_idx}-{seq_idx}"
                new_req = _create_new_data_cls(
                    NewRequestData,
                    req_id=req_id,
                    prompt_token_ids=input_ids_list,
                    prefill_token_ids=input_ids_list,
                    mm_kwargs=[],
                    mm_hashes=[],
                    mm_positions=[],
                    mm_features=[],
                    sampling_params=SamplingParams(max_tokens=1),
                    pooling_params=None,
                    block_ids=block_ids_batch[seq_idx],
                    num_computed_tokens=0,
                    lora_request=None,
                )
                scheduled_new_reqs.append(new_req)
                num_scheduled_tokens[req_id] = len(input_ids_list)
                total_tokens += len(input_ids_list)

            scheduler_output = _create_new_data_cls(
                SchedulerOutput,
                scheduled_new_reqs=scheduled_new_reqs,
                scheduled_cached_reqs=CachedRequestData.make_empty(),
                num_scheduled_tokens=num_scheduled_tokens,
                total_num_scheduled_tokens=total_tokens,
                scheduled_spec_decode_tokens={},
                scheduled_encoder_inputs={},
                num_common_prefix_blocks=[0] * num_groups,
                finished_req_ids=set(),
                free_encoder_mm_hashes=[],
                kv_connector_metadata=None,
                structured_output_request_ids={},
                grammar_bitmask=None,
                new_block_ids_to_zero=new_block_ids_to_zero,
            )
            # Submit a zero-token scheduler step after the request has been
            # registered. This is the vLLM 0.28 cleanup path and removes
            # request-scoped attention/Mamba state from the persistent batch.
            cleanup_output = _create_new_data_cls(
                type(scheduler_output),
                scheduled_new_reqs=[],
                scheduled_cached_reqs=CachedRequestData.make_empty(),
                num_scheduled_tokens={},
                total_num_scheduled_tokens=0,
                scheduled_spec_decode_tokens={},
                scheduled_encoder_inputs={},
                num_common_prefix_blocks=[0] * num_groups,
                finished_req_ids=set(num_scheduled_tokens),
                free_encoder_mm_hashes=[],
                kv_connector_metadata=None,
                structured_output_request_ids={},
                grammar_bitmask=None,
            )
            try:
                output = self.execute_model(scheduler_output)
                if hasattr(self, "sample_tokens"):
                    if output is None:  # TODO: make this default when vllm <= 0.11 is outdated
                        self.sample_tokens(None)
            except BaseException as calibration_error:
                _cleanup_calibration_requests(self, cleanup_output, calibration_error)
                raise

            _cleanup_calibration_requests(self, cleanup_output, calibration_error=None)

    return calibrate_loop


def update_kv_cfg_for_mla(model: torch.nn.Module, kv_quant_cfg: list) -> list:
    """Update KV cache quantization config for MLA models.

    MLA uses `kv_c_bmm_quantizer` (compressed KV) and `k_pe_bmm_quantizer` (RoPE key) instead of
    separate `k_bmm_quantizer` and `v_bmm_quantizer`. This function copies the format of the first
    `*[kv]_bmm_quantizer` entry to them; `k_pe` is skipped for NoPE models (no RoPE key).
    """
    mla_layers = [
        m
        for m in model.modules()
        if VllmMLAAttention is not None and isinstance(m, VllmMLAAttention)
    ]
    if not mla_layers:
        return kv_quant_cfg

    kv_entries = [
        e
        for e in kv_quant_cfg
        if isinstance(e, dict) and e.get("quantizer_name") == "*[kv]_bmm_quantizer"
    ]
    if not kv_entries:
        warnings.warn(
            "MLA detected, but the KV-cache config has no '*[kv]_bmm_quantizer' entry, so the MLA "
            "KV cache stays unquantized."
        )
        return kv_quant_cfg
    if any(isinstance(e.get("cfg"), dict) and e["cfg"].get("bias") for e in kv_entries):
        warnings.warn("The affine KV-cache bias is not applied to the MLA KV cache.")

    kv_config = kv_entries[0].get("cfg", {})
    names = ["*kv_c_bmm_quantizer"]
    if any(getattr(m, "qk_rope_head_dim", 1) for m in mla_layers):
        names.append("*k_pe_bmm_quantizer")
    kv_quant_cfg.extend(
        {"quantizer_name": name, "cfg": kv_config, "enable": True} for name in names
    )
    print(f"MLA detected: added {' and '.join(names)} config")

    return kv_quant_cfg


def get_quant_config(quant_config: dict[str, Any], model: Any) -> dict[str, Any]:
    """Resolve and merge model and KV-cache quantization configuration."""
    import copy

    if quant_config["recipe_path"] and (quant_config["quant_cfg"] or quant_config["kv_quant_cfg"]):
        raise ValueError(
            "recipe_path and quant_cfg/kv_quant_cfg are mutually exclusive -- the recipe file "
            "already carries the quant_cfg. Set only one."
        )

    if quant_config["recipe_path"]:
        recipe_path = Path(quant_config["recipe_path"])
        raw_recipe = yaml.safe_load(recipe_path.read_text()) if recipe_path.is_file() else None
        if isinstance(raw_recipe, dict) and raw_recipe.get("format") == QUANTIZER_RECIPE_FORMAT:
            # Versioned per-quantizer recipe, e.g. written by Megatron-Bridge's HF export.
            if raw_recipe.get("version") != QUANTIZER_RECIPE_VERSION:
                raise ValueError(
                    f"Unsupported {QUANTIZER_RECIPE_FORMAT} version {raw_recipe.get('version')!r}; "
                    f"expected {QUANTIZER_RECIPE_VERSION}"
                )
            raw_recipe = raw_recipe.get("quantizers")
            if not (
                isinstance(raw_recipe, dict)
                and raw_recipe
                and all(isinstance(name, str) and "_quantizer" in name for name in raw_recipe)
            ):
                raise ValueError(
                    f"'quantizers' of {recipe_path} must map quantizer names to states"
                )
        if (
            isinstance(raw_recipe, dict)
            and raw_recipe
            and all(isinstance(name, str) and "_quantizer" in name for name in raw_recipe)
        ):
            # Defer the serve dependency so standalone PTQ imports work.
            from vllm_reload_utils import quantizer_recipe_to_quant_cfg

            quant_cfg = quantizer_recipe_to_quant_cfg(raw_recipe, model)
        else:
            recipe = load_recipe(recipe_path)
            assert isinstance(recipe, ModelOptPTQRecipe), (
                f"Expected PTQ recipe, but got {type(recipe).__name__} from {quant_config['recipe_path']}"
            )
            quant_cfg = recipe.quantize
    else:
        quant_cfg = (
            copy.deepcopy(getattr(mtq, quant_config["quant_cfg"]))
            if quant_config["quant_cfg"]
            else {}
        )
        quant_kv_cfg = (
            copy.deepcopy(getattr(mtq, quant_config["kv_quant_cfg"]))
            if quant_config["kv_quant_cfg"]
            else {}
        )

        # Check if model has MLA and update KV config accordingly
        if quant_kv_cfg:
            quant_kv_cfg["quant_cfg"] = update_kv_cfg_for_mla(model, quant_kv_cfg["quant_cfg"])

        if quant_kv_cfg:
            quant_cfg = mtq.utils.update_quant_cfg_with_kv_cache_quant(
                quant_cfg, quant_kv_cfg["quant_cfg"]
            )

    return quant_cfg
