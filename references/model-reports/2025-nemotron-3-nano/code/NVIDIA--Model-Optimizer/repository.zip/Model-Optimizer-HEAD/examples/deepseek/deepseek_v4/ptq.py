# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""DeepSeek-V4 PTQ — NVFP4 on the routed experts only, everything else native.

Design notes (in contrast to ``examples/deepseek/deepseek_v3/ptq.py`` which covers V3):

  * We do **not** register Quant wrappers against DeepSeek-V4's ``Linear`` /
    ``ColumnParallelLinear`` / ``RowParallelLinear`` classes. Wrapping those
    globally would force every linear (attention projections, gate, shared
    expert, lm_head) through a BF16 dequant + ``F.linear`` path with
    pass-through quantizers attached — that changes the compute kernels for
    layers the user explicitly asked to leave untouched.

  * Instead we register a wrapper **only** against the routed-expert module
    (``deekseep_v4_model.Expert``). That wrapper installs per-weight and per-
    input ``TensorQuantizer`` pairs for ``w1``, ``w2``, ``w3`` and redefines
    ``forward`` to dequantize each MXFP4-packed expert weight to BF16 on the
    fly (via ``MXFP4QTensor.dequantize``) before the ``F.linear`` call
    that the quantizers hook into.

  * The shared expert (``MoE.shared_experts``) is also an ``Expert`` instance,
    so it gets the wrapper too — but we disable its quantizers by config
    pattern (``*shared_experts*``) so no amax gets collected and its output
    remains numerically equivalent to the un-wrapped path. (It still pays the
    BF16 dequant cost during calibration; the savings show up at inference
    time where shared_experts' weights on disk are unchanged and downstream
    inference uses the native FP4/FP8 GEMMs.)

  * Router gate weights, attention, dense projections, lm_head, embeddings —
    untouched. Their forward path uses V4's native ``linear()`` dispatch
    which routes to ``fp4_gemm`` / ``fp8_gemm`` / ``F.linear`` based on the
    weight dtype on disk.

Usage (single node, 4 GPUs, MP=4):

    torchrun --nproc-per-node 4 --master_port 12346 deepseek_v4/ptq.py \\
        --model_path  /path/to/DeepSeek-V4-Pro-mp4-mxfp4 \\
        --config      /path/to/DeepSeek-V4-Pro/inference/config.json \\
        --output_path /path/to/amax_dump

For MP=8 across two nodes use torchrun's ``--nnodes=2 --node_rank=<i>
--master_addr=<ip>`` flags.

Calibration settings
--------------------

When the amax dumped here is later consumed by ``quantize_to_nvfp4.py
--cast_mxfp4_to_nvfp4``, the expert weights are a lossless bit-cast, so the
activation amax (``input_scale``) is the only calibrated quantity that survives:

  * ``--calib_seq`` sets the tokenizer truncation cap, which decides how much of a
    long document survives. Raising it is **not** free on this path: the whole
    corpus is tokenized in one ``padding=True`` call, so every row is padded to
    the longest surviving sample, and ``calibrate_loop`` passes only ``input_ids``
    -- so those pad tokens participate in calibration. Choose it from the context
    length the activations must cover, and re-validate rather than assuming
    higher is better.

  * ModelOpt's ``mse_calibrate`` has no effect on this path — it tunes weight
    quantizers only, and the MXFP4->NVFP4 cast overwrites ``weight_scale``
    afterwards.
"""

import argparse
import copy
import fnmatch
import inspect
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any

import torch
import torch.distributed as dist
import torch.nn.functional as F
from safetensors.torch import load_model
from transformers import AutoTokenizer

import modelopt.torch.quantization as mtq
from modelopt.recipe import load_recipe
from modelopt.torch.quantization.nn import TensorQuantizer
from modelopt.torch.quantization.qtensor.mxfp4_tensor import MXFP4QTensor
from modelopt.torch.utils.dataset_utils import get_dataset_dataloader
from modelopt.torch.utils.distributed import ParallelState

_DEFAULT_V4_DIR = Path("DeepSeek-V4-Pro/inference")


def _inject_v4_module(v4_inference_dir: Path) -> None:
    assert v4_inference_dir.exists(), (
        f"DeepSeek-V4 inference dir not found at {v4_inference_dir}; pass --dsv4_inference_dir"
    )
    sys.path.insert(0, str(v4_inference_dir))


# Populated by ``install_quant_registry`` once DS-V4's ``model`` is importable.
deekseep_v4_model: Any = None


_DS_FP8_BLOCK_SIZES = (32, 128)


def _ds_fp8_block_size(weight: torch.Tensor, scale: torch.Tensor) -> int:
    """Detect the FP8 quantization block size used by the loaded DeepSeek V4 module.

    Prefers an explicit module attribute (``fp8_block_size`` on V4.1-Flash,
    ``block_size`` on V4-Pro), falling back to the one known DS-V4 block size
    whose scale shape matches the tensors. Shapes alone cannot name a block size:
    once a block is partial, a whole range of sizes gives the same scale shape.
    """
    for attr in ("fp8_block_size", "block_size"):
        blk = getattr(deekseep_v4_model, attr, None)
        if isinstance(blk, int) and blk > 0 and scale.shape == _fp8_scale_shape(weight, blk):
            return blk
    fits = [b for b in _DS_FP8_BLOCK_SIZES if scale.shape == _fp8_scale_shape(weight, b)]
    assert len(fits) == 1, (
        f"cannot infer FP8 block size from weight {tuple(weight.shape)} "
        f"and scale {tuple(scale.shape)}: known block sizes {_DS_FP8_BLOCK_SIZES} "
        f"matching these shapes: {fits}"
    )
    return fits[0]


def _fp8_scale_shape(weight: torch.Tensor, block: int) -> tuple[int, int]:
    """Ceil-div, matching DS-V4 ``Linear.__init__``'s scale allocation."""
    m, n = weight.shape
    return ((m + block - 1) // block, (n + block - 1) // block)


def _fp8_ue8m0_blockwise_to_bf16(
    weight: torch.Tensor, scale: torch.Tensor, block: int = 128
) -> torch.Tensor:
    """FP8 E4M3 × UE8M0 ``block``x``block`` block-scale → BF16 (V4 native FP8 layout).

    Same math as ``scripts/convert_dsv4_to_bf16.py``'s helper; ModelOpt's
    triton ``weight_dequant`` expects FP32 scales and cannot consume UE8M0
    directly, so we dequant inline.
    """
    m, n = weight.shape
    expected = _fp8_scale_shape(weight, block)
    assert scale.shape == expected, (
        f"FP8 scale shape {tuple(scale.shape)} != expected {expected} for "
        f"weight {(m, n)} at block size {block}"
    )
    exp = scale.contiguous().view(torch.uint8).to(torch.int32) - 127
    exp = exp.repeat_interleave(block, 0).repeat_interleave(block, 1)[:m, :n]
    return torch.ldexp(weight.to(torch.float32), exp).to(torch.bfloat16)


def _dequantize_linear_weight(linear_module) -> torch.Tensor:
    """Materialize a BF16 copy of a DS-V4 ``Linear``'s weight.

    Three on-disk formats are possible here. Both routed and shared experts
    are wrapped (both are ``Expert`` instances); their weight dtype depends
    on V4's global default (``set_dtype`` typically sets it to fp8) and on
    the optional ``dtype=`` kwarg passed to ``Expert.__init__``:
      * ``float4_e2m1fn_x2`` + UE8M0 1x32 scale   → MXFP4 dequant.
      * ``float8_e4m3fn``    + UE8M0 NxN block scale → FP8 dequant (inline).
      * any float dtype without a ``.scale``       → passthrough (already BF16).
    """
    w = linear_module.weight
    if w.dtype == torch.float4_e2m1fn_x2:
        block_size = 32
        packed = w.contiguous().view(torch.uint8)
        scale = w.scale.contiguous().view(torch.uint8)
        original_shape = torch.Size((*packed.shape[:-1], packed.shape[-1] * 2))
        assert packed.shape[:-1] == scale.shape[:-1] and (
            2 * packed.shape[-1] == scale.shape[-1] * block_size
        ), f"Incompatible MXFP4 shapes: weight {tuple(packed.shape)} vs scale {tuple(scale.shape)}"
        return MXFP4QTensor(original_shape, torch.bfloat16, packed).dequantize(
            dtype=torch.bfloat16,
            scale=scale,
            block_sizes=[block_size],
        )
    if w.dtype == torch.float8_e4m3fn:
        return _fp8_ue8m0_blockwise_to_bf16(w, w.scale, block=_ds_fp8_block_size(w, w.scale))
    return w


def install_quant_registry() -> None:
    """Import DS-V4's ``model`` module and register minimal Quant wrappers."""
    global deekseep_v4_model
    import model as _m

    deekseep_v4_model = _m

    class QuantExpert(deekseep_v4_model.Expert):
        """Routed expert with per-``w{1,2,3}`` input & weight quantizers.

        Forward mirrors ``Expert.forward`` (SwiGLU with optional clipping and
        optional per-token weight), but each ``w{1,2,3}`` call goes through
        our ``_qlinear`` which dequantizes on the fly and exposes the hook
        points the quantizers need.

        ``TensorQuantizer`` instances are installed in ``_setup`` (not
        ``__init__``) because ModelOpt's ``DynamicModule.convert`` patches
        ``__class__`` in place and calls ``_setup(**setup_kwargs)`` — it does
        not invoke ``__init__``.
        """

        def _setup(self):
            self.w1_input_quantizer = TensorQuantizer()
            self.w1_weight_quantizer = TensorQuantizer()
            self.w2_input_quantizer = TensorQuantizer()
            self.w2_weight_quantizer = TensorQuantizer()
            self.w3_input_quantizer = TensorQuantizer()
            self.w3_weight_quantizer = TensorQuantizer()
            # Tell modelopts post-calibration amax sync not to do any
            # cross-rank all_reduce on these quantizers. Routed experts
            # are sharded across ranks (rank i has experts i*n_local ..
            # (i+1)*n_local-1), so the same quantizer path exists on
            # only one rank. The default parallel_state treats all ranks
            # as one group, which deadlocks when some ranks have amax
            # populated (routed) and others do not.
            self._parallel_state = ParallelState(
                data_parallel_group=-1,
                tensor_parallel_group=-1,
            )

        @staticmethod
        def _qlinear(
            x: torch.Tensor,
            linear_module,
            input_quantizer: TensorQuantizer,
            weight_quantizer: TensorQuantizer,
        ) -> torch.Tensor:
            w = _dequantize_linear_weight(linear_module)
            x = input_quantizer(x)
            w = weight_quantizer(w)
            return F.linear(x, w, linear_module.bias)

        def forward(self, x, weights=None):
            dtype = x.dtype
            gate = self._qlinear(
                x, self.w1, self.w1_input_quantizer, self.w1_weight_quantizer
            ).float()
            up = self._qlinear(
                x, self.w3, self.w3_input_quantizer, self.w3_weight_quantizer
            ).float()
            if self.swiglu_limit > 0:
                up = torch.clamp(up, min=-self.swiglu_limit, max=self.swiglu_limit)
                gate = torch.clamp(gate, max=self.swiglu_limit)
            y = F.silu(gate) * up
            if weights is not None:
                y = weights * y
            return self._qlinear(
                y.to(dtype), self.w2, self.w2_input_quantizer, self.w2_weight_quantizer
            )

    mtq.register(original_cls=deekseep_v4_model.Expert, quantized_cls=QuantExpert)


def load_deepseek_v4(
    model_config: str,
    model_path: str,
    batch_size: int,
    dummy_weights: bool = False,
    tokenizer=None,
):
    world_size = int(os.getenv("WORLD_SIZE", "1"))
    rank = int(os.getenv("RANK", "0"))
    local_rank = int(os.getenv("LOCAL_RANK", "0"))
    if world_size > 1:
        dist.init_process_group("nccl")
        torch.cuda.set_device(local_rank)
    torch.set_default_dtype(torch.bfloat16)

    with open(model_config) as f:
        margs = deekseep_v4_model.ModelArgs(**json.load(f))
        margs.max_batch_size = max(batch_size, margs.max_batch_size)
    with torch.device("cuda"):
        if "tokenizer" in inspect.signature(deekseep_v4_model.Transformer.__init__).parameters:
            assert tokenizer is not None, (
                "this DS-V4 release's Transformer requires a tokenizer "
                "(engram hash tables); load it before the model"
            )
            model = deekseep_v4_model.Transformer(margs, tokenizer)
        else:
            model = deekseep_v4_model.Transformer(margs)

    if dummy_weights:
        print(
            f"[rank {rank}] --dummy-weights: skipping load_model; params remain at torch.empty values"
        )
    else:
        ckpt = os.path.join(model_path, f"model{rank}-mp{world_size}.safetensors")
        print(f"[rank {rank}] loading {ckpt}")
        missing, unexpected = load_model(model, ckpt, strict=False)
        if missing or unexpected:
            raise RuntimeError(
                f"checkpoint key mismatch while loading {ckpt}: "
                f"missing={missing}, unexpected={unexpected}"
            )
        print(f"[rank {rank}] loaded")
    # Match generate.py: default device to this rank's CUDA so that any
    # torch.empty(...) / torch.zeros(...) inside the V4 forward (TileLang
    # kernels verify device_type==cuda and device_id==local_rank on their
    # inputs) lands on the right GPU.
    torch.set_default_device("cuda")
    return model


_PUBLISHED_RECIPE = "models/deepseek-ai/DeepSeek-V4-Pro-0813/ptq/nvfp4_experts_only"


_MTP_PROBE = "mtp.0.ffn.experts.0.w1_weight_quantizer"


def _effective_enable(quant_cfg, name: str) -> bool:
    """Whether ``name`` ends up enabled; mtq applies rules in order, so later ones win."""
    enabled = False
    for entry in quant_cfg:
        if isinstance(entry, dict) and "quantizer_name" in entry:
            if fnmatch.fnmatch(name, entry["quantizer_name"]):
                enabled = entry.get("enable", True) is True
    return enabled


def _quant_cfg_from_recipe(recipe_path: str) -> dict:
    """Load a ModelOpt recipe and return an ``mtq.quantize`` config.

    ``mtq.quantize`` accepts ``algorithm`` as a string or as a dict keyed on
    ``method``, which is the shape a recipe yields, so no translation is needed.

    The recipe is validated against what the rest of this pipeline can actually
    export. ``save_amax_and_quant_config`` persists only routed-expert quantizer
    state and writes ``quantized_layers_manifest.json`` hardcoded to
    ``NVFP4_W4A4``/``num_bits [2, 1]``/``block_size 16``/``scale_bits [4, 3]``,
    and ``quantize_to_nvfp4.py`` re-derives expert paths itself and emits E4M3
    block scales unconditionally. A recipe that enables anything else, or asks
    for a different numeric format, would silently drop quantizers and describe
    the result with a manifest that does not match the amax it ships beside.
    Mirrors the guard in ``examples/kimi/kimi_k3/quantize_to_nvfp4.py``.
    """
    recipe = load_recipe(recipe_path)
    quantize = getattr(recipe, "quantize", None)
    if quantize is None:
        raise ValueError(f"recipe {recipe_path!r} has no 'quantize' section; expected a PTQ recipe")
    cfg = quantize.model_dump()

    algo = cfg.get("algorithm")
    method = algo.get("method") if isinstance(algo, dict) else algo
    if method != "max":
        raise ValueError(f"recipe must use the 'max' calibration algorithm, got {method!r}")

    enabled_experts = False
    for entry in cfg.get("quant_cfg", []):
        if not isinstance(entry, dict) or entry.get("enable") is not True:
            continue
        name = entry.get("quantizer_name", "")
        if "ffn.experts." not in name:
            raise ValueError(
                f"recipe enables {name!r}, but this pipeline exports only routed-expert "
                "quantizers (*ffn.experts.*); it would be dropped from the amax dump "
                "and the manifest without any error"
            )
        qcfg = entry.get("cfg") or {}
        if not isinstance(qcfg, dict):
            raise ValueError(
                f"recipe entry {name!r} has a non-dict 'cfg' ({type(qcfg).__name__}); "
                "this pipeline supports only a single NVFP4 config per quantizer"
            )
        block_sizes = qcfg.get("block_sizes") or {}
        if (
            tuple(qcfg.get("num_bits") or ()) != (2, 1)
            or block_sizes.get(-1) != 16
            or block_sizes.get("type") != "dynamic"
            or tuple(block_sizes.get("scale_bits") or ()) != (4, 3)
        ):
            raise ValueError(
                f"recipe entry {name!r} must be block-16 NVFP4 (num_bits (2, 1), "
                f"block_sizes[-1] 16, type 'dynamic', scale_bits (4, 3)) to match "
                f"the exported manifest, got num_bits={qcfg.get('num_bits')!r} "
                f"block_sizes={block_sizes!r}"
            )
        enabled_experts = True

    if not enabled_experts:
        raise ValueError("recipe enables no routed-expert quantizers (*ffn.experts.*)")

    # The scope check above is a substring test, so a pattern such as
    # *mtp.*ffn.experts.* satisfies it. MTP experts match save_amax's
    # \.experts\.\d+\.w[123]_ regex too, so resolve the rules the way mtq applies
    # them (in order, last match wins) and reject a recipe that leaves them on.
    if _effective_enable(cfg.get("quant_cfg", []), _MTP_PROBE):
        raise ValueError(
            f"recipe enables MTP quantizers (matched {_MTP_PROBE!r}); this pipeline "
            "leaves the MTP/DSpark block in its source format"
        )
    return cfg


def _build_nvfp4_experts_cfg() -> dict:
    """Quant config: NVFP4 weight + NVFP4 input, routed experts only.

    Routed experts live at ``model.layers.<i>.ffn.experts.<j>.w{1,2,3}``. The
    shared expert lives at ``model.layers.<i>.ffn.shared_experts.w{1,2,3}``
    — same ``Expert`` class, different MoE attribute name — and we disable
    its quantizers explicitly.
    """
    nvfp4 = {
        "num_bits": (2, 1),
        "block_sizes": {-1: 16, "type": "dynamic", "scale_bits": (4, 3)},
    }
    return {
        "quant_cfg": [
            # Start with everything disabled so non-Expert modules are never
            # touched — since we only registered Quant wrappers for Expert
            # and MoE, there are no other quantizer instances anyway, but
            # keep the explicit baseline as a safety rail.
            {"quantizer_name": "*input_quantizer", "enable": False},
            {"quantizer_name": "*weight_quantizer", "enable": False},
            # Re-enable only routed experts (``ffn.experts.<idx>.w*``).
            {
                "quantizer_name": "*ffn.experts.*.w*_weight_quantizer",
                "enable": True,
                "cfg": copy.deepcopy(nvfp4),
            },
            {
                "quantizer_name": "*ffn.experts.*.w*_input_quantizer",
                "enable": True,
                "cfg": copy.deepcopy(nvfp4),
            },
            # Belt-and-suspenders: shared expert lives under the same Expert
            # class; make sure it's disabled even if patterns above matched.
            {"quantizer_name": "*shared_experts*", "enable": False},
            # MTP is a speculative decoding block. Leave it in the source
            # format unless a dedicated MTP quantization path is added.
            {"quantizer_name": "*mtp.*", "enable": False},
        ],
        "algorithm": "max",
    }


def ptq(
    model,
    tokenizer,
    batch_size: int,
    calib_size: int,
    calib_datasets: list[str],
    calib_seq: int = 512,
    recipe: str | None = None,
):
    world_size = int(os.getenv("WORLD_SIZE", "1"))
    rank = int(os.getenv("RANK", "0"))

    def _trace(msg):
        print(f"[rank {rank}] {msg}", flush=True)

    _trace("ptq() entered")
    device = next(model.parameters()).device
    _trace(f"device={device}, building calib dataloader")
    calib_dataset = get_dataset_dataloader(
        dataset_name=calib_datasets,
        tokenizer=tokenizer,
        batch_size=batch_size,
        num_samples=[calib_size] * len(calib_datasets),
        max_sample_length=calib_seq,
        device=device,
    )
    _trace("calib dataloader ready")

    def calibrate_loop(model):
        _trace("calibrate_loop: entering")
        t_loop = time.time()
        for i, data in enumerate(calib_dataset):
            t0 = time.time()
            model(data["input_ids"])
            dt = time.time() - t0
            _trace(f"calibrate_loop: batch {i} shape={tuple(data['input_ids'].shape)} dt={dt:.2f}s")
        _trace(f"calibrate_loop: exited after {time.time() - t_loop:.1f}s")

    if world_size > 1:
        _trace("pre-calib barrier")
        dist.barrier()
        _trace("pre-calib barrier done")

    mtq_cfg = _quant_cfg_from_recipe(recipe) if recipe else _build_nvfp4_experts_cfg()
    _trace(f"quant config from {'recipe' if recipe else 'built-in default'}")
    _trace("calling mtq.quantize")
    model = mtq.quantize(model, mtq_cfg, calibrate_loop)
    _trace("mtq.quantize returned")
    if rank == 0:
        mtq.print_quant_summary(model)
    _trace("ptq() returning")
    return model


def save_amax_and_quant_config(model, output_path: str):
    """Save routed-expert quantizer state + a manifest enumerating the
    quantized layer paths. The manifest is built by scanning the model for
    ``TensorQuantizer`` instances whose path contains ``.experts.<n>.w``
    (i.e. routed-expert quantizers only, excluding ``shared_experts``); we do
    *not* rely on ``modelopt.torch.export.quant_utils.get_quant_config``
    because its introspection doesn't see weights stored on nested
    submodules — ``QuantExpert``'s ``w{1,2,3}`` are submodules of the
    container, not direct parameters. The manifest is a descriptive record of
    what was calibrated: ``quantize_to_nvfp4.py`` does not read it, it
    re-derives the expert tensor paths from the source checkpoint itself.
    """

    def _trace(msg):
        print(f"[rank {os.getenv('RANK', '0')}] SAVE: {msg}", flush=True)

    _trace("entered")
    world_size = int(os.getenv("WORLD_SIZE", "1"))
    rank = int(os.getenv("RANK", "0"))
    if rank == 0:
        os.makedirs(output_path, exist_ok=True)
    if world_size > 1:
        _trace("pre-save barrier")
        dist.barrier()
        _trace("pre-save barrier done")

    # Dump only routed-expert quantizer state (skip any stray shared_experts
    # or other quantizer state attached by mtq's pattern matcher).
    _trace("building filtered state dict")
    expert_re = re.compile(r"\.experts\.\d+\.w[123]_")
    full_sd = model.state_dict()
    _trace(f"full state_dict size={len(full_sd)}")
    state = {
        k: v for k, v in full_sd.items() if expert_re.search(k) and ("amax" in k or "quant" in k)
    }
    _trace(f"filtered state size={len(state)}, saving")
    torch.save(state, os.path.join(output_path, f"amax_dict_rank{rank}-mp{world_size}.pt"))
    _trace("torch.save done")

    # Enumerate quantized layer tensor paths so the export script knows
    # exactly which weights to replace with NVFP4 packed + scales.
    quantized_layers: set[str] = set()
    for name, module in model.named_modules():
        if isinstance(module, TensorQuantizer) and module.is_enabled and expert_re.search(name):
            # Strip trailing ``._weight_quantizer`` / ``._input_quantizer`` and
            # the ``w1_/w2_/w3_`` prefix to get the DS-native Linear path.
            # e.g. ``layers.0.ffn.experts.5.w1_weight_quantizer`` →
            #      ``layers.0.ffn.experts.5.w1``.
            base = name.rsplit(".", 1)[0]
            proj = name.rsplit(".", 1)[1].split("_")[0]  # "w1"|"w2"|"w3"
            quantized_layers.add(f"{base}.{proj}")

    manifest = {
        "quantization_format": "NVFP4_W4A4",
        "quantized_layers": sorted(quantized_layers),
        "world_size": world_size,
        "layer_cfg": {
            "num_bits": [2, 1],
            "block_size": 16,
            "scale_bits": [4, 3],
        },
    }
    if world_size > 1:
        all_manifests: list = [None] * world_size
        dist.all_gather_object(all_manifests, manifest)
    else:
        all_manifests = [manifest]
    if rank == 0:
        merged: set[str] = set()
        for m in all_manifests:
            assert m is not None
            merged.update(m["quantized_layers"])
        manifest["quantized_layers"] = sorted(merged)
        with open(os.path.join(output_path, "quantized_layers_manifest.json"), "w") as f:
            json.dump(manifest, f, indent=2)


def main():
    p = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    p.add_argument("--model_path", required=True, help="MP-sharded DS-V4 checkpoint dir")
    p.add_argument("--config", required=True, help="DS-V4 ModelArgs JSON")
    p.add_argument(
        "--dsv4_inference_dir",
        type=Path,
        default=_DEFAULT_V4_DIR,
        help="dir containing DS-V4 inference/ model.py + kernel.py",
    )
    p.add_argument(
        "--output_path",
        required=True,
        help="where to dump amax files and quantized_layers_manifest.json",
    )
    p.add_argument("--batch_size", type=int, default=4)
    p.add_argument(
        "--recipe",
        default=None,
        help=(
            "ModelOpt recipe describing the quant config, loaded by path relative to "
            f"modelopt_recipes/ (published: {_PUBLISHED_RECIPE}). Defaults to the "
            "built-in routed-experts-only NVFP4 config, which this recipe mirrors."
        ),
    )
    p.add_argument("--calib_size", type=int, default=64)
    p.add_argument(
        "--calib_seq",
        type=int,
        default=512,
        help=(
            "calibration sequence truncation cap (max_sample_length). Longer documents are "
            "truncated to this; because the corpus is tokenized in one padded call, shorter "
            "ones are padded up to it. Re-validate when changing it."
        ),
    )
    p.add_argument(
        "--calib_dataset",
        dest="calib_datasets",
        nargs="+",
        default=["cnn_dailymail", "nemotron-post-training-dataset-v2"],
        metavar="NAME",
        help=(
            "calibration dataset names accepted by "
            "modelopt.torch.utils.dataset_utils.get_dataset_dataloader"
        ),
    )
    p.add_argument("--trust_remote_code", action="store_true")
    p.add_argument(
        "--dummy_weights",
        action="store_true",
        help="skip load_model (fast iteration on wiring; weights are uninitialized)",
    )
    p.add_argument(
        "--run_generate",
        type=str,
        default=None,
        help="after calibration, generate from this prompt string (rank 0 prints) "
        "to smoke-test that the quantized forward produces coherent text.",
    )
    p.add_argument("--max_new_tokens", type=int, default=16)
    args = p.parse_args()

    _inject_v4_module(args.dsv4_inference_dir)
    install_quant_registry()
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path, trust_remote_code=args.trust_remote_code
    )
    model = load_deepseek_v4(
        args.config,
        args.model_path,
        args.batch_size,
        dummy_weights=args.dummy_weights,
        tokenizer=tokenizer,
    )
    model = ptq(
        model,
        tokenizer,
        args.batch_size,
        args.calib_size,
        args.calib_datasets,
        args.calib_seq,
        args.recipe,
    )
    save_amax_and_quant_config(model, args.output_path)

    if args.run_generate is not None:
        _run_quantized_generate(model, tokenizer, args.run_generate, args.max_new_tokens)


def _run_quantized_generate(
    model, tokenizer, prompt: str, max_new_tokens: int, device: str = "cuda"
):
    """Smoke-test: generate tokens from a prompt through the calibrated+quantized
    model. If the output decodes to coherent text, the quantized forward works
    end-to-end."""
    rank = int(os.getenv("RANK", "0"))

    input_ids = tokenizer(prompt, return_tensors="pt").input_ids.to(device)
    tokens = torch.full(
        (1, input_ids.shape[1] + max_new_tokens), -1, dtype=torch.long, device=device
    )
    tokens[0, : input_ids.shape[1]] = input_ids[0]
    prev_pos = 0
    with torch.inference_mode():
        for cur_pos in range(input_ids.shape[1], tokens.shape[1]):
            out = model.forward(tokens[:, prev_pos:cur_pos], prev_pos)
            logits = out[1] if isinstance(out, tuple) else out
            next_token = logits.argmax(dim=-1)
            tokens[:, cur_pos] = next_token
            prev_pos = cur_pos
    if rank == 0:
        out = tokens[0, input_ids.shape[1] :].tolist()
        text = tokenizer.decode(out, skip_special_tokens=False)
        print(f"\n[generate] prompt: {prompt!r}\n[generate] completion: {text!r}\n", flush=True)


if __name__ == "__main__":
    main()
