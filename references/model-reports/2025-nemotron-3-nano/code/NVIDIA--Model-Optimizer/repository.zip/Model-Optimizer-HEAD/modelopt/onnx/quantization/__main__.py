# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Command-line entrypoint for ONNX PTQ."""

import argparse
import json
import os

import numpy as np

from modelopt.onnx.quantization.autotune.utils import (
    MODE_PRESETS,
    StoreWithExplicitFlag,
    get_node_filter_list,
)
from modelopt.onnx.quantization.quantize import quantize

__all__ = ["main"]


def parse_input_shapes_profile(value: str) -> list[dict[str, str]]:
    """Parse input shapes profile from an inline JSON value or a JSON file path."""
    try:
        if os.path.exists(value):
            validate_file_size(value, 1024 * 1024)
            with open(value, encoding="utf-8") as profile_file:
                profile = json.load(profile_file)
        else:
            profile = json.loads(value)
    except (OSError, json.JSONDecodeError) as e:
        raise argparse.ArgumentTypeError(
            "input_shapes_profile must be a JSON file path or an inline JSON list of dictionaries"
        ) from e

    if not isinstance(profile, list) or not all(isinstance(item, dict) for item in profile):
        raise argparse.ArgumentTypeError("input_shapes_profile must be a JSON list of dictionaries")

    for item in profile:
        if not all(isinstance(key, str) and isinstance(val, str) for key, val in item.items()):
            raise argparse.ArgumentTypeError(
                "input_shapes_profile dictionaries must contain only string keys and string values"
            )

    return profile


def validate_file_size(file_path: str, max_size_bytes: int) -> None:
    """Validate that a file exists and does not exceed the maximum allowed size.

    Args:
        file_path: Path to the file to validate
        max_size_bytes: Maximum allowed file size in bytes

    Raises:
        FileNotFoundError: If the file does not exist
        ValueError: If the file exceeds the maximum allowed size
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    file_size = os.path.getsize(file_path)
    if file_size > max_size_bytes:
        max_size_gb = max_size_bytes / (1024 * 1024 * 1024)
        actual_size_gb = file_size / (1024 * 1024 * 1024)
        raise ValueError(
            f"File size validation failed: {file_path} ({actual_size_gb:.2f}GB) exceeds "
            f"maximum allowed size of {max_size_gb:.2f}GB. This limit helps prevent potential "
            f"denial-of-service attacks."
        )


def get_parser() -> argparse.ArgumentParser:
    """Get the argument parser for ONNX PTQ."""
    argparser = argparse.ArgumentParser("python -m modelopt.onnx.quantization")
    group = argparser.add_mutually_exclusive_group(required=False)
    argparser.add_argument(
        "--onnx_path", required=True, type=str, help="Input onnx model without Q/DQ nodes."
    )
    argparser.add_argument(
        "--model_id",
        required=False,
        type=str,
        help=(
            "Hugging Face model ID, local config directory, or local config.json path used "
            "to infer EP input shape profiles when --input_shapes_profile is not provided."
        ),
    )
    argparser.add_argument(
        "--input_shapes_profile",
        required=False,
        type=parse_input_shapes_profile,
        help=(
            "Input shape profile provider options as an inline JSON list or a path to a JSON file. "
            "The list must have one dictionary per --calibration_eps entry, in the same order. "
            'Example: \'[{"nv_profile_min_shapes":"input_ids:1x1",'
            '"nv_profile_opt_shapes":"input_ids:1x512",'
            '"nv_profile_max_shapes":"input_ids:1x1024"},{}]\'.'
        ),
    )
    argparser.add_argument(
        "--trust_remote_code",
        action="store_true",
        help="Allow custom code when resolving --model_id with Hugging Face transformers.",
    )
    argparser.add_argument(
        "--quantize_mode",
        type=str,
        choices=["fp8", "int8", "int4"],
        default="int8",
        help="Quantization mode for the given ONNX model.",
    )
    argparser.add_argument(
        "--calibration_method",
        type=str,
        choices=["max", "entropy", "awq_clip", "rtn_dq"],
        help=(
            "Calibration method choices for int8/fp8: {entropy (default), max}, "
            "int4: {awq_clip (default), rtn_dq}."
        ),
    )
    group.add_argument(
        "--calibration_data_path",
        type=str,
        help="Calibration data in npz/npy format. If None, random data for calibration will be used.",
    )
    group.add_argument(
        "--trust_calibration_data",
        action="store_true",
        help="If True, trust the calibration data and allow pickle deserialization.",
    )
    group.add_argument(
        "--calibration_cache_path",
        type=str,
        help="Pre-calculated activation tensor scaling factors aka calibration cache path.",
    )
    argparser.add_argument(
        "--calibration_shapes",
        type=str,
        required=False,
        help=(
            "Optional model input shapes for calibration."
            "Users should provide the shapes specifically if the model has non-batch dynamic dimensions."
            "Example input shapes spec: input0:1x3x256x256,input1:1x3x128x128"
        ),
    )
    argparser.add_argument(
        "--calibration_eps",
        type=str,
        default=["cpu", "cuda:0", "trt"],
        nargs="+",
        help=(
            "Priority order for the execution providers (EP) to calibrate the model. "
            "Any subset of ['NvTensorRtRtx', 'trt', 'cuda:x', dml:x, 'cpu'], where 'x' is "
            "the device id. For TensorRT-RTX, pass 'NvTensorRtRtx' for either backend; "
            "select the backend with --trt_rtx_backend. "
            "If a custom op is detected in the model, 'trt' will automatically be added to the EP list."
        ),
    )
    argparser.add_argument(
        "--trt_rtx_backend",
        choices=["legacy", "abi"],
        default="legacy",
        help=(
            "TensorRT-RTX implementation used with --calibration_eps NvTensorRtRtx. "
            "The legacy backend uses TensorRT-RTX libraries on PATH; "
            "the ABI backend uses the installed standalone EP plugin."
        ),
    )
    argparser.add_argument(
        "--override_shapes",
        type=str,
        required=False,
        help=(
            "Override model input shapes with static shapes."
            "Example input shapes spec: input0:1x3x256x256,input1:1x3x128x128"
        ),
    )
    argparser.add_argument(
        "--op_types_to_quantize",
        type=str,
        nargs="+",
        help="A space-separated list of node types to quantize.",
    )
    argparser.add_argument(
        "--op_types_to_exclude",
        type=str,
        nargs="+",
        help="A space-separated list of node types to exclude from quantization.",
    )
    argparser.add_argument(
        "--op_types_to_exclude_fp16",
        type=str,
        nargs="+",
        help=(
            "A space-separated list of node types to exclude from FP16/BF16 conversion. "
            "Relevant when --high_precision_dtype is 'fp16' or 'bf16'."
        ),
    )
    argparser.add_argument(
        "--nodes_to_quantize",
        type=str,
        nargs="+",
        help="A space-separated list of node names to quantize. Regular expressions are supported.",
    )
    argparser.add_argument(
        "--nodes_to_exclude",
        type=str,
        nargs="+",
        help="A space-separated list of node names to exclude from quantization. Regular expressions are supported.",
    )
    argparser.add_argument(
        "--use_external_data_format",
        action="store_true",
        help=(
            "If True or model size is larger than 2GB, "
            "<MODEL_NAME>.onnx_data will be used to write weights and constants."
        ),
    )
    argparser.add_argument(
        "--keep_intermediate_files",
        action="store_true",
        help=(
            "If True, keep the files generated during the ONNX models' conversion/calibration. "
            "Otherwise, only the converted ONNX file is kept for the user."
        ),
    )
    argparser.add_argument(
        "--output_path",
        type=str,
        help=(
            "Output filename to save the converted ONNX model. If None, save it in the same dir as "
            "the original ONNX model with an appropriate suffix."
        ),
    )
    argparser.add_argument(
        "--log_level",
        type=str,
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "debug", "info", "warning", "error"],
        default="INFO",
        help="Set the logging level for the quantization process.",
    )
    argparser.add_argument(
        "--log_file",
        type=str,
        default=None,
        help="Path to the log file for the quantization process.",
    )
    argparser.add_argument(
        "--trt_plugins",
        type=str,
        default=None,
        nargs="+",
        help=(
            "A space-separated list with the custom TensorRT plugin library paths in .so format (compiled shared "
            "library). If this is not None, the TensorrtExecutionProvider is invoked, so make sure that the TensorRT "
            "libraries are in the PATH or LD_LIBRARY_PATH variables."
        ),
    )
    argparser.add_argument(
        "--trt_plugins_precision",
        type=str,
        default=None,
        nargs="+",
        help=(
            "A space-separated list indicating the precision for each custom op. "
            "Each item should have the format <op_type>:<precision> (all inputs and outputs have the same precision) "
            "or <op_type>:[<inp1_precision>,<inp2_precision>,...]:[<out1_precision>,<out2_precision>,...] "
            "(inputs and outputs can have different precisions), where precision can be fp32 (default), "
            "fp16, int8, or fp8. Note that int8/fp8 should be the same as the quantization mode. "
            "For example: op_type_1:fp16 op_type_2:[int8,fp32]:[int8]."
        ),
    )
    argparser.add_argument(
        "--high_precision_dtype",
        type=str,
        default="fp16",
        choices=["fp32", "fp16", "bf16"],
        help=(
            "High precision data type of the output model. If the input model is of dtype fp32, "
            "it will be converted to fp16 dtype by default."
        ),
    )
    argparser.add_argument(
        "--mha_accumulation_dtype",
        type=str,
        default="fp16",
        help=(
            "Accumulation dtype of MHA. This flag will only take effect when mha_accumulation_dtype == 'fp32' "
            "and quantize_mode == 'fp8'. One of ['fp32', 'fp16']"
        ),
    )
    argparser.add_argument(
        "--disable_mha_qdq",
        action="store_true",
        help="If True, Q/DQ will not be added to MatMuls in MHA pattern.",
    )
    argparser.add_argument(
        "--dq_only",
        action="store_true",
        help=(
            "If True, FP32/FP16 weights will be converted to INT8/FP8 weights. Q nodes will get removed from the "
            "weights and have only DQ nodes with those converted INT8/FP8 weights in the output model."
        ),
    )
    argparser.add_argument(
        "--use_zero_point",
        type=bool,
        default=False,
        help=(
            "If True, zero-point based quantization will be used - currently, applicable for awq_lite algorithm."
        ),
    )
    argparser.add_argument(
        "--passes",
        type=str,
        choices=["concat_elimination"],
        default=["concat_elimination"],
        nargs="+",
        help=(
            "A space-separated list of optimization passes name, if set, appropriate pre/post-processing passes will "
            "be invoked."
        ),
    )
    argparser.add_argument(
        "--simplify",
        action="store_true",
        help="If True, the given ONNX model will be simplified before quantization is performed.",
    )
    argparser.add_argument(
        "--calibrate_per_node",
        action="store_true",
        help=(
            "If set, performs calibration per node instead of running inference over the entire network. "
            "Useful for reducing memory consumption during large model inference."
        ),
    )
    argparser.add_argument(
        "--direct_io_types",
        action="store_true",
        help=(
            "If True, the I/O types in the quantized ONNX model will be modified to be lower precision whenever "
            "possible. Else, they will match the I/O types in the given ONNX model. "
            "The currently supported precisions are {fp16, int8, fp8}."
        ),
    )
    argparser.add_argument(
        "--opset",
        type=int,
        help=(
            "Target ONNX opset version for the quantized model. If not specified, uses default minimum opset "
            "(19 for fp16 scales support, 21 for int4, 23 for nvfp4). The opset may be automatically increased "
            "if certain operations require a higher version."
        ),
    )
    argparser.add_argument(
        "--target_dla",
        action="store_true",
        help=(
            "Expand INT8 Q/DQ coverage for DLA and preserve scalar operator constants. "
            "TensorRT 10.7 and earlier require the separate Q/DQ Translator workflow. "
            "DLA deployment is unsupported after 10.7 through 11.3. TensorRT 11.4+ supports "
            "direct Q/DQ deployment with strongly typed DLA support enabled. "
            "Requires a compatible DLA platform and package. Only affects INT8; may reduce accuracy."
        ),
    )
    argparser.add_argument(
        "--autotune",
        nargs="?",
        const="default",
        default=None,
        choices=["quick", "default", "extensive"],
        help=(
            "If set, enable Autotune to detect optimal Q/DQ node placements according to TensorRT runtimes. "
            "Candidates are benchmarked in the requested runtime precision, and calibrated Q/DQ is retained only "
            "when it meets the 1.02x performance threshold; otherwise the output has no Q/DQ. "
            "Available modes (presets 'schemes_per_region', 'warmup_runs', and 'timing_runs' values): "
            "  - 'quick': fewer schemes and benchmark runs for quick exploration; "
            "  - 'default': balanced, recommended for most cases; "
            "  - 'extensive': more schemes and runs for extensive search and thorough tuning. "
            "Explicit --autotune_schemes_per_region/warmup_runs/timing_runs override the preset."
        ),
    )

    autotune_group = argparser.add_argument_group(
        "Autotune (only applicable when --autotune is set)"
    )
    autotune_group.add_argument(
        "--autotune_output_dir",
        type=str,
        default=None,
        help="Output directory for autotune results (state file, logs). Default: temp directory.",
    )
    autotune_group.add_argument(
        "--autotune_schemes_per_region",
        type=int,
        default=MODE_PRESETS["default"]["schemes_per_region"],
        help="Number of Q/DQ schemes to test per region.",
        action=StoreWithExplicitFlag,
        explicit_attr="_explicit_autotune_schemes_per_region",
    )
    autotune_group.add_argument(
        "--autotune_pattern_cache",
        type=str,
        default=None,
        dest="autotune_pattern_cache_file",
        help="Path to pattern cache YAML for warm-start.",
    )
    autotune_group.add_argument(
        "--autotune_qdq_baseline",
        type=str,
        default=None,
        help="Path to a pre-quantized ONNX model to import Q/DQ patterns as warm-start.",
    )
    autotune_group.add_argument(
        "--autotune_state_file",
        type=str,
        default=None,
        help="State file path for crash recovery and resume capability (default: <output_dir>/autotuner_state.yaml).",
    )
    autotune_group.add_argument(
        "--autotune_node_filter_list",
        type=str,
        default=None,
        help=(
            "Path to a file containing wildcard patterns to filter ONNX nodes (one pattern per line). "
            "Regions without any matching nodes are skipped during autotuning."
        ),
    )
    autotune_group.add_argument(
        "--autotune_verbose",
        action="store_true",
        help="Enable verbose logging in the autotuner.",
    )
    autotune_group.add_argument(
        "--autotune_use_trtexec",
        action="store_true",
        help="Use trtexec for benchmarking instead of the TensorRT Python API.",
    )
    autotune_group.add_argument(
        "--autotune_timing_cache",
        type=str,
        default=None,
        help="TensorRT timing cache file for faster engine builds.",
    )
    autotune_group.add_argument(
        "--autotune_warmup_runs",
        type=int,
        default=MODE_PRESETS["default"]["warmup_runs"],
        help="Number of warmup runs before timing.",
        action=StoreWithExplicitFlag,
        explicit_attr="_explicit_autotune_warmup_runs",
    )
    autotune_group.add_argument(
        "--autotune_timing_runs",
        type=int,
        default=MODE_PRESETS["default"]["timing_runs"],
        help="Number of timed runs for latency measurement.",
        action=StoreWithExplicitFlag,
        explicit_attr="_explicit_autotune_timing_runs",
    )
    autotune_group.add_argument(
        "--autotune_trtexec_args",
        type=str,
        default=None,
        help=(
            "Additional 'trtexec' arguments as a single quoted string. Only relevant when '--autotune_use_trtexec' is "
            "set. Example: '--fp16 --workspace=4096'"
        ),
    )
    return argparser


def apply_mode_presets(args) -> None:
    """Apply --autotune=mode preset to schemes_per_region, warmup_runs, timing_runs.

    Only applies preset for an option when that option was not explicitly set on the
    command line (explicit flags override the preset).
    """
    if args.autotune not in MODE_PRESETS:
        return
    preset = MODE_PRESETS[args.autotune]
    if not getattr(args, "_explicit_autotune_schemes_per_region", False):
        args.autotune_schemes_per_region = preset["schemes_per_region"]
    if not getattr(args, "_explicit_autotune_warmup_runs", False):
        args.autotune_warmup_runs = preset["warmup_runs"]
    if not getattr(args, "_explicit_autotune_timing_runs", False):
        args.autotune_timing_runs = preset["timing_runs"]


def main():
    """Command-line entrypoint for ONNX PTQ."""
    args = get_parser().parse_args()

    # Security: Validate onnx model size is under 2GB by default
    if not args.use_external_data_format:
        try:
            validate_file_size(args.onnx_path, 2 * (1024**3))
        except ValueError as e:
            raise ValueError(
                "Onnx model size larger than 2GB. Please set --use_external_data_format flag to bypass this validation."
            ) from e

    calibration_data = None
    if args.calibration_data_path:
        # Security: Disable pickle deserialization for untrusted sources to prevent RCE attacks
        try:
            calibration_data = np.load(
                args.calibration_data_path, allow_pickle=args.trust_calibration_data
            )
            if args.calibration_data_path.endswith(".npz"):
                # Convert the NpzFile object to a Python dictionary
                calibration_data = {key: calibration_data[key] for key in calibration_data.files}
        except ValueError as e:
            if "allow_pickle" in str(e) and not args.trust_calibration_data:
                raise ValueError(
                    "Calibration data file contains pickled objects which pose a security risk. "
                    "For trusted sources, you may enable pickle deserialization by setting the "
                    "--trust_calibration_data flag."
                ) from e
            else:
                raise

    # Autotune configs
    autotune_enabled = args.autotune is not None
    if autotune_enabled:
        apply_mode_presets(args)
    autotune_node_filter_list = (
        get_node_filter_list(args.autotune_node_filter_list) if autotune_enabled else None
    )

    quantize(
        args.onnx_path,
        quantize_mode=args.quantize_mode,
        calibration_data=calibration_data,
        calibration_method=args.calibration_method,
        calibration_cache_path=args.calibration_cache_path,
        calibration_shapes=args.calibration_shapes,
        calibration_eps=args.calibration_eps,
        trt_rtx_backend=args.trt_rtx_backend,
        override_shapes=args.override_shapes,
        op_types_to_quantize=args.op_types_to_quantize,
        op_types_to_exclude=args.op_types_to_exclude,
        op_types_to_exclude_fp16=args.op_types_to_exclude_fp16,
        nodes_to_quantize=args.nodes_to_quantize,
        nodes_to_exclude=args.nodes_to_exclude,
        use_external_data_format=args.use_external_data_format,
        keep_intermediate_files=args.keep_intermediate_files,
        output_path=args.output_path,
        log_level=args.log_level,
        log_file=args.log_file,
        trt_plugins=args.trt_plugins,
        trt_plugins_precision=args.trt_plugins_precision,
        high_precision_dtype=args.high_precision_dtype,
        mha_accumulation_dtype=args.mha_accumulation_dtype,
        disable_mha_qdq=args.disable_mha_qdq,
        dq_only=args.dq_only,
        use_zero_point=args.use_zero_point,
        passes=args.passes,
        simplify=args.simplify,
        calibrate_per_node=args.calibrate_per_node,
        direct_io_types=args.direct_io_types,
        opset=args.opset,
        target_dla=args.target_dla,
        autotune=autotune_enabled,
        autotune_output_dir=args.autotune_output_dir,
        autotune_num_schemes_per_region=args.autotune_schemes_per_region,
        autotune_pattern_cache_file=args.autotune_pattern_cache_file,
        autotune_state_file=args.autotune_state_file,
        autotune_qdq_baseline=args.autotune_qdq_baseline,
        autotune_node_filter_list=autotune_node_filter_list,
        autotune_verbose=args.autotune_verbose,
        autotune_use_trtexec=args.autotune_use_trtexec,
        autotune_timing_cache=args.autotune_timing_cache,
        autotune_warmup_runs=args.autotune_warmup_runs,
        autotune_timing_runs=args.autotune_timing_runs,
        autotune_trtexec_args=args.autotune_trtexec_args,
        input_shapes_profile=args.input_shapes_profile,
        model_id=args.model_id,
        trust_remote_code=args.trust_remote_code,
    )


if __name__ == "__main__":
    main()
