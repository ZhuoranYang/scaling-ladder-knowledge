# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

"""Intra-card CP backend for shared delta rule operations.

Accelerates prefill by splitting long sequences into sub-sequences
and processing them in parallel across SMs.

Only active under torch.inference_mode() with varlen (cu_seqlens != None).
"""

from __future__ import annotations

import os

import torch

from fla.backends import BaseBackend, register
from fla.ops.common.chunk_delta_h import chunk_gated_delta_rule_fwd_h

# limit merge-chain depth to control precision loss
MAX_SUBSEQS = int(os.environ.get('FLA_INTRACARD_MAX_SPLITS', 32))


@register(chunk_gated_delta_rule_fwd_h)
class IntraCardCPBackend(BaseBackend):
    """Intra-card context parallel backend for chunk_gated_delta_rule_fwd_h."""

    backend_type = "intracard_cp"
    package_name = None
    env_var = "FLA_INTRACARD_CP"
    default_enable = False

    @classmethod
    def is_available(cls) -> bool:
        return True

    def chunk_gated_delta_rule_fwd_h_verifier(
        self,
        k: torch.Tensor,
        w: torch.Tensor,
        u: torch.Tensor,
        g: torch.Tensor | None = None,
        gk: torch.Tensor | None = None,
        initial_state: torch.Tensor | None = None,
        output_final_state: bool = False,
        chunk_size: int = 64,
        save_new_value: bool = True,
        state_v_first: bool = False,
        cu_seqlens: torch.LongTensor | None = None,
        cu_seqlens_cpu: torch.LongTensor | None = None,
        chunk_indices: torch.LongTensor | None = None,
        chunk_offsets: torch.LongTensor | None = None,
    ) -> tuple[bool, str | None]:
        """Check if intracard CP should handle this call."""
        if not torch.is_inference_mode_enabled():
            return False, "Not in inference mode"

        if cu_seqlens is None:
            return False, "cu_seqlens is None"

        # graph-mode callers pass chunk_offsets; splitting reads cu_seqlens on the host,
        # which CUDA Graph capture cannot record
        if chunk_offsets is not None:
            return False, "chunk_offsets is given (CUDA Graph mode)"

        return True, None

    def chunk_gated_delta_rule_fwd_h(
        self,
        k: torch.Tensor,
        w: torch.Tensor,
        u: torch.Tensor,
        g: torch.Tensor | None = None,
        gk: torch.Tensor | None = None,
        initial_state: torch.Tensor | None = None,
        output_final_state: bool = False,
        chunk_size: int = 64,
        save_new_value: bool = True,
        state_v_first: bool = False,
        cu_seqlens: torch.LongTensor | None = None,
        cu_seqlens_cpu: torch.LongTensor | None = None,
        chunk_indices: torch.LongTensor | None = None,
        chunk_offsets: torch.LongTensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor | None]:
        """Intra-card CP implementation of chunk_gated_delta_rule_fwd_h."""
        from fla.ops.common.intracard_cp import intracard_fwd_h

        return intracard_fwd_h(
            k=k,
            w=w,
            u=u,
            g=g,
            gk=gk,
            initial_state=initial_state,
            output_final_state=output_final_state,
            chunk_size=chunk_size,
            save_new_value=save_new_value,
            state_v_first=state_v_first,
            cu_seqlens=cu_seqlens,
            cu_seqlens_cpu=cu_seqlens_cpu,
            chunk_indices=chunk_indices,
            max_splits=MAX_SUBSEQS,
        )
