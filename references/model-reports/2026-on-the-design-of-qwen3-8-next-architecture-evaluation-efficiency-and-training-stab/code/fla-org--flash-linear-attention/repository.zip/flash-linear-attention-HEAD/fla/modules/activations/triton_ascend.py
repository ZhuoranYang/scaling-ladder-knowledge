# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

"""Activation kernels adapted for triton-ascend on Huawei NPU."""

import torch
import torch.nn.functional as F
import triton
import triton.language as tl

from fla.backends import TritonAscendBackend, register
from fla.modules.activations.ops import (
    alloc_output,
    logsigmoid_bwd,
    logsigmoid_fwd,
    powglu_fwd,
    powglu_fwdbwd,
    powglu_linear,
    prepare_input,
    sigmoid_bwd,
    sigmoid_fwd,
    swiglu_fwd,
    swiglu_fwdbwd,
    swiglu_linear,
    swish_bwd,
    swish_fwd,
)
from fla.ops.utils.op import exp, log
from fla.utils import autocast_custom_bwd, autocast_custom_fwd, input_guard
from fla.utils.ascend_ub_manager import ASCEND_MAX_GRID_DIM, compute_activation_block_size

# ascend launch limits: grid dim and per-core vector width.
_MAX_CORE_DIM = 65535


def _activation_launch_config(
    T: int,
    is_backward: bool = False,
    *,
    memory_multiplier: float | None = None,
) -> tuple[tuple[int], int]:
    """Pick block size under Ascend launch and UB limits."""
    B = compute_activation_block_size(
        total_elements=T,
        is_backward=is_backward,
        max_grid=ASCEND_MAX_GRID_DIM,
        max_core_dim=_MAX_CORE_DIM,
        memory_multiplier=memory_multiplier,
    )
    return (triton.cdiv(T, B),), B


@triton.jit
def _flat_offset(offs, D: tl.constexpr, stride, IS_LINEAR: tl.constexpr):
    if IS_LINEAR:
        return offs
    row = offs // D
    col = offs % D
    return row * stride + col


def _is_linear_stride(stride: int, D: int) -> bool:
    return stride == D


_LINEAR_HEURISTICS_XY = {
    'X_LINEAR': lambda args: _is_linear_stride(stride=args['stride_x_row'], D=args['D']),
    'Y_LINEAR': lambda args: _is_linear_stride(stride=args['stride_y_row'], D=args['D']),
}

_LINEAR_HEURISTICS_XYZ = {
    **_LINEAR_HEURISTICS_XY,
    'Z_LINEAR': lambda args: _is_linear_stride(stride=args['stride_z_row'], D=args['D']),
}

_LINEAR_HEURISTICS_BWD = {
    'X_LINEAR': lambda args: _is_linear_stride(stride=args['stride_x_row'], D=args['D']),
    'DY_LINEAR': lambda args: _is_linear_stride(stride=args['stride_dy_row'], D=args['D']),
    'DX_LINEAR': lambda args: _is_linear_stride(stride=args['stride_dx_row'], D=args['D']),
}

_LINEAR_HEURISTICS_FWDBWD = {
    **_LINEAR_HEURISTICS_XYZ,
    'G_LINEAR': lambda args: _is_linear_stride(stride=args['stride_g_row'], D=args['D']),
    'DX_LINEAR': lambda args: _is_linear_stride(stride=args['stride_dx_row'], D=args['D']),
    'DY_LINEAR': lambda args: _is_linear_stride(stride=args['stride_dy_row'], D=args['D']),
}


@triton.heuristics(_LINEAR_HEURISTICS_XY)
@triton.jit(do_not_specialize=['T'])
def sigmoid_fwd_kernel(
    x,
    y,
    T,
    D: tl.constexpr,
    stride_x_row,
    stride_y_row,
    B: tl.constexpr,
    X_LINEAR: tl.constexpr,
    Y_LINEAR: tl.constexpr,
):
    pid = tl.program_id(0)
    offs = pid * B + tl.arange(0, B)
    mask = offs < T
    x_off = _flat_offset(offs=offs, D=D, stride=stride_x_row, IS_LINEAR=X_LINEAR)
    y_off = _flat_offset(offs=offs, D=D, stride=stride_y_row, IS_LINEAR=Y_LINEAR)
    x_val = tl.load(x + x_off, mask=mask, other=0.).to(tl.float32)
    y_val = tl.sigmoid(x_val)
    tl.store(y + y_off, y_val.to(y.dtype.element_ty), mask=mask)


@triton.heuristics(_LINEAR_HEURISTICS_BWD)
@triton.jit(do_not_specialize=['T'])
def sigmoid_bwd_kernel(
    x,
    dy,
    dx,
    T,
    D: tl.constexpr,
    stride_x_row,
    stride_dy_row,
    stride_dx_row,
    B: tl.constexpr,
    X_LINEAR: tl.constexpr,
    DY_LINEAR: tl.constexpr,
    DX_LINEAR: tl.constexpr,
):
    pid = tl.program_id(0)
    offs = pid * B + tl.arange(0, B)
    mask = offs < T
    x_off = _flat_offset(offs=offs, D=D, stride=stride_x_row, IS_LINEAR=X_LINEAR)
    dy_off = _flat_offset(offs=offs, D=D, stride=stride_dy_row, IS_LINEAR=DY_LINEAR)
    dx_off = _flat_offset(offs=offs, D=D, stride=stride_dx_row, IS_LINEAR=DX_LINEAR)
    x_val = tl.load(x + x_off, mask=mask, other=0.).to(tl.float32)
    g_val = tl.load(dy + dy_off, mask=mask, other=0.).to(tl.float32)
    s = tl.sigmoid(x_val)
    dx_val = g_val * s * (1.0 - s)
    tl.store(dx + dx_off, dx_val.to(dx.dtype.element_ty), mask=mask)


@triton.heuristics(_LINEAR_HEURISTICS_XY)
@triton.jit(do_not_specialize=['T'])
def logsigmoid_fwd_kernel(
    x,
    y,
    temperature,
    T,
    D: tl.constexpr,
    stride_x_row,
    stride_y_row,
    B: tl.constexpr,
    X_LINEAR: tl.constexpr,
    Y_LINEAR: tl.constexpr,
):
    i = tl.program_id(0)
    offs = i * B + tl.arange(0, B)
    mask = offs < T
    x_off = _flat_offset(offs=offs, D=D, stride=stride_x_row, IS_LINEAR=X_LINEAR)
    y_off = _flat_offset(offs=offs, D=D, stride=stride_y_row, IS_LINEAR=Y_LINEAR)

    b_x = tl.load(x + x_off, mask=mask, other=0.).to(tl.float32)
    b_m = tl.minimum(0., b_x)
    b_z = 1. + exp(-tl.abs(b_x))
    b_y = (b_m - log(b_z)) / temperature
    tl.store(y + y_off, b_y.to(y.dtype.element_ty), mask=mask)


@triton.heuristics(_LINEAR_HEURISTICS_BWD)
@triton.jit(do_not_specialize=['T'])
def logsigmoid_bwd_kernel(
    x,
    dx,
    dy,
    temperature,
    T,
    D: tl.constexpr,
    stride_x_row,
    stride_dx_row,
    stride_dy_row,
    B: tl.constexpr,
    X_LINEAR: tl.constexpr,
    DX_LINEAR: tl.constexpr,
    DY_LINEAR: tl.constexpr,
):
    i = tl.program_id(0)
    offs = i * B + tl.arange(0, B)
    mask = offs < T
    x_off = _flat_offset(offs=offs, D=D, stride=stride_x_row, IS_LINEAR=X_LINEAR)
    dx_off = _flat_offset(offs=offs, D=D, stride=stride_dx_row, IS_LINEAR=DX_LINEAR)
    dy_off = _flat_offset(offs=offs, D=D, stride=stride_dy_row, IS_LINEAR=DY_LINEAR)

    b_x = tl.load(x + x_off, mask=mask, other=0.).to(tl.float32)
    b_dy = tl.load(dy + dy_off, mask=mask, other=0.).to(tl.float32)
    b_s = tl.sigmoid(b_x)
    b_dx = b_dy * ((1. - b_s) / temperature)
    tl.store(dx + dx_off, b_dx.to(dx.dtype.element_ty), mask=mask)


@triton.heuristics(_LINEAR_HEURISTICS_XY)
@triton.jit(do_not_specialize=['T'])
def swish_fwd_kernel(
    x,
    y,
    T,
    D: tl.constexpr,
    stride_x_row,
    stride_y_row,
    B: tl.constexpr,
    X_LINEAR: tl.constexpr,
    Y_LINEAR: tl.constexpr,
):
    pid = tl.program_id(0)
    offs = pid * B + tl.arange(0, B)
    mask = offs < T
    x_off = _flat_offset(offs=offs, D=D, stride=stride_x_row, IS_LINEAR=X_LINEAR)
    y_off = _flat_offset(offs=offs, D=D, stride=stride_y_row, IS_LINEAR=Y_LINEAR)
    x_val = tl.load(x + x_off, mask=mask, other=0.).to(tl.float32)
    s = tl.sigmoid(x_val)
    y_val = x_val * s
    tl.store(y + y_off, y_val.to(y.dtype.element_ty), mask=mask)


@triton.heuristics(_LINEAR_HEURISTICS_BWD)
@triton.jit(do_not_specialize=['T'])
def swish_bwd_kernel(
    x,
    dy,
    dx,
    T,
    D: tl.constexpr,
    stride_x_row,
    stride_dy_row,
    stride_dx_row,
    B: tl.constexpr,
    X_LINEAR: tl.constexpr,
    DY_LINEAR: tl.constexpr,
    DX_LINEAR: tl.constexpr,
):
    pid = tl.program_id(0)
    offs = pid * B + tl.arange(0, B)
    mask = offs < T
    x_off = _flat_offset(offs=offs, D=D, stride=stride_x_row, IS_LINEAR=X_LINEAR)
    dy_off = _flat_offset(offs=offs, D=D, stride=stride_dy_row, IS_LINEAR=DY_LINEAR)
    dx_off = _flat_offset(offs=offs, D=D, stride=stride_dx_row, IS_LINEAR=DX_LINEAR)
    x_val = tl.load(x + x_off, mask=mask, other=0.).to(tl.float32)
    g_val = tl.load(dy + dy_off, mask=mask, other=0.).to(tl.float32)
    s = tl.sigmoid(x_val)
    dx_val = g_val * s * (1.0 + x_val * (1.0 - s))
    tl.store(dx + dx_off, dx_val.to(dx.dtype.element_ty), mask=mask)


@triton.heuristics(_LINEAR_HEURISTICS_XYZ)
@triton.jit(do_not_specialize=['T'])
def swiglu_fwd_kernel(
    x,
    y,
    z,
    T,
    D: tl.constexpr,
    stride_x_row,
    stride_y_row,
    stride_z_row,
    B: tl.constexpr,
    X_LINEAR: tl.constexpr,
    Y_LINEAR: tl.constexpr,
    Z_LINEAR: tl.constexpr,
):
    pid = tl.program_id(0)
    offs = pid * B + tl.arange(0, B)
    mask = offs < T
    x_off = _flat_offset(offs=offs, D=D, stride=stride_x_row, IS_LINEAR=X_LINEAR)
    y_off = _flat_offset(offs=offs, D=D, stride=stride_y_row, IS_LINEAR=Y_LINEAR)
    z_off = _flat_offset(offs=offs, D=D, stride=stride_z_row, IS_LINEAR=Z_LINEAR)
    x_val = tl.load(x + x_off, mask=mask, other=0.).to(tl.float32)
    y_val = tl.load(y + y_off, mask=mask, other=0.).to(tl.float32)
    s = tl.sigmoid(x_val)
    z_val = x_val * s * y_val
    tl.store(z + z_off, z_val.to(z.dtype.element_ty), mask=mask)


@triton.heuristics({'HAS_WEIGHT': lambda args: args['z'] is not None, **_LINEAR_HEURISTICS_FWDBWD})
@triton.jit(do_not_specialize=['T'])
def swiglu_fwdbwd_kernel(
    x,
    y,
    g,
    dx,
    dy,
    z,
    T,
    D: tl.constexpr,
    stride_x_row,
    stride_y_row,
    stride_g_row,
    stride_dx_row,
    stride_dy_row,
    stride_z_row,
    B: tl.constexpr,
    HAS_WEIGHT: tl.constexpr,
    X_LINEAR: tl.constexpr,
    Y_LINEAR: tl.constexpr,
    G_LINEAR: tl.constexpr,
    DX_LINEAR: tl.constexpr,
    DY_LINEAR: tl.constexpr,
    Z_LINEAR: tl.constexpr,
):
    pid = tl.program_id(0)
    offs = pid * B + tl.arange(0, B)
    mask = offs < T
    x_off = _flat_offset(offs=offs, D=D, stride=stride_x_row, IS_LINEAR=X_LINEAR)
    y_off = _flat_offset(offs=offs, D=D, stride=stride_y_row, IS_LINEAR=Y_LINEAR)
    g_off = _flat_offset(offs=offs, D=D, stride=stride_g_row, IS_LINEAR=G_LINEAR)
    dx_off = _flat_offset(offs=offs, D=D, stride=stride_dx_row, IS_LINEAR=DX_LINEAR)
    dy_off = _flat_offset(offs=offs, D=D, stride=stride_dy_row, IS_LINEAR=DY_LINEAR)
    x_val = tl.load(x + x_off, mask=mask, other=0.).to(tl.float32)
    y_val = tl.load(y + y_off, mask=mask, other=0.).to(tl.float32)
    g_val = tl.load(g + g_off, mask=mask, other=0.).to(tl.float32)

    s = tl.sigmoid(x_val)
    x_s = x_val * s
    dx_val = g_val * s * (1.0 + x_val * (1.0 - s)) * y_val
    dy_val = g_val * x_s

    tl.store(dx + dx_off, dx_val.to(dx.dtype.element_ty), mask=mask)
    tl.store(dy + dy_off, dy_val.to(dy.dtype.element_ty), mask=mask)
    if HAS_WEIGHT:
        z_off = _flat_offset(offs=offs, D=D, stride=stride_z_row, IS_LINEAR=Z_LINEAR)
        z_val = x_s * y_val
        tl.store(z + z_off, z_val.to(z.dtype.element_ty), mask=mask)


@register(sigmoid_fwd, backend=TritonAscendBackend)
@torch.compiler.disable
def sigmoid_fwd_npu(x: torch.Tensor, output_contiguous: bool = False) -> torch.Tensor:
    x, stride_x_row = prepare_input(x=x)
    T, D = x.numel(), x.shape[-1]
    y = alloc_output(x=x, contiguous=output_contiguous)
    grid, B = _activation_launch_config(T=T)
    sigmoid_fwd_kernel[grid](x=x, y=y, T=T, D=D, stride_x_row=stride_x_row, stride_y_row=D, B=B)
    return y


@register(sigmoid_bwd, backend=TritonAscendBackend)
@torch.compiler.disable
def sigmoid_bwd_npu(x: torch.Tensor, dy: torch.Tensor, output_contiguous: bool = False) -> torch.Tensor:
    x, stride_x_row = prepare_input(x=x)
    dy, stride_dy_row = prepare_input(x=dy)
    T, D = x.numel(), x.shape[-1]
    dx = alloc_output(x=x, contiguous=output_contiguous)
    grid, B = _activation_launch_config(T=T, is_backward=True)
    sigmoid_bwd_kernel[grid](
        x=x,
        dy=dy,
        dx=dx,
        T=T,
        D=D,
        stride_x_row=stride_x_row,
        stride_dy_row=stride_dy_row,
        stride_dx_row=D,
        B=B,
    )
    return dx


@register(logsigmoid_fwd, backend=TritonAscendBackend)
@torch.compiler.disable
def logsigmoid_fwd_npu(x: torch.Tensor, temperature: float = 1., output_contiguous: bool = False) -> torch.Tensor:
    x, stride_x_row = prepare_input(x=x)
    T, D = x.numel(), x.shape[-1]
    y = alloc_output(x=x, contiguous=output_contiguous)
    grid, B = _activation_launch_config(T=T)
    logsigmoid_fwd_kernel[grid](
        x=x,
        y=y,
        temperature=temperature,
        T=T,
        D=D,
        stride_x_row=stride_x_row,
        stride_y_row=D,
        B=B,
    )
    return y


@register(logsigmoid_bwd, backend=TritonAscendBackend)
@torch.compiler.disable
def logsigmoid_bwd_npu(
    x: torch.Tensor,
    dy: torch.Tensor,
    temperature: float = 1.,
    output_contiguous: bool = False,
) -> torch.Tensor:
    x, stride_x_row = prepare_input(x=x)
    dy, stride_dy_row = prepare_input(x=dy)
    T, D = x.numel(), x.shape[-1]
    dx = alloc_output(x=x, contiguous=output_contiguous)
    grid, B = _activation_launch_config(T=T, is_backward=True)
    logsigmoid_bwd_kernel[grid](
        x=x,
        dx=dx,
        dy=dy,
        temperature=temperature,
        T=T,
        D=D,
        stride_x_row=stride_x_row,
        stride_dx_row=D,
        stride_dy_row=stride_dy_row,
        B=B,
    )
    return dx


@register(swish_fwd, backend=TritonAscendBackend)
@torch.compiler.disable
def swish_fwd_npu(x: torch.Tensor, output_contiguous: bool = False) -> torch.Tensor:
    x, stride_x_row = prepare_input(x=x)
    T, D = x.numel(), x.shape[-1]
    y = alloc_output(x=x, contiguous=output_contiguous)
    grid, B = _activation_launch_config(T=T)
    swish_fwd_kernel[grid](x=x, y=y, T=T, D=D, stride_x_row=stride_x_row, stride_y_row=D, B=B)
    return y


@register(swish_bwd, backend=TritonAscendBackend)
@torch.compiler.disable
def swish_bwd_npu(x: torch.Tensor, dy: torch.Tensor, output_contiguous: bool = False) -> torch.Tensor:
    x, stride_x_row = prepare_input(x=x)
    dy, stride_dy_row = prepare_input(x=dy)
    T, D = x.numel(), x.shape[-1]
    dx = alloc_output(x=x, contiguous=output_contiguous)
    grid, B = _activation_launch_config(T=T, is_backward=True)
    swish_bwd_kernel[grid](
        x=x,
        dy=dy,
        dx=dx,
        T=T,
        D=D,
        stride_x_row=stride_x_row,
        stride_dy_row=stride_dy_row,
        stride_dx_row=D,
        B=B,
    )
    return dx


@register(swiglu_fwd, backend=TritonAscendBackend)
@torch.compiler.disable
def swiglu_fwd_npu(x: torch.Tensor, y: torch.Tensor, output_contiguous: bool = False) -> torch.Tensor:
    assert x.shape == y.shape, f"swiglu_fwd: shape mismatch x={x.shape} y={y.shape}"
    x, stride_x_row = prepare_input(x=x)
    y, stride_y_row = prepare_input(x=y)
    T, D = x.numel(), x.shape[-1]
    z = alloc_output(x=x, contiguous=output_contiguous)
    grid, B = _activation_launch_config(T=T)
    swiglu_fwd_kernel[grid](
        x=x,
        y=y,
        z=z,
        T=T,
        D=D,
        stride_x_row=stride_x_row,
        stride_y_row=stride_y_row,
        stride_z_row=D,
        B=B,
    )
    return z


@register(swiglu_fwdbwd, backend=TritonAscendBackend)
@torch.compiler.disable
def swiglu_fwdbwd_npu(
    x: torch.Tensor,
    y: torch.Tensor,
    g: torch.Tensor,
    use_weight: bool = False,
    output_contiguous: bool = False,
):
    assert x.shape == y.shape == g.shape, f"swiglu_fwdbwd: shape mismatch x={x.shape} y={y.shape} g={g.shape}"
    x, stride_x_row = prepare_input(x=x)
    y, stride_y_row = prepare_input(x=y)
    g, stride_g_row = prepare_input(x=g)
    T, D = x.numel(), x.shape[-1]
    dx = alloc_output(x=x, contiguous=output_contiguous)
    dy = alloc_output(x=y, contiguous=output_contiguous)
    if use_weight:
        z = alloc_output(x=x, contiguous=output_contiguous)
    else:
        z = None
    grid, B = _activation_launch_config(T=T, is_backward=True)
    swiglu_fwdbwd_kernel[grid](
        x=x,
        y=y,
        g=g,
        dx=dx,
        dy=dy,
        z=z,
        T=T,
        D=D,
        stride_x_row=stride_x_row,
        stride_y_row=stride_y_row,
        stride_g_row=stride_g_row,
        stride_dx_row=D,
        stride_dy_row=D,
        stride_z_row=D if z is not None else 0,
        B=B,
    )
    if use_weight:
        return dx, dy, z
    return dx, dy


class SwiGLULinearFunctionNPU(torch.autograd.Function):

    @staticmethod
    @input_guard(no_guard_contiguous=True)
    @autocast_custom_fwd
    def forward(ctx, x, y, weight, bias):
        z = swiglu_fwd_npu(x=x, y=y, output_contiguous=True)
        out = F.linear(z, weight, bias)
        ctx.save_for_backward(x, y, weight)
        ctx.linear_bias_is_none = bias is None
        return out

    @staticmethod
    @input_guard(no_guard_contiguous=True)
    @autocast_custom_bwd
    def backward(ctx, dout, *args):
        x, y, weight = ctx.saved_tensors
        dout = dout.reshape(-1, dout.shape[-1])
        dz = F.linear(dout, weight.t()).view_as(x)
        dx, dy, z = swiglu_fwdbwd_npu(x=x, y=y, g=dz, use_weight=True, output_contiguous=True)
        z_flat = z.reshape(-1, z.shape[-1])
        dlinear_weight = dout.t() @ z_flat
        dlinear_bias = None if ctx.linear_bias_is_none else dout.sum(0)
        return dx, dy, dlinear_weight, dlinear_bias


@register(swiglu_linear, backend=TritonAscendBackend)
def swiglu_linear_npu(x, y, weight, bias):
    return SwiGLULinearFunctionNPU.apply(x, y, weight, bias)


@triton.heuristics(_LINEAR_HEURISTICS_XYZ)
@triton.jit(do_not_specialize=['T'])
def powglu_fwd_kernel(
    x,
    y,
    z,
    stride_x_row,
    stride_y_row,
    stride_z_row,
    m,
    T,
    D: tl.constexpr,
    B: tl.constexpr,
    X_LINEAR: tl.constexpr,
    Y_LINEAR: tl.constexpr,
    Z_LINEAR: tl.constexpr,
):
    i_n = tl.program_id(0)
    offs = i_n * B + tl.arange(0, B)
    mask = offs < T
    x_off = _flat_offset(offs=offs, D=D, stride=stride_x_row, IS_LINEAR=X_LINEAR)
    y_off = _flat_offset(offs=offs, D=D, stride=stride_y_row, IS_LINEAR=Y_LINEAR)
    z_off = _flat_offset(offs=offs, D=D, stride=stride_z_row, IS_LINEAR=Z_LINEAR)
    b_x = tl.load(x + x_off, mask=mask, other=0.).to(tl.float32)
    b_y = tl.load(y + y_off, mask=mask, other=0.).to(tl.float32)
    b_s = tl.sigmoid(b_x)
    b_pos = b_x > 0
    # feed only positive lanes to log/sqrt; masked lanes give x**p = 1 and are dropped by the where
    b_xp = tl.where(b_pos, b_x, 1.0)
    b_sqrt = tl.sqrt(b_xp)
    b_p = m / (b_sqrt + 1.0)
    b_pow = exp(b_p * log(b_xp))
    b_g = tl.where(b_pos, b_pow * b_s, b_x * b_s)
    b_z = b_g * b_y
    tl.store(z + z_off, b_z.to(z.dtype.element_ty), mask=mask)


@triton.heuristics({'HAS_WEIGHT': lambda args: args['z'] is not None, **_LINEAR_HEURISTICS_FWDBWD})
@triton.jit(do_not_specialize=['T'])
def powglu_fwdbwd_kernel(
    x,
    y,
    g,
    dx,
    dy,
    z,
    stride_x_row,
    stride_y_row,
    stride_g_row,
    stride_dx_row,
    stride_dy_row,
    stride_z_row,
    m,
    T,
    D: tl.constexpr,
    B: tl.constexpr,
    HAS_WEIGHT: tl.constexpr,
    X_LINEAR: tl.constexpr,
    Y_LINEAR: tl.constexpr,
    G_LINEAR: tl.constexpr,
    DX_LINEAR: tl.constexpr,
    DY_LINEAR: tl.constexpr,
    Z_LINEAR: tl.constexpr,
):
    i_n = tl.program_id(0)
    offs = i_n * B + tl.arange(0, B)
    mask = offs < T
    x_off = _flat_offset(offs=offs, D=D, stride=stride_x_row, IS_LINEAR=X_LINEAR)
    y_off = _flat_offset(offs=offs, D=D, stride=stride_y_row, IS_LINEAR=Y_LINEAR)
    g_off = _flat_offset(offs=offs, D=D, stride=stride_g_row, IS_LINEAR=G_LINEAR)
    dx_off = _flat_offset(offs=offs, D=D, stride=stride_dx_row, IS_LINEAR=DX_LINEAR)
    dy_off = _flat_offset(offs=offs, D=D, stride=stride_dy_row, IS_LINEAR=DY_LINEAR)
    b_x = tl.load(x + x_off, mask=mask, other=0.).to(tl.float32)
    b_y = tl.load(y + y_off, mask=mask, other=0.).to(tl.float32)
    b_g = tl.load(g + g_off, mask=mask, other=0.).to(tl.float32)

    b_s = tl.sigmoid(b_x)
    b_pos = b_x > 0
    b_xp = tl.where(b_pos, b_x, 1.0)
    b_sqrt = tl.sqrt(b_xp)
    b_ln = log(b_xp)
    b_p = m / (b_sqrt + 1.0)
    b_pow = exp(b_p * b_ln)

    b_gate_pos = b_pow * b_s
    # d/dx of the exponent term: p' = -m / (2*sqrt(x)*(sqrt(x)+1)**2)
    b_pprime = -m / (2.0 * b_sqrt * (b_sqrt + 1.0) * (b_sqrt + 1.0))
    b_dgate_pos = b_gate_pos * (b_pprime * b_ln + b_p / b_xp + 1.0 - b_s)
    b_gate_neg = b_x * b_s
    b_dgate_neg = b_s * (1.0 + b_x * (1.0 - b_s))

    b_gate = tl.where(b_pos, b_gate_pos, b_gate_neg)
    b_dgate = tl.where(b_pos, b_dgate_pos, b_dgate_neg)

    b_dx = b_g * b_y * b_dgate
    b_dy = b_g * b_gate

    tl.store(dx + dx_off, b_dx.to(dx.dtype.element_ty), mask=mask)
    tl.store(dy + dy_off, b_dy.to(dy.dtype.element_ty), mask=mask)
    if HAS_WEIGHT:
        b_z = b_gate * b_y
        z_off = _flat_offset(offs=offs, D=D, stride=stride_z_row, IS_LINEAR=Z_LINEAR)
        tl.store(z + z_off, b_z.to(z.dtype.element_ty), mask=mask)


# peak fp32 temporaries: sigmoid, sqrt, log, exp, pow, gate, output.
_POWGLU_FWD_MEM_MULT = 8.0
_POWGLU_BWD_MEM_MULT = 10.0


@register(powglu_fwd, backend=TritonAscendBackend)
@torch.compiler.disable
def powglu_fwd_npu(x: torch.Tensor, y: torch.Tensor, power: float = 3.0, output_contiguous: bool = False) -> torch.Tensor:
    assert x.shape == y.shape, f"powglu_fwd: shape mismatch x={x.shape} y={y.shape}"
    x, stride_x_row = prepare_input(x=x)
    y, stride_y_row = prepare_input(x=y)
    T, D = x.numel(), x.shape[-1]
    z = alloc_output(x=x, contiguous=output_contiguous)
    grid, B = _activation_launch_config(T=T, memory_multiplier=_POWGLU_FWD_MEM_MULT)
    powglu_fwd_kernel[grid](
        x=x,
        y=y,
        z=z,
        stride_x_row=stride_x_row,
        stride_y_row=stride_y_row,
        stride_z_row=D,
        m=power,
        T=T,
        D=D,
        B=B,
    )
    return z


@register(powglu_fwdbwd, backend=TritonAscendBackend)
@torch.compiler.disable
def powglu_fwdbwd_npu(
    x: torch.Tensor,
    y: torch.Tensor,
    g: torch.Tensor,
    power: float = 3.0,
    use_weight: bool = False,
    output_contiguous: bool = False,
):
    assert x.shape == y.shape == g.shape, f"powglu_fwdbwd: shape mismatch x={x.shape} y={y.shape} g={g.shape}"
    x, stride_x_row = prepare_input(x=x)
    y, stride_y_row = prepare_input(x=y)
    g, stride_g_row = prepare_input(x=g)
    T, D = x.numel(), x.shape[-1]
    dx = alloc_output(x=x, contiguous=output_contiguous)
    dy = alloc_output(x=y, contiguous=output_contiguous)
    if use_weight:
        z = alloc_output(x=x, contiguous=output_contiguous)
    else:
        z = None
    grid, B = _activation_launch_config(T=T, is_backward=True, memory_multiplier=_POWGLU_BWD_MEM_MULT)
    powglu_fwdbwd_kernel[grid](
        x=x,
        y=y,
        g=g,
        dx=dx,
        dy=dy,
        z=z,
        stride_x_row=stride_x_row,
        stride_y_row=stride_y_row,
        stride_g_row=stride_g_row,
        stride_dx_row=D,
        stride_dy_row=D,
        stride_z_row=D if z is not None else 0,
        m=power,
        T=T,
        D=D,
        B=B,
    )
    if use_weight:
        return dx, dy, z
    return dx, dy


class PowGLULinearFunctionNPU(torch.autograd.Function):
    r"""
    Power-Gated Linear Unit (PowGLU) function followed by a linear transformation.

    .. math::
        \text{PowGLULinear}(x, y, W, b) = (g(x) * y) W + b

    This simple wrap discards the intermediate results of PowGLU(x, y) to save memory.
    """

    @staticmethod
    @input_guard(no_guard_contiguous=True)
    @autocast_custom_fwd
    def forward(ctx, x, y, weight, bias, power):
        z = powglu_fwd_npu(x=x, y=y, power=power, output_contiguous=True)
        out = F.linear(z, weight, bias)
        ctx.save_for_backward(x, y, weight)
        ctx.linear_bias_is_none = bias is None
        ctx.power = power
        return out

    @staticmethod
    @input_guard(no_guard_contiguous=True)
    @autocast_custom_bwd
    def backward(ctx, dout, *args):
        x, y, weight = ctx.saved_tensors
        dout = dout.reshape(-1, dout.shape[-1])
        dz = F.linear(dout, weight.t()).view_as(x)
        dx, dy, z = powglu_fwdbwd_npu(x=x, y=y, g=dz, power=ctx.power, use_weight=True, output_contiguous=True)
        z_flat = z.reshape(-1, z.shape[-1])
        dlinear_weight = dout.t() @ z_flat
        dlinear_bias = None if ctx.linear_bias_is_none else dout.sum(0)
        return dx, dy, dlinear_weight, dlinear_bias, None


@register(powglu_linear, backend=TritonAscendBackend)
def powglu_linear_npu(
    x: torch.Tensor,
    y: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    power: float = 3.0,
) -> torch.Tensor:
    return PowGLULinearFunctionNPU.apply(x, y, weight, bias, power)
