# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

import torch
import torch.distributed as dist

from fla.ops.cp import FLACPContext, all_gather_into_tensor, conv_cp_send_recv_bwd, conv_cp_send_recv_fwd
from fla.ops.utils import prepare_chunk_indices


class CausalConv1dFunctionCP(torch.autograd.Function):
    """
    Context Parallel version of CausalConv1dFunction.

    Forward:
        1. Get tails from previous rank to construct initial_state
        2. Call causal_conv1d_fwd

    Backward:
        1. Call causal_conv1d_bwd to get dx
        2. Sync communication: add next rank's first W-1 token gradients to current rank's last W-1 tokens
    """

    @staticmethod
    def _prepare_initial_state_for_cp(
        x: torch.Tensor,
        weight: torch.Tensor,
        cu_seqlens: torch.Tensor | None,
        context: FLACPContext,
        group: dist.ProcessGroup | None,
    ) -> torch.Tensor | None:
        """Prepare initial_state for CP forward pass by communicating with previous rank.

        Args:
            x (torch.Tensor):
                Input tensor of shape [1, T, D]
            weight (torch.Tensor):
                Weight tensor of shape [D, W]
            cu_seqlens (torch.Tensor | None):
                Cumulative sequence lengths
            context (FLACPContext):
                CP context
            group (dist.ProcessGroup | None):
                Process group for communication

        Returns:
            initial_state (torch.Tensor | None):
                Initial state tensor of shape [N, D, W] or None
        """
        W = weight.shape[-1]  # weight: [D, W]
        if group is None or W == 1:
            return None

        D = weight.shape[0]
        initial_state = None
        if context.layout == 'zigzag':
            world_size = dist.get_world_size(group)
            rank = dist.get_rank(group)
            part_len = context.part_len
            assert part_len >= W - 1, (
                f"zigzag CP requires part_len ({part_len}) >= conv1d_kernel_size - 1 ({W - 1}); "
                "increase total tokens or reduce world size"
            )
            assert x.dim() == 3 and x.shape[0] == 1, f"CP requires [1, T, D], got {x.shape}"
            x_2d = x.squeeze(0)  # [T, D]
            # last W-1 tokens of each chain part (front, back)
            tails = torch.stack([x_2d[part_len - (W - 1): part_len], x_2d[-(W - 1):]])
            gathered, _ = all_gather_into_tensor(tails, group=group)
            # chain order: front parts of ranks 0..W-1, then back parts of ranks W-1..0
            slots = torch.cat([gathered[:, 0], gathered[:, 1].flip(0)])
            N = len(cu_seqlens) - 1
            initial_state = torch.zeros(N, D, W, device=x.device, dtype=x.dtype)
            for part, row in enumerate((0, context.front_num_seqs)):
                if not context.is_first_by_part[part]:
                    valid_len = min(W - 1, context.pre_num_conv_tokens_by_part[part])
                    if valid_len > 0:
                        chain_pos = rank if part == 0 else 2 * world_size - 1 - rank
                        initial_state[row, :, -valid_len:] = slots[chain_pos - 1][-valid_len:].T
            return initial_state
        if not context.is_first_rank:
            # non-first rank needs initial_state
            assert x.dim() == 3 and x.shape[0] == 1, f"CP requires [1, T, D], got {x.shape}"
            x_2d = x.squeeze(0)  # [T, D]
            tails = x_2d[-(W-1):].contiguous()  # [W-1, D]
            heads = conv_cp_send_recv_fwd(tails, group)  # [W-1, D]
            # construct initial_state: [N, D, W]
            N = len(cu_seqlens) - 1
            initial_state = torch.zeros(N, D, W, device=x.device, dtype=x.dtype)
            valid_len = min(W - 1, context.pre_num_conv_tokens)
            if valid_len > 0:
                # heads[-valid_len:]: [valid_len, D] -> [D, valid_len]
                initial_state[0, :, -valid_len:] = heads[-valid_len:].T
        else:
            # first rank also needs to participate in communication (send tails)
            x_2d = x.squeeze(0)
            tails = x_2d[-(W-1):].contiguous()
            # send but don't use
            _ = conv_cp_send_recv_fwd(tails, group)

        return initial_state

    @staticmethod
    def _correct_dx_for_cp(
        dx: torch.Tensor,
        dh0: torch.Tensor | None,
        W: int,
        group: dist.ProcessGroup | None,
        cp_context: FLACPContext,
    ) -> None:
        """Correct dx gradients for CP backward pass by communicating with next rank.

        Args:
            dx (torch.Tensor):
                Gradient tensor to be corrected, shape [1, T, D]
            dh0 (torch.Tensor | None):
                Gradient w.r.t. initial_state, shape [N, D, W] or None
            W (int):
                Kernel size
            group (dist.ProcessGroup | None):
                Process group for communication
            cp_context (FLACPContext):
                CP context
        """
        if group is None or W == 1:
            return

        D = dx.shape[-1]
        if cp_context.layout == 'zigzag':
            world_size = dist.get_world_size(group)
            rank = dist.get_rank(group)
            part_len = cp_context.part_len
            # dh0 rows for chain-first parts stay zero: their forward initial_state was zeros
            d_initial_state = torch.zeros(2, W - 1, D, device=dx.device, dtype=dx.dtype)
            for part, row in enumerate((0, cp_context.front_num_seqs)):
                if not cp_context.is_first_by_part[part]:
                    valid_len = min(W - 1, cp_context.pre_num_conv_tokens_by_part[part])
                    if valid_len > 0:
                        d_initial_state[part, -valid_len:] = dh0[row, :, -valid_len:].T
            gathered, _ = all_gather_into_tensor(d_initial_state, group=group)
            # chain order: front parts of ranks 0..W-1, then back parts of ranks W-1..0
            slots = torch.cat([gathered[:, 0], gathered[:, 1].flip(0)])
            # the front part's chain successor is the next rank's front or own back part
            dx[0, part_len - (W - 1): part_len, :].add_(slots[rank + 1])
            # the back part's successor exists unless it is chain-last (rank 0)
            if rank > 0:
                dx[0, -(W - 1):, :].add_(slots[2 * world_size - rank])
            return
        # dh0: [N, D, W] or None
        # We only care about the first sequence's initial_state gradient
        if dh0 is not None:
            # Only keep gradients for positions that had real data from the
            # previous rank. The forward fills only the last valid_len positions
            # of initial_state; gradients for the remaining (zero-padded) positions
            # must not flow back, otherwise they leak into unrelated sequences.
            valid_len = min(W - 1, cp_context.pre_num_conv_tokens)
            d_initial_state = torch.zeros(W-1, D, device=dx.device, dtype=dx.dtype)
            if valid_len > 0:
                d_initial_state[-valid_len:] = dh0[0, :, -valid_len:].T
        else:
            # dh0 is None only when this is the first rank (no initial_state needed)
            assert cp_context.is_first_rank, "dh0 should not be None when is_first_rank=False"
            d_initial_state = torch.zeros(W-1, D, device=dx.device, dtype=dx.dtype)
        # Sync communication: send d_initial_state to previous rank, receive from next rank
        recv_d_init = conv_cp_send_recv_bwd(d_initial_state, group)  # [W-1, D]
        # Add to current rank's last W-1 tokens (these tokens are used as initial_state by next rank)
        dx[0, -(W-1):, :].add_(recv_d_init)

    @staticmethod
    def forward(
        ctx,
        x: torch.Tensor,
        weight: torch.Tensor,
        bias: torch.Tensor | None,
        activation: str | None,
        chunk_indices: torch.Tensor | None,
        cp_context: FLACPContext | None,
        chunk_size: int | None,
        backend: str = 'triton',
        residual: torch.Tensor | None = None,
    ) -> torch.Tensor:
        # import here to avoid circular dependency
        from fla.modules.causal_conv1d import causal_conv1d_fwd

        if cp_context is None:
            raise ValueError("cp_context must be provided for CausalConv1dFunctionCP")
        cu_seqlens = cp_context.cu_seqlens
        cu_seqlens_cpu = cp_context.cu_seqlens_cpu
        group = cp_context.group

        # get kernel_size
        W = weight.shape[-1]  # weight: [D, W]
        # prepare initial_state for CP
        initial_state = CausalConv1dFunctionCP._prepare_initial_state_for_cp(
            x=x,
            weight=weight,
            cu_seqlens=cu_seqlens,
            context=cp_context,
            group=group,
        )

        ctx.save_for_backward(x, weight, bias, residual, initial_state)
        ctx.activation = activation
        ctx.cu_seqlens = cu_seqlens
        ctx.cu_seqlens_cpu = cu_seqlens_cpu
        ctx.chunk_indices = chunk_indices
        ctx.chunk_size = chunk_size
        ctx.group = group
        ctx.W = W
        ctx.cp_context = cp_context

        # call original forward
        y, _ = causal_conv1d_fwd(
            x=x,
            weight=weight,
            bias=bias,
            residual=residual,
            initial_state=initial_state,
            output_final_state=False,
            activation=activation,
            cu_seqlens=cu_seqlens,
            cu_seqlens_cpu=cu_seqlens_cpu,
            chunk_indices=chunk_indices,
            chunk_size=chunk_size,
        )

        return y

    @staticmethod
    def backward(ctx, dy: torch.Tensor) -> tuple[torch.Tensor | None, ...]:
        # import here to avoid circular dependency
        from fla.modules.causal_conv1d import causal_conv1d_bwd

        x, weight, bias, residual, initial_state = ctx.saved_tensors
        group = ctx.group
        W = ctx.W

        # call original backward
        dx, dw, db, dr, dh0 = causal_conv1d_bwd(
            x=x,
            dy=dy,
            dht=None,
            weight=weight,
            bias=bias,
            residual=residual,
            initial_state=initial_state,
            activation=ctx.activation,
            cu_seqlens=ctx.cu_seqlens,
            cu_seqlens_cpu=ctx.cu_seqlens_cpu,
            chunk_indices=ctx.chunk_indices,
            chunk_size=ctx.chunk_size,
        )

        # correct dx gradients for CP
        CausalConv1dFunctionCP._correct_dx_for_cp(dx=dx, dh0=dh0, W=W, group=group, cp_context=ctx.cp_context)

        return dx, dw, db, None, None, None, None, None, dr


def causal_conv1d_cp(
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor | None = None,
    activation: str | None = None,
    chunk_indices: torch.Tensor | None = None,
    cp_context: FLACPContext | None = None,
    chunk_size: int | None = None,
    backend: str = 'triton',
    residual: torch.Tensor | None = None,
) -> torch.Tensor:
    """Apply causal convolution with cross-rank history and gradient exchange.

    Args:
        x (torch.Tensor):
            Local input of shape `[1, T, D]`.
        weight (torch.Tensor):
            Convolution weights of shape `[D, W]`.
        bias (torch.Tensor, Optional):
            Bias of shape `[D]`. Default: `None`.
        activation (str, Optional):
            Output activation: `None`, `silu`, or `swish`. Default: `None`.
        chunk_indices (torch.Tensor, Optional):
            Precomputed chunk indices for the Triton backend. Default: `None`.
        cp_context (FLACPContext, Optional):
            Required CP context with cumulative sequence lengths and convolution width. Default: `None`.
        chunk_size (int, Optional):
            Triton chunk size; `None` selects 64. Default: `None`.
        backend (str, Optional):
            Convolution backend: `triton`, `cuda`, or `mix`. `mix` retains the Triton CP path.
            CUDA requires contiguous layout, width 2–4, and at least `W - 1` tokens per rank. Default: `'triton'`.
        residual (torch.Tensor, Optional):
            Residual added to the output, of shape `[1, T, D]`. Default: `None`.

    Returns:
        torch.Tensor:
            Local output of shape `[1, T, D]`.
    """
    if cp_context is None:
        raise ValueError("cp_context must be provided for causal_conv1d_cp")

    assert cp_context.conv1d_kernel_size is not None, "conv1d_kernel_size must be provided for causal_conv1d_cp"
    assert cp_context.cu_seqlens is not None, "cu_seqlens must be provided for causal_conv1d_cp"
    if backend == 'mix':
        backend = 'triton'
    if backend not in ('triton', 'cuda'):
        raise ValueError(f"Unsupported CP convolution backend: {backend!r}; expected 'triton', 'cuda', or 'mix'")
    if backend == 'cuda':
        from fla.modules.causal_conv1d.backends.cuda.cp import causal_conv1d_cuda_cp

        return causal_conv1d_cuda_cp(
            x=x,
            weight=weight,
            bias=bias,
            residual=residual,
            activation=activation,
            cp_context=cp_context,
        )

    chunk_size = chunk_size or 64
    if chunk_indices is None:
        chunk_indices = prepare_chunk_indices(
            cu_seqlens=cp_context.cu_seqlens,
            chunk_size=chunk_size,
            cu_seqlens_cpu=cp_context.cu_seqlens_cpu,
        )

    return CausalConv1dFunctionCP.apply(x, weight, bias, activation, chunk_indices, cp_context, chunk_size, backend, residual)
