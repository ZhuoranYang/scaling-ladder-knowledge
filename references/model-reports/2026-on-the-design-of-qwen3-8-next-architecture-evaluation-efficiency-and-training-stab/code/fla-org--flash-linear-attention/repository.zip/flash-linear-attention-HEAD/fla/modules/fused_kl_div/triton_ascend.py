# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

"""Fused KL divergence kernels adapted for triton-ascend on Huawei NPU."""

import torch
import torch.nn.functional as F
import triton
import triton.language as tl

from fla.backends import TritonAscendBackend, register
from fla.modules.fused_kl_div.ops import fused_kl_div_bwd, fused_kl_div_fwd
from fla.ops.utils.op import exp, log
from fla.utils.ascend_ub_manager import ASCEND_MAX_GRID_DIM, compute_elementwise_block_size, compute_vocab_block_size

_KLD_FWD_MEM_MULT = 12.0
_ELEMENTWISE_MEM_MULT = 2.5
STATIC_WARPS = 2


@triton.jit
def kl_div_kernel(
    logits,
    target_logits,
    loss,
    s_logits,
    s_loss,
    reduction: tl.constexpr,
    N: tl.constexpr,
    V: tl.constexpr,
    BV: tl.constexpr,
):
    i_n = tl.program_id(0).to(tl.int64)

    logits += i_n * s_logits
    target_logits += i_n * s_logits

    sm = float('-inf')
    tm = float('-inf')
    sd, td = 0.0, 0.0

    NV = tl.cdiv(V, BV)
    for iv in range(0, NV):
        o_x = iv * BV + tl.arange(0, BV)
        b_sl = tl.load(logits + o_x, mask=o_x < V, other=float('-inf'))
        b_sm = tl.max(b_sl)
        m_new = tl.maximum(sm, b_sm)
        sd = sd * exp(sm - m_new) + tl.sum(exp(b_sl - m_new))
        sm = m_new

        b_tl = tl.load(target_logits + o_x, mask=o_x < V, other=float('-inf'))
        b_tm = tl.max(b_tl)
        m_new = tl.maximum(tm, b_tm)
        td = td * exp(tm - m_new) + tl.sum(exp(b_tl - m_new))
        tm = m_new

    b_loss = 0.
    for iv in range(0, NV):
        o_x = iv * BV + tl.arange(0, BV)
        b_sl = tl.load(logits + o_x, mask=o_x < V, other=float('-inf'))
        b_tl = tl.load(target_logits + o_x, mask=o_x < V, other=float('-inf'))
        b_sp_log = b_sl - sm - log(sd)
        b_tp_log = b_tl - tm - log(td)
        b_sp = exp(b_sp_log)
        b_tp = exp(b_tp_log)
        b_kl = tl.where(o_x < V, b_tp * (b_tp_log - b_sp_log), 0)
        b_dl = -b_tp + b_sp
        b_loss += tl.sum(b_kl)
        if reduction == 'batchmean':
            b_dl = b_dl / N
        tl.store(logits + o_x, b_dl, mask=o_x < V)

    if reduction == 'batchmean':
        b_loss = b_loss / N

    tl.store(loss + i_n * s_loss, b_loss)


@triton.jit
def elementwise_mul_kernel(x, g, N: tl.constexpr, B: tl.constexpr):
    i_x = tl.program_id(0).to(tl.int64)
    o_x = i_x * B + tl.arange(0, B)

    b_g = tl.load(g)
    if b_g == 1.0:
        return
    b_x = tl.load(x + o_x, mask=o_x < N)
    tl.store(x + o_x, b_x * b_g, mask=o_x < N)


def _npu_vocab_block_size(vocab_size: int, num_rows: int) -> int:
    return compute_vocab_block_size(vocab_size=vocab_size, num_rows=num_rows, memory_multiplier=_KLD_FWD_MEM_MULT)


@register(fused_kl_div_fwd, backend=TritonAscendBackend)
def fused_kl_div_fwd_npu(
    x: torch.Tensor,
    target_x: torch.Tensor,
    weight: torch.Tensor,
    target_weight: torch.Tensor,
    reduction: str = 'batchmean',
    accumulate_grad_in_fp32: bool = True,
    use_dx: bool = True,
    use_dw: bool = True,
):
    device = x.device

    N, H, V = *x.shape, weight.shape[0]
    BV = _npu_vocab_block_size(vocab_size=V, num_rows=N)
    NC = min(8, triton.cdiv(V, H))
    C = min(triton.next_power_of_2(triton.cdiv(N, NC)), ASCEND_MAX_GRID_DIM)
    NC = triton.cdiv(N, C)

    grad_dtype = torch.float32 if accumulate_grad_in_fp32 else weight.dtype

    dx = torch.zeros_like(x, device=device) if use_dx else None
    dw = torch.zeros_like(weight, device=device, dtype=grad_dtype) if use_dw else None
    loss = torch.zeros(N, dtype=torch.float32, device=device)

    for ic in range(NC):
        start, end = ic * C, min((ic + 1) * C, N)
        c_sx = x[start:end]
        c_tx = target_x[start:end]
        c_sl = F.linear(c_sx, weight)
        c_tl = F.linear(c_tx, target_weight)
        if dw is not None and c_sx.dtype != grad_dtype:
            c_sx = c_sx.to(dtype=grad_dtype)

        c_loss = loss[start:end]

        kl_div_kernel[(c_sx.shape[0],)](
            logits=c_sl,
            target_logits=c_tl,
            loss=c_loss,
            s_logits=c_sl.stride(-2),
            s_loss=c_loss.stride(-1),
            reduction=reduction,
            N=N,
            V=V,
            BV=BV,
            num_warps=STATIC_WARPS,
        )

        c_grad = c_sl if c_sl.is_contiguous() else c_sl.contiguous()
        if dx is not None:
            dx[start:end] = torch.mm(c_grad, weight)

        if dw is not None:
            grad_w = c_grad.t().to(dtype=grad_dtype)
            grad_x = c_sx if c_sx.dtype == grad_dtype else c_sx.to(dtype=grad_dtype)
            dw.add_(grad_w @ grad_x)

    loss = loss.sum()
    if dw is not None:
        dw = dw.to(weight)
    return loss, dx, dw


@register(fused_kl_div_bwd, backend=TritonAscendBackend)
def fused_kl_div_bwd_npu(do: torch.Tensor, dx: torch.Tensor | None, dw: torch.Tensor | None):
    for grad in (dx, dw):
        if grad is None:
            continue
        N, H = grad.shape
        B = compute_elementwise_block_size(n_elements=N * H, memory_multiplier=_ELEMENTWISE_MEM_MULT)
        elementwise_mul_kernel[(triton.cdiv(N * H, B),)](x=grad, g=do, N=N*H, B=B, num_warps=STATIC_WARPS,)

    return dx, dw
