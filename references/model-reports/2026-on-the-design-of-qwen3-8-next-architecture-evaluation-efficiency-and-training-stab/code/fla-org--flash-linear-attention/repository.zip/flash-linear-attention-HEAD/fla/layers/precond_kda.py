# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import torch
import torch.nn as nn
from einops import rearrange, repeat
from torch.nn import functional as F

from fla.layers.utils import (
    get_layer_cache,
    repad_hidden_states,
    unpad_hidden_states,
    update_layer_cache,
)
from fla.modules import FusedRMSNormGated, ShortConvolution
from fla.ops.kda.gate import fused_kda_gate
from fla.ops.precond_kda import chunk_precond_kda, fused_recurrent_precond_kda

if TYPE_CHECKING:
    from transformers.processing_utils import Unpack

    from fla.models.cache_utils import Cache


class PrecondKDA(nn.Module):
    """
    Preconditioned KDA (PrecondKDA) layer implementation.

    Reference: `Preconditioned DeltaNet: Curvature-aware Sequence Modeling for Linear Recurrences <https://arxiv.org/abs/2604.21100>`_

    Each layer contains around ``hidden_size * key_dim * 2 + hidden_size * value_dim * 3`` parameters
    (q/k projections + v/g/o projections), plus the low-rank f_proj bottleneck and ATK projections.

    Args:
        hidden_size (int, Optional):
            The hidden size of the input. Default: 2048.
        expand_v (float, Optional):
            The expansion ratio for the value dimension. Default: 1.0.
        head_dim (int, Optional):
            The dimension of each head. Default: 128.
        num_heads (int, Optional):
            The number of heads. Default: 16.
        num_v_heads (int, Optional):
            The number of heads for the value projection, equal to `num_heads` if `None`.
            GVA (Grouped Value Attention) is applied if `num_v_heads` > `num_heads`,
            where `num_v_heads` must be divisible by `num_heads`. Default: `None`.
        mode (str, Optional):
            Which PrecondKDA kernel to use.
            Currently available: `chunk` and `fused_recurrent`.
            Default: `chunk`.
        use_short_conv (bool, Optional):
            Whether to use short convolutions. Default: `True`.
        allow_neg_eigval (bool, Optional):
            Allow negative eigenvalues. Default: `False`. If set to `True`, the beta will be multiplied by 2.
            See reference:
            `Unlocking State-Tracking in Linear RNNs Through Negative Eigenvalues <https://arxiv.org/abs/2411.12537>`_
        conv_size (int, Optional):
            The kernel size of the short convolution, only used when `use_short_conv` is `True`. Default: 4.
        conv_bias (bool, Optional):
            Whether to use bias in the short convolution, only used when `use_short_conv` is `True`. Default: `False`.
        safe_gate (bool, Optional):
            Whether the kernel can assume the gate values (in log space) are in ``[lower_bound, 0)``
            and use M=16 TensorCore acceleration. Requires ``lower_bound`` to be set.
            See :func:`chunk_precond_kda` for details. Default: ``False``.
        lower_bound (float, Optional):
            Lower bound for the forget gate in log space. Clamps the gate output to ``[lower_bound, 0)``.
            With ``-5``, the per-step decay ``exp(g) ≈ 0.0067`` at minimum — negligible impact on quality.
            See :func:`chunk_precond_kda` for details. Default: ``None``.
        layer_idx (int, Optional):
            The index of the layer. Default: None.
        norm_eps (float, Optional):
            The epsilon value for the normalization layer. Default: 1e-5.
        squash_x (float, Optional):
            The squash range parameter. Squashes preconditioner onto interval [1/x, x].
            Needs to be <= 2.0 for eigenstability. Default: 1.5.
        squash_eps (float, Optional):
            The epsilon for numerical stability in the squash function. Default: 1e-6.
        log_atk_scale_init (float, Optional):
            The initial value for the learnable per-head log_atk_scale parameter. Default: -0.2.
    """

    def __init__(
        self,
        hidden_size: int = 2048,
        expand_v: float = 1,
        head_dim: int = 128,
        num_heads: int = 16,
        num_v_heads: int = None,
        mode: str = "chunk",
        use_short_conv: bool = True,
        allow_neg_eigval: bool = False,
        safe_gate: bool = False,
        lower_bound: float | None = None,
        conv_size: int = 4,
        conv_bias: bool = False,
        layer_idx: int = None,
        norm_eps: float = 1e-5,
        squash_x: float = 1.5,
        squash_eps: float = 1e-6,
        log_atk_scale_init: float = -0.2,
        **kwargs,
    ) -> PrecondKDA:
        super().__init__()

        self.mode = mode
        self.allow_neg_eigval = allow_neg_eigval
        self.safe_gate = safe_gate
        self.lower_bound = lower_bound
        self.hidden_size = hidden_size
        self.expand_v = expand_v

        self.use_short_conv = use_short_conv
        self.conv_size = conv_size
        self.conv_bias = conv_bias

        self.head_dim = head_dim
        self.num_heads = num_heads
        self.num_v_heads = num_v_heads if num_v_heads is not None else num_heads

        self.head_k_dim = head_dim
        self.head_v_dim = int(self.head_dim * self.expand_v)
        self.key_dim = int(self.num_heads * self.head_k_dim)
        self.value_dim = int(self.num_v_heads * self.head_v_dim)
        self.layer_idx = layer_idx

        self.squash_x_val = squash_x
        self.squash_eps = squash_eps
        self.log_atk_scale_init = log_atk_scale_init

        # Consistency check: Ensure expand_v produces integer values
        if not math.isclose(self.num_v_heads * self.head_dim * expand_v, self.value_dim, rel_tol=1e-5):
            raise ValueError(
                f"expand_v={expand_v} does not produce an integer value when multiplied by key_dim={self.key_dim}. "
                f"Resulting value_dim would be {self.num_v_heads * self.head_dim * expand_v}, which is invalid for nn.Linear.",
            )
        if self.num_v_heads > self.num_heads and self.num_v_heads % self.num_heads != 0:
            raise ValueError(
                f"num_v_heads={self.num_v_heads} must be divisible by num_heads={self.num_heads}.",
            )

        if not math.isclose(head_dim * expand_v, self.head_v_dim, rel_tol=1e-5):
            raise ValueError(
                f"expand_v={expand_v} does not produce an integer value when multiplied by head_dim={head_dim}. "
                f"Resulting head_v_dim would be {head_dim * expand_v}, which is invalid for FusedRMSNormGated.",
            )
        assert mode in ["chunk", "fused_recurrent"], f"Not supported mode `{mode}`."

        self.q_proj = nn.Linear(hidden_size, self.key_dim, bias=False)
        self.k_proj = nn.Linear(hidden_size, self.key_dim, bias=False)
        self.v_proj = nn.Linear(hidden_size, self.value_dim, bias=False)

        # ATK gate projection (scalar per head)
        self.a_proj = nn.Linear(hidden_size, self.num_v_heads, bias=False)

        # KDA gate projection (diagonal - per dimension, 2-layer MLP)
        self.f_proj = nn.Sequential(
            nn.Linear(hidden_size, self.head_v_dim, bias=False),
            nn.Linear(self.head_v_dim, self.num_v_heads * self.head_k_dim, bias=False),
        )

        self.b_atk_proj = nn.Linear(hidden_size, self.num_v_heads, bias=False)
        self.b_proj = nn.Linear(hidden_size, self.num_heads, bias=False)

        A_atk = torch.empty(self.num_v_heads, dtype=torch.float32).uniform_(1, 16)
        self.A_log_atk = nn.Parameter(torch.log(A_atk))
        self.A_log_atk._no_weight_decay = True

        dt_min = 0.001
        dt_max = 0.1
        dt_init_floor = 1e-4
        dt_atk = torch.exp(
            torch.rand(self.num_v_heads) * (math.log(dt_max) - math.log(dt_min))
            + math.log(dt_min),
        )
        dt_atk = torch.clamp(dt_atk, min=dt_init_floor)
        inv_dt_atk = dt_atk + torch.log(-torch.expm1(-dt_atk))
        self.dt_bias_atk = nn.Parameter(inv_dt_atk)
        self.dt_bias_atk._no_weight_decay = True

        if safe_gate:
            self.A_log = nn.Parameter(torch.zeros(self.num_v_heads, dtype=torch.float32))
        else:
            self.A_log = nn.Parameter(torch.log(torch.empty(self.num_v_heads, dtype=torch.float32).uniform_(1, 16)))
        self.A_log._no_weight_decay = True
        self.dt_bias = nn.Parameter(torch.zeros(self.num_v_heads * self.head_k_dim, dtype=torch.float32))
        self.dt_bias._no_weight_decay = True

        self.log_atk_scale = nn.Parameter(
            torch.full((self.num_v_heads,), self.log_atk_scale_init, dtype=torch.float32)
        )
        self.log_atk_scale._no_weight_decay = True

        if use_short_conv:
            self.q_conv1d = ShortConvolution(
                hidden_size=self.key_dim,
                kernel_size=conv_size,
                bias=conv_bias,
                activation="silu",
            )
            self.k_conv1d = ShortConvolution(
                hidden_size=self.key_dim,
                kernel_size=conv_size,
                bias=conv_bias,
                activation="silu",
            )
            self.v_conv1d = ShortConvolution(
                hidden_size=self.value_dim,
                kernel_size=conv_size,
                bias=conv_bias,
                activation="silu",
            )

        self.g_proj = nn.Sequential(
            nn.Linear(hidden_size, self.head_v_dim, bias=False),
            nn.Linear(self.head_v_dim, self.value_dim, bias=True),
        )
        self.o_norm = FusedRMSNormGated(self.head_v_dim, activation="sigmoid", eps=norm_eps)
        self.o_proj = nn.Linear(self.value_dim, hidden_size, bias=False)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor | None = None,
        past_key_values: Cache | None = None,
        use_cache: bool | None = False,
        output_attentions: bool | None = False,
        **kwargs: Unpack[dict],
    ) -> tuple[torch.Tensor, torch.Tensor | None, Cache | None]:
        if attention_mask is not None:
            assert len(attention_mask.shape) == 2, (
                "Expected attention_mask as a 0-1 matrix with shape [batch_size, seq_len] "
                "for padding purposes (0 indicating padding). "
                "Arbitrary attention masks of shape [batch_size, seq_len, seq_len] are not allowed."
            )

        batch_size, q_len, _ = hidden_states.shape

        # change to inference mode.
        if torch.is_grad_enabled():
            mode = "chunk"
        elif q_len <= 64 and not self.training:
            mode = "fused_recurrent"
        else:
            mode = self.mode
        if self.training:
            assert mode == "chunk", "Only chunk mode is supported in training."

        last_state = get_layer_cache(self, past_key_values)

        cu_seqlens = kwargs.get("cu_seqlens")
        hidden_states, indices, cu_seqlens = unpad_hidden_states(
            hidden_states,
            cu_seqlens,
            attention_mask,
            q_len,
        )

        if self.use_short_conv:
            conv_state_q, conv_state_k, conv_state_v = None, None, None
            if last_state is not None:
                conv_state_q, conv_state_k, conv_state_v = last_state["conv_state"]
            q, conv_state_q = self.q_conv1d(
                x=self.q_proj(hidden_states),
                cache=conv_state_q,
                output_final_state=use_cache,
                cu_seqlens=cu_seqlens,
            )
            k, conv_state_k = self.k_conv1d(
                x=self.k_proj(hidden_states),
                cache=conv_state_k,
                output_final_state=use_cache,
                cu_seqlens=cu_seqlens,
            )
            v, conv_state_v = self.v_conv1d(
                x=self.v_proj(hidden_states),
                cache=conv_state_v,
                output_final_state=use_cache,
                cu_seqlens=cu_seqlens,
            )
        else:
            q = F.silu(self.q_proj(hidden_states))
            k = F.silu(self.k_proj(hidden_states))
            v = F.silu(self.v_proj(hidden_states))

        g = self.f_proj(hidden_states)
        beta = self.b_proj(hidden_states).sigmoid()

        q, k, g = (rearrange(x, "... (h d) -> ... h d", d=self.head_k_dim) for x in (q, k, g))
        v = rearrange(v, "... (h d) -> ... h d", d=self.head_v_dim)

        # for multi-value attention, we repeat the inputs for simplicity.
        # NOTE: g is projected to num_v_heads heads (via f_proj), so it must NOT be repeated;
        # only the num_heads-shaped q/k/beta are expanded to num_v_heads.
        if self.num_v_heads > self.num_heads:
            q, k = (repeat(x, "... h d -> ... (h g) d", g=self.num_v_heads // self.num_heads) for x in (q, k))
            beta = repeat(beta, "... h -> ... (h g)", g=self.num_v_heads // self.num_heads)

        if self.allow_neg_eigval:
            beta = beta * 2.0

        beta_atk = self.b_atk_proj(hidden_states).sigmoid()
        g_atk = -(self.A_log_atk.float().exp()) * F.softplus(self.a_proj(hidden_states).float() + self.dt_bias_atk)

        recurrent_state = preconditioner_state = None
        if last_state is not None and last_state["recurrent_state"] is not None:
            recurrent_state, preconditioner_state = last_state["recurrent_state"]

        if mode == "chunk":
            g = fused_kda_gate(g=g, A_log=self.A_log, dt_bias=self.dt_bias, lower_bound=self.lower_bound)
            o, recurrent_state, preconditioner_state = chunk_precond_kda(
                q=q,
                k=k,
                v=v,
                g=g,
                beta=beta,
                g_atk=g_atk,
                beta_atk=beta_atk,
                initial_state=recurrent_state,
                initial_A_state=preconditioner_state,
                output_final_state=use_cache,
                use_qk_l2norm_in_kernel=True,
                use_gate_in_kernel=False,
                safe_gate=self.safe_gate,
                lower_bound=self.lower_bound,
                cu_seqlens=cu_seqlens,
                x=self.squash_x_val,
                eps=self.squash_eps,
                log_atk_scale=self.log_atk_scale,
            )
        elif mode == "fused_recurrent":
            g = fused_kda_gate(g=g, A_log=self.A_log, dt_bias=self.dt_bias, lower_bound=self.lower_bound)
            o, recurrent_state, preconditioner_state = fused_recurrent_precond_kda(
                q=q,
                k=k,
                v=v,
                g=g,
                beta=beta,
                g_atk=g_atk,
                beta_atk=beta_atk,
                initial_state=recurrent_state,
                initial_A_state=preconditioner_state,
                output_final_state=use_cache,
                use_qk_l2norm_in_kernel=True,
                cu_seqlens=cu_seqlens,
                x=self.squash_x_val,
                eps=self.squash_eps,
                log_atk_scale=self.log_atk_scale,
            )
        else:
            raise NotImplementedError(f"Not supported mode `{mode}`.")

        update_layer_cache(
            self,
            past_key_values,
            recurrent_state=(recurrent_state, preconditioner_state) if use_cache else None,
            conv_state=(conv_state_q, conv_state_k, conv_state_v) if self.use_short_conv else None,
            offset=q_len,
        )

        o = self.o_norm(o, rearrange(self.g_proj(hidden_states), "... (h d) -> ... h d", d=self.head_v_dim))
        o = rearrange(o, "b t h d -> b t (h d)")
        o = self.o_proj(o)
        o = repad_hidden_states(o, indices, batch_size, q_len)

        return o, None, past_key_values
