# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

import torch
import triton
import triton.language as tl

from fla.backends import dispatch
from fla.ops.utils.op import exp, logaddexp, unflatten_program_id
from fla.utils import autocast_custom_bwd, autocast_custom_fwd, autotune_cache_kwargs, input_guard


@triton.heuristics({
    'IS_VARLEN': lambda args: args['cu_seqlens'] is not None,
    'USE_INITIAL_STATE': lambda args: args['initial_state'] is not None,
    'STORE_Z': lambda args: args['z'] is not None,
})
@triton.autotune(
    configs=[
        triton.Config({'BT': BT}, num_warps=num_warps)
        for BT in [16, 32, 64]
        for num_warps in [2, 4, 8]
    ],
    key=['S'],
    **autotune_cache_kwargs,
)
@triton.jit(do_not_specialize=['T'])
def fused_additive_gate_fwd_kernel(
    x,
    z,
    k,
    g,
    initial_state,
    final_state,
    cu_seqlens,
    T,
    S: tl.constexpr,
    BT: tl.constexpr,
    BS: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
    STORE_Z: tl.constexpr,
):
    i_s, i_n = unflatten_program_id(tl.cdiv(S, BS))
    if IS_VARLEN:
        bos = tl.load(cu_seqlens + i_n).to(tl.int64)
        eos = tl.load(cu_seqlens + i_n + 1).to(tl.int64)
    else:
        bos, eos = i_n * T, (i_n + 1) * T
    T = eos - bos
    o_s = i_s * BS + tl.arange(0, BS)
    o_i = tl.arange(0, BT)
    m_s = o_s < S
    p_x = x + bos * S + o_s
    p_k = k + bos * S + o_s
    p_g = g + bos * S + o_s
    if STORE_Z:
        p_z = z + bos * S + o_s
    if USE_INITIAL_STATE:
        b_zp = tl.load(initial_state + i_n * S + o_s, mask=m_s, other=float('-inf')).to(tl.float32)
    else:
        b_zp = tl.full((BS,), float('-inf'), tl.float32)
    for i_t in range(0, T, BT):
        o_t = i_t + o_i
        m_x = (o_t[:, None] < T) & m_s[None, :]
        b_x = tl.load(p_x + o_t[:, None] * S, mask=m_x, other=float('-inf')).to(tl.float32)
        b_z = tl.associative_scan(b_x, axis=0, combine_fn=logaddexp)
        b_z = logaddexp(b_z, b_zp[None, :])
        o_prev = tl.broadcast_to(tl.maximum(o_i - 1, 0)[:, None], (BT, BS))
        b_zc = tl.gather(b_z, o_prev, axis=0)
        b_zc = tl.where(o_i[:, None] == 0, b_zp[None, :], b_zc)
        b_k = exp(b_x - b_z)
        b_g = tl.where(b_zc == float('-inf'), 0., b_zc - b_z)
        tl.store(p_k + o_t[:, None] * S, b_k, mask=m_x)
        tl.store(p_g + o_t[:, None] * S, b_g, mask=m_x)
        if STORE_Z:
            tl.store(p_z + o_t[:, None] * S, b_z, mask=m_x)
        o_last = tl.minimum(i_t + BT, T) - 1
        b_zp = tl.sum(tl.where(o_t[:, None] == o_last, b_z, 0.), axis=0)
    tl.store(final_state + i_n * S + o_s, b_zp, mask=m_s)


@triton.jit
def _reverse_recurrence(a_left, b_left, a_right, b_right):
    return a_left * a_right, b_left * a_right + b_right


@triton.heuristics({
    'IS_VARLEN': lambda args: args['cu_seqlens'] is not None,
    'USE_INITIAL_STATE': lambda args: args['initial_state'] is not None,
    'HAS_DK': lambda args: args['dk'] is not None,
    'HAS_DG': lambda args: args['dg'] is not None,
    'USE_FINAL_STATE_GRADIENT': lambda args: args['dfinal_state'] is not None,
})
@triton.jit(do_not_specialize=['T'])
def fused_additive_gate_bwd_kernel(
    x,
    z,
    initial_state,
    cu_seqlens,
    dk,
    dg,
    dfinal_state,
    dx,
    dinitial_state,
    T,
    S: tl.constexpr,
    BT: tl.constexpr,
    BS: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
    HAS_DK: tl.constexpr,
    HAS_DG: tl.constexpr,
    USE_FINAL_STATE_GRADIENT: tl.constexpr,
):
    i_s, i_n = unflatten_program_id(tl.cdiv(S, BS))
    if IS_VARLEN:
        bos = tl.load(cu_seqlens + i_n).to(tl.int64)
        eos = tl.load(cu_seqlens + i_n + 1).to(tl.int64)
    else:
        bos, eos = i_n * T, (i_n + 1) * T
    T = eos - bos
    o_s = i_s * BS + tl.arange(0, BS)
    o_i = tl.arange(0, BT)
    m_s = o_s < S
    p_x = x + bos * S + o_s
    p_z = z + bos * S + o_s
    if HAS_DK:
        p_dk = dk + bos * S + o_s
    if HAS_DG:
        p_dg = dg + bos * S + o_s
    p_dx = dx + bos * S + o_s
    if USE_INITIAL_STATE:
        b_z0 = tl.load(initial_state + i_n * S + o_s, mask=m_s, other=float('-inf')).to(tl.float32)
    else:
        b_z0 = tl.full((BS,), float('-inf'), tl.float32)
    b_dzp = tl.full((BS,), 0., tl.float32)
    if USE_FINAL_STATE_GRADIENT:
        b_dzt = tl.load(dfinal_state + i_n * S + o_s, mask=m_s, other=0.).to(tl.float32)
    else:
        b_dzt = tl.zeros((BS,), tl.float32)
    for i_t in range(0, T, BT):
        o_t = T - 1 - i_t - o_i
        m_x = (o_t[:, None] >= 0) & m_s[None, :]
        m_next = m_x & (o_t[:, None] + 1 < T)
        b_x = tl.load(p_x + o_t[:, None] * S, mask=m_x, other=0.).to(tl.float32)
        b_z = tl.load(p_z + o_t[:, None] * S, mask=m_x, other=0.)
        b_zn = tl.load(p_z + (o_t[:, None] + 1) * S, mask=m_next, other=0.)
        b_k = exp(b_x - b_z)
        if HAS_DK:
            b_dk = tl.load(p_dk + o_t[:, None] * S, mask=m_x, other=0.).to(tl.float32)
        else:
            b_dk = tl.zeros((BT, BS), tl.float32)
        b_dzc = -b_dk * b_k
        if HAS_DG:
            b_dg = tl.load(p_dg + o_t[:, None] * S, mask=m_x, other=0.).to(tl.float32)
            b_dgn = tl.load(p_dg + (o_t[:, None] + 1) * S, mask=m_next, other=0.).to(tl.float32)
            b_dg = tl.where((o_t[:, None] > 0) | (b_z0[None, :] != float('-inf')), b_dg, 0.)
            b_dzc += b_dgn - b_dg
        b_dzc += tl.where(o_t[:, None] == T - 1, b_dzt[None, :], 0.)
        # all exponent differences in the reverse recurrence are nonpositive.
        b_r = exp(tl.where(m_next, b_z - b_zn, 0.))
        b_r, b_dzc = tl.associative_scan((b_r, b_dzc), axis=0, combine_fn=_reverse_recurrence)
        b_dz = b_dzc + b_r * b_dzp[None, :]
        tl.store(p_dx + o_t[:, None] * S, b_k * (b_dk + b_dz), mask=m_x)
        o_last = tl.full((1, BS), tl.minimum(T - i_t, BT) - 1, tl.int32)
        b_dzp = tl.gather(b_dz, o_last, axis=0).reshape((BS,))
    if USE_INITIAL_STATE:
        if T > 0:
            b_z1 = tl.load(p_z, mask=m_s, other=0.)
            b_dz0 = exp(b_z0 - b_z1) * b_dzp
            if HAS_DG:
                b_dg0 = tl.load(p_dg, mask=m_s, other=0.).to(tl.float32)
                b_dz0 += tl.where(b_z0 != float('-inf'), b_dg0, 0.)
        else:
            b_dz0 = b_dzt
        tl.store(dinitial_state + i_n * S + o_s, b_dz0, mask=m_s)


def fused_additive_gate_fwd(
    x: torch.Tensor,
    initial_state: torch.Tensor | None,
    cu_seqlens: torch.Tensor | None,
    save_z: bool,
    output_dtype: torch.dtype | None = None,
    gate_dtype: torch.dtype | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor | None]:
    B, T, H, K = x.shape
    N = B if cu_seqlens is None else cu_seqlens.numel() - 1
    S, BS = H * K, 32
    k = torch.empty_like(x, dtype=output_dtype or x.dtype)
    g = torch.empty_like(x, dtype=gate_dtype or x.dtype)
    z = torch.empty_like(x, dtype=torch.float32) if save_z else None
    final_state = x.new_empty((N, 1, H, K), dtype=torch.float32)
    fused_additive_gate_fwd_kernel[(N * triton.cdiv(S, BS),)](
        x=x,
        z=z,
        k=k,
        g=g,
        initial_state=initial_state,
        final_state=final_state,
        cu_seqlens=cu_seqlens,
        T=T,
        S=S,
        BS=BS,
    )
    return k, g, final_state, z


def fused_additive_gate_bwd(
    x: torch.Tensor,
    z: torch.Tensor,
    initial_state: torch.Tensor | None,
    cu_seqlens: torch.Tensor | None,
    dk: torch.Tensor | None,
    dg: torch.Tensor | None,
    dfinal_state: torch.Tensor | None,
) -> tuple[torch.Tensor, torch.Tensor | None]:
    B, T, H, K = x.shape
    N = B if cu_seqlens is None else cu_seqlens.numel() - 1
    S, BS = H * K, 32
    dx = torch.empty_like(x)
    dinitial_state = torch.empty_like(initial_state) if initial_state is not None else None
    fused_additive_gate_bwd_kernel[(N * triton.cdiv(S, BS),)](
        x=x,
        z=z,
        initial_state=initial_state,
        cu_seqlens=cu_seqlens,
        dk=dk,
        dg=dg,
        dfinal_state=dfinal_state,
        dx=dx,
        dinitial_state=dinitial_state,
        T=T,
        S=S,
        BT=32,
        BS=BS,
    )
    return dx, dinitial_state


class FusedAdditiveGateFunction(torch.autograd.Function):

    @staticmethod
    @input_guard
    @autocast_custom_fwd
    def forward(ctx, x, initial_state, cu_seqlens, output_dtype, gate_dtype):
        k, g, final_state, z = fused_additive_gate_fwd(
            x=x,
            initial_state=initial_state,
            cu_seqlens=cu_seqlens,
            save_z=ctx.needs_input_grad[0] or ctx.needs_input_grad[1],
            output_dtype=output_dtype,
            gate_dtype=gate_dtype,
        )
        ctx.save_for_backward(x, z, initial_state, cu_seqlens)
        ctx.set_materialize_grads(False)
        return k, g, final_state

    @staticmethod
    @input_guard
    @autocast_custom_bwd
    def backward(ctx, dk, dg, dfinal_state):
        x, z, initial_state, cu_seqlens = ctx.saved_tensors
        dx, dinitial_state = fused_additive_gate_bwd(
            x=x,
            z=z,
            initial_state=initial_state,
            cu_seqlens=cu_seqlens,
            dk=dk,
            dg=dg,
            dfinal_state=dfinal_state,
        )
        return dx, dinitial_state, None, None, None


@dispatch
def fused_additive_gate(
    x: torch.Tensor,
    initial_state: torch.Tensor | None = None,
    cu_seqlens: torch.Tensor | None = None,
    output_dtype: torch.dtype | None = None,
    gate_dtype: torch.dtype | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Compute additive input and log-forget gates from cumulative exponential scores.

    Args:
        x (torch.Tensor):
            Logits of shape `[B, T, H, K]`. Packed inputs have `B=1`.
        initial_state (torch.Tensor, Optional):
            FP32 log-normalizers of shape `[N, 1, H, K]`, where `N` is the number of sequences. Default: `None`.
        cu_seqlens (torch.Tensor, Optional):
            Cumulative lengths of the packed sequences, including empty sequences. Default: `None`.
        output_dtype (torch.dtype, Optional):
            Dtype of the normalized output. Default: the input dtype.
        gate_dtype (torch.dtype, Optional):
            Dtype of the log-decay gates. Default: the input dtype.

    Returns:
        k (torch.Tensor):
            Normalized values with the shape of `x` and the requested output dtype.
        g (torch.Tensor):
            Log-decay gates with the shape of `x` and the requested gate dtype. An empty prefix has a zero first gate.
        final_state (torch.Tensor):
            FP32 log-normalizers of shape `[N, 1, H, K]`. Empty sequences preserve `initial_state`,
            or return `-inf` without one. Gradients are supported for `x` and `initial_state`.
    """
    if cu_seqlens is not None and x.shape[0] != 1:
        raise ValueError("Packed inputs with cu_seqlens must have batch size 1.")
    if initial_state is not None:
        N = x.shape[0] if cu_seqlens is None else cu_seqlens.numel() - 1
        expected_shape = (N, 1, *x.shape[2:])
        if initial_state.shape != expected_shape:
            raise ValueError(f"initial_state must have shape {expected_shape}, got {tuple(initial_state.shape)}.")
    return FusedAdditiveGateFunction.apply(x, initial_state, cu_seqlens, output_dtype, gate_dtype)
