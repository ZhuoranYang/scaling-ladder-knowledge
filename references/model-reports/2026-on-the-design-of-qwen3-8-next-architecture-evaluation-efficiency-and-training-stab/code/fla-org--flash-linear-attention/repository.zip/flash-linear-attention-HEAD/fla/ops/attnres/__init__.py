# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

from fla.backends import GluonBackend, TritonAscendBackend
from fla.ops.attnres.fused import fused_attnres
from fla.ops.attnres.naive import naive_attnres

__all__ = [
    'fused_attnres',
    'naive_attnres',
]


if GluonBackend.is_available():
    from fla.ops.attnres.backends import gluon  # noqa: F401

if TritonAscendBackend.is_available():
    from fla.ops.attnres.backends import triton_ascend  # noqa: F401
