# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

from fla.backends import TritonAscendBackend
from fla.modules.fused_linear_cross_entropy.ops import (
    FusedLinearCrossEntropyLoss,
    LinearLossParallel,
    fused_linear_cross_entropy_loss,
)

__all__ = ['FusedLinearCrossEntropyLoss', 'LinearLossParallel', 'fused_linear_cross_entropy_loss']


if TritonAscendBackend.is_available():
    from fla.modules.fused_linear_cross_entropy import triton_ascend  # noqa: F401
