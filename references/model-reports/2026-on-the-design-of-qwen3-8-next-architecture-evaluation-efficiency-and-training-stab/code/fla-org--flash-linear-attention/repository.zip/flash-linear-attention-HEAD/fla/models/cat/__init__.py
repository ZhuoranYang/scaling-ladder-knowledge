# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors
#
# Contributed by: Jatin Prakash (bicycleman15)
# Controllably Efficient Language Models (https://arxiv.org/abs/2511.05313)

from transformers import AutoConfig, AutoModel, AutoModelForCausalLM

from fla.models.cat.configuration_cat import CATConfig
from fla.models.cat.modeling_cat import CATForCausalLM, CATModel

AutoConfig.register(CATConfig.model_type, CATConfig, exist_ok=True)
AutoModel.register(CATConfig, CATModel, exist_ok=True)
AutoModelForCausalLM.register(CATConfig, CATForCausalLM, exist_ok=True)

__all__ = ['CATConfig', 'CATForCausalLM', 'CATModel']
