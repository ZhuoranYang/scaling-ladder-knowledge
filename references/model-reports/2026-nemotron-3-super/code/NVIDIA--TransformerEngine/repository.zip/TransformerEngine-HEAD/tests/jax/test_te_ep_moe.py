# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.

"""Multi-process (one-GPU-per-process) tests for the TE-EP MoE custom_vjp.

The launcher ``tests/jax/run_te_ep_moe.sh`` forks one pytest process per
visible GPU. Each process binds to exactly one device via
``jax.distributed.initialize(..., local_device_ids=process_id)``; the
participating processes form a global ``(ep, fsdp)`` mesh through JAX's
distributed runtime.

How to run
----------

You typically do NOT invoke pytest on this file directly -- use the
launcher, which passes ``--num-process=N --process-id=i`` to each
forked process. Driving it directly with only one process will skip
every test because :func:`jax.distributed.initialize` requires
multiple participants, and the TE EP NCCL primitives require at
least four ranks.

    bash tests/jax/run_te_ep_moe.sh

What this suite covers
----------------------

Each test exercises one MoE-block run and bundles every check that
single run supports — shape, dtype,
finiteness AND numerical parity vs a pure-JAX reference. Variations
on the block are pytest parametrize values rather than separate test
classes. The module-scoped fusion parameter runs all unfused cases first,
then tears down EP and runs all cuDNN cases in the same processes:

* ``test_forward`` covers BF16 and MXFP8 forward execution across a
  curated set of configurations (softmax/sigmoid scoring, optional
  non-zero expert_bias). Each config asserts shape, dtype, finiteness
  and numerical parity vs the same BF16 reference in one run.
* ``test_backward`` mirrors that for gradients. BF16 and MXFP8 share
  the full test body and differ only in the grouped-GEMM quantizer sets.
* ``TestTeEpMoeAuxLoss`` covers the second return value end-to-end
  (returned + parity + aux-only grad propagates to gate + combined
  main+aux grads stay finite) in two consolidated tests.
"""

import importlib
import os

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.5")

import sys
from functools import partial

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from jax.experimental import mesh_utils, multihost_utils
from jax.sharding import Mesh, NamedSharding, PartitionSpec as P
from flax.linen import partitioning as nn_partitioning


def _init_distributed(num_process: int, process_id: int) -> bool:
    """Initialize jax.distributed for this pytest process.

    Returns True on a real multi-process launch, False otherwise so
    the module can fast-skip when pytest collects it without the
    launcher.
    """
    if num_process <= 1:
        return False
    coord = os.environ.get("TE_EP_MOE_COORDINATOR_ADDRESS", "127.0.0.1:13457")
    jax.distributed.initialize(
        coordinator_address=coord,
        num_processes=num_process,
        process_id=process_id,
        local_device_ids=process_id,
    )
    assert jax.local_device_count() == 1, "one GPU per process is required for TE EP"
    assert (
        jax.device_count() == num_process
    ), f"global device_count {jax.device_count()} != num_process {num_process}"
    return True


def _read_mp_options():
    num = int(os.environ.get("MP_NUM_PROCESS", "0") or "0")
    pid = int(os.environ.get("MP_PROCESS_ID", "0") or "0")
    for i, a in enumerate(sys.argv):
        if a.startswith("--num-process="):
            num = int(a.split("=", 1)[1])
        elif a == "--num-process" and i + 1 < len(sys.argv):
            num = int(sys.argv[i + 1])
        elif a.startswith("--process-id="):
            pid = int(a.split("=", 1)[1])
        elif a == "--process-id" and i + 1 < len(sys.argv):
            pid = int(sys.argv[i + 1])
    return num, pid


_MP_NUM_PROCESS, _MP_PROCESS_ID = _read_mp_options()
_MP_ACTIVE = _init_distributed(_MP_NUM_PROCESS, _MP_PROCESS_ID)

if not _MP_ACTIVE:
    pytest.skip(
        "test_te_ep_moe.py requires the multiprocess launcher (run_te_ep_moe.sh). Skipping.",
        allow_module_level=True,
    )

from transformer_engine_jax import get_device_compute_capability

# Grouped GEMM in the MoE custom_vjp requires Blackwell (sm_100+). The
# TE EP NCCL primitives themselves need SM>=90, but the FFN body uses
# grouped_gemm, so the file as a whole gates on sm_100+.
if get_device_compute_capability(0) < 100:
    pytest.skip(
        "MoE TE EP tests require Blackwell (sm_100+) for grouped GEMM",
        allow_module_level=True,
    )

from transformer_engine.jax.flax import _MoEBlock as MoEBlock
from transformer_engine.jax.moe import (
    RouterComputationInfo,
    RoutingMapInfo,
    get_moe_recv_capacity_per_rank,
    moe,
    record_ep_bootstrap_signature_for_moe,
)
from transformer_engine.jax.ep import ep_bootstrap, ep_finalize
from transformer_engine.common.recipe import Format, MXFP8BlockScaling
from transformer_engine.jax.sharding import MeshResource, global_shard_guard

# -----------------------------------------------------------------------------
# Mesh / shape config
# -----------------------------------------------------------------------------

EP_AXIS = "ep"
FSDP_AXIS = "fsdp"
EP_SIZE = 2
assert (
    jax.device_count() % EP_SIZE == 0
), f"device_count {jax.device_count()} must be divisible by EP_SIZE={EP_SIZE}"
FSDP_SIZE = jax.device_count() // EP_SIZE
NUM_DEVICES_REQUIRED = EP_SIZE * FSDP_SIZE

LOGICAL_AXIS_RULES = (
    ("exp", EP_AXIS),
    ("expert_weight_fsdp", (EP_AXIS, FSDP_AXIS)),
    ("gated_weight_fsdp", FSDP_AXIS),
    ("embed", FSDP_AXIS),
    ("mlp", None),
    ("batch", (FSDP_AXIS, EP_AXIS)),
)

# Small shapes so the parity tests stay tight on bf16. The block still
# has all four ranks participating in dispatch/combine.
DTYPE = jnp.bfloat16
BATCH = EP_SIZE * FSDP_SIZE * 2  # 8 on 4-GPU, 16 on 8-GPU
SEQ = 32
HIDDEN = 128
INTER = 128
NUM_EXPERTS = 8
TOPK = 2

# MXFP8 grouped GEMMs have measurably more quantization drift than BF16.
# These bounds are rounded slightly above the worst error observed across
# the forward and backward configuration matrix.
FWD_TOLERANCE = {
    "bf16": {"atol": 5e-4, "rtol": 5e-4},
    "mxfp8": {"atol": 7e-3, "rtol": 7e-3},
}
GRAD_FFN_TOLERANCE = {
    "bf16": {"atol": 1e-7, "rtol": 1e-7},
    "mxfp8": {"atol": 1.3e-6, "rtol": 1.3e-6},
}
GRAD_GATE_TOLERANCE = {
    "bf16": {"atol": 7e-8, "rtol": 7e-8},
    "mxfp8": {"atol": 8e-7, "rtol": 8e-7},
}

# Aux loss is computed in float32 from the SAME logits as the routing
# path. Numerical drift between TE-EP and the reference is dominated by
# the bf16-rounded softmax inside the topk kernel.
AUX_TOLERANCE = {"atol": 1e-6, "rtol": 1e-6}


# -----------------------------------------------------------------------------
# Fixtures
# -----------------------------------------------------------------------------


@pytest.fixture(scope="module", params=[False, True], ids=["unfused", "cudnn"], autouse=True)
def use_cudnn_fusion(request):
    """Group every test by fusion mode before changing EP's cached alignment."""
    return request.param


@pytest.fixture(scope="module")
def mesh(use_cudnn_fusion):
    if jax.device_count() < NUM_DEVICES_REQUIRED:
        pytest.skip(
            f"Need >={NUM_DEVICES_REQUIRED} devices for ep={EP_SIZE} x fsdp={FSDP_SIZE};"
            f" have {jax.device_count()}"
        )
    # ``ep`` must be the inner axis: ``ep_bootstrap`` forms NCCL EP groups
    # from consecutive global ranks via ``dp_color = rank // ep_size``, so
    # only an (outer_fsdp, inner_ep) device layout groups ranks correctly.
    devices = mesh_utils.create_device_mesh((FSDP_SIZE, EP_SIZE))
    mesh_obj = Mesh(devices, axis_names=(FSDP_AXIS, EP_AXIS))

    num_procs = jax.process_count()
    max_tokens_per_rank = (BATCH // num_procs) * SEQ
    # Worst-case recv capacity per rank
    # TODO(jberchtold) support configurations other than worst-case by refactoring tests
    # but if possible avoid bootstrap/teardown for each test
    recv_capacity_per_rank = get_moe_recv_capacity_per_rank(
        num_experts=NUM_EXPERTS,
        num_experts_per_tok=TOPK,
        max_tokens_per_rank=max_tokens_per_rank,
        ep_size=EP_SIZE,
        use_cudnn_fusion=use_cudnn_fusion,
    )

    # Eager bootstrap: ep_bootstrap does a host-side NCCL UID allgather
    # and cannot run from inside jax.jit. Sized to the worst-case recv_pr
    # across _CONFIGS so every parametrized config is bootstrap-compatible.
    with mesh_obj, global_shard_guard(MeshResource(ep_resource=EP_AXIS, fsdp_resource=FSDP_AXIS)):
        ep_bootstrap(
            world_size=num_procs,
            rank=jax.process_index(),
            num_experts=NUM_EXPERTS,
            max_tokens_per_rank=max_tokens_per_rank,
            recv_capacity_per_rank=recv_capacity_per_rank,
            hidden_dim=HIDDEN,
            max_token_dtype=DTYPE,
        )
    record_ep_bootstrap_signature_for_moe(
        num_experts=NUM_EXPERTS,
        max_tokens_per_rank=max_tokens_per_rank,
        recv_capacity_per_rank=recv_capacity_per_rank,
        hidden_dim=HIDDEN,
        ep_size=EP_SIZE,
    )
    mode = "cudnn" if use_cudnn_fusion else "unfused"
    try:
        yield mesh_obj
    finally:
        # Every rank finishes the mode before releasing cached EP executables.
        jax.effects_barrier()
        multihost_utils.sync_global_devices(f"te_moe_{mode}_finished")
        ep_finalize()
        multihost_utils.sync_global_devices(f"te_moe_{mode}_finalized")


# -----------------------------------------------------------------------------
# Pure-JAX reference MoE (no EP). Mirrors the exact math of TE's fused
# router primitive (see tests/jax/test_fused_router.py for the same
# reference applied to the standalone router kernel):
#
# softmax + post-softmax (use_pre_softmax=False, the default):
#   1. top_k by raw logits
#   2. softmax over just the K selected logits (so weights sum to 1)
#
# sigmoid + optional expert_bias:
#   1. scores = sigmoid(logits)
#   2. top_k by (scores + expert_bias)  [bias only steers selection]
#   3. weights = scores at top_k positions, normalized when K > 1
#
# Then for both:
#   * weights *= scaling_factor (we leave scaling_factor=1.0 in this
#     suite, matching _make_block's default).
#   * per-expert FFN: silu(layer_w0) * layer_w1 → wo.
# -----------------------------------------------------------------------------


@partial(
    jax.jit,
    static_argnames=(
        "num_experts",
        "num_experts_per_tok",
        "aux_loss_coeff",
        "score_function",
    ),
)
def _pure_jax_moe_reference(
    x,
    gate_kernel,
    wi,
    wo,
    expert_bias=None,
    hash_input_ids=None,
    hash_tid2eid=None,
    *,
    num_experts,
    num_experts_per_tok,
    aux_loss_coeff: float = 0.0,
    score_function: str = "softmax",
    scaling_factor: float = 1.0,
):
    B, S, H = x.shape
    T = B * S
    K = num_experts_per_tok
    x_2d = x.reshape(T, H)

    gate_kernel_cast = gate_kernel.astype(x.dtype)
    logits = (x_2d @ gate_kernel_cast).astype(jnp.float32)  # [T, E]

    if hash_input_ids is not None:
        if score_function != "sqrtsoftplus" or hash_tid2eid is None:
            raise ValueError("Hash reference requires sqrtsoftplus and hash_tid2eid.")
        scores = jnp.sqrt(jax.nn.softplus(logits))
        top_indices = hash_tid2eid.astype(jnp.int32)[hash_input_ids.reshape(-1)]
        weights = jnp.take_along_axis(scores, top_indices, axis=-1)
        weights = weights / (weights.sum(axis=-1, keepdims=True) + 1e-20)
    elif score_function == "softmax":
        # use_pre_softmax=False: topk on raw logits, then softmax over K.
        top_logits, top_indices = jax.lax.top_k(logits, k=K)
        weights = jax.nn.softmax(top_logits, axis=-1)  # [T, K], sums to 1
    elif score_function == "sigmoid":
        scores = jax.nn.sigmoid(logits)  # [T, E]
        if expert_bias is not None and expert_bias.shape != (0,):
            scores_for_routing = scores + expert_bias.astype(jnp.float32)[None, :]
            _, top_indices = jax.lax.top_k(scores_for_routing, k=K)
            weights = jnp.take_along_axis(scores, top_indices, axis=-1)
        else:
            weights, top_indices = jax.lax.top_k(scores, k=K)
        # Sigmoid weights are normalized when K > 1 (matches the kernel).
        if K > 1:
            weights = weights / (weights.sum(axis=-1, keepdims=True) + 1e-20)
    else:
        raise ValueError(f"Unsupported score_function={score_function!r}")
    weights = weights * scaling_factor

    routing_weights_full = jnp.zeros((T, num_experts), dtype=jnp.float32)
    routing_weights_full = routing_weights_full.at[jnp.arange(T)[:, None], top_indices].set(weights)

    # FFN. ``apply_topk_weights_early`` is a fusion knob that doesn't
    # change the math (wo is linear), so the reference is identical for
    # both placements.
    wi_0, wi_1 = jnp.split(wi, 2, axis=-1)
    layer_w0 = jnp.einsum("th,ehm->tem", x_2d, wi_0)
    layer_w1 = jnp.einsum("th,ehm->tem", x_2d, wi_1)
    # Activation runs in x.dtype (typically bf16) to mirror the impl --
    # the impl keeps silu+multiply in the wi GEMM output dtype because
    # storing higher precision than the consumer (wo) GEMM buys nothing.
    intermediate = jax.nn.silu(layer_w0) * layer_w1
    expert_out = jnp.einsum("tem,emh->teh", intermediate, wo)  # [T, E, H]
    output_2d = jnp.einsum("te,teh->th", routing_weights_full.astype(x.dtype), expert_out)
    output = output_2d.reshape(B, S, H).astype(x.dtype)

    if aux_loss_coeff > 0.0:
        if hash_input_ids is not None:
            raise ValueError("Hash routing does not use auxiliary loss.")
        # tex.fused_moe_aux_loss formula (matches the same
        # reference_aux_loss helper from test_fused_router.py). The
        # "aux scores" use the same score_function but always with
        # K-normalised sigmoid (when sigmoid) / plain softmax (when
        # softmax) — see tex.fused_topk_with_score_function_fwd with
        # compute_aux_scores=True.
        if score_function == "softmax":
            aux_scores = jax.nn.softmax(logits, axis=-1)
        else:  # sigmoid
            aux_scores = jax.nn.sigmoid(logits)
            if K > 1:
                aux_scores = aux_scores / (aux_scores.sum(axis=-1, keepdims=True) + 1e-20)
        routing_map = (routing_weights_full > 0).astype(jnp.int32)
        tokens_per_expert = jnp.sum(routing_map, axis=0)  # [E]
        sum_probs_per_expert = jnp.sum(aux_scores, axis=0)  # [E]
        aux_loss = (num_experts * aux_loss_coeff / (K * (T**2))) * jnp.sum(
            sum_probs_per_expert * tokens_per_expert.astype(jnp.float32)
        )
        aux_loss = aux_loss.astype(x.dtype)
    else:
        aux_loss = jnp.zeros((), dtype=x.dtype)
    return output, aux_loss


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------


def _make_block(
    *,
    apply_topk_weights_early=False,
    aux_loss_coeff=0.0,
    use_expert_routing_bias=False,
    score_function="softmax",
    scaling_factor=1.0,
    expert_bias_init=None,
    input_axes=("batch", None, None),
    quantization_recipe=None,
    dispatch_checkpoint_name=None,
    quant_before_fsdp_ag=False,
    mesh_resource=None,
    use_cudnn_fusion,
):
    kwargs = dict(
        num_experts=NUM_EXPERTS,
        num_experts_per_tok=TOPK,
        intermediate_size=INTER,
        mesh_resource=mesh_resource,
        apply_topk_weights_early=apply_topk_weights_early,
        aux_loss_coeff=aux_loss_coeff,
        use_expert_routing_bias=use_expert_routing_bias,
        score_function=score_function,
        scaling_factor=scaling_factor,
        dtype=DTYPE,
        input_axes=input_axes,
        quantization_recipe=quantization_recipe,
        dispatch_checkpoint_name=dispatch_checkpoint_name,
        quant_before_fsdp_ag=quant_before_fsdp_ag,
        use_cudnn_fusion=use_cudnn_fusion,
    )
    # Custom expert_bias_init lets tests inject a non-zero expert_bias without
    # poking variables['params'] post-init.
    if expert_bias_init is not None:
        kwargs["expert_bias_init"] = expert_bias_init
    return MoEBlock(**kwargs)


@pytest.fixture
def make_block(use_cudnn_fusion):
    return partial(_make_block, use_cudnn_fusion=use_cudnn_fusion)


def _strong_expert_bias_init(key, shape, dtype):
    """Half +5, half -5 — large enough to force topk onto the +ve half."""
    del key
    n = shape[0]
    return jnp.concatenate(
        [
            jnp.full((n // 2,), 5.0, dtype=dtype),
            jnp.full((n - n // 2,), -5.0, dtype=dtype),
        ]
    )


def _shard_inputs(x, mesh):
    # Match the layout moe.py re-pins to: outer dp axes, then ep innermost.
    return jax.lax.with_sharding_constraint(
        x, NamedSharding(mesh, P((FSDP_AXIS, EP_AXIS), None, None))
    )


def _ctx(mesh):
    """Combined mesh + global_shard_guard + axis_rules context."""

    class _Combo:
        def __enter__(self_inner):
            self_inner._m = mesh.__enter__()
            self_inner._gs = global_shard_guard(
                MeshResource(ep_resource=EP_AXIS, fsdp_resource=FSDP_AXIS)
            )
            self_inner._gs.__enter__()
            self_inner._ar = nn_partitioning.axis_rules(LOGICAL_AXIS_RULES)
            self_inner._ar.__enter__()
            return self_inner._m

        def __exit__(self_inner, *args):
            self_inner._ar.__exit__(*args)
            self_inner._gs.__exit__(*args)
            mesh.__exit__(*args)

    return _Combo()


def _init_apply(block, mesh, x, key):
    with _ctx(mesh):
        x_sh = _shard_inputs(x, mesh)
        variables = jax.jit(block.init)(key, x_sh)
        jax.block_until_ready(jax.tree_util.tree_leaves(variables)[0])
        output, aux, _trt, expert_counts = jax.jit(block.apply)(variables, x_sh)
        jax.block_until_ready(output)
    return variables, output, aux, expert_counts


def _grad_step(
    block,
    variables,
    mesh,
    x,
    *,
    include_aux=False,
):
    """Run jax.grad of mean(out^2) [+ aux if include_aux] vs (params, x).

    Returns ``(grads_variables, grad_x)`` so callers can check both the
    weight gradients and the input-activation gradient that propagates
    back to the previous layer.
    """
    with _ctx(mesh):
        x_sh = _shard_inputs(x, mesh)

        def loss_fn(variables, x):
            output, aux, _trt, _expert_counts = block.apply(variables, x)
            loss = jnp.mean(output.astype(jnp.float32) ** 2)
            if include_aux and aux is not None:
                loss = loss + aux.astype(jnp.float32)
            return loss

        grads_v, grad_x = jax.jit(jax.grad(loss_fn, argnums=(0, 1)))(variables, x_sh)
        jax.block_until_ready(jax.tree_util.tree_leaves(grads_v)[0])
        jax.block_until_ready(grad_x)
        return grads_v, grad_x


def _grad_aux_only(block, variables, mesh, x):
    """Jit'd grad of just the aux loss scalar — proves it reaches the
    gate even when no main-output contribution is present."""
    with _ctx(mesh):
        x_sh = _shard_inputs(x, mesh)

        def aux_only(variables, x):
            _, aux, _trt, _expert_counts = block.apply(variables, x)
            return aux.astype(jnp.float32)

        grads = jax.jit(jax.grad(aux_only))(variables, x_sh)
        jax.block_until_ready(jax.tree_util.tree_leaves(grads)[0])
        return grads


def _unwrap(x):
    return x.value if hasattr(x, "value") else x


def _to_global_numpy(arr, mesh):
    """Replicate a sharded JAX array onto every rank and return as numpy.

    Triggers an all-gather inside JIT. The resulting addressable_data(0)
    contains the full global array on every process, so we can run the
    pure-JAX reference and compare against it from any process.
    """
    rep = NamedSharding(mesh, P())
    with mesh:
        full = jax.jit(lambda a: jax.lax.with_sharding_constraint(a, rep))(arr)
        full.block_until_ready()
    return np.asarray(jax.device_get(full.addressable_data(0)))


def _params_global_numpy(variables, mesh):
    """Pull every entry of variables['params'] to a replicated numpy array."""
    params = variables["params"]
    return {name: _to_global_numpy(_unwrap(p), mesh) for name, p in params.items()}


def _make_inputs(key):
    """Generate a globally-identical input tensor on every process."""
    return jax.random.normal(key, (BATCH, SEQ, HIDDEN), dtype=DTYPE)


def _quantization_recipe(quantization):
    if quantization == "bf16":
        return None
    assert quantization == "mxfp8"
    return MXFP8BlockScaling()


# -----------------------------------------------------------------------------
# Tests
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# Parametrize variants exercised by both the forward and the backward
# parity tests. Each config is one MoE-block configuration the suite
# wants covered; the test body checks shape, dtype, finiteness AND
# numerical parity vs the same pure-JAX reference (which understands
# the same set of knobs).
# -----------------------------------------------------------------------------

_CONFIGS = [
    pytest.param(
        dict(score_function="softmax"),
        id="softmax",
    ),
    pytest.param(
        dict(score_function="softmax", apply_topk_weights_early=True),
        id="softmax-early-weighting",
    ),
    pytest.param(
        dict(score_function="sigmoid"),
        id="sigmoid",
    ),
    # NOTE: a ``sigmoid-bias-zero`` config (use_expert_routing_bias=True
    # with a zero-initialised bias buffer) was previously exercised
    # here. It was dropped because the routing math collapses to the
    # no-bias case when the buffer is zero -- ``sigmoid`` already
    # covers that numerical path. The bias-aware codepath is still
    # exercised by ``sigmoid-bias-strong`` below, which uses a
    # non-zero bias.
    pytest.param(
        dict(
            score_function="sigmoid",
            use_expert_routing_bias=True,
            expert_bias_init=_strong_expert_bias_init,
        ),
        id="sigmoid-bias-strong",
    ),
]

_QUANTIZATION_CASES = [
    pytest.param("bf16", id="bf16"),
]

if get_device_compute_capability(0) >= 100:
    _QUANTIZATION_CASES.append(pytest.param("mxfp8", id="mxfp8"))


@pytest.mark.parametrize("native_weight_layout", [False, True])
@pytest.mark.parametrize("fsdp_dimension", ["k", "gated", "expert"])
def test_quantized_weight_gather_matches_full_precision_gather(
    mesh, monkeypatch, native_weight_layout, fsdp_dimension, make_block
):
    """The FP8 weight gather retains forward and backward MoE semantics."""
    if native_weight_layout or fsdp_dimension != "k":
        from transformer_engine.jax import cpp_extensions as tex

        flax_moe_module = importlib.import_module("transformer_engine.jax.flax.moe")
        original_moe = flax_moe_module.moe

        def layout_moe(*args, **kwargs):
            args = list(args)
            if native_weight_layout:
                gate, up = jnp.split(args[2], 2, axis=-1)
                args[2] = tex.pack_gated_activation_pair(gate, up).transpose(0, 2, 1)
                kwargs["wi_kernel_axes"] = ("exp", "mlp", "embed")
                kwargs["cudnn_native_weight_layout"] = True
            if fsdp_dimension == "gated":
                kwargs["wi_kernel_axes"] = (
                    ("exp", "gated_weight_fsdp", None)
                    if native_weight_layout
                    else ("exp", None, "gated_weight_fsdp")
                )
                spec = (
                    P(EP_AXIS, FSDP_AXIS, None)
                    if native_weight_layout
                    else P(EP_AXIS, None, FSDP_AXIS)
                )
                args[2] = jax.lax.with_sharding_constraint(args[2], NamedSharding(mesh, spec))
            if fsdp_dimension == "expert":
                kwargs["wi_kernel_axes"] = ("expert_weight_fsdp", None, None)
                kwargs["wo_kernel_axes"] = ("expert_weight_fsdp", None, None)
                spec = P((EP_AXIS, FSDP_AXIS), None, None)
                args[2] = jax.lax.with_sharding_constraint(args[2], NamedSharding(mesh, spec))
                args[3] = jax.lax.with_sharding_constraint(args[3], NamedSharding(mesh, spec))
            return original_moe(*args, **kwargs)

        monkeypatch.setattr(flax_moe_module, "moe", layout_moe)
    x = _make_inputs(jax.random.PRNGKey(41))
    baseline = make_block(quantization_recipe=MXFP8BlockScaling())
    quantized_ag = make_block(quantization_recipe=MXFP8BlockScaling(), quant_before_fsdp_ag=True)
    variables, baseline_out, _, _ = _init_apply(baseline, mesh, x, jax.random.PRNGKey(42))
    with _ctx(mesh):
        x_sh = _shard_inputs(x, mesh)
        quantized_out, _, _, _ = jax.jit(quantized_ag.apply)(variables, x_sh)
        quantized_out.block_until_ready()
    np.testing.assert_allclose(
        _to_global_numpy(quantized_out, mesh).astype(np.float32),
        _to_global_numpy(baseline_out, mesh).astype(np.float32),
        **FWD_TOLERANCE["mxfp8"],
    )
    baseline_grads, baseline_dx = _grad_step(baseline, variables, mesh, x)
    quantized_grads, quantized_dx = _grad_step(quantized_ag, variables, mesh, x)
    for name in ("wi", "wo"):
        np.testing.assert_allclose(
            _to_global_numpy(_unwrap(quantized_grads["params"][name]), mesh).astype(np.float32),
            _to_global_numpy(_unwrap(baseline_grads["params"][name]), mesh).astype(np.float32),
            **GRAD_FFN_TOLERANCE["mxfp8"],
        )
    np.testing.assert_allclose(
        _to_global_numpy(quantized_dx, mesh).astype(np.float32),
        _to_global_numpy(baseline_dx, mesh).astype(np.float32),
        **GRAD_FFN_TOLERANCE["mxfp8"],
    )


@pytest.mark.parametrize("quant_before_fsdp_ag", [False, True])
def test_mesh_resource_api_forward_and_backward(mesh, quant_before_fsdp_ag, make_block):
    """Explicit and global resources give identical forward and backward results."""
    baseline = make_block(
        quantization_recipe=MXFP8BlockScaling(), quant_before_fsdp_ag=quant_before_fsdp_ag
    )
    candidate = baseline.clone(
        mesh_resource=MeshResource(ep_resource=EP_AXIS, fsdp_resource=FSDP_AXIS)
    )
    x = _make_inputs(jax.random.PRNGKey(51))
    variables, baseline_out, _, _ = _init_apply(baseline, mesh, x, jax.random.PRNGKey(52))
    baseline_grads, baseline_dx = _grad_step(baseline, variables, mesh, x)
    with jax.set_mesh(mesh), nn_partitioning.axis_rules(LOGICAL_AXIS_RULES):
        with global_shard_guard(None):
            x_sh = _shard_inputs(x, mesh)
            candidate_out, _, _, _ = jax.jit(candidate.apply)(variables, x_sh)

            def loss_fn(variables, inputs):
                output, _, _, _ = candidate.apply(variables, inputs)
                return jnp.mean(output.astype(jnp.float32) ** 2)

            candidate_grads, candidate_dx = jax.jit(jax.grad(loss_fn, argnums=(0, 1)))(
                variables, x_sh
            )
            jax.block_until_ready((candidate_out, candidate_grads, candidate_dx))
    np.testing.assert_allclose(
        _to_global_numpy(candidate_out, mesh).astype(np.float32),
        _to_global_numpy(baseline_out, mesh).astype(np.float32),
        **FWD_TOLERANCE["mxfp8"],
    )
    for name in ("gate_kernel", "wi", "wo"):
        np.testing.assert_allclose(
            _to_global_numpy(_unwrap(candidate_grads["params"][name]), mesh).astype(np.float32),
            _to_global_numpy(_unwrap(baseline_grads["params"][name]), mesh).astype(np.float32),
            **(
                GRAD_GATE_TOLERANCE["mxfp8"]
                if name == "gate_kernel"
                else GRAD_FFN_TOLERANCE["mxfp8"]
            ),
        )
    np.testing.assert_allclose(
        _to_global_numpy(candidate_dx, mesh).astype(np.float32),
        _to_global_numpy(baseline_dx, mesh).astype(np.float32),
        **GRAD_FFN_TOLERANCE["mxfp8"],
    )


def _reference_kwargs_from_config(config, params_np):
    """Pick out the reference-relevant pieces of a parametrize config."""
    return dict(
        score_function=config.get("score_function", "softmax"),
        expert_bias=(
            jnp.asarray(params_np["expert_bias"])
            if config.get("use_expert_routing_bias", False)
            else None
        ),
    )


class TestTeEpMoeForward:
    """Per-config forward correctness in a single run: shape, dtype,
    finiteness AND numerical parity vs the pure-JAX reference."""

    @pytest.mark.parametrize("config", _CONFIGS)
    @pytest.mark.parametrize("quantization", _QUANTIZATION_CASES)
    def test_forward(self, mesh, config, quantization, make_block):
        block = make_block(**config, quantization_recipe=_quantization_recipe(quantization))
        x = _make_inputs(jax.random.PRNGKey(0))
        variables, output, aux, expert_counts = _init_apply(block, mesh, x, jax.random.PRNGKey(1))

        # Shape / dtype / finiteness (cheap; on the local shard).
        assert output.shape == x.shape
        assert output.dtype == x.dtype
        out_local = np.asarray(jax.device_get(output.addressable_data(0)))
        assert np.all(np.isfinite(out_local)), "output has NaN/Inf"
        assert aux is None, "aux_loss should be None when aux_loss_coeff == 0"
        counts_np = np.asarray(jax.device_get(expert_counts))
        assert expert_counts.shape == (NUM_EXPERTS,)
        assert expert_counts.dtype == jnp.int32
        assert int(counts_np.sum()) == BATCH * SEQ * TOPK

        # Numerical parity (replicated global view -> single rank's numpy).
        params_np = _params_global_numpy(variables, mesh)
        x_np = np.asarray(jax.device_get(x))
        out_te_np = _to_global_numpy(output, mesh)

        out_ref, _ = _pure_jax_moe_reference(
            jnp.asarray(x_np),
            jnp.asarray(params_np["gate_kernel"]),
            jnp.asarray(params_np["wi"]),
            jnp.asarray(params_np["wo"]),
            num_experts=NUM_EXPERTS,
            num_experts_per_tok=TOPK,
            **_reference_kwargs_from_config(config, params_np),
        )
        np.testing.assert_allclose(
            out_te_np.astype(np.float32),
            np.asarray(jax.device_get(out_ref)).astype(np.float32),
            **FWD_TOLERANCE[quantization],
            err_msg=f"forward parity breach for config={config}, quantization={quantization}",
        )


class TestTeEpMoeHashRouting:
    """DeepSeek-V4 hash selection with differentiable gate weights."""

    def test_hash_forward_and_backward(self, mesh, make_block, use_cudnn_fusion):
        vocab_size = 64
        scaling_factor = 1.5
        token_ids = jnp.arange(BATCH * SEQ, dtype=jnp.int32).reshape(BATCH, SEQ) % vocab_size
        vocab_ids = jnp.arange(vocab_size, dtype=jnp.int32)
        tid2eid = jnp.stack(
            [vocab_ids % NUM_EXPERTS, (vocab_ids + 3) % NUM_EXPERTS],
            axis=-1,
        )
        block = make_block(
            score_function="sqrtsoftplus",
            scaling_factor=scaling_factor,
        )
        x = _make_inputs(jax.random.PRNGKey(30))

        with _ctx(mesh):
            x_sh = _shard_inputs(x, mesh)
            ids_sh = jax.device_put(
                token_ids,
                NamedSharding(mesh, P((FSDP_AXIS, EP_AXIS), None)),
            )
            table_sh = jax.device_put(tid2eid, NamedSharding(mesh, P()))
            variables = jax.jit(block.init)(jax.random.PRNGKey(31), x_sh)
            params = {
                name: _unwrap(variables["params"][name]) for name in ("gate_kernel", "wi", "wo")
            }

            def externally_routed_moe(params, activations, token_ids_arg, tid2eid_arg):
                logits = jnp.einsum(
                    "bsh,he->bse",
                    activations,
                    params["gate_kernel"].astype(activations.dtype),
                ).astype(jnp.float32)
                scores = jnp.sqrt(jax.nn.softplus(logits))
                routing_indices = tid2eid_arg[token_ids_arg]
                routing_weights = jnp.take_along_axis(scores, routing_indices, axis=-1)
                routing_weights = routing_weights / (
                    routing_weights.sum(axis=-1, keepdims=True) + 1e-20
                )
                routing_weights = routing_weights * scaling_factor
                return moe(
                    activations,
                    RoutingMapInfo(
                        routing_indices=routing_indices,
                        routing_weights=routing_weights,
                    ),
                    params["wi"],
                    params["wo"],
                    num_experts=NUM_EXPERTS,
                    input_axes=("batch", None, None),
                    wi_kernel_axes=("exp", "embed", "mlp"),
                    wo_kernel_axes=("exp", "mlp", "embed"),
                    dtype=DTYPE,
                    collect_expert_counts=True,
                    use_cudnn_fusion=use_cudnn_fusion,
                )

            output, aux, _trt, expert_counts = jax.jit(externally_routed_moe)(
                params, x_sh, ids_sh, table_sh
            )
            jax.block_until_ready(output)
            assert aux is None, "aux_loss must be None for caller-supplied routing"

            def te_loss(params, activations, token_ids_arg, tid2eid_arg):
                out, _aux, _total_recv, _counts = externally_routed_moe(
                    params, activations, token_ids_arg, tid2eid_arg
                )
                return jnp.mean(out.astype(jnp.float32) ** 2)

            grads_te, grad_x_te = jax.jit(jax.grad(te_loss, argnums=(0, 1)))(
                params, x_sh, ids_sh, table_sh
            )

        params_np = _params_global_numpy(variables, mesh)
        x_np = np.asarray(jax.device_get(x))
        ids_np = np.asarray(jax.device_get(token_ids))
        table_np = np.asarray(jax.device_get(tid2eid))

        def ref_loss(params, activations):
            out, _ = _pure_jax_moe_reference(
                activations,
                params["gate_kernel"],
                params["wi"],
                params["wo"],
                hash_input_ids=jnp.asarray(ids_np),
                hash_tid2eid=jnp.asarray(table_np),
                num_experts=NUM_EXPERTS,
                num_experts_per_tok=TOPK,
                score_function="sqrtsoftplus",
                scaling_factor=scaling_factor,
            )
            return jnp.mean(out.astype(jnp.float32) ** 2)

        ref_params = {name: jnp.asarray(params_np[name]) for name in ("gate_kernel", "wi", "wo")}
        grads_ref, grad_x_ref = jax.jit(jax.grad(ref_loss, argnums=(0, 1)))(
            ref_params, jnp.asarray(x_np)
        )

        np.testing.assert_allclose(
            _to_global_numpy(output, mesh).astype(np.float32),
            np.asarray(
                _pure_jax_moe_reference(
                    jnp.asarray(x_np),
                    ref_params["gate_kernel"],
                    ref_params["wi"],
                    ref_params["wo"],
                    hash_input_ids=jnp.asarray(ids_np),
                    hash_tid2eid=jnp.asarray(table_np),
                    num_experts=NUM_EXPERTS,
                    num_experts_per_tok=TOPK,
                    score_function="sqrtsoftplus",
                    scaling_factor=scaling_factor,
                )[0]
            ).astype(np.float32),
            **FWD_TOLERANCE["bf16"],
        )
        expected_counts = np.bincount(table_np[ids_np].reshape(-1), minlength=NUM_EXPERTS)
        np.testing.assert_array_equal(np.asarray(jax.device_get(expert_counts)), expected_counts)

        # Use a slightly larger tolerance as the numerical difference is just over 1e-7.
        grad_ffn_tolerance_bf16 = {"atol": 2e-7, "rtol": 1e-7}

        for name in ("gate_kernel", "wi", "wo"):
            np.testing.assert_allclose(
                _to_global_numpy(grads_te[name], mesh).astype(np.float32),
                np.asarray(jax.device_get(grads_ref[name])).astype(np.float32),
                **(
                    GRAD_GATE_TOLERANCE["bf16"]
                    if name == "gate_kernel"
                    else grad_ffn_tolerance_bf16
                ),
            )
        np.testing.assert_allclose(
            _to_global_numpy(grad_x_te, mesh).astype(np.float32),
            np.asarray(jax.device_get(grad_x_ref)).astype(np.float32),
            **grad_ffn_tolerance_bf16,
        )


class TestTeEpMoeRouterInfo:
    """Functional ``moe(router_info=...)`` API surface."""

    def test_router_computation_matches_block(self, mesh, make_block, use_cudnn_fusion):
        """Calling ``moe`` with a RouterComputationInfo reproduces _MoEBlock."""
        scaling_factor = 1.5
        aux_loss_coeff = 1e-2
        block = make_block(
            score_function="sigmoid",
            use_expert_routing_bias=True,
            expert_bias_init=_strong_expert_bias_init,
            scaling_factor=scaling_factor,
            aux_loss_coeff=aux_loss_coeff,
        )
        x = _make_inputs(jax.random.PRNGKey(40))
        variables, out_block, aux_block, counts_block = _init_apply(
            block, mesh, x, jax.random.PRNGKey(41)
        )
        params = {name: _unwrap(p) for name, p in variables["params"].items()}

        def functional_moe(params, activations):
            router_info = RouterComputationInfo(
                gate_kernel=params["gate_kernel"],
                num_experts_per_tok=TOPK,
                expert_bias=params["expert_bias"],
                score_function="sigmoid",
                scaling_factor=scaling_factor,
                aux_loss_coeff=aux_loss_coeff,
            )
            return moe(
                activations,
                router_info,
                params["wi"],
                params["wo"],
                num_experts=NUM_EXPERTS,
                input_axes=("batch", None, None),
                dtype=DTYPE,
                use_cudnn_fusion=use_cudnn_fusion,
            )

        with _ctx(mesh):
            x_sh = _shard_inputs(x, mesh)
            out_fn, aux_fn, _trt, counts_fn = jax.jit(functional_moe)(params, x_sh)
            jax.block_until_ready(out_fn)

        np.testing.assert_allclose(
            _to_global_numpy(out_fn, mesh).astype(np.float32),
            _to_global_numpy(out_block, mesh).astype(np.float32),
            **FWD_TOLERANCE["bf16"],
        )
        assert aux_fn is not None and aux_block is not None
        np.testing.assert_allclose(
            float(_to_global_numpy(aux_fn, mesh)),
            float(_to_global_numpy(aux_block, mesh)),
            **AUX_TOLERANCE,
        )
        np.testing.assert_array_equal(
            np.asarray(jax.device_get(counts_fn)), np.asarray(jax.device_get(counts_block))
        )

    def test_router_info_pytree_leaves(self):
        """Only arrays are pytree leaves; router settings stay static."""
        gate_kernel = jnp.zeros((HIDDEN, NUM_EXPERTS), DTYPE)
        expert_bias = jnp.zeros((NUM_EXPERTS,), jnp.float32)
        router = RouterComputationInfo(
            gate_kernel=gate_kernel,
            num_experts_per_tok=TOPK,
            expert_bias=expert_bias,
            score_function="sigmoid",
        )
        leaves = jax.tree_util.tree_leaves(router)
        assert len(leaves) == 2
        assert leaves[0] is gate_kernel and leaves[1] is expert_bias

        indices = jnp.zeros((BATCH, SEQ, TOPK), jnp.int32)
        weights = jnp.ones((BATCH, SEQ, TOPK), jnp.float32)
        leaves = jax.tree_util.tree_leaves(
            RoutingMapInfo(routing_indices=indices, routing_weights=weights)
        )
        assert len(leaves) == 2
        assert leaves[0] is indices and leaves[1] is weights

    def test_rejects_unknown_router_info(self):
        x = jnp.zeros((BATCH, SEQ, HIDDEN), DTYPE)
        wi = jnp.zeros((NUM_EXPERTS, HIDDEN, 2 * INTER), DTYPE)
        wo = jnp.zeros((NUM_EXPERTS, INTER, HIDDEN), DTYPE)
        with pytest.raises(TypeError, match="router_info"):
            moe(
                x,
                object(),
                wi,
                wo,
                num_experts=NUM_EXPERTS,
                mesh_resource=MeshResource(ep_resource=EP_AXIS),
            )

    def test_routing_map_shape_validation(self):
        x = jnp.zeros((BATCH, SEQ, HIDDEN), DTYPE)
        wi = jnp.zeros((NUM_EXPERTS, HIDDEN, 2 * INTER), DTYPE)
        wo = jnp.zeros((NUM_EXPERTS, INTER, HIDDEN), DTYPE)
        indices = jnp.zeros((BATCH, SEQ, TOPK), jnp.int32)
        with pytest.raises(ValueError, match="routing_weights"):
            moe(
                x,
                RoutingMapInfo(
                    routing_indices=indices,
                    routing_weights=jnp.ones((BATCH, SEQ, TOPK + 1), jnp.float32),
                ),
                wi,
                wo,
                num_experts=NUM_EXPERTS,
                mesh_resource=MeshResource(ep_resource=EP_AXIS),
            )


class TestTeEpMoeBackward:
    """Per-config backward correctness in a single run: per-tensor
    grads finite, non-zero AND parity vs the pure-JAX reference."""

    @pytest.mark.parametrize("config", _CONFIGS)
    @pytest.mark.parametrize("quantization", _QUANTIZATION_CASES)
    def test_backward(self, mesh, config, quantization, make_block):
        block = make_block(**config, quantization_recipe=_quantization_recipe(quantization))
        x = _make_inputs(jax.random.PRNGKey(2))
        variables, _, _, _ = _init_apply(block, mesh, x, jax.random.PRNGKey(3))
        grads_te, grad_x_te = _grad_step(block, variables, mesh, x)

        # Reference grads via jax.grad over the pure-JAX MoE with the
        # same config. argnums=(0, 1) so the reference also produces a
        # d_x for the propagated-gradient parity check below.
        params_np = _params_global_numpy(variables, mesh)
        x_np = np.asarray(jax.device_get(x))
        ref_kwargs = _reference_kwargs_from_config(config, params_np)
        ref_expert_bias = ref_kwargs.pop("expert_bias")

        def loss_fn(params, x):
            out, _ = _pure_jax_moe_reference(
                x,
                params["gate_kernel"],
                params["wi"],
                params["wo"],
                ref_expert_bias,
                num_experts=NUM_EXPERTS,
                num_experts_per_tok=TOPK,
                **ref_kwargs,
            )
            return jnp.mean(out.astype(jnp.float32) ** 2)

        grads_ref, grad_x_ref = jax.jit(jax.grad(loss_fn, argnums=(0, 1)))(
            {k: jnp.asarray(v) for k, v in params_np.items() if k != "expert_bias"},
            jnp.asarray(x_np),
        )
        grads_ref_np = {k: np.asarray(jax.device_get(v)) for k, v in grads_ref.items()}
        grad_x_ref_np = np.asarray(jax.device_get(grad_x_ref))

        for name in ("gate_kernel", "wi", "wo"):
            # Per-tensor: finite + non-zero + parity in one pass.
            g_te = _to_global_numpy(_unwrap(grads_te["params"][name]), mesh)
            assert np.all(np.isfinite(g_te)), f"{name} grad has NaN/Inf [config={config}]"
            assert np.any(g_te != 0.0), f"{name} grad identically zero [config={config}]"
            tolerances = GRAD_GATE_TOLERANCE if name == "gate_kernel" else GRAD_FFN_TOLERANCE
            np.testing.assert_allclose(
                g_te.astype(np.float32),
                grads_ref_np[name].astype(np.float32),
                **tolerances[quantization],
                err_msg=(
                    f"grad parity breach on {name} [config={config}, quantization={quantization}]"
                ),
            )

        # d_x: the gradient propagated back to the previous layer. Checks
        # shape, dtype (must match x.dtype — protects the
        # _with_sharding_constraint_cast_bwd wrapper that casts the
        # fp32-promoted gate path back to bf16), finiteness, non-zero
        # AND numerical parity vs the pure-JAX reference d_x.
        grad_x_te_np = _to_global_numpy(grad_x_te, mesh)
        assert (
            grad_x_te.shape == x.shape
        ), f"d_x shape {grad_x_te.shape} != x.shape {x.shape} [config={config}]"
        assert (
            grad_x_te.dtype == x.dtype
        ), f"d_x dtype {grad_x_te.dtype} != x.dtype {x.dtype} [config={config}]"
        assert np.all(np.isfinite(grad_x_te_np)), f"d_x has NaN/Inf [config={config}]"
        assert np.any(grad_x_te_np != 0.0), f"d_x identically zero [config={config}]"
        np.testing.assert_allclose(
            grad_x_te_np.astype(np.float32),
            grad_x_ref_np.astype(np.float32),
            **GRAD_FFN_TOLERANCE[quantization],
            err_msg=f"d_x parity breach [config={config}, quantization={quantization}]",
        )


def test_ep_checkpoint_names(mesh, monkeypatch, make_block):
    moe_module = importlib.import_module("transformer_engine.jax.moe")
    named_values = {}
    original_checkpoint_name = moe_module.checkpoint_name

    def recorded_checkpoint_name(value, name):
        named_values.setdefault(name, []).append(value)
        return original_checkpoint_name(value, name)

    monkeypatch.setattr(moe_module, "checkpoint_name", recorded_checkpoint_name)
    block = make_block(
        dispatch_checkpoint_name="saved_dispatch",
    )
    inputs = _make_inputs(jax.random.PRNGKey(34))
    variables, output, _, _ = _init_apply(block, mesh, inputs, jax.random.PRNGKey(35))
    grads, grad_inputs = _grad_step(block, variables, mesh, inputs)

    assert len(named_values["saved_dispatch"]) >= 2
    assert all(hasattr(value, "shape") for values in named_values.values() for value in values)
    assert np.all(np.isfinite(_to_global_numpy(output, mesh)))
    assert np.all(np.isfinite(_to_global_numpy(grad_inputs, mesh)))
    for name in ("gate_kernel", "wi", "wo"):
        assert np.all(np.isfinite(_to_global_numpy(_unwrap(grads["params"][name]), mesh)))


def test_explicitly_disabled_fusion_with_native_weights(
    mesh, monkeypatch, make_block, use_cudnn_fusion
):
    """Disabling fusion bypasses dependency probing and preserves native gradients."""
    if use_cudnn_fusion:
        pytest.skip("Requires the ordinary 128-token EP bootstrap")
    from transformer_engine.jax import cpp_extensions as tex

    moe_module = importlib.import_module("transformer_engine.jax.moe")

    def unexpected_selection(*args, **kwargs):
        raise AssertionError("Explicitly disabled fusion must not probe cuDNN")

    monkeypatch.setattr(moe_module, "_select_cudnn_jax_fusion", unexpected_selection)
    block = make_block(quantization_recipe=MXFP8BlockScaling(), use_cudnn_fusion=False)
    x = _make_inputs(jax.random.PRNGKey(53))
    variables, baseline_output, _, _ = _init_apply(block, mesh, x, jax.random.PRNGKey(54))
    baseline_grads, baseline_dx = _grad_step(block, variables, mesh, x)
    flax_moe = importlib.import_module("transformer_engine.jax.flax.moe")
    original_moe = flax_moe.moe

    def native_moe(*args, **kwargs):
        args = list(args)
        gate, up = jnp.split(args[2], 2, axis=-1)
        args[2] = tex.pack_gated_activation_pair(gate, up).transpose(0, 2, 1)
        kwargs["wi_kernel_axes"] = ("exp", "mlp", "embed")
        kwargs["cudnn_native_weight_layout"] = True
        return original_moe(*args, **kwargs)

    monkeypatch.setattr(flax_moe, "moe", native_moe)
    with _ctx(mesh):
        output, _, _, _ = jax.jit(block.apply)(variables, _shard_inputs(x, mesh))
        output.block_until_ready()
    grads, dx = _grad_step(block, variables, mesh, x)
    np.testing.assert_array_equal(
        _to_global_numpy(output, mesh), _to_global_numpy(baseline_output, mesh)
    )
    np.testing.assert_array_equal(_to_global_numpy(dx, mesh), _to_global_numpy(baseline_dx, mesh))
    for name in ("gate_kernel", "wi", "wo"):
        np.testing.assert_array_equal(
            _to_global_numpy(_unwrap(grads["params"][name]), mesh),
            _to_global_numpy(_unwrap(baseline_grads["params"][name]), mesh),
        )


class TestTeEpMoeCudnnCutedslFusion:
    """End-to-end MXFP8 coverage for cuDNN's grouped GLU JAX APIs."""

    @pytest.mark.parametrize("fallback", ["missing_api", "old_version", "hybrid"])
    @pytest.mark.parametrize("native_layout", [False, True])
    def test_unsupported_fusion_unfused_forward_and_backward(
        self, mesh, monkeypatch, native_layout, make_block, use_cudnn_fusion, fallback
    ):
        """Unfused fallback retains bootstrap capacity and native-layout gradients."""
        if not use_cudnn_fusion:
            pytest.skip("Requires fusion requested at bootstrap")
        import cudnn
        from transformer_engine.jax import cpp_extensions as tex

        if fallback == "missing_api":
            # Avoid triggering a lazy optional import just to disable the API.
            monkeypatch.setitem(cudnn.__dict__, "grouped_gemm_glu_wrapper_sm100", None)
        elif fallback == "old_version":
            monkeypatch.setattr(cudnn, "__version__", "1.31.0")
        recipe = MXFP8BlockScaling(
            fp8_format=Format.HYBRID if fallback == "hybrid" else Format.E4M3
        )

        def unexpected_fused_kernel(*args, **kwargs):
            raise AssertionError("Unsupported fusion must use unfused kernels")

        monkeypatch.setattr(tex, "grouped_gemm_glu", unexpected_fused_kernel)
        monkeypatch.setattr(tex, "grouped_gemm_dglu", unexpected_fused_kernel)
        baseline = make_block(quantization_recipe=recipe)
        block = make_block(quantization_recipe=recipe)
        x = _make_inputs(jax.random.PRNGKey(51))
        # Keep the fusion-requested EP alignment and bootstrap capacity while
        # independently forcing the baseline to execute the unfused FFN.
        moe_module = importlib.import_module("transformer_engine.jax.moe")
        with monkeypatch.context() as baseline_patch:
            baseline_patch.setattr(moe_module, "_select_cudnn_jax_fusion", lambda _: False)
            variables, baseline_output, _, _ = _init_apply(
                baseline, mesh, x, jax.random.PRNGKey(52)
            )
            baseline_grads, baseline_dx = _grad_step(baseline, variables, mesh, x)

        if native_layout:
            flax_moe = importlib.import_module("transformer_engine.jax.flax.moe")
            original_moe = flax_moe.moe

            def native_moe(*args, **kwargs):
                args = list(args)
                gate, up = jnp.split(args[2], 2, axis=-1)
                args[2] = tex.pack_gated_activation_pair(gate, up).transpose(0, 2, 1)
                kwargs["wi_kernel_axes"] = ("exp", "mlp", "embed")
                kwargs["cudnn_native_weight_layout"] = True
                return original_moe(*args, **kwargs)

            monkeypatch.setattr(flax_moe, "moe", native_moe)
        with _ctx(mesh):
            output, _, _, _ = jax.jit(block.apply)(variables, _shard_inputs(x, mesh))
            output.block_until_ready()
        grads, dx = _grad_step(block, variables, mesh, x)
        np.testing.assert_array_equal(
            _to_global_numpy(output, mesh), _to_global_numpy(baseline_output, mesh)
        )
        np.testing.assert_array_equal(
            _to_global_numpy(dx, mesh), _to_global_numpy(baseline_dx, mesh)
        )
        for name in ("gate_kernel", "wi", "wo"):
            np.testing.assert_array_equal(
                _to_global_numpy(_unwrap(grads["params"][name]), mesh),
                _to_global_numpy(_unwrap(baseline_grads["params"][name]), mesh),
            )

    @pytest.mark.parametrize("native_layout", [False, True])
    @pytest.mark.parametrize("apply_topk_weights_early", [False, True])
    def test_mxfp8_forward_and_backward(
        self,
        mesh,
        apply_topk_weights_early,
        monkeypatch,
        make_block,
        use_cudnn_fusion,
        native_layout,
    ):
        if not use_cudnn_fusion:
            pytest.skip("requires the cuDNN fusion fixture parameter")
        from transformer_engine.jax import cpp_extensions as tex

        available, reason = tex.grouped_gemm_glu_dependencies_available()
        if not available:
            pytest.skip(reason)

        if native_layout:
            flax_moe = importlib.import_module("transformer_engine.jax.flax.moe")
            original_moe = flax_moe.moe

            def native_moe(*args, **kwargs):
                args = list(args)
                gate, up = jnp.split(args[2], 2, axis=-1)
                args[2] = tex.pack_gated_activation_pair(gate, up).transpose(0, 2, 1)
                kwargs["wi_kernel_axes"] = ("exp", "mlp", "embed")
                kwargs["cudnn_native_weight_layout"] = True
                return original_moe(*args, **kwargs)

            monkeypatch.setattr(flax_moe, "moe", native_moe)

        shared_calls = []
        original_glu = tex.grouped_gemm_glu
        original_dglu = tex.grouped_gemm_dglu

        def checked_glu(*args, **kwargs):
            shared_calls.append("glu")
            return original_glu(*args, **kwargs)

        def checked_dglu(*args, **kwargs):
            shared_calls.append("dglu")
            return original_dglu(*args, **kwargs)

        monkeypatch.setattr(tex, "grouped_gemm_glu", checked_glu)
        monkeypatch.setattr(tex, "grouped_gemm_dglu", checked_dglu)
        block = make_block(
            apply_topk_weights_early=apply_topk_weights_early,
            quantization_recipe=MXFP8BlockScaling(),
        )
        x = _make_inputs(jax.random.PRNGKey(30))
        variables, output, aux, _ = _init_apply(block, mesh, x, jax.random.PRNGKey(31))
        assert "glu" in shared_calls, "MoE did not select the shared cuDNN GLU JAX API"
        grads, grad_x = _grad_step(block, variables, mesh, x)
        assert "dglu" in shared_calls, "MoE VJP did not select the shared cuDNN dGLU JAX API"

        assert output.shape == x.shape
        assert output.dtype == x.dtype
        assert aux is None
        output_np = _to_global_numpy(output, mesh).astype(np.float32)
        assert np.all(np.isfinite(output_np))
        assert np.any(output_np != 0)

        for name in ("gate_kernel", "wi", "wo"):
            grad = _to_global_numpy(_unwrap(grads["params"][name]), mesh).astype(np.float32)
            assert np.all(np.isfinite(grad)), f"{name} fused MXFP8 grad has NaN/Inf"
            assert np.any(grad != 0), f"{name} fused MXFP8 grad is identically zero"
        grad_x_np = _to_global_numpy(grad_x, mesh).astype(np.float32)
        assert np.all(np.isfinite(grad_x_np))
        assert np.any(grad_x_np != 0)

        params_np = _params_global_numpy(variables, mesh)
        x_np = np.asarray(jax.device_get(x))

        def loss_fn(params, inputs):
            out, _ = _pure_jax_moe_reference(
                inputs,
                params["gate_kernel"],
                params["wi"],
                params["wo"],
                num_experts=NUM_EXPERTS,
                num_experts_per_tok=TOPK,
                score_function="softmax",
                expert_bias=None,
            )
            return jnp.mean(out.astype(jnp.float32) ** 2)

        grads_ref, grad_x_ref = jax.jit(jax.grad(loss_fn, argnums=(0, 1)))(
            {k: jnp.asarray(v) for k, v in params_np.items() if k != "expert_bias"},
            jnp.asarray(x_np),
        )
        for name in ("gate_kernel", "wi", "wo"):
            np.testing.assert_allclose(
                _to_global_numpy(_unwrap(grads["params"][name]), mesh).astype(np.float32),
                np.asarray(jax.device_get(grads_ref[name])).astype(np.float32),
                **(
                    GRAD_GATE_TOLERANCE["mxfp8"]
                    if name == "gate_kernel"
                    else GRAD_FFN_TOLERANCE["mxfp8"]
                ),
                err_msg=f"{name} fused MXFP8 gradient parity breach",
            )
        grad_x_ref_np = np.asarray(jax.device_get(grad_x_ref)).astype(np.float32)
        np.testing.assert_allclose(
            grad_x_np,
            grad_x_ref_np,
            **GRAD_FFN_TOLERANCE["mxfp8"],
            err_msg="d_x fused MXFP8 gradient parity breach",
        )
        # The mean-square loss makes dX smaller than the absolute tolerance.
        # Also bound relative error to catch a wrong MXFP8 quantization axis.
        relative_dx_error = np.linalg.norm(grad_x_np - grad_x_ref_np) / np.linalg.norm(
            grad_x_ref_np
        )
        assert (
            relative_dx_error < 0.1
        ), f"d_x MXFP8 relative L2 error {relative_dx_error:.3%} >= 10%"

    def test_cudnn_fused_with_checkpoint_names(
        self, mesh, monkeypatch, make_block, use_cudnn_fusion
    ):
        if not use_cudnn_fusion:
            pytest.skip("cuDNN grouped GEMM fusion is disabled")
        from transformer_engine.jax import cpp_extensions as tex

        available, reason = tex.grouped_gemm_glu_dependencies_available()
        if not available:
            pytest.skip(reason)

        moe_module = importlib.import_module("transformer_engine.jax.moe")
        flax_moe_module = importlib.import_module("transformer_engine.jax.flax.moe")
        selected_calls = []
        fused_op_name = "grouped_gemm_glu"
        original_fused_op = getattr(tex, fused_op_name)

        def checked_fused_op(*args, **kwargs):
            selected_calls.append(True)
            return original_fused_op(*args, **kwargs)

        monkeypatch.setattr(tex, fused_op_name, checked_fused_op)
        named_values = {}
        original_checkpoint_name = moe_module.checkpoint_name

        def recorded_checkpoint_name(value, name):
            named_values.setdefault(name, []).append(value)
            return original_checkpoint_name(value, name)

        monkeypatch.setattr(moe_module, "checkpoint_name", recorded_checkpoint_name)
        original_moe = flax_moe_module.moe

        def checkpointed_moe(*args, **kwargs):
            kwargs.update(
                wi_0_checkpoint_name="moe_mlpwi_0",
                wi_1_checkpoint_name="moe_mlpwi_1",
                wo_checkpoint_name="moe_mlpwo",
            )
            return original_moe(*args, **kwargs)

        monkeypatch.setattr(flax_moe_module, "moe", checkpointed_moe)
        block = make_block(
            quantization_recipe=MXFP8BlockScaling(),
            dispatch_checkpoint_name="saved_dispatch",
        )
        inputs = _make_inputs(jax.random.PRNGKey(32))
        variables, output, _, _ = _init_apply(block, mesh, inputs, jax.random.PRNGKey(33))
        grads, grad_inputs = _grad_step(block, variables, mesh, inputs)

        assert selected_calls, f"{fused_op_name} was not selected"
        for label in ("moe_mlpwi_0", "moe_mlpwi_1"):
            assert len(named_values[label]) == 5 * len(selected_calls)
            assert all(hasattr(value, "shape") for value in named_values[label])
        assert len(named_values["moe_mlpwo"]) == len(selected_calls)
        assert all(hasattr(value, "shape") for value in named_values["moe_mlpwo"])
        assert len(named_values["saved_dispatch"]) >= 2 * len(selected_calls)
        assert np.all(np.isfinite(_to_global_numpy(output, mesh)))
        assert np.all(np.isfinite(_to_global_numpy(grad_inputs, mesh)))
        for name in ("gate_kernel", "wi", "wo"):
            assert np.all(np.isfinite(_to_global_numpy(_unwrap(grads["params"][name]), mesh)))


class TestTeEpMoeAuxLoss:
    """Aux-loss path. Consolidated into:
    * ``test_aux_loss``: one run that checks the returned scalar's
      shape / dtype / finiteness / magnitude AND numerical parity vs the
      reference AND that the aux-only bwd propagates to gate_kernel.
    * ``test_combined_loss_grads``: one run for joint main+aux bwd
      finite + non-zero per tensor.
    """

    def test_aux_loss(self, mesh, make_block):
        coeff = 1e-2
        block = make_block(aux_loss_coeff=coeff)
        x = _make_inputs(jax.random.PRNGKey(20))
        variables, _, aux, _ = _init_apply(block, mesh, x, jax.random.PRNGKey(21))

        # Shape / dtype / finiteness / magnitude.
        assert aux is not None, "aux_loss should be returned when coeff > 0"
        assert aux.shape == (), f"aux_loss must be 0-d scalar, got {aux.shape}"
        assert aux.dtype == DTYPE, f"aux_loss dtype {aux.dtype} != {DTYPE}"
        aux_np = _to_global_numpy(aux, mesh)
        assert np.isfinite(aux_np), "aux_loss is NaN/Inf"
        assert abs(float(aux_np)) < 1e2, f"aux_loss looks unreasonable: {aux_np}"

        # Numerical parity vs the reference.
        params_np = _params_global_numpy(variables, mesh)
        x_np = np.asarray(jax.device_get(x))
        _, aux_ref = _pure_jax_moe_reference(
            jnp.asarray(x_np),
            jnp.asarray(params_np["gate_kernel"]),
            jnp.asarray(params_np["wi"]),
            jnp.asarray(params_np["wo"]),
            num_experts=NUM_EXPERTS,
            num_experts_per_tok=TOPK,
            aux_loss_coeff=coeff,
        )
        np.testing.assert_allclose(
            float(aux_np),
            float(jax.device_get(aux_ref)),
            **AUX_TOLERANCE,
        )

        # Aux-only bwd must propagate to gate_kernel — proves the
        # fused_moe_aux_loss_bwd → topk(compute_aux_scores)_bwd chain is
        # wired.
        aux_grads = _grad_aux_only(block, variables, mesh, x)
        g_gate = np.asarray(
            jax.device_get(_unwrap(aux_grads["params"]["gate_kernel"]).addressable_data(0))
        )
        assert np.all(np.isfinite(g_gate)), "gate grad NaN/Inf under aux-only loss"
        assert np.any(g_gate != 0.0), "aux bwd should propagate to gate_kernel"

    def test_combined_loss_grads(self, mesh, make_block):
        """Joint main + aux loss bwd: per-tensor finite + non-zero in
        one pass."""
        block = make_block(aux_loss_coeff=1e-2)
        x = _make_inputs(jax.random.PRNGKey(22))
        variables, _, _, _ = _init_apply(block, mesh, x, jax.random.PRNGKey(23))
        grads, _ = _grad_step(block, variables, mesh, x, include_aux=True)
        for name in ("gate_kernel", "wi", "wo"):
            g_local = np.asarray(jax.device_get(_unwrap(grads["params"][name]).addressable_data(0)))
            assert np.all(np.isfinite(g_local)), f"{name} grad NaN/Inf under main+aux"
            assert np.any(g_local != 0.0), f"{name} grad zero under main+aux"
