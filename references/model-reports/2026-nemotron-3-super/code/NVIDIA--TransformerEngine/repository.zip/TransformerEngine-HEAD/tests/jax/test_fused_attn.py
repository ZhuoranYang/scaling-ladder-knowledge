# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.
"""Tests for fused attention"""
import os
from enum import Enum, auto
from dataclasses import dataclass, field, replace
from functools import partial
from math import sqrt
from typing import Any, Callable, Mapping, Tuple, Optional, Dict
import random

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from flax.linen import combine_masks
from flax.linen import make_attention_mask
from flax.linen.dtypes import promote_dtype
from jax import Array
from jax import value_and_grad, jit
from jax.sharding import Mesh, NamedSharding, PartitionSpec
from jax.typing import ArrayLike, DTypeLike

from transformer_engine.jax import autocast
from transformer_engine.jax.sharding import MeshResource
from transformer_engine.jax.attention import (
    AttnBiasType,
    AttnMaskType,
    AttnSoftmaxType,
    QKVLayout,
    QKVFormat,
    reorder_causal_load_balancing,
    inverse_reorder_causal_load_balancing,
    fused_attn,
    run_length_fill,
    make_swa_mask,
    SequenceDescriptor,
    CPStrategy,
    ReorderStrategy,
)
from transformer_engine.jax.cpp_extensions import FusedAttnHelper
from transformer_engine_jax import (
    NVTE_Fused_Attn_Backend,
    get_cudnn_version,
    get_device_compute_capability,
)

from distributed_test_base import assert_equal_collectives
from utils import assert_allclose, dtype_tols, get_test_level, print_debug_tensor_stats

# Get determinism
_deterministic = not bool(int(os.getenv("NVTE_ALLOW_NONDETERMINISTIC_ALGO", "1")))

# CI test level
_TEST_LEVEL = get_test_level()


@pytest.fixture(autouse=True, scope="module")
def init():
    """
    WAR for CUDA uninitialize error
    """
    # Calling customcalls before jax may cause CUDA uninitialize error
    _ = jnp.zeros(0)
    yield


@partial(jax.jit, static_argnums=(6, 7, 8, 9, 11, 12, 13))
def general_dot_product_attention(
    query: ArrayLike,
    key: ArrayLike,
    value: ArrayLike,
    softmax_offset: Optional[ArrayLike],
    bias: ArrayLike,
    mask: ArrayLike,
    deterministic: bool,
    softmax_type: AttnSoftmaxType,
    scale_factor: float,
    dropout_rate: float,
    dropout_rng: ArrayLike,
    dtype: DTypeLike,
    score_mod_reference: Optional[Callable[[Array], Array]] = None,
    is_max_logit_enabled: bool = False,
) -> Array:
    """
    Similar to flax.linen.dot_product_attention but with GQA support
    """
    query, key, value, bias = promote_dtype(query, key, value, bias, dtype=dtype)
    dtype = query.dtype
    b, s_q, h_q, d = query.shape
    _, s_kv, h_kv, _ = key.shape
    assert (h_q % h_kv == 0) and (h_q >= h_kv)
    num_groups = h_q // h_kv
    grouped_query = jnp.reshape(query, (b, s_q, h_kv, num_groups, d))
    logits = scale_factor * jnp.einsum("...qhgd,...khd->...hgqk", grouped_query, key)

    if bias is not None:
        logits = logits.reshape((b, h_kv * num_groups, s_q, s_kv))
        logits = logits + bias
        logits = logits.reshape((b, h_kv, num_groups, s_q, s_kv))

    if mask is not None:
        if mask.ndim != logits.ndim:
            mask = jnp.expand_dims(mask, axis=-3)
        logits = jnp.where(mask, jnp.finfo(dtype).min, logits)

    if score_mod_reference is not None:
        # Kernel tests use NO_MASK; fused_attn rejects mask+score_mod before this reference path.
        logits = score_mod_reference(logits.astype(jnp.float32))
    if is_max_logit_enabled:
        return jnp.max(logits.reshape((b, h_q, s_q, s_kv)), axis=(0, 2, 3)).astype(dtype)

    match softmax_type:
        case AttnSoftmaxType.VANILLA_SOFTMAX:
            softmax_out = jax.nn.softmax(logits).astype(dtype)
        case AttnSoftmaxType.OFF_BY_ONE_SOFTMAX:
            # Softmax with +1 in denominator: exp(x_i) / (sum(exp(x_j)) + 1)
            # Append a zero logit, apply standard softmax, then remove last column
            zero_logit = jnp.zeros(logits.shape[:-1] + (1,), dtype=logits.dtype)
            logits_with_extra = jnp.concatenate([logits, zero_logit], axis=-1)
            softmax_with_extra = jax.nn.softmax(logits_with_extra, axis=-1)
            softmax_out = softmax_with_extra[..., :-1].astype(dtype)
        case AttnSoftmaxType.LEARNABLE_SOFTMAX:
            # Append learnable offset logit, apply standard softmax, then remove last column
            learnable_logit = softmax_offset.reshape(1, h_kv, num_groups, 1, 1)
            learnable_logit = jnp.broadcast_to(learnable_logit, logits.shape[:-1] + (1,))
            logits_with_extra = jnp.concatenate([logits, learnable_logit], axis=-1)
            softmax_with_extra = jax.nn.softmax(logits_with_extra, axis=-1)
            softmax_out = softmax_with_extra[..., :-1].astype(dtype)
        case _:
            raise NotImplementedError(f"Unknown {softmax_type=}")

    if not deterministic and dropout_rate > 0.0:
        keep_prob = 1.0 - dropout_rate
        keep = jax.random.bernoulli(dropout_rng, keep_prob, softmax_out.shape)
        multiplier = keep.astype(dtype) / jnp.asarray(keep_prob, dtype=dtype)
        softmax_out = softmax_out * multiplier

    context = jnp.einsum("...hgqk,...khd->...qhgd", softmax_out, value)
    context_shape = query.shape[:-1] + (value.shape[-1],)
    context = jnp.reshape(context, context_shape)
    return context


@jax.jit
def make_causal_mask(
    segment_ids_q: ArrayLike,
    segment_ids_kv: ArrayLike,
    segment_pos_q: ArrayLike = None,
    segment_pos_kv: ArrayLike = None,
) -> Array:
    """
    Create inverse padded causal mask where `True` means allowing the corresponding
    position to participate in attention and `False` means masking out that position.
    If segment_pos is not provided, aragne of the segment_ids will be applied.
    """
    if segment_pos_q is None:
        segment_pos_q = jnp.broadcast_to(
            jnp.arange(segment_ids_q.shape[-1], dtype=jnp.int32), segment_ids_q.shape
        )
    if segment_pos_kv is None:
        segment_pos_kv = jnp.broadcast_to(
            jnp.arange(segment_ids_kv.shape[-1], dtype=jnp.int32), segment_ids_kv.shape
        )
    inv_causal_mask = make_attention_mask(segment_pos_q, segment_pos_kv, jnp.greater_equal)
    return inv_causal_mask


@partial(jax.jit, static_argnums=(4, 5))
def make_mask(
    segment_ids_q: ArrayLike,
    segment_ids_kv: ArrayLike,
    segment_pos_q: ArrayLike,
    segment_pos_kv: ArrayLike,
    attn_mask_type: AttnMaskType,
    window_size: Optional[Tuple[int, int]] = None,
) -> Array:
    """
    Create attention mask based on mask type. A `True` value in the mask means
    masking out the corresponding position and a `False` value means allowing
    that position to participate in attention.

    - segment_ids should start with 1, and using 0s for the paddings.
      Expected that each segment starts without paddings.
    - segment_pos marks the token position in the segments.

    A example pair of segments_ids and segment_pos:
    segment_ids: [1, 1, 1, 0, 2, 2, 2, 3, 3, 3, 4, 0, 0, 5, 5, 5]
    segment_pos: [0, 1, 2, 3, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2]
    """
    # segment masks
    inv_mask = make_attention_mask(
        segment_ids_q, segment_ids_kv, lambda x, y: (jnp.logical_and(jnp.equal(x, y), x != 0))
    )

    if segment_pos_q is None:
        segment_pos_q = jnp.broadcast_to(
            jnp.arange(segment_ids_q.shape[-1], dtype=jnp.int32), segment_ids_q.shape
        )
    if segment_pos_kv is None:
        segment_pos_kv = jnp.broadcast_to(
            jnp.arange(segment_ids_kv.shape[-1], dtype=jnp.int32), segment_ids_kv.shape
        )

    if attn_mask_type.is_bottom_right():
        run_length_out_q = run_length_fill(segment_ids_q)
        run_length_out_kv = run_length_fill(segment_ids_kv)
        bottom_right_causal_mask = make_attention_mask(
            run_length_out_q - segment_pos_q,
            run_length_out_kv - segment_pos_kv,
            jnp.less_equal,
        )
        inv_mask = combine_masks(bottom_right_causal_mask, inv_mask)
    elif attn_mask_type.is_causal():
        inv_causal_mask = make_attention_mask(
            segment_pos_q, segment_pos_kv, lambda x, y: jnp.greater_equal(x, y)
        )
        inv_mask = combine_masks(inv_causal_mask, inv_mask)

    # sliding window mask
    inv_swa_mask = (
        make_swa_mask(
            segment_pos_q,
            segment_pos_kv,
            window_size,
            dtype=jnp.bool_,
            segment_ids_q=segment_ids_q,
            segment_ids_kv=segment_ids_kv,
        )
        if attn_mask_type.is_bottom_right()
        else make_swa_mask(segment_pos_q, segment_pos_kv, window_size, dtype=jnp.bool_)
    )
    inv_mask = combine_masks(inv_mask, inv_swa_mask)
    mask = jnp.logical_not(inv_mask)
    return mask


@jax.jit
def get_seqlens_and_offsets(segment_ids):
    batch, max_seqlen = segment_ids.shape
    bincount_vmap = jax.vmap(partial(jnp.bincount, length=max_seqlen))
    seqlens_with_zero = bincount_vmap(segment_ids.astype(jnp.int32))
    seqlens = seqlens_with_zero[..., 1:]

    def _find_offsets(x):
        same_as_previous = jnp.logical_and(x[..., 1:] != x[..., :-1], x[..., 1:] != 0)
        first_column = x[..., :1] != 0
        same_as_previous = jnp.hstack((first_column, same_as_previous))
        return jax.vmap(partial(jnp.argwhere, size=x.shape[1], fill_value=-1))(
            same_as_previous
        ).squeeze(-1)

    offsets = _find_offsets(segment_ids)
    offsets = jnp.insert(offsets, offsets.shape[-1], values=-1, axis=-1)
    seqlens = jnp.insert(seqlens, seqlens.shape[-1], values=0, axis=-1)
    seqlens = jnp.where(seqlens, seqlens, -1)
    return seqlens, offsets


@jax.jit
def _split_valid_and_invalid(primitive, reference, pad):
    """Use JIT to speed up the verifications"""
    primitive_valid = jnp.where(pad[..., jnp.newaxis, jnp.newaxis], 0, primitive)
    primitive_invalid = jnp.where(pad[..., jnp.newaxis, jnp.newaxis], primitive, 0)
    reference_valid = jnp.where(pad[..., jnp.newaxis, jnp.newaxis], 0, reference)
    reference_invalid = jnp.where(pad[..., jnp.newaxis, jnp.newaxis], reference, 0)
    return primitive_valid, primitive_invalid, reference_valid, reference_invalid


def jax_dpa(
    query,
    key,
    value,
    bias,
    softmax_offset,
    mask,
    dropout_rng,
    is_max_logit_enabled=False,
    **kwargs,
):
    """
    JAX native dot product attention implementation
    """
    score_mod_reference = kwargs.get("score_mod_reference")
    if score_mod_reference is not None:
        if (
            bias is not None
            or softmax_offset is not None
            or mask is not None
            or dropout_rng is not None
        ):
            raise ValueError(
                "score_mod reference path expects no bias, mask, softmax offset, or dropout."
            )
        if kwargs["qkv_layout"] != QKVLayout.BSHD_BSHD_BSHD:
            raise ValueError(
                "score_mod reference path expects separate BSHD query/key/value tensors."
            )
        deterministic = not kwargs["is_training"]
        dropout_probability = kwargs["dropout_probability"]
        softmax_type = kwargs["softmax_type"]
    else:
        deterministic = not kwargs["is_training"]
        dropout_probability = kwargs["dropout_probability"]
        softmax_type = kwargs["softmax_type"]
    output = general_dot_product_attention(
        query,
        key,
        value,
        softmax_offset,
        bias,
        mask,
        deterministic=deterministic,
        scale_factor=kwargs["scaling_factor"],
        dropout_rate=dropout_probability,
        softmax_type=softmax_type,
        dropout_rng=dropout_rng,
        dtype=jnp.float32,
        score_mod_reference=score_mod_reference,
        is_max_logit_enabled=is_max_logit_enabled,
    )
    return output.astype(query.dtype)


def customcall_fused_dpa(
    query,
    key,
    value,
    bias,
    softmax_offset,
    sequence_descriptor,
    dropout_rng,
    **kwargs,
):
    """
    TE customcall dot product attention implementation
    """
    qkv_layout = kwargs["qkv_layout"]
    match qkv_layout:
        case QKVLayout.BS3HD | QKVLayout.T3HD:
            query, key, value = map(partial(jnp.expand_dims, axis=-3), [query, key, value])
            qkv = jnp.concatenate((query, key, value), axis=-3)
            qkv_args = (qkv,)
        case QKVLayout.BSHD_BS2HD | QKVLayout.THD_T2HD:
            key, value = map(partial(jnp.expand_dims, axis=-3), [key, value])
            kv = jnp.concatenate((key, value), axis=-3)
            qkv_args = (query, kv)
        case QKVLayout.BSHD_BSHD_BSHD | QKVLayout.THD_THD_THD:
            qkv_args = (query, key, value)
        case _:
            raise ValueError(f"Unsupported {qkv_layout=}")
    result = fused_attn(
        qkv_args, bias, sequence_descriptor, dropout_rng, softmax_offset=softmax_offset, **kwargs
    )
    if isinstance(result, tuple):
        output, max_logit = result
        return output.astype(query.dtype), max_logit
    return result.astype(query.dtype)


def test_fused_attn_score_mod_rejects_masks_before_cudnn_frontend():
    """fused_attn rejects score_mod with masks before cuDNN frontend graph building."""
    q = jax.ShapeDtypeStruct((1, 16, 1, 128), jnp.float16)
    k = jax.ShapeDtypeStruct((1, 16, 1, 128), jnp.float16)
    v = jax.ShapeDtypeStruct((1, 16, 1, 128), jnp.float16)

    def score_mod(_graph, score, _tensors):
        return score

    with pytest.raises(ValueError, match="mutually exclusive with attention masks"):
        fused_attn(
            (q, k, v),
            None,
            None,
            None,
            AttnBiasType.NO_BIAS,
            AttnMaskType.CAUSAL_MASK,
            QKVLayout.BSHD_BSHD_BSHD,
            AttnSoftmaxType.VANILLA_SOFTMAX,
            1.0,
            0.0,
            True,
            score_mod=score_mod,
        )


def test_fused_attn_backend_message():
    """Test the error messaging of the fused attention backend query."""
    baseline = FusedAttnHelper(
        is_training=True,
        batch_size=2,
        q_dtype=jnp.bfloat16,
        kv_dtype=jnp.bfloat16,
        qkv_layout=QKVLayout.BSHD_BSHD_BSHD,
        attn_bias_type=AttnBiasType.NO_BIAS,
        attn_mask_type=AttnMaskType.NO_MASK,
        softmax_type=AttnSoftmaxType.VANILLA_SOFTMAX,
        dropout_probability=0.0,
        q_num_heads=8,
        kv_num_heads=8,
        q_max_seqlen=128,
        kv_max_seqlen=128,
        head_dim_qk=64,
        head_dim_v=64,
        window_size=(-1, -1),
        attn_scale=0.125,
    )

    # One of TE's rules is violated and the error message is surfaced
    backend, message = replace(
        baseline, attn_bias_type=AttnBiasType.PRE_SCALE_BIAS
    ).get_fused_attn_backend()
    assert backend == NVTE_Fused_Attn_Backend.NVTE_No_Backend
    assert message == "Fused attention does not support pre-scale bias."

    # No error message if supported; otherwise skip the test
    backend, message = baseline.get_fused_attn_backend()
    if backend == NVTE_Fused_Attn_Backend.NVTE_No_Backend:
        pytest.skip(f"FusedAttention does not support the baseline config: {message}")
    assert message == ""

    # All TE rules have cleared; now gets rejected by cuDNN's support check
    # cuDNN's error message might change across cuDNN versions, so only verify the presence of the string
    backend, message = replace(baseline, head_dim_qk=1024, head_dim_v=1024).get_fused_attn_backend()
    assert backend == NVTE_Fused_Attn_Backend.NVTE_No_Backend
    assert message != ""


class BiasShape(Enum):
    """
    Enum class to represent the different bias shapes used in the fused attention.
    """

    _1HSS = "1HSS"
    _B1SS = "B1SS"
    _BHSS = "BHSS"
    _11SS = "11SS"


class SeqDescFormat(Enum):
    Mask = auto()
    Seqlens = auto()
    SegmentIDs = auto()


@dataclass
class FusedAttnRunner:
    """
    Fused attention runner
    """

    batch_size: int
    max_seqlen_q: int
    max_seqlen_kv: int
    num_heads_q: int
    num_heads_kv: int
    head_dim_qk: int
    head_dim_v: int
    attn_bias_type: AttnBiasType
    attn_mask_type: AttnMaskType
    softmax_type: AttnSoftmaxType
    dropout_prob: float
    dtype: DTypeLike
    is_training: bool
    qkv_layout: QKVLayout
    bias_shape: BiasShape
    window_size: Tuple[int, int]
    seq_desc_format: SeqDescFormat
    stripe_size: int | None = None
    num_segments_per_seq: int | None = None

    # Specifies sharding resources for distributed tests
    number_of_devices: int = 1
    mesh_shape: tuple[int, ...] = (1, 1, 1)
    mesh_axes: tuple[str, ...] = ("dp", "cp", "tp")
    mesh_resource: MeshResource = field(default_factory=partial(MeshResource, "dp", "cp", "tp"))

    # Context parallel aux arguments
    cp_strategy: CPStrategy = CPStrategy.DEFAULT
    cp_load_balanced: bool = True

    # dictionary of expected collective comm bytes
    coll_count_ref: Optional[Dict[str, int]] = None

    # Optional score_mod test hooks.
    score_mod: Optional[Callable] = None
    score_mod_bprop: Optional[Callable] = None
    score_mod_tensors: Optional[Mapping[str, Any]] = None
    score_mod_bprop_tensors: Optional[Mapping[str, Any]] = None
    score_mod_reference: Optional[Callable[[Array], Array]] = None
    input_scale: float = 1.0
    doutput_seed: Optional[int] = None
    is_self_attention: Optional[bool] = None
    doutput: Optional[Array] = field(init=False, default=None)
    rtol: Optional[float] = None
    atol: Optional[float] = None

    def __post_init__(self):
        # Reset defaults for num_segments_per_seq if not explicitly passed
        if self.num_segments_per_seq is None:
            if self.qkv_layout.is_thd():
                self.num_segments_per_seq = 2
            else:
                self.num_segments_per_seq = 1
        if self.doutput_seed is not None:
            output_shape = (
                self.batch_size,
                self.max_seqlen_q,
                self.num_heads_q,
                self.head_dim_v,
            )
            self.doutput = jax.random.normal(
                jax.random.PRNGKey(self.doutput_seed), output_shape, dtype=self.dtype
            )

    def _get_max_segments_per_sequence(self):
        if self.qkv_layout.is_thd():
            # +1 for testing runtime_segments < max_segments
            return self.num_segments_per_seq + 1
        else:
            return 1

    def _check_configs(self):
        # Trim SWA configs for L0 and L1 to reduce test time; need to trim more in future test refactoring.
        if self.window_size is not None and (
            self.dropout_prob != 0.0 or self.attn_bias_type is not AttnBiasType.NO_BIAS
        ):
            if _TEST_LEVEL == "L0" and (
                self.softmax_type != AttnSoftmaxType.VANILLA_SOFTMAX
                or self.dtype != jnp.bfloat16
                or self.attn_bias_type is not AttnBiasType.POST_SCALE_BIAS
                or self.attn_mask_type is not AttnMaskType.NO_MASK
            ):
                pytest.skip(
                    "Trimmed SWA+bias/dropout config: only vanilla-softmax + bf16 + post_scale_bias"
                    " + no-mask runs at L0"
                )
            if _TEST_LEVEL == "L1" and (
                self.dtype != jnp.float16 or self.softmax_type != AttnSoftmaxType.LEARNABLE_SOFTMAX
            ):
                pytest.skip(
                    "Trimmed SWA+bias/dropout config: only float16 + learnable-softmax runs at L1"
                )

        # TODO(KshitijLakhani): probably add/move this to is_fused_attn_available
        if self.qkv_layout.is_thd() and not self.attn_mask_type.is_padding():
            pytest.skip("THD format requires padding masks.")

        if self.attn_mask_type.is_bottom_right():
            if self.max_seqlen_q > self.max_seqlen_kv:
                pytest.skip(
                    "BRCM requires cross attn type pattern, i.e.max_seqlen_kv >= max_seqlen_q"
                )
            if self.attn_bias_type is not AttnBiasType.NO_BIAS:
                pytest.skip("cuDNN does not support pre or post scale bias for BRCM")
            if self.dropout_prob != 0.0:
                pytest.skip("cuDNN does not support non-zero dropouts for BRCM")

        if self.qkv_layout.is_qkvpacked():
            if self.max_seqlen_q != self.max_seqlen_kv:
                pytest.skip(f"{self.qkv_layout} requires max_seqlen_q == max_seqlen_kv")
            if self.num_heads_q != self.num_heads_kv:
                pytest.skip(f"{self.qkv_layout} requires num_heads_q == num_heads_kv")

        if self.max_seqlen_q > self.max_seqlen_kv and self.window_size is not None:
            pytest.skip(
                "seqlen_q > seqlen_kv is not supported with sliding window attention in cuDNN"
            )
        compute_capability = get_device_compute_capability(0)
        cudnn_version = get_cudnn_version()
        # D=256 bprop on SM10x uses the deterministic algorithm path only. BSHD support
        # starts with cuDNN FE 1.24 / BE 9.23; THD execution-plan support starts with
        # cuDNN FE 1.26 / BE 9.25. The kernel rejects dBias, dropout, and ALiBi, supports vanilla
        # softmax only, and allows SWA together with a causal mask only.
        is_sm10x = 100 <= compute_capability < 110
        if self.is_training and is_sm10x and (self.head_dim_qk == 256 or self.head_dim_v == 256):
            if self.head_dim_qk != 256 or self.head_dim_v != 256:
                pytest.skip(
                    "D=256 BWD on Blackwell only supports d_qk == d_v == 256;"
                    f" got d_qk={self.head_dim_qk}, d_v={self.head_dim_v}."
                )
            required_cudnn_version = 92500 if self.qkv_layout.is_thd() else 92300
            required_cudnn_version_label = "9.25" if self.qkv_layout.is_thd() else "9.23"
            if cudnn_version < required_cudnn_version:
                pytest.skip(
                    f"D=256 BWD on Blackwell with {self.qkv_layout} requires cuDNN"
                    f" {required_cudnn_version_label} or newer; got cuDNN {cudnn_version}."
                )
            # TODO(KshitijLakhani): cuDNN FE can model bias input separately from dBias,
            # but TE does not yet plumb whether dBias is requested into the common backend selector.
            # Until that distinction is available, the D=256 SM10x gate requires no bias.
            unsupported = None
            if self.attn_bias_type == AttnBiasType.PRE_SCALE_BIAS:
                unsupported = "pre-scale bias"
            elif self.attn_bias_type != AttnBiasType.NO_BIAS:
                unsupported = (
                    "post-scale bias in TE's D=256 backend gate; bias-input-only"
                    " support needs TE to distinguish between bias input and dBias"
                )
            elif self.dropout_prob != 0.0:
                unsupported = "dropout"
            elif self.softmax_type != AttnSoftmaxType.VANILLA_SOFTMAX:
                unsupported = "non-vanilla softmax"
            if unsupported is not None:
                pytest.skip(
                    "D=256 BWD on Blackwell uses the deterministic SM100 D=256 SDPA BWD"
                    f" kernel which does not support {unsupported}."
                )
            if self.window_size is not None and self.window_size != (-1, -1):
                if not self.attn_mask_type.is_causal():
                    pytest.skip(
                        "D=256 BWD on Blackwell uses the SM100 D=256 SDPA BWD kernel"
                        " which requires window_size=(-1, -1) for non-causal masks."
                    )
                if self.window_size[1] not in (-1, 0):
                    pytest.skip(
                        "D=256 BWD on Blackwell only supports right window -1 or 0"
                        " for causal masks."
                    )

        if compute_capability >= 100 and self.is_training:
            if FusedAttnHelper.is_non_deterministic_allowed() and (
                self.dropout_prob != 0.0 and self.attn_bias_type != AttnBiasType.NO_BIAS
            ):
                pytest.skip(
                    "For sm100+, non-deterministic bprop does not support bias with dropout"
                )
            if not FusedAttnHelper.is_non_deterministic_allowed() and (
                self.dropout_prob != 0.0
                or self.attn_bias_type != AttnBiasType.NO_BIAS
                or cudnn_version < 91801
            ):
                pytest.skip(
                    "For sm100+, deterministic bprop (cuDNN 9.18.1+) does not support bias or"
                    " dropout"
                )
        # Test the MLA case where head dims for qk differ from head dims for v, only if the tensors
        # are provided in BSHD_BSHD_BSHD or THD_THD_THD formats
        if self.head_dim_qk != self.head_dim_v and not self.qkv_layout.is_separate():
            pytest.skip(
                "For head_dim_qk != head_dim_v, it is necessary that the QKV layout "
                "is either BSHD_BSHD_BSHD or THD_THD_THD"
            )

        bias_batch = bias_heads = bias_seqlen_q = bias_seqlen_kv = None
        if self.attn_bias_type == AttnBiasType.POST_SCALE_BIAS:
            if self.bias_shape == BiasShape._1HSS:
                bias_batch, bias_heads = 1, self.num_heads_q
            elif self.bias_shape == BiasShape._B1SS:
                bias_batch, bias_heads = self.batch_size, 1
            elif self.bias_shape == BiasShape._BHSS:
                bias_batch, bias_heads = self.batch_size, self.num_heads_q
            elif self.bias_shape == BiasShape._11SS:
                bias_batch, bias_heads = 1, 1
            bias_seqlen_q, bias_seqlen_kv = self.max_seqlen_q, self.max_seqlen_kv

        self.backend, message = FusedAttnHelper(
            is_training=self.is_training,
            batch_size=self.batch_size,
            q_dtype=self.dtype,
            kv_dtype=self.dtype,
            qkv_layout=self.qkv_layout,
            attn_bias_type=self.attn_bias_type,
            attn_mask_type=self.attn_mask_type,
            softmax_type=self.softmax_type,
            dropout_probability=self.dropout_prob,
            q_num_heads=self.num_heads_q,
            kv_num_heads=self.num_heads_kv,
            q_max_seqlen=self.max_seqlen_q,
            kv_max_seqlen=self.max_seqlen_kv,
            head_dim_qk=self.head_dim_qk,
            head_dim_v=self.head_dim_v,
            window_size=(-1, -1) if self.window_size is None else self.window_size,
            bottom_right_diagonal=self.attn_mask_type.is_bottom_right(),
            bias_batch=bias_batch,
            bias_heads=bias_heads,
            bias_seqlen_q=bias_seqlen_q,
            bias_seqlen_kv=bias_seqlen_kv,
            max_segments_per_seq=self._get_max_segments_per_sequence(),
        ).get_fused_attn_backend()
        if self.backend != NVTE_Fused_Attn_Backend.NVTE_F16_arbitrary_seqlen:
            pytest.skip(message)

        if (
            self.attn_bias_type == AttnBiasType.POST_SCALE_BIAS
            and self.bias_shape != BiasShape._1HSS
        ):
            if self.attn_mask_type.is_padding():
                pytest.skip(
                    "B1SS, BHSS and 11SS bias shapes are only supported for non-padding mask"
                )

    def _setup_inputs(self):
        self._check_configs()

        # Create a mesh for distributed tests
        self.devices = np.asarray(jax.devices()[: self.number_of_devices]).reshape(*self.mesh_shape)
        self.mesh = Mesh(self.devices, self.mesh_axes)
        data_axes = tuple(
            axis
            for axis in (
                self.mesh_resource.dp_resource,
                self.mesh_resource.fsdp_resource,
            )
            if axis is not None
        )
        self.data_axis = data_axes[0] if len(data_axes) == 1 else data_axes or None
        self.data_parallel_size = np.prod([self.mesh.shape[axis] for axis in data_axes], dtype=int)
        self.cp_size = self.mesh.shape.get(self.mesh_resource.cp_resource, 1)
        self.tp_size = self.mesh.shape.get(self.mesh_resource.tpsp_resource, 1)

        key = jax.random.PRNGKey(0)
        q_key, k_key, v_key, bias_key, dropout_key, softmax_key = jax.random.split(key, 6)

        q_shape = (self.batch_size, self.max_seqlen_q, self.num_heads_q, self.head_dim_qk)
        k_shape = (self.batch_size, self.max_seqlen_kv, self.num_heads_kv, self.head_dim_qk)
        v_shape = (self.batch_size, self.max_seqlen_kv, self.num_heads_kv, self.head_dim_v)

        if self.attn_bias_type == AttnBiasType.NO_BIAS:
            bias_shape = None
        elif self.bias_shape == BiasShape._1HSS:
            bias_shape = (1, self.num_heads_q, self.max_seqlen_q, self.max_seqlen_kv)
        elif self.bias_shape == BiasShape._B1SS:
            bias_shape = (self.batch_size, 1, self.max_seqlen_q, self.max_seqlen_kv)
        elif self.bias_shape == BiasShape._BHSS:
            bias_shape = (
                self.batch_size,
                self.num_heads_q,
                self.max_seqlen_q,
                self.max_seqlen_kv,
            )
        elif self.bias_shape == BiasShape._11SS:
            bias_shape = (1, 1, self.max_seqlen_q, self.max_seqlen_kv)
        else:
            pytest.fail(f"PyTest attempted to use an unrecognized bias_layout = {self.bias_shape}!")

        self.q = (self.input_scale * jax.random.uniform(q_key, q_shape, self.dtype, -1.0)).astype(
            self.dtype
        )
        self.k = (self.input_scale * jax.random.uniform(k_key, k_shape, self.dtype, -1.0)).astype(
            self.dtype
        )
        self.v = (self.input_scale * jax.random.uniform(v_key, v_shape, self.dtype, -1.0)).astype(
            self.dtype
        )
        if self.attn_bias_type != AttnBiasType.NO_BIAS:
            if self.bias_shape == BiasShape._1HSS:
                self.bias = jax.random.uniform(bias_key, bias_shape, self.dtype, -1.0)
            else:
                # [b, 1, s, s], [b, h, s, s] and [1, 1, s, s] bias shapes are workarounds for
                # an arbitrary mask where (True/False -> 0/-Inf)
                cudnn_neg_inf = -(2.0**27.0) if self.dtype == jnp.bfloat16 else -(2.0**15.0)
                self.bias = jnp.full(bias_shape, cudnn_neg_inf, dtype=self.dtype)
                max_id = min(self.max_seqlen_q, self.max_seqlen_kv)
                seq_id_size = max_id * 5 // 128  # 5 ids per interval of 128 sequences
                seq_id = jax.random.randint(bias_key, (int(seq_id_size),), 0, max_id).tolist()
                for i in range(1, len(seq_id)):
                    self.bias = self.bias.at[
                        :, :, seq_id[i - 1] : seq_id[i], seq_id[i - 1] : seq_id[i]
                    ].set(0.0)
        else:
            self.bias = None

        if self.attn_mask_type.is_padding():
            pad_ratio = 0.3
        else:
            pad_ratio = 0.0

        if self.softmax_type == AttnSoftmaxType.LEARNABLE_SOFTMAX:
            self.softmax_offset = jax.random.uniform(
                softmax_key, (1, self.num_heads_q, 1, 1), jnp.float32, -1.0
            )
        else:
            self.softmax_offset = None

        def generate_valid_segment_ids_and_pos(bs, max_seqlen, pad_ratio):
            pad_len = int(max_seqlen * pad_ratio)
            valid_len = max_seqlen - pad_len
            tokens = jnp.concatenate(
                [
                    jnp.ones((bs, valid_len), dtype=jnp.int32),
                    jnp.zeros((bs, pad_len), dtype=jnp.int32),
                ],
                axis=-1,
            )
            segment_pos = jnp.broadcast_to(jnp.arange(max_seqlen, dtype=jnp.int32), tokens.shape)
            return tokens, segment_pos, jnp.logical_not(tokens)

        def generate_random_segment_ids_and_pos(
            batch_size,
            sequence_length,
            num_segments,
            seed,
            with_segment_pad=True,
            min_segment_len=None,
        ):
            rng = np.random.default_rng(seed=seed)
            # [1, 1, 1, 2, 2, 3, 3, 3, 3, 0, 0], 0 means pad
            segment_ids = np.zeros((batch_size, sequence_length), dtype=np.int32)
            segment_pos = np.zeros((batch_size, sequence_length), dtype=np.int32)
            # [0, 1, 2, 0, 1, 0, 1, 2, 3, 0, 0]
            # [0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1], 1 means pad
            segment_pad = np.zeros((batch_size, sequence_length), dtype=np.int32)

            # Not include paddings
            max_segment_size = sequence_length // num_segments
            for i in range(batch_size):
                current_pos = 0
                segment_id = 1

                for seg_id in range(num_segments):
                    # min_segment_len is to force kv_len >= q_len because cuDNN kernels failed
                    # TODO(rewang): Remove this constrain after cuDNN supports
                    min_segment_size = 1
                    if min_segment_len is not None:
                        min_segment_size = min_segment_len[i][seg_id]
                    segment_size = rng.integers(min_segment_size, max_segment_size + 1)
                    if current_pos + segment_size > sequence_length:
                        break
                    segment_end = current_pos + segment_size
                    segment_ids[i, current_pos:segment_end] = segment_id
                    segment_pos[i, current_pos:segment_end] = np.arange(segment_size)
                    if with_segment_pad:
                        num_valid = rng.integers(min_segment_size, segment_size + 1)
                        segment_pad[i, current_pos + num_valid : segment_end] = 1
                    current_pos = segment_end
                    segment_id += 1
                segment_pad[i, current_pos:sequence_length] = 1

            segment_ids, segment_pos, segment_pad = map(
                jnp.asarray, [segment_ids, segment_pos, segment_pad]
            )
            segment_ids = jnp.where(segment_pad, 0, segment_ids)
            return segment_ids, segment_pos, segment_pad

        if self.qkv_layout.is_thd():
            if self.qkv_layout.is_qkvpacked() and self.is_self_attention is False:
                raise ValueError("QKV-packed layouts only support self-attention metadata")
            self.segment_ids_q, self.segment_pos_q, self.pad_q = (
                generate_random_segment_ids_and_pos(
                    self.batch_size, self.max_seqlen_q, self.num_segments_per_seq, seed=42
                )
            )
            self.seqlens_q, self.offsets_q = get_seqlens_and_offsets(self.segment_ids_q)
            is_self_attention = self.is_self_attention
            if is_self_attention is None:
                is_self_attention = (
                    self.qkv_layout.is_qkvpacked() or self.max_seqlen_q == self.max_seqlen_kv
                )
            if is_self_attention:
                self.segment_ids_kv = self.segment_ids_q
                self.segment_pos_kv = self.segment_pos_q
                self.pad_kv = self.pad_q
            else:
                # Force kv_len >= q_len for swa, otherwise, cuDNN kernels don't support
                min_segment_len = None
                if (
                    self.window_size is not None or self.attn_mask_type.is_bottom_right()
                ):  # SWA or BRCM requires kv_len >= q_len
                    min_segment_len = self.seqlens_q
                self.segment_ids_kv, self.segment_pos_kv, self.pad_kv = (
                    generate_random_segment_ids_and_pos(
                        self.batch_size,
                        self.max_seqlen_kv,
                        self.num_segments_per_seq,
                        seed=2024,
                        min_segment_len=min_segment_len,
                    )
                )
            self.seqlens_kv, self.offsets_kv = get_seqlens_and_offsets(self.segment_ids_kv)
        else:
            self.segment_ids_q, self.segment_pos_q, self.pad_q = generate_valid_segment_ids_and_pos(
                self.batch_size, self.max_seqlen_q, pad_ratio
            )
            self.segment_ids_kv, self.segment_pos_kv, self.pad_kv = (
                generate_valid_segment_ids_and_pos(self.batch_size, self.max_seqlen_kv, pad_ratio)
            )
            self.seqlens_q = self.seqlens_kv = self.offsets_q = self.offsets_kv = None

        # For reference code
        self.mask = make_mask(
            self.segment_ids_q,
            self.segment_ids_kv,
            self.segment_pos_q,
            self.segment_pos_kv,
            self.attn_mask_type,
            self.window_size,
        )

        if self.cp_size > 1 and self.cp_load_balanced:
            if self.qkv_layout.is_thd():
                reorder_strategy = ReorderStrategy.Striped
            else:
                reorder_strategy = ReorderStrategy.DualChunkSwap

            seq_dim = 0 if self.qkv_layout.get_qkv_format() == QKVFormat.SBHD else 1
            self.cp_reorder_fn = partial(
                reorder_causal_load_balancing,
                strategy=reorder_strategy,
                cp_size=self.cp_size,
                seq_dim=seq_dim,
                stripe_size=self.stripe_size,
            )
            self.cp_inverse_reorder_fn = partial(
                inverse_reorder_causal_load_balancing,
                strategy=reorder_strategy,
                cp_size=self.cp_size,
                seq_dim=seq_dim,
                stripe_size=self.stripe_size,
            )
        else:
            # no-ops for non cp or non load balanced
            self.cp_reorder_fn = lambda x: x
            self.cp_inverse_reorder_fn = lambda x: x

        # Test different input formats
        if self.qkv_layout.is_thd():
            match self.seq_desc_format:
                case SeqDescFormat.Mask:
                    pytest.skip("THD doesn't support mask input")
                case SeqDescFormat.Seqlens:
                    self.sequence_desciptor = SequenceDescriptor.from_seqlens_and_offsets(
                        (self.seqlens_q, self.seqlens_kv),
                        (self.offsets_q, self.offsets_kv),
                    )
                case SeqDescFormat.SegmentIDs:
                    # from_segment_ids_and_pos requires explicit segment_pos.
                    self.sequence_desciptor = SequenceDescriptor.from_segment_ids_and_pos(
                        (
                            self.cp_reorder_fn(self.segment_ids_q),
                            self.cp_reorder_fn(self.segment_ids_kv),
                        ),
                        (
                            self.cp_reorder_fn(self.segment_pos_q),
                            self.cp_reorder_fn(self.segment_pos_kv),
                        ),
                    )
                case _:
                    raise ValueError(f"Unknown {self.seq_desc_format=}")
        else:
            match self.seq_desc_format:
                case SeqDescFormat.Mask:
                    if self.attn_mask_type == AttnMaskType.NO_MASK:
                        self.sequence_desciptor = None
                    else:
                        self.sequence_desciptor = make_mask(
                            self.segment_ids_q,
                            self.segment_ids_kv,
                            self.segment_pos_q,
                            self.segment_pos_kv,
                            self.attn_mask_type,
                        )
                case SeqDescFormat.Seqlens:
                    self.sequence_desciptor = SequenceDescriptor.from_seqlens(
                        (
                            self.segment_ids_q.sum(axis=-1).astype(jnp.int32),
                            self.segment_ids_kv.sum(axis=-1).astype(jnp.int32),
                        ),
                    )
                case SeqDescFormat.SegmentIDs:
                    self.sequence_desciptor = SequenceDescriptor.from_segment_ids_and_pos(
                        (self.segment_ids_q, self.segment_ids_kv),
                        (self.segment_pos_q, self.segment_pos_kv),
                    )
                case _:
                    raise ValueError(f"Unknown {self.seq_desc_format=}")

        self.dropout_rng = dropout_key if self.dropout_prob > 0 else None
        self.scaling_factor = 1.0 / sqrt(self.head_dim_qk)

        # Setup distributed sharding specs
        # Setup shardings for distributed tests
        self.qkvo_psec = PartitionSpec(
            self.data_axis,
            self.mesh_resource.cp_resource,
            self.mesh_resource.tpsp_resource,
            None,
        )
        self.qkvo_sharding = NamedSharding(self.mesh, self.qkvo_psec)

        mask_pspec = PartitionSpec(self.data_axis, None, self.mesh_resource.cp_resource, None)
        self.mask_sharding = NamedSharding(self.mesh, mask_pspec)

        match self.seq_desc_format:
            case SeqDescFormat.Mask:
                self.seq_desc_sharding = self.mask_sharding
            case _:

                def to_dp_shardings(x):
                    if x.ndim == 1:
                        pspec = PartitionSpec(self.data_axis)
                    else:
                        pspec = PartitionSpec(self.data_axis, self.mesh_resource.cp_resource)
                    return NamedSharding(self.mesh, pspec)

                self.seq_desc_sharding = jax.tree.map(to_dp_shardings, self.sequence_desciptor)

        if self.bias_shape == BiasShape._1HSS:
            self.bias_pspec = PartitionSpec(
                None, self.mesh_resource.tpsp_resource, self.mesh_resource.cp_resource, None
            )
        elif self.bias_shape == BiasShape._B1SS:
            self.bias_pspec = PartitionSpec(
                self.data_axis, None, self.mesh_resource.cp_resource, None
            )
        elif self.bias_shape == BiasShape._11SS:
            self.bias_pspec = PartitionSpec(None, None, self.mesh_resource.cp_resource, None)
        else:
            self.bias_pspec = PartitionSpec()
        self.bias_sharding = NamedSharding(self.mesh, self.bias_pspec)

        # Softmax offset sharding (1, num_heads, 1, 1)
        # Use the same logic as HEAD_AXES: tpsp_resource if enabled, else tp_resource
        head_resource = (
            self.mesh_resource.tpsp_resource
            if self.mesh_resource.tpsp_resource is not None
            else self.mesh_resource.tp_resource
        )
        self.softmax_offset_pspec = PartitionSpec(None, head_resource, None, None)
        self.softmax_offset_sharding = NamedSharding(self.mesh, self.softmax_offset_pspec)

        self.dropout_rng_pspec = PartitionSpec(
            None,
        )
        self.dropout_rng_sharding = NamedSharding(self.mesh, self.dropout_rng_pspec)

        self.logit_scale_pspec = PartitionSpec(None, None, self.mesh_resource.cp_resource, None)
        self.logit_scale_sharding = NamedSharding(self.mesh, self.logit_scale_pspec)

        # [batch][max_segments_per_batch]
        # TODO(mgoldfarb-nvidia): Will need to handle CP cases of replicated or distributed length/offset.
        self.seq_length_offset_pspec = PartitionSpec(self.data_axis, None)
        self.seq_length_offset_sharding = NamedSharding(self.mesh, self.seq_length_offset_pspec)

    def test_forward(self, return_max_logit=False, check_output=True):
        """
        Test forward with JITted primitive and unJITted reference
        """
        self._setup_inputs()

        reference_mask = (
            self.sequence_desciptor if self.score_mod_reference is not None else self.mask
        )
        args = [
            self.q,
            self.k,
            self.v,
            self.bias,
            self.softmax_offset,
            reference_mask,
            self.dropout_rng,
        ]

        customcall_args = [
            # Put test data onto each GPU for distributed.
            # TODO(mgoldfarb-nvidia): We will need to add reordering for bias, mask and
            # THD params once we support those features on CP.
            jax.device_put(self.cp_reorder_fn(self.q), self.qkvo_sharding),
            jax.device_put(self.cp_reorder_fn(self.k), self.qkvo_sharding),
            jax.device_put(self.cp_reorder_fn(self.v), self.qkvo_sharding),
            jax.device_put(self.bias, self.bias_sharding),
            jax.device_put(self.softmax_offset, self.softmax_offset_sharding),
            jax.device_put(self.sequence_desciptor, self.seq_desc_sharding),
            jax.device_put(self.dropout_rng, self.dropout_rng_sharding),
        ]
        kwargs = {
            "attn_bias_type": self.attn_bias_type,
            "attn_mask_type": self.attn_mask_type,
            "softmax_type": self.softmax_type,
            "scaling_factor": self.scaling_factor,
            "dropout_probability": self.dropout_prob,
            "is_training": self.is_training,
            "qkv_layout": self.qkv_layout,
            "max_segments_per_seq": self._get_max_segments_per_sequence(),
            "window_size": self.window_size,
            "context_parallel_strategy": self.cp_strategy,
            "context_parallel_causal_load_balanced": self.cp_load_balanced,
            "stripe_size": self.stripe_size,
            "score_mod": self.score_mod,
            "score_mod_bprop": self.score_mod_bprop,
            "score_mod_tensors": self.score_mod_tensors,
            "score_mod_bprop_tensors": self.score_mod_bprop_tensors,
            "return_max_logit": return_max_logit,
        }
        reference_kwargs = {**kwargs, "score_mod_reference": self.score_mod_reference}

        customcall_fused_dpa_jit = jit(
            partial(customcall_fused_dpa, **kwargs),
            static_argnames=kwargs.keys(),
            in_shardings=[
                self.qkvo_sharding,
                self.qkvo_sharding,
                self.qkvo_sharding,
                self.bias_sharding,
                self.softmax_offset_sharding,
                self.seq_desc_sharding,
                self.dropout_rng_sharding,
            ],
        )

        with self.mesh, autocast(mesh_resource=self.mesh_resource):
            primitive_out = customcall_fused_dpa_jit(*customcall_args)
            if return_max_logit:
                primitive_out, primitive_max_logit = primitive_out
            primitive_out = self.cp_inverse_reorder_fn(primitive_out)

        if return_max_logit:
            reference_max_logit = jax_dpa(*args, is_max_logit_enabled=True, **reference_kwargs)

        if check_output and not (self.is_training and self.dropout_prob > 0.0):
            reference_out = jax_dpa(*args, **reference_kwargs)

            primitive_valid, primitive_invalid, reference_valid, _ = _split_valid_and_invalid(
                primitive_out, reference_out, self.pad_q
            )

            assert_allclose(
                primitive_invalid,
                jnp.zeros_like(primitive_invalid),
                rtol=self.rtol,
                atol=self.atol,
                dtype=self.dtype,
            )
            assert_allclose(
                primitive_valid,
                reference_valid,
                rtol=self.rtol,
                atol=self.atol,
                dtype=self.dtype,
            )

        if return_max_logit:
            assert_allclose(primitive_max_logit, reference_max_logit, dtype=self.dtype)

        if self.coll_count_ref is not None:
            with self.mesh, autocast(mesh_resource=self.mesh_resource):
                target_hlo = (
                    customcall_fused_dpa_jit.lower(*customcall_args, **kwargs).compile().as_text()
                )
            assert_equal_collectives(target_hlo, self.coll_count_ref)

    def test_backward(self, return_max_logit=False):
        """
        Test value_and_grad with JIT, which includes both forward and backward.

        If coll_count_ref is not None then the HLO of the backwrds function
        HLO will be examined for the expected comms.
        """

        if self.doutput is None:
            raise ValueError("FusedAttnRunner.test_backward requires a random doutput_seed")

        self._setup_inputs()

        def grad_func(
            func,
            q,
            k,
            v,
            bias,
            softmax_offset,
            sequence_descriptor,
            dropout_rng,
            doutput=None,
            cp_reverse_out=False,
            **kwargs,
        ):
            # Gradient is small, use a gradient multiplier to amplify the gradient
            gradient_multiplier = self.max_seqlen_q * self.num_heads_q
            if self.attn_mask_type.is_causal():
                gradient_multiplier /= 10
            output = func(q, k, v, bias, softmax_offset, sequence_descriptor, dropout_rng, **kwargs)
            if isinstance(output, tuple):
                output, _ = output
            if cp_reverse_out:
                output = self.cp_inverse_reorder_fn(output)
            # Keep only valid result for the gradient
            ret_valid = jnp.where(self.pad_q[..., jnp.newaxis, jnp.newaxis], 0, output)
            if doutput is not None:
                return jnp.sum(ret_valid.astype(jnp.float32) * doutput.astype(jnp.float32)).astype(
                    self.dtype
                )
            return (
                jnp.mean(ret_valid.astype(jnp.float32), dtype=jnp.float32) * gradient_multiplier
            ).astype(self.dtype)

        reference_mask = (
            self.sequence_desciptor if self.score_mod_reference is not None else self.mask
        )
        args = [
            self.q,
            self.k,
            self.v,
            self.bias,
            self.softmax_offset,
            reference_mask,
            self.dropout_rng,
        ]
        customcall_args = [
            # TODO(mgoldfarb-nvidia): We will need to add reordering for bias, mask and
            # THD params once we support those features on CP.
            jax.device_put(self.cp_reorder_fn(self.q), self.qkvo_sharding),
            jax.device_put(self.cp_reorder_fn(self.k), self.qkvo_sharding),
            jax.device_put(self.cp_reorder_fn(self.v), self.qkvo_sharding),
            jax.device_put(self.bias, self.bias_sharding),
            jax.device_put(self.softmax_offset, self.softmax_offset_sharding),
            jax.device_put(self.sequence_desciptor, self.seq_desc_sharding),
            jax.device_put(self.dropout_rng, self.dropout_rng_sharding),
        ]
        input_shardings = [
            self.qkvo_sharding,
            self.qkvo_sharding,
            self.qkvo_sharding,
            self.bias_sharding,
            self.softmax_offset_sharding,
            self.seq_desc_sharding,
            self.dropout_rng_sharding,
        ]
        if self.doutput is not None:
            args.append(self.doutput)
            # Keep CP doutput in logical token order, as it would be when inferred by
            # JAX through the inverse reorder. TE must align it inside the backward rule.
            doutput_sharding = (
                NamedSharding(self.mesh, PartitionSpec())
                if self.cp_size > 1 and self.cp_load_balanced
                else self.qkvo_sharding
            )
            customcall_args.append(jax.device_put(self.doutput, doutput_sharding))
            input_shardings.append(doutput_sharding)
        kwargs = {
            "attn_bias_type": self.attn_bias_type,
            "attn_mask_type": self.attn_mask_type,
            "softmax_type": self.softmax_type,
            "scaling_factor": self.scaling_factor,
            "dropout_probability": self.dropout_prob,
            "is_training": self.is_training,
            "qkv_layout": self.qkv_layout,
            "max_segments_per_seq": self._get_max_segments_per_sequence(),
            "window_size": self.window_size,
            "context_parallel_strategy": self.cp_strategy,
            "context_parallel_causal_load_balanced": self.cp_load_balanced,
            "stripe_size": self.stripe_size,
            "score_mod": self.score_mod,
            "score_mod_bprop": self.score_mod_bprop,
            "score_mod_tensors": self.score_mod_tensors,
            "score_mod_bprop_tensors": self.score_mod_bprop_tensors,
            "return_max_logit": return_max_logit,
        }
        reference_kwargs = {**kwargs, "score_mod_reference": self.score_mod_reference}

        # We can compute dBias only for the [1, h, s, s] layout
        if self.bias_shape == BiasShape._1HSS:
            arg_nums = (0, 1, 2, 3)
            grad_shardings = (
                self.qkvo_sharding,
                self.qkvo_sharding,
                self.qkvo_sharding,
                self.bias_sharding,
            )
        else:
            arg_nums = (0, 1, 2)
            grad_shardings = (self.qkvo_sharding, self.qkvo_sharding, self.qkvo_sharding)

        # Use FP16/BF16 to sum the results may cause overflow, use FP32 for the summation
        jitted_primitive = jit(
            value_and_grad(
                lambda q, k, v, bias, softmax_offset, *args: grad_func(
                    customcall_fused_dpa,
                    q,
                    k,
                    v,
                    bias,
                    softmax_offset,
                    *args,
                    cp_reverse_out=True,
                    **kwargs,
                ),
                arg_nums,
            ),
            in_shardings=tuple(input_shardings),
            out_shardings=(None, grad_shardings),
        )
        jitted_reference = jit(
            value_and_grad(
                lambda q, k, v, bias, softmax_offset, *args: grad_func(
                    jax_dpa, q, k, v, bias, softmax_offset, *args, **reference_kwargs
                ),
                arg_nums,
            )
        )

        with self.mesh, autocast(mesh_resource=self.mesh_resource):
            primitive_out, primitive_dgrad = jitted_primitive(*customcall_args)

        reference_out, reference_dgrad = jitted_reference(*args)

        # Skip elementwise comparison when dropout enabled
        if self.dropout_prob > 0.0:
            return

        def check_dqkv(primitive, reference, pad, idx):
            primitive_valid, primitive_invalid, reference_valid, reference_invalid = (
                _split_valid_and_invalid(primitive, reference, pad)
            )

            print_debug_tensor_stats(f"primitive_grad_valid[{idx}]", primitive_valid[idx])
            print_debug_tensor_stats(f"reference_grad_valid[{idx}]", reference_valid[idx])
            print_debug_tensor_stats(
                f"diff_grad[{idx}]", jnp.abs(primitive_valid[idx] - reference_valid[idx])
            )

            assert_allclose(
                primitive_invalid,
                jnp.zeros_like(primitive_invalid),
                rtol=self.rtol,
                atol=self.atol,
                dtype=self.dtype,
            )
            assert_allclose(
                primitive_invalid,
                reference_invalid,
                rtol=self.rtol,
                atol=self.atol,
                dtype=self.dtype,
            )
            assert_allclose(
                primitive_valid,
                reference_valid,
                rtol=self.rtol,
                atol=self.atol,
                dtype=self.dtype,
            )

        primitive_dq, primitive_dk, primitive_dv = primitive_dgrad[:3]
        reference_dq, reference_dk, reference_dv = reference_dgrad[:3]

        primitive_dq = self.cp_inverse_reorder_fn(primitive_dq)
        primitive_dk = self.cp_inverse_reorder_fn(primitive_dk)
        primitive_dv = self.cp_inverse_reorder_fn(primitive_dv)

        check_dqkv(primitive_dq, reference_dq, self.pad_q, 0)
        check_dqkv(primitive_dk, reference_dk, self.pad_kv, 1)
        check_dqkv(primitive_dv, reference_dv, self.pad_kv, 2)

        if self.attn_bias_type != AttnBiasType.NO_BIAS and self.bias_shape == BiasShape._1HSS:
            # TODO(mgoldfarb-nvidia): Inverse reorder bias once supported by a CP implementation.

            primitive_dbias = primitive_dgrad[3]
            reference_dbias = reference_dgrad[3]

            # Assume all batch has the same actual_seqlen, probably needs to extend the tests
            bias_mask = self.mask[0, 0]

            # Distributed dBias is the result of a BF16 reduction across DP/FSDP ranks,
            # whose summation order differs from the unsharded reference. Scale only the
            # default dBias tolerance with the expected reduction-error growth.
            dbias_rtol = self.rtol
            dbias_atol = self.atol
            if self.data_parallel_size > 1:
                default_tols = dtype_tols(self.dtype)
                reduction_scale = sqrt(self.data_parallel_size)
                if dbias_rtol is None:
                    dbias_rtol = default_tols["rtol"] * reduction_scale
                if dbias_atol is None:
                    dbias_atol = default_tols["atol"] * reduction_scale

            # Assert all masked dbias are 0s
            assert_allclose(
                jnp.where(bias_mask, primitive_dbias, 0),
                jnp.zeros_like(primitive_dbias),
                rtol=dbias_rtol,
                atol=dbias_atol,
                dtype=self.dtype,
            )

            # dbias padded part
            assert_allclose(
                jnp.where(bias_mask, primitive_dbias, 0),
                jnp.where(bias_mask, reference_dbias, 0),
                rtol=dbias_rtol,
                atol=dbias_atol,
                dtype=self.dtype,
            )

            # dbias valid part
            assert_allclose(
                jnp.where(bias_mask, 0, primitive_dbias),
                jnp.where(bias_mask, 0, reference_dbias),
                rtol=dbias_rtol,
                atol=dbias_atol,
                dtype=self.dtype,
            )

        if self.coll_count_ref is not None:
            with self.mesh, autocast(mesh_resource=self.mesh_resource):
                target_hlo = jitted_primitive.lower(*customcall_args).compile().as_text()
            assert_equal_collectives(target_hlo, self.coll_count_ref)


FUSED_ATTN_MAX_LOGIT_QKV_LAYOUTS = [
    pytest.param(
        QKVLayout.BSHD_BSHD_BSHD,
        8,
        8,
        id="BSHD_SEPARATE",
    ),
    pytest.param(
        QKVLayout.BS3HD,
        8,
        8,
        id="BS3HD",
    ),
    pytest.param(
        QKVLayout.BSHD_BS2HD,
        8,
        4,
        id="BSHD_KV_PACKED-GQA",
    ),
    pytest.param(
        QKVLayout.T3HD,
        8,
        8,
        id="THD_QKV_PACKED",
    ),
    pytest.param(
        QKVLayout.THD_THD_THD,
        8,
        8,
        id="THD_SEPARATE",
    ),
]


class TestFusedAttnMaxLogit:
    """Targeted non-CP max_logit coverage."""

    @staticmethod
    @pytest.mark.parametrize(
        "qkv_layout, num_heads_q, num_heads_kv",
        FUSED_ATTN_MAX_LOGIT_QKV_LAYOUTS,
    )
    @pytest.mark.parametrize(
        "attn_bias_type, bias_shape",
        [
            pytest.param(AttnBiasType.NO_BIAS, None, id="NO_BIAS"),
            pytest.param(
                AttnBiasType.POST_SCALE_BIAS,
                BiasShape._1HSS,
                id="POST_SCALE_BIAS-1HSS",
            ),
        ],
    )
    @pytest.mark.parametrize(
        "attn_mask_type",
        [
            pytest.param(AttnMaskType.NO_MASK, id="NO_MASK"),
            pytest.param(AttnMaskType.PADDING_MASK, id="PADDING_MASK"),
            pytest.param(AttnMaskType.CAUSAL_MASK, id="CAUSAL_MASK"),
            pytest.param(AttnMaskType.PADDING_CAUSAL_MASK, id="PADDING_CAUSAL_MASK"),
        ],
    )
    def test_forward(
        qkv_layout,
        num_heads_q,
        num_heads_kv,
        attn_bias_type,
        bias_shape,
        attn_mask_type,
    ):
        """Check non-CP JAX fused attention can expose framework-compatible max_logit."""
        runner = FusedAttnRunner(
            batch_size=2,
            max_seqlen_q=128,
            max_seqlen_kv=128,
            num_heads_q=num_heads_q,
            num_heads_kv=num_heads_kv,
            head_dim_qk=64,
            head_dim_v=64,
            attn_bias_type=attn_bias_type,
            attn_mask_type=attn_mask_type,
            softmax_type=AttnSoftmaxType.VANILLA_SOFTMAX,
            dropout_prob=0.0,
            dtype=jnp.bfloat16,
            is_training=True,
            qkv_layout=qkv_layout,
            bias_shape=bias_shape,
            window_size=None,
            seq_desc_format=SeqDescFormat.Seqlens,
        )
        runner.test_forward(return_max_logit=True)

    @staticmethod
    def test_backward():
        """Ensure aux-return cotangents do not break the fused attention backward path."""
        runner = FusedAttnRunner(
            batch_size=2,
            max_seqlen_q=128,
            max_seqlen_kv=128,
            num_heads_q=8,
            num_heads_kv=8,
            head_dim_qk=64,
            head_dim_v=64,
            attn_bias_type=AttnBiasType.NO_BIAS,
            attn_mask_type=AttnMaskType.PADDING_CAUSAL_MASK,
            softmax_type=AttnSoftmaxType.VANILLA_SOFTMAX,
            dropout_prob=0.0,
            dtype=jnp.bfloat16,
            is_training=True,
            qkv_layout=QKVLayout.BSHD_BSHD_BSHD,
            bias_shape=None,
            window_size=None,
            seq_desc_format=SeqDescFormat.Seqlens,
            doutput_seed=2026,
        )
        runner.test_backward(return_max_logit=True)


def _get_swa_window_size_for_test(s_kv: int, attn_mask_type: AttnMaskType) -> Tuple[int, int]:
    """Pick a sliding-window size for SWA tests.

    Bidirectional window (s_kv // 10, s_kv // 10 + 5) is used for the mask types whose
    bidirectional fused dispatch is meaningful here (NO_MASK, PADDING_MASK). Other mask
    types keep a left-only window (s_kv // 10, 0): causal-family masks would collapse
    (W, W) -> (W, 0), hence not tested here.
    """
    left_window_size = s_kv // 10
    # choose asymmetric window size for testing
    right_window_size = left_window_size + 5
    if attn_mask_type in (
        AttnMaskType.NO_MASK,
        AttnMaskType.PADDING_MASK,
    ):
        return (left_window_size, right_window_size)
    return (left_window_size, 0)


@pytest.mark.parametrize(
    "attn_mask_type",
    [
        pytest.param(AttnMaskType.NO_MASK, id="NO_MASK"),
        pytest.param(AttnMaskType.PADDING_MASK, id="PADDING"),
        pytest.param(AttnMaskType.CAUSAL_MASK, id="CAUSAL"),
        pytest.param(AttnMaskType.PADDING_CAUSAL_MASK, id="PADDING_CAUSAL"),
        pytest.param(
            AttnMaskType.PADDING_CAUSAL_BOTTOM_RIGHT_MASK, id="PADDING_CAUSAL_BOTTOM_RIGHT"
        ),
    ],
)
@pytest.mark.parametrize(
    "softmax_type",
    [
        pytest.param(AttnSoftmaxType.VANILLA_SOFTMAX, id="VANILLA_SOFTMAX"),
        pytest.param(AttnSoftmaxType.OFF_BY_ONE_SOFTMAX, id="OFF_BY_ONE_SOFTMAX"),
        pytest.param(AttnSoftmaxType.LEARNABLE_SOFTMAX, id="LEARNABLE_SOFTMAX"),
    ],
)
@pytest.mark.parametrize(
    "b, s_q, s_kv, h_q, h_kv, d_qk, d_v, dtype, qkv_layout, is_self_attention",
    [
        # large data size + bf16 + qkv packed
        pytest.param(
            2,
            2048,
            2048,
            12,
            12,
            64,
            64,
            jnp.bfloat16,
            QKVLayout.BS3HD,
            True,
            id="2-2048-2048-12-12-64-64-BF16-SELF-QKV_PACKED",
        ),
        pytest.param(
            2,
            2048,
            2048,
            12,
            12,
            64,
            64,
            jnp.bfloat16,
            QKVLayout.T3HD,
            True,
            id="2-2048-2048-12-12-64-64-BF16-SELF-RAGGED_QKV_PACKED",
        ),
        # mid data size + bf16 + cross attn + kv packed
        pytest.param(
            2,
            512,
            1024,
            12,
            12,
            64,
            64,
            jnp.bfloat16,
            QKVLayout.BSHD_BS2HD,
            False,
            id="2-512-1024-12-12-64-64-BF16-CROSS-KV_PACKED",
        ),
        pytest.param(
            2,
            512,
            1024,
            12,
            12,
            64,
            64,
            jnp.bfloat16,
            QKVLayout.THD_T2HD,
            False,
            id="2-512-1024-12-12-64-64-BF16-CROSS-RAGGED_KV_PACKED",
        ),
        # large data size + bf16 + cross attn + diff hidden v dim + qkv separate
        pytest.param(
            2,
            2048,
            1024,
            12,
            12,
            64,
            32,
            jnp.bfloat16,
            QKVLayout.BSHD_BSHD_BSHD,
            False,
            id="2-2048-1024-12-12-64-32-BF16-CROSS-SEPARATE",
        ),
        pytest.param(
            2,
            2048,
            1024,
            12,
            12,
            64,
            32,
            jnp.bfloat16,
            QKVLayout.THD_THD_THD,
            False,
            id="2-2048-1024-12-12-64-32-BF16-CROSS-RAGGED_SEPARATE",
        ),
        # large data size + bf16 + gqa + kv packed
        pytest.param(
            2,
            2048,
            2048,
            12,
            6,
            64,
            64,
            jnp.bfloat16,
            QKVLayout.BSHD_BS2HD,
            True,
            id="2-2048-2048-12-6-64-64-BF16-GQA-KV_PACKED",
        ),
        pytest.param(
            2,
            2048,
            2048,
            12,
            6,
            64,
            64,
            jnp.bfloat16,
            QKVLayout.THD_T2HD,
            True,
            id="2-2048-2048-12-6-64-64-BF16-GQA-RAGGED_KV_PACKED",
        ),
        # small data size + fp16 + diff hidden v dim + qkv packed
        pytest.param(
            4,
            128,
            128,
            16,
            16,
            64,
            32,
            jnp.float16,
            QKVLayout.BS3HD,
            True,
            id="4-128-128-16-16-64-32-FP16-SELF-QKV_PACKED",
        ),
        pytest.param(
            4,
            128,
            128,
            16,
            16,
            64,
            32,
            jnp.float16,
            QKVLayout.T3HD,
            True,
            id="4-128-128-16-16-64-32-FP16-SELF-RAGGED_QKV_PACKED",
        ),
        # small data size + fp16 + kv packed
        pytest.param(
            4,
            128,
            128,
            16,
            16,
            64,
            64,
            jnp.float16,
            QKVLayout.BSHD_BS2HD,
            True,
            id="4-128-128-16-16-64-64-FP16-SELF-KV_PACKED",
        ),
        pytest.param(
            4,
            128,
            128,
            16,
            16,
            64,
            64,
            jnp.float16,
            QKVLayout.THD_T2HD,
            True,
            id="4-128-128-16-16-64-64-FP16-SELF-RAGGED_KV_PACKED",
        ),
        # large data size + fp16 + cross attn + gqa + diff hidden v dim + qkv separate
        pytest.param(
            2,
            1024,
            2048,
            12,
            6,
            128,
            64,
            jnp.float16,
            QKVLayout.BSHD_BSHD_BSHD,
            False,
            id="2-1024-2048-12-6-128-64-FP16-CROSS-GQA-SEPARATE",
        ),
        # Equal maximum sequence lengths do not make this self-attention: Q and KV
        # intentionally use independent segment boundaries, positions, and padding.
        pytest.param(
            2,
            1024,
            1024,
            12,
            6,
            128,
            64,
            jnp.float16,
            QKVLayout.THD_THD_THD,
            False,
            id="2-1024-1024-12-6-128-64-FP16-CROSS-GQA-RAGGED_SEPARATE",
        ),
    ],
)
@pytest.mark.parametrize(
    "dropout_prob",
    [
        pytest.param(0.0, id="DROP_0.0"),
        pytest.param(0.1, id="DROP_0.1"),
    ],
)
@pytest.mark.parametrize(
    "swa",
    [
        pytest.param(False, id="NO_SWA"),
        pytest.param(True, id="SWA"),
    ],
)
@pytest.mark.parametrize(
    "seq_desc_format",
    [
        pytest.param(SeqDescFormat.Mask, id="Mask"),
        pytest.param(SeqDescFormat.Seqlens, id="Seqlens"),
        pytest.param(SeqDescFormat.SegmentIDs, id="SegmentIDs"),
    ],
)
@pytest.mark.skipif(_deterministic, reason="Test non-determinism only")
class TestFusedAttn:
    """
    Fused attention tester
    """

    @staticmethod
    @pytest.mark.parametrize(
        "is_training",
        [
            pytest.param(True, id="TRAINING"),
            pytest.param(False, id="INFERENCE"),
        ],
    )
    @pytest.mark.parametrize(
        "attn_bias_type, bias_shape",
        [
            pytest.param(AttnBiasType.NO_BIAS, None, id="NO_BIAS"),
            pytest.param(AttnBiasType.POST_SCALE_BIAS, BiasShape._1HSS, id="POST_SCALE_BIAS-1HSS"),
            pytest.param(AttnBiasType.POST_SCALE_BIAS, BiasShape._B1SS, id="POST_SCALE_BIAS-B1SS"),
            pytest.param(AttnBiasType.POST_SCALE_BIAS, BiasShape._BHSS, id="POST_SCALE_BIAS-BHSS"),
            pytest.param(AttnBiasType.POST_SCALE_BIAS, BiasShape._11SS, id="POST_SCALE_BIAS-11SS"),
        ],
    )
    def _test_forward(
        b,
        s_q,
        s_kv,
        h_q,
        h_kv,
        d_qk,
        d_v,
        attn_bias_type,
        attn_mask_type,
        softmax_type,
        dropout_prob,
        dtype,
        is_training,
        qkv_layout,
        bias_shape,
        swa,
        seq_desc_format,
        is_self_attention,
    ):
        """
        Test forward with parameterized configs
        This test is not intended to run automatically during CI as it is time-consuming
        It is kept for development and debugging
        """
        window_size = _get_swa_window_size_for_test(s_kv, attn_mask_type) if swa else None
        runner = FusedAttnRunner(
            b,
            s_q,
            s_kv,
            h_q,
            h_kv,
            d_qk,
            d_v,
            attn_bias_type,
            attn_mask_type,
            softmax_type,
            dropout_prob,
            dtype,
            is_training,
            qkv_layout,
            bias_shape,
            window_size,
            seq_desc_format,
            is_self_attention=is_self_attention,
        )
        runner.test_forward()

    @staticmethod
    @pytest.mark.parametrize(
        "attn_bias_type, bias_shape",
        [
            pytest.param(AttnBiasType.NO_BIAS, None, id="NO_BIAS"),
            pytest.param(AttnBiasType.POST_SCALE_BIAS, BiasShape._1HSS, id="POST_SCALE_BIAS-1HSS"),
        ],
    )
    def test_backward(
        b,
        s_q,
        s_kv,
        h_q,
        h_kv,
        d_qk,
        d_v,
        attn_bias_type,
        attn_mask_type,
        softmax_type,
        dropout_prob,
        dtype,
        qkv_layout,
        bias_shape,
        swa,
        seq_desc_format,
        is_self_attention,
    ):
        """
        Test backward with parameterized configs
        """
        window_size = _get_swa_window_size_for_test(s_kv, attn_mask_type) if swa else None
        runner = FusedAttnRunner(
            b,
            s_q,
            s_kv,
            h_q,
            h_kv,
            d_qk,
            d_v,
            attn_bias_type,
            attn_mask_type,
            softmax_type,
            dropout_prob,
            dtype,
            True,
            qkv_layout,
            bias_shape,
            window_size,
            seq_desc_format,
            doutput_seed=2026,
            is_self_attention=is_self_attention,
        )
        runner.test_backward()


@pytest.mark.parametrize(
    "attn_mask_type",
    [
        pytest.param(AttnMaskType.NO_MASK, id="NO_MASK"),
        pytest.param(AttnMaskType.PADDING_MASK, id="PADDING"),
        pytest.param(AttnMaskType.CAUSAL_MASK, id="CAUSAL"),
        pytest.param(AttnMaskType.PADDING_CAUSAL_MASK, id="PADDING_CAUSAL"),
        pytest.param(
            AttnMaskType.PADDING_CAUSAL_BOTTOM_RIGHT_MASK, id="PADDING_CAUSAL_BOTTOM_RIGHT"
        ),
    ],
)
@pytest.mark.parametrize(
    "softmax_type",
    [
        pytest.param(AttnSoftmaxType.VANILLA_SOFTMAX, id="VANILLA_SOFTMAX"),
    ],
)
@pytest.mark.parametrize(
    "b, s_q, s_kv, h_q, h_kv, d_qk, d_v, dtype, qkv_layout",
    [
        # large data size + fp16 + cross attn + gqa + diff hidden v dim + qkv separate
        pytest.param(
            2,
            1024,
            2048,
            12,
            6,
            128,
            64,
            jnp.bfloat16,
            QKVLayout.BSHD_BSHD_BSHD,
            id="2-1024-2048-12-6-128-64-BF16-CROSS-GQA-SEPARATE",
        ),
        pytest.param(
            2,
            1024,
            2048,
            12,
            6,
            128,
            64,
            jnp.bfloat16,
            QKVLayout.THD_THD_THD,
            id="2-1024-2048-12-6-128-64-BF16-CROSS-GQA-RAGGED_SEPARATE",
        ),
        # D=256 deterministic backward on the SM100 dedicated SDPA bprop kernel.
        # BSHD requires cuDNN FE 1.24 / BE 9.23+; THD requires cuDNN FE 1.26 / BE 9.25+.
        pytest.param(
            4,
            128,
            128,
            16,
            16,
            256,
            256,
            jnp.float16,
            QKVLayout.BSHD_BS2HD,
            id="4-128-128-16-16-256-256-FP16-SELF-KV_PACKED",
        ),
        pytest.param(
            4,
            128,
            128,
            16,
            16,
            256,
            256,
            jnp.float16,
            QKVLayout.THD_T2HD,
            id="4-128-128-16-16-256-256-FP16-SELF-RAGGED_KV_PACKED",
        ),
    ],
)
@pytest.mark.parametrize(
    "dropout_prob",
    [
        pytest.param(0.0, id="DROP_0.0"),
    ],
)
@pytest.mark.parametrize(
    "swa",
    [
        pytest.param(False, id="NO_SWA"),
    ],
)
@pytest.mark.parametrize(
    "seq_desc_format",
    [
        pytest.param(SeqDescFormat.Seqlens, id="Seqlens"),
    ],
)
@pytest.mark.skipif(not _deterministic, reason="Test determinism only")
class TestFusedAttnWithDeterminism:
    """
    Fused attention tester with determinism
    """

    @staticmethod
    @pytest.mark.parametrize(
        "is_training",
        [
            pytest.param(True, id="TRAINING"),
        ],
    )
    @pytest.mark.parametrize(
        "attn_bias_type, bias_shape",
        [
            pytest.param(AttnBiasType.NO_BIAS, None, id="NO_BIAS"),
            pytest.param(AttnBiasType.POST_SCALE_BIAS, BiasShape._1HSS, id="POST_SCALE_BIAS-1HSS"),
        ],
    )
    def _test_forward(
        b,
        s_q,
        s_kv,
        h_q,
        h_kv,
        d_qk,
        d_v,
        attn_bias_type,
        attn_mask_type,
        softmax_type,
        dropout_prob,
        dtype,
        is_training,
        qkv_layout,
        bias_shape,
        swa,
        seq_desc_format,
    ):
        """
        Test forward with parameterized configs
        This test is not intended to run automatically during CI as it is time-consuming
        It is kept for development and debugging
        """
        TestFusedAttn._test_forward(
            b,
            s_q,
            s_kv,
            h_q,
            h_kv,
            d_qk,
            d_v,
            attn_bias_type,
            attn_mask_type,
            softmax_type,
            dropout_prob,
            dtype,
            is_training,
            qkv_layout,
            bias_shape,
            swa,
            seq_desc_format,
            is_self_attention=None,
        )

    @staticmethod
    @pytest.mark.parametrize(
        "attn_bias_type, bias_shape",
        [
            pytest.param(AttnBiasType.NO_BIAS, None, id="NO_BIAS"),
            pytest.param(AttnBiasType.POST_SCALE_BIAS, BiasShape._1HSS, id="POST_SCALE_BIAS-1HSS"),
        ],
    )
    def test_backward(
        b,
        s_q,
        s_kv,
        h_q,
        h_kv,
        d_qk,
        d_v,
        attn_bias_type,
        attn_mask_type,
        softmax_type,
        dropout_prob,
        dtype,
        qkv_layout,
        bias_shape,
        swa,
        seq_desc_format,
    ):
        """
        Test backward with parameterized configs
        """
        TestFusedAttn.test_backward(
            b,
            s_q,
            s_kv,
            h_q,
            h_kv,
            d_qk,
            d_v,
            attn_bias_type,
            attn_mask_type,
            softmax_type,
            dropout_prob,
            dtype,
            qkv_layout,
            bias_shape,
            swa,
            seq_desc_format,
            is_self_attention=None,
        )
