# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.

"""Tests for GroupedTensor class"""

from types import SimpleNamespace
from typing import List, Optional, Tuple

import pytest
import torch
import transformer_engine.pytorch as te
from transformer_engine.pytorch.tensor.grouped_tensor import GroupedTensor
from transformer_engine.pytorch import (
    Quantizer,
    Float8Quantizer,
    Float8CurrentScalingQuantizer,
    Float8BlockQuantizer,
    MXFP8Quantizer,
    NVFP4Quantizer,
)
from transformer_engine.pytorch.utils import is_non_tn_fp8_gemm_supported, mark_grouped_tensor
import transformer_engine_torch as tex

# Import test utilities
from utils import assert_close

# Check available recipes
fp8_available, reason_for_no_fp8 = te.is_fp8_available(return_reason=True)
fp8_block_scaling_available, reason_for_no_fp8_block_scaling = te.is_fp8_block_scaling_available(
    return_reason=True
)
mxfp8_available, reason_for_no_mxfp8 = te.is_mxfp8_available(return_reason=True)
nvfp4_available, reason_for_no_nvfp4 = te.is_nvfp4_available(return_reason=True)

# Grouped FP8 block-scaling quantize/dequantize kernels need TMA (SM90+). On Blackwell and newer
# the FP8 block-scaling recipe is emulated with MXFP8, which only supports power-of-2 scales.
_device_cc = torch.cuda.get_device_capability() if torch.cuda.is_available() else (0, 0)
fp8_block_scaling_grouped_available = fp8_block_scaling_available and _device_cc >= (9, 0)
reason_for_no_fp8_block_scaling_grouped = (
    reason_for_no_fp8_block_scaling
    if not fp8_block_scaling_available
    else "Grouped FP8 block-scaling quantize/dequantize requires SM90 or newer."
)
_fp8bs_pow2_required = _device_cc >= (10, 0)


def test_mark_grouped_tensor_supports_plain_tensor():
    tensor = torch.empty(16)

    mark_grouped_tensor(tensor)

    assert tensor.grouped_tensor_scale_inv is False


def test_mark_grouped_tensor_supports_unquantized_rowwise_storage():
    rowwise_data = torch.empty(16)
    grouped_tensor = SimpleNamespace(
        rowwise_data=rowwise_data,
        columnwise_data=None,
        columnwise_scale_inv=None,
    )

    mark_grouped_tensor(grouped_tensor)

    assert rowwise_data.grouped_tensor_scale_inv is False


def test_mark_grouped_tensor_marks_quantized_columnwise_storage():
    rowwise_data = torch.empty(16)
    columnwise_data = torch.empty(16)
    columnwise_scale_inv = torch.empty(4)
    grouped_tensor = SimpleNamespace(
        rowwise_data=rowwise_data,
        columnwise_data=columnwise_data,
        columnwise_scale_inv=columnwise_scale_inv,
    )

    mark_grouped_tensor(grouped_tensor)

    assert not hasattr(rowwise_data, "grouped_tensor_scale_inv")
    assert columnwise_data.grouped_tensor_scale_inv is False
    assert columnwise_scale_inv.grouped_tensor_scale_inv is True


_quantization_params = [
    pytest.param(
        "fp8_delayed_scaling",
        marks=pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8),
    ),
    pytest.param(
        "fp8_current_scaling",
        marks=pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8),
    ),
    pytest.param(
        "fp8_blockwise",
        marks=pytest.mark.skipif(
            not fp8_block_scaling_available, reason=reason_for_no_fp8_block_scaling
        ),
    ),
    pytest.param(
        "mxfp8",
        marks=pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8),
    ),
    pytest.param(
        "nvfp4",
        marks=pytest.mark.skipif(not nvfp4_available, reason=reason_for_no_nvfp4),
    ),
]


def make_quantizer(quantization: str, num_tensors: int, shape: List[Tuple[int, int]]) -> Quantizer:
    """Create quantizer for given quantization scheme"""

    if quantization == "fp8_delayed_scaling":
        quantizer = Float8Quantizer(
            scale=torch.ones(1, dtype=torch.float32, device="cuda"),
            amax=torch.zeros(1, dtype=torch.float32, device="cuda"),
            fp8_dtype=te.DType.kFloat8E4M3,
        )
    elif quantization == "fp8_current_scaling":
        quantizer = Float8CurrentScalingQuantizer(
            fp8_dtype=te.DType.kFloat8E4M3,
            device="cuda",
        )
        quantizer.set_usage(rowwise=True, columnwise=False)
    elif quantization == "fp8_blockwise":
        quantizer = Float8BlockQuantizer(
            fp8_dtype=te.DType.kFloat8E4M3,
            rowwise=True,
            columnwise=False,
            force_pow_2_scales=True,
            amax_epsilon=0.0,
            block_scaling_dim=1,
        )
    elif quantization == "mxfp8":
        quantizer = MXFP8Quantizer(fp8_dtype=te.DType.kFloat8E4M3)
    elif quantization == "nvfp4":
        quantizer = NVFP4Quantizer(
            with_rht=False,
            with_post_rht_amax=False,
            with_2d_quantization=False,
            stochastic_rounding=False,
            with_random_sign_mask=False,
        )
    else:
        raise ValueError(f"Unknown quantization scheme: {quantization}")

    quantizer.internal = False

    return quantizer


def _get_rowwise_data_tensor(qtensor, quantization: str) -> torch.Tensor:
    if quantization in ("fp8_delayed_scaling", "fp8_current_scaling"):
        return qtensor._data
    if quantization in ("fp8_blockwise", "mxfp8", "nvfp4"):
        return qtensor._rowwise_data
    raise ValueError(f"Unknown quantization scheme: {quantization}")


def _rowwise_offset_bytes(numel: int, quantization: str) -> int:
    if quantization == "nvfp4":
        return numel // 2
    return numel


def _fp8bs_per_expert_scale_floats(
    block_scaling_dim: int, columnwise: bool, m_t: int, k: int
) -> int:
    """Per-expert padded scale size (in floats) for grouped FP8 block-scaling.

    Mirrors the per-expert sub-block layout that cuBLAS grouped GEMM consumes (and that the C++
    test ``test_cast_float8blockwise_grouped.cu`` verifies against)::

        1D rowwise : blocks_X   * roundup(M_t, 4)
        1D colwise : blocks_y_t * roundup(K, 4)
        2D rowwise : blocks_y_t * roundup(blocks_X, 4)
        2D colwise : blocks_X   * roundup(blocks_y_t, 4)

    The 2D columnwise roundup of each expert's block-rows to a multiple of 4 is the source of the
    per-expert slack reserved in ``Float8BlockQuantizer.create_grouped_tensor``.
    """

    def align4(x: int) -> int:
        return ((x + 3) // 4) * 4

    blocks_x = (k + 127) // 128
    blocks_y = (m_t + 127) // 128
    if block_scaling_dim == 1:
        return blocks_y * align4(k) if columnwise else blocks_x * align4(m_t)
    return blocks_x * align4(blocks_y) if columnwise else blocks_y * align4(blocks_x)


def _scaled_swiglu_reference(
    input_2h: torch.Tensor,
    prob: torch.Tensor,
    *,
    limit: Optional[float] = None,
    alpha: float = 1.0,
    glu_linear_offset: float = 0.0,
) -> torch.Tensor:
    """PyTorch reference for the (clamped) scaled SwiGLU that the grouped kernel recomputes.

    ``limit=None`` selects plain SwiGLU, where ``alpha`` and ``glu_linear_offset`` sit at
    their identity values. The clamps use ``torch.where`` rather than ``Tensor.clamp`` so
    this stays character-for-character the formulation that #3424 settled on in
    tests/pytorch/test_fusible_ops.py.

    Evaluated in fp32 because the kernel also widens its bf16 input to fp32 and quantizes
    from there; a bf16 reference would carry a rounding step the kernel never takes.
    """
    x_glu, x_linear = input_2h.float().chunk(2, dim=-1)
    if limit is not None:
        x_glu = torch.where(x_glu > limit, limit, x_glu)
        x_linear = torch.where(x_linear < -limit, -limit, x_linear)
        x_linear = torch.where(x_linear > limit, limit, x_linear)
    out_glu = x_glu * torch.sigmoid(alpha * x_glu)
    return out_glu * (x_linear + glu_linear_offset) * prob.float().unsqueeze(-1)


# MXFP8 scales one e8m0 exponent per 32-row block of a column, and e4m3 carries 3 mantissa
# bits, so within a block the representable values are spaced 2^-3 of the leading binade
# apart. Using the block amax as a stand-in for that binade (it is within 2x of it) puts one
# code step at ``amax * 2^-3``; the bound below allows two, which covers a block whose two
# e8m0 exponents land one step apart and so quantizes at twice the spacing.
#
# Note the scope: this bounds the resolution the kernel is entitled to lose, so it catches a
# defect that moves some element far. It is measured against each block's largest element, so
# it is much weaker against a defect that perturbs many elements a little without moving that
# one -- a wrong ``alpha`` is the case in point, since sigmoid has saturated where the largest
# element sits. Measured on GB200, a doubled alpha lands at 1.14 steps, inside this bound.
_MXFP8_STEPS_ALLOWED = 2.0
_MXFP8_E4M3_MANTISSA_BITS = 3

_MXFP8_SCALE_BLOCK_ROWS = 32


def _assert_mxfp8_matches_reference(actual, expected, *, context: str) -> None:
    """Compare two columnwise-MXFP8 tensors produced by the same quantizer.

    Both sides must come from the same quantizer instance so the scale layout (compact or
    GEMM-swizzled) and the usage flags agree; only the values being quantized differ, which
    is what makes a resolution-level comparison meaningful.

    Two independent assertions. The e8m0 scales are compared as raw exponents, where any
    disagreement beyond one step means the two sides indexed different data rather than
    rounded differently. The values are then compared after dequantization, elementwise,
    against the quantization step of their own 32-row block.
    """
    actual_scale = actual._columnwise_scale_inv.reshape(-1).view(torch.uint8)
    expected_scale = expected._columnwise_scale_inv.reshape(-1).view(torch.uint8)
    assert actual_scale.shape == expected_scale.shape, (
        f"{context}: scale size {tuple(actual_scale.shape)} != reference"
        f" {tuple(expected_scale.shape)}"
    )

    scale_delta = (actual_scale.int() - expected_scale.int()).abs()
    scale_bad = int((scale_delta > 1).sum())
    assert scale_bad == 0, (
        f"{context}: {scale_bad} of {expected_scale.numel()} scales differ by more than one"
        f" e8m0 step (max delta {int(scale_delta.max())}); that is an indexing or layout"
        " error, not rounding"
    )

    actual_deq = actual.dequantize().float()
    expected_deq = expected.dequantize().float()
    assert actual_deq.shape == expected_deq.shape, (
        f"{context}: dequantized shape {tuple(actual_deq.shape)} != reference"
        f" {tuple(expected_deq.shape)}"
    )
    rows, cols = actual_deq.shape
    assert rows % _MXFP8_SCALE_BLOCK_ROWS == 0, (
        f"{context}: {rows} rows is not a whole number of {_MXFP8_SCALE_BLOCK_ROWS}-row scale"
        " blocks, so the per-block bound below would not line up"
    )

    blocked = (rows // _MXFP8_SCALE_BLOCK_ROWS, _MXFP8_SCALE_BLOCK_ROWS, cols)
    block_amax = expected_deq.reshape(blocked).abs().amax(dim=1, keepdim=True)
    tolerance = block_amax * _MXFP8_STEPS_ALLOWED * 2.0**-_MXFP8_E4M3_MANTISSA_BITS
    deviation = (actual_deq - expected_deq).reshape(blocked).abs()

    n_over = int((deviation > tolerance).sum())
    floor = torch.finfo(torch.float32).tiny
    worst = float((deviation / tolerance.clamp(min=floor)).max()) * _MXFP8_STEPS_ALLOWED
    assert n_over == 0, (
        f"{context}: {n_over} of {deviation.numel()} elements deviate by more than"
        f" {_MXFP8_STEPS_ALLOWED:g} MXFP8 code steps of their block"
        f" (worst {worst:.3f} steps); scales differing by one step:"
        f" {int((scale_delta != 0).sum())}"
    )


class TestGroupedTensor:
    @staticmethod
    def setup_class(cls) -> None:
        # Configure RNG
        seed = 1234
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)

    def test_autograd_identity_view_preserves_grouped_storage_and_gradient(self) -> None:
        """Autograd's identity view keeps grouped metadata and passes back a dense gradient."""

        class Identity(torch.autograd.Function):
            @staticmethod
            def forward(ctx, tensor):
                return tensor

            @staticmethod
            def backward(ctx, grad):
                return grad

        first_dims = torch.tensor([1, 2], dtype=torch.int64, device="cuda")
        tensor_offsets = torch.tensor([0, 4, 12], dtype=torch.int64, device="cuda")
        source = GroupedTensor(
            shape=(3, 4),
            dtype=torch.float32,
            num_tensors=2,
            data=torch.randn(12, device="cuda"),
            first_dims=first_dims,
            tensor_offsets=tensor_offsets,
            requires_grad=True,
        )

        view = Identity.apply(source)
        assert isinstance(view, GroupedTensor)
        assert view is not source
        assert view._base is source
        assert view.rowwise_data is source.rowwise_data
        assert view.first_dims is first_dims
        assert view.tensor_offsets is tensor_offsets

        expected = torch.arange(1, 13, dtype=torch.float32, device="cuda").reshape(3, 4)
        (grad,) = torch.autograd.grad(view, source, grad_outputs=expected)
        assert type(grad) is torch.Tensor
        torch.testing.assert_close(grad, expected)

    def test_record_stream_tracks_grouped_buffers(self, monkeypatch) -> None:
        """record_stream should reach every allocation owned by the wrapper."""
        first_dims = torch.tensor([1, 2], dtype=torch.int64, device="cuda")
        last_dims = torch.tensor([4, 4], dtype=torch.int64, device="cuda")
        tensor_offsets = torch.tensor([0, 4, 12], dtype=torch.int64, device="cuda")
        grouped_tensor = GroupedTensor(
            shape=(3, 4),
            dtype=torch.float32,
            num_tensors=2,
            data=torch.randn(12, device="cuda"),
            columnwise_data=torch.randn(12, device="cuda"),
            scale_inv=torch.ones(2, device="cuda"),
            columnwise_scale_inv=torch.ones(2, device="cuda"),
            amax=torch.zeros(2, device="cuda"),
            columnwise_amax=torch.zeros(2, device="cuda"),
            scale=torch.ones(2, device="cuda"),
            first_dims=first_dims,
            last_dims=last_dims,
            tensor_offsets=tensor_offsets,
        )
        buffers = grouped_tensor.get_data_tensors()
        recorded = []
        original_record_stream = torch.Tensor.record_stream

        def record_stream(tensor, stream):
            recorded.append(tensor)
            return original_record_stream(tensor, stream)

        monkeypatch.setattr(torch.Tensor, "record_stream", record_stream)
        grouped_tensor.record_stream(torch.cuda.Stream())

        assert all(any(record is buffer for record in recorded) for buffer in buffers)

    def test_basic_construction_all_same_shape(self) -> None:
        """Test GroupedTensor construction with all tensors having same shape"""
        num_tensors = 4
        shape = [(256, 512) for _ in range(num_tensors)]

        grouped_tensor = GroupedTensor.make_grouped_tensor_with_shapes(
            num_tensors=num_tensors,
            shapes=shape,
            quantizer=None,
            device="cuda",
            dtype=torch.float32,
        )

        assert grouped_tensor.num_tensors == num_tensors
        assert grouped_tensor.all_same_shape()
        assert grouped_tensor.all_same_first_dim()
        assert grouped_tensor.all_same_last_dim()
        assert grouped_tensor.logical_shape == (num_tensors * 256, 512)
        assert grouped_tensor.get_common_first_dim() == 256
        assert grouped_tensor.get_common_last_dim() == 512
        assert grouped_tensor.has_data()

    def test_basic_construction_varying_first_dim(self) -> None:
        """Test GroupedTensor construction with varying first dimension"""
        num_tensors = 3
        shape = [(128, 512), (256, 512), (384, 512)]

        grouped_tensor = GroupedTensor.make_grouped_tensor_with_shapes(
            num_tensors=num_tensors,
            shapes=shape,
            quantizer=None,
            device="cuda",
            dtype=torch.float32,
        )

        assert grouped_tensor.num_tensors == num_tensors
        assert not grouped_tensor.all_same_shape()
        assert not grouped_tensor.all_same_first_dim()
        assert grouped_tensor.all_same_last_dim()
        assert grouped_tensor.get_common_last_dim() == shape[0][1]
        assert grouped_tensor.logical_shape == (
            sum(v for v, _ in shape),
            shape[0][1],
        )  # sum of first dims

    @pytest.mark.parametrize(
        "split_sizes_list,logical_last_dim",
        [
            pytest.param([3, 4, 5, 2], 7, id="all_nonzero"),
            pytest.param([3, 0, 5, 2], 7, id="zero_middle"),
            pytest.param([0, 3, 5, 0], 11, id="zero_edges"),
            pytest.param([1], 17, id="single_group"),
            pytest.param([1, 2, 3, 4, 5, 6, 7, 8], 13, id="many_groups"),
            # MoE-style group counts. ``split_points`` (an int32[num_groups]
            # tensor packed into a shared buffer alongside int64 outputs) used
            # to land at an 8-byte-aligned offset for these counts, which
            # tripped cuDNN's 16-byte alignment requirement in grouped GEMM.
            pytest.param([8192] * 8, 2048, id="num_groups_8_uniform"),
            pytest.param([4096] * 16, 4096, id="num_groups_16_uniform"),
            pytest.param([2048] * 32, 7168, id="num_groups_32_uniform"),
            pytest.param([1024] * 64, 7168, id="num_groups_64_uniform"),
            pytest.param([512] * 128, 7168, id="num_groups_128_uniform"),
            # Non-uniform with large totals to also exercise tensor_offsets > 2^31.
            pytest.param(
                [12345, 0, 8192, 1, 65536, 100, 131072, 7],
                7168,
                id="non_uniform_large_totals",
            ),
        ],
    )
    @pytest.mark.parametrize("input_dtype", [torch.int32, torch.int64], ids=["int32", "int64"])
    @pytest.mark.parametrize("input_device", ["cuda", "cpu"], ids=["cuda", "cpu"])
    @pytest.mark.parametrize("bulk_allocate", [False, True], ids=["separate", "bulk"])
    def test_splits_to_offsets_multi(
        self,
        bulk_allocate: bool,
        input_device: str,
        input_dtype: torch.dtype,
        split_sizes_list: List[int],
        logical_last_dim: int,
    ) -> None:
        """Test fused grouped split metadata preparation."""
        device = torch.device("cuda")
        split_sizes = torch.tensor(split_sizes_list, dtype=input_dtype, device=input_device)

        # Exercise the grouped-MLP-shaped call: mix of int32 (no leading zero)
        # and int64 (with leading zero) outputs, several strides.
        strides = [1, 1, logical_last_dim, 0, logical_last_dim + 17]
        include_leading_zero = [False, True, True, True, True]
        dtypes = [torch.int32, torch.int64, torch.int64, torch.int64, torch.int64]
        split_sizes_out, outputs = tex.splits_to_offsets_multi(
            split_sizes,
            device,
            strides=strides,
            include_leading_zero=include_leading_zero,
            dtypes=dtypes,
            bulk_allocate=bulk_allocate,
        )

        # Reference implementation.
        expected_split_sizes_i64 = split_sizes.to(device=device, dtype=torch.int64)
        expected_base_offsets = torch.cat(
            (
                torch.zeros(1, dtype=torch.int64, device=device),
                torch.cumsum(expected_split_sizes_i64, dim=0),
            )
        )

        # Check output split_sizes: always int64, always on the target device.
        assert split_sizes_out.device.type == "cuda"
        assert split_sizes_out.dtype == torch.int64
        assert_close(split_sizes_out, expected_split_sizes_i64)

        # Check output offsets.
        assert len(outputs) == len(strides)
        for output, stride, with_zero, dtype in zip(outputs, strides, include_leading_zero, dtypes):
            assert output.dtype == dtype
            assert output.device.type == "cuda"
            expected_length = split_sizes.numel() + (1 if with_zero else 0)
            assert output.numel() == expected_length
            expected = expected_base_offsets * stride
            if not with_zero:
                expected = expected[1:]
            assert_close(output, expected)

        # Check pointer alignment: cuDNN CuTe-DSL grouped GEMM kernels
        # require 16-byte-aligned data pointers.
        for idx, output in enumerate(outputs):
            assert (
                output.data_ptr() % 16 == 0
            ), f"outputs[{idx}] data_ptr is not 16-byte aligned: {output.data_ptr():#x}"

    def test_split_into_quantized_tensors_no_quantization(self) -> None:
        """Test split_into_quantized_tensors for unquantized tensors"""
        num_tensors = 3
        shape = [(256, 512) for _ in range(num_tensors)]

        grouped_tensor = GroupedTensor.make_grouped_tensor_with_shapes(
            num_tensors=num_tensors,
            shapes=shape,
            quantizer=None,
            device="cuda",
            dtype=torch.float32,
        )

        # GroupedTensor is a wrapper; use backing storage buffer pointer.
        storage = grouped_tensor.rowwise_data
        if storage is None:
            storage = grouped_tensor.columnwise_data
        assert storage is not None
        original_data_ptr = storage.data_ptr()

        # Split into tensors
        tensors = grouped_tensor.split_into_quantized_tensors()

        assert len(tensors) == num_tensors

        # Verify each tensor has correct shape and shares storage
        for i, tensor in enumerate(tensors):
            assert tensor.shape == shape[i]
            assert isinstance(tensor, torch.Tensor)
            assert not hasattr(tensor, "_data")  # Not a quantized tensor

            # Verify data pointer is within the original grouped tensor storage
            # The tensor should be a view of the original data
            assert tensor.data_ptr() >= original_data_ptr

            # Calculate expected offset
            expected_offset = i * (shape[i][0] * shape[i][1]) * tensor.element_size()
            assert tensor.data_ptr() == original_data_ptr + expected_offset

    @pytest.mark.parametrize("quantization", _quantization_params)
    def test_split_into_quantized_tensors_quantized(self, quantization: str) -> None:
        """Test split_into_quantized_tensors for quantized tensors"""
        num_tensors = 3
        shape = [(512, 512) for _ in range(num_tensors)]
        quantizer = make_quantizer(quantization, num_tensors, shape)

        grouped_tensor = GroupedTensor.make_grouped_tensor_with_shapes(
            num_tensors=num_tensors,
            shapes=shape,
            quantizer=quantizer,
            device="cuda",
            dtype=torch.float32,
        )

        # GroupedTensor is a wrapper; use backing storage buffer pointer.
        storage = grouped_tensor.rowwise_data
        if storage is None:
            storage = grouped_tensor.columnwise_data
        assert storage is not None
        original_data_ptr = storage.data_ptr()

        # Split into tensors
        tensors = grouped_tensor.split_into_quantized_tensors()

        assert len(tensors) == num_tensors

        # Verify each tensor shares storage with the grouped tensor
        for i, tensor in enumerate(tensors):
            rowwise_data = _get_rowwise_data_tensor(tensor, quantization)
            assert rowwise_data is not None
            assert rowwise_data.data_ptr() >= original_data_ptr
            numel = shape[i][0] * shape[i][1]
            expected_offset = _rowwise_offset_bytes(i * numel, quantization)
            assert rowwise_data.data_ptr() == original_data_ptr + expected_offset

    def test_split_varying_shapes(self) -> None:
        """Test split_into_quantized_tensors with varying shapes"""
        num_tensors = 3
        shape = [(128, 512), (256, 512), (384, 512)]

        grouped_tensor = GroupedTensor.make_grouped_tensor_with_shapes(
            num_tensors=num_tensors,
            shapes=shape,
            quantizer=None,
            device="cuda",
            dtype=torch.float32,
        )

        storage = grouped_tensor.rowwise_data
        if storage is None:
            storage = grouped_tensor.columnwise_data
        assert storage is not None
        original_data_ptr = storage.data_ptr()
        tensors = grouped_tensor.split_into_quantized_tensors()

        assert len(tensors) == num_tensors

        # Verify shapes and storage
        cumulative_offset = 0
        for i, tensor in enumerate(tensors):
            assert tensor.shape == shape[i]
            expected_offset = cumulative_offset * tensor.element_size()
            assert tensor.data_ptr() == original_data_ptr + expected_offset
            cumulative_offset += shape[i][0] * shape[i][1]

    @pytest.mark.parametrize("quantization", _quantization_params)
    def test_quantize_inplace(self, quantization: str) -> None:
        """Test that quantize is done in-place for all recipes"""
        num_tensors = 3
        shape = [(512, 512) for _ in range(num_tensors)]
        quantizer = make_quantizer(quantization, num_tensors, shape)

        grouped_tensor = GroupedTensor.make_grouped_tensor_with_shapes(
            num_tensors=num_tensors,
            shapes=shape,
            quantizer=quantizer,
            device="cuda",
            dtype=torch.float32,
        )

        # Get original data pointers before quantization
        storage = grouped_tensor.rowwise_data
        if storage is None:
            storage = grouped_tensor.columnwise_data
        assert storage is not None
        original_data_ptr = storage.data_ptr()
        original_scale_inv_ptr = grouped_tensor.scale_inv.data_ptr()
        original_scale_ptr = (
            grouped_tensor.scale.data_ptr() if grouped_tensor.scale is not None else None
        )

        # Create input tensors
        input_tensors = [torch.randn(s, dtype=torch.float32, device="cuda") for s in shape]

        # Quantize in place
        quantized_tensors = grouped_tensor.quantize(input_tensors)

        # Verify data pointers haven't changed (in-place operation)
        assert storage.data_ptr() == original_data_ptr
        assert grouped_tensor.scale_inv.data_ptr() == original_scale_inv_ptr
        if original_scale_ptr is not None:
            assert grouped_tensor.scale.data_ptr() == original_scale_ptr

        # Verify returned tensors point to the same storage
        for i, qtensor in enumerate(quantized_tensors):
            rowwise_data = _get_rowwise_data_tensor(qtensor, quantization)
            numel = shape[i][0] * shape[i][1]
            expected_offset = _rowwise_offset_bytes(i * numel, quantization)
            assert rowwise_data.data_ptr() == original_data_ptr + expected_offset

    @pytest.mark.parametrize("quantization", _quantization_params)
    def test_quantize_varying_shapes(self, quantization: str) -> None:
        """Test quantize with varying shapes"""
        num_tensors = 3
        shape = [(256, 512), (512, 512), (768, 512)]
        quantizer = make_quantizer(quantization, num_tensors, shape)

        grouped_tensor = GroupedTensor.make_grouped_tensor_with_shapes(
            num_tensors=num_tensors,
            shapes=shape,
            quantizer=quantizer,
            device="cuda",
            dtype=torch.float32,
        )

        # Get original data pointers
        storage = grouped_tensor.rowwise_data
        if storage is None:
            storage = grouped_tensor.columnwise_data
        assert storage is not None
        original_data_ptr = storage.data_ptr()

        # Create input tensors with varying shapes
        input_tensors = [torch.randn(s, dtype=torch.float32, device="cuda") for s in shape]

        # Quantize in place
        quantized_tensors = grouped_tensor.quantize(input_tensors)

        # Verify data pointer hasn't changed
        assert storage.data_ptr() == original_data_ptr

        # Verify each tensor points to correct location
        cumulative_numel = 0
        for qtensor, tensor_shape in zip(quantized_tensors, shape):
            rowwise_data = _get_rowwise_data_tensor(qtensor, quantization)
            expected_offset = _rowwise_offset_bytes(cumulative_numel, quantization)
            assert rowwise_data.data_ptr() == original_data_ptr + expected_offset
            cumulative_numel += tensor_shape[0] * tensor_shape[1]

    @pytest.mark.parametrize(
        "shape_case",
        ["varying_first", "varying_last", "varying_both"],
    )
    @pytest.mark.parametrize("usage", ["rowwise", "columnwise", "both"])
    @pytest.mark.parametrize("optimize_for_gemm", [False, True])
    @pytest.mark.parametrize("output_dbias", [False, True])
    @pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
    def test_quantize_grouped_mxfp8(
        self, shape_case: str, usage: str, optimize_for_gemm: bool, output_dbias: bool
    ) -> None:
        """Test grouped MXFP8 quantization against per-tensor quantization for
        varying first/last/both dimensions and compact or GEMM-swizzled scales."""
        if output_dbias and shape_case != "varying_first":
            pytest.skip("bgrad_group_quantize requires constant last dimension")

        # Per-tensor shapes are chosen to satisfy MXFP8 alignment requirements:
        #   - rowwise scale block size 32 -> last dim must be a multiple of 32
        #   - kernel chunk size 128 along the first dim -> first dim must be a
        #     multiple of 128 (per-tensor for VARYING_BOTH_DIMS, otherwise the
        #     logical first dim).
        if shape_case == "varying_first":
            per_tensor_shapes = [(128, 512), (256, 512), (384, 512)]
        elif shape_case == "varying_last":
            per_tensor_shapes = [(512, 128), (512, 256), (512, 384)]
        else:  # varying_both
            per_tensor_shapes = [(128, 256), (256, 512), (384, 384)]

        num_tensors = len(per_tensor_shapes)

        # Each tensor occupies a contiguous chunk of a flat buffer; the kernel
        # locates each chunk via tensor_offsets, so the 2D view below only needs
        # to encode the correct total number of elements.
        input_tensors = [
            torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in per_tensor_shapes
        ]
        flat_buffer = torch.cat([t.reshape(-1) for t in input_tensors])

        first_dims_host: Optional[List[int]]
        last_dims_host: Optional[List[int]]
        if shape_case == "varying_first":
            first_dims_host = [s[0] for s in per_tensor_shapes]
            last_dims_host = None
            common_last = per_tensor_shapes[0][1]
            grouped_input = flat_buffer.view(sum(first_dims_host), common_last)
        elif shape_case == "varying_last":
            first_dims_host = None
            last_dims_host = [s[1] for s in per_tensor_shapes]
            common_first = per_tensor_shapes[0][0]
            grouped_input = flat_buffer.view(common_first, sum(last_dims_host))
        else:  # varying_both
            first_dims_host = [s[0] for s in per_tensor_shapes]
            last_dims_host = [s[1] for s in per_tensor_shapes]
            grouped_input = flat_buffer.view(1, -1)

        first_dims = (
            torch.tensor(first_dims_host, dtype=torch.int64, device="cuda")
            if first_dims_host is not None
            else None
        )
        last_dims = (
            torch.tensor(last_dims_host, dtype=torch.int64, device="cuda")
            if last_dims_host is not None
            else None
        )

        quantizer = MXFP8Quantizer(fp8_dtype=tex.DType.kFloat8E4M3)
        rowwise = usage in ("rowwise", "both")
        columnwise = usage in ("columnwise", "both")
        quantizer.set_usage(rowwise=rowwise, columnwise=columnwise)
        quantizer.optimize_for_gemm = optimize_for_gemm

        if output_dbias:
            grouped_output, dbias = tex.bgrad_group_quantize(
                grouped_input, quantizer, num_tensors, first_dims, last_dims
            )
        else:
            grouped_output = tex.group_quantize(
                grouped_input, quantizer, num_tensors, first_dims, last_dims
            )

        # Reference: quantize each tensor independently and concatenate the
        # data / scale_inv buffers in tensor order. Both dimensions of every member
        # are multiples of 128, so swizzled scales need no padding between members.
        expected_tensors = [quantizer(tensor) for tensor in input_tensors]
        if rowwise:
            expected_data = torch.cat([t._rowwise_data.reshape(-1) for t in expected_tensors])
            expected_scales = torch.cat(
                [t._rowwise_scale_inv.reshape(-1) for t in expected_tensors]
            )
            assert torch.equal(grouped_output.rowwise_data, expected_data)
            assert torch.equal(grouped_output.scale_inv, expected_scales)
        if columnwise:
            expected_data = torch.cat([t._columnwise_data.reshape(-1) for t in expected_tensors])
            expected_scales = torch.cat(
                [t._columnwise_scale_inv.reshape(-1) for t in expected_tensors]
            )
            assert torch.equal(grouped_output.columnwise_data, expected_data)
            assert torch.equal(grouped_output.columnwise_scale_inv, expected_scales)

        if output_dbias:
            expected_dbias = torch.stack([t.sum(dim=0) for t in input_tensors])
            torch.testing.assert_close(dbias, expected_dbias, rtol=1e-5, atol=4e-3)

    @pytest.mark.parametrize("output_dbias", [False, True])
    @pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
    def test_group_quantize_precomputed_offsets(self, output_dbias: bool) -> None:
        """Test grouped quantization can reuse caller-provided tensor offsets."""
        num_tensors = 2
        last_dim = 1024
        split_sizes_list = [512, 512]
        input_tensors = [
            torch.randn(split, last_dim, dtype=torch.bfloat16, device="cuda")
            for split in split_sizes_list
        ]
        grouped_input = torch.cat(input_tensors, dim=0)

        quantizer = MXFP8Quantizer(fp8_dtype=tex.DType.kFloat8E4M3)
        quantizer.set_usage(rowwise=True, columnwise=False)
        split_sizes = torch.tensor(split_sizes_list, dtype=torch.int64, device="cuda")
        split_sizes, (tensor_offsets,) = tex.splits_to_offsets_multi(
            split_sizes,
            torch.device("cuda"),
            strides=[last_dim],
            include_leading_zero=[True],
            dtypes=[torch.int64],
        )

        if output_dbias:
            grouped_output, dbias = tex.bgrad_group_quantize(
                grouped_input,
                quantizer,
                num_tensors,
                split_sizes,
                tensor_offsets=tensor_offsets,
            )
            expected_output, expected_dbias = tex.bgrad_group_quantize(
                grouped_input,
                quantizer,
                num_tensors,
                split_sizes,
            )
            assert torch.allclose(dbias, expected_dbias)
        else:
            grouped_output = tex.group_quantize(
                grouped_input,
                quantizer,
                num_tensors,
                split_sizes,
                tensor_offsets=tensor_offsets,
            )
            expected_output = tex.group_quantize(
                grouped_input,
                quantizer,
                num_tensors,
                split_sizes,
            )

        assert grouped_output.tensor_offsets.data_ptr() == tensor_offsets.data_ptr()
        assert torch.equal(grouped_output.rowwise_data, expected_output.rowwise_data)
        assert torch.equal(grouped_output.scale_inv, expected_output.scale_inv)

    @pytest.mark.parametrize("optimize_for_gemm", [False, True])
    @pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
    def test_group_scaled_swiglu_shapes(self, optimize_for_gemm: bool) -> None:
        """Test the grouped scaled SwiGLU MXFP8 recompute binding plumbs shapes/dtypes.

        Covers the pybind layer and its rejection paths: a [N, 2H] input plus a [N] prob must
        come back as a columnwise-MXFP8 [N, H] grouped output, and non-contiguous or
        wrong-dtype operands must raise. Values are checked in
        ``test_group_scaled_swiglu_matches_reference``.
        """
        num_tensors = 3
        last_dim = 256
        split_sizes_list = [128, 384, 512]
        total_tokens = sum(split_sizes_list)

        input_2h = torch.randn(total_tokens, 2 * last_dim, dtype=torch.bfloat16, device="cuda")
        # prob rides in the model dtype, matching TE's cuDNN fc1_prob_tensor convention.
        prob = torch.rand(total_tokens, dtype=torch.bfloat16, device="cuda")
        first_dims = torch.tensor(split_sizes_list, dtype=torch.int64, device="cuda")

        quantizer = MXFP8Quantizer(fp8_dtype=te.DType.kFloat8E4M3)
        quantizer.set_usage(rowwise=False, columnwise=True)
        quantizer.optimize_for_gemm = optimize_for_gemm

        grouped_output = tex.group_scaled_swiglu(input_2h, prob, quantizer, num_tensors, first_dims)

        outputs = grouped_output.split_into_quantized_tensors()
        assert len(outputs) == num_tensors
        for rows, output in zip(split_sizes_list, outputs):
            assert output.shape == (rows, last_dim)
            assert output._columnwise_data.numel() == rows * last_dim
            # One e8m0 exponent per 32-row block of every column. Both the compact and the
            # GEMM-swizzled layout need the same number of scales.
            assert output._columnwise_scale_inv.numel() == (rows // 32) * last_dim

        with pytest.raises(RuntimeError):
            tex.group_scaled_swiglu(input_2h, prob.float(), quantizer, num_tensors, first_dims)

        # Both operands reach the kernel as raw pointers over a densely packed range, so a
        # strided view must be rejected instead of being read as if it were contiguous.
        wide = torch.randn(total_tokens, 4 * last_dim, dtype=torch.bfloat16, device="cuda")
        with pytest.raises(RuntimeError):
            tex.group_scaled_swiglu(
                wide[:, : 2 * last_dim], prob, quantizer, num_tensors, first_dims
            )

        strided_prob = torch.rand(2 * total_tokens, dtype=torch.bfloat16, device="cuda")[::2]
        with pytest.raises(RuntimeError):
            tex.group_scaled_swiglu(input_2h, strided_prob, quantizer, num_tensors, first_dims)

    @pytest.mark.parametrize("optimize_for_gemm", [False, True])
    @pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
    def test_group_scaled_clamped_swiglu_shapes(self, optimize_for_gemm: bool) -> None:
        """Test the clamped variant's binding plumbs shapes, dtypes and clamp parameters.

        Covers the pybind layer, the identity case that must collapse onto the unclamped
        kernel, and rejection of a non-positive limit. Values are checked in
        ``test_group_scaled_swiglu_matches_reference``.
        """
        num_tensors = 3
        last_dim = 256
        split_sizes_list = [128, 384, 512]
        total_tokens = sum(split_sizes_list)

        input_2h = torch.randn(total_tokens, 2 * last_dim, dtype=torch.bfloat16, device="cuda")
        prob = torch.rand(total_tokens, dtype=torch.bfloat16, device="cuda")
        first_dims = torch.tensor(split_sizes_list, dtype=torch.int64, device="cuda")

        quantizer = MXFP8Quantizer(fp8_dtype=te.DType.kFloat8E4M3)
        quantizer.set_usage(rowwise=False, columnwise=True)
        quantizer.optimize_for_gemm = optimize_for_gemm

        grouped_output = tex.group_scaled_clamped_swiglu(
            input_2h, prob, quantizer, num_tensors, 7.0, 1.702, 1.0, first_dims
        )

        outputs = grouped_output.split_into_quantized_tensors()
        assert len(outputs) == num_tensors
        for rows, output in zip(split_sizes_list, outputs):
            assert output.shape == (rows, last_dim)
            assert output._columnwise_data.numel() == rows * last_dim
            assert output._columnwise_scale_inv.numel() == (rows // 32) * last_dim

        # A clamp wider than any input, with alpha and offset at their identity values,
        # must reproduce the unclamped kernel exactly.
        wide_limit = float(input_2h.abs().max()) + 1.0
        clamped_identity = tex.group_scaled_clamped_swiglu(
            input_2h, prob, quantizer, num_tensors, wide_limit, 1.0, 0.0, first_dims
        )
        plain = tex.group_scaled_swiglu(input_2h, prob, quantizer, num_tensors, first_dims)
        for lhs, rhs in zip(
            clamped_identity.split_into_quantized_tensors(),
            plain.split_into_quantized_tensors(),
        ):
            assert torch.equal(lhs._columnwise_data, rhs._columnwise_data)
            assert torch.equal(lhs._columnwise_scale_inv, rhs._columnwise_scale_inv)

        for bad_limit in (0.0, -1.0):
            with pytest.raises(RuntimeError):
                tex.group_scaled_clamped_swiglu(
                    input_2h, prob, quantizer, num_tensors, bad_limit, 1.702, 1.0, first_dims
                )

    @pytest.mark.parametrize("optimize_for_gemm", [False, True])
    @pytest.mark.parametrize("clamped", [False, True])
    @pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
    def test_group_scaled_swiglu_matches_reference(
        self, clamped: bool, optimize_for_gemm: bool
    ) -> None:
        """Check both grouped kernels against a quantized PyTorch reference, expert by expert.

        Each expert's reference is computed from that expert's own rows and quantized with
        the very quantizer the kernel used, so a wrong expert offset, a dropped prob multiply
        or a mis-applied clamp all surface as codes differing far beyond the rounding budget
        that ``_assert_mxfp8_matches_reference`` allows.
        """
        limit, alpha, glu_linear_offset = (7.0, 1.702, 1.0) if clamped else (None, 1.0, 0.0)

        # Row counts are multiples of the kernel's 128-row chunk, and deliberately unequal so
        # that a per-expert offset computed from the wrong group is caught.
        split_sizes_list = [128, 256, 384, 512]
        num_tensors = len(split_sizes_list)
        last_dim = 256
        total_tokens = sum(split_sizes_list)

        # Scaled up so the tails reach past the clamp limit: standard normals essentially
        # never exceed 7.0, which would leave the clamped path untested on its own numerics.
        input_2h = 4.0 * torch.randn(
            total_tokens, 2 * last_dim, dtype=torch.bfloat16, device="cuda"
        )
        prob = torch.rand(total_tokens, dtype=torch.bfloat16, device="cuda")
        first_dims = torch.tensor(split_sizes_list, dtype=torch.int64, device="cuda")

        quantizer = MXFP8Quantizer(fp8_dtype=te.DType.kFloat8E4M3)
        quantizer.set_usage(rowwise=False, columnwise=True)
        quantizer.optimize_for_gemm = optimize_for_gemm

        if clamped:
            grouped_output = tex.group_scaled_clamped_swiglu(
                input_2h,
                prob,
                quantizer,
                num_tensors,
                limit,
                alpha,
                glu_linear_offset,
                first_dims,
            )
        else:
            grouped_output = tex.group_scaled_swiglu(
                input_2h, prob, quantizer, num_tensors, first_dims
            )

        outputs = grouped_output.split_into_quantized_tensors()
        assert len(outputs) == num_tensors

        row = 0
        for expert, (rows, output) in enumerate(zip(split_sizes_list, outputs)):
            reference = _scaled_swiglu_reference(
                input_2h[row : row + rows],
                prob[row : row + rows],
                limit=limit,
                alpha=alpha,
                glu_linear_offset=glu_linear_offset,
            )
            assert reference.shape == (rows, last_dim)
            _assert_mxfp8_matches_reference(
                output,
                quantizer(reference),
                context=(
                    f"expert {expert} ({rows}x{last_dim}, clamped={clamped},"
                    f" optimize_for_gemm={optimize_for_gemm})"
                ),
            )
            row += rows

    @pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
    def test_bgrad_group_quantize_zero_size_tensor(self) -> None:
        """Test bgrad_group_quantize handles zero-row input without error."""
        num_tensors = 3
        last_dim = 1024
        grouped_input = torch.empty(0, last_dim, dtype=torch.bfloat16, device="cuda")

        quantizer = MXFP8Quantizer(fp8_dtype=te.DType.kFloat8E4M3)
        quantizer.set_usage(rowwise=True, columnwise=False)
        first_dims = torch.zeros(num_tensors, dtype=torch.int64, device="cuda")

        grouped_output, dbias = tex.bgrad_group_quantize(
            grouped_input,
            quantizer,
            num_tensors,
            first_dims,
        )

        assert dbias.shape == (num_tensors, last_dim)
        assert torch.all(dbias == 0)

    @pytest.mark.parametrize(
        "quantization",
        [
            pytest.param(
                "fp8_current_scaling",
                marks=pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8),
            ),
            pytest.param(
                "mxfp8",
                marks=pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8),
            ),
        ],
    )
    @pytest.mark.parametrize("output_dbias", [False, True])
    @pytest.mark.parametrize("shape_case", ["varying_first", "varying_last"])
    def test_group_quantize_cudagraph_capturable(
        self, quantization: str, output_dbias: bool, shape_case: str
    ) -> None:
        """Ensure group_quantize is CUDA graph capturable."""
        if output_dbias and quantization != "mxfp8":
            pytest.skip("bgrad_group_quantize only supports MXFP8")
        if output_dbias and shape_case == "varying_last":
            pytest.skip("bgrad_group_quantize does not accept last_dims")

        if shape_case == "varying_last":
            rows = 128
            last_dims_host = [256, 128, 384]
            num_tensors = len(last_dims_host)
            total_cols = sum(last_dims_host)
            flat_input = torch.empty(rows * total_cols, dtype=torch.bfloat16, device="cuda")
            offset = 0
            for cols in last_dims_host:
                member = torch.randn(rows, cols, dtype=torch.bfloat16, device="cuda")
                flat_input[offset : offset + member.numel()].copy_(member.reshape(-1))
                offset += member.numel()
            grouped_input = flat_input.view(rows, total_cols)
            first_dims = None
            last_dims = torch.tensor(last_dims_host, dtype=torch.int64, device="cuda")
        else:
            first_dims_host = [256, 128, 384]
            num_tensors = len(first_dims_host)
            hidden = 1024
            shape = [(r, hidden) for r in first_dims_host]
            input_tensors = [torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in shape]
            grouped_input = torch.cat(input_tensors, dim=0)
            first_dims = torch.tensor(first_dims_host, dtype=torch.int64, device="cuda")
            last_dims = None

        if quantization == "mxfp8":
            quantizer = MXFP8Quantizer(fp8_dtype=tex.DType.kFloat8E4M3)
        else:
            quantizer = Float8CurrentScalingQuantizer(
                fp8_dtype=tex.DType.kFloat8E4M3,
                device="cuda",
                force_pow_2_scales=False,
                amax_epsilon=0.0,
            )
        quantizer.set_usage(rowwise=True, columnwise=False)

        torch.cuda.synchronize()
        static_input = grouped_input.clone()
        static_first_dims = first_dims.clone() if first_dims is not None else None
        static_last_dims = last_dims.clone() if last_dims is not None else None

        def _run_group_quantize(input_tensor):
            """Return (output, dbias) where dbias is None when output_dbias is False."""
            if output_dbias:
                out, dbias = tex.bgrad_group_quantize(
                    input_tensor, quantizer, num_tensors, static_first_dims
                )
                return out, dbias
            out = tex.group_quantize(
                input_tensor,
                quantizer,
                num_tensors,
                static_first_dims,
                last_dims=static_last_dims,
            )
            return out, None

        # Warmup to initialize kernels and allocator state
        _ = _run_group_quantize(static_input)
        torch.cuda.synchronize()

        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            static_output, static_dbias = _run_group_quantize(static_input)

        fresh_input = torch.randn_like(grouped_input)
        static_input.copy_(fresh_input)
        graph.replay()
        torch.cuda.synchronize()

        expected_out, expected_dbias = _run_group_quantize(static_input)
        assert torch.equal(static_output.rowwise_data, expected_out.rowwise_data)
        assert torch.equal(static_output.scale_inv, expected_out.scale_inv)
        if output_dbias:
            assert torch.allclose(static_dbias, expected_dbias)

    @pytest.mark.parametrize("block_scaling_dim", [1, 2], ids=["1D", "2D"])
    @pytest.mark.skipif(
        not fp8_block_scaling_grouped_available, reason=reason_for_no_fp8_block_scaling_grouped
    )
    def test_group_quantize_fp8_blockwise_cudagraph_capturable(
        self, block_scaling_dim: int
    ) -> None:
        """Ensure grouped FP8 block-scaling quantize is CUDA graph capturable (parity with MXFP8)."""
        first_dims_host = [256, 128, 384]
        num_tensors = len(first_dims_host)
        hidden = 512
        shape = [(r, hidden) for r in first_dims_host]
        input_tensors = [torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in shape]
        grouped_input = torch.cat(input_tensors, dim=0)
        first_dims = torch.tensor(first_dims_host, dtype=torch.int64, device="cuda")

        quantizer = Float8BlockQuantizer(
            fp8_dtype=tex.DType.kFloat8E4M3,
            rowwise=True,
            columnwise=False,
            force_pow_2_scales=_fp8bs_pow2_required,
            amax_epsilon=0.0,
            block_scaling_dim=block_scaling_dim,
        )

        torch.cuda.synchronize()
        static_input = grouped_input.clone()
        static_first_dims = first_dims.clone()

        def _run(inp):
            return tex.group_quantize(inp, quantizer, num_tensors, static_first_dims)

        _ = _run(static_input)  # warmup allocator/kernels
        torch.cuda.synchronize()

        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            static_output = _run(static_input)

        # Replay with fresh input copied into the captured buffer.
        static_input.copy_(torch.randn_like(grouped_input))
        graph.replay()
        torch.cuda.synchronize()

        expected = _run(static_input)
        assert torch.equal(static_output.rowwise_data, expected.rowwise_data)
        assert torch.equal(static_output.scale_inv, expected.scale_inv)

    @pytest.mark.parametrize(
        "quantization",
        [
            pytest.param(
                "fp8_current_scaling",
                marks=pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8),
            ),
            pytest.param(
                "fp8_blockwise",
                marks=pytest.mark.skipif(
                    not fp8_block_scaling_grouped_available,
                    reason=reason_for_no_fp8_block_scaling_grouped,
                ),
            ),
        ],
    )
    def test_group_quantize_reuses_destination_and_honors_noop_fp8(self, quantization: str) -> None:
        """Check pointer-stable weight-cache updates and no-op CUDA graph replays."""
        num_tensors = 2
        shape = (num_tensors * 256, 256)
        if quantization == "fp8_current_scaling":
            quantizer = Float8CurrentScalingQuantizer(
                fp8_dtype=tex.DType.kFloat8E4M3,
                device="cuda",
                force_pow_2_scales=False,
                amax_epsilon=0.0,
            )
            quantizer.set_usage(rowwise=True, columnwise=True)
        else:
            quantizer = Float8BlockQuantizer(
                fp8_dtype=tex.DType.kFloat8E4M3,
                rowwise=True,
                columnwise=True,
                force_pow_2_scales=_fp8bs_pow2_required,
                amax_epsilon=0.0,
                block_scaling_dim=1,
            )

        source = torch.randn(shape, dtype=torch.bfloat16, device="cuda")
        output = tex.group_quantize(source, quantizer, num_tensors, None)
        output_buffers = tuple(
            buffer
            for buffer in (
                output.rowwise_data,
                output.columnwise_data,
                output.scale_inv,
                output.columnwise_scale_inv,
                output.amax,
                output.columnwise_amax,
                output.scale,
            )
            if buffer is not None
        )
        assert output_buffers
        pointers = tuple(buffer.data_ptr() for buffer in output_buffers)

        # Re-quantization must update the existing allocations because a captured GEMM keeps
        # their raw addresses rather than looking them up again through the Python object.
        updated_source = source + 1
        updated = tex.group_quantize(
            updated_source,
            quantizer,
            num_tensors,
            None,
            output=output,
        )
        reference = tex.group_quantize(updated_source, quantizer, num_tensors, None)
        assert updated is output
        assert pointers == tuple(buffer.data_ptr() for buffer in output_buffers)
        reference_buffers = tuple(
            buffer
            for buffer in (
                reference.rowwise_data,
                reference.columnwise_data,
                reference.scale_inv,
                reference.columnwise_scale_inv,
                reference.amax,
                reference.columnwise_amax,
                reference.scale,
            )
            if buffer is not None
        )
        assert len(output_buffers) == len(reference_buffers)
        for output_buffer, reference_buffer in zip(output_buffers, reference_buffers, strict=True):
            assert torch.equal(output_buffer, reference_buffer)

        # A nonzero device flag must preserve every cached payload and metadata buffer.
        old_buffers = tuple(buffer.clone() for buffer in output_buffers)
        noop = torch.ones(1, dtype=torch.float32, device="cuda")
        tex.group_quantize(
            updated_source * 2,
            quantizer,
            num_tensors,
            None,
            noop_flag=noop,
            output=output,
        )
        for output_buffer, old_buffer in zip(output_buffers, old_buffers, strict=True):
            assert torch.equal(output_buffer, old_buffer)

        # Capture one pointer-stable update. Replays change only source contents and the device
        # no-op value, matching TE's CUDA graph microbatch weight-cache protocol.
        graph_source = updated_source.clone()
        noop.zero_()
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            tex.group_quantize(
                graph_source,
                quantizer,
                num_tensors,
                None,
                noop_flag=noop,
                output=output,
            )

        graph_source.copy_(source - 1)
        noop.zero_()
        graph.replay()
        torch.cuda.synchronize()
        reference = tex.group_quantize(graph_source, quantizer, num_tensors, None)
        reference_buffers = tuple(
            buffer
            for buffer in (
                reference.rowwise_data,
                reference.columnwise_data,
                reference.scale_inv,
                reference.columnwise_scale_inv,
                reference.amax,
                reference.columnwise_amax,
                reference.scale,
            )
            if buffer is not None
        )
        assert len(output_buffers) == len(reference_buffers)
        for output_buffer, reference_buffer in zip(output_buffers, reference_buffers, strict=True):
            assert torch.equal(output_buffer, reference_buffer)

        old_buffers = tuple(buffer.clone() for buffer in output_buffers)
        graph_source.copy_(source + 2)
        noop.fill_(1)
        graph.replay()
        torch.cuda.synchronize()
        for output_buffer, old_buffer in zip(output_buffers, old_buffers, strict=True):
            assert torch.equal(output_buffer, old_buffer)

    @pytest.mark.parametrize("mode", ["rowwise", "columnwise", "both"])
    @pytest.mark.parametrize(
        "shape_case",
        [
            "uniform",
            "varying_first",
            "empty_split",
            "varying_last",
        ],
    )
    @pytest.mark.parametrize("overallocated", [False, True])
    @pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8)
    def test_group_quantize_fp8_current_scaling(
        self,
        mode: str,
        shape_case: str,
        overallocated: bool,
    ) -> None:
        """Test grouped FP8 current scaling matches per-tensor current scaling
        across shape topologies:

        - ``uniform``: no ``first_dims``/``last_dims`` (kernel partitions implicitly).
        - ``varying_first``: ``first_dims`` set, values vary.
        - ``empty_split``: ``first_dims`` set with one zero entry.
        - ``varying_last``: ``last_dims`` set, values vary.

        When ``overallocated`` is True the backing buffer is twice the active size
        in the test case, so the kernel sees an active region followed by an unused tail.
        The unused tail elements are poisoned with a large sentinel value (1e4);
        since the per-group amax assertion compares against amax computed over the
        active input tensors only, any tail read by the kernel would explode the
        per-group amax and the assertion would fail. Overallocation is skipped for
        ``uniform`` because it partitions the buffer implicitly (no metadata-defined
        active region to over-allocate against).
        """
        if overallocated and shape_case == "uniform":
            pytest.skip(
                "Overallocation is not meaningful for ``uniform`` "
                "(the kernel partitions the buffer implicitly, so there is no "
                "metadata-defined active region to over-allocate against)."
            )

        # Per-tensor shapes for each shape_case.
        if shape_case == "uniform":
            per_tensor_shapes = [(128, 256)] * 3
            first_dims_host = None
            last_dims_host = None
        elif shape_case == "varying_first":
            # Only common dimension needs to be 16B aligned.
            first_dims_host = [65, 128, 97]
            last_dims_host = None
            per_tensor_shapes = [(r, 256) for r in first_dims_host]
        elif shape_case == "empty_split":
            first_dims_host = [128, 0, 96]
            last_dims_host = None
            per_tensor_shapes = [(r, 256) for r in first_dims_host]
        elif shape_case == "varying_last":
            first_dims_host = None
            last_dims_host = [513, 1027, 259]
            per_tensor_shapes = [(256, c) for c in last_dims_host]
        else:
            raise ValueError(f"Unknown shape_case: {shape_case}")

        num_tensors = len(per_tensor_shapes)
        first_dims = (
            torch.tensor(first_dims_host, dtype=torch.int64, device="cuda")
            if first_dims_host is not None
            else None
        )
        last_dims = (
            torch.tensor(last_dims_host, dtype=torch.int64, device="cuda")
            if last_dims_host is not None
            else None
        )

        # Per-tensor data + flat buffer (tensor i occupies a contiguous chunk).
        input_tensors = [
            torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in per_tensor_shapes
        ]
        actual_numel = sum(t.numel() for t in input_tensors)
        allocated_numel = actual_numel * 2 if overallocated else actual_numel
        flat_buffer = torch.empty(allocated_numel, dtype=torch.bfloat16, device="cuda")
        offset = 0
        for t in input_tensors:
            flat_buffer[offset : offset + t.numel()].copy_(t.reshape(-1))
            offset += t.numel()
        if overallocated:
            flat_buffer[actual_numel:].fill_(10000.0)

        # View flat buffer as the 2D shape expected by group_quantize.
        if shape_case in ("varying_last",):
            common_first = per_tensor_shapes[0][0]
            allocated_last = allocated_numel // common_first
            grouped_input = flat_buffer.view(common_first, allocated_last)
        else:
            common_last = per_tensor_shapes[0][1]
            allocated_first = allocated_numel // common_last
            grouped_input = flat_buffer.view(allocated_first, common_last)

        requested_rowwise = mode in ("rowwise", "both")
        requested_columnwise = mode in ("columnwise", "both")
        rowwise = requested_rowwise or (requested_columnwise and is_non_tn_fp8_gemm_supported())
        columnwise = requested_columnwise and not is_non_tn_fp8_gemm_supported()

        quantizer = Float8CurrentScalingQuantizer(
            fp8_dtype=tex.DType.kFloat8E4M3,
            device="cuda",
            force_pow_2_scales=False,
            amax_epsilon=0.0,
        )
        quantizer.set_usage(rowwise=requested_rowwise, columnwise=requested_columnwise)

        grouped_output = tex.group_quantize(
            grouped_input, quantizer, num_tensors, first_dims, last_dims=last_dims
        )

        # Metadata validation for the varying-last code path.
        if shape_case in ("varying_last",):
            assert grouped_output.first_dims is None
            assert torch.equal(grouped_output.last_dims, last_dims)

        # When ``overallocated`` is True, the input has poisoned rows past
        # sum(first_dims) (filled with 1e4). If the kernel were to read those
        # tail rows, per-group amax would explode well above what bf16 N(0,1)
        # produces. We catch that implicitly via the per-group amax assertion in
        # ``_assert_fp8_cs_group_quantize_matches_reference`` below.
        self._assert_fp8_cs_group_quantize_matches_reference(
            grouped_output=grouped_output,
            input_tensors=input_tensors,
            rowwise=rowwise,
            columnwise=columnwise,
        )

    @staticmethod
    def _assert_fp8_cs_group_quantize_matches_reference(
        *,
        grouped_output,
        input_tensors: List[torch.Tensor],
        rowwise: bool,
        columnwise: bool,
    ) -> None:
        """Validate amax/scale/scale_inv/per-tensor data of an FP8 current-scaling
        grouped output against per-tensor Float8CurrentScalingQuantizer references."""
        expected_amax = torch.stack(
            [
                (
                    tensor.abs().max().float()
                    if tensor.numel() > 0
                    else torch.zeros((), dtype=torch.float32, device="cuda")
                )
                for tensor in input_tensors
            ]
        )
        torch.testing.assert_close(grouped_output.amax, expected_amax, rtol=0.0, atol=0.0)

        scale_inv = grouped_output.scale_inv
        if scale_inv is None:
            scale_inv = grouped_output.columnwise_scale_inv
        torch.testing.assert_close(
            scale_inv,
            torch.reciprocal(grouped_output.scale),
            rtol=1e-6,
            atol=1e-6,
        )
        if rowwise and columnwise:
            torch.testing.assert_close(
                grouped_output.columnwise_scale_inv,
                grouped_output.scale_inv,
                rtol=0.0,
                atol=0.0,
            )

        expected_rowwise = []
        expected_columnwise = []
        for tensor in input_tensors:
            if tensor.numel() == 0:
                continue
            ref_quantizer = Float8CurrentScalingQuantizer(
                fp8_dtype=tex.DType.kFloat8E4M3,
                device="cuda",
                rowwise=True,
                columnwise=False,
                force_pow_2_scales=False,
                amax_epsilon=0.0,
            )
            ref = ref_quantizer(tensor)
            ref_rowwise_data = ref._data.reshape(tensor.shape)
            if rowwise:
                expected_rowwise.append(ref_rowwise_data.reshape(-1))
            if columnwise:
                expected_columnwise.append(ref_rowwise_data.T.contiguous().reshape(-1))

        if rowwise and expected_rowwise:
            expected = torch.cat(expected_rowwise)
            assert torch.equal(grouped_output.rowwise_data[: expected.numel()], expected)
        if columnwise and expected_columnwise:
            expected = torch.cat(expected_columnwise)
            assert torch.equal(grouped_output.columnwise_data[: expected.numel()], expected)

    @pytest.mark.parametrize("block_scaling_dim", [1, 2], ids=["1D", "2D"])
    @pytest.mark.parametrize("shape_case", ["uniform", "varying_first"])
    @pytest.mark.parametrize("direction", ["rowwise", "columnwise", "both"])
    @pytest.mark.parametrize("output_dbias", [False, True])
    @pytest.mark.parametrize(
        "force_pow_2_scales", [False, True], ids=["fp32_scales", "pow2_scales"]
    )
    @pytest.mark.skipif(
        not fp8_block_scaling_grouped_available, reason=reason_for_no_fp8_block_scaling_grouped
    )
    def test_quantize_grouped_fp8_blockwise(
        self,
        block_scaling_dim: int,
        shape_case: str,
        direction: str,
        output_dbias: bool,
        force_pow_2_scales: bool,
    ) -> None:
        """Test grouped FP8 block-scaling quantization against per-tensor quantization.

        Covers rowwise, columnwise and both directions. Each expert's data sub-block (and, for
        rowwise, its scale sub-block placed at the cumulative padded offset from
        ``_fp8bs_per_expert_scale_floats``) is compared against an independent per-tensor reference
        quantizer. The columnwise scale layout carries 2D padding plus the per-expert slack
        reserved in ``Float8BlockQuantizer.create_grouped_tensor``; it is validated end to end by
        ``test_group_dequantize_fp8_blockwise`` rather than by a fragile byte-compare here.

        FP8 block-scaling supports only SAME_BOTH_DIMS (``uniform``) and VARYING_FIRST_DIM
        (``varying_first``); ``varying_last``/``varying_both`` are rejected at the kernel level.
        Per-tensor first dim must be a multiple of 128 (kernel tile size).
        """
        if not force_pow_2_scales and _fp8bs_pow2_required:
            # Non-power-of-2 FP8 block scales cannot be emulated with MXFP8 on Blackwell+.
            quantizer = Float8BlockQuantizer(
                fp8_dtype=tex.DType.kFloat8E4M3,
                rowwise=True,
                columnwise=True,
                force_pow_2_scales=False,
                amax_epsilon=0.0,
                block_scaling_dim=block_scaling_dim,
            )
            x = torch.randn(256, 256, dtype=torch.bfloat16, device="cuda")
            with pytest.raises(RuntimeError, match="power of two scaling factors"):
                tex.group_quantize(x, quantizer, 2, None)
            return

        rowwise = direction in ("rowwise", "both")
        columnwise = direction in ("columnwise", "both")

        # dbias is the bias gradient (per-column input sum) emitted by the bgrad path, which
        # requires rowwise output; the columnwise-only + dbias combination is not applicable.
        if output_dbias and not rowwise:
            pytest.skip("bgrad (dbias) requires rowwise output; columnwise-only does not apply.")

        if shape_case == "uniform":
            per_tensor_shapes = [(128, 512)] * 3
            first_dims_host = None
        else:  # varying_first
            per_tensor_shapes = [(128, 512), (256, 512), (384, 512)]
            first_dims_host = [s[0] for s in per_tensor_shapes]

        num_tensors = len(per_tensor_shapes)

        input_tensors = [
            torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in per_tensor_shapes
        ]
        flat_buffer = torch.cat([t.reshape(-1) for t in input_tensors])
        common_last = per_tensor_shapes[0][1]
        grouped_input = flat_buffer.view(-1, common_last)

        first_dims = (
            torch.tensor(first_dims_host, dtype=torch.int64, device="cuda")
            if first_dims_host is not None
            else None
        )

        quantizer = Float8BlockQuantizer(
            fp8_dtype=tex.DType.kFloat8E4M3,
            rowwise=rowwise,
            columnwise=columnwise,
            force_pow_2_scales=force_pow_2_scales,
            amax_epsilon=0.0,
            block_scaling_dim=block_scaling_dim,
        )

        if output_dbias:
            grouped_output, dbias = tex.bgrad_group_quantize(
                grouped_input, quantizer, num_tensors, first_dims
            )
        else:
            grouped_output = tex.group_quantize(grouped_input, quantizer, num_tensors, first_dims)

        # Compare each expert's sub-block against an independent per-tensor reference. The
        # reference enables both directions: the non-grouped 2D kernel requires rowwise output to
        # be allocated even when only columnwise is consumed, and the columnwise data/scale it
        # emits are independent of whether rowwise is also computed.
        ref_quantizer = Float8BlockQuantizer(
            fp8_dtype=tex.DType.kFloat8E4M3,
            rowwise=True,
            columnwise=True,
            force_pow_2_scales=force_pow_2_scales,
            amax_epsilon=0.0,
            block_scaling_dim=block_scaling_dim,
        )
        # Data sub-blocks are contiguous (rowwise (M_t, K) / columnwise transposed (K, M_t)) with
        # no inter-expert padding. The rowwise scale sub-block is placed at the cumulative
        # per-expert padded offset, so a wrong stride fails byte-equality here. The columnwise
        # scale carries 2D ``roundup(blocks_y_t, 4)`` padding columns (and the per-expert slack),
        # so its layout is validated end to end by ``test_group_dequantize_fp8_blockwise`` instead.
        data_off = 0
        rw_scale_off = 0
        for tensor in input_tensors:
            m_t, k = tensor.shape
            numel = m_t * k
            ref = ref_quantizer(tensor)
            if rowwise:
                ref_rw = ref._rowwise_data.reshape(-1)
                assert torch.equal(grouped_output.rowwise_data[data_off : data_off + numel], ref_rw)
                ref_rs = ref._rowwise_scale_inv.reshape(-1)
                assert torch.equal(
                    grouped_output.scale_inv[rw_scale_off : rw_scale_off + ref_rs.numel()], ref_rs
                )
                rw_scale_off += _fp8bs_per_expert_scale_floats(block_scaling_dim, False, m_t, k)
            if columnwise:
                ref_cw = ref._columnwise_data.reshape(-1)
                assert torch.equal(
                    grouped_output.columnwise_data[data_off : data_off + numel], ref_cw
                )
            data_off += numel

        if output_dbias:
            expected_dbias = torch.stack([t.sum(dim=0) for t in input_tensors])
            torch.testing.assert_close(dbias, expected_dbias, rtol=1e-5, atol=4e-3)

    @pytest.mark.parametrize(
        "shape",
        [[(512, 1024), (512, 1024)], [(256, 512), (512, 512), (768, 512)]],
    )
    @pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
    def test_group_dequantize(self, shape: List[Tuple[int, int]]) -> None:
        """Test grouped dequantization for MXFP8 back to BF16."""
        num_tensors = len(shape)

        # Create BF16 input tensors and quantize them with MXFP8.
        input_tensors = [torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in shape]
        grouped_input = torch.cat(input_tensors, dim=0)

        quantizer = MXFP8Quantizer(fp8_dtype=te.DType.kFloat8E4M3)
        quantizer.set_usage(rowwise=True, columnwise=False)
        first_dims = torch.tensor([s[0] for s in shape], dtype=torch.int64, device="cuda")

        # Quantize.
        quantized = tex.group_quantize(grouped_input, quantizer, num_tensors, first_dims)

        # Dequantize.
        dequantized = tex.group_dequantize(quantized, te.DType.kBFloat16)

        # Verify output metadata.
        assert dequantized.num_tensors == num_tensors
        assert dequantized.logical_shape == quantized.logical_shape
        assert torch.equal(dequantized.first_dims, quantized.first_dims)
        assert torch.equal(dequantized.tensor_offsets, quantized.tensor_offsets)

        # Verify dequantized values are close to original (per-tensor).
        dequantized_tensors = dequantized.split_into_quantized_tensors()
        assert len(dequantized_tensors) == num_tensors
        for orig, deq in zip(input_tensors, dequantized_tensors):
            torch.testing.assert_close(deq, orig, atol=0.125, rtol=0.1)

    @pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
    def test_group_dequantize_cudagraph_capturable(self) -> None:
        """Ensure group_dequantize is CUDA graph capturable."""
        num_tensors = 2
        shape = [(512, 1024) for _ in range(num_tensors)]
        input_tensors = [torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in shape]
        grouped_input = torch.cat(input_tensors, dim=0)

        quantizer = MXFP8Quantizer(fp8_dtype=te.DType.kFloat8E4M3)
        quantizer.set_usage(rowwise=True, columnwise=False)
        first_dims = torch.tensor(
            [shape[0][0] for _ in range(num_tensors)],
            dtype=torch.int64,
            device="cuda",
        )

        # Quantize to get MXFP8 grouped tensor.
        quantized = tex.group_quantize(grouped_input, quantizer, num_tensors, first_dims)

        # Warmup dequantize.
        torch.cuda.synchronize()
        _ = tex.group_dequantize(quantized, te.DType.kBFloat16)
        torch.cuda.synchronize()

        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            static_output = tex.group_dequantize(quantized, te.DType.kBFloat16)

        # Replay with different input data.
        fresh_input = torch.cat(
            [torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in shape],
            dim=0,
        )
        fresh_quantized = tex.group_quantize(fresh_input, quantizer, num_tensors, first_dims)
        quantized.rowwise_data.copy_(fresh_quantized.rowwise_data)
        quantized.scale_inv.copy_(fresh_quantized.scale_inv)

        graph.replay()
        torch.cuda.synchronize()

        expected = tex.group_dequantize(quantized, te.DType.kBFloat16)
        expected_tensors = expected.split_into_quantized_tensors()
        static_tensors = static_output.split_into_quantized_tensors()
        for exp, got in zip(expected_tensors, static_tensors):
            assert torch.equal(got, exp)

    @pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
    def test_group_quantize_reuses_destination_and_honors_noop(self) -> None:
        """Verify the in-place and graph-safe contracts of grouped MXFP8 quantization.

        A captured training graph records the addresses of all MXFP8 weight storage, not just
        the Python ``GroupedTensor`` object. Re-quantizing an updated BF16 weight must therefore
        refresh the existing FP8 payloads and scales without replacing any allocation. During
        graph replay, ``noop_flag`` must additionally allow the captured quantization kernel to
        execute as a no-op on microbatches that should reuse the cached weight.
        """
        num_tensors = 2
        # Treat two contiguous [256, 256] matrices as one grouped BF16 source. These dimensions
        # satisfy the MXFP8 block-alignment requirements in both rowwise and columnwise layouts.
        shape = (num_tensors * 256, 256)
        quantizer = MXFP8Quantizer(fp8_dtype=te.DType.kFloat8E4M3)

        # Forward GEMM consumes rowwise weight storage, while backward dgrad consumes columnwise
        # storage. Both representations and both scale tensors must be updated and kept stable.
        quantizer.set_usage(rowwise=True, columnwise=True)
        # Store the quantized output in GEMM-ready (swizzled) scale layout. This makes the test
        # cover the exact destination format used by cached MXFP8 model weights.
        quantizer.optimize_for_gemm = True

        # The first call owns allocation: it creates the persistent destination that subsequent
        # optimizer updates and CUDA graph replays must modify in place.
        source = torch.randn(shape, dtype=torch.bfloat16, device="cuda")
        output = tex.group_quantize(source, quantizer, num_tensors, None)

        # CUDA graphs retain these raw addresses. Object identity alone is insufficient because
        # replacing one internal payload or scale allocation would leave the graph with a stale
        # pointer even if ``output`` remained the same Python object.
        pointers = (
            output.rowwise_data.data_ptr(),
            output.columnwise_data.data_ptr(),
            output.scale_inv.data_ptr(),
            output.columnwise_scale_inv.data_ptr(),
        )

        # Eager in-place update: quantize new BF16 values into the previously allocated output.
        # An independently allocated quantization provides the numerical reference.
        updated_source = source + 1
        updated = tex.group_quantize(
            updated_source,
            quantizer,
            num_tensors,
            None,
            output=output,
        )
        reference = tex.group_quantize(updated_source, quantizer, num_tensors, None)

        # The API must return the caller-provided destination and preserve every captured address.
        assert updated is output
        assert pointers == (
            output.rowwise_data.data_ptr(),
            output.columnwise_data.data_ptr(),
            output.scale_inv.data_ptr(),
            output.columnwise_scale_inv.data_ptr(),
        )

        # In-place quantization must still produce exactly the same FP8 bytes and scales as a
        # normal allocating call, for both GEMM orientations.
        assert torch.equal(output.rowwise_data, reference.rowwise_data)
        assert torch.equal(output.columnwise_data, reference.columnwise_data)
        assert torch.equal(output.scale_inv, reference.scale_inv)
        assert torch.equal(output.columnwise_scale_inv, reference.columnwise_scale_inv)

        # Eager no-op: a nonzero device flag tells the kernel to preserve the cached destination.
        # Clone all four buffers so this checks payloads and metadata independently.
        old_buffers = (
            output.rowwise_data.clone(),
            output.columnwise_data.clone(),
            output.scale_inv.clone(),
            output.columnwise_scale_inv.clone(),
        )
        noop = torch.ones(1, dtype=torch.float32, device="cuda")

        # The source is deliberately different. If the kernel ignores ``noop_flag``, at least
        # one payload or scale tensor below will change and expose the failure.
        tex.group_quantize(
            updated_source * 2,
            quantizer,
            num_tensors,
            None,
            noop_flag=noop,
            output=output,
        )
        assert torch.equal(output.rowwise_data, old_buffers[0])
        assert torch.equal(output.columnwise_data, old_buffers[1])
        assert torch.equal(output.scale_inv, old_buffers[2])
        assert torch.equal(output.columnwise_scale_inv, old_buffers[3])

        # Capture one fixed launch. ``graph_source``, ``noop``, and ``output`` keep stable device
        # addresses; replay changes only their contents. This is how weight caching works when
        # different microbatches replay the same CUDA graph.
        graph_source = updated_source.clone()
        # zero means "perform quantization"; nonzero means "leave destination untouched".
        noop.zero_()
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            tex.group_quantize(
                graph_source,
                quantizer,
                num_tensors,
                None,
                noop_flag=noop,
                output=output,
            )

        # Replay with new source contents and noop=0. The captured kernel must refresh the same
        # destination allocations, and the result must equal a fresh eager quantization.
        graph_source.copy_(source - 1)
        noop.zero_()
        graph.replay()
        torch.cuda.synchronize()
        reference = tex.group_quantize(graph_source, quantizer, num_tensors, None)
        assert torch.equal(output.rowwise_data, reference.rowwise_data)
        assert torch.equal(output.columnwise_data, reference.columnwise_data)
        assert torch.equal(output.scale_inv, reference.scale_inv)
        assert torch.equal(output.columnwise_scale_inv, reference.columnwise_scale_inv)

        # Snapshot the successfully refreshed cache before testing the captured no-op branch.
        old_buffers = (
            output.rowwise_data.clone(),
            output.columnwise_data.clone(),
            output.scale_inv.clone(),
            output.columnwise_scale_inv.clone(),
        )

        # Replay the exact same captured graph with different source data but noop=1. The launch
        # still occurs, which is required for CUDA graph structural consistency, but the kernel
        # must not mutate any cached FP8 payload or scale buffer.
        graph_source.copy_(source + 2)
        noop.fill_(1)
        graph.replay()
        torch.cuda.synchronize()
        assert torch.equal(output.rowwise_data, old_buffers[0])
        assert torch.equal(output.columnwise_data, old_buffers[1])
        assert torch.equal(output.scale_inv, old_buffers[2])
        assert torch.equal(output.columnwise_scale_inv, old_buffers[3])

    @pytest.mark.parametrize("block_scaling_dim", [1, 2], ids=["1D", "2D"])
    @pytest.mark.parametrize("direction", ["rowwise", "columnwise"])
    @pytest.mark.skipif(
        not fp8_block_scaling_grouped_available, reason=reason_for_no_fp8_block_scaling_grouped
    )
    def test_group_dequantize_fp8_blockwise_cudagraph_capturable(
        self, block_scaling_dim: int, direction: str
    ) -> None:
        """Ensure grouped FP8 block-scaling dequantize is CUDA graph capturable (parity with MXFP8)."""
        rowwise = direction == "rowwise"
        columnwise = direction == "columnwise"
        num_tensors = 2
        shape = [(512, 1024) for _ in range(num_tensors)]
        input_tensors = [torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in shape]
        grouped_input = torch.cat(input_tensors, dim=0)

        quantizer = Float8BlockQuantizer(
            fp8_dtype=tex.DType.kFloat8E4M3,
            rowwise=rowwise,
            columnwise=columnwise,
            force_pow_2_scales=_fp8bs_pow2_required,
            amax_epsilon=0.0,
            block_scaling_dim=block_scaling_dim,
        )
        first_dims = torch.tensor(
            [shape[0][0] for _ in range(num_tensors)], dtype=torch.int64, device="cuda"
        )

        quantized = tex.group_quantize(grouped_input, quantizer, num_tensors, first_dims)

        # Warmup dequantize.
        torch.cuda.synchronize()
        _ = tex.group_dequantize(quantized, te.DType.kBFloat16)
        torch.cuda.synchronize()

        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            static_output = tex.group_dequantize(quantized, te.DType.kBFloat16)

        # Replay with fresh quantized data copied into the captured input buffers.
        fresh_input = torch.cat(
            [torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in shape], dim=0
        )
        fresh_quantized = tex.group_quantize(fresh_input, quantizer, num_tensors, first_dims)
        if rowwise:
            quantized.rowwise_data.copy_(fresh_quantized.rowwise_data)
            quantized.scale_inv.copy_(fresh_quantized.scale_inv)
        else:
            quantized.columnwise_data.copy_(fresh_quantized.columnwise_data)
            quantized.columnwise_scale_inv.copy_(fresh_quantized.columnwise_scale_inv)

        graph.replay()
        torch.cuda.synchronize()

        expected = tex.group_dequantize(quantized, te.DType.kBFloat16)
        expected_tensors = expected.split_into_quantized_tensors()
        static_tensors = static_output.split_into_quantized_tensors()
        for exp, got in zip(expected_tensors, static_tensors):
            assert torch.equal(got, exp)

    @pytest.mark.parametrize("block_scaling_dim", [1, 2], ids=["1D", "2D"])
    @pytest.mark.parametrize("direction", ["rowwise", "columnwise"])
    @pytest.mark.parametrize(
        "shape",
        [[(512, 1024), (512, 1024)], [(128, 512), (256, 512), (384, 512)]],
    )
    @pytest.mark.skipif(
        not fp8_block_scaling_grouped_available, reason=reason_for_no_fp8_block_scaling_grouped
    )
    def test_group_dequantize_fp8_blockwise(
        self, block_scaling_dim: int, direction: str, shape: List[Tuple[int, int]]
    ) -> None:
        """Test grouped FP8 block-scaling dequantize round-trip for rowwise and columnwise.

        The columnwise + ``varying_first`` + 2D case exercises the per-expert columnwise
        scale-buffer slack end to end: a wrong slack/stride would place scales at the wrong
        offsets and corrupt the dequantized values. ``group_dequantize`` consumes exactly one of
        rowwise / columnwise data, so ``both`` is not a valid round-trip and is not tested here.
        """
        rowwise = direction == "rowwise"
        columnwise = direction == "columnwise"
        num_tensors = len(shape)

        input_tensors = [torch.randn(s, dtype=torch.bfloat16, device="cuda") for s in shape]
        grouped_input = torch.cat(input_tensors, dim=0)

        quantizer = Float8BlockQuantizer(
            fp8_dtype=tex.DType.kFloat8E4M3,
            rowwise=rowwise,
            columnwise=columnwise,
            force_pow_2_scales=_fp8bs_pow2_required,
            amax_epsilon=0.0,
            block_scaling_dim=block_scaling_dim,
        )
        first_dims = torch.tensor([s[0] for s in shape], dtype=torch.int64, device="cuda")

        quantized = tex.group_quantize(grouped_input, quantizer, num_tensors, first_dims)
        dequantized = tex.group_dequantize(quantized, te.DType.kBFloat16)

        assert dequantized.num_tensors == num_tensors
        assert dequantized.logical_shape == quantized.logical_shape
        assert torch.equal(dequantized.first_dims, quantized.first_dims)
        assert torch.equal(dequantized.tensor_offsets, quantized.tensor_offsets)

        dequantized_tensors = dequantized.split_into_quantized_tensors()
        assert len(dequantized_tensors) == num_tensors
        for orig, deq in zip(input_tensors, dequantized_tensors):
            torch.testing.assert_close(deq, orig, atol=0.125, rtol=0.1)

    def test_clear(self) -> None:
        """Test clear method"""
        num_tensors = 3
        shape = [(256, 512) for _ in range(num_tensors)]

        grouped_tensor = GroupedTensor.make_grouped_tensor_with_shapes(
            num_tensors=num_tensors,
            shapes=shape,
            quantizer=None,
            device="cuda",
            dtype=torch.float32,
        )

        assert grouped_tensor.has_data()
        assert grouped_tensor.num_tensors == num_tensors

        grouped_tensor.clear()

        assert not grouped_tensor.has_data()
        assert grouped_tensor.num_tensors == 0
        assert grouped_tensor.rowwise_data is None
        assert grouped_tensor.logical_shape == (0, 0)

    def test_grouped_linear_load_state_dict_multi_to_single_param(self, tmp_path) -> None:
        """Load per-GEMM checkpoint from disk into single grouped parameter format."""
        num_gemms = 3
        in_features = 64
        out_features = 32
        dtype = torch.float32
        src = te.GroupedLinear(
            num_gemms=num_gemms,
            in_features=in_features,
            out_features=out_features,
            params_dtype=dtype,
            single_grouped_weight=False,
        ).cuda()
        with torch.no_grad():
            for i in range(num_gemms):
                getattr(src, f"weight{i}").copy_(
                    torch.randn(out_features, in_features, device="cuda", dtype=dtype)
                )
                if src.use_bias:
                    getattr(src, f"bias{i}").copy_(
                        torch.randn(out_features, device="cuda", dtype=dtype)
                    )
        expected_weights = [getattr(src, f"weight{i}").detach().clone() for i in range(num_gemms)]
        expected_biases = [getattr(src, f"bias{i}").detach().clone() for i in range(num_gemms)]
        ckpt_path = tmp_path / "grouped_linear_per_gemm.pt"
        torch.save(src.state_dict(), ckpt_path)
        del src

        src_state_dict = torch.load(ckpt_path, map_location="cpu", weights_only=False)

        dst = te.GroupedLinear(
            num_gemms=num_gemms,
            in_features=in_features,
            out_features=out_features,
            params_dtype=dtype,
            single_grouped_weight=True,
            single_grouped_bias=True,
        ).cuda()
        load_result = dst.load_state_dict(src_state_dict, strict=True)
        assert len(load_result.missing_keys) == 0
        assert len(load_result.unexpected_keys) == 0

        assert getattr(dst, "weight", None) is not None
        loaded_weights = dst.weight.split_into_quantized_tensors()
        assert len(loaded_weights) == num_gemms
        for loaded_weight, expected_weight in zip(loaded_weights, expected_weights):
            assert torch.equal(loaded_weight, expected_weight)

        assert getattr(dst, "bias", None) is not None
        loaded_biases = dst.bias.split_into_quantized_tensors()
        assert len(loaded_biases) == num_gemms
        for loaded_bias, expected_bias in zip(loaded_biases, expected_biases):
            assert torch.equal(loaded_bias.reshape(-1), expected_bias.reshape(-1))

    def test_grouped_linear_load_state_dict_single_to_multi_param(self, tmp_path) -> None:
        """Load grouped-parameter checkpoint from disk into per-GEMM parameter format."""
        num_gemms = 3
        in_features = 64
        out_features = 32
        dtype = torch.float32

        src = te.GroupedLinear(
            num_gemms=num_gemms,
            in_features=in_features,
            out_features=out_features,
            params_dtype=dtype,
            single_grouped_weight=True,
            single_grouped_bias=True,
        ).cuda()
        with torch.no_grad():
            source_weights = src.weight.split_into_quantized_tensors()
            for i in range(num_gemms):
                source_weights[i].copy_(
                    torch.randn(out_features, in_features, device="cuda", dtype=dtype)
                )
        expected_weights = [weight.detach().clone() for weight in source_weights]
        source_biases = src.bias.split_into_quantized_tensors()
        for i in range(num_gemms):
            source_biases[i].copy_(torch.randn(out_features, device="cuda", dtype=dtype))
        expected_biases = [b.detach().clone() for b in source_biases]
        ckpt_path = tmp_path / "grouped_linear_single_param.pt"
        torch.save(src.state_dict(), ckpt_path)
        del src

        src_state_dict = torch.load(ckpt_path, map_location="cpu", weights_only=False)

        dst = te.GroupedLinear(
            num_gemms=num_gemms,
            in_features=in_features,
            out_features=out_features,
            params_dtype=dtype,
            single_grouped_weight=False,
        ).cuda()
        load_result = dst.load_state_dict(src_state_dict, strict=True)
        assert len(load_result.missing_keys) == 0
        assert len(load_result.unexpected_keys) == 0

        for i, expected_weight in enumerate(expected_weights):
            assert torch.equal(getattr(dst, f"weight{i}"), expected_weight)
        for i, expected_bias in enumerate(expected_biases):
            assert torch.equal(getattr(dst, f"bias{i}"), expected_bias.reshape(-1))
