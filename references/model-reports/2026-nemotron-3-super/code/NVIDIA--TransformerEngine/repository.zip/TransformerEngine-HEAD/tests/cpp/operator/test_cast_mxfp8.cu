/*************************************************************************
 * Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * See LICENSE for license information.
 ************************************************************************/

#include <algorithm>

#include <cuda_bf16.h>
#include <cuda_fp8.h>
#include <cuda_runtime.h>
#include <cstring>
#include <gtest/gtest.h>

#include <transformer_engine/cast.h>
#include <transformer_engine/activation.h>
#include <transformer_engine/swizzle.h>
#include "../test_common.h"
#include "transformer_engine/transformer_engine.h"

using namespace transformer_engine;
using namespace test;

namespace {

enum ProcessingMethod {
    CAST_ONLY,
    CAST_DBIAS,
    CAST_DBIAS_DACT,
    CAST_DACT,
    CAST_ACT
};

enum ActivationType {
    Identity,
    GeLU,
    SiLU,
    ReLU,
    QGeLU,
    SReLU
};

enum MXFP82DScalingDirection {
    RowwiseOnly,
    ColwiseOnly,
    Bidirectional
};

template <typename InputType, typename OutputType>
void compute_ref(const ProcessingMethod processing_method,
                 float (*OP)(const float),
                 const bool rowwise,
                 const bool colwise,
                 const InputType* input,
                 const InputType* grad,
                 OutputType* output_rowwise,
                 OutputType* output_colwise,
                 fp8e8m0* output_scales_rowwise,
                 fp8e8m0* output_scales_colwise,
                 InputType* output_dbias,
                 const size_t rows,
                 const size_t cols,
                 const size_t scales_stride_rowwise,
                 const size_t scales_stride_colwise)
{
    const size_t tile_size_Y = 32;
    const size_t tile_size_X = 32;
    const size_t tiles_num_Y = (rows + tile_size_Y - 1) / tile_size_Y;
    const size_t tiles_num_X = (cols + tile_size_X - 1) / tile_size_X;

    std::vector<float> output_dbias_fp32(cols, 0);
    #pragma omp parallel proc_bind(spread)
    {
        // Buffers to cache intermediate computations
        std::vector<float> cache_buffer(tile_size_Y * tile_size_X);

        std::vector<float> thread_dbias(cols, 0);
        #pragma omp for schedule(static)
        for (size_t t = 0; t < tiles_num_Y * tiles_num_X; ++t) {
            const size_t tile_Y = t / tiles_num_X;
            const size_t tile_X = t % tiles_num_X;
            const size_t tile_offset_Y = tile_Y * tile_size_Y;
            const size_t tile_offset_X = tile_X * tile_size_X;

            const size_t i_min = tile_offset_Y;
            const size_t i_max = std::min(i_min + tile_size_Y, rows);

            const size_t j_min = tile_offset_X;
            const size_t j_max = std::min(j_min + tile_size_X, cols);

            // Cache computations
            for (size_t i = i_min; i < i_max; ++i) {
                for (size_t j = j_min; j < j_max; ++j) {

                    const size_t idx = i * cols + j;
                    const size_t cache_idx = (i - i_min) * tile_size_X + (j - j_min);

                    float elt = static_cast<float>(input[idx]);
                    if (processing_method == ProcessingMethod::CAST_DBIAS) {
                        // grad is the input
                        elt = static_cast<float>(grad[idx]);
                    }
                    if (processing_method != ProcessingMethod::CAST_ONLY
                        && processing_method != ProcessingMethod::CAST_DBIAS) {
                        elt = OP(elt);
                    }
                    if (processing_method == ProcessingMethod::CAST_DACT ||
                        processing_method == ProcessingMethod::CAST_DBIAS_DACT) {
                        elt *= static_cast<float>(grad[idx]);
                    }
                    thread_dbias[j] += elt;

                    // Numerical truncation: after downcast to InputType (BF16/FP16), upcast it back to FP32
                    elt = static_cast<float>(static_cast<InputType>(elt));

                    cache_buffer[cache_idx] = elt;
                    if (isinf(elt) || isnan(elt)) {
                        continue;
                    }
                }
            }

            if (rowwise) {
                for (size_t i = i_min; i < i_max; ++i) {
                    float block_amax = 0.0f;

                    for (size_t j = j_min; j < j_max; ++j) {
                        const size_t cache_idx = (i - i_min) * tile_size_X + (j - j_min);
                        block_amax = std::max(block_amax, std::abs(cache_buffer[cache_idx]));
                    }

                    const fp8e8m0 biased_exponent = float_to_e8m0(block_amax * Quantized_Limits<OutputType>::max_reciprocal());
                    const size_t scale_idx = i * scales_stride_rowwise + tile_X;
                    output_scales_rowwise[scale_idx] = biased_exponent;
                    const float scale_reciprocal = exp2f_rcp(biased_exponent);

                    for (size_t j = j_min; j < j_max; ++j) {
                        const size_t idx = i * cols + j;
                        const size_t cache_idx = (i - i_min) * tile_size_X + (j - j_min);
                        output_rowwise[idx] = static_cast<OutputType>(cache_buffer[cache_idx] * scale_reciprocal);
                    }
                }
            }
            if (colwise) {
                for (size_t j = j_min; j < j_max; ++j) {
                    float block_amax = 0.0f;

                    for (size_t i = i_min; i < i_max; ++i) {
                        const size_t cache_idx = (i - i_min) * tile_size_X + (j - j_min);
                        block_amax = std::max(block_amax, std::abs(cache_buffer[cache_idx]));
                    }

                    const fp8e8m0 biased_exponent = float_to_e8m0(block_amax * Quantized_Limits<OutputType>::max_reciprocal());
                    const size_t scale_idx = tile_Y * scales_stride_colwise + j;
                    output_scales_colwise[scale_idx] = biased_exponent;
                    const float scale_reciprocal = exp2f_rcp(biased_exponent);

                    for (size_t i = i_min; i < i_max; ++i) {
                        const size_t idx = i * cols + j;
                        const size_t cache_idx = (i - i_min) * tile_size_X + (j - j_min);
                        output_colwise[idx] = static_cast<OutputType>(cache_buffer[cache_idx] * scale_reciprocal);
                    }
                }
            }
        }
        #pragma omp critical
        {
            for (size_t j = 0; j < cols; ++j) {
                output_dbias_fp32[j] += thread_dbias[j];
            }
        }
    }
    for (size_t j = 0; j < cols; ++j) {
        output_dbias[j] = static_cast<InputType>(output_dbias_fp32[j]);
    }
}

template <typename InputType, typename OutputType>
void compute_ref_2d_quantize(const bool rowwise,
                             const bool colwise,
                             const InputType* input,
                             OutputType* output_rowwise,
                             OutputType* output_colwise,
                             fp8e8m0* output_scales_rowwise,
                             fp8e8m0* output_scales_colwise,
                             const size_t rows,
                             const size_t cols,
                             const size_t scales_stride_rowwise,
                             const size_t scales_stride_colwise) {
    const size_t tile_size_Y = 32;
    const size_t tile_size_X = 32;
    const size_t tiles_num_Y = (rows + tile_size_Y - 1) / tile_size_Y;
    const size_t tiles_num_X = (cols + tile_size_X - 1) / tile_size_X;

    #pragma omp parallel for collapse(2) proc_bind(spread)
    for (size_t tile_Y = 0; tile_Y < tiles_num_Y; ++tile_Y) {
        for (size_t tile_X = 0; tile_X < tiles_num_X; ++tile_X) {
            const size_t i_min = tile_Y * tile_size_Y;
            const size_t i_max = std::min(i_min + tile_size_Y, rows);
            const size_t j_min = tile_X * tile_size_X;
            const size_t j_max = std::min(j_min + tile_size_X, cols);

            float block_amax = 0.0f;
            for (size_t i = i_min; i < i_max; ++i) {
                for (size_t j = j_min; j < j_max; ++j) {
                    const size_t idx = i * cols + j;
                    block_amax = std::max(block_amax, std::abs(static_cast<float>(input[idx])));
                }
            }

            const fp8e8m0 biased_exponent =
                float_to_e8m0(block_amax * Quantized_Limits<OutputType>::max_reciprocal());
            const float scale_reciprocal = exp2f_rcp(biased_exponent);

            if (rowwise) {
                for (size_t i = i_min; i < i_max; ++i) {
                    output_scales_rowwise[i * scales_stride_rowwise + tile_X] = biased_exponent;
                    for (size_t j = j_min; j < j_max; ++j) {
                        const size_t idx = i * cols + j;
                        output_rowwise[idx] =
                            static_cast<OutputType>(static_cast<float>(input[idx]) *
                                                    scale_reciprocal);
                    }
                }
            }

            if (colwise) {
                for (size_t j = j_min; j < j_max; ++j) {
                    output_scales_colwise[tile_Y * scales_stride_colwise + j] = biased_exponent;
                    for (size_t i = i_min; i < i_max; ++i) {
                        const size_t idx = i * cols + j;
                        output_colwise[idx] =
                            static_cast<OutputType>(static_cast<float>(input[idx]) *
                                                    scale_reciprocal);
                    }
                }
            }
        }
    }
}

/**
 * Scaling along single dimension (either rows or columns)
 * Produces one set of output data and the corresponding data of the fused operation (dbias):
 * 1) Scaled rows + row-wise scaling factors
 *       OR
 * 2) Scaled columns + column-wise scaling factors
 */

template <typename InputType, typename OutputType>
void performTest_x1(const ProcessingMethod processing_method,
                    float (*OP)(const float),
                    const std::vector<size_t>& shape,
                    const bool rowwise,
                    const bool colwise,
                    InputsFillCase fill_case) {
    using namespace test;
    using EncodingType = fp32;
    DType itype = TypeInfo<InputType>::dtype;
    DType otype = TypeInfo<OutputType>::dtype;

    const size_t rows = first_dimension(shape);
    const size_t cols = last_dimension(shape);

    if (shape.size() < 2 && colwise) {
      GTEST_SKIP();
    }

    const size_t block_size_rows = rowwise ? 1 : 32;
    const size_t block_size_cols = colwise ? 1 : 32;

    const std::array<size_t,4> scale_dims = get_scale_tensor_dims(rows, cols, block_size_rows,
                                                                  block_size_cols);

    const size_t unpadded_blocks_Y = scale_dims[0];
    const size_t unpadded_blocks_X = scale_dims[1];
    const size_t blocks_Y = scale_dims[2];
    const size_t blocks_X = scale_dims[3];
    const size_t scales_stride = blocks_X;

    Tensor input("input", shape, itype);
    Tensor grad("grad", shape, itype);
    Tensor output_c("output_c", shape, otype, rowwise, colwise, NVTE_MXFP8_1D_SCALING);
    Tensor output_dbias("output_dbias", std::vector<size_t>{ cols }, itype);

    std::unique_ptr<OutputType[]> ref_output_c = std::make_unique<OutputType[]>(rows * cols);
    std::unique_ptr<InputType[]> ref_output_dbias = std::make_unique<InputType[]>(cols);
    std::unique_ptr<fp8e8m0[]> ref_output_scales = std::make_unique<fp8e8m0[]>(blocks_Y * blocks_X);

    fillCase<EncodingType>(&input, fill_case);
    fillUniform(&grad);

    Tensor workspace;
    switch (processing_method) {
        case ProcessingMethod::CAST_ONLY: {
            nvte_quantize(input.data(), output_c.data(), 0);
            break;
        }
        case ProcessingMethod::CAST_DBIAS: {
            nvte_quantize_dbias(grad.data(),
                                output_c.data(),
                                output_dbias.data(),
                                workspace.data(),
                                0);
            workspace = Tensor("workspace", workspace.rowwise_shape(), workspace.dtype());

            nvte_quantize_dbias(grad.data(),
                                output_c.data(),
                                output_dbias.data(),
                                workspace.data(),
                                0);
            break;
        }
        case ProcessingMethod::CAST_DBIAS_DACT: {
            auto nvte_quantize_dbias_dact = &nvte_quantize_dbias_dgelu;
            if (OP == &dsilu)       { nvte_quantize_dbias_dact = &nvte_quantize_dbias_dsilu; }
            else if (OP == &drelu)  { nvte_quantize_dbias_dact = &nvte_quantize_dbias_drelu; }
            else if (OP == &dqgelu) { nvte_quantize_dbias_dact = &nvte_quantize_dbias_dqgelu; }
            else if (OP == &dsrelu) { nvte_quantize_dbias_dact = &nvte_quantize_dbias_dsrelu; }

            nvte_quantize_dbias_dact(grad.data(),
                                     input.data(),
                                     output_c.data(),
                                     output_dbias.data(),
                                     workspace.data(),
                                     0);
            workspace = Tensor("workspace", workspace.rowwise_shape(), workspace.dtype());

            nvte_quantize_dbias_dact(grad.data(),
                                     input.data(),
                                     output_c.data(),
                                     output_dbias.data(),
                                     workspace.data(),
                                     0);
            break;
        }
        case ProcessingMethod::CAST_DACT: {
            auto nvte_dact = &nvte_dgelu;
            if (OP == &dsilu)       { nvte_dact = &nvte_dsilu; }
            else if (OP == &drelu)  { nvte_dact = &nvte_drelu; }
            else if (OP == &dqgelu) { nvte_dact = &nvte_dqgelu; }
            else if (OP == &dsrelu) { nvte_dact = &nvte_dsrelu; }

            nvte_dact(grad.data(), input.data(), output_c.data(), 0);
            break;
        }
        case ProcessingMethod::CAST_ACT: {
            auto nvte_act = &nvte_gelu;
            if (OP == &silu)       { nvte_act = &nvte_silu; }
            else if (OP == &relu)  { nvte_act = &nvte_relu; }
            else if (OP == &qgelu) { nvte_act = &nvte_qgelu; }
            else if (OP == &srelu) { nvte_act = &nvte_srelu; }

            nvte_act(input.data(), output_c.data(), 0);
            break;
        }
    }

    cudaDeviceSynchronize();
    auto err = cudaGetLastError();
    ASSERT_EQ(err, cudaSuccess) << cudaGetErrorString(err);

    compute_ref<InputType, OutputType>(processing_method,
                                       OP,
                                       rowwise,
                                       colwise,
                                       input.rowwise_cpu_dptr<InputType>(),
                                       grad.rowwise_cpu_dptr<InputType>(),
                                       ref_output_c.get(),
                                       ref_output_c.get(),
                                       ref_output_scales.get(),
                                       ref_output_scales.get(),
                                       ref_output_dbias.get(),
                                       rows,
                                       cols,
                                       scales_stride,
                                       scales_stride);

    const uint8_t * const gpu_scales_ptr = rowwise
                                           ? output_c.rowwise_cpu_scale_inv_ptr<fp8e8m0>()
                                           : output_c.columnwise_cpu_scale_inv_ptr<fp8e8m0>();

    const size_t scale_diff_abs_tolerance = 0;
    const double abs_tolerable_mismatches_limit = 0.0;
    const double rel_tolerable_mismatches_limit = 0.0;

    size_t mismatches_scales = 0;

    compare_scaling_factors("scales", gpu_scales_ptr, ref_output_scales.get(),
                            unpadded_blocks_Y, unpadded_blocks_X, scales_stride,
                            mismatches_scales,
                            scale_diff_abs_tolerance,
                            abs_tolerable_mismatches_limit,
                            rel_tolerable_mismatches_limit);

    const size_t mismatches_elts = 32 * mismatches_scales;
    auto [atol, rtol] = getTolerances(otype);
    compareResults("output_c", output_c, ref_output_c.get(), rowwise, atol, rtol, true, mismatches_elts);

    if (processing_method == ProcessingMethod::CAST_DBIAS
        || processing_method == ProcessingMethod::CAST_DBIAS_DACT)
    {
        auto [atol_dbias, rtol_dbias] = getTolerances(itype);
        if (itype == DType::kFloat32) {
            atol_dbias = 1e-4;
            rtol_dbias *= sqrt(static_cast<double>(rows)) ;
        } else {
            rtol_dbias *= 4;
        }
        compareResults("output_dbias", output_dbias, ref_output_dbias.get(), true, atol_dbias, rtol_dbias);
    }
}

/**
 * Scaling along both dimensions (rows and columns)
 * Produces two sets of scaled output data and the corresponding data of the fused operation (dbias):
 * 1) Scaled rows + row-wise scaling factors
 *      AND
 * 2) Scaled columns + column-wise scaling factors
 */
template <typename InputType, typename OutputType>
void performTest_x2(const ProcessingMethod processing_method,
                    float (*OP)(const float),
                    const std::vector<size_t>& shape,
                    const size_t block_size_rows,
                    const size_t block_size_cols,
                    InputsFillCase fill_case) {
    using namespace test;
    using EncodingType = fp32;
    DType itype = TypeInfo<InputType>::dtype;
    DType otype = TypeInfo<OutputType>::dtype;

    if (shape.size() < 2) {
      GTEST_SKIP();
    }

    const size_t rows = first_dimension(shape);
    const size_t cols = last_dimension(shape);

    const std::array<size_t,4> scale_dims_rowwise = get_scale_tensor_dims(rows, cols, 1, 32);
    const std::array<size_t,4> scale_dims_colwise = get_scale_tensor_dims(rows, cols, 32, 1);

    const size_t unpadded_blocks_Y_rowwise = scale_dims_rowwise[0];
    const size_t unpadded_blocks_X_rowwise = scale_dims_rowwise[1];
    const size_t blocks_Y_rowwise = scale_dims_rowwise[2];
    const size_t blocks_X_rowwise = scale_dims_rowwise[3];
    const size_t scales_stride_rowwise = blocks_X_rowwise;

    const size_t unpadded_blocks_Y_colwise = scale_dims_colwise[0];
    const size_t unpadded_blocks_X_colwise = scale_dims_colwise[1];
    const size_t blocks_Y_colwise = scale_dims_colwise[2];
    const size_t blocks_X_colwise = scale_dims_colwise[3];
    const size_t scales_stride_colwise = blocks_X_colwise;

    Tensor input("input", shape, itype);
    Tensor grad("grad", shape, itype);
    Tensor output("output", shape, otype, true, true, NVTE_MXFP8_1D_SCALING);
    Tensor output_dbias("output_dbias", std::vector<size_t>{ cols }, itype);

    std::unique_ptr<OutputType[]> ref_output_c_rowwise = std::make_unique<OutputType[]>(rows * cols);
    std::unique_ptr<OutputType[]> ref_output_c_colwise = std::make_unique<OutputType[]>(rows * cols);
    std::unique_ptr<fp8e8m0[]> ref_scales_rowwise = std::make_unique<fp8e8m0[]>(blocks_Y_rowwise * blocks_X_rowwise);
    std::unique_ptr<fp8e8m0[]> ref_scales_colwise = std::make_unique<fp8e8m0[]>(blocks_Y_colwise * blocks_X_colwise);
    std::unique_ptr<InputType[]> ref_output_dbias = std::make_unique<InputType[]>(cols);

    fillCase<EncodingType>(&input, fill_case);
    fillUniform(&grad);

    Tensor workspace;
    switch (processing_method) {
        case ProcessingMethod::CAST_ONLY: {
            nvte_quantize(input.data(), output.data(), 0);
            break;
        }
        case ProcessingMethod::CAST_DBIAS: {
            nvte_quantize_dbias(grad.data(),
                                output.data(),
                                output_dbias.data(),
                                workspace.data(),
                                0);
            workspace = Tensor("workspace", workspace.rowwise_shape(), workspace.dtype());

            nvte_quantize_dbias(grad.data(),
                                output.data(),
                                output_dbias.data(),
                                workspace.data(),
                                0);
            break;
        }
        case ProcessingMethod::CAST_DBIAS_DACT: {
            auto nvte_quantize_dbias_dact = &nvte_quantize_dbias_dgelu;
            if (OP == &dsilu)       { nvte_quantize_dbias_dact = &nvte_quantize_dbias_dsilu; }
            else if (OP == &drelu)  { nvte_quantize_dbias_dact = &nvte_quantize_dbias_drelu; }
            else if (OP == &dqgelu) { nvte_quantize_dbias_dact = &nvte_quantize_dbias_dqgelu; }
            else if (OP == &dsrelu) { nvte_quantize_dbias_dact = &nvte_quantize_dbias_dsrelu; }

            nvte_quantize_dbias_dact(grad.data(),
                                     input.data(),
                                     output.data(),
                                     output_dbias.data(),
                                     workspace.data(),
                                     0);
            workspace = Tensor("workspace", workspace.rowwise_shape(), workspace.dtype());

            nvte_quantize_dbias_dact(grad.data(),
                                     input.data(),
                                     output.data(),
                                     output_dbias.data(),
                                     workspace.data(),
                                     0);
            break;
        }
        case ProcessingMethod::CAST_DACT: {
            auto nvte_dact = &nvte_dgelu;
            if (OP == &dsilu)       { nvte_dact = &nvte_dsilu; }
            else if (OP == &drelu)  { nvte_dact = &nvte_drelu; }
            else if (OP == &dqgelu) { nvte_dact = &nvte_dqgelu; }
            else if (OP == &dsrelu) { nvte_dact = &nvte_dsrelu; }

            nvte_dact(grad.data(), input.data(), output.data(), 0);
            break;
        }
        case ProcessingMethod::CAST_ACT: {
            auto nvte_act = &nvte_gelu;
            if (OP == &silu)       { nvte_act = &nvte_silu; }
            else if (OP == &relu)  { nvte_act = &nvte_relu; }
            else if (OP == &qgelu) { nvte_act = &nvte_qgelu; }
            else if (OP == &srelu) { nvte_act = &nvte_srelu; }

            nvte_act(input.data(), output.data(), 0);
            break;
        }
    }

    cudaDeviceSynchronize();
    auto err = cudaGetLastError();
    ASSERT_EQ(err, cudaSuccess) << cudaGetErrorString(err);

    compute_ref<InputType, OutputType>(processing_method,
                                       OP,
                                       true,
                                       true,
                                       input.rowwise_cpu_dptr<InputType>(),
                                       grad.rowwise_cpu_dptr<InputType>(),
                                       ref_output_c_rowwise.get(),
                                       ref_output_c_colwise.get(),
                                       ref_scales_rowwise.get(),
                                       ref_scales_colwise.get(),
                                       ref_output_dbias.get(),
                                       rows,
                                       cols,
                                       scales_stride_rowwise,
                                       scales_stride_colwise);

    const size_t scale_diff_abs_tolerance = 0;
    const double abs_tolerable_mismatches_limit = 0.0;
    const double rel_tolerable_mismatches_limit = 0.0;

    size_t mismatches_scales_rowwise = 0;
    compare_scaling_factors("scales_rowwise", output.rowwise_cpu_scale_inv_ptr<fp8e8m0>(),
                            ref_scales_rowwise.get(), unpadded_blocks_Y_rowwise,
                            unpadded_blocks_X_rowwise, scales_stride_rowwise,
                            mismatches_scales_rowwise,
                            scale_diff_abs_tolerance,
                            abs_tolerable_mismatches_limit,
                            rel_tolerable_mismatches_limit);

    size_t mismatches_scales_colwise = 0;
    compare_scaling_factors("scales_colwise", output.columnwise_cpu_scale_inv_ptr<fp8e8m0>(),
                            ref_scales_colwise.get(), unpadded_blocks_Y_colwise,
                            unpadded_blocks_X_colwise, scales_stride_colwise,
                            mismatches_scales_colwise,
                            scale_diff_abs_tolerance,
                            abs_tolerable_mismatches_limit,
                            rel_tolerable_mismatches_limit);

    const size_t mismatches_elts_rowwise = 32 * mismatches_scales_rowwise;
    const size_t mismatches_elts_colwise = 32 * mismatches_scales_colwise;

    auto [atol, rtol] = getTolerances(otype);
    compareResults("output_c_rowwise", output, ref_output_c_rowwise.get(), true, atol, rtol, true, mismatches_elts_rowwise);
    compareResults("output_c_colwise", output, ref_output_c_colwise.get(), false, atol, rtol, true, mismatches_elts_colwise);

    if (processing_method == ProcessingMethod::CAST_DBIAS
        || processing_method == ProcessingMethod::CAST_DBIAS_DACT)
    {
        auto [atol_dbias, rtol_dbias] = getTolerances(itype);
        if (itype == DType::kFloat32) {
            atol_dbias = 1e-4;
            rtol_dbias *= sqrt(static_cast<double>(rows)) ;
        } else {
            rtol_dbias *= 4;
        }
        compareResults("output_dbias", output_dbias, ref_output_dbias.get(), true, atol_dbias, rtol_dbias);
    }
}

template <typename InputType, typename OutputType>
void performTest_2d_quantize(const std::vector<size_t>& shape,
                             const MXFP82DScalingDirection scaling_direction,
                             InputsFillCase fill_case) {
    using namespace test;
    using EncodingType = fp32;
    DType itype = TypeInfo<InputType>::dtype;
    DType otype = TypeInfo<OutputType>::dtype;

    if (shape.size() < 2) {
      GTEST_SKIP();
    }

    const size_t rows = first_dimension(shape);
    const size_t cols = last_dimension(shape);

    const bool rowwise = scaling_direction != MXFP82DScalingDirection::ColwiseOnly;
    const bool colwise = scaling_direction != MXFP82DScalingDirection::RowwiseOnly;

    const std::array<size_t,4> scale_dims_rowwise = get_scale_tensor_dims(rows, cols, 1, 32);
    const std::array<size_t,4> scale_dims_colwise = get_scale_tensor_dims(rows, cols, 32, 1);

    const size_t unpadded_blocks_Y_rowwise = scale_dims_rowwise[0];
    const size_t unpadded_blocks_X_rowwise = scale_dims_rowwise[1];
    const size_t blocks_Y_rowwise = scale_dims_rowwise[2];
    const size_t blocks_X_rowwise = scale_dims_rowwise[3];
    const size_t scales_stride_rowwise = blocks_X_rowwise;

    const size_t unpadded_blocks_Y_colwise = scale_dims_colwise[0];
    const size_t unpadded_blocks_X_colwise = scale_dims_colwise[1];
    const size_t blocks_Y_colwise = scale_dims_colwise[2];
    const size_t blocks_X_colwise = scale_dims_colwise[3];
    const size_t scales_stride_colwise = blocks_X_colwise;

    Tensor input("input", shape, itype);
    Tensor output("output", shape, otype, rowwise, colwise, NVTE_MXFP8_1D_SCALING);

    std::unique_ptr<OutputType[]> ref_output_rowwise = std::make_unique<OutputType[]>(rows * cols);
    std::unique_ptr<OutputType[]> ref_output_colwise = std::make_unique<OutputType[]>(rows * cols);
    std::unique_ptr<fp8e8m0[]> ref_scales_rowwise =
        std::make_unique<fp8e8m0[]>(blocks_Y_rowwise * blocks_X_rowwise);
    std::unique_ptr<fp8e8m0[]> ref_scales_colwise =
        std::make_unique<fp8e8m0[]>(blocks_Y_colwise * blocks_X_colwise);
    std::fill_n(ref_scales_rowwise.get(), blocks_Y_rowwise * blocks_X_rowwise, 0);
    std::fill_n(ref_scales_colwise.get(), blocks_Y_colwise * blocks_X_colwise, 0);

    fillCase<EncodingType>(&input, fill_case);

    QuantizationConfigWrapper quant_config;
    quant_config.set_mxfp8_2d_quantization(true);
    nvte_quantize_v2(input.data(), output.data(), quant_config, 0);

    cudaDeviceSynchronize();
    auto err = cudaGetLastError();
    ASSERT_EQ(err, cudaSuccess) << cudaGetErrorString(err);

    compute_ref_2d_quantize<InputType, OutputType>(
        rowwise,
        colwise,
        input.rowwise_cpu_dptr<InputType>(),
        ref_output_rowwise.get(),
        ref_output_colwise.get(),
        ref_scales_rowwise.get(),
        ref_scales_colwise.get(),
        rows,
        cols,
        scales_stride_rowwise,
        scales_stride_colwise);

    const size_t scale_diff_abs_tolerance = 0;
    const double abs_tolerable_mismatches_limit = 0.0;
    const double rel_tolerable_mismatches_limit = 0.0;

    auto [atol, rtol] = getTolerances(otype);

    if (rowwise) {
        size_t mismatches_scales_rowwise = 0;
        compare_scaling_factors("scales_rowwise", output.rowwise_cpu_scale_inv_ptr<fp8e8m0>(),
                                ref_scales_rowwise.get(), unpadded_blocks_Y_rowwise,
                                unpadded_blocks_X_rowwise, scales_stride_rowwise,
                                mismatches_scales_rowwise,
                                scale_diff_abs_tolerance,
                                abs_tolerable_mismatches_limit,
                                rel_tolerable_mismatches_limit);
        compareResults("output_rowwise", output, ref_output_rowwise.get(), true, atol, rtol, true);
    }

    if (colwise) {
        size_t mismatches_scales_colwise = 0;
        compare_scaling_factors("scales_colwise", output.columnwise_cpu_scale_inv_ptr<fp8e8m0>(),
                                ref_scales_colwise.get(), unpadded_blocks_Y_colwise,
                                unpadded_blocks_X_colwise, scales_stride_colwise,
                                mismatches_scales_colwise,
                                scale_diff_abs_tolerance,
                                abs_tolerable_mismatches_limit,
                                rel_tolerable_mismatches_limit);
        compareResults("output_colwise", output, ref_output_colwise.get(), false, atol, rtol, true);
    }
}

std::vector<std::vector<size_t>> matrix_sizes = {
    {1, 16},
    {16, 48},
    {128, 128},
    {993, 512},
    {1024},
    {8, 32, 1024},
    {16, 8, 4, 512},
    {8192, 7168},
};

std::vector<std::vector<size_t>> matrix_sizes_2d_quantize = {
    {1, 16},
    {16, 48},
    {65, 80},
    {127, 400},
    {128, 128},
    {993, 512},
    {8, 32, 1024},
    {16, 8, 4, 512},
    {8192, 7168},
};

std::vector<std::pair<size_t, size_t>> block_sizes = {
    {1, 32},
    {32, 1},
    {32, 32},
};

std::vector<InputsFillCase> input_scenarios = {
    InputsFillCase::uniform,
    // InputsFillCase::zeros,
    // InputsFillCase::zero_to_minNorm,
    // InputsFillCase::minNorm_to_maxNorm,
    // InputsFillCase::maxNorm_to_inf
};

std::vector<ProcessingMethod> processing_methods = {
    ProcessingMethod::CAST_ONLY,
    ProcessingMethod::CAST_DBIAS,
    ProcessingMethod::CAST_DBIAS_DACT,
    ProcessingMethod::CAST_DACT,
    ProcessingMethod::CAST_ACT,
};

std::vector<MXFP82DScalingDirection> scaling_directions_2d_quantize = {
    MXFP82DScalingDirection::RowwiseOnly,
    MXFP82DScalingDirection::ColwiseOnly,
    MXFP82DScalingDirection::Bidirectional,
};

std::vector<ActivationType> Activation_types = {
    ActivationType::Identity,
    ActivationType::GeLU,
    ActivationType::SiLU,
    ActivationType::ReLU,
    ActivationType::QGeLU,
    ActivationType::SReLU,
};

class FusedCastMXFP8TestSuite : public ::testing::TestWithParam
    <std::tuple<ProcessingMethod,
                ActivationType,
                std::vector<size_t>,
                std::pair<size_t, size_t>,
                transformer_engine::DType,
                transformer_engine::DType,
                InputsFillCase>> {};

class CastMXFP82DQuantizationTestSuite : public ::testing::TestWithParam
    <std::tuple<MXFP82DScalingDirection,
                std::vector<size_t>,
                transformer_engine::DType,
                transformer_engine::DType,
                InputsFillCase>> {};

TEST_P(FusedCastMXFP8TestSuite, TestFusedCastMXFP8) {
    // Skip tests for pre-Blackwell architectures
    if (getDeviceComputeCapability() < blackwellComputeCapability) {
        GTEST_SKIP();
    }

    using namespace transformer_engine;
    using namespace test;

    const ProcessingMethod processing_method = std::get<0>(GetParam());
    const ActivationType Act_type = std::get<1>(GetParam());
    const auto matrix_size = std::get<2>(GetParam());
    const auto block_size = std::get<3>(GetParam());
    const DType input_type = std::get<4>(GetParam());
    const DType output_type = std::get<5>(GetParam());
    const InputsFillCase fill_case = std::get<6>(GetParam());

    // Skips non Act tests if the Activation type is not an identity
    if ((processing_method == ProcessingMethod::CAST_ONLY || processing_method == ProcessingMethod::CAST_DBIAS)
        && Act_type != ActivationType::Identity) {
        GTEST_SKIP();
    }
    // Skips Act tests if the Activation is an identity
    if ((processing_method == ProcessingMethod::CAST_DBIAS_DACT
        || processing_method == ProcessingMethod::CAST_DACT
        || processing_method == ProcessingMethod::CAST_ACT) && (Act_type == ActivationType::Identity)) {
        GTEST_SKIP();
    }

    const bool rowwise = block_size.second != 1;
    const bool colwise = block_size.first != 1;
    if (processing_method == ProcessingMethod::CAST_ACT) {
        // Forward activations
        auto OP = &identity;
        switch (Act_type) {
            case ActivationType::GeLU: OP = &gelu; break;
            case ActivationType::SiLU: OP = &silu; break;
            case ActivationType::ReLU: OP = &relu; break;
            case ActivationType::QGeLU: OP = &qgelu; break;
            case ActivationType::SReLU: OP = &srelu; break;
        }

        TRANSFORMER_ENGINE_TYPE_SWITCH_FP16_FP32_ONLY(input_type, InputType,
            TRANSFORMER_ENGINE_TYPE_SWITCH_FP8_ONLY(output_type, OutputType,
                if (block_size.first == 1 || block_size.second == 1) {
                    performTest_x1<InputType, OutputType>(
                        processing_method, OP, matrix_size,
                        rowwise, colwise, fill_case);
                } else {
                    performTest_x2<InputType, OutputType>(
                        processing_method, OP, matrix_size,
                        block_size.first, block_size.second, fill_case);
                }
            );
        );
    } else {
        auto OP = &identity;
        switch (Act_type) {
            case ActivationType::GeLU: OP = &dgelu; break;
            case ActivationType::SiLU: OP = &dsilu; break;
            case ActivationType::ReLU: OP = &drelu; break;
            case ActivationType::QGeLU: OP = &dqgelu; break;
            case ActivationType::SReLU: OP = &dsrelu; break;
        }
        TRANSFORMER_ENGINE_TYPE_SWITCH_FP16_FP32_ONLY(input_type, InputType,
            TRANSFORMER_ENGINE_TYPE_SWITCH_FP8_ONLY(output_type, OutputType,
                if (block_size.first == 1 || block_size.second == 1) {
                    performTest_x1<InputType, OutputType>(
                        processing_method, OP, matrix_size,
                        rowwise, colwise, fill_case);
                } else {
                    performTest_x2<InputType, OutputType>(
                        processing_method, OP, matrix_size,
                        block_size.first, block_size.second, fill_case);
                }
            );
        );
    }
}

TEST_P(CastMXFP82DQuantizationTestSuite, TestCastMXFP82DQuantization) {
    // Skip tests for pre-Blackwell architectures
    if (getDeviceComputeCapability() < blackwellComputeCapability) {
        GTEST_SKIP();
    }

    using namespace transformer_engine;
    using namespace test;

    const auto scaling_direction = std::get<0>(GetParam());
    const auto matrix_size = std::get<1>(GetParam());
    const DType input_type = std::get<2>(GetParam());
    const DType output_type = std::get<3>(GetParam());
    const InputsFillCase fill_case = std::get<4>(GetParam());

    TRANSFORMER_ENGINE_TYPE_SWITCH_FP16_FP32_ONLY(input_type, InputType,
        TRANSFORMER_ENGINE_TYPE_SWITCH_FP8_ONLY(output_type, OutputType,
            performTest_2d_quantize<InputType, OutputType>(
                matrix_size, scaling_direction, fill_case);
        );
    );
}

std::string to_string(const ProcessingMethod method) {
    switch (method) {
        case ProcessingMethod::CAST_ONLY:       return "CAST_ONLY";
        case ProcessingMethod::CAST_DBIAS:      return "CAST_DBIAS";
        case ProcessingMethod::CAST_DBIAS_DACT: return "CAST_DBIAS_DACT";
        case ProcessingMethod::CAST_DACT:       return "CAST_DACT";
        case ProcessingMethod::CAST_ACT:        return "CAST_ACT";
        default: return "";
    }
}

std::string to_string(const ActivationType Act_type) {
    switch (Act_type) {
        case ActivationType::Identity:  return "Identity";
        case ActivationType::GeLU:      return "GeLU";
        case ActivationType::SiLU:      return "SiLU";
        case ActivationType::ReLU:      return "ReLU";
        case ActivationType::QGeLU:     return "QGeLU";
        case ActivationType::SReLU:     return "SReLU";
        default: return "";
    }
}

std::string to_string(const MXFP82DScalingDirection scaling_direction) {
    switch (scaling_direction) {
        case MXFP82DScalingDirection::RowwiseOnly:   return "RowwiseOnly";
        case MXFP82DScalingDirection::ColwiseOnly:   return "ColwiseOnly";
        case MXFP82DScalingDirection::Bidirectional: return "Bidirectional";
        default: return "";
    }
}

std::string test_name_generator(
    const testing::TestParamInfo<FusedCastMXFP8TestSuite::ParamType>& info) {
    std::string name = to_string(std::get<0>(info.param)) + "X" +
        to_string(std::get<1>(info.param));
    const auto& shape = std::get<2>(info.param);
    for ( const auto& s: shape) {
        name += "X" + std::to_string(s);
    }
    name += "X" + std::to_string(std::get<3>(info.param).first) +
            "X" + std::to_string(std::get<3>(info.param).second) +
            "X" + test::typeName(std::get<4>(info.param)) +
            "X" + test::typeName(std::get<5>(info.param)) +
            "X" + test::caseName(std::get<6>(info.param));
    return name;
}

std::string mxfp8_2d_quantization_test_name_generator(
    const testing::TestParamInfo<CastMXFP82DQuantizationTestSuite::ParamType>& info) {
    std::string name = to_string(std::get<0>(info.param));
    const auto& shape = std::get<1>(info.param);
    for ( const auto& s: shape) {
        name += "X" + std::to_string(s);
    }
    name += "X" + test::typeName(std::get<2>(info.param)) +
            "X" + test::typeName(std::get<3>(info.param)) +
            "X" + test::caseName(std::get<4>(info.param));
    return name;
}

}  // namespace

// Test cases with only cast kernels
INSTANTIATE_TEST_SUITE_P(
    OperatorTest_FusedCastMXFP8_CastOnly,
    FusedCastMXFP8TestSuite,
    ::testing::Combine(
        ::testing::Values(ProcessingMethod::CAST_ONLY),
        ::testing::Values(ActivationType::Identity),
        ::testing::ValuesIn(matrix_sizes),
        ::testing::ValuesIn(block_sizes),
        ::testing::Values(DType::kFloat32, DType::kBFloat16, DType::kFloat16),
        ::testing::Values(DType::kFloat8E4M3, DType::kFloat8E5M2),
        ::testing::ValuesIn(input_scenarios)),
    test_name_generator);

// Test cases for MXFP8 2D block scaling through the common C++ API.
INSTANTIATE_TEST_SUITE_P(
    OperatorTest_CastMXFP8_2DQuantization,
    CastMXFP82DQuantizationTestSuite,
    ::testing::Combine(
        ::testing::ValuesIn(scaling_directions_2d_quantize),
        ::testing::ValuesIn(matrix_sizes_2d_quantize),
        ::testing::Values(DType::kFloat32, DType::kBFloat16),
        ::testing::Values(DType::kFloat8E4M3, DType::kFloat8E5M2),
        ::testing::Values(InputsFillCase::uniform)),
    mxfp8_2d_quantization_test_name_generator);

// Test cases with varying matrix shapes and block shapes
INSTANTIATE_TEST_SUITE_P(
    OperatorTest_FusedCastMXFP8_Sizes,
    FusedCastMXFP8TestSuite,
    ::testing::Combine(
        ::testing::ValuesIn(processing_methods),
        ::testing::ValuesIn(Activation_types),
        ::testing::ValuesIn(matrix_sizes),
        ::testing::ValuesIn(block_sizes),
        ::testing::Values(DType::kBFloat16),
        ::testing::Values(DType::kFloat8E4M3),
        ::testing::ValuesIn(input_scenarios)),
    test_name_generator);

// Exceptional inputs, on one small aligned shape.
//
// maxNorm_to_inf is the only scenario that drives a block amax to Inf or NaN,
// which is where the E8M0 encoding stops being a plain exponent subtraction:
// code 254 needs a subnormal reciprocal and 255 is NaN, and both have to be
// supplied rather than derived.  Two bugs of exactly that kind reached review,
// so keep at least one shape covering it.
//
// 256x512 is chosen so the cast-only path reaches the register-resident
// kernels: rows % 32 == 0 and cols % 256 == 0 for the bidimensional one,
// cols % 128 == 0 for the rowwise one.  Both block sizes are listed so the
// rowwise-only and bidimensional kernels are each exercised.
INSTANTIATE_TEST_SUITE_P(
    OperatorTest_FusedCastMXFP8_ExceptionalInputs,
    FusedCastMXFP8TestSuite,
    ::testing::Combine(
        ::testing::ValuesIn(processing_methods),
        ::testing::ValuesIn(Activation_types),
        ::testing::Values(std::vector<size_t>{256, 512}),
        ::testing::Values(std::pair<size_t, size_t>{1, 32}, std::pair<size_t, size_t>{32, 32}),
        ::testing::Values(DType::kBFloat16),
        ::testing::Values(DType::kFloat8E4M3, DType::kFloat8E5M2),
        ::testing::Values(InputsFillCase::maxNorm_to_inf)),
    test_name_generator);

// Test cases with varying dtypes
INSTANTIATE_TEST_SUITE_P(
    OperatorTest_FusedCastMXFP8_Dtypes,
    FusedCastMXFP8TestSuite,
    ::testing::Combine(
        ::testing::ValuesIn(processing_methods),
        ::testing::ValuesIn(Activation_types),
        ::testing::Values(std::vector<size_t>{256, 384}),
        ::testing::Values(std::pair<size_t, size_t>{32, 32}),
        ::testing::Values(DType::kFloat32, DType::kBFloat16, DType::kFloat16),
        ::testing::Values(DType::kFloat8E4M3, DType::kFloat8E5M2),
        ::testing::ValuesIn(input_scenarios)),
    test_name_generator);

// ============================================================================
// Swizzled-scales cast-only tests
//
// Validate the WITH_GEMM_SWIZZLED_SCALES=true code path added by the
// CastTraitsSwizzle port. The specialized kernel dispatches to
// CastTraitsSwizzle<..., kCacheColwise=true, kSwizzled=true> whenever the
// output tensor has set_with_gemm_swizzled_scales(true), producing scales
// directly in GEMM-swizzled layout.
//
// Reference construction: run the well-tested linear-scale path, then apply
// nvte_swizzle_scaling_factors (independently tested by SwizzleTestSuite) to
// transform the linear scales into the swizzled layout. Byte-compare the
// direct swizzled cast output against this reference for both scale tensors
// and the FP8 output data itself.
//
// Pass criteria per test:
//   1. FP8 rowwise data byte-identical between linear and swizzled paths.
//   2. FP8 colwise data byte-identical between linear and swizzled paths.
//   3. Swizzled rowwise scale bytes match linear->swizzle reference.
//   4. Swizzled colwise scale bytes match linear->swizzle reference.
//   5. Rowwise-only FP8 data and swizzled scales match the same reference.
//   6. No CUDA errors from any launch.
// ============================================================================

class SwizzledScalesFusedCastMXFP8TestSuite : public ::testing::TestWithParam<
    std::tuple<std::vector<size_t>,
               transformer_engine::DType,
               transformer_engine::DType>> {};

TEST_P(SwizzledScalesFusedCastMXFP8TestSuite, TestSwizzledCastMXFP8) {
    if (getDeviceComputeCapability() < blackwellComputeCapability) {
        GTEST_SKIP();
    }

    using namespace transformer_engine;
    using namespace test;

    const auto shape = std::get<0>(GetParam());
    const DType itype = std::get<1>(GetParam());
    const DType otype = std::get<2>(GetParam());

    // BIDIMENSIONAL scaling needs a 2D+ input.
    if (shape.size() < 2) {
        GTEST_SKIP();
    }

    const size_t rows = first_dimension(shape);
    const size_t cols = last_dimension(shape);
    const size_t out_bytes = rows * cols;  // fp8 = 1 byte/elem

    // Input filled with the same values for all casts.
    Tensor input("input", shape, itype);
    fillUniform(&input);

    // Target: swizzled-scale cast. Dispatcher routes to
    // CastTraitsSwizzle<..., kCacheColwise=true, kSwizzled=true> on kernel #3.
    Tensor output_swizzled("output_swizzled", shape, otype, true, true, NVTE_MXFP8_1D_SCALING);
    output_swizzled.set_with_gemm_swizzled_scales(true);
    nvte_quantize(input.data(), output_swizzled.data(), 0);

    // Rowwise-only activations take the pointer-based cast-only kernel. This
    // directly exercises its WITH_GEMM_SWIZZLED_SCALES trait specialization
    // for shapes whose column count is a multiple of 128.
    Tensor output_rowwise_swizzled("output_rowwise_swizzled", shape, otype,
                                   /*rowwise=*/true, /*colwise=*/false,
                                   NVTE_MXFP8_1D_SCALING);
    output_rowwise_swizzled.set_with_gemm_swizzled_scales(true);
    nvte_quantize(input.data(), output_rowwise_swizzled.data(), 0);

    cudaDeviceSynchronize();
    ASSERT_EQ(cudaGetLastError(), cudaSuccess) << "swizzled-scale nvte_quantize failed";

    // Reference construction: nvte_swizzle_scaling_factors accepts tensors with
    // exactly one scale direction, so we build the rowwise and colwise references
    // independently. Each is a single-direction linear cast followed by a
    // single-direction swizzle transform, using the same input as the target.
    // MXFP8 is a deterministic per-direction operation, so a rowwise-only cast
    // produces the same rowwise fp8 bytes and scales as a rowwise+colwise cast.

    // Rowwise reference.
    Tensor linear_row("linear_row", shape, otype, /*rowwise=*/true, /*colwise=*/false,
                      NVTE_MXFP8_1D_SCALING);
    nvte_quantize(input.data(), linear_row.data(), 0);
    Tensor ref_row_swz("ref_row_swz", shape, otype, /*rowwise=*/true, /*colwise=*/false,
                       NVTE_MXFP8_1D_SCALING);
    ref_row_swz.set_with_gemm_swizzled_scales(true);
    if (out_bytes > 0) {
        cudaMemcpy(ref_row_swz.rowwise_dptr(), linear_row.rowwise_dptr(),
                   out_bytes, cudaMemcpyDeviceToDevice);
        nvte_swizzle_scaling_factors(linear_row.data(), ref_row_swz.data(), 0);
    }

    // Colwise reference.
    Tensor linear_col("linear_col", shape, otype, /*rowwise=*/false, /*colwise=*/true,
                      NVTE_MXFP8_1D_SCALING);
    nvte_quantize(input.data(), linear_col.data(), 0);
    Tensor ref_col_swz("ref_col_swz", shape, otype, /*rowwise=*/false, /*colwise=*/true,
                       NVTE_MXFP8_1D_SCALING);
    ref_col_swz.set_with_gemm_swizzled_scales(true);
    if (out_bytes > 0) {
        cudaMemcpy(ref_col_swz.columnwise_dptr(), linear_col.columnwise_dptr(),
                   out_bytes, cudaMemcpyDeviceToDevice);
        nvte_swizzle_scaling_factors(linear_col.data(), ref_col_swz.data(), 0);
    }

    cudaDeviceSynchronize();
    ASSERT_EQ(cudaGetLastError(), cudaSuccess) << "reference construction failed";

    // ---- Comparisons ----

    // (1) & (2): FP8 output data byte-identical to single-direction linear casts.
    TRANSFORMER_ENGINE_TYPE_SWITCH_FP8_ONLY(otype, OutputType,
        {
            const uint8_t *test_row = reinterpret_cast<const uint8_t *>(
                output_swizzled.rowwise_cpu_dptr<OutputType>());
            const uint8_t *ref_row = reinterpret_cast<const uint8_t *>(
                linear_row.rowwise_cpu_dptr<OutputType>());
            for (size_t i = 0; i < out_bytes; ++i) {
                ASSERT_EQ(test_row[i], ref_row[i])
                    << "rowwise fp8 data mismatch at index " << i
                    << " (swizzled=" << static_cast<int>(test_row[i])
                    << " linear=" << static_cast<int>(ref_row[i]) << ")";
            }
            const uint8_t *test_col = reinterpret_cast<const uint8_t *>(
                output_swizzled.columnwise_cpu_dptr<OutputType>());
            const uint8_t *ref_col = reinterpret_cast<const uint8_t *>(
                linear_col.columnwise_cpu_dptr<OutputType>());
            for (size_t i = 0; i < out_bytes; ++i) {
                ASSERT_EQ(test_col[i], ref_col[i])
                    << "colwise fp8 data mismatch at index " << i
                    << " (swizzled=" << static_cast<int>(test_col[i])
                    << " linear=" << static_cast<int>(ref_col[i]) << ")";
            }
        }
    );

    // (3): Swizzled rowwise scale bytes — directly-written vs linear-then-transform.
    {
        const size_t n = product(output_swizzled.rowwise_scale_inv_shape());
        const fp8e8m0 *test = output_swizzled.rowwise_cpu_scale_inv_ptr<fp8e8m0>();
        const fp8e8m0 *ref  = ref_row_swz.rowwise_cpu_scale_inv_ptr<fp8e8m0>();
        for (size_t i = 0; i < n; ++i) {
            ASSERT_EQ(test[i], ref[i])
                << "swizzled rowwise scale byte mismatch at offset " << i
                << " (test=" << static_cast<int>(test[i])
                << " ref=" << static_cast<int>(ref[i]) << ")";
        }
    }

    // (4): Swizzled colwise scale bytes — exercises the uint16-pair-packed flush
    // path added by CACHE_COLWISE_SCALE_IN_SMEM + WITH_SWIZZLED_SCALES.
    {
        const size_t n = product(output_swizzled.columnwise_scale_inv_shape());
        const fp8e8m0 *test = output_swizzled.columnwise_cpu_scale_inv_ptr<fp8e8m0>();
        const fp8e8m0 *ref  = ref_col_swz.columnwise_cpu_scale_inv_ptr<fp8e8m0>();
        for (size_t i = 0; i < n; ++i) {
            ASSERT_EQ(test[i], ref[i])
                << "swizzled colwise scale byte mismatch at offset " << i
                << " (test=" << static_cast<int>(test[i])
                << " ref=" << static_cast<int>(ref[i]) << ")";
        }
    }

    // (5) & (6): The rowwise-only swizzled path matches the same independently
    // constructed linear-then-swizzle reference.
    TRANSFORMER_ENGINE_TYPE_SWITCH_FP8_ONLY(otype, OutputType,
        {
            const uint8_t *test = reinterpret_cast<const uint8_t *>(
                output_rowwise_swizzled.rowwise_cpu_dptr<OutputType>());
            const uint8_t *ref = reinterpret_cast<const uint8_t *>(
                linear_row.rowwise_cpu_dptr<OutputType>());
            for (size_t i = 0; i < out_bytes; ++i) {
                ASSERT_EQ(test[i], ref[i])
                    << "rowwise-only fp8 data mismatch at index " << i;
            }
        }
    );
    {
        const size_t n = product(output_rowwise_swizzled.rowwise_scale_inv_shape());
        const fp8e8m0 *test =
            output_rowwise_swizzled.rowwise_cpu_scale_inv_ptr<fp8e8m0>();
        const fp8e8m0 *ref = ref_row_swz.rowwise_cpu_scale_inv_ptr<fp8e8m0>();
        for (size_t i = 0; i < n; ++i) {
            ASSERT_EQ(test[i], ref[i])
                << "rowwise-only swizzled scale mismatch at offset " << i;
        }
    }

}

std::string swizzled_test_name_generator(
    const testing::TestParamInfo<SwizzledScalesFusedCastMXFP8TestSuite::ParamType>& info) {
    std::string name;
    const auto &shape = std::get<0>(info.param);
    for (size_t i = 0; i < shape.size(); ++i) {
        if (i > 0) name += "x";
        name += std::to_string(shape[i]);
    }
    name += "X" + test::typeName(std::get<1>(info.param))
          + "X" + test::typeName(std::get<2>(info.param));
    return name;
}

INSTANTIATE_TEST_SUITE_P(
    OperatorTest_FusedCastMXFP8_SwizzledCastOnly,
    SwizzledScalesFusedCastMXFP8TestSuite,
    ::testing::Values(
        // 1. Aligned, small — sanity.
        std::make_tuple(std::vector<size_t>{128, 128}, DType::kBFloat16, DType::kFloat8E4M3),
        // 2. Aligned, small — second dtype pair.
        std::make_tuple(std::vector<size_t>{128, 128}, DType::kFloat32, DType::kFloat8E5M2),
        // 3. Aligned, medium.
        std::make_tuple(std::vector<size_t>{256, 384}, DType::kBFloat16, DType::kFloat8E4M3),
        // 4. Odd number of scale rows (96/32 = 3) - exercises colwise flush
        //    odd-row scalar tail.
        std::make_tuple(std::vector<size_t>{96, 512}, DType::kBFloat16, DType::kFloat8E4M3),
        // 5. cols/32 not a multiple of 4 - exercises rowwise flush scalar tail
        //    (need cols multiple of 8 for TMA-alignment on 16-bit input).
        std::make_tuple(std::vector<size_t>{256, 160}, DType::kBFloat16, DType::kFloat8E4M3),
        // 6. Odd colwise scale rows + rowwise tail cols - combined tail paths.
        std::make_tuple(std::vector<size_t>{96, 160}, DType::kBFloat16, DType::kFloat8E4M3),
        // 7. Small but tile-aligned.
        std::make_tuple(std::vector<size_t>{32, 64}, DType::kBFloat16, DType::kFloat8E4M3),
        // 8. Minimum aligned size - single 32x32 tile.
        std::make_tuple(std::vector<size_t>{32, 32}, DType::kBFloat16, DType::kFloat8E4M3),
        // 9. Multi-CTA at scale — stresses gmem writes across many CTAs.
        std::make_tuple(std::vector<size_t>{4096, 32768}, DType::kBFloat16, DType::kFloat8E4M3),
        // 10. 4D input — matches the existing suite's rank coverage.
        std::make_tuple(std::vector<size_t>{16, 8, 4, 512}, DType::kBFloat16, DType::kFloat8E4M3),
        // 11. Third input dtype.
        std::make_tuple(std::vector<size_t>{128, 128}, DType::kFloat16, DType::kFloat8E4M3),
        // 12. Larger fp32.
        std::make_tuple(std::vector<size_t>{1024, 1024}, DType::kFloat32, DType::kFloat8E4M3)
    ),
    swizzled_test_name_generator);
