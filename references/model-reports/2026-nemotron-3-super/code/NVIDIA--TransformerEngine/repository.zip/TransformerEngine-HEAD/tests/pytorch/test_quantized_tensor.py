# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.

from collections.abc import Iterable
import io
from typing import Any, Dict, List, Tuple, Union, Optional

import pytest
import torch

import transformer_engine.common.recipe
import transformer_engine.pytorch as te
from transformer_engine.pytorch import (
    Float8Quantizer,
    Float8CurrentScalingQuantizer,
    Float8BlockQuantizer,
    MXFP8Quantizer,
    NVFP4Quantizer,
    Float8Tensor,
    Float8BlockwiseQTensor,
    MXFP8Tensor,
    MXFP8TensorStorage,
    NVFP4Tensor,
    QuantizedTensor,
)

from transformer_engine.pytorch.quantized_tensor import prepare_for_saving, restore_from_saved
from transformer_engine.pytorch.utils import is_non_tn_fp8_gemm_supported

from references.ref_per_tensor_cs import ref_per_tensor_cs_cast
from utils import assert_close

# PyTorch tensor dtypes
_dtypes: List[torch.dtype] = [torch.float32, torch.float16, torch.bfloat16]
# TE FP8 dtypes
_fp8_dtypes: List[te.DType] = [te.DType.kFloat8E4M3, te.DType.kFloat8E5M2]

# Numerical tolerances with FP8 types
_tols: Dict[te.DType, Dict[str, float]] = {
    te.DType.kFloat8E4M3: dict(rtol=0.125, atol=0.0675),  # epsilon = 0.0625
    te.DType.kFloat8E5M2: dict(rtol=0.25, atol=0.125),  # epsilon = 0.125
}


def _to_list(x: Union[Iterable, Any]) -> List:
    """Convert to list if iterable, otherwise put in singleton list"""
    if isinstance(x, Iterable):
        return list(x)
    else:
        return [x]


# Types that can be interpreted as tensor dims
DimsType = Union[Iterable[int], int]

# Supported quantization recipes
fp8_available, reason_for_no_fp8 = te.is_fp8_available(return_reason=True)
fp8_block_scaling_available, reason_for_no_fp8_block_scaling = te.is_fp8_block_scaling_available(
    return_reason=True
)
mxfp8_available, reason_for_no_mxfp8 = te.is_mxfp8_available(return_reason=True)
nvfp4_available, reason_for_no_nvfp4 = te.is_nvfp4_available(return_reason=True)
_quantization_list: List[str] = []
if fp8_available:
    _quantization_list.append("fp8")
if fp8_block_scaling_available:
    _quantization_list.append("fp8_blockwise")
if mxfp8_available:
    _quantization_list.append("mxfp8")
if nvfp4_available:
    _quantization_list.append("nvfp4")
    _quantization_list.append("nvfp4_row_scaled")
    _quantization_list.append("nvfp4_4over6")


# delayed scaling
def to_float8(
    tensor: torch.Tensor,
    fp8_dtype: te.DType = te.DType.kFloat8E4M3,
    scale: float = 1.0,
) -> Float8Tensor:
    """Cast tensor to FP8"""
    quantizer = Float8Quantizer(
        scale=torch.full([1], scale, dtype=torch.float32, device="cuda"),
        amax=torch.empty([1], dtype=torch.float32, device="cuda"),
        fp8_dtype=fp8_dtype,
    )
    return quantizer(tensor.cuda())


# current scaling
def to_float8_CS(
    tensor: torch.Tensor,
    fp8_dtype: te.DType = te.DType.kFloat8E4M3,
    return_transpose: bool = False,
    force_pow_2_scales: bool = False,
    amax_epsilon: float = 0.0,
) -> Float8Tensor:
    """Cast tensor to FP8"""
    tensor = tensor.cuda()
    quantizer = Float8CurrentScalingQuantizer(
        fp8_dtype=fp8_dtype,
        device=tensor.device,
        force_pow_2_scales=force_pow_2_scales,
        amax_epsilon=amax_epsilon,
    )
    if return_transpose:
        quantizer.set_usage(rowwise=True, columnwise=True)
    else:
        quantizer.set_usage(rowwise=True, columnwise=False)
    return quantizer(tensor)


def make_quantizer(quantization: str, device: torch.device = "cuda"):
    """Construct a quantizer for the given quantization scheme."""
    if quantization in ("fp8", "fp8_delayed_scaling"):
        return Float8Quantizer(
            scale=torch.ones(1, dtype=torch.float32, device=device).squeeze(),
            amax=torch.zeros(1, dtype=torch.float32, device=device),
            fp8_dtype=te.DType.kFloat8E4M3,
        )
    if quantization == "fp8_current_scaling":
        return Float8CurrentScalingQuantizer(fp8_dtype=te.DType.kFloat8E4M3, device=device)
    if quantization == "fp8_blockwise":
        return Float8BlockQuantizer(
            fp8_dtype=te.DType.kFloat8E4M3,
            rowwise=True,
            columnwise=True,
            force_pow_2_scales=True,
            amax_epsilon=0.0,
            block_scaling_dim=1,
        )
    if quantization == "mxfp8":
        return MXFP8Quantizer(fp8_dtype=te.DType.kFloat8E4M3)
    if quantization in ("nvfp4", "nvfp4_row_scaled", "nvfp4_4over6"):
        row_scaled_nvfp4 = quantization == "nvfp4_row_scaled"
        return NVFP4Quantizer(
            columnwise=not row_scaled_nvfp4,
            with_rht=False,
            with_post_rht_amax=False,
            with_2d_quantization=False,
            stochastic_rounding=False,
            row_scaled_nvfp4=row_scaled_nvfp4,
            with_random_sign_mask=False,
            nvfp4_use_4over6=(quantization == "nvfp4_4over6"),
        )
    raise ValueError(f"Unsupported quantization scheme ({quantization})")


@torch.no_grad()
def make_reference_and_test_tensors(
    shape: int | Iterable[int],
    quantization: Optional[str] = None,
    ref_dtype: torch.dtype = torch.float64,
    ref_device: torch.device = "cpu",
    test_dtype: torch.dtype = torch.float32,
    test_device: torch.device = "cuda",
    requires_grad: bool = True,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Construct tensors with the same values

    The reference tensor is intended for use in plain PyTorch
    operations in high precision. The test tensor is intended for use
    in Transformer Engine operations.

    If a quantization scheme is provided, the tensor values are
    quantized so that they are representable.

    """

    # Random reference tensor
    ref = torch.rand(shape, dtype=ref_dtype, device=ref_device)

    # Construct test tensor from reference tensor
    test = ref.to(device=test_device, dtype=test_dtype)
    if quantization is None:
        if test.data_ptr() == ref.data_ptr():
            test = test.clone()
    else:
        test = make_quantizer(quantization, device=test_device)(test)

    # Make sure reference and test tensors match each other
    ref.copy_(test.to(dtype=ref.dtype))

    ref.requires_grad_(requires_grad)
    test.requires_grad_(requires_grad)
    return ref, test


@pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8)
class TestFloat8Tensor:

    @staticmethod
    def setup_class(cls) -> None:
        # Configure RNG
        seed = 1234
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)

    def test_constructor(
        self,
        dims: DimsType = 1,
        fp8_dtype: te.DType = te.DType.kFloat8E4M3,
        scale_inv: float = 0.375,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        """Call constructor and perform sanity checks"""
        dims = _to_list(dims)
        tensor = Float8Tensor(
            shape=dims,
            dtype=dtype,
            data=torch.zeros(dims, device="cuda", dtype=torch.uint8),
            fp8_dtype=fp8_dtype,
            fp8_scale_inv=torch.full([1], scale_inv),
        )
        assert list(tensor.size()) == dims, "Incorrect dims"
        assert tensor.dtype == dtype, "Incorrect nominal dtype"
        assert tensor.is_cuda, "Incorrect device"

    def _test_quantize_dequantize(
        self,
        fp8_dtype: te.DType = te.DType.kFloat8E4M3,
        scale: float = 3.5,
        dtype: torch.dtype = torch.float32,
        dims: DimsType = 23,
    ) -> None:
        """Check numerical error when casting to FP8 and back"""

        # Initialize random data
        x_ref = 2 * torch.rand(_to_list(dims), dtype=dtype, device="cpu") - 1

        # Cast to FP8 and back
        x_fp8 = to_float8(x_ref, fp8_dtype=fp8_dtype, scale=scale)
        x_fp8 = x_fp8.dequantize().cpu()

        # Check results
        torch.testing.assert_close(x_fp8, x_ref, **_tols[fp8_dtype])

        # Make sure we are not trivially passing the test
        with pytest.raises(AssertionError):
            torch.testing.assert_close(x_fp8, -x_ref, **_tols[fp8_dtype])

    @pytest.mark.parametrize("fp8_dtype", _fp8_dtypes)
    @pytest.mark.parametrize("dtype", _dtypes)
    def test_quantize_dequantize_dtypes(
        self,
        fp8_dtype: te.DType,
        dtype: torch.dtype,
    ) -> None:
        self._test_quantize_dequantize(fp8_dtype=fp8_dtype, dtype=dtype)

    @pytest.mark.parametrize("scale", [0.375, 1, 3.5])
    def test_quantize_dequantize_scales(self, scale: float) -> None:
        self._test_quantize_dequantize(scale=scale)

    @pytest.mark.parametrize("dims", [[], 1, 311, [7, 11], [7, 5, 3], [2, 3, 5, 3]])
    def test_quantize_dequantize_dims(self, dims: DimsType) -> None:
        self._test_quantize_dequantize(dims=dims)

    @pytest.mark.parametrize("fp8_dtype", _fp8_dtypes)
    @pytest.mark.parametrize("dtype", _dtypes)
    @pytest.mark.parametrize("noop", [True, False])
    def test_quantize_dequantize_noop(
        self, fp8_dtype: te.DType, dtype: torch.dtype, noop: bool
    ) -> None:
        noop_tensor = torch.zeros(1, dtype=torch.float32, device="cuda")
        if noop:
            noop_tensor = torch.ones(1, dtype=torch.float32, device="cuda")
        dims = 23
        scale: float = 3.5

        # Initialize random data
        x_ref = 2 * torch.rand(_to_list(dims), dtype=dtype, device="cpu") - 1

        # Cast to FP8 and back
        x_fp8 = to_float8(x_ref, fp8_dtype=fp8_dtype, scale=scale)
        # if noop, then when we input a different tensor, output should still be x_fp8_orig
        x_ref_noop_test = 2 * x_ref.cuda()
        x_fp8_orig = x_fp8.clone()
        x_fp8.quantize_(x_ref_noop_test, noop_flag=noop_tensor)
        if noop_tensor.item() == 1.0:
            torch.testing.assert_close(x_fp8, x_fp8_orig, atol=0, rtol=0)
        else:
            torch.testing.assert_close(x_fp8, x_ref_noop_test, **_tols[fp8_dtype])

    def test_basic_ops(
        self,
        dims: DimsType = 23,
        fp8_dtype: te.DType = te.DType.kFloat8E4M3,
        scale: float = 3.5,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        """Test basic out-of-place ops"""

        # Initialize random data
        dims = _to_list(dims)
        x_ref = 2 * torch.rand(dims, dtype=dtype, device="cpu") - 1
        y_ref = 2 * torch.rand(dims, dtype=dtype, device="cpu") - 1
        x_fp8 = to_float8(x_ref, fp8_dtype=fp8_dtype, scale=scale)
        y_fp8 = to_float8(y_ref, fp8_dtype=fp8_dtype, scale=scale)
        x_ref = x_fp8.dequantize()
        y_ref = y_fp8.dequantize()

        # Exact operations
        torch.testing.assert_close(-x_fp8, -x_ref, rtol=0, atol=0)
        torch.testing.assert_close(x_fp8.abs(), x_ref.abs(), rtol=0, atol=0)

        # Operations with numerical error
        tols = _tols[fp8_dtype]
        torch.testing.assert_close(x_fp8 + y_fp8, x_ref + y_ref, **tols)
        torch.testing.assert_close(x_fp8 - y_fp8, x_ref - y_ref, **tols)
        torch.testing.assert_close(x_fp8 * y_fp8, x_ref * y_ref, **tols)
        torch.testing.assert_close(x_fp8 + y_ref, x_ref + y_ref, **tols)
        torch.testing.assert_close(x_ref + y_fp8, x_ref + y_ref, **tols)
        torch.testing.assert_close(torch.sin(x_fp8), torch.sin(x_ref), **tols)

        # Make sure we are not trivially passing tests
        with pytest.raises(AssertionError):
            torch.testing.assert_close(x_fp8 + y_fp8, x_ref - y_fp8, **tols)

    @pytest.mark.parametrize("dims", [2, [4, 4], [8, 5, 3, 3]])
    def test_chunk_op(
        self,
        dims: DimsType,
        fp8_dtype: te.DType = te.DType.kFloat8E4M3,
        scale: float = 3.5,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        """Test for ops for which shape of inputs and outputs differ."""

        # Initialize random data
        dims = _to_list(dims)
        x_ref = torch.randn(dims, dtype=dtype, device="cpu")
        x_fp8 = to_float8(x_ref, fp8_dtype=fp8_dtype, scale=1.0)

        # Get chunks.
        chunk1, chunk2 = x_fp8.chunk(2, dim=0)

        # Test chunks.
        torch.testing.assert_close(x_fp8[0 : dims[0] // 2,], chunk1, atol=0, rtol=0)
        torch.testing.assert_close(x_fp8[dims[0] // 2 :,], chunk2, atol=0, rtol=0)

        # Check shapes.
        assert (
            chunk1.shape == torch.Size([x_fp8.shape[0] // 2]) + x_fp8.shape[1:]
        ), "Wrong shape for chunk1"
        assert (
            chunk2.shape == torch.Size([x_fp8.shape[0] // 2]) + x_fp8.shape[1:]
        ), "Wrong shape for chunk2"

    def test_inplace_ops(
        self,
        dims: DimsType = 23,
        fp8_dtype: te.DType = te.DType.kFloat8E4M3,
        scale: float = 3.5,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        """Test in-place ops"""

        # Initialize random data
        dims = _to_list(dims)
        x_ref = 2 * torch.rand(dims, dtype=dtype, device="cpu") - 1
        y_ref = 2 * torch.rand(dims, dtype=dtype, device="cpu") - 1
        x_fp8 = to_float8(x_ref, fp8_dtype=fp8_dtype, scale=scale)
        y_fp8 = to_float8(y_ref, fp8_dtype=fp8_dtype, scale=scale)
        x_ref = x_fp8.dequantize()
        y_ref = y_fp8.dequantize()

        # In-place operations
        tols = _tols[fp8_dtype]
        x_fp8 += y_ref
        x_ref += y_ref
        torch.testing.assert_close(x_fp8, x_ref, **tols)
        x_ref = x_fp8.dequantize()
        x_fp8 -= y_fp8
        x_ref -= y_fp8
        torch.testing.assert_close(x_fp8, x_ref, **tols)
        x_ref = x_fp8.dequantize()
        x_fp8 *= 2
        x_ref *= 2
        torch.testing.assert_close(x_fp8, x_ref, **tols)
        x_ref = x_fp8.dequantize()

        # Make sure we are not trivially passing tests
        x_ref += 123
        with pytest.raises(AssertionError):
            torch.testing.assert_close(x_fp8, x_ref, **tols)

    def test_serialization(
        self,
        dims: DimsType = [2, 3, 5],
        fp8_dtype: te.DType = te.DType.kFloat8E4M3,
        scale: float = 0.5,
        dtype: torch.dtype = torch.float32,
    ):

        # Initialize random data
        dims = _to_list(dims)
        x_ref = 2 * torch.rand(dims, dtype=dtype, device="cpu") - 1
        x_fp8 = to_float8(x_ref, fp8_dtype=fp8_dtype, scale=scale)
        x_ref = x_fp8.dequantize()

        # Serialize tensor
        byte_stream = io.BytesIO()
        torch.save(x_fp8, byte_stream)
        x_bytes = byte_stream.getvalue()

        # Mess up and delete old tensor
        x_fp8._data.zero_()
        x_fp8._scale_inv.zero_()
        del x_fp8, byte_stream

        # Deserialize tensor
        x_fp8 = torch.load(io.BytesIO(x_bytes), weights_only=False)
        del x_bytes

        # Check results
        tols = dict(rtol=0, atol=0)
        torch.testing.assert_close(x_fp8, x_ref, **tols)

        # Make sure we are not trivially passing tests
        x_fp8._data.zero_()
        x_fp8._scale_inv.zero_()
        with pytest.raises(AssertionError):
            torch.testing.assert_close(x_fp8, x_ref, **tols)

    def test_set_data(self):
        """Test directly setting .data attr"""

        # Initialize Float8Tensor
        x0 = torch.zeros(4, dtype=torch.float32)
        x = to_float8(x0)
        assert isinstance(x, Float8Tensor)
        assert x0.size() == x.size() == x._data.size()
        assert x.dtype == torch.float32
        assert x.is_cuda and x._data.is_cuda
        y = x.dequantize()
        assert not isinstance(y, Float8Tensor)
        assert x.size() == y.size()
        assert x.dtype == y.dtype
        assert x.device == y.device

        # Set data to plain tensor
        x0 = torch.zeros((3, 2), dtype=torch.float16, device=x.device)
        x.data = x0
        assert isinstance(x, Float8Tensor)
        assert x0.size() == x.size() == x._data.size()
        assert x0.dtype == x.dtype
        assert x0.device == x.device == x._data.device
        y = x.dequantize()
        assert not isinstance(y, Float8Tensor)
        assert x.size() == y.size()
        assert x.dtype == y.dtype
        assert x.device == y.device

        # Set data to Float8Tensor
        x0 = to_float8(torch.zeros((4, 3, 1), dtype=torch.float32))
        x.data = x0
        assert isinstance(x, Float8Tensor)
        assert x0.size() == x.size() == x._data.size()
        assert x0.dtype == x.dtype
        assert x0.device == x.device == x._data.device
        assert x0._data is x._data
        assert x0._scale_inv is x._scale_inv
        y = x.dequantize()
        assert not isinstance(y, Float8Tensor)
        assert x.size() == y.size()
        assert x.dtype == y.dtype
        assert x.device == y.device


@pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8)
class TestCurrentScalingFloat8Tensor:

    @staticmethod
    def setup_class(cls) -> None:
        # Configure RNG
        seed = 1234
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)

    @pytest.mark.parametrize("fp8_dtype", _fp8_dtypes)
    @pytest.mark.parametrize("dtype", _dtypes)
    @pytest.mark.parametrize(
        "dims", [[], 1, 311, [7, 11], [7, 5, 3], [2, 3, 5, 3], [128, 128], [611, 782]]
    )
    @pytest.mark.parametrize("return_transpose", [True, False], ids=str)
    @pytest.mark.parametrize("force_pow_2_scales", [True, False], ids=str)
    @pytest.mark.parametrize("amax_epsilon", [0.0, 1e-6], ids=str)
    def test_quantize(
        self,
        fp8_dtype: te.DType,
        dtype: torch.dtype,
        dims: DimsType,
        return_transpose: bool,
        force_pow_2_scales: bool,
        amax_epsilon: float,
    ) -> None:
        """Check numerical error when casting to FP8"""

        # Skip invalid configurations
        if is_non_tn_fp8_gemm_supported() and return_transpose:
            pytest.skip("FP8 transpose is neither needed nor supported on current system")

        # Initialize random high precision data
        device = "cuda"
        x_hp = 2 * torch.rand(_to_list(dims), dtype=dtype, device=device) - 1

        # Cast to FP8 and back
        x_fp8 = to_float8_CS(
            x_hp,
            fp8_dtype=fp8_dtype,
            return_transpose=return_transpose,
            force_pow_2_scales=force_pow_2_scales,
            amax_epsilon=amax_epsilon,
        )

        # get reference implementation of current scaling
        x_fp8_ref, sx_ref, x_fp8_t_ref, _ = ref_per_tensor_cs_cast(
            x_hp,
            fp8_dtype=fp8_dtype,
            return_transpose=return_transpose,
            force_pow_2_scales=force_pow_2_scales,
            amax_epsilon=amax_epsilon,
        )

        torch.testing.assert_close(x_fp8._data, x_fp8_ref.view(torch.uint8), atol=0.0, rtol=0.0)
        torch.testing.assert_close(x_fp8._scale_inv, sx_ref, atol=0.0, rtol=0.0)
        if return_transpose:
            torch.testing.assert_close(
                x_fp8._transpose, x_fp8_t_ref.view(torch.uint8), atol=0.0, rtol=0.0
            )

    @pytest.mark.parametrize("fp8_dtype", [te.DType.kFloat8E4M3], ids=str)
    @pytest.mark.parametrize("dtype", [torch.bfloat16], ids=str)
    @pytest.mark.parametrize("dims", [[], 1, 311, [7, 11], [7, 5, 3], [2, 3, 5, 3]])
    def test_quantize_dequantize(
        self, fp8_dtype: te.DType, dtype: torch.dtype, dims: DimsType
    ) -> None:
        """Check numerical error when casting to FP8 and back"""

        # Initialize random high precision data
        device = "cuda"
        x_hp = 2 * torch.rand(_to_list(dims), dtype=dtype, device=device) - 1

        # Cast to FP8 and back
        x_fp8 = to_float8_CS(x_hp, fp8_dtype=fp8_dtype)
        x_fp8_dequantized = x_fp8.dequantize()

        # Check results
        torch.testing.assert_close(x_fp8_dequantized, x_hp, **_tols[fp8_dtype])

        # Make sure we are not trivially passing the test
        with pytest.raises(AssertionError):
            torch.testing.assert_close(x_fp8_dequantized, -x_hp, **_tols[fp8_dtype])


class TestQuantizedTensor:
    @staticmethod
    def setup_class(cls) -> None:
        # Configure RNG
        seed = 1234
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)

    @pytest.mark.parametrize(
        "quantization",
        [
            pytest.param(
                "fp8",
                marks=pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8),
            ),
            pytest.param(
                "fp8_blockwise",
                marks=pytest.mark.skipif(
                    not fp8_block_scaling_available,
                    reason=reason_for_no_fp8_block_scaling,
                ),
            ),
            pytest.param(
                "mxfp8",
                marks=pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8),
            ),
            pytest.param(
                "nvfp4",
                marks=pytest.mark.skipif(not nvfp4_available, reason=reason_for_no_nvfp4),
            ),
        ],
    )
    def test_detach_preserves_subclass(self, quantization: str) -> None:
        """Detaching a quantized tensor preserves its runtime subclass."""
        quantizer = make_quantizer(quantization)
        tensor = quantizer(torch.randn(128, 128, dtype=torch.bfloat16, device="cuda"))
        derived_type = type(f"Derived{type(tensor).__name__}", (type(tensor),), {})
        tensor.__class__ = derived_type

        detached = tensor.detach()

        assert type(detached) is derived_type
        for detached_data, source_data in zip(
            detached.get_data_tensors(), tensor.get_data_tensors()
        ):
            assert detached_data is source_data
        assert not detached.requires_grad

        parameter = torch.nn.Parameter(tensor)
        assert type(parameter) is derived_type

    @pytest.mark.parametrize(
        "quantization",
        [
            pytest.param(
                "fp8",
                marks=pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8),
            ),
            pytest.param(
                "fp8_blockwise",
                marks=pytest.mark.skipif(
                    not fp8_block_scaling_available,
                    reason=reason_for_no_fp8_block_scaling,
                ),
            ),
            pytest.param(
                "mxfp8",
                marks=pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8),
            ),
            pytest.param(
                "nvfp4",
                marks=pytest.mark.skipif(not nvfp4_available, reason=reason_for_no_nvfp4),
            ),
        ],
    )
    def test_update_quantized_supports_subclass(self, quantization: str) -> None:
        """Quantizers update derived quantized tensor wrappers in-place."""
        quantizer = make_quantizer(quantization)
        source = torch.randn(128, 128, dtype=torch.bfloat16, device="cuda")
        tensor = quantizer(source)
        derived_type = type(f"Derived{type(tensor).__name__}", (type(tensor),), {})
        tensor.__class__ = derived_type

        quantizer.update_quantized(torch.zeros_like(source), tensor)

        assert type(tensor) is derived_type
        torch.testing.assert_close(tensor.dequantize(), torch.zeros_like(source))

    @pytest.mark.parametrize("op", ("clone", "view", "reshape", "contiguous"))
    @pytest.mark.parametrize("quantization", _quantization_list)
    def test_identity_op(
        self,
        *,
        op: str,
        quantization: str,
        shape: Iterable[int] = (128, 128),
        dtype: torch.dtype = torch.bfloat16,
        device: torch.device = "cuda",
    ) -> None:
        """Test operations that do not affect tensor values.

        These operations are must produce outputs that are bit-wise
        equivalent to the inputs. They must support autograd.

        """

        # Create reference and quantized tensor
        x_ref, x_test = make_reference_and_test_tensors(
            shape=shape,
            quantization=quantization,
            test_dtype=dtype,
        )
        dy_ref, dy_test = make_reference_and_test_tensors(
            shape=shape,
            test_dtype=dtype,
            requires_grad=False,
        )

        # Apply identity operation
        if op == "clone":
            y_ref = x_ref.clone()
            y_test = x_test.clone()
        elif op == "view":
            y_ref = x_ref.view(shape)
            y_test = x_test.view(shape)
        elif op == "reshape":
            y_ref = x_ref.reshape(shape)
            y_test = x_test.reshape(shape)
        elif op == "contiguous":
            y_ref = x_ref.contiguous()
            y_test = x_test.contiguous()

        # Check autograd
        y_test.backward(dy_test)
        assert x_test.grad is not None

        # Check values
        tols = dict(rtol=0, atol=0)
        if isinstance(y_test, QuantizedTensor):
            y_test = y_test.dequantize()
        y_test = y_test.to(dtype=torch.float64, device="cpu")
        dx_test = x_test.grad.to(dtype=torch.float64, device="cpu")
        dx_ref = dy_ref
        torch.testing.assert_close(y_test, y_ref, **tols)
        torch.testing.assert_close(dx_test, dx_ref, **tols)

    @pytest.mark.parametrize("quantization", _quantization_list)
    def test_cpu_dequantize(
        self,
        *,
        quantization: str,
        shape: Iterable[int] = (128, 128),
        dtype: torch.dtype = torch.bfloat16,
    ) -> None:
        """Dequantize on a CPU-resident QuantizedTensor."""

        # Construct a quantized tensor on CUDA.
        _, x_cuda = make_reference_and_test_tensors(
            shape=shape,
            quantization=quantization,
            test_dtype=dtype,
            requires_grad=False,
        )
        assert isinstance(x_cuda, QuantizedTensor)
        assert x_cuda.device.type == "cuda"

        # Reference: dequantize on CUDA, then move the dense result to CPU.
        ref_cpu = x_cuda.dequantize().to(device="cpu")

        # Move the QuantizedTensor itself to CPU and dequantize there.
        # ``.cpu()`` routes through ``aten._to_copy.default`` so all inner
        # buffers (data, scales, amax) are moved to CPU.
        x_cpu = x_cuda.cpu()
        assert isinstance(x_cpu, QuantizedTensor)
        assert x_cpu.device.type == "cpu"
        for attr in (
            "_data",
            "_rowwise_data",
            "_columnwise_data",
            "_rowwise_scale_inv",
            "_columnwise_scale_inv",
            "_amax_rowwise",
            "_amax_columnwise",
        ):
            buf = getattr(x_cpu, attr, None)
            if buf is not None:
                assert buf.device.type == "cpu", f"{attr} did not move to CPU"

        # Dequantize the CPU tensor. Implementation may bounce through CUDA
        # internally, but must return a CPU tensor.
        y_cpu = x_cpu.dequantize()
        assert y_cpu.device.type == "cpu"
        assert y_cpu.dtype == ref_cpu.dtype
        assert y_cpu.shape == ref_cpu.shape
        torch.testing.assert_close(y_cpu, ref_cpu, rtol=0, atol=0)

    def test_mxfp8_fsdp_extract_keeps_partial_columnwise_scale_block(self) -> None:
        """FSDP extraction must retain the scale for a partial final 32-row block."""
        rows, cols = 48, 64
        columnwise_scale_inv = torch.arange(4 * 128, dtype=torch.float32).reshape(4, 128)
        storage = MXFP8TensorStorage(
            rowwise_data=None,
            rowwise_scale_inv=None,
            columnwise_data=torch.zeros((rows, cols), dtype=torch.uint8),
            columnwise_scale_inv=columnwise_scale_inv,
            fp8_dtype=te.DType.kFloat8E4M3,
            quantizer=None,
            with_gemm_swizzled_scales=False,
            fake_dtype=torch.bfloat16,
        )

        buffers, metadata = storage.fsdp_extract_buffers()

        assert metadata == {"field_names": ("_columnwise_data", "_columnwise_scale_inv")}
        assert len(buffers) == 2
        assert buffers[0] is storage._columnwise_data
        extracted_scale_inv = buffers[1]
        assert extracted_scale_inv is not None
        assert extracted_scale_inv.shape == (2, 128)
        torch.testing.assert_close(extracted_scale_inv, columnwise_scale_inv[:2], rtol=0, atol=0)

    @pytest.mark.parametrize("quantization", _quantization_list)
    @pytest.mark.parametrize("dim", [0, 1])
    def test_chunk(
        self,
        *,
        quantization: str,
        dim: int,
        shape: Iterable[int] = (128, 128),
        chunks: int = 2,
        dtype: torch.dtype = torch.bfloat16,
        device: torch.device = "cuda",
    ) -> None:

        # Create reference and quantized tensor
        x_ref, x_test = make_reference_and_test_tensors(
            shape=shape,
            quantization=quantization,
            test_dtype=dtype,
        )

        # Chunk tensors
        ys_ref = torch.chunk(x_ref, chunks, dim=dim)
        ys_test = torch.chunk(x_test, chunks, dim=dim)

        # Check splits
        for y_ref, y_test in zip(ys_ref, ys_test):

            # Check split shapes
            assert y_ref.size() == y_test.size()

            # Check that splits are quantized when expected
            if quantization == "fp8":
                assert isinstance(y_test, Float8Tensor)
                y_test = y_test.dequantize()
            elif quantization == "mxfp8" and dim == 0:
                assert isinstance(y_test, MXFP8Tensor)
                y_test = y_test.dequantize()

            # Check values
            tols = dict(rtol=0, atol=0)  # Chunking is exact
            y_test = y_test.to(dtype=torch.float64, device="cpu")
            torch.testing.assert_close(y_test, y_ref, **tols)

    def test_view_not_implemented(self) -> None:
        """QuantizedTensor base class does not support tensor views."""
        qt = QuantizedTensor((128, 128), torch.bfloat16)
        with pytest.raises(
            NotImplementedError, match="QuantizedTensor class does not support tensor views"
        ):
            qt.view(-1)

    @pytest.mark.parametrize("quantization", _quantization_list)
    def test_shape_with_none_data(
        self,
        *,
        quantization: str,
        shape: Iterable[int] = (128, 128),
        dtype: torch.dtype = torch.bfloat16,
    ) -> None:
        """Test that shape is accessible after internal data tensors are set to None.

        During CPU offloading, both data and transpose tensors can be None.
        The shape should still be available via the wrapper subclass metadata.
        """

        _, x_test = make_reference_and_test_tensors(
            shape=shape,
            quantization=quantization,
            test_dtype=dtype,
            requires_grad=False,
        )

        # Verify shape before clearing data
        assert x_test.shape == torch.Size(shape)

        # Simulate CPU offloading: None out all internal data
        if isinstance(x_test, Float8Tensor):
            x_test._data = None
            x_test._transpose = None
        elif isinstance(x_test, MXFP8Tensor):
            x_test._rowwise_data = None
            x_test._columnwise_data = None
        elif isinstance(x_test, NVFP4Tensor):
            x_test._rowwise_data = None
            x_test._columnwise_data = None
        elif isinstance(x_test, Float8BlockwiseQTensor):
            x_test._rowwise_data = None
            x_test._columnwise_data = None

        # Shape must still be correct after data is cleared
        assert x_test.shape == torch.Size(shape), (
            f"Expected shape {shape} but got {x_test.shape} "
            f"after setting data to None on {type(x_test).__name__}"
        )

    @pytest.mark.parametrize("quantization", _quantization_list)
    @pytest.mark.parametrize(
        "rowwise, columnwise",
        [(True, True), (True, False), (False, True)],
        ids=["rowwise_columnwise", "rowwise_only", "columnwise_only"],
    )
    @pytest.mark.parametrize("shape", [(128, 256), (4, 128, 256)], ids=["2d", "3d"])
    def test_shape_matches_size(
        self,
        *,
        quantization: str,
        rowwise: bool,
        columnwise: bool,
        shape: Iterable[int],
        dtype: torch.dtype = torch.bfloat16,
        device: torch.device = "cuda",
    ) -> None:
        """shape, size() and size(dim) stay consistent for every usage combination.

        Both shape and size() are derived from whichever data buffer is present,
        and classes that store columnwise data transposed have to undo that. A
        columnwise-only tensor is where they can drift apart -- from each other,
        and from the shape the tensor was allocated with.
        """
        quantizer = make_quantizer(quantization, device=device)
        # Row-scaled NVFP4 accepts set_usage(rowwise=False) but rejects the
        # allocation itself, so it has to be filtered out up front.
        if getattr(quantizer, "row_scaled_nvfp4", False) and not rowwise:
            pytest.skip(f"{quantization} requires rowwise usage")
        quantizer.set_usage(rowwise=rowwise, columnwise=columnwise)
        if (quantizer.rowwise_usage, quantizer.columnwise_usage) != (rowwise, columnwise):
            pytest.skip(f"{quantization} does not support this usage combination")

        x = quantizer.make_empty(shape, dtype=dtype, device=device)
        name = type(x).__name__

        # shape and size() must describe the same tensor, whichever buffer they
        # end up reading.
        assert tuple(x.shape) == tuple(x.size()), f"{name}: {tuple(x.shape)} vs {tuple(x.size())}"

        # size(dim) must agree with the full shape, including negative indices.
        # It cannot be served by forwarding dim to a transposed buffer.
        for dim in range(len(x.shape)):
            assert x.size(dim) == x.shape[dim], f"{name}.size({dim}) is {x.size(dim)}"
            neg = dim - len(x.shape)
            assert x.size(neg) == x.shape[neg], f"{name}.size({neg}) is {x.size(neg)}"

        # NVFP4 deliberately reports columnwise-only tensors flattened to 2D and
        # warns about it, so only the ranks it preserves are checked here.
        if not (isinstance(quantizer, NVFP4Quantizer) and not rowwise and len(shape) > 2):
            assert tuple(x.shape) == tuple(shape), f"{name}.shape is {tuple(x.shape)}"

    @pytest.mark.parametrize(
        "quantization",
        _quantization_list + (["nvfp4_2d"] if nvfp4_available else []),
    )
    def test_update_nd_tensor(
        self,
        *,
        quantization: str,
        shape: Iterable[int] = (32, 4, 128),
        dtype: torch.dtype = torch.bfloat16,
        device: str = "cuda",
    ) -> None:
        """Check that an N-D quantized tensor can be updated."""

        # Construct quantizer
        if quantization == "fp8":
            quantizer = Float8Quantizer(
                scale=torch.ones(1, dtype=torch.float32, device=device).squeeze(),
                amax=torch.zeros(1, dtype=torch.float32, device=device),
                fp8_dtype=te.DType.kFloat8E4M3,
            )
        elif quantization == "fp8_blockwise":
            quantizer = Float8BlockQuantizer(
                fp8_dtype=te.DType.kFloat8E4M3,
                rowwise=True,
                columnwise=True,
                force_pow_2_scales=True,
                amax_epsilon=0.0,
                block_scaling_dim=1,
            )
        elif quantization == "mxfp8":
            quantizer = MXFP8Quantizer(fp8_dtype=te.DType.kFloat8E4M3)
        elif quantization in ("nvfp4", "nvfp4_2d", "nvfp4_row_scaled", "nvfp4_4over6"):
            row_scaled_nvfp4 = quantization == "nvfp4_row_scaled"
            quantizer = NVFP4Quantizer(
                rowwise=True,
                columnwise=not row_scaled_nvfp4,
                with_rht=False,
                with_post_rht_amax=False,
                with_2d_quantization=(quantization == "nvfp4_2d"),
                row_scaled_nvfp4=row_scaled_nvfp4,
                nvfp4_use_4over6=(quantization == "nvfp4_4over6"),
            )
            quantization = "nvfp4"
        else:
            raise ValueError(f"Unknown quantization: {quantization}")

        # Construct quantized tensor
        x = torch.randn(list(shape), dtype=dtype, device=device)
        q_x = quantizer(x)

        # Update tensor
        x_new = torch.randn(list(shape), dtype=dtype, device=device)
        q_x.copy_(x_new)

        # Check results
        q_ref = quantizer(x_new)
        assert q_x.shape == torch.Size(shape)
        assert_close(q_x, q_ref, rtol=0, atol=0)

    @pytest.mark.parametrize("quantization", _quantization_list)
    def test_quantize_dequantize_autograd(
        self,
        *,
        quantization: str,
        shape: Iterable[int] = (128, 128),
        dtype: torch.dtype = torch.bfloat16,
        device: torch.device = "cuda",
    ) -> None:
        """Autograd must survive a quantize -> dequantize round trip."""

        quantizer = make_quantizer(quantization, device=device)
        x = torch.randn(list(shape), dtype=dtype, device=device, requires_grad=True)
        # Quantize with autograd enabled: a grad_fn is attached to the output.
        x_q = quantizer(x)
        assert isinstance(x_q, QuantizedTensor)
        assert x_q.grad_fn is not None, "quantized tensor is missing its grad_fn"
        # requires_grad must reflect the attached grad_fn, not a stale cache.
        assert x_q.requires_grad, (
            "quantized tensor reports requires_grad=False despite having a "
            "grad_fn (stale requires_grad cache)"
        )

        # Dequantize and take a loss; the gradient must reach the input.
        (x_q.dequantize().float() ** 2).sum().backward()
        assert (
            x.grad is not None and x.grad.norm().item() > 0
        ), "Gradient did not flow back to the input through quantize -> dequantize"


@pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
class TestMXFP8Tensor:

    @staticmethod
    def setup_class(cls) -> None:
        # Configure RNG
        seed = 1234
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)

    @pytest.mark.parametrize("fp8_dtype", _fp8_dtypes)
    @pytest.mark.parametrize("dtype", _dtypes)
    @pytest.mark.parametrize("dims", [[128, 128], [256, 256], [128, 256]])
    def test_mxfp8_dequantize_columnwise_only(
        self,
        fp8_dtype: te.DType,
        dtype: torch.dtype,
        dims: DimsType,
    ) -> None:
        """Check dequantization of MXFP8 tensor with only columnwise data"""

        # Initialize random data
        x_ref = 2 * torch.rand(_to_list(dims), dtype=dtype, device="cuda") - 1

        # Quantize with both rowwise and columnwise
        quantizer = MXFP8Quantizer(fp8_dtype=fp8_dtype, rowwise=True, columnwise=True)
        x_mxfp8 = quantizer(x_ref)

        # Dequantize from rowwise (default path)
        x_deq_rowwise = x_mxfp8.dequantize(dtype=dtype)

        # Rowwise dequantization should be close to the original
        torch.testing.assert_close(x_deq_rowwise, x_ref, **_tols[fp8_dtype])

        # Strip rowwise data, keeping only columnwise
        x_mxfp8.update_usage(rowwise_usage=False, columnwise_usage=True)
        assert x_mxfp8._rowwise_data is None
        assert x_mxfp8._columnwise_data is not None

        # Dequantize from columnwise only
        x_deq_columnwise = x_mxfp8.dequantize(dtype=dtype)

        # Columnwise dequantization should be close to the original
        torch.testing.assert_close(x_deq_columnwise, x_ref, **_tols[fp8_dtype])

        # Rowwise and columnwise dequantizations should match each other
        torch.testing.assert_close(x_deq_columnwise, x_deq_rowwise, **_tols[fp8_dtype])

        # Make sure we are not trivially passing the test
        with pytest.raises(AssertionError):
            torch.testing.assert_close(x_deq_columnwise, -x_ref, **_tols[fp8_dtype])

    @pytest.mark.parametrize("fp8_dtype", _fp8_dtypes)
    @pytest.mark.parametrize("dims", [[128, 128], [256, 256]])
    def test_mxfp8_dequantize_columnwise_only_quantized_separately(
        self,
        fp8_dtype: te.DType,
        dims: DimsType,
    ) -> None:
        """Check dequantization of MXFP8 tensor quantized with columnwise only"""

        dtype = torch.bfloat16

        # Initialize random data
        x_ref = 2 * torch.rand(_to_list(dims), dtype=dtype, device="cuda") - 1

        # Quantize with columnwise only (no rowwise)
        quantizer = MXFP8Quantizer(fp8_dtype=fp8_dtype, rowwise=False, columnwise=True)
        x_mxfp8 = quantizer(x_ref)
        assert x_mxfp8._rowwise_data is None
        assert x_mxfp8._columnwise_data is not None

        # Dequantize from columnwise only
        x_deq = x_mxfp8.dequantize(dtype=dtype)

        # Should be close to the original
        torch.testing.assert_close(x_deq, x_ref, **_tols[fp8_dtype])

        # Make sure we are not trivially passing the test
        with pytest.raises(AssertionError):
            torch.testing.assert_close(x_deq, -x_ref, **_tols[fp8_dtype])


@pytest.mark.parametrize("quantization", _quantization_list)
@pytest.mark.parametrize("usage", ["rowwise", "columnwise", "both"])
@pytest.mark.parametrize("shape", [(256, 512), (128, 320)], ids=lambda s: f"{s[0]}x{s[1]}")
def test_skip_quantization_with_noop_flag(
    quantization: str, usage: str, shape: Tuple[int, int]
) -> None:
    """
    Test if the quantization honors the noop flag and skips quantization.
    This test only verifies that the kernel skips quantization where it's expected to do so.
    It doesn't verify otherwise (kernel correctly quantizes when noop is false) since that is already covered by other tests.
    """
    if usage == "columnwise" and quantization in ("fp8", "fp8_delayed_scaling"):
        pytest.skip("Delayed scaling does not support columnwise-only quantization")
    if usage != "rowwise" and quantization == "nvfp4_row_scaled":
        pytest.skip("Row-scaled NVFP4 does not produce columnwise output")

    quantizer = make_quantizer(quantization)
    quantizer.set_usage(
        rowwise=usage in ("rowwise", "both"),
        columnwise=usage in ("columnwise", "both"),
    )

    first_batch = torch.rand(shape, dtype=torch.bfloat16, device="cuda")
    # Make the input range much larger, even under delayed scaling, so amax will differ for sure
    # if the noop flag doesn't take effect
    second_batch = torch.rand_like(first_batch) * 2.0
    x = first_batch.clone()

    noop = torch.zeros(1, dtype=torch.float32, device="cuda")

    # Allocate and populate the destination outside the graph
    quantized = quantizer(x)

    # CUDA graph capture requires the work to be warmed up on a side stream first.
    side_stream = torch.cuda.Stream()
    side_stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(side_stream):
        for _ in range(3):
            quantized.quantize_(x, noop_flag=noop)
    torch.cuda.current_stream().wait_stream(side_stream)

    # Capture the CUDA graph
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        quantized.quantize_(x, noop_flag=noop)

    # Clone the underlying buffers of the quantized tensor's output so we can compare them later.
    # Note that we can't clone the quantized tensor, but its underlying buffers are torch tensors and can be cloned.
    def clone_quantized_output():
        output_buffers = {}
        for attr in (
            "_data",
            "_transpose",
            "_rowwise_data",
            "_columnwise_data",
            "_scale_inv",
            "_rowwise_scale_inv",
            "_columnwise_scale_inv",
            "_amax_rowwise",
            "_amax_columnwise",
        ):
            buf = getattr(quantized, attr, None)
            if buf is not None:
                output_buffers[attr] = buf.clone()
        # Delayed scaling keeps its global amax on the quantizer rather than on the tensor.
        quantizer_amax = getattr(quantizer, "amax", None)
        if quantizer_amax is not None:
            output_buffers["quantizer.amax"] = quantizer_amax.clone()
        assert output_buffers, f"{quantization}: quantized tensor exposes no data buffer"
        return output_buffers

    # Obtain the quantized x by setting the noop flag to false (zero)
    noop.zero_()
    graph.replay()
    torch.cuda.synchronize()
    quantized_without_noop = clone_quantized_output()

    # Reset x to different values and set the noop flag to true (one).
    # The quantization should be skipped so the output should not be different.
    x.copy_(second_batch)
    noop.fill_(1.0)
    graph.replay()
    torch.cuda.synchronize()
    quantized_with_noop = clone_quantized_output()

    for attr in quantized_without_noop:
        buf_without_noop = quantized_without_noop[attr]
        buf_with_noop = quantized_with_noop[attr]
        assert torch.equal(
            buf_without_noop, buf_with_noop
        ), f"{quantization}/{usage}: noop flag fails to take effect because {attr} changed."


def test_saved_storage_protocol(monkeypatch):
    """Preserve custom metadata, pass the full suffix, and use the returned remainder."""
    value, tail, replacement = (torch.tensor(i) for i in range(3))
    remainder = [replacement, tail]

    class Storage:
        __slots__ = ()

        def prepare_for_saving(self):
            return [value], self

        def restore_from_saved(self, tensors):
            assert isinstance(tensors, list)
            assert len(tensors) == 2 and tensors[0] is value and tensors[1] is tail
            return remainder

    monkeypatch.setattr(torch.compiler, "is_compiling", lambda: False)
    storage = Storage()
    saved, objects = prepare_for_saving(value, storage)
    restored, remaining = restore_from_saved(
        objects + [None], saved + [tail], return_saved_tensors=True
    )
    assert restored[0] is value and restored[1] is storage and restored[2] is replacement
    assert isinstance(remaining, list) and len(remaining) == 1 and remaining[0] is tail


@pytest.mark.parametrize("compiled_metadata", [False, True])
def test_restore_real_quantized_storage(monkeypatch, compiled_metadata):
    """Restore actual MXFP8 buffers and None/plain tensor slots with either metadata form."""
    if not te.is_mxfp8_available():
        pytest.skip("MXFP8 is unavailable.")
    q = MXFP8Quantizer(te.DType.kFloat8E4M3, rowwise=True, columnwise=True)
    q.internal = True
    x = torch.randn(128, 128, device="cuda", dtype=torch.bfloat16)
    quantized = q(x)
    expected = quantized.dequantize().clone()
    with monkeypatch.context() as context:
        context.setattr(torch.compiler, "is_compiling", lambda: compiled_metadata)
        saved, objects = prepare_for_saving(x, quantized, None)
    restored, tail = restore_from_saved(objects, tuple(saved) + (x,), return_saved_tensors=True)
    assert restored[0] is x and restored[2] is None
    assert isinstance(tail, tuple) and tail[0] is x
    torch.testing.assert_close(restored[1].dequantize(), expected, rtol=0, atol=0)
