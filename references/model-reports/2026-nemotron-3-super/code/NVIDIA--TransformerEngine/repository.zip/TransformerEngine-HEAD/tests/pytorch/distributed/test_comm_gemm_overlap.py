# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.
import ctypes
import os
import subprocess
from pathlib import Path

import pytest
import torch
import transformer_engine.pytorch as te
import transformer_engine.pytorch.cpp_extensions as tex

if torch.cuda.device_count() < 2:
    pytest.skip("Comm+GEMM overlap requires at least 2 GPUs.")

fp8_available, reason_for_no_fp8 = te.is_fp8_available(return_reason=True)
mxfp8_available, reason_for_no_mxfp8 = te.is_mxfp8_available(return_reason=True)
nvfp4_available, reason_for_no_nvfp4 = te.is_nvfp4_available(return_reason=True)


def _loaded_cublasmp_version() -> int:
    """Version of the cuBLASMp library loaded by Transformer Engine, or 0 if there is none."""
    if not tex.nvte_built_with_cublasmp():
        return 0
    try:
        version = ctypes.c_int(0)
        ctypes.CDLL("libcublasmp.so.0").cublasMpGetVersion(ctypes.byref(version))
    except (OSError, AttributeError):
        return 0
    return version.value


# NVFP4 with cuBLASMp applies the global scales through a device-side alpha (cuBLASMp 0.11.0+)
cublasmp_nvfp4_available = _loaded_cublasmp_version() >= 1100
reason_for_no_cublasmp_nvfp4 = "NVFP4 with cuBLASMp requires cuBLASMp 0.11.0 or newer."

RNG_SEED: int = 42
SEQ_LENGTH: int = 1024
BATCH_SIZE: int = 2
NUM_HEADS: int = 32
HEAD_DIM: int = 48
TE_LAYERS = [
    te.Linear,
    te.LayerNormLinear,
    te.LayerNormMLP,
    te.MultiheadAttention,
    te.TransformerLayer,
]
MAX_LAYER_NAME_LENGTH = max([len(layer.__name__) for layer in TE_LAYERS])

# to avoid numerical tolerance issues of doing comm gemm overlap, limit the number of GPUs used
MAX_GPUS_TO_USE = 4

COMM_GEMM_QUANTIZATION_PARAMS = [
    pytest.param(False, "none", id="ub-bf16"),
    pytest.param(False, "fp8", id="ub-fp8"),
    pytest.param(False, "mxfp8", id="ub-mxfp8"),
    pytest.param(True, "none", id="cublasmp-bf16"),
    pytest.param(True, "fp8", id="cublasmp-fp8"),
    pytest.param(True, "mxfp8", id="cublasmp-mxfp8"),
    # Userbuffers does not support NVFP4
    pytest.param(True, "nvfp4", id="cublasmp-nvfp4"),
]

TEST_ROOT = Path(__file__).parent.resolve()
NUM_PROCS: int = min(torch.cuda.device_count(), MAX_GPUS_TO_USE)
LAUNCH_CMD = ["torchrun", f"--nproc_per_node={NUM_PROCS}"]
if tex.ubuf_built_with_mpi():
    LAUNCH_CMD = ["mpirun", "-np", str(NUM_PROCS), "--oversubscribe", "--quiet", "python3"]

OUTPUT_TAIL_CHARS = 4000


def _assert_subprocess_succeeded(result):
    if (
        result.returncode != 0
        or "NUMERICAL CHECK FAILED" in result.stderr
        or "NUMERICAL CHECK PASSED" not in result.stdout
    ):
        raise AssertionError(
            f"Distributed test exited with return code {result.returncode}"
            f"\n--- stdout (last {OUTPUT_TAIL_CHARS} characters) ---\n"
            f"{result.stdout[-OUTPUT_TAIL_CHARS:]}"
            f"\n--- stderr (last {OUTPUT_TAIL_CHARS} characters) ---\n"
            f"{result.stderr[-OUTPUT_TAIL_CHARS:]}"
        )


# Fall back on CUDA IPC if the platform does not support CUDA multicast
if not tex.device_supports_multicast():
    os.environ["UB_SKIPMC"] = "1"

# Force GPU kernels to launch in the order they're executed by the host CPU
os.environ["CUDA_DEVICE_MAX_CONNECTIONS"] = "1"

# Clear torch.dynamo caches
torch._dynamo.reset()


def _run_gemm_with_overlap(
    comm_type, bulk, p2p, atomic, aggregate, quantization, use_cublasmp=False
):
    test_path = TEST_ROOT / "run_gemm_with_overlap.py"
    test_cmd = LAUNCH_CMD + [
        str(test_path),
        "--check-numerics",
        f"--seed={RNG_SEED}",
        f"--seq-length={SEQ_LENGTH}",
        f"--batch-size={BATCH_SIZE}",
        f"--num-heads={NUM_HEADS}",
        f"--head-dim={HEAD_DIM}",
        f"--comm-type={comm_type}",
    ]

    if bulk:
        test_cmd.append("--bulk-overlap")
    else:
        if quantization == "fp8" and not fp8_available:
            pytest.skip(reason_for_no_fp8)
        if quantization == "mxfp8" and not mxfp8_available:
            pytest.skip(reason_for_no_mxfp8)
        if quantization == "nvfp4" and not nvfp4_available:
            pytest.skip(reason_for_no_nvfp4)
        test_cmd.append(f"--quantization={quantization}")
        if p2p:
            test_cmd.append("--p2p")
        if atomic:
            if torch.cuda.get_device_properties(0).major != 9:
                pytest.skip("Atomic GEMM is requires device compute capability 9.x (Hopper).")
            test_cmd.append("--atomic")
        if aggregate:
            test_cmd.append("--aggregate")
        if use_cublasmp:
            if not tex.nvte_built_with_cublasmp():
                pytest.skip("Transformer Engine not built with cuBLASMp (NVTE_WITH_CUBLASMP=0).")
            if quantization == "nvfp4" and not cublasmp_nvfp4_available:
                pytest.skip(reason_for_no_cublasmp_nvfp4)
            if comm_type == "RS" and not p2p and not tex.device_supports_multicast():
                pytest.skip(
                    "cuBLASMp non-P2P reduce-scatter requires NVSwitch (multicast support)."
                )
            test_cmd.append("--use-cublasmp")

    result = subprocess.run(test_cmd, env=os.environ, capture_output=True, text=True, check=False)
    _assert_subprocess_succeeded(result)


def _run_layer_with_overlap(
    layer_type,
    linear_parallel_mode,
    overlap_rs_dgrad,
    fp8,
    quantization,
    num_layers=1,
    use_cublasmp=False,
    use_compile=False,
    compile_mode="default",
):
    test_path = TEST_ROOT / "run_layer_with_overlap.py"
    test_cmd = LAUNCH_CMD + [
        str(test_path),
        f"--seed={RNG_SEED}",
        f"--seq-length={SEQ_LENGTH}",
        f"--batch-size={BATCH_SIZE}",
        f"--num-heads={NUM_HEADS}",
        f"--head-dim={HEAD_DIM}",
        f"--layer-type={layer_type}",
        f"--num-layers={num_layers}",
    ]
    if layer_type in [te.Linear.__name__, te.LayerNormLinear.__name__]:
        test_cmd.append(f"--linear-parallel-mode={linear_parallel_mode}")

    if overlap_rs_dgrad:
        test_cmd.append("--overlap-rs-dgrad")

    if use_compile:
        test_cmd.append("--compile")
        test_cmd.append(f"--compile-mode={compile_mode}")

    if fp8:
        if quantization in ("fp8_delayed_scaling", "fp8_current_scaling") and not fp8_available:
            pytest.skip(reason_for_no_fp8)
        if quantization == "mxfp8" and not mxfp8_available:
            pytest.skip(reason_for_no_mxfp8)
        if quantization == "nvfp4":
            if not nvfp4_available:
                pytest.skip(reason_for_no_nvfp4)
            if not use_cublasmp:
                pytest.skip("Userbuffers does not support NVFP4.")
        test_cmd.append("--fp8")
        test_cmd.append(f"--quantization={quantization}")

    if use_cublasmp:
        if not tex.nvte_built_with_cublasmp():
            pytest.skip("Transformer Engine not built with cuBLASMp (NVTE_WITH_CUBLASMP=0).")
        if fp8 and quantization == "nvfp4" and not cublasmp_nvfp4_available:
            pytest.skip(reason_for_no_cublasmp_nvfp4)
        test_cmd.append("--use-cublasmp")

    test_env = os.environ.copy()
    test_env["PYTORCH_JIT"] = "0"
    test_env["NVTE_TORCH_COMPILE"] = "0"
    test_env["NVTE_ALLOW_NONDETERMINISTIC_ALGO"] = "0"
    if te.get_device_compute_capability() <= (8, 0):
        # We've experienced numerical discrepancies in Flash Attention
        # backward when running with Userbuffers on A100s. This does
        # not show up in more recent GPUs.
        test_env["NVTE_FLASH_ATTN"] = "0"
    elif fp8:
        # Fused attention is causing non-deterministic FP8 failures on H100s even with
        # NVTE_ALLOW_NONDETERMINISTIC_ALGO=0, so disable it entirely for this test.
        test_env["NVTE_FUSED_ATTN"] = "0"

    result = subprocess.run(test_cmd, env=test_env, capture_output=True, text=True, check=False)

    _assert_subprocess_succeeded(result)


@pytest.mark.parametrize("use_cublasmp,quantization", COMM_GEMM_QUANTIZATION_PARAMS)
@pytest.mark.parametrize("aggregate", (False, True))
def test_split_all_gather_overlaps(quantization, aggregate, use_cublasmp):
    """
    Test (split GEMM -> all-gather) overlaps with direct calls to te.cpp_extensions.gemm or
    te.cpp_extensions.fp8_gemm.
    """
    _run_gemm_with_overlap("AG", False, True, False, aggregate, quantization, use_cublasmp)


@pytest.mark.parametrize("use_cublasmp,quantization", COMM_GEMM_QUANTIZATION_PARAMS)
@pytest.mark.parametrize("p2p", (False, True))
def test_split_reduce_scatter_overlaps(quantization, p2p, use_cublasmp):
    """
    Test (reduce-scatter -> split GEMM) overlaps with direct calls to te.cpp_extensions.gemm or
    te.cpp_extensions.fp8_gemm.
    """
    _run_gemm_with_overlap("RS", False, p2p, False, False, quantization, use_cublasmp)


@pytest.mark.parametrize(
    "comm_type, quantization, connections",
    [
        ("AG", "none", 1),
        ("RS", "none", 1),
        ("RS", "fp8", 1),
        ("AG", "none", 8),
        ("RS", "none", 8),
        ("RS", "fp8", 8),
    ],
    ids=[
        "ALL-GATHER     - BF16 - 1 connections",
        "REDUCE-SCATTER - BF16 - 1 connections",
        "REDUCE-SCATTER - FP8  - 1 connections",
        "ALL-GATHER     - BF16 - 8 connections",
        "REDUCE-SCATTER - BF16 - 8 connections",
        "REDUCE-SCATTER - FP8  - 8 connections",
    ],
)
def test_bulk_overlaps(comm_type, quantization, connections):
    """
    Test bulk overlaps with direct calls to te.cpp_extensions.gemm or te.cpp_extensions.fp8_gemm.
    """
    if connections == 8:
        if torch.cuda.get_device_properties(0).major != 9:
            pytest.skip(
                "CUDA_DEVICE_MAX_CONNECTIONS=8 test only applies to devices with compute capability"
                " 9.0 (HOPPER ARCH)."
            )
        os.environ["CUDA_DEVICE_MAX_CONNECTIONS"] = "8"
        _run_gemm_with_overlap(comm_type, True, False, False, False, quantization)
        os.environ["CUDA_DEVICE_MAX_CONNECTIONS"] = "1"
    else:
        _run_gemm_with_overlap(comm_type, True, False, False, False, quantization)


@pytest.mark.parametrize("use_cublasmp", (False, True))
@pytest.mark.parametrize(
    "fp8",
    (False,),
    ids=[
        " BF16 ",
    ],
)
@pytest.mark.parametrize(
    "layer_type,linear_parallel_mode,overlap_rs_dgrad",
    [
        (te.Linear.__name__, "row", False),
        (te.Linear.__name__, "column", False),
        (te.Linear.__name__, "column", True),
        (te.LayerNormLinear.__name__, "column", False),
        (te.LayerNormLinear.__name__, "column", True),
    ]
    + list(
        zip(
            [layer.__name__ for layer in TE_LAYERS[2:] for _ in range(2)],
            [None] * len(TE_LAYERS[2:]) * 2,
            [False, True] * len(TE_LAYERS[2:]),
        )
    ),
    ids=[
        f" {te.Linear.__name__} - ROW-PARALLEL ",
        f" {te.Linear.__name__} - COL-PARALLEL - BULK DGRAD/WGRAD ",
        f" {te.Linear.__name__} - COL-PARLALEL - DGRAD+RS ",
        f" {te.LayerNormLinear.__name__} - COL-PARALLEL - BULK DGRAD/WGRAD ",
        f" {te.LayerNormLinear.__name__} - COL-PARALLEL - DGRAD+RS ",
    ]
    + [
        " " + " - ".join(test_name_parts) + " "
        for test_name_parts in zip(
            [layer.__name__ for layer in TE_LAYERS[2:] for _ in range(2)],
            ["BULK DGRAD/WGRAD", "DGRAD+RS"] * len(TE_LAYERS[2:]),
        )
    ],
)
def test_layers_with_overlap_bf16(
    layer_type, linear_parallel_mode, overlap_rs_dgrad, use_cublasmp, fp8
):
    """
    Test Transformer Engine layers with comm+GEMM overlap.
    """
    _run_layer_with_overlap(
        layer_type, linear_parallel_mode, overlap_rs_dgrad, fp8, None, use_cublasmp=use_cublasmp
    )


@pytest.mark.parametrize("compile_mode", ["default", "reduce-overhead"])
@pytest.mark.parametrize(
    "quantization",
    [None, "fp8_current_scaling", "mxfp8"],
    ids=["bf16", "fp8_current_scaling", "mxfp8"],
)
@pytest.mark.parametrize(
    "linear_parallel_mode,overlap_rs_dgrad",
    [
        ("row", False),
        ("column", False),
        ("column", True),
    ],
    ids=[
        "ROW-PARALLEL",
        "COL-PARALLEL - BULK DGRAD/WGRAD",
        "COL-PARALLEL - DGRAD+RS",
    ],
)
def test_linear_with_overlap_compile(
    linear_parallel_mode, overlap_rs_dgrad, quantization, compile_mode
):
    """te.Linear comm+GEMM overlap (Userbuffers) under torch.compile,
    checked numerically against the eager, non-overlap reference."""
    if quantization is not None and linear_parallel_mode == "row":
        pytest.skip(
            "FP8 row-parallel UB forces differentiable fp8_output, unsupported under compile."
        )
    _run_layer_with_overlap(
        te.Linear.__name__,
        linear_parallel_mode,
        overlap_rs_dgrad,
        quantization is not None,
        quantization,
        use_compile=True,
        compile_mode=compile_mode,
    )


@pytest.mark.parametrize("use_cublasmp", (False, True))
@pytest.mark.parametrize(
    "quantization",
    ["fp8_delayed_scaling", "fp8_current_scaling", "mxfp8", "nvfp4"],
)
@pytest.mark.parametrize(
    "layer_type,linear_parallel_mode,overlap_rs_dgrad",
    [
        (te.Linear.__name__, "row", False),
        (te.Linear.__name__, "column", False),
        (te.Linear.__name__, "column", True),
        (te.LayerNormLinear.__name__, "column", False),
        (te.LayerNormLinear.__name__, "column", True),
    ]
    + list(
        zip(
            [layer.__name__ for layer in TE_LAYERS[2:] for _ in range(2)],
            [None] * len(TE_LAYERS[2:]) * 2,
            [False, True] * len(TE_LAYERS[2:]),
        )
    ),
    ids=[
        f"{te.Linear.__name__}-row_tensor_parallel",
        f"{te.Linear.__name__}-col_tensor_parallel-BULK DGRAD/WGRAD",
        f"{te.Linear.__name__}-col_tensor_parallel-DGRAD+RS",
        f"{te.LayerNormLinear.__name__}-col_tensor_parallel-BULK DGRAD/WGRAD",
        f"{te.LayerNormLinear.__name__}-col_tensor_parallel-DGRAD+RS",
    ]
    + [
        "-".join(test_name_parts)
        for test_name_parts in zip(
            [layer.__name__ for layer in TE_LAYERS[2:] for _ in range(2)],
            ["BULK DGRAD/WGRAD", "DGRAD+RS"] * len(TE_LAYERS[2:]),
        )
    ],
)
def test_layers_with_overlap_fp8(
    layer_type,
    linear_parallel_mode,
    overlap_rs_dgrad,
    quantization,
    use_cublasmp,
):
    """
    Test Transformer Engine layers with comm+GEMM overlap.

    The layer runner uses 3-D logical activations. Column-parallel and composite-layer cases
    without RS-dgrad overlap exercise FP8 GEMMs with bulk reduce-scatter in backward, and the
    runner checks that output and gradient shapes match the non-overlap reference in addition to
    checking their values.
    """
    _run_layer_with_overlap(
        layer_type,
        linear_parallel_mode,
        overlap_rs_dgrad,
        True,
        quantization,
        use_cublasmp=use_cublasmp,
    )
