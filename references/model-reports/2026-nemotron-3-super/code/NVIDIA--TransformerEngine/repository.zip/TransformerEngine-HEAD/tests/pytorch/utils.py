# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.

from __future__ import annotations

import logging
import os
import random
import subprocess
from collections.abc import Iterable
from contextlib import contextmanager
from typing import Optional, Sequence, Tuple, Dict, Any, List
from packaging.version import Version as PkgVersion

import pytest
import torch

import transformer_engine
from transformer_engine.common.recipe import Format as RecipeFormat, Recipe
from transformer_engine.pytorch import (
    DType,
    InferenceParams,
    NVFP4Quantizer,
    QuantizedTensor,
    QuantizerRole,
)
from transformer_engine.pytorch.attention.dot_product_attention import _attention_backends
from transformer_engine.pytorch.attention.dot_product_attention.utils import (
    get_attention_backend,
    get_qkv_format,
    AttentionParams,
    AttentionLogging,
    check_set_window_size,
)
from transformer_engine.pytorch.cpp_extensions.fused_attn import FusedAttnBackend
from transformer_engine.pytorch.module.base import get_dummy_wgrad


# NVFP4 recipe names
nvfp4_variant_names: Tuple[str, ...] = (
    "nvfp4",
    "nvfp4_row_scaled",
    "nvfp4_4over6",
    "nvfp4_rht",
    "nvfp4_ue5m3",
    "nvfp4_rht_ue5m3",
)


def str_to_dtype(dtype: str | torch.dtype) -> torch.dtype:
    """Convert type name to PyTorch dtype"""
    if isinstance(dtype, torch.dtype):
        return dtype
    name = str(dtype).strip().lower()
    if name.startswith("torch."):
        name = name.replace("torch.", "", 1)
    if name.startswith("fp"):
        name = name.replace("fp", "float", 1)
    dtype = dict(
        float32=torch.float32,
        float=torch.float32,
        float64=torch.float64,
        double=torch.float64,
        float16=torch.float16,
        half=torch.float16,
        bfloat16=torch.bfloat16,
        bf16=torch.bfloat16,
        float8_e4m3fn=torch.float8_e4m3fn,
        float8_e4m3=torch.float8_e4m3fn,
        float8e4m3=torch.float8_e4m3fn,
        float8=torch.float8_e4m3fn,
        float8_e5m2=torch.float8_e5m2,
        float8e5m2=torch.float8_e5m2,
        uint8=torch.uint8,
        byte=torch.uint8,
        int8=torch.int8,
        char=torch.int8,
        int16=torch.int16,
        short=torch.int16,
        int32=torch.int32,
        int=torch.int32,
        int64=torch.int64,
        long=torch.int64,
        bool=torch.bool,
    )[name]
    return dtype


def dtype_tols(dtype: torch.dtype | DType) -> dict[str, float]:
    """Estimated numerical error for a datatype

    Based on tolerances for torch.testing.assert_close.

    """

    # Transformer Engine dtypes
    if isinstance(dtype, DType):
        if dtype == DType.kFloat4E2M1:
            return dict(rtol=0.25, atol=0.125)  # epsilon = 0.25
        dtype = {
            DType.kByte: torch.uint8,
            DType.kInt32: torch.int32,
            DType.kFloat32: torch.float32,
            DType.kFloat16: torch.half,
            DType.kBFloat16: torch.bfloat16,
            DType.kFloat8E4M3: torch.float8_e4m3fn,
            DType.kFloat8E5M2: torch.float8_e5m2,
        }[dtype]

    # PyTorch dtypes
    if dtype == torch.float16:
        return dict(rtol=1e-3, atol=1e-5)
    if dtype == torch.bfloat16:
        return dict(rtol=1.6e-2, atol=1e-5)
    if dtype == torch.float32:
        return dict(rtol=1.3e-6, atol=1e-5)
    if dtype == torch.float64:
        return dict(rtol=1e-7, atol=1e-7)
    if dtype == torch.float8_e4m3fn:
        return dict(rtol=0.125, atol=0.0675)  # epsilon = 0.0625
    if dtype == torch.float8_e5m2:
        return dict(rtol=0.25, atol=0.125)  # epsilon = 0.125
    raise ValueError(f"Unsupported dtype ({dtype})")


def quantization_tols(name: str) -> dict[str, float]:
    """Estimated numerical error for a quantization scheme"""
    if name in (
        "fp8",
        "fp8_delayed_scaling",
        "fp8_current_scaling",
        "fp8_blockwise",
        "fp8_block_scaling",
        "mxfp8",
        "mxfp8_block_scaling",
    ):
        return dtype_tols(DType.kFloat8E4M3)
    if name in nvfp4_variant_names:
        return dtype_tols(DType.kFloat4E2M1)
    raise ValueError(f"Unsupported quantization scheme ({name})")


def make_recipe(name: Optional[str], **recipe_kwargs: Any) -> Optional[Recipe]:
    """Make recipe for quantization scheme"""
    if name is None:
        return None
    if name in ("fp8", "fp8_delayed_scaling"):
        return transformer_engine.common.recipe.DelayedScaling(
            fp8_format=RecipeFormat.E4M3,
            amax_history_len=8,
            **recipe_kwargs,
        )
    if name == "fp8_current_scaling":
        return transformer_engine.common.recipe.Float8CurrentScaling(
            fp8_format=RecipeFormat.E4M3,
            **recipe_kwargs,
        )
    if name == "mxfp8":
        return transformer_engine.common.recipe.MXFP8BlockScaling(
            fp8_format=RecipeFormat.E4M3,
            **recipe_kwargs,
        )
    if name == "fp8_block_scaling":
        return transformer_engine.common.recipe.Float8BlockScaling(**recipe_kwargs)
    if name in ("nvfp4_ue5m3", "nvfp4_rht_ue5m3"):

        def make_nvfp4_ue5m3_quantizer(role: QuantizerRole) -> NVFP4Quantizer:
            """Quantizer factory for NVFP4-UE5M3 recipe."""
            tensor_type = role.tensor_type if role is not None else None
            if not tensor_type:
                tensor_type = "input"
            with_rht = name == "nvfp4_rht_ue5m3" and tensor_type != "weight"
            return NVFP4Quantizer(
                scale_dtype=DType.kFloat8UE5M3,
                with_rht=with_rht,
                with_post_rht_amax=with_rht,
                with_2d_quantization=False,
                stochastic_rounding=False,
                with_random_sign_mask=False,
                disable_second_level_scale=tensor_type == "input",
            )

        recipe = transformer_engine.common.recipe.CustomRecipe(
            qfactory=make_nvfp4_ue5m3_quantizer,
            **recipe_kwargs,
        )
        recipe.enable_cutedsl_fused_grouped_mlp = True
        return recipe
    if name in nvfp4_variant_names:
        with_rht = name in ("nvfp4_rht", "nvfp4_rht_ue5m3")
        use_4over6 = name == "nvfp4_4over6"
        kwargs = {
            "disable_rht": not with_rht,
            "disable_stochastic_rounding": True,
            "disable_2d_quantization": not use_4over6,
            "row_scaled_activation": name == "nvfp4_row_scaled",
            "nvfp4_4over6": "all" if use_4over6 else "none",
        }
        kwargs.update(recipe_kwargs)
        return transformer_engine.common.recipe.NVFP4BlockScaling(**kwargs)
    raise ValueError(f"Unsupported quantization scheme ({name})")


def recipe_id(recipe: Optional[Recipe]) -> str:
    """Readable pytest id for a quantization recipe."""
    if not isinstance(recipe, Recipe):
        return "None"
    if recipe.nvfp4():
        nvfp4_features = []
        if recipe.row_scaled_activation:
            nvfp4_features.append("RowScaled")
        if recipe.nvfp4_4over6 != "none":
            nvfp4_features.append("4Over6")
        if not recipe.disable_rht:
            nvfp4_features.append("RHT")
        if recipe.fp8_format == RecipeFormat.UE5M3:
            nvfp4_features.append("UE5M3")
        if nvfp4_features:
            return f"NVFP4{''.join(nvfp4_features)}BlockScaling"
    return type(recipe).__name__


def skip_unsupported_backward_override(
    layer_type: str,
    quant_recipe: Optional[Recipe],
    backward_override: Optional[str],
) -> None:
    """Skip known unsupported layer/recipe/backward-override combinations used in tests."""
    if (
        quant_recipe is not None
        and quant_recipe.nvfp4()
        and getattr(quant_recipe, "row_scaled_activation", False)
        and backward_override is None
    ):
        pytest.skip("Row-scaled NVFP4 does not support default quantized backward.")
    if (
        quant_recipe is not None
        and quant_recipe.nvfp4()
        and quant_recipe.nvfp4_4over6 != "none"
        and layer_type == "grouped_linear"
    ):
        pytest.skip("NVFP4 4over6 currently does not support grouped quantization.")
    if backward_override is None:
        return
    if quant_recipe is None and backward_override is not None:
        pytest.skip(f"Not a quantized recipe, cannot use backward override {backward_override}.")
    if quant_recipe.delayed() and backward_override is not None:
        pytest.skip(f"Delayed scaling does not support backward override {backward_override}.")
    if layer_type in (
        "layernorm_mlp",
        "layernorm_mlp_nocheckpoint",
        "layernorm_mlp_checkpoint",
        "transformer",
        "transformer_layer",
    ):
        pytest.skip(f"{layer_type} does not support NVTE_BACKWARD_OVERRIDE={backward_override}.")


# Cached RNG state (torch CPU, torch CUDA, Python ``random``)
_rng_states: Optional[Tuple[torch.Tensor, torch.Tensor, Any]] = None


def reset_rng_states() -> None:
    """Revert to deterministic RNG state"""
    global _rng_states
    if _rng_states is None:
        torch.manual_seed(1234)
        torch.cuda.manual_seed(1234)
        random.seed(1234)
        _rng_states = (
            torch.get_rng_state(),
            torch.cuda.get_rng_state(),
            random.getstate(),
        )
    else:
        cpu_rng_state, cuda_rng_state, random_state = _rng_states
        torch.set_rng_state(cpu_rng_state)
        torch.cuda.set_rng_state(cuda_rng_state)
        random.setstate(random_state)


def compare_and_assert(a, b, name_a, name_b, atol, rtol, rmse_tol, is_fp8):
    if a is None and b is None:
        logging.debug(f"{name_a} vs {name_b}: both are None")
        return

    if not is_fp8:
        torch.testing.assert_close(a, b, atol=atol, rtol=rtol)
        return

    try:
        if a.dtype != b.dtype:
            a = a.to(b.dtype)
        torch.testing.assert_close(a, b, atol=atol, rtol=rtol)
    except Exception as e:
        logging.debug(e)

    rmse = torch.sqrt((a - b).square().mean()).item()
    logging.debug(name_a + " vs " + name_b + " RMSE: {:.6f}".format(rmse))
    rmse_range = max(a.max().item(), b.max().item()) - min(a.min().item(), b.min().item())
    assert rmse < rmse_tol * rmse_range, (
        name_a
        + " vs "
        + name_b
        + " RMSE {:.5f} is over tolerance {:.5f} ({:.5f} * {:.5f})".format(
            rmse, rmse_tol * rmse_range, rmse_tol, rmse_range
        )
    )


class ModelConfig:
    def __init__(
        self,
        batch_size: int,
        max_seqlen_q: int,
        num_heads: int,
        head_dim_qk: int,
        max_seqlen_kv: int = None,
        num_gqa_groups: int = None,
        head_dim_v: int = None,
        softmax_type: str = "vanilla",
        dropout_p: float = 0.0,
        attn_mask_type: str = "no_mask",
        attn_bias_type: str = "no_bias",
        alibi_type: str = "none",
        bias_shape: str = "1hss",
        window_size: Tuple[int, int] = (-1, -1),
        softcap: float = 0.0,
        context_parallel: bool = False,
        cp_comm_type: str = "p2p",
        return_max_logit=False,
        total_requests: int = None,
        max_ctx_len: int = None,
        num_layers: int = 1,
        eps: float = 1e-5,
        num_splits=1,
    ):
        self.batch_size = batch_size
        self.max_seqlen_q = max_seqlen_q
        self.max_seqlen_kv = max_seqlen_q if max_seqlen_kv is None else max_seqlen_kv
        self.num_heads = num_heads
        self.num_gqa_groups = num_heads if num_gqa_groups is None else num_gqa_groups
        self.head_dim_qk = head_dim_qk
        self.head_dim_v = head_dim_qk if head_dim_v is None else head_dim_v
        if self.head_dim_qk == self.head_dim_v:
            self.kv_channels = self.head_dim_qk
        else:
            self.kv_channels = (self.head_dim_qk, self.head_dim_v)
        self.hidden_size = self.num_heads * self.head_dim_qk
        self.hidden_size_kv = self.num_gqa_groups * self.head_dim_v
        self.softmax_type = softmax_type
        self.dropout_p = dropout_p
        self.attn_mask_type = attn_mask_type
        self.attn_bias_type = attn_bias_type
        self.alibi_type = alibi_type
        self.attn_type = "self" if (self.max_seqlen_q == self.max_seqlen_kv) else "cross"
        self.bias_shape = bias_shape
        self.window_size = check_set_window_size(self.attn_mask_type, window_size)
        self.bottom_right_diagonal = self.attn_mask_type not in {
            "causal",
            "padding_causal",
        }
        self.softcap = softcap
        self.context_parallel = context_parallel
        self.cp_comm_type = cp_comm_type
        self.return_max_logit = return_max_logit
        self.total_requests = total_requests
        self.max_ctx_len = max_ctx_len
        self.num_layers = num_layers
        self.eps = eps
        self.num_splits = num_splits


@contextmanager
def logging_context(highest_level=logging.WARNING):
    previous_level = logging.root.manager.disable
    logging.disable(highest_level)
    try:
        yield
    finally:
        logging.disable(previous_level)


def get_available_attention_backends(
    config: ModelConfig,
    qkv_dtype: torch.dtype,
    qkv_layout: str,
    nominal_dtype: Optional[torch.dtype] = None,
    pad_between_seqs: bool = False,
    deterministic: bool = False,
    fp8: bool = False,
    fp8_meta: Optional[Dict[str, Any]] = None,
    is_training: bool = True,
    inference_params: Optional[InferenceParams] = None,
    score_mod: bool = False,
    score_mod_bprop: bool = False,
    cp_size: int = 1,
    cp_size_a2a: int = 1,
    num_tokens_q: Optional[int] = None,
    num_tokens_kv: Optional[int] = None,
) -> Tuple[List, List]:
    """Check for all available attention backends that support a model configuration"""

    _, q_format, kv_format = get_qkv_format(qkv_layout, inference_params)
    if num_tokens_q is None:
        num_tokens_q = (
            max(config.batch_size * config.max_seqlen_q // cp_size, 1) if q_format == "thd" else 0
        )
    if num_tokens_kv is None:
        num_tokens_kv = (
            max(config.batch_size * config.max_seqlen_kv // cp_size, 1) if kv_format == "thd" else 0
        )

    os.environ["NVTE_FLASH_ATTN"] = "1"
    os.environ["NVTE_FUSED_ATTN"] = "1"
    os.environ["NVTE_UNFUSED_ATTN"] = "1"
    _attention_backends["backend_selection_requires_update"] = True
    alibi_slopes_shape = None
    if config.attn_bias_type == "alibi" and config.alibi_type == "custom":
        if config.bias_shape == "1hss":
            alibi_slopes_shape = [config.num_heads]
        if config.bias_shape == "bhss":
            alibi_slopes_shape = [config.batch_size, config.num_heads]

    core_attention_bias_shape = None
    if config.attn_bias_type == "post_scale_bias":
        b_dim, h_dim, sq_dim, skv_dim = config.bias_shape
        core_attention_bias_shape = (
            config.batch_size if b_dim == "b" else 1,
            config.num_heads if h_dim == "h" else 1,
            config.max_seqlen_q if sq_dim == "s" else 1,
            config.max_seqlen_kv if skv_dim == "s" else 1,
        )
    core_attention_bias_requires_grad = False
    # d=256 is supported by cuDNN 9.0+ for inference but not training
    if (
        config.attn_bias_type == "post_scale_bias"
        and config.head_dim_qk <= 128
        and config.head_dim_v <= 128
    ):
        # TODO(KshitijLakhani): Remove this guard when cuDNN starts support dbias calculation for bias shape 111s
        if config.bias_shape != "111s":
            core_attention_bias_requires_grad = True

    fused_attn_backends = []
    available_backends = None
    flash_attention_backend = None
    fused_attention_backend = None

    def test():
        attention_params = AttentionParams(
            qkv_dtype=qkv_dtype,
            nominal_dtype=nominal_dtype,
            qkv_layout=qkv_layout,
            batch_size=config.batch_size,
            num_heads=config.num_heads,
            num_gqa_groups=config.num_gqa_groups,
            max_seqlen_q=config.max_seqlen_q,
            max_seqlen_kv=config.max_seqlen_kv,
            head_dim_qk=config.head_dim_qk,
            head_dim_v=config.head_dim_v,
            num_tokens_q=num_tokens_q,
            num_tokens_kv=num_tokens_kv,
            attn_mask_type=config.attn_mask_type,
            window_size=config.window_size,
            bottom_right_diagonal=config.bottom_right_diagonal,
            softcap=config.softcap,
            alibi_slopes_shape=alibi_slopes_shape,
            core_attention_bias_type=config.attn_bias_type,
            core_attention_bias_shape=core_attention_bias_shape,
            core_attention_bias_requires_grad=core_attention_bias_requires_grad,
            pad_between_seqs=pad_between_seqs,
            attention_dropout=config.dropout_p,
            context_parallel=config.context_parallel,
            cp_comm_type=config.cp_comm_type,
            cp_size=cp_size,
            cp_size_a2a=cp_size_a2a,
            deterministic=deterministic,
            fp8=fp8,
            fp8_meta=fp8_meta,
            is_training=is_training,
            inference_params=inference_params,
            softmax_type=config.softmax_type,
            return_max_logit=config.return_max_logit,
            has_score_mod=score_mod,
            has_score_mod_bprop=score_mod_bprop,
            # allow all backends to pass so they can be used for testing;
            # check for FA3 availability later
            num_splits=1,
        )
        (
            use_flash_attention,
            flash_attention_backend,
            use_fused_attention,
            fused_attention_backend,
            use_unfused_attention,
            available_backends,
        ) = get_attention_backend(attention_params)
        # Check if FA3 is an available backend when num_splits != 1
        if available_backends[0]:
            if config.num_splits != 1 and not flash_attention_backend > PkgVersion("3.0.0b"):
                available_backends[0] = False
        # Set attention.py _attention_backends var using return value
        # from get_attention_backend()
        _attention_backends["use_flash_attention"] = use_flash_attention
        _attention_backends["use_fused_attention"] = use_fused_attention
        _attention_backends["flash_attention_backend"] = flash_attention_backend
        _attention_backends["fused_attention_backend"] = fused_attention_backend
        _attention_backends["use_unfused_attention"] = use_unfused_attention
        _attention_backends["backend_selection_requires_update"] = False
        return available_backends, flash_attention_backend, fused_attention_backend

    backends = {1: "F16_arbitrary_seqlen", 2: "FP8"}
    if AttentionLogging._is_logging_setup is False:
        AttentionLogging.setup_logging()

    _attention_backends["backend_selection_requires_update"] = True
    available_backends, flash_attention_backend, fused_attention_backend = test()
    if fused_attention_backend in (FusedAttnBackend[name] for name in backends.values()):
        fused_attn_backends.append(fused_attention_backend)
    return available_backends, flash_attention_backend, fused_attn_backends


@torch.no_grad
def assert_close(
    actual: Optional[torch.Tensor],
    expected: Optional[torch.Tensor],
    *,
    check_device: bool = False,
    check_dtype: bool = False,
    check_layout: bool = False,
    **kwargs,
) -> None:
    """Assert that two tensors are close.

    This function is a wrapper around torch.testing.assert_close. It
    changes the defaults for device and dtype checks (useful when the
    reference implementation is computed in high precision on CPU) and
    it can handle quantized tensors.

    """
    if isinstance(actual, QuantizedTensor):
        actual = actual.dequantize()
    if isinstance(expected, QuantizedTensor):
        expected = expected.dequantize()
    torch.testing.assert_close(
        actual,
        expected,
        check_device=check_device,
        check_dtype=check_dtype,
        check_layout=check_layout,
        **kwargs,
    )


def assert_close_grads(
    actual: Optional[torch.Tensor],
    expected: Optional[torch.Tensor],
    **kwargs,
) -> None:
    """Assert that two tensors have close gradients."""
    if actual is None and expected is None:
        return
    assert actual is not None
    assert expected is not None
    assert_close(actual.grad, expected.grad, **kwargs)


def assert_close_rms(
    actual: torch.Tensor,
    expected: torch.Tensor,
    *,
    rtol: float,
) -> None:
    """Assert that the RMS of ``actual - expected`` is within ``rtol`` of the RMS of ``expected``.

    Unlike an elementwise check, this is not dominated by the few elements that land in a
    different quantization bin, which makes it suitable for comparing quantized results.

    """
    if isinstance(actual, QuantizedTensor):
        actual = actual.dequantize()
    if isinstance(expected, QuantizedTensor):
        expected = expected.dequantize()
    actual = actual.double()
    expected = expected.double()
    error_rms = (actual - expected).square().mean().sqrt().item()
    expected_rms = expected.square().mean().sqrt().item()
    assert (
        error_rms <= rtol * expected_rms
    ), f"RMS error {error_rms:.4g} exceeds {rtol} * RMS of expected ({expected_rms:.4g})"


def run_distributed(
    args: Sequence[str],
    *,
    valid_returncodes: Sequence[int] = (0,),
    **kwargs,
) -> subprocess.CompletedProcess:
    """Run a distributed subprocess with stderr capture for better error reporting.

    stdout streams to the terminal in real time for interactive debugging.
    On failure, stderr (containing Python tracebacks) is included in the
    AssertionError so pytest writes it into the JUnit XML report.

    Args:
        args: Command and arguments to run.
        valid_returncodes: Return codes considered success (default: (0,)).
            Use (0, 5) for inner pytest runs where 5 means all tests skipped.
        **kwargs: Passed through to subprocess.run (e.g. env, timeout).
    """
    result = subprocess.run(args, stderr=subprocess.PIPE, text=True, **kwargs)
    if result.returncode not in valid_returncodes:
        cmd_str = " ".join(str(a) for a in args)
        msg = f"Command exited with code {result.returncode}:\n  {cmd_str}\n"
        if result.stderr:
            stderr_tail = result.stderr[-4000:]
            if len(result.stderr) > 4000:
                stderr_tail = "... [truncated] ...\n" + stderr_tail
            msg += f"\n--- stderr ---\n{stderr_tail}"
        raise AssertionError(msg)
    return result


class MegatronTrainingHelper:
    """Test-side stand-in for the Megatron-Core DDP / MegatronFSDP wrapper.
    Megatron's DDP wrapper (and MegatronFSDP) owns the per-parameter
    ``main_grad`` buffer and the ``overwrite_main_grad`` /
    ``grad_added_to_main_grad`` attributes that coordinate
    ``fuse_wgrad_accumulation`` with TE modules. These helpers reproduce the
    relevant slice of that protocol so TE tests can exercise the
    accumulate-into-``main_grad`` code path without pulling in the full
    Megatron-Core dependency.
    """

    @staticmethod
    def init_main_grad_buffers(
        weight_params: Iterable[torch.nn.Parameter],
        *,
        fill_value: float,
        overwrite_main_grad: bool,
        zero_out_wgrad: bool = False,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        """Allocate ``main_grad`` and stamp the wrapper attributes on each
        param, mirroring what the Megatron DDP/FSDP wrapper does before
        backward."""
        for wp in weight_params:
            wp.main_grad = torch.full(wp.size(), fill_value, device=wp.device, dtype=dtype)
            wp.overwrite_main_grad = overwrite_main_grad
            wp.zero_out_wgrad = zero_out_wgrad
            wp.grad_added_to_main_grad = False

    @staticmethod
    def verify_main_grad_accumulation(
        weight_params: Iterable[torch.nn.Parameter],
        *,
        expected_main_grads: Iterable[torch.Tensor],
        rtol: float = 0.0,
        atol: float = 0.0,
    ) -> None:
        """Check that backward produced what the Megatron wrapper expects:
        each ``main_grad`` matches ``expected_main_grads``,
        ``grad_added_to_main_grad`` was flipped to ``True`` so the wrapper's
        post-backward hooks won't double-accumulate, and ``param.grad`` was
        replaced by the cached dummy tensor (so a wrapper hook that did
        ``main_grad += grad`` would be a no-op rather than double-counting).
        """
        for wp, expected in zip(weight_params, expected_main_grads):
            torch.testing.assert_close(wp.main_grad.to(expected), expected, rtol=rtol, atol=atol)

            assert wp.grad_added_to_main_grad is True, (
                "weight.grad_added_to_main_grad was not flipped to True; "
                "the Megatron DDP/FSDP wrapper hook will double-accumulate."
            )

            # ``.grad`` should be the cached dummy tensor returned by
            # ``get_dummy_wgrad`` -- shared storage, not the real wgrad.
            expected_dummy = get_dummy_wgrad(list(wp.size()), wp.dtype)
            assert (
                wp.grad is not None
            ), "weight.grad is None; the Megatron protocol expects a dummy tensor stand-in here."
            assert wp.grad.data_ptr() == expected_dummy.data_ptr(), (
                "weight.grad does not share storage with the cached dummy "
                "wgrad; downstream wrapper hooks risk double-accumulating."
            )
            if getattr(wp, "zero_out_wgrad", False):
                assert torch.all(wp.grad == 0), (
                    "weight.zero_out_wgrad=True but the dummy weight.grad "
                    "was not zeroed; downstream hooks reading .grad would "
                    "see stale bytes from the previous step."
                )
