# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.

"""Unit tests for context parallel utils."""

import itertools
import torch
import unittest
from transformer_engine.pytorch import CPLoadBalancingStrategy
from transformer_engine.pytorch.attention.dot_product_attention.context_parallel import (
    _zero_thd_padding,
    get_batch_on_this_cp_rank,
    get_no_load_balance_thd_causal_metadata,
    get_thd_partitioned_indices,
    restore_thd_gathered_kv,
    unrestore_thd_gathered_kv,
    pad_thd_sequences_for_cp,
    generate_positional_ids_for_cp,
)
from transformer_engine.pytorch.attention.dot_product_attention.utils import get_thd_padding_mask

try:
    import transformer_engine_torch as tex
except ImportError:
    tex = None


class TestTHDPartitioning(unittest.TestCase):
    def test_default_partition_rejects_cpu_metadata(self):
        with self.assertRaisesRegex(AssertionError, "requires CUDA cu_seqlens"):
            get_thd_partitioned_indices(torch.tensor([0, 8]), 8, 2, 0)

    def test_no_load_balance_metadata_handles_document_padding_boundary(self):
        cu_seqlens = torch.tensor([0, 6, 10], dtype=torch.int32)
        cu_seqlens_padded = torch.tensor([0, 8, 12], dtype=torch.int32)

        q_cu, q_cu_padded, kv_cu = get_no_load_balance_thd_causal_metadata(
            cu_seqlens,
            cu_seqlens_padded,
            total_tokens=12,
            cp_size=2,
            cp_rank=1,
        )

        self.assertEqual(len(q_cu), 1)
        self.assertTrue(torch.equal(q_cu[0], torch.tensor([0, 0, 4], dtype=torch.int32)))
        self.assertTrue(torch.equal(q_cu_padded[0], torch.tensor([0, 2, 6], dtype=torch.int32)))
        self.assertTrue(torch.equal(kv_cu[0], torch.tensor([0, 6, 10], dtype=torch.int32)))

    def test_no_load_balance_restore_uses_captured_mode(self):
        tokens = torch.arange(8)
        cu_seqlens_padded = torch.tensor([0, 8], dtype=torch.int32)

        restored = restore_thd_gathered_kv(
            tokens,
            cu_seqlens_padded,
            2,
            CPLoadBalancingStrategy.NO_LOAD_BALANCE,
        )
        unrestored = unrestore_thd_gathered_kv(
            tokens,
            cu_seqlens_padded,
            2,
            CPLoadBalancingStrategy.NO_LOAD_BALANCE,
        )

        self.assertIs(restored, tokens)
        self.assertIs(unrestored, tokens)


class TestSequencePadding(unittest.TestCase):
    def test_padding_with_custom_padding_values_sequences_shorter_than_divisibility_factor(
        self,
    ):
        """Test with custom padding values for all tensors."""
        # Setup

        input_ids = torch.tensor([1, 1, 1, 2, 2, 3, 3, 3, 3])
        cu_seqlens = torch.tensor([0, 3, 5, 9])
        labels = torch.tensor([-100, -100, -100, -100, -100, -100, -100, 13, -100])
        positional_ids = torch.tensor([0, 1, 2, 0, 1, 0, 1, 2, 3])
        divisibility_factor = 8

        pid = 777
        label_pad = -200

        input_ids_padded, labels_padded, cu_seqlens_padded = pad_thd_sequences_for_cp(
            input_ids.unsqueeze(0),
            labels.unsqueeze(0),
            cu_seqlens,
            divisibility_factor,
            padding_token_id=pid,
            padding_label_id=label_pad,
        )

        positional_ids_padded = generate_positional_ids_for_cp(
            cu_seqlens,
            divisibility_factor,
        )

        # Sequence: [ a a a p p p p p b b pppppp ccccpppp]
        print("input_ids_padded: ", input_ids_padded)
        print("labels_padded: ", labels_padded)
        print("positional_ids_padded: ", positional_ids_padded)
        print("cu_seqlens_padded: ", cu_seqlens_padded)

        expected_input_ids = torch.tensor(
            [
                1,
                1,
                1,
                pid,
                pid,
                pid,
                pid,
                pid,
                2,
                2,
                pid,
                pid,
                pid,
                pid,
                pid,
                pid,
                3,
                3,
                3,
                3,
                pid,
                pid,
                pid,
                pid,
            ]
        )
        expected_cu_seqlens_padded = torch.tensor([0, 8, 16, 24])
        expected_labels_padded = torch.tensor(
            [
                -100,
                -100,
                -100,
                label_pad,
                label_pad,
                label_pad,
                label_pad,
                label_pad,
                -100,
                -100,
                label_pad,
                label_pad,
                label_pad,
                label_pad,
                label_pad,
                label_pad,
                -100,
                -100,
                13,
                -100,
                label_pad,
                label_pad,
                label_pad,
                label_pad,
            ]
        )
        expected_positional_ids = torch.tensor(
            [0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7]
        )

        assert torch.equal(input_ids_padded, expected_input_ids)
        assert torch.equal(labels_padded, expected_labels_padded)
        assert torch.equal(positional_ids_padded, expected_positional_ids)
        assert torch.equal(cu_seqlens_padded, expected_cu_seqlens_padded)

    def test_mixed_sequence_lengths_with_divisibility_factor(self):
        """Test with sequences both shorter and longer than divisibility factor."""
        # Setup - divisibility factor 6
        # Seq 1: length 2 (shorter than 6, needs 4 padding)
        # Seq 2: length 7 (longer than 6, needs 5 padding to reach 12)
        # Seq 3: length 4 (shorter than 6, needs 2 padding)
        # Seq 4: length 10 (longer than 6, needs 2 padding to reach 12)

        input_ids = torch.tensor(
            [1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]
        )
        labels = torch.tensor(
            [
                10,
                11,
                20,
                21,
                22,
                23,
                24,
                25,
                26,
                30,
                31,
                32,
                33,
                40,
                41,
                42,
                43,
                44,
                45,
                46,
                47,
                48,
                49,
            ]
        )
        positional_ids = torch.tensor(
            [0, 1, 0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        )
        cu_seqlens = torch.tensor([0, 2, 9, 13, 23])
        divisibility_factor = 6

        pid = 999
        label_pad = -300

        # Execute
        input_ids_padded, labels_padded, cu_seqlens_padded = pad_thd_sequences_for_cp(
            input_ids.unsqueeze(0),
            labels.unsqueeze(0),
            cu_seqlens,
            divisibility_factor,
            padding_token_id=pid,
            padding_label_id=label_pad,
        )

        positional_ids_padded = generate_positional_ids_for_cp(
            cu_seqlens,
            divisibility_factor,
        )

        # Assert
        # Seq 1: [1,1] + 4 pads = 6 total
        # Seq 2: [2,2,2,2,2,2,2] + 5 pads = 12 total
        # Seq 3: [3,3,3,3] + 2 pads = 6 total
        # Seq 4: [4,4,4,4,4,4,4,4,4,4] + 2 pads = 12 total

        expected_input_ids = torch.tensor(
            [
                1,
                1,
                pid,
                pid,
                pid,
                pid,  # Seq 1: 2 + 4 padding
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                pid,
                pid,
                pid,
                pid,
                pid,  # Seq 2: 7 + 5 padding
                3,
                3,
                3,
                3,
                pid,
                pid,  # Seq 3: 4 + 2 padding
                4,
                4,
                4,
                4,
                4,
                4,
                4,
                4,
                4,
                4,
                pid,
                pid,  # Seq 4: 10 + 2 padding
            ]
        )

        expected_labels = torch.tensor(
            [
                10,
                11,
                label_pad,
                label_pad,
                label_pad,
                label_pad,
                20,
                21,
                22,
                23,
                24,
                25,
                26,
                label_pad,
                label_pad,
                label_pad,
                label_pad,
                label_pad,
                30,
                31,
                32,
                33,
                label_pad,
                label_pad,
                40,
                41,
                42,
                43,
                44,
                45,
                46,
                47,
                48,
                49,
                label_pad,
                label_pad,
            ]
        )

        expected_positional_ids = torch.tensor(
            [
                0,
                1,
                2,
                3,
                4,
                5,  # Seq 1 positions continue through padding
                0,
                1,
                2,
                3,
                4,
                5,
                6,
                7,
                8,
                9,
                10,
                11,  # Seq 2 positions continue
                0,
                1,
                2,
                3,
                4,
                5,  # Seq 3 positions continue
                0,
                1,
                2,
                3,
                4,
                5,
                6,
                7,
                8,
                9,
                10,
                11,  # Seq 4 positions continue
            ]
        )

        expected_cu_seqlens_padded = torch.tensor([0, 6, 18, 24, 36])

        self.assertTrue(torch.equal(input_ids_padded, expected_input_ids))
        self.assertTrue(torch.equal(labels_padded, expected_labels))
        self.assertTrue(torch.equal(positional_ids_padded, expected_positional_ids))
        self.assertTrue(torch.equal(cu_seqlens_padded, expected_cu_seqlens_padded))

    def test_sequences_longer_than_divisibility_factor(self):
        """Test with all sequences longer than the divisibility factor."""
        # Setup - divisibility factor 4, all sequences longer than 4
        # Seq 1: length 7 (needs 1 padding to reach 8)
        # Seq 2: length 11 (needs 1 padding to reach 12)
        # Seq 3: length 5 (needs 3 padding to reach 8)

        input_ids = torch.tensor(
            [
                1,
                1,
                1,
                1,
                1,
                1,
                1,  # 7 tokens
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                2,  # 11 tokens
                3,
                3,
                3,
                3,
                3,  # 5 tokens
            ]
        )
        labels = torch.tensor(
            [
                100,
                101,
                102,
                103,
                104,
                105,
                106,
                200,
                201,
                202,
                203,
                204,
                205,
                206,
                207,
                208,
                209,
                210,
                300,
                301,
                302,
                303,
                304,
            ]
        )
        positional_ids = torch.tensor(
            [0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0, 1, 2, 3, 4]
        )
        cu_seqlens = torch.tensor([0, 7, 18, 23])
        divisibility_factor = 4

        pid = 888
        label_pad = -400

        # Execute
        input_ids_padded, labels_padded, cu_seqlens_padded = pad_thd_sequences_for_cp(
            input_ids.unsqueeze(0),
            labels.unsqueeze(0),
            cu_seqlens,
            divisibility_factor,
            padding_token_id=pid,
            padding_label_id=label_pad,
        )

        positional_ids_padded = generate_positional_ids_for_cp(
            cu_seqlens,
            divisibility_factor,
        )

        # Assert
        # Seq 1: 7 + 1 pad = 8 (divisible by 4)
        # Seq 2: 11 + 1 pad = 12 (divisible by 4)
        # Seq 3: 5 + 3 pads = 8 (divisible by 4)

        expected_input_ids = torch.tensor(
            [
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                pid,
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                pid,
                3,
                3,
                3,
                3,
                3,
                pid,
                pid,
                pid,
            ]
        )

        expected_labels = torch.tensor(
            [
                100,
                101,
                102,
                103,
                104,
                105,
                106,
                label_pad,
                200,
                201,
                202,
                203,
                204,
                205,
                206,
                207,
                208,
                209,
                210,
                label_pad,
                300,
                301,
                302,
                303,
                304,
                label_pad,
                label_pad,
                label_pad,
            ]
        )

        expected_positional_ids = torch.tensor(
            [
                0,
                1,
                2,
                3,
                4,
                5,
                6,
                7,
                0,
                1,
                2,
                3,
                4,
                5,
                6,
                7,
                8,
                9,
                10,
                11,
                0,
                1,
                2,
                3,
                4,
                5,
                6,
                7,
            ]
        )

        expected_cu_seqlens_padded = torch.tensor([0, 8, 20, 28])

        self.assertTrue(torch.equal(input_ids_padded, expected_input_ids))
        self.assertTrue(torch.equal(labels_padded, expected_labels))
        self.assertTrue(torch.equal(positional_ids_padded, expected_positional_ids))
        self.assertTrue(torch.equal(cu_seqlens_padded, expected_cu_seqlens_padded))


class TestContextParallelUtils(unittest.TestCase):
    """Test utilities for context parallel functionality."""

    def setUp(self):
        """Set up mock distributed environment."""
        # Mock torch.distributed functions
        self.original_get_world_size = torch.distributed.get_world_size
        self.original_get_rank = torch.distributed.get_rank

    def tearDown(self):
        """Restore original torch.distributed functions."""
        torch.distributed.get_world_size = self.original_get_world_size
        torch.distributed.get_rank = self.original_get_rank

    def _mock_distributed_env(self, cp_size, cp_rank):
        """Mock the distributed environment for testing."""

        def mock_get_world_size(group=None):
            return cp_size

        def mock_get_rank(group=None):
            return cp_rank

        torch.distributed.get_world_size = mock_get_world_size
        torch.distributed.get_rank = mock_get_rank

    def test_cp_rank_slicing_simple_case(self):
        """Test CP rank slicing with a simple 2-rank, single sequence case."""
        # Setup: Single sequence of length 8, CP size = 2
        # Each sequence gets divided into 2*cp_size = 4 slices of size 2 each
        # Rank 0 gets slices [0,1] and [6,7] (first and last)
        # Rank 1 gets slices [2,3] and [4,5] (second and second-to-last)

        input_ids = torch.tensor([[1, 2, 3, 4, 5, 6, 7, 8]])  # Shape: (1, 8) - batch first
        labels = torch.tensor([[10, 20, 30, 40, 50, 60, 70, 80]])
        position_ids = torch.tensor([0, 1, 2, 3, 4, 5, 6, 7])  # Shape: (8,) - 1D as expected
        cu_seqlens = torch.tensor([0, 8])

        # Test rank 0
        self._mock_distributed_env(cp_size=2, cp_rank=0)
        input_ids_r0, labels_r0, pos_ids_r0 = get_batch_on_this_cp_rank(
            cu_seqlens, input_ids, labels, position_ids
        )

        # Rank 0 should get indices [0,1] and [6,7]
        expected_input_ids_r0 = torch.tensor([[1, 2, 7, 8]])
        expected_labels_r0 = torch.tensor([[10, 20, 70, 80]])
        expected_pos_ids_r0 = torch.tensor([0, 1, 6, 7])

        self.assertTrue(torch.equal(input_ids_r0, expected_input_ids_r0))
        self.assertTrue(torch.equal(labels_r0, expected_labels_r0))
        self.assertTrue(torch.equal(pos_ids_r0, expected_pos_ids_r0))

        # Test rank 1
        self._mock_distributed_env(cp_size=2, cp_rank=1)
        input_ids_r1, labels_r1, pos_ids_r1 = get_batch_on_this_cp_rank(
            cu_seqlens, input_ids, labels, position_ids
        )

        # Rank 1 should get indices [2,3] and [4,5]
        expected_input_ids_r1 = torch.tensor([[3, 4, 5, 6]])
        expected_labels_r1 = torch.tensor([[30, 40, 50, 60]])
        expected_pos_ids_r1 = torch.tensor([2, 3, 4, 5])

        self.assertTrue(torch.equal(input_ids_r1, expected_input_ids_r1))
        self.assertTrue(torch.equal(labels_r1, expected_labels_r1))
        self.assertTrue(torch.equal(pos_ids_r1, expected_pos_ids_r1))

    @unittest.skipUnless(torch.cuda.is_available() and tex is not None, "CUDA extension required")
    def test_cp_rank_slicing_dual_chunk_swap_on_cuda(self):
        """CUDA inputs use the native DualChunkSwap partition indices."""
        input_ids = torch.arange(16, device="cuda").unsqueeze(0)
        labels = input_ids + 100
        position_ids = torch.arange(16, device="cuda")
        cu_seqlens = torch.tensor([0, 8, 16])

        self._mock_distributed_env(cp_size=2, cp_rank=0)
        input_ids_rank, labels_rank, position_ids_rank = get_batch_on_this_cp_rank(
            cu_seqlens, input_ids, labels, position_ids
        )

        expected_indices = torch.tensor([0, 1, 6, 7, 8, 9, 14, 15], device="cuda")
        self.assertTrue(torch.equal(input_ids_rank, input_ids.index_select(1, expected_indices)))
        self.assertTrue(torch.equal(labels_rank, labels.index_select(1, expected_indices)))
        self.assertTrue(
            torch.equal(position_ids_rank, position_ids.index_select(0, expected_indices))
        )

    def test_cp_rank_slicing_no_load_balance_on_cpu(self):
        """The experimental policy assigns one contiguous CPU chunk per rank."""
        input_ids = torch.arange(12).unsqueeze(0)
        labels = input_ids + 100
        position_ids = torch.arange(12)
        cu_seqlens = torch.tensor([0, 5, 12])

        self._mock_distributed_env(cp_size=4, cp_rank=2)
        input_ids_rank, labels_rank, position_ids_rank = get_batch_on_this_cp_rank(
            cu_seqlens,
            input_ids,
            labels,
            position_ids,
            load_balancing_strategy=CPLoadBalancingStrategy.NO_LOAD_BALANCE,
        )

        self.assertTrue(torch.equal(input_ids_rank, torch.tensor([[6, 7, 8]])))
        self.assertTrue(torch.equal(labels_rank, torch.tensor([[106, 107, 108]])))
        self.assertTrue(torch.equal(position_ids_rank, torch.tensor([6, 7, 8])))

    def test_cp_rank_slicing_multiple_sequences(self):
        """Test CP rank slicing with multiple sequences."""
        # Setup: Two sequences of length 8 each, CP size = 2
        # Total sequence length = 16, cu_seqlens = [0, 8, 16]

        input_ids = torch.tensor([[1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 18]])
        labels = torch.tensor(
            [[10, 20, 30, 40, 50, 60, 70, 80, 110, 120, 130, 140, 150, 160, 170, 180]]
        )
        position_ids = torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7])
        cu_seqlens = torch.tensor([0, 8, 16])

        # Test rank 0
        self._mock_distributed_env(cp_size=2, cp_rank=0)
        input_ids_r0, labels_r0, pos_ids_r0 = get_batch_on_this_cp_rank(
            cu_seqlens, input_ids, labels, position_ids
        )

        # For each sequence, rank 0 gets first and last slices
        # Seq 1: indices [0,1] and [6,7] -> values [1,2] and [7,8]
        # Seq 2: indices [8,9] and [14,15] -> values [11,12] and [17,18]
        expected_input_ids_r0 = torch.tensor([[1, 2, 7, 8, 11, 12, 17, 18]])
        expected_labels_r0 = torch.tensor([[10, 20, 70, 80, 110, 120, 170, 180]])
        expected_pos_ids_r0 = torch.tensor([0, 1, 6, 7, 0, 1, 6, 7])

        self.assertTrue(torch.equal(input_ids_r0, expected_input_ids_r0))
        self.assertTrue(torch.equal(labels_r0, expected_labels_r0))
        self.assertTrue(torch.equal(pos_ids_r0, expected_pos_ids_r0))

    def test_cp_rank_slicing_with_cp_size_1(self):
        """Test that CP size = 1 returns original tensors unchanged."""
        input_ids = torch.tensor([[1, 2, 3, 4, 5, 6, 7, 8]])
        labels = torch.tensor([[10, 20, 30, 40, 50, 60, 70, 80]])
        position_ids = torch.tensor([0, 1, 2, 3, 4, 5, 6, 7])
        cu_seqlens = torch.tensor([0, 8])

        self._mock_distributed_env(cp_size=1, cp_rank=0)
        input_ids_result, labels_result, pos_ids_result = get_batch_on_this_cp_rank(
            cu_seqlens, input_ids, labels, position_ids
        )

        # With CP size = 1, should return original tensors
        self.assertTrue(torch.equal(input_ids_result, input_ids))
        self.assertTrue(torch.equal(labels_result, labels))
        self.assertTrue(torch.equal(pos_ids_result, position_ids))

    def test_cp_rank_slicing_sequence_dim_detection(self):
        """Test that the function correctly detects sequence dimension."""
        # Test with sequence dimension = 0 (sequence_length, batch_size)
        input_ids = torch.tensor(
            [[1, 10], [2, 20], [3, 30], [4, 40], [5, 50], [6, 60], [7, 70], [8, 80]]
        )  # (8, 2)
        labels = torch.tensor(
            [[1, 10], [2, 20], [3, 30], [4, 40], [5, 50], [6, 60], [7, 70], [8, 80]]
        )
        position_ids = torch.tensor(
            [[0, 0], [1, 1], [2, 2], [3, 3], [4, 4], [5, 5], [6, 6], [7, 7]]
        )
        cu_seqlens = torch.tensor([0, 8])

        self._mock_distributed_env(cp_size=2, cp_rank=0)
        input_ids_r0, labels_r0, pos_ids_r0 = get_batch_on_this_cp_rank(
            cu_seqlens, input_ids, labels, position_ids
        )

        # Should get indices [0,1] and [6,7] along dimension 0
        expected_input_ids_r0 = torch.tensor([[1, 10], [2, 20], [7, 70], [8, 80]])
        expected_labels_r0 = torch.tensor([[1, 10], [2, 20], [7, 70], [8, 80]])
        expected_pos_ids_r0 = torch.tensor([[0, 0], [1, 1], [6, 6], [7, 7]])

        self.assertTrue(torch.equal(input_ids_r0, expected_input_ids_r0))
        self.assertTrue(torch.equal(labels_r0, expected_labels_r0))
        self.assertTrue(torch.equal(pos_ids_r0, expected_pos_ids_r0))

    def test_cp_rank_slicing_mixed_dimensions(self):
        """Test CP rank slicing where input_ids/labels are 1D but position_ids has batch dimension."""
        # Setup: Single sequence of length 8, CP size = 2
        # This tests the opposite case from the simple test:
        # - input_ids and labels: 1D (no batch dimension)
        # - position_ids: 2D (has batch dimension)

        input_ids = torch.tensor([1, 2, 3, 4, 5, 6, 7, 8])  # Shape: (8,) - 1D
        labels = torch.tensor([10, 20, 30, 40, 50, 60, 70, 80])  # Shape: (8,) - 1D
        position_ids = torch.tensor([[0, 1, 2, 3, 4, 5, 6, 7]])  # Shape: (1, 8) - 2D with batch
        cu_seqlens = torch.tensor([0, 8])

        # Test rank 0
        self._mock_distributed_env(cp_size=2, cp_rank=0)
        input_ids_r0, labels_r0, pos_ids_r0 = get_batch_on_this_cp_rank(
            cu_seqlens, input_ids, labels, position_ids
        )

        # Rank 0 should get indices [0,1] and [6,7]
        expected_input_ids_r0 = torch.tensor([1, 2, 7, 8])  # 1D result
        expected_labels_r0 = torch.tensor([10, 20, 70, 80])  # 1D result
        expected_pos_ids_r0 = torch.tensor([[0, 1, 6, 7]])  # 2D result (preserves batch dim)

        self.assertTrue(torch.equal(input_ids_r0, expected_input_ids_r0))
        self.assertTrue(torch.equal(labels_r0, expected_labels_r0))
        self.assertTrue(torch.equal(pos_ids_r0, expected_pos_ids_r0))

        # Test rank 1
        self._mock_distributed_env(cp_size=2, cp_rank=1)
        input_ids_r1, labels_r1, pos_ids_r1 = get_batch_on_this_cp_rank(
            cu_seqlens, input_ids, labels, position_ids
        )

        # Rank 1 should get indices [2,3] and [4,5]
        expected_input_ids_r1 = torch.tensor([3, 4, 5, 6])  # 1D result
        expected_labels_r1 = torch.tensor([30, 40, 50, 60])  # 1D result
        expected_pos_ids_r1 = torch.tensor([[2, 3, 4, 5]])  # 2D result (preserves batch dim)

        self.assertTrue(torch.equal(input_ids_r1, expected_input_ids_r1))
        self.assertTrue(torch.equal(labels_r1, expected_labels_r1))
        self.assertTrue(torch.equal(pos_ids_r1, expected_pos_ids_r1))

    def test_integration_with_padding_and_cp_slicing(self):
        """Integration test: pad sequences then slice for CP ranks."""
        # Start with unpadded sequences
        input_ids = torch.tensor([1, 1, 2, 2, 2])  # Two sequences: [1,1] and [2,2,2]
        labels = torch.tensor([10, 11, 20, 21, 22])
        positional_ids = torch.tensor([0, 1, 0, 1, 2])
        cu_seqlens = torch.tensor([0, 2, 5])
        divisibility_factor = 4  # Will pad to lengths 4 and 4

        # First, pad sequences
        input_ids_padded, labels_padded, cu_seqlens_padded = pad_thd_sequences_for_cp(
            input_ids.unsqueeze(0),
            labels.unsqueeze(0),
            cu_seqlens,
            divisibility_factor,
            padding_token_id=0,
            padding_label_id=-100,
        )

        positional_ids_padded = generate_positional_ids_for_cp(
            cu_seqlens,
            divisibility_factor,
        )

        # Expected after padding: [1,1,0,0,2,2,2,0] with cu_seqlens [0,4,8]
        expected_padded = torch.tensor([1, 1, 0, 0, 2, 2, 2, 0])
        self.assertTrue(torch.equal(input_ids_padded, expected_padded))

        # Now test CP slicing with cp_size=2

        # Test rank 0
        self._mock_distributed_env(cp_size=2, cp_rank=0)
        input_ids_r0, labels_r0, pos_ids_r0 = get_batch_on_this_cp_rank(
            cu_seqlens_padded,
            input_ids_padded.unsqueeze(0),
            labels_padded.unsqueeze(0),
            positional_ids_padded,
        )

        # Each sequence of length 4 gets divided into 4 slices of size 1
        # Rank 0 gets slices [0] and [3] from each sequence
        # Seq 1: indices [0] and [3] -> values [1] and [0]
        # Seq 2: indices [4] and [7] -> values [2] and [0]
        expected_input_ids_r0 = torch.tensor([[1, 0, 2, 0]])

        self.assertTrue(torch.equal(input_ids_r0, expected_input_ids_r0))


def _legacy_reorder_thd_to_cp_rank_order(x, cu_seqlens, cp_size, seq_dim=0):
    total_slices_of_any_sequence = 2 * cp_size
    slice_sizes = (cu_seqlens[1:] - cu_seqlens[:-1]) // total_slices_of_any_sequence

    indices = [
        (
            torch.arange(
                seq_start + (cp_rank * slice_size),
                seq_start + ((cp_rank + 1) * slice_size),
                device=cu_seqlens.device,
            ),
            torch.arange(
                seq_start + ((total_slices_of_any_sequence - cp_rank - 1) * slice_size),
                seq_start + ((total_slices_of_any_sequence - cp_rank) * slice_size),
                device=cu_seqlens.device,
            ),
        )
        for cp_rank in range(cp_size)
        for slice_size, seq_start in zip(slice_sizes, cu_seqlens[:-1])
    ]

    indices = list(itertools.chain(*indices))
    indices = torch.cat(indices)
    return x.index_select(seq_dim, indices)


def _legacy_reorder_thd_to_sequence_order(x, cu_seqlens, seq_chunk_ids, cp_size, seq_dim=0):
    max_cum_seqlen_per_cp_rank = cu_seqlens[-1] // cp_size
    cu_seqlens_on_any_cp_rank = cu_seqlens // cp_size

    indices = [
        torch.arange(
            (
                start + max_cum_seqlen_per_cp_rank * (chunk_id // 2)
                if loc < cp_size
                else (start + end) // 2 + max_cum_seqlen_per_cp_rank * (chunk_id // 2)
            ),
            (
                (start + end) // 2 + max_cum_seqlen_per_cp_rank * (chunk_id // 2)
                if loc < cp_size
                else end + max_cum_seqlen_per_cp_rank * (chunk_id // 2)
            ),
            device=cu_seqlens.device,
        )
        for start, end in zip(cu_seqlens_on_any_cp_rank[:-1], cu_seqlens_on_any_cp_rank[1:])
        for loc, chunk_id in enumerate(seq_chunk_ids)
    ]

    indices = torch.cat(indices)
    return x.index_select(seq_dim, indices)


def _legacy_valid_copy(out, inp, cu_seqlens_padded, cu_seqlens):
    batch_size = cu_seqlens.shape[0] - 1
    for b in range(batch_size):
        s = cu_seqlens_padded[b].item()
        sz = (cu_seqlens[b + 1] - cu_seqlens[b]).item()
        if sz > 0:
            out[s : s + sz].copy_(inp[s : s + sz])


@unittest.skipIf(not torch.cuda.is_available(), "THD padding-mask tests require CUDA")
class TestTHDPaddingMask(unittest.TestCase):
    @staticmethod
    def _reference_mask(cu_seqlens, cu_seqlens_padded):
        mask = torch.ones(cu_seqlens_padded[-1].item(), dtype=torch.bool)
        for batch_idx in range(cu_seqlens.numel() - 1):
            start = cu_seqlens_padded[batch_idx].item()
            length = (cu_seqlens[batch_idx + 1] - cu_seqlens[batch_idx]).item()
            mask[start : start + length] = False
        return mask.cuda()

    def test_matches_reference_across_batch_sizes_and_q_kv_layouts(self):
        for batch_size in (2, 8, 32, 128):
            with self.subTest(batch_size=batch_size):
                sequence = torch.arange(batch_size, dtype=torch.int32)
                layouts = (
                    (17 + sequence % 7, torch.full_like(sequence, 32)),
                    (9 + sequence * 3 % 11, torch.full_like(sequence, 24)),
                )
                for seqlens, padded_seqlens in layouts:
                    cu_seqlens = torch.cat((torch.zeros(1, dtype=torch.int32), seqlens.cumsum(0)))
                    cu_seqlens_padded = torch.cat(
                        (torch.zeros(1, dtype=torch.int32), padded_seqlens.cumsum(0))
                    )
                    expected = self._reference_mask(cu_seqlens, cu_seqlens_padded)
                    cu_seqlens = cu_seqlens.cuda()
                    cu_seqlens_padded = cu_seqlens_padded.cuda()
                    actual = get_thd_padding_mask(expected.numel(), cu_seqlens, cu_seqlens_padded)
                    self.assertTrue(torch.equal(actual, expected))

    def test_zeroes_padding_without_changing_valid_rows(self):
        cu_seqlens = torch.tensor([0, 3, 8], dtype=torch.int32)
        cu_seqlens_padded = torch.tensor([0, 4, 12], dtype=torch.int32)
        padding_mask = self._reference_mask(cu_seqlens, cu_seqlens_padded)
        cu_seqlens = cu_seqlens.cuda()
        cu_seqlens_padded = cu_seqlens_padded.cuda()

        tensors = tuple(
            torch.arange(1, 25, dtype=torch.float32, device="cuda").view(12, 2) + offset
            for offset in (0, 100)
        )
        originals = tuple(tensor.clone() for tensor in tensors)

        _zero_thd_padding(tensors, cu_seqlens, cu_seqlens_padded)

        for tensor, original in zip(tensors, originals):
            self.assertTrue(torch.equal(tensor[~padding_mask], original[~padding_mask]))
            self.assertEqual(torch.count_nonzero(tensor[padding_mask]).item(), 0)

    def test_zero_padding_is_cuda_graph_safe(self):
        cu_seqlens = torch.tensor([0, 3, 8], dtype=torch.int32, device="cuda")
        cu_seqlens_padded = torch.tensor([0, 4, 12], dtype=torch.int32, device="cuda")
        tensors = tuple(torch.ones((12, 2), dtype=torch.float32, device="cuda") for _ in range(2))

        side_stream = torch.cuda.Stream()
        side_stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side_stream):
            _zero_thd_padding(tensors, cu_seqlens, cu_seqlens_padded)
        torch.cuda.current_stream().wait_stream(side_stream)
        torch.cuda.synchronize()

        for tensor in tensors:
            tensor.fill_(1)
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            _zero_thd_padding(tensors, cu_seqlens, cu_seqlens_padded)

        for tensor in tensors:
            tensor.fill_(1)
        graph.replay()
        torch.cuda.synchronize()

        padding_mask = get_thd_padding_mask(12, cu_seqlens, cu_seqlens_padded)
        for tensor in tensors:
            self.assertEqual(torch.count_nonzero(tensor[padding_mask]).item(), 0)
            self.assertTrue(torch.all(tensor[~padding_mask] == 1))


@unittest.skipIf(
    not torch.cuda.is_available() or tex is None,
    "THD kernel tests require CUDA and transformer_engine_torch",
)
class TestTHDKernels(unittest.TestCase):
    def test_thd_sequence_cp_rank_order_roundtrip_matches_legacy_python_reorder(self):
        cp_size = 4
        cu_seqlens = torch.tensor([0, 8, 24, 40], dtype=torch.int32, device="cuda")
        x = torch.arange(40 * 2 * 4, dtype=torch.float16, device="cuda").view(40, 2, 4)

        cp_rank_order = tex.thd_sequence_order_to_cp_rank_order(x, cu_seqlens, cp_size, x.shape[0])
        ref_cp_rank_order = _legacy_reorder_thd_to_cp_rank_order(x, cu_seqlens, cp_size)
        self.assertTrue(torch.equal(cp_rank_order, ref_cp_rank_order))

        seq_chunk_ids = torch.empty(2 * cp_size, dtype=torch.int32, device="cuda")
        for rank in range(cp_size):
            seq_chunk_ids[rank] = 2 * rank
            seq_chunk_ids[rank + cp_size] = 2 * cp_size - 2 * rank - 1
        sequence_order = tex.thd_cp_rank_order_to_sequence_order(
            cp_rank_order, cu_seqlens, cp_size, cp_rank_order.shape[0]
        )
        ref_sequence_order = _legacy_reorder_thd_to_sequence_order(
            cp_rank_order, cu_seqlens, seq_chunk_ids, cp_size
        )
        self.assertTrue(torch.equal(sequence_order, ref_sequence_order))
        self.assertTrue(torch.equal(sequence_order, x))

    def test_thd_get_partitioned_indices_matches_dual_chunk_expected_indices(self):
        cu_seqlens = torch.tensor([0, 8, 16], dtype=torch.int32, device="cuda")

        rank0 = tex.thd_get_partitioned_indices(cu_seqlens, 16, 2, 0)
        rank1 = tex.thd_get_partitioned_indices(cu_seqlens, 16, 2, 1)

        expected_rank0 = torch.tensor([0, 1, 6, 7, 8, 9, 14, 15], dtype=torch.int32, device="cuda")
        expected_rank1 = torch.tensor(
            [2, 3, 4, 5, 10, 11, 12, 13], dtype=torch.int32, device="cuda"
        )
        self.assertTrue(torch.equal(rank0, expected_rank0))
        self.assertTrue(torch.equal(rank1, expected_rank1))

    def test_thd_get_partitioned_indices_shared_memory_boundary(self):
        props = torch.cuda.get_device_properties(torch.cuda.current_device())
        if not hasattr(props, "shared_memory_per_block"):
            self.skipTest(f"PyTorch {torch.__version__} does not expose shared-memory limits")
        max_shared_docs = props.shared_memory_per_block // 4 - 1
        for documents in (max_shared_docs, max_shared_docs + 1):
            for cp_size in (2, 4):
                cu_seqlens = torch.arange(documents + 1, device="cuda", dtype=torch.int32)
                cu_seqlens *= 2 * cp_size
                tokens = torch.arange(
                    documents * 2 * cp_size, device="cuda", dtype=torch.int32
                ).view(documents, 2 * cp_size)
                for rank in range(cp_size):
                    with self.subTest(documents=documents, cp_size=cp_size, rank=rank):
                        indices = tex.thd_get_partitioned_indices(
                            cu_seqlens, tokens.numel(), cp_size, rank
                        )
                        expected = tokens[:, [rank, 2 * cp_size - 1 - rank]].reshape(-1)
                        torch.cuda.synchronize()
                        self.assertTrue(torch.equal(indices, expected))

    def test_thd_kernels_shared_memory_boundary(self):
        props = torch.cuda.get_device_properties(torch.cuda.current_device())
        if not hasattr(props, "shared_memory_per_block"):
            self.skipTest(f"PyTorch {torch.__version__} does not expose shared-memory limits")
        for tables in (1, 2):
            bytes_per_document = 4 * tables
            for documents in (
                props.shared_memory_per_block // bytes_per_document - 1,
                props.shared_memory_per_block // bytes_per_document,
            ):
                with self.subTest(tables=tables, documents=documents):
                    cu = torch.arange(documents + 1, dtype=torch.int32, device="cuda") * 4
                    total = documents * 4
                    x = torch.arange(total * 4, dtype=torch.float32, device="cuda").view(
                        total, 1, 4
                    )
                    docs = x.view(documents, 4, 1, 4)
                    if tables == 2:
                        out = torch.full_like(x, -1)
                        expected = out.clone().view_as(docs)
                        expected[:, :2] = docs[:, :2]
                        tex.thd_copy_valid_tokens_from_per_split_to_rank_local(out, x, cu, cu // 2)
                        self.assertTrue(torch.equal(out, expected.reshape_as(out)))
                        continue

                    reordered = tex.thd_sequence_order_to_cp_rank_order(x, cu, 2, total)
                    expected = torch.cat(
                        [docs[:, [rank, 3 - rank]].reshape(-1, 1, 4) for rank in range(2)]
                    )
                    self.assertTrue(torch.equal(reordered, expected))
                    restored = tex.thd_cp_rank_order_to_sequence_order(reordered, cu, 2, total)
                    self.assertTrue(torch.equal(restored, x))
                    for half in (0, 1):
                        actual = tex.thd_read_half_tensor(x, cu, half)
                        expected = docs[:, 2 * half : 2 * half + 2].reshape_as(actual)
                        self.assertTrue(torch.equal(actual, expected))

                    for packed in (False, True):
                        shape = (1, total) if packed else (documents, 1, 4)
                        half_shape = (1, total // 2) if packed else (documents, 1, 2)
                        lse = torch.arange(total, dtype=torch.float32, device="cuda").view(shape)
                        lse /= total
                        half_lse = tex.thd_read_second_half_lse(
                            lse, cu, packed, total // 2 if packed else 2
                        )
                        expected_half = lse.reshape(documents, 4)[:, 2:].reshape(half_shape)
                        self.assertTrue(torch.equal(half_lse, expected_half))
                        expected = lse.clone()
                        expected.reshape(documents, 4)[:, 2:] = torch.logaddexp(
                            expected_half.reshape(documents, 2),
                            torch.zeros_like(expected_half).reshape(documents, 2),
                        )
                        tex.thd_second_half_lse_correction(
                            lse, torch.zeros_like(half_lse), cu, packed
                        )
                        torch.testing.assert_close(lse, expected)

                        for second_half in (False, True):
                            out = torch.full_like(x, 3)
                            step = torch.ones_like(x[: total // (2 if second_half else 1)])
                            old_lse = torch.full(shape, 0.5, device="cuda").log()
                            expected = out.clone().view_as(docs)
                            expected[:, 2 if second_half else 0 :] *= 0.5
                            expected[:, 2 if second_half else 0 :] += 1
                            tex.thd_out_correction(
                                out,
                                step,
                                old_lse,
                                torch.zeros(shape, device="cuda"),
                                torch.zeros(half_shape if second_half else shape, device="cuda"),
                                cu,
                                second_half,
                                packed,
                            )
                            torch.testing.assert_close(out, expected.reshape_as(out))

                    grad = x.clone()
                    tex.thd_grad_correction(grad, torch.ones_like(x), cu, "add", "copy")
                    expected = docs.clone()
                    expected[:, :2] += 1
                    expected[:, 2:] = 1
                    self.assertTrue(torch.equal(grad, expected.reshape_as(grad)))
                    grad.fill_(-1)
                    tex.thd_grad_correction(grad, x[: total // 2], cu, "copy", "zero")
                    expected.zero_()
                    expected[:, :2] = x[: total // 2].view(documents, 2, 1, 4)
                    torch.cuda.synchronize()
                    self.assertTrue(torch.equal(grad, expected.reshape_as(grad)))

    def test_thd_copy_valid_tokens_from_per_split_matches_legacy_slice_copy_loop(self):
        cu_seqlens_padded = torch.tensor([2, 6, 12], dtype=torch.int32, device="cuda")
        cu_seqlens = torch.tensor([0, 3, 7], dtype=torch.int32, device="cuda")
        inp = torch.arange(12 * 2 * 4, dtype=torch.float16, device="cuda").view(12, 2, 4)
        out = torch.full_like(inp, -1)
        expected = torch.full_like(inp, -1)

        _legacy_valid_copy(expected, inp, cu_seqlens_padded, cu_seqlens)
        tex.thd_copy_valid_tokens_from_per_split_to_rank_local(
            out, inp, cu_seqlens_padded, cu_seqlens
        )
        self.assertTrue(torch.equal(out, expected))

    def test_thd_read_half_tensor_reads_each_sequence_half(self):
        cu_seqlens = torch.tensor([0, 8, 16], dtype=torch.int32, device="cuda")
        q = torch.arange(16 * 2 * 4, dtype=torch.float16, device="cuda").view(16, 2, 4)
        kv = torch.arange(2 * 16 * 2 * 4, dtype=torch.float16, device="cuda").view(2, 16, 2, 4)

        q_first = tex.thd_read_half_tensor(q, cu_seqlens, 0)
        q_second = tex.thd_read_half_tensor(q, cu_seqlens, 1)
        kv_first = tex.thd_read_half_tensor(kv, cu_seqlens, 0)
        kv_second = tex.thd_read_half_tensor(kv, cu_seqlens, 1)

        expected_first = torch.cat([q[0:4], q[8:12]], dim=0)
        expected_second = torch.cat([q[4:8], q[12:16]], dim=0)
        self.assertTrue(torch.equal(q_first, expected_first))
        self.assertTrue(torch.equal(q_second, expected_second))
        self.assertTrue(torch.equal(kv_first, torch.stack([expected_first, expected_first + 128])))
        self.assertTrue(
            torch.equal(kv_second, torch.stack([expected_second, expected_second + 128]))
        )

    def test_thd_grad_correction_copies_byte_half_and_zeros_inactive_half(self):
        cu_seqlens = torch.tensor([0, 8, 20], dtype=torch.int32, device="cuda")
        grad_per_step = torch.arange(10 * 2 * 8, dtype=torch.uint8, device="cuda").view(10, 2, 8)
        first_half_rows = torch.tensor([0, 1, 2, 3, 8, 9, 10, 11, 12, 13], device="cuda")
        second_half_rows = torch.tensor([4, 5, 6, 7, 14, 15, 16, 17, 18, 19], device="cuda")

        grad = torch.full((20, 2, 8), 255, dtype=torch.uint8, device="cuda")
        tex.thd_grad_correction(grad, grad_per_step, cu_seqlens, "copy", "zero")
        self.assertTrue(torch.equal(grad[first_half_rows], grad_per_step))
        self.assertEqual(torch.count_nonzero(grad[second_half_rows]).item(), 0)

        grad.fill_(255)
        tex.thd_grad_correction(grad, grad_per_step, cu_seqlens, "zero", "copy")
        self.assertEqual(torch.count_nonzero(grad[first_half_rows]).item(), 0)
        self.assertTrue(torch.equal(grad[second_half_rows], grad_per_step))

    def test_thd_read_second_half_lse_handles_packed_and_batch_major_lse(self):
        cu_seqlens = torch.tensor([0, 8, 16], dtype=torch.int32, device="cuda")
        lse = torch.arange(2 * 2 * 8, dtype=torch.float32, device="cuda").view(2, 2, 8)
        packed_lse = torch.arange(2 * 16, dtype=torch.float32, device="cuda").view(2, 16)

        second_half_lse = tex.thd_read_second_half_lse(lse, cu_seqlens, False, 4)
        packed_second_half_lse = tex.thd_read_second_half_lse(packed_lse, cu_seqlens, True, 8)

        expected = lse[:, :, 4:8]
        expected_packed = torch.cat([packed_lse[:, 4:8], packed_lse[:, 12:16]], dim=1)
        self.assertTrue(torch.equal(second_half_lse, expected))
        self.assertTrue(torch.equal(packed_second_half_lse, expected_packed))


if __name__ == "__main__":
    unittest.main()
