# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.
import collections
import logging
import os
import re
import subprocess
import sys
import pathlib
import copy
from dataclasses import replace
from typing import Any, Dict, List, NamedTuple, Tuple, Union

from packaging.version import Version as PkgVersion
import pytest
import torch

from transformer_engine.pytorch.quantization import FP8GlobalStateManager, get_fp8_te_dtype
from transformer_engine.common import recipe
from transformer_engine.pytorch import (
    TransformerLayer,
    autocast,
    quantized_model_init,
    DotProductAttention,
    MultiheadAttention,
    get_device_compute_capability,
    Quantizer,
    is_fp8_available,
    is_bf16_available,
)
from transformer_engine.pytorch.attention.dot_product_attention import (
    _attention_backends,
)
from transformer_engine.pytorch.attention.dot_product_attention.utils import (
    AttentionParams,
    FlashAttentionUtils,
    FusedAttentionParams,
    _get_supported_versions,
    check_set_window_size,
    get_attention_backend,
    get_fused_attn_spec,
    get_thd_padding_mask,
)
from transformer_engine.pytorch.attention import RotaryPositionEmbedding
import transformer_engine.pytorch.cpp_extensions as ext
from transformer_engine.pytorch.cpp_extensions.fused_attn import (
    FusedAttnBackend,
    QKVFormat,
    QKVLayout,
    fused_attn_bwd,
    fused_attn_fwd,
)
from transformer_engine.pytorch.distributed import CudaRNGStatesTracker
from transformer_engine.pytorch.module.base import TransformerEngineBaseModule
from transformer_engine.pytorch.utils import (
    init_method_normal,
    scaled_init_method_normal,
)
from transformer_engine.pytorch.utils import get_cudnn_version
from transformer_engine.pytorch.constants import FP8BwdTensorIdx, FP8FwdTensorIdx
import transformer_engine_torch as tex
from transformer_engine.pytorch.quantized_tensor import (
    Quantizer,
    prepare_for_saving,
    restore_from_func_ctx,
)

_current_file = pathlib.Path(__file__).resolve()
sys.path = [str(_current_file.parent.parent)] + sys.path
from utils import (
    reset_rng_states,
    compare_and_assert,
    ModelConfig,
    dtype_tols,
    get_available_attention_backends,
)

# Check if hardware supports FP8 attention.
fp8_available, reason_for_no_fp8 = is_fp8_available(return_reason=True)
fp8_attn_available, reason_for_no_fp8_attn = fp8_available, reason_for_no_fp8
device_compute_capability = get_device_compute_capability()
if fp8_available and (device_compute_capability < (9, 0) or device_compute_capability >= (12, 0)):
    fp8_attn_available = False
    reason_for_no_fp8_attn = (
        "FP8 attention is not supported for compute capability ="
        f" sm{device_compute_capability[0] * 10 + device_compute_capability[1]}"
    )


# Get determinism
_deterministic = (
    not bool(int(os.getenv("NVTE_ALLOW_NONDETERMINISTIC_ALGO", "1")))
    or torch.are_deterministic_algorithms_enabled()
)


# Reset RNG seed and states
seed = 1234
reset_rng_states()


# Reset FP8 global state manager
@pytest.fixture(autouse=True)
def reset_global_fp8_state():
    yield
    FP8GlobalStateManager.reset()


@pytest.mark.parametrize(
    "version,expected",
    (
        ("2.1.0", False),
        ("2.1.1", True),
        ("2.8.3", True),
        ("2.8.3+local_version", True),
        ("2.8.3.post1", True),
        ("2.8.4", True),
        ("2.8.4+local_version", True),
        ("2.8.5", False),
        ("2.8.5+local_version", False),
        ("2.9.0", False),
    ),
)
def test_flash_attention_version_support(version, expected):
    """Test the supported Flash Attention v2 version range."""
    assert (
        FlashAttentionUtils.is_version_supported(
            PkgVersion(version), FlashAttentionUtils.version_required
        )
        is expected
    )


def test_flash_attention_supported_version_message():
    """Test that the supported version range describes an exclusive upper bound."""
    assert (
        _get_supported_versions(
            FlashAttentionUtils.version_required, FlashAttentionUtils.max_version
        )
        == ">= 2.1.1, < 2.8.5"
    )


def test_fused_attn_backend_message():
    """Test the error messaging of the fused attention backend query."""
    baseline = FusedAttentionParams(
        qkv_layout=tex.NVTE_QKV_Layout.NVTE_BSHD_BSHD_BSHD,
        dqkv_layout=tex.NVTE_QKV_Layout.NVTE_BSHD_BSHD_BSHD,
        o_format=tex.NVTE_QKV_Format.NVTE_BSHD,
        do_format=tex.NVTE_QKV_Format.NVTE_BSHD,
        batch_size=2,
        num_attn_heads=8,
        num_gqa_groups=8,
        head_dim_qk=64,
        head_dim_v=64,
        max_seqlen_q=128,
        max_seqlen_kv=128,
        attn_scale=0.125,
    )

    # One of TE's rules is violated and the error message is surfaced
    backend, message = tex.get_fused_attn_backend(
        replace(baseline, bias_type=tex.NVTE_Bias_Type.NVTE_PRE_SCALE_BIAS)
    )
    assert backend == tex.NVTE_Fused_Attn_Backend.NVTE_No_Backend
    assert message == "Fused attention does not support pre-scale bias."

    # No error message if supported; otherwise skip the test
    backend, message = tex.get_fused_attn_backend(baseline)
    if backend == tex.NVTE_Fused_Attn_Backend.NVTE_No_Backend:
        pytest.skip(f"FusedAttention does not support the baseline config: {message}")
    assert message == ""

    # All TE rules have cleared; now gets rejected by cuDNN's support check
    # cuDNN's error message might change across cuDNN versions, so only verify the presence of the string
    backend, message = tex.get_fused_attn_backend(
        replace(baseline, head_dim_qk=1024, head_dim_v=1024)
    )
    assert backend == tex.NVTE_Fused_Attn_Backend.NVTE_No_Backend
    assert message != ""

    if not fp8_attn_available:
        return

    # The same checks in FP8; the dtypes, formats and scaling mode come from get_fused_attn_spec so
    # that the config matches what FusedAttnFunc feeds the kernels for this recipe
    fp8_recipe = recipe.DelayedScaling(fp8_format=recipe.Format.HYBRID, fp8_dpa=True)
    spec = get_fused_attn_spec(fp8_recipe, torch.float8_e4m3fn, "bshd_bshd_bshd", cs_o_in_f16=True)
    fp8_baseline = replace(
        baseline,
        scaling_mode=spec.scaling_mode,
        qkv_dtype=spec.qkv,
        o_dtype=spec.o,
        do_dtype=spec.do,
        dqkv_dtype=spec.dqkv,
        qkv_layout=QKVLayout[spec.qkv_layout],
        o_format=QKVFormat[spec.o_format],
        do_format=QKVFormat[spec.do_format],
        dqkv_layout=QKVLayout[spec.dqkv_layout],
        qkv_scale_inv_format=QKVFormat[spec.scale_inv_format],
        do_scale_inv_format=QKVFormat[spec.scale_inv_format],
    )

    # No error message if supported; otherwise skip the test
    backend, message = tex.get_fused_attn_backend(fp8_baseline)
    if backend == tex.NVTE_Fused_Attn_Backend.NVTE_No_Backend:
        pytest.skip(f"FusedAttention does not support the baseline FP8 config: {message}")
    assert backend == tex.NVTE_Fused_Attn_Backend.NVTE_FP8
    assert message == ""

    # All TE FP8 rules have cleared; now gets rejected by cuDNN's FP8 support check
    backend, message = tex.get_fused_attn_backend(
        replace(fp8_baseline, head_dim_qk=1024, head_dim_v=1024)
    )
    assert backend == tex.NVTE_Fused_Attn_Backend.NVTE_No_Backend
    assert message != ""


@pytest.mark.parametrize(
    "cu_seqlens,cu_seqlens_padded,expected",
    [
        ([0, 3, 8], [0, 4, 12], [False] * 3 + [True] + [False] * 5 + [True] * 3),
        ([0, 3, 8], [0, 4, 12], [False] * 3 + [True] + [False] * 5 + [True] * 7),
        ([0, 3, 8], [0, 3, 8], [False] * 8 + [True] * 4),
        ([0, 0, 3, 3, 5], [0, 0, 4, 4, 8], [False] * 3 + [True] + [False] * 2 + [True] * 4),
    ],
)
def test_thd_padding_mask_capacity(cu_seqlens, cu_seqlens_padded, expected):
    """Cover sequence gaps, reserved buffer tails, and zero-length sequences."""
    actual = get_thd_padding_mask(
        len(expected),
        torch.tensor(cu_seqlens, dtype=torch.int32, device="cuda"),
        torch.tensor(cu_seqlens_padded, dtype=torch.int32, device="cuda"),
    )
    torch.testing.assert_close(actual, torch.tensor(expected, dtype=torch.bool, device="cuda"))


@pytest.mark.parametrize("fa_version", [3, 4])
def test_dpa_flash_thd_padding_capacity_cuda_graph(fa_version, monkeypatch):
    """Check padded outputs and gradients, including buffer tails, without CP.

    This regression exercises eager execution and raw CUDA Graph capture. CP graph
    capture uses TE's make_graphed_callables and is outside this test's scope.
    """
    for key, value in {
        "NVTE_FLASH_ATTN": "1",
        "NVTE_FUSED_ATTN": "0",
        "NVTE_UNFUSED_ATTN": "0",
        "NVTE_FLASH_ATTN_V2": "0",
        "NVTE_FLASH_ATTN_V3": str(int(fa_version == 3)),
        "NVTE_FLASH_ATTN_V4": str(int(fa_version == 4)),
    }.items():
        monkeypatch.setenv(key, value)
    use_flash_attention, flash_attention_backend, *_ = get_attention_backend(
        AttentionParams(
            qkv_dtype=torch.bfloat16,
            qkv_layout="thd_thd_thd",
            batch_size=2,
            num_heads=4,
            num_gqa_groups=4,
            max_seqlen_q=128,
            max_seqlen_kv=128,
            num_tokens_q=128,
            num_tokens_kv=192,
            head_dim_qk=64,
            head_dim_v=64,
            attn_mask_type="padding",
            window_size=(-1, -1),
            core_attention_bias_requires_grad=False,
            pad_between_seqs=True,
            attention_dropout=0.0,
            context_parallel=False,
            deterministic=_deterministic,
            is_training=True,
            cuda_graph=True,
            softmax_scale=0.125,
        )
    )
    if not use_flash_attention:
        pytest.skip(f"FlashAttention {fa_version} does not support this CUDA Graph configuration.")
    assert flash_attention_backend.major == fa_version
    # Restore the complete backend cache along with the environment at test teardown.
    for key, value in _attention_backends.items():
        monkeypatch.setitem(_attention_backends, key, value)
    _attention_backends["backend_selection_requires_update"] = True
    reset_rng_states()
    cu_q, cu_kv, padded_q, padded_kv = [
        torch.tensor(offsets, dtype=torch.int32, device="cuda")
        for offsets in ([0, 61, 96], [0, 45, 118], [0, 64, 112], [0, 64, 160])
    ]
    # Expected valid token positions are independent of get_thd_padding_mask.
    q_rows = torch.tensor(list(range(61)) + list(range(64, 99)), device="cuda")
    kv_rows = torch.tensor(list(range(45)) + list(range(64, 137)), device="cuda")
    qkv = [
        torch.randn(tokens, 4, 64, dtype=torch.bfloat16, device="cuda", requires_grad=True)
        for tokens in (128, 192, 192)
    ]
    grad_output = torch.randn(128, 256, dtype=torch.bfloat16, device="cuda")
    block = DotProductAttention(
        4,
        64,
        qkv_format="thd",
        attn_mask_type="padding",
        attention_type="cross",
        attention_dropout=0.0,
    ).cuda()

    def run(inputs, grad, padded):
        """Run the selected FlashAttention backend and differentiate Q/K/V."""
        output = block(
            *inputs,
            cu_seqlens_q=cu_q,
            cu_seqlens_kv=cu_kv,
            cu_seqlens_q_padded=padded_q if padded else None,
            cu_seqlens_kv_padded=padded_kv if padded else None,
            max_seqlen_q=128,
            max_seqlen_kv=128,
            pad_between_seqs=padded,
        )
        assert _attention_backends["use_flash_attention"]
        assert _attention_backends["flash_attention_backend"].major == fa_version
        assert not _attention_backends["use_fused_attention"]
        assert not _attention_backends["use_unfused_attention"]
        return (output, *torch.autograd.grad(output, inputs, grad))

    def check(actual):
        """Compare valid token positions with compact attention and require exact-zero padding."""
        compact_qkv = [
            tensor.detach()[rows].requires_grad_()
            for tensor, rows in zip(qkv, (q_rows, kv_rows, kv_rows))
        ]
        expected = run(compact_qkv, grad_output[q_rows], False)
        for tensor, reference, rows in zip(actual, expected, (q_rows, q_rows, kv_rows, kv_rows)):
            assert tensor.shape[0] == (128 if rows is q_rows else 192)
            torch.testing.assert_close(tensor[rows], reference, atol=1.5e-2, rtol=1.5e-2)
            padding = torch.ones(tensor.shape[0], dtype=torch.bool, device="cuda")
            padding[rows] = False
            assert torch.count_nonzero(tensor[padding]).item() == 0

    check(run(qkv, grad_output, True))
    stream = torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(3):
            run(qkv, grad_output, True)
    torch.cuda.current_stream().wait_stream(stream)
    torch.cuda.synchronize()
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph, stream=stream):
        captured = run(qkv, grad_output, True)
    for _ in range(2):
        # Replays must consume fresh inputs and upstream gradients at the same addresses.
        with torch.no_grad():
            for tensor in (*qkv, grad_output):
                tensor.normal_()
        graph.replay()
        check(captured)


# Define F16 data types to test
param_types = [torch.float16]
if is_bf16_available():
    param_types.append(torch.bfloat16)
param_types_lean = [torch.bfloat16]

model_configs_base = {
    # test: ModelConfig(b, sq, hq, dqk)
    "base_1_0": ModelConfig(8, 128, 16, 64),
    "base_1_1": ModelConfig(4, 128, 16, 64, max_seqlen_kv=256),
    "base_2_0": ModelConfig(2, 2048, 24, 128),
    "base_2_1": ModelConfig(1, 2048, 24, 128, max_seqlen_kv=4096),
    "base_3_0": ModelConfig(8, 1, 16, 128, max_seqlen_kv=2048),
    "base_3_1": ModelConfig(8, 1, 16, 256, max_seqlen_kv=2048),
    "base_4_0": ModelConfig(8, 1, 16, 192, max_seqlen_kv=2048),
    "base_4_1": ModelConfig(8, 128, 16, 192, max_seqlen_kv=2048),
    "base_5_0": ModelConfig(8, 1, 16, 512, max_seqlen_kv=2048),
    "base_5_1": ModelConfig(8, 128, 16, 512, max_seqlen_kv=2048),
    "base_6_0": ModelConfig(8, 1, 16, 1024, max_seqlen_kv=2048),
    "base_6_1": ModelConfig(8, 128, 16, 1024, max_seqlen_kv=2048),
}


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("model_configs", [model_configs_base])
@pytest.mark.parametrize("model", model_configs_base.keys())
@pytest.mark.parametrize("ckpt_attn", [False])
@pytest.mark.parametrize("qkv_layout", [None])
@pytest.mark.parametrize("swa", [False])
@pytest.mark.parametrize("pad_between_seqs", [False, True])
def test_dot_product_attention(
    dtype,
    model_configs,
    model,
    ckpt_attn,
    qkv_layout,
    swa,
    pad_between_seqs,
    declarative_packed=False,
    is_training=True,
    fwd_only_without_fused_attn=True,
):
    """Test DotProductAttention module"""

    # Get configs
    tols = dict(atol=1e-3, rtol=1e-3)
    if dtype == torch.bfloat16:
        tols = dict(atol=1.5e-2, rtol=1.5e-2)
    config = copy.deepcopy(model_configs[model])
    is_mla = config.head_dim_qk != config.head_dim_v
    is_mqa_gqa = config.num_heads != config.num_gqa_groups
    if qkv_layout is None:
        if config.attn_type == "self":
            qkv_layout = "sb3hd" if not is_mla and not is_mqa_gqa else "sbhd_sbhd_sbhd"
        else:
            qkv_layout = "bshd_bs2hd" if not is_mla and not is_mqa_gqa else "bshd_bshd_bshd"
    if "3" in qkv_layout and config.attn_type == "cross":
        pytest.skip("No need to test this layout for cross attention")
    if declarative_packed and not any(c.isdigit() for c in qkv_layout):
        pytest.skip("Declarative packed inputs only apply to packed qkv layouts.")

    if config.window_size == (-1, -1) and swa:
        config.window_size = [2, 2]

    config.window_size = check_set_window_size(config.attn_mask_type, config.window_size)
    qkv_format = qkv_layout.replace("3", "").replace("2", "").split("_")[0]
    if pad_between_seqs and qkv_format != "thd":
        pytest.skip("pad_between_seqs only applies to THD format!")
    if qkv_format == "thd" and "padding" not in config.attn_mask_type:
        config.attn_mask_type = (
            "padding_" + config.attn_mask_type if config.attn_mask_type != "no_mask" else "padding"
        )

    # Get backends
    # For 111s, dbias calculation is not supported as of cuDNN 9.18, hence, test fwd only for 111s.
    # For all other shapes test fwd+bwd unless the caller requests fwd-only coverage.
    # TODO(KshitijLakhani): Set is_training to True for all cases once cuDNN supports dbias for 111s.
    if is_training and config.bias_shape == "111s":
        is_training = False
        logging.info(
            "Setting is_training to False as cuDNN does not support dbias for"
            f" {config.bias_shape=} "
        )
    # Generate token counts for THD so the support query and execution will use the same values
    num_tokens_q, num_tokens_kv = None, None
    if qkv_format == "thd":
        reset_rng_states()
        seqlens = _generate_seqlens(config, qkv_format, pad_between_seqs)
        num_tokens_q = int(seqlens.cu_q_after_pad[-1])
        num_tokens_kv = int(seqlens.cu_kv_after_pad[-1])
    available_backends, _, fused_attn_backends = get_available_attention_backends(
        config,
        qkv_dtype=dtype,
        qkv_layout=qkv_layout,
        pad_between_seqs=pad_between_seqs,
        is_training=is_training,
        deterministic=_deterministic,
        num_tokens_q=num_tokens_q,
        num_tokens_kv=num_tokens_kv,
    )
    flash_attn_supported, fused_attn_supported, unfused_attn_supported = available_backends

    # Some backends are only available in inference mode, so when FusedAttention cannot train this
    # config the query is repeated forward-only to recover enough backends to compare. Callers
    # whose backward-capable pair does not include FusedAttention -- softcap, where
    # get_attention_backend always disables FusedAttention -- opt out to keep dgrad coverage.
    if not fused_attn_supported and fwd_only_without_fused_attn:
        is_training = False
        available_backends, _, fused_attn_backends = get_available_attention_backends(
            config,
            qkv_dtype=dtype,
            qkv_layout=qkv_layout,
            pad_between_seqs=pad_between_seqs,
            is_training=is_training,
            deterministic=_deterministic,
            num_tokens_q=num_tokens_q,
            num_tokens_kv=num_tokens_kv,
        )
        flash_attn_supported, fused_attn_supported, unfused_attn_supported = available_backends

    # Skip if only unfused backend is supported
    if (len(fused_attn_backends) + flash_attn_supported + unfused_attn_supported) < 2:
        pytest.skip("Less than two backends to compare.")

    # UnfusedDotProductAttention backend
    if unfused_attn_supported:
        unfused_attn_fwd, unfused_max_logit, unfused_attn_bwd = run_dot_product_attention(
            dtype,
            config,
            "UnfusedDotProductAttention",
            ckpt_attn,
            qkv_layout,
            pad_between_seqs,
            is_training,
        )

    # FusedAttention backend
    if fused_attn_supported:
        fused_attn_fwd, fused_max_logit, fused_attn_bwd = run_dot_product_attention(
            dtype,
            config,
            "FusedAttention",
            ckpt_attn,
            qkv_layout,
            pad_between_seqs,
            is_training,
            declarative_packed=declarative_packed,
        )

    # FlashAttention backend
    if flash_attn_supported:
        flash_attn_fwd, _, flash_attn_bwd = run_dot_product_attention(
            dtype,
            config,
            "FlashAttention",
            ckpt_attn,
            qkv_layout,
            pad_between_seqs,
            is_training,
            declarative_packed=declarative_packed,
        )

    # Compare results
    logging.info(f"[test_dot_product_attention]: is_training = {is_training}")
    if unfused_attn_supported and flash_attn_supported:
        logging.info("[test_dot_product_attention]: unfused attn vs flash attn")
        torch.testing.assert_close(flash_attn_fwd, unfused_attn_fwd, **tols)
        for i, _ in enumerate(flash_attn_bwd):
            torch.testing.assert_close(unfused_attn_bwd[i], flash_attn_bwd[i], **tols)
    if unfused_attn_supported and fused_attn_supported:
        logging.info("[test_dot_product_attention]: unfused attn vs fused attn")
        torch.testing.assert_close(fused_attn_fwd, unfused_attn_fwd, **tols)
        if config.return_max_logit:
            torch.testing.assert_close(fused_max_logit, unfused_max_logit, **tols)
        for i, _ in enumerate(unfused_attn_bwd):
            torch.testing.assert_close(fused_attn_bwd[i], unfused_attn_bwd[i], **tols)
    if fused_attn_supported and flash_attn_supported:
        logging.info("[test_dot_product_attention]: fused attn vs flash attn")
        torch.testing.assert_close(fused_attn_fwd, flash_attn_fwd, **tols)
        for i, _ in enumerate(flash_attn_bwd):
            torch.testing.assert_close(fused_attn_bwd[i], flash_attn_bwd[i], **tols)


_CACHE_EVENT = re.compile(
    r"\[FUSED-ATTN-CACHE\]\s+(?:rank=\d+\s+\|\s+)?tid=\d+\s+dev=-?\d+\s+\|\s+"
    r"(?P<backend>f16|fp8)\s+(?P<pass>fwd|bwd)\s+"
    r"(?P<event>CREATE_GRAPH|CACHE_GRAPH|BUILD_PLANS|EXECUTE|MISS|HIT)\b(?P<rest>.*)"
)
_CACHE_PHASE = re.compile(r"\[CACHE-TEST\] phase=(?P<name>\w+)")


def test_fused_attn_graph_cache():
    """Test FusedAttention graph cache with level 2 diagnostics. It runs a subprocess
    to avoid contamination from other tests as the counters are process-wide.
    """
    worker = _current_file.parent / "run_graph_cache.py"
    result = subprocess.run(
        [sys.executable, str(worker)],
        env={
            **os.environ,
            "NVTE_FUSED_ATTN_CACHE_DEBUG": "2",
            "PYTHONUNBUFFERED": "1",
        },
        capture_output=True,
        text=True,
        timeout=900,
        check=False,
    )
    assert result.returncode == 0, f"Graph cache worker exited with {result.returncode}."
    if "[CACHE-TEST] fused=1" not in result.stdout:
        pytest.skip("No FusedAttention backend for the graph cache test config.")

    # Group the cache diagnostics:
    # events[phase][(pass, event)] = count of events
    # miss_keys[phase][pass] = set of distinct cache keys that missed
    events = collections.defaultdict(collections.Counter)
    miss_keys = collections.defaultdict(lambda: collections.defaultdict(set))
    phase = None
    for line in result.stderr.splitlines():
        phase_match = _CACHE_PHASE.search(line)
        if phase_match is not None:
            phase = phase_match.group("name")
            continue
        event_match = _CACHE_EVENT.search(line)
        if event_match is None or phase is None:
            continue
        event_pass, event = event_match.group("pass"), event_match.group("event")
        events[phase][(event_pass, event)] += 1
        if event == "MISS":
            miss_keys[phase][event_pass].add(event_match.group("rest").split("|")[-1].strip())

    context = f"\n--- stderr ---\n{result.stderr[-8000:]}"

    for pass_name in ("fwd", "bwd"):

        def expect(phase, event, expected, reason, actual=None, pass_name=pass_name):
            if actual is None:
                actual = events[phase][(pass_name, event)]
            ok = actual >= 1 if expected == "1+" else actual == expected
            assert (
                ok
            ), f"{pass_name} {phase}: expected {event}={expected}, got {actual} ({reason}){context}"

        expect("query", "MISS", 1, "expected one cold miss")
        expect("query", "CREATE_GRAPH", 1, "expected one build")
        expect("query", "CACHE_GRAPH", 1, "build was not cached")
        expect("query", "BUILD_PLANS", 0, "query compiled kernels")

        expect("requery", "MISS", 0, "repeated query missed")
        expect("requery", "CREATE_GRAPH", 0, "repeated query rebuilt")
        expect("requery", "HIT", "1+", "repeated query never looked")

        expect("exec", "MISS", 0, "execution missed the query's graph")
        expect("exec", "CREATE_GRAPH", 0, "execution rebuilt the graph")
        expect("exec", "EXECUTE", "1+", "fused attention never ran")
        expect("exec", "BUILD_PLANS", 1, "expected one plan build")

        expect("rescale", "MISS", 0, "attn_scale changed the key")
        expect("rescale", "CREATE_GRAPH", 0, "attn_scale forced a build")
        expect("rescale", "BUILD_PLANS", 0, "attn_scale recompiled")
        expect("rescale", "EXECUTE", "1+", "rescaled run did not execute")

        expect("reshape", "MISS", 1, "expected one miss")
        expect("reshape", "CREATE_GRAPH", 1, "expected one build")
        expect(
            "reshape",
            "MISS keys",
            1,
            "more than one new cache key",
            actual=len(miss_keys["reshape"][pass_name]),
        )


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("model_configs", [model_configs_base])
@pytest.mark.parametrize("model", ["base_1_1", "base_2_1"])
def test_dpa_checkpoint(dtype, model_configs, model):
    """Test DotProductAttention module with checkpointing"""
    test_dot_product_attention(dtype, model_configs, model, True, None, False, False)


model_configs_max_logit = {
    # test: ModelConfig(b, sq, hq, dqk)
    "max_logit_1": ModelConfig(1, 2048, 24, 128, max_seqlen_kv=4096),
    "max_logit_2": ModelConfig(2, 2048, 24, 128, attn_mask_type="causal"),
    "max_logit_3": ModelConfig(2, 1, 16, 128, max_seqlen_kv=2048, attn_mask_type="padding_causal"),
    "max_logit_4": ModelConfig(
        8, 128, 16, 192, max_seqlen_kv=2048, attn_bias_type="post_scale_bias"
    ),
    "max_logit_5": ModelConfig(
        8, 128, 16, 512, max_seqlen_kv=2048, attn_mask_type="causal", window_size=(20, 0)
    ),
    "max_logit_6": ModelConfig(8, 1, 16, 1024, max_seqlen_kv=2048),
}


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("model_configs", [model_configs_max_logit])
@pytest.mark.parametrize("model", model_configs_max_logit.keys())
@pytest.mark.parametrize("qkv_layout", ["sbhd_sbhd_sbhd", "thd_thd_thd"])
def test_dpa_max_logit(dtype, model_configs, model, qkv_layout):
    """Test DotProductAttention module with checkpointing"""
    config = model_configs[model]
    config.return_max_logit = True
    test_dot_product_attention(dtype, model_configs, model, False, qkv_layout, False, False)


model_configs_num_splits = {
    # test: ModelConfig(b, sq, hq, dqk)
    "num_splits_1_0": ModelConfig(2, 2048, 24, 128, num_splits=2),
    "num_splits_1_1": ModelConfig(1, 2048, 24, 128, max_seqlen_kv=4096, num_splits=4),
}


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("model_configs", [model_configs_num_splits])
@pytest.mark.parametrize("model", model_configs_num_splits.keys())
def test_dpa_num_splits(dtype, model_configs, model):
    """Test DotProductAttention with FlashAttention-3 num_splits enabled"""
    test_dot_product_attention(
        dtype,
        model_configs,
        model,
        False,
        None,
        False,
        False,
    )


# ==============================
# Flash Attention 4 (FA4) tests
# ==============================

model_configs_fa4_base = {
    # test: ModelConfig(b, sq, hq, dqk)
    # Standard head dims
    "fa4_base_1": ModelConfig(4, 128, 16, 64),
    "fa4_base_2": ModelConfig(2, 2048, 24, 128, attn_mask_type="causal"),
    "fa4_base_3": ModelConfig(2, 1024, 8, 96, attn_mask_type="causal"),
    # GQA
    "fa4_gqa_1": ModelConfig(2, 1024, 32, 128, num_gqa_groups=8, attn_mask_type="causal"),
    "fa4_gqa_2": ModelConfig(2, 1024, 16, 128, num_gqa_groups=1, attn_mask_type="causal"),
    # num_splits
    "fa4_splits_1": ModelConfig(2, 2048, 24, 128, num_splits=2),
    "fa4_splits_2": ModelConfig(1, 2048, 24, 128, max_seqlen_kv=4096, num_splits=4),
}


fa4_enabled = bool(int(os.getenv("NVTE_FLASH_ATTN", "1"))) and bool(
    int(os.getenv("NVTE_FLASH_ATTN_V4", "1"))
)
requires_fa4 = pytest.mark.skipif(
    not fa4_enabled
    or not FlashAttentionUtils.v4_is_installed
    or device_compute_capability < (9, 0),
    reason="Enabled Flash-attn v4 and compute capability >= SM90 are required.",
)


@requires_fa4
@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_fa4_base])
@pytest.mark.parametrize("model", model_configs_fa4_base.keys())
def test_dpa_fa4_base(dtype, model_configs, model):
    """Test DotProductAttention with FA4: base configs, GQA, num_splits"""
    test_dot_product_attention(dtype, model_configs, model, False, None, False, False)


# head_dim=256 is supported only on SM100 via FA4's dedicated kernel
# (flash_attn/cute/sm100_hd256_2cta_fmha_*.py), available in flash-attn-4 > 4.0.0b10.
# On other architectures, _validate_head_dims rejects (256, 256), FA4 is disabled, and
# the test would silently fall back to another backend — defeating the purpose. Gate
# explicitly so the CI signal is unambiguous.
model_configs_fa4_hdim256 = {
    "fa4_hdim256": ModelConfig(2, 1024, 8, 256, attn_mask_type="causal"),
}


@requires_fa4
@pytest.mark.skipif(
    device_compute_capability not in ((10, 0), (10, 3)),
    reason="FA4 head_dim=256 dedicated kernel is SM100/103-only.",
)
@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_fa4_hdim256])
@pytest.mark.parametrize("model", model_configs_fa4_hdim256.keys())
def test_dpa_fa4_hdim256(dtype, model_configs, model):
    """Test DotProductAttention with FA4: head_dim=256 dedicated kernel on SM100"""
    # Keep this FA4 D=256 test forward-only. Before cuDNN D=256 backward support,
    # the generic helper took this path implicitly because fused-attn training was unavailable.
    test_dot_product_attention(
        dtype, model_configs, model, False, None, False, False, is_training=False
    )


# cuDNN FusedAttention D=256 bprop is supported on sm10x by the dedicated deterministic
# SDPA bprop kernel. BSHD support starts with cuDNN FE 1.24 / BE 9.23; THD support starts
# with cuDNN FE 1.26 / BE 9.25. The kernel supports d_qk == d_v == 256 only, vanilla softmax only,
# no dropout, no ALiBi, and (for non-causal masks) full-window attention only.
model_configs_d256 = {
    # test: ModelConfig(b, sq, hq, dqk)  -> head_dim_v defaults to head_dim_qk (256)
    "d256_no_mask": ModelConfig(2, 512, 16, 256),
    "d256_padding": ModelConfig(2, 512, 16, 256, attn_mask_type="padding"),
    # SWA is allowed only together with a causal mask on the D=256 bprop kernel.
    "d256_causal_swa": ModelConfig(2, 1024, 16, 256, attn_mask_type="causal", window_size=(128, 0)),
    # GQA variant (num_gqa_groups < num_heads).
    "d256_padding_causal_gqa": ModelConfig(
        2, 1024, 16, 256, num_gqa_groups=4, attn_mask_type="padding_causal"
    ),
}


@pytest.mark.skipif(
    device_compute_capability not in ((10, 0), (10, 3)),
    reason="cuDNN FusedAttention head_dim=256 backward is Blackwell server (SM100/SM103) only.",
)
@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("model_configs", [model_configs_d256])
@pytest.mark.parametrize("model", model_configs_d256.keys())
@pytest.mark.parametrize(
    "qkv_layout",
    [
        pytest.param(
            "bshd_bs2hd",
            marks=pytest.mark.skipif(
                get_cudnn_version() < (9, 23, 0),
                reason="cuDNN 9.23+ is required for BSHD D=256 fused-attn backward.",
            ),
        ),
        pytest.param(
            "thd_t2hd",
            marks=pytest.mark.skipif(
                get_cudnn_version() < (9, 25, 0),
                reason="cuDNN 9.25+ is required for THD D=256 fused-attn backward.",
            ),
        ),
    ],
)
def test_dpa_d256(dtype, model_configs, model, qkv_layout):
    """Test DotProductAttention with head_dim=256 backward on Blackwell"""
    test_dot_product_attention(dtype, model_configs, model, False, qkv_layout, False, False)


model_configs_fa4_mla = {
    # test: ModelConfig(b, sq, hq, dqk, head_dim_v=dv)
    "fa4_mla_1": ModelConfig(4, 128, 16, 128, head_dim_v=64),
    "fa4_mla_2": ModelConfig(2, 128, 16, 64, max_seqlen_kv=256, head_dim_v=128),
    "fa4_mla_3": ModelConfig(2, 1024, 16, 96, head_dim_v=64, attn_mask_type="causal"),
    # dqk=128, dv=96: FA4 SM100 backward has dK_reduce_ncol misalignment for dV;
    # the backend filter should reject FA4 and fall back to another backend.
    "fa4_mla_4": ModelConfig(2, 1024, 16, 128, head_dim_v=96, attn_mask_type="causal"),
    # DeepSeek-style MLA: dqk=192, dv=128 (supported on SM100 as special case)
    "fa4_mla_deepseek": ModelConfig(2, 1024, 16, 192, head_dim_v=128, attn_mask_type="causal"),
}


@requires_fa4
@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_fa4_mla])
@pytest.mark.parametrize("model", model_configs_fa4_mla.keys())
def test_dpa_fa4_mla(dtype, model_configs, model):
    """Test DotProductAttention with FA4: MLA (head_dim_qk != head_dim_v)"""
    test_dot_product_attention(dtype, model_configs, model, False, "bshd_bshd_bshd", False, False)


model_configs_fa4_swa = {
    # test: ModelConfig(b, sq, hq, dqk, window_size=(left, right))
    "fa4_swa_1": ModelConfig(2, 2048, 16, 128, attn_mask_type="causal", window_size=(128, 0)),
    "fa4_swa_2": ModelConfig(2, 2048, 24, 64, attn_mask_type="causal", window_size=(64, 0)),
    "fa4_swa_3": ModelConfig(
        2, 2048, 16, 128, num_gqa_groups=4, attn_mask_type="causal", window_size=(256, 0)
    ),
    "fa4_swa_4": ModelConfig(
        2, 2048, 16, 128, attn_mask_type="padding_causal", window_size=(128, 0)
    ),
}


@requires_fa4
@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_fa4_swa])
@pytest.mark.parametrize("model", model_configs_fa4_swa.keys())
@pytest.mark.parametrize("qkv_layout", ["sbhd_sbhd_sbhd", "bshd_bshd_bshd"])
def test_dpa_fa4_sliding_window(dtype, model_configs, model, qkv_layout):
    """Test DotProductAttention with FA4: sliding window attention"""
    test_dot_product_attention(dtype, model_configs, model, False, qkv_layout, True, False)


model_configs_fa4_varlen = {
    # test: ModelConfig(b, sq, hq, dqk)
    "fa4_varlen_1": ModelConfig(4, 128, 16, 64, attn_mask_type="padding"),
    "fa4_varlen_2": ModelConfig(2, 2048, 24, 128, attn_mask_type="padding_causal"),
    "fa4_varlen_3": ModelConfig(
        2, 2048, 24, 128, num_gqa_groups=4, attn_mask_type="padding_causal"
    ),
    "fa4_varlen_4": ModelConfig(2, 128, 16, 64, max_seqlen_kv=256, attn_mask_type="padding"),
}


@requires_fa4
@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_fa4_varlen])
@pytest.mark.parametrize("model", model_configs_fa4_varlen.keys())
@pytest.mark.parametrize("qkv_layout", ["thd_thd_thd", "bshd_bshd_bshd"])
def test_dpa_fa4_varlen(dtype, model_configs, model, qkv_layout):
    """Test DotProductAttention with FA4: variable-length sequences (varlen/thd)"""
    test_dot_product_attention(dtype, model_configs, model, False, qkv_layout, False, False)


model_configs_fa4_mask = {
    # test: ModelConfig(b, sq, hq, dqk)
    "fa4_mask_no_mask": ModelConfig(2, 1024, 16, 128),
    "fa4_mask_causal": ModelConfig(2, 1024, 16, 128, attn_mask_type="causal"),
    "fa4_mask_causal_br": ModelConfig(2, 1024, 16, 128, attn_mask_type="causal_bottom_right"),
    "fa4_mask_padding": ModelConfig(2, 1024, 16, 128, attn_mask_type="padding"),
    "fa4_mask_padding_causal": ModelConfig(2, 1024, 16, 128, attn_mask_type="padding_causal"),
    "fa4_mask_padding_causal_br": ModelConfig(
        2, 1024, 16, 128, attn_mask_type="padding_causal_bottom_right"
    ),
}


@requires_fa4
@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_fa4_mask])
@pytest.mark.parametrize("model", model_configs_fa4_mask.keys())
def test_dpa_fa4_mask(dtype, model_configs, model):
    """Test DotProductAttention with FA4: various attention mask types"""
    test_dot_product_attention(dtype, model_configs, model, False, None, False, False)


model_configs_softmax = {
    # test: ModelConfig(b, sq, hq, dqk)
    "softmax_1_0": ModelConfig(2, 2048, 64, 64, num_gqa_groups=8),
    "softmax_1_1": ModelConfig(2, 2048, 64, 64, num_gqa_groups=8, softmax_type="off-by-one"),
    "softmax_1_2": ModelConfig(2, 2048, 64, 64, num_gqa_groups=8, softmax_type="learnable"),
    "softmax_2_0": ModelConfig(2, 2048, 64, 64, num_gqa_groups=8, attn_mask_type="causal"),
    "softmax_2_1": ModelConfig(
        2, 2048, 64, 64, num_gqa_groups=8, attn_mask_type="causal", softmax_type="off-by-one"
    ),
    "softmax_2_2": ModelConfig(
        2, 2048, 64, 64, num_gqa_groups=8, attn_mask_type="causal", softmax_type="learnable"
    ),
    "softmax_3_0": ModelConfig(2, 2048, 64, 64, num_gqa_groups=8, attn_mask_type="padding"),
    "softmax_3_1": ModelConfig(
        2, 2048, 64, 64, num_gqa_groups=8, attn_mask_type="padding", softmax_type="off-by-one"
    ),
    "softmax_3_2": ModelConfig(
        2, 2048, 64, 64, num_gqa_groups=8, attn_mask_type="padding", softmax_type="learnable"
    ),
    "softmax_4_0": ModelConfig(
        2, 2048, 64, 64, num_gqa_groups=8, window_size=(128, 0), attn_mask_type="causal"
    ),
    "softmax_4_1": ModelConfig(
        2,
        2048,
        64,
        64,
        num_gqa_groups=8,
        window_size=(128, 0),
        attn_mask_type="causal",
        softmax_type="off-by-one",
    ),
    "softmax_4_2": ModelConfig(
        2,
        2048,
        64,
        64,
        num_gqa_groups=8,
        window_size=(128, 0),
        attn_mask_type="causal",
        softmax_type="learnable",
    ),
    "softmax_5_0": ModelConfig(
        2, 2048, 64, 64, num_gqa_groups=8, window_size=(128, 0), attn_mask_type="padding_causal"
    ),
    "softmax_5_1": ModelConfig(
        2,
        2048,
        64,
        64,
        num_gqa_groups=8,
        window_size=(128, 0),
        attn_mask_type="padding_causal",
        softmax_type="off-by-one",
    ),
    "softmax_5_2": ModelConfig(
        2,
        2048,
        64,
        64,
        num_gqa_groups=8,
        window_size=(128, 0),
        attn_mask_type="padding_causal",
        softmax_type="learnable",
    ),
}


@pytest.mark.parametrize("dtype", [torch.bfloat16])
@pytest.mark.parametrize("model_configs", [model_configs_softmax])
@pytest.mark.parametrize("model", model_configs_softmax.keys())
def test_dpa_softmax(dtype, model_configs, model):
    """Test DotProductAttention module with different softmax types"""
    test_dot_product_attention(dtype, model_configs, model, True, "bshd_bshd_bshd", False, False)


@pytest.mark.skipif(get_cudnn_version() < (9, 18, 0), reason="cuDNN 9.18.0+ is required.")
@pytest.mark.parametrize("dtype", [torch.bfloat16])
@pytest.mark.parametrize("model_configs", [model_configs_softmax])
@pytest.mark.parametrize("model", model_configs_softmax.keys())
def test_dpa_softmax_thd(dtype, model_configs, model):
    """Test DotProductAttention module with different softmax types"""
    config = model_configs[model]
    if "padding" not in config.attn_mask_type:
        promoted = dict(vars(config))
        promoted["attn_mask_type"] = (
            "padding" if config.attn_mask_type == "no_mask" else "padding_" + config.attn_mask_type
        )
        if any(name != model and vars(other) == promoted for name, other in model_configs.items()):
            pytest.skip("Duplicate test to others with THD and padding mask.")
    test_dot_product_attention(dtype, model_configs, model, True, "thd_thd_thd", False, False)


model_configs_softcap = {
    # test: ModelConfig(b, sq, hq, dqk)
    # High cap, no padding -> flash_attn_func.
    "softcap_1_0": ModelConfig(4, 128, 16, 64, softcap=50.0),
    # Low cap, padding -> flash_attn_varlen_func. The shared harness feeds 0.1 * randn, putting
    # logits at O(1e-2) whatever the head dim, so tanh is numerically linear at a Gemma-sized
    # cap. A cap of 0.01 is the one regime these inputs can distinguish. Softcapping in tanh's
    # saturating region is covered by test_dpa_softcap_vs_reference, which uses its own inputs.
    # head_dim 128 rather than 64: FA2 and FA3 compile a separate softcap kernel per head_dim,
    # and the logit scale above is head_dim invariant since softmax_scale cancels the sqrt(d).
    "softcap_3_1": ModelConfig(2, 512, 16, 128, attn_mask_type="padding_causal", softcap=0.01),
}


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("model_configs", [model_configs_softcap])
@pytest.mark.parametrize("model", model_configs_softcap.keys())
def test_dpa_softcap(dtype, model_configs, model):
    """Test DotProductAttention module with tanh logit softcapping"""
    test_dot_product_attention(
        dtype,
        model_configs,
        model,
        False,
        "bshd_bshd_bshd",
        False,
        False,
        fwd_only_without_fused_attn=False,
    )


@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_softcap])
@pytest.mark.parametrize("model", ["softcap_1_0"])
def test_dpa_softcap_zero_backend_selection(dtype, model_configs, model):
    """Test that softcap=0.0 leaves backend selection untouched.

    The softcap filter in get_attention_backend disables FusedAttention (and FA4) whenever the
    cap is nonzero. If it also fired at 0.0, those backends would silently drop out of every
    other test in this file rather than failing one, so assert both halves here.

    Whether FusedAttention is available at all is arch- and mode-dependent (cuDNN support,
    NVTE_ALLOW_NONDETERMINISTIC_ALGO=0), and is not what this test is about, so that half is a
    skip rather than an assert.
    """
    config = copy.deepcopy(model_configs[model])
    query = dict(
        qkv_dtype=dtype,
        qkv_layout="bshd_bshd_bshd",
        is_training=True,
        deterministic=_deterministic,
    )

    config.softcap = 0.0
    (_, fused_off, unfused_off), _, _ = get_available_attention_backends(config, **query)
    config.softcap = 50.0
    (_, fused_on, unfused_on), _, _ = get_available_attention_backends(config, **query)

    if not fused_off:
        pytest.skip(
            "FusedAttention is unavailable for this config irrespective of softcap (no cuDNN"
            " support for this arch/shape, or deterministic mode), so the softcap filter has"
            " nothing to disable and the comparison below would be vacuous."
        )
    assert not fused_on, "a nonzero softcap must disable FusedAttention"
    assert unfused_off and unfused_on, "UnfusedDotProductAttention must support softcap"


def _softcap_reference_attention(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    softmax_scale: float,
    softcap: float,
    causal: bool,
    bias: torch.Tensor = None,
    cap_includes_bias: bool = False,
) -> torch.Tensor:
    """Closed-form softcapped attention in bshd layout, computed in fp32.

    scores = softcap * tanh(Q @ K^T * softmax_scale / softcap), with the tanh skipped entirely
    when softcap == 0.0, so this doubles as the reference for the no-op claim. GQA is supported.
    An additive `bias` lands outside the tanh unless `cap_includes_bias`, which builds the
    reference an implementation that capped the bias along with the logits would produce.
    """
    q, k, v = (x.transpose(1, 2).float() for x in (q, k, v))
    if q.shape[1] != k.shape[1]:
        repeats = q.shape[1] // k.shape[1]
        k = k.repeat_interleave(repeats, dim=1)
        v = v.repeat_interleave(repeats, dim=1)
    scores = torch.matmul(q, k.transpose(-2, -1)) * softmax_scale
    if bias is not None and cap_includes_bias:
        scores = scores + bias.float()
    if softcap != 0.0:
        scores = softcap * torch.tanh(scores / softcap)
    if bias is not None and not cap_includes_bias:
        scores = scores + bias.float()
    if causal:
        max_seqlen_q, max_seqlen_kv = scores.shape[-2], scores.shape[-1]
        mask = torch.triu(
            torch.ones(max_seqlen_q, max_seqlen_kv, dtype=torch.bool, device=scores.device),
            diagonal=1 + max_seqlen_kv - max_seqlen_q,
        )
        scores = scores.masked_fill(mask, float("-inf"))
    return torch.matmul(torch.softmax(scores, dim=-1), v).transpose(1, 2)


model_configs_softcap_reference = {
    # test: ModelConfig(b, sq, hq, dqk)
    "softcap_ref_1_0": ModelConfig(2, 128, 8, 64),
    "softcap_ref_2_0": ModelConfig(2, 128, 8, 64, num_gqa_groups=2, attn_mask_type="causal"),
}

# "plain" checks the cap itself. The other two pin down *where* the cap is applied inside
# UnfusedDotProductAttention, so they run on that backend only, at a cap that saturates.
_SOFTCAP_BACKEND_ENV = ("NVTE_FLASH_ATTN", "NVTE_FUSED_ATTN", "NVTE_UNFUSED_ATTN")

softcap_variants = ["plain", "bias_outside_cap", "qk_layer_scaling"]

# Large enough that a cap of softcap * layer_number is far from a cap of softcap for O(1)
# logits; at layer_number=3 the two references differ by less than the tolerance below.
_SOFTCAP_QK_LAYER_NUMBER = 8


def _softcap_variant_spec(variant, config, dtype, softcap, softmax_scale, q, k, v):
    """Return (dpa_kwargs, forward_kwargs, right_fn, wrong_fn) for one softcap variant.

    `wrong_fn` is the reference that an implementation carrying the bug this variant guards
    against would produce, or None when there is no distinguishable wrong answer.
    """
    causal = "causal" in config.attn_mask_type

    def _ref(cap, **kwargs):
        return _softcap_reference_attention(q, k, v, softmax_scale, cap, causal, **kwargs)

    if variant == "plain":
        # A backend that ignored the cap entirely would land on the uncapped reference.
        wrong_fn = None if softcap == 0.0 else (lambda: _ref(0.0))
        return dict(layer_number=1), {}, (lambda: _ref(softcap)), wrong_fn

    if variant == "bias_outside_cap":
        # O(1) against the cap, so capping the bias too is visible in the output while the
        # softmax stays well conditioned; a larger bias only sharpens fp16 rounding.
        bias = torch.randn(
            1,
            config.num_heads,
            config.max_seqlen_q,
            config.max_seqlen_kv,
            dtype=dtype,
            device="cuda",
        )
        forward_kwargs = dict(core_attention_bias_type="post_scale_bias", core_attention_bias=bias)
        return (
            dict(layer_number=1),
            forward_kwargs,
            (lambda: _ref(softcap, bias=bias)),
            (lambda: _ref(softcap, bias=bias, cap_includes_bias=True)),
        )

    if variant == "qk_layer_scaling":
        # Omitting the cap / layer_number division caps the reduced logits instead, which after
        # the softmax's layer_number factor is exactly a softcap * layer_number cap.
        layer_number = _SOFTCAP_QK_LAYER_NUMBER
        return (
            dict(layer_number=layer_number),
            {},
            (lambda: _ref(softcap)),
            (lambda: _ref(softcap * layer_number)),
        )

    raise ValueError(f"Unknown softcap variant {variant}!")


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("model_configs", [model_configs_softcap_reference])
@pytest.mark.parametrize("model", model_configs_softcap_reference.keys())
@pytest.mark.parametrize("softcap", [0.0, 0.5])
@pytest.mark.parametrize("backend", ["UnfusedDotProductAttention", "FlashAttention"])
@pytest.mark.parametrize("variant", softcap_variants)
def test_dpa_softcap_vs_reference(dtype, model_configs, model, softcap, backend, variant):
    """Test softcap against a closed-form reference, one backend and one variant at a time.

    This needs only one TE backend, so UnfusedDotProductAttention -- the reference
    implementation for every other softcap test -- stays covered on machines without
    flash-attn. softcap=0.0 checks against a reference that never applies tanh, which is the
    numerical half of the no-op claim. Every variant with a distinguishable wrong answer
    asserts the two references are further apart than the tolerance, so a backend that
    implemented the wrong one could not pass.
    """
    config = copy.deepcopy(model_configs[model])
    causal = "causal" in config.attn_mask_type
    if variant != "plain":
        # These pin down UnfusedDotProductAttention's own arithmetic and need one saturating
        # cap on one mask type; "plain" carries the backend and mask coverage.
        if backend != "UnfusedDotProductAttention" or softcap == 0.0 or causal:
            pytest.skip(f"{variant} is covered once, on the non-causal config with a nonzero cap")
        if variant == "qk_layer_scaling" and dtype != torch.float16:
            pytest.skip("qk layer scaling is gated on fp16 keys")

    config.softcap = softcap
    available_backends, _, _ = get_available_attention_backends(
        config,
        qkv_dtype=dtype,
        qkv_layout="bshd_bshd_bshd",
        is_training=True,
        deterministic=_deterministic,
    )
    supported = dict(
        zip(["FlashAttention", "FusedAttention", "UnfusedDotProductAttention"], available_backends)
    )
    if not supported[backend]:
        pytest.skip(f"{backend} is unavailable for this config.")

    reset_rng_states()
    os.environ["NVTE_FLASH_ATTN"] = "1" if backend == "FlashAttention" else "0"
    os.environ["NVTE_FUSED_ATTN"] = "0"
    os.environ["NVTE_UNFUSED_ATTN"] = "1" if backend == "UnfusedDotProductAttention" else "0"
    if variant == "qk_layer_scaling":
        os.environ["NVTE_APPLY_QK_LAYER_SCALING"] = "1"
    _attention_backends["backend_selection_requires_update"] = True

    softmax_scale = 1.0 / config.head_dim_qk**0.5
    q_shape = (config.batch_size, config.max_seqlen_q, config.num_heads, config.head_dim_qk)
    k_shape = (config.batch_size, config.max_seqlen_kv, config.num_gqa_groups, config.head_dim_qk)
    v_shape = (config.batch_size, config.max_seqlen_kv, config.num_gqa_groups, config.head_dim_v)
    out_shape = (config.batch_size, config.max_seqlen_q, config.num_heads, config.head_dim_v)
    # randn puts the logits at O(1), so a cap of 0.5 lands in tanh's saturating region and moves
    # the output by O(1). The shared harness uses 0.1 * randn, where the logits are O(1e-2) and
    # no cap value is distinguishable from no cap at all.
    q, k, v = (
        torch.randn(shape, dtype=dtype, device="cuda").requires_grad_()
        for shape in (q_shape, k_shape, v_shape)
    )
    q_ref, k_ref, v_ref = (x.detach().clone().requires_grad_() for x in (q, k, v))
    # DotProductAttention merges the head and head-dim axes of its output.
    d_out = torch.randn(out_shape, dtype=dtype, device="cuda")

    dpa_kwargs, forward_kwargs, right_fn, wrong_fn = _softcap_variant_spec(
        variant, config, dtype, softcap, softmax_scale, q_ref, k_ref, v_ref
    )

    try:
        block = DotProductAttention(
            config.num_heads,
            (config.head_dim_qk, config.head_dim_v),
            num_gqa_groups=config.num_gqa_groups,
            qkv_format="bshd",
            attn_mask_type=config.attn_mask_type,
            softmax_scale=softmax_scale,
            softcap=softcap,
            **dpa_kwargs,
        ).to(dtype=dtype, device="cuda")
        out = block(q, k, v, **forward_kwargs).view(out_shape)
    finally:
        os.environ["NVTE_APPLY_QK_LAYER_SCALING"] = "0"
        _attention_backends["backend_selection_requires_update"] = True

    out_ref = right_fn()

    tols = dict(atol=2e-2, rtol=2e-2)
    if dtype == torch.bfloat16:
        tols = dict(atol=4e-2, rtol=4e-2)

    if wrong_fn is not None:
        # Without this the test could be vacuous: the right and wrong references have to be
        # distinguishable at this cap for the comparison below to mean anything.
        variant_effect = (out_ref.detach() - wrong_fn().detach()).abs().max().item()
        assert variant_effect > 10 * tols["atol"], (
            f"{variant} moves the reference output by only {variant_effect:.2e}; this config"
            " would pass even if the backend implemented the wrong variant"
        )

    torch.testing.assert_close(out.float(), out_ref, **tols)

    if variant == "plain":
        out.backward(d_out)
        out_ref.backward(d_out.float())
        torch.testing.assert_close(q.grad.float(), q_ref.grad.float(), **tols)
        torch.testing.assert_close(k.grad.float(), k_ref.grad.float(), **tols)
        torch.testing.assert_close(v.grad.float(), v_ref.grad.float(), **tols)


@pytest.mark.parametrize("softcap", (-1.0, float("inf"), float("nan")))
def test_dpa_softcap_rejects_invalid(softcap):
    """A cap that is negative or non-finite must raise rather than diverge by backend.

    The backends disagree about these values: unfused applies a negative cap as its
    absolute value and returns NaN for a non-finite one, while flash caps only when
    softcap > 0 and so drops both silently.
    """
    block = DotProductAttention(4, 64, qkv_format="bshd", softcap=softcap).to(device="cuda")
    q, k, v = (torch.randn(2, 32, 4, 64, dtype=torch.float16, device="cuda") for _ in range(3))

    with pytest.raises(ValueError, match="softcap"):
        block(q, k, v)

    # A forward override is validated on the same path as the constructor value.
    ok = DotProductAttention(4, 64, qkv_format="bshd").to(device="cuda")
    with pytest.raises(ValueError, match="softcap"):
        ok(q, k, v, softcap=softcap)


@pytest.mark.parametrize("dtype", param_types)
def test_transformer_layer_softcap_plumbing(dtype):
    """Test that TransformerLayer forwards softcap to both of its attention modules.

    Numerics are covered above; this only checks the value arrives. Cross-attention is
    reached through a separate call site, so a refactor can drop the cap there while
    self-attention keeps working and nothing else in the suite would notice.
    """
    hidden_size, num_heads, seqlen, batch_size = 256, 4, 32, 2
    seen = {}

    def _record(name):
        def hook(_module, _args, kwargs):
            seen[name] = kwargs.get("softcap")

        return hook

    # Set explicitly rather than inheriting: the tests above leave these set, and a stale
    # NVTE_UNFUSED_ATTN=0 would leave no eligible backend once softcap drops the fused ones.
    # Restored in the finally below so this test does not do to others what they did to it.
    backend_env = {k: os.environ.get(k) for k in _SOFTCAP_BACKEND_ENV}
    reset_rng_states()
    os.environ["NVTE_FLASH_ATTN"] = "1"
    os.environ["NVTE_FUSED_ATTN"] = "0"
    os.environ["NVTE_UNFUSED_ATTN"] = "1"
    _attention_backends["backend_selection_requires_update"] = True

    try:
        block = TransformerLayer(
            hidden_size,
            4 * hidden_size,
            num_heads,
            layer_type="decoder",
            softcap=50.0,
            params_dtype=dtype,
            device="cuda",
        )
        block.self_attention.core_attention.register_forward_pre_hook(
            _record("self"), with_kwargs=True
        )
        block.inter_attention.core_attention.register_forward_pre_hook(
            _record("cross"), with_kwargs=True
        )

        hidden_states = torch.randn(
            seqlen, batch_size, hidden_size, dtype=dtype, device="cuda", requires_grad=True
        )
        forward_kwargs = dict(
            encoder_output=hidden_states,
            enc_dec_attn_mask=torch.zeros(
                batch_size, 1, 1, seqlen, dtype=torch.bool, device="cuda"
            ),
        )

        # The constructor value reaches both attention modules.
        block(hidden_states, **forward_kwargs)
        assert seen["self"] == 50.0, f"self-attention saw softcap={seen['self']}, expected 50.0"
        assert seen["cross"] == 50.0, f"cross-attention saw softcap={seen['cross']}, expected 50.0"

        # A forward override wins over the constructor, for both.
        seen.clear()
        block(hidden_states, softcap=10.0, **forward_kwargs)
        assert seen["self"] == 10.0, f"self-attention saw softcap={seen['self']}, expected 10.0"
        assert seen["cross"] == 10.0, f"cross-attention saw softcap={seen['cross']}, expected 10.0"
    finally:
        for key, value in backend_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        _attention_backends["backend_selection_requires_update"] = True


model_configs_mla = {
    # test: ModelConfig(b, sq, hq, dqk)
    "mla_1_0": ModelConfig(8, 128, 16, 64, head_dim_v=128),
    "mla_1_1": ModelConfig(4, 128, 16, 64, max_seqlen_kv=256, head_dim_v=128),
    "mla_1_2": ModelConfig(4, 128, 16, 192, max_seqlen_kv=256, head_dim_v=128),
    "mla_2_0": ModelConfig(2, 2048, 24, 128, attn_mask_type="causal", head_dim_v=64),
    "mla_2_1": ModelConfig(
        1, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="causal", head_dim_v=64
    ),
    "mla_2_2": ModelConfig(
        1, 2048, 24, 192, max_seqlen_kv=4096, attn_mask_type="causal", head_dim_v=128
    ),
    "mla_3_0": ModelConfig(8, 1, 16, 128, max_seqlen_kv=2048, head_dim_v=64),
    "mla_3_1": ModelConfig(8, 1, 16, 256, max_seqlen_kv=2048, head_dim_v=128),
    "mla_3_2": ModelConfig(8, 1, 16, 192, max_seqlen_kv=2048, head_dim_v=128),
    "mla_3_3": ModelConfig(8, 1, 16, 160, max_seqlen_kv=2048, head_dim_v=128),
    "mla_3_4": ModelConfig(8, 1, 16, 160, max_seqlen_kv=2048, head_dim_v=160),
}


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("model_configs", [model_configs_mla])
@pytest.mark.parametrize("model", model_configs_mla.keys())
def test_dpa_mla(dtype, model_configs, model):
    """Test DotProductAttention module with Multi-Latent Attention (MLA)"""
    test_dot_product_attention(dtype, model_configs, model, True, None, False, False)


model_configs_mask = {
    # test: ModelConfig(b, sq, hq, dqk)
    "mask_1_0": ModelConfig(2, 2048, 16, 64, attn_mask_type="causal"),
    "mask_1_1": ModelConfig(2, 2048, 24, 128, num_gqa_groups=1, attn_mask_type="causal"),
    "mask_1_2": ModelConfig(2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="causal"),
    "mask_2_0": ModelConfig(2, 2048, 16, 64, attn_mask_type="causal_bottom_right"),
    "mask_2_1": ModelConfig(
        2, 2048, 24, 128, num_gqa_groups=1, attn_mask_type="causal_bottom_right"
    ),
    "mask_2_2": ModelConfig(
        2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="causal_bottom_right"
    ),
    "mask_3_0": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding"),
    "mask_3_1": ModelConfig(2, 2048, 24, 128, num_gqa_groups=1, attn_mask_type="padding"),
    "mask_3_2": ModelConfig(2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding"),
    "mask_4_0": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding_causal"),
    "mask_4_1": ModelConfig(2, 2048, 24, 128, num_gqa_groups=1, attn_mask_type="padding_causal"),
    "mask_4_2": ModelConfig(2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding_causal"),
    "mask_5_0": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding_causal_bottom_right"),
    "mask_5_1": ModelConfig(
        2, 2048, 24, 128, num_gqa_groups=1, attn_mask_type="padding_causal_bottom_right"
    ),
    "mask_5_2": ModelConfig(
        2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding_causal_bottom_right"
    ),
    "mask_6_0": ModelConfig(2, 1, 16, 128, max_seqlen_kv=2048, attn_mask_type="causal"),
    "mask_6_1": ModelConfig(2, 1, 16, 256, max_seqlen_kv=2048, attn_mask_type="causal"),
    "mask_7_0": ModelConfig(
        2, 1, 16, 128, max_seqlen_kv=2048, attn_mask_type="causal_bottom_right"
    ),
    "mask_7_1": ModelConfig(
        2, 1, 16, 256, max_seqlen_kv=2048, attn_mask_type="causal_bottom_right"
    ),
    "mask_8_0": ModelConfig(2, 1, 24, 128, max_seqlen_kv=2048, attn_mask_type="padding"),
    "mask_8_1": ModelConfig(2, 1, 16, 256, max_seqlen_kv=2048, attn_mask_type="padding"),
    "mask_9_0": ModelConfig(2, 1, 24, 128, max_seqlen_kv=2048, attn_mask_type="padding_causal"),
    "mask_9_1": ModelConfig(2, 1, 16, 256, max_seqlen_kv=2048, attn_mask_type="padding_causal"),
    "mask_10_0": ModelConfig(
        2, 1, 24, 128, max_seqlen_kv=2048, attn_mask_type="padding_causal_bottom_right"
    ),
    "mask_10_1": ModelConfig(
        2, 1, 16, 256, max_seqlen_kv=2048, attn_mask_type="padding_causal_bottom_right"
    ),
}


@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_mask])
@pytest.mark.parametrize("model", model_configs_mask.keys())
def test_dpa_mask(dtype, model_configs, model):
    """Test DotProductAttention module with different mask types"""
    test_dot_product_attention(dtype, model_configs, model, False, None, False, False)


model_configs_bias = {
    # test: ModelConfig(b, sq, hq, dqk)
    "bias_1_0": ModelConfig(4, 128, 16, 64, attn_bias_type="post_scale_bias"),
    "bias_1_1": ModelConfig(2, 128, 16, 64, max_seqlen_kv=256, attn_bias_type="post_scale_bias"),
    "bias_1_2": ModelConfig(4, 2048, 24, 128, attn_bias_type="post_scale_bias"),
    "bias_1_3": ModelConfig(2, 2048, 24, 128, max_seqlen_kv=4096, attn_bias_type="post_scale_bias"),
    "bias_1_4": ModelConfig(4, 2048, 24, 128, attn_bias_type="alibi"),
    "bias_1_5": ModelConfig(2, 2048, 24, 128, max_seqlen_kv=4096, attn_bias_type="alibi"),
    "bias_2_0": ModelConfig(
        4, 128, 16, 64, attn_mask_type="padding", attn_bias_type="post_scale_bias"
    ),
    "bias_2_1": ModelConfig(
        2,
        128,
        16,
        64,
        max_seqlen_kv=256,
        attn_mask_type="padding",
        attn_bias_type="post_scale_bias",
    ),
    "bias_2_2": ModelConfig(
        4, 2048, 24, 128, attn_mask_type="padding", attn_bias_type="post_scale_bias"
    ),
    "bias_2_3": ModelConfig(
        2,
        2048,
        24,
        128,
        max_seqlen_kv=4096,
        attn_mask_type="padding",
        attn_bias_type="post_scale_bias",
    ),
    "bias_2_4": ModelConfig(4, 2048, 24, 128, attn_mask_type="padding", attn_bias_type="alibi"),
    "bias_2_5": ModelConfig(
        2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding", attn_bias_type="alibi"
    ),
    "bias_3_0": ModelConfig(
        4, 128, 16, 64, attn_mask_type="causal", attn_bias_type="post_scale_bias"
    ),
    "bias_3_1": ModelConfig(
        2, 128, 16, 64, max_seqlen_kv=256, attn_mask_type="causal", attn_bias_type="post_scale_bias"
    ),
    "bias_3_2": ModelConfig(
        4, 2048, 24, 128, attn_mask_type="causal", attn_bias_type="post_scale_bias"
    ),
    "bias_3_3": ModelConfig(
        2,
        2048,
        24,
        128,
        max_seqlen_kv=4096,
        attn_mask_type="causal",
        attn_bias_type="post_scale_bias",
    ),
    "bias_3_4": ModelConfig(4, 2048, 24, 128, attn_mask_type="causal", attn_bias_type="alibi"),
    "bias_3_5": ModelConfig(
        2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="causal", attn_bias_type="alibi"
    ),
    "bias_4_0": ModelConfig(
        4, 128, 16, 64, attn_mask_type="padding_causal", attn_bias_type="post_scale_bias"
    ),
    "bias_4_1": ModelConfig(
        2,
        128,
        16,
        64,
        max_seqlen_kv=256,
        attn_mask_type="padding_causal",
        attn_bias_type="post_scale_bias",
    ),
    "bias_4_2": ModelConfig(
        4, 2048, 24, 128, attn_mask_type="padding_causal", attn_bias_type="post_scale_bias"
    ),
    "bias_4_3": ModelConfig(
        2,
        2048,
        24,
        128,
        max_seqlen_kv=4096,
        attn_mask_type="padding_causal",
        attn_bias_type="post_scale_bias",
    ),
    "bias_4_4": ModelConfig(
        4, 2048, 24, 128, attn_mask_type="padding_causal", attn_bias_type="alibi"
    ),
    "bias_4_5": ModelConfig(
        2,
        2048,
        24,
        128,
        max_seqlen_kv=4096,
        attn_mask_type="padding_causal",
        attn_bias_type="alibi",
    ),
}


@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_bias])
@pytest.mark.parametrize("model", model_configs_bias.keys())
def test_dpa_bias(dtype, model_configs, model):
    """Test DotProductAttention module with different bias types"""
    test_dot_product_attention(dtype, model_configs, model, False, None, False, False)


model_configs_bias_shapes = {
    # test: ModelConfig(b, sq, hq, dqk)
    "bias_1_0": ModelConfig(4, 128, 16, 64, attn_bias_type="post_scale_bias", bias_shape="11ss"),
    "bias_1_1": ModelConfig(2, 128, 16, 64, attn_bias_type="post_scale_bias", bias_shape="1hss"),
    "bias_1_2": ModelConfig(4, 2048, 24, 128, attn_bias_type="post_scale_bias", bias_shape="b1ss"),
    "bias_1_3": ModelConfig(2, 2048, 24, 128, attn_bias_type="post_scale_bias", bias_shape="bhss"),
    "bias_1_4": ModelConfig(2, 2048, 24, 128, attn_bias_type="post_scale_bias", bias_shape="111s"),
    "bias_1_5": ModelConfig(
        4,
        2048,
        24,
        128,
        attn_mask_type="causal",
        attn_bias_type="alibi",
        bias_shape="1hss",
        alibi_type="custom",
    ),
    "bias_1_6": ModelConfig(
        2,
        2048,
        24,
        128,
        attn_mask_type="causal",
        attn_bias_type="alibi",
        bias_shape="bhss",
        alibi_type="custom",
    ),
}


@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_bias_shapes])
@pytest.mark.parametrize("model", model_configs_bias_shapes.keys())
def test_dpa_bias_shapes(dtype, model_configs, model):
    """Test DotProductAttention module with different bias types and shapes"""
    test_dot_product_attention(dtype, model_configs, model, False, None, False, False)


model_configs_swa = {
    # test: ModelConfig(b, sq, hq, dqk)
    "swa_1_1": ModelConfig(2, 2048, 16, 64),
    "swa_1_2": ModelConfig(2, 2048, 24, 128, num_gqa_groups=4),
    "swa_1_3": ModelConfig(2, 2048, 24, 128, max_seqlen_kv=4096),
    "swa_2_1": ModelConfig(2, 2048, 16, 64, attn_mask_type="causal"),
    "swa_2_2": ModelConfig(2, 2048, 24, 128, num_gqa_groups=4, attn_mask_type="causal"),
    "swa_2_3": ModelConfig(2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="causal"),
    "swa_3_1": ModelConfig(2, 2048, 16, 64, attn_mask_type="causal_bottom_right"),
    "swa_3_2": ModelConfig(
        2, 2048, 24, 128, num_gqa_groups=4, attn_mask_type="causal_bottom_right"
    ),
    "swa_3_3": ModelConfig(
        2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="causal_bottom_right"
    ),
    "swa_4_1": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding"),
    "swa_4_2": ModelConfig(2, 2048, 24, 128, num_gqa_groups=4, attn_mask_type="padding"),
    "swa_4_3": ModelConfig(2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding"),
    "swa_5_1": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding_causal"),
    "swa_5_2": ModelConfig(2, 2048, 24, 128, num_gqa_groups=4, attn_mask_type="padding_causal"),
    "swa_5_3": ModelConfig(2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding_causal"),
    "swa_6_1": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding_causal_bottom_right"),
    "swa_6_2": ModelConfig(
        2, 2048, 24, 128, num_gqa_groups=4, attn_mask_type="padding_causal_bottom_right"
    ),
    "swa_6_3": ModelConfig(
        2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding_causal_bottom_right"
    ),
}


@pytest.mark.skipif(not FlashAttentionUtils.v2_3_plus, reason="Flash-attn 2.3+ is required.")
@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_swa])
@pytest.mark.parametrize("model", model_configs_swa.keys())
@pytest.mark.parametrize("qkv_layout", ["thd_thd_thd", "sbhd_sbhd_sbhd"])
def test_dpa_sliding_window(dtype, model_configs, model, qkv_layout):
    """Test DotProductAttention module with sliding window attention"""
    config = model_configs[model]
    if qkv_layout == "thd_thd_thd" and "padding" not in config.attn_mask_type:
        pytest.skip("Duplicate test to others with THD and padding mask.")
    test_dot_product_attention(dtype, model_configs, model, False, qkv_layout, True, False)


model_configs_alibi_slopes = {
    # test: ModelConfig(b, sq, hq, dqk)
    "alibi_1_0": ModelConfig(
        2, 128, 16, 64, attn_mask_type="causal", attn_bias_type="alibi", alibi_type="vanilla"
    ),
    "alibi_1_1": ModelConfig(
        1,
        128,
        16,
        64,
        max_seqlen_kv=256,
        attn_mask_type="causal",
        attn_bias_type="alibi",
        alibi_type="vanilla",
    ),
    "alibi_2_0": ModelConfig(
        2, 1024, 24, 128, attn_mask_type="causal", attn_bias_type="alibi", alibi_type="custom"
    ),
    "alibi_2_1": ModelConfig(
        1,
        1024,
        24,
        128,
        max_seqlen_kv=2048,
        attn_mask_type="causal",
        attn_bias_type="alibi",
        alibi_type="custom",
    ),
}


@pytest.mark.skipif(not FlashAttentionUtils.v2_3_plus, reason="Flash-attn 2.3+ is required.")
@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_alibi_slopes])
@pytest.mark.parametrize("model", model_configs_alibi_slopes.keys())
def test_dpa_alibi_slopes(dtype, model_configs, model):
    """Test DotProductAttention module with ALiBi slopes"""
    test_dot_product_attention(dtype, model_configs, model, False, None, False, False)


qkv_layouts = [
    "sb3hd",
    "sbh3d",
    "sbhd_sb2hd",
    "sbhd_sbh2d",
    "sbhd_sbhd_sbhd",
    "bs3hd",
    "bsh3d",
    "bshd_bs2hd",
    "bshd_bsh2d",
    "bshd_bshd_bshd",
]


model_configs_layout = {
    # test: ModelConfig(b, sq, hq, dqk)
    "layout_0_0": ModelConfig(2, 128, 16, 64),
    "layout_0_1": ModelConfig(
        2, 128, 16, 64, attn_mask_type="causal", attn_bias_type="post_scale_bias"
    ),
    "layout_0_2": ModelConfig(1, 128, 16, 64, max_seqlen_kv=256, attn_mask_type="padding"),
    "layout_0_3": ModelConfig(
        1,
        128,
        16,
        64,
        max_seqlen_kv=256,
        attn_mask_type="padding_causal",
        attn_bias_type="post_scale_bias",
    ),
    "layout_1_0": ModelConfig(2, 2048, 24, 128),
    "layout_1_1": ModelConfig(
        2, 2048, 24, 128, attn_mask_type="causal", attn_bias_type="post_scale_bias"
    ),
    "layout_1_2": ModelConfig(1, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding"),
    "layout_1_3": ModelConfig(
        1,
        2048,
        24,
        128,
        max_seqlen_kv=4096,
        attn_mask_type="padding_causal",
        attn_bias_type="post_scale_bias",
    ),
    "layout_2_0": ModelConfig(2, 1, 16, 256, max_seqlen_kv=2048),
    "layout_2_1": ModelConfig(
        2, 2048, 24, 256, attn_mask_type="causal", attn_bias_type="post_scale_bias"
    ),
}


@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_layout])
@pytest.mark.parametrize("model", model_configs_layout.keys())
@pytest.mark.parametrize("qkv_layout", qkv_layouts)
def test_dpa_qkv_layout(dtype, model_configs, model, qkv_layout):
    """Test DotProductAttention module with different QKV layouts"""
    test_dot_product_attention(dtype, model_configs, model, False, qkv_layout, False, False)


qkv_layouts_packed = [l for l in qkv_layouts if any(c.isdigit() for c in l)]


@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_layout])
@pytest.mark.parametrize("model", ["layout_1_1", "layout_1_2"])
@pytest.mark.parametrize("qkv_layout", qkv_layouts_packed)
def test_dpa_qkv_layout_declarative(dtype, model_configs, model, qkv_layout):
    """Declarative packed inputs: the packed buffer is passed to
    DotProductAttention via qkv_layer/kv_layer (declared layout, gradients read
    off the packed buffer) instead of q/k/v views + pointer-based detection.
    Layout coverage is complete; the model-config dimension is trimmed to one
    self-attention and one cross-attention config, since past the input
    handling the backend code is identical to test_dpa_qkv_layout."""
    test_dot_product_attention(
        dtype, model_configs, model, False, qkv_layout, False, False, declarative_packed=True
    )


qkv_layouts_thd = ["t3hd", "th3d", "thd_t2hd", "thd_th2d", "thd_thd_thd"]
model_configs_layout_thd = {
    # test: ModelConfig(b, sq, hq, dqk)
    "layout_0_0": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding"),
    "layout_0_1": ModelConfig(2, 2048, 24, 128, num_gqa_groups=1, attn_mask_type="padding"),
    "layout_0_2": ModelConfig(2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding"),
    "layout_1_0": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding_causal"),
    "layout_1_1": ModelConfig(2, 2048, 24, 128, num_gqa_groups=1, attn_mask_type="padding_causal"),
    "layout_1_2": ModelConfig(
        2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding_causal"
    ),
    "layout_2_0": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding_causal_bottom_right"),
    "layout_2_1": ModelConfig(
        2, 2048, 24, 128, num_gqa_groups=1, attn_mask_type="padding_causal_bottom_right"
    ),
    "layout_2_2": ModelConfig(
        2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding_causal_bottom_right"
    ),
    "layout_3_0": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding", window_size=(4, 4)),
    "layout_3_1": ModelConfig(
        2, 2048, 24, 128, num_gqa_groups=1, attn_mask_type="padding", window_size=(4, 4)
    ),
    "layout_3_2": ModelConfig(
        2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding", window_size=(4, 4)
    ),
    "layout_4_0": ModelConfig(2, 2048, 16, 64, attn_mask_type="padding_causal", window_size=(4, 0)),
    "layout_4_1": ModelConfig(
        2, 2048, 24, 128, num_gqa_groups=1, attn_mask_type="padding_causal", window_size=(4, 0)
    ),
    "layout_4_2": ModelConfig(
        2, 2048, 24, 128, max_seqlen_kv=4096, attn_mask_type="padding_causal", window_size=(4, 0)
    ),
    "layout_5_0": ModelConfig(
        2, 2048, 16, 64, attn_mask_type="padding_causal_bottom_right", window_size=(4, 0)
    ),
    "layout_5_1": ModelConfig(
        2,
        2048,
        24,
        128,
        num_gqa_groups=1,
        attn_mask_type="padding_causal_bottom_right",
        window_size=(4, 0),
    ),
    "layout_5_2": ModelConfig(
        2,
        2048,
        24,
        128,
        max_seqlen_kv=4096,
        attn_mask_type="padding_causal_bottom_right",
        window_size=(4, 0),
    ),
}


@pytest.mark.skipif(
    get_device_compute_capability() < (9, 0), reason="THD is only supported on Hopper+."
)
@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_layout_thd])
@pytest.mark.parametrize("model", model_configs_layout_thd.keys())
@pytest.mark.parametrize("qkv_layout", qkv_layouts_thd)
def test_dpa_qkv_layout_thd(dtype, model_configs, model, qkv_layout, declarative_packed=False):
    """Test DotProductAttention module with different QKV layouts"""
    config = model_configs[model]
    if config.num_heads != config.num_gqa_groups and "3" in qkv_layout:
        pytest.skip("qkv_layout not applicable for MQA/GQA")
    logging.info("[test_dpa_qkv_layout_thd]: pad_between_seqs = True")
    pad_between_seqs = True
    test_dot_product_attention(
        dtype,
        model_configs,
        model,
        False,
        qkv_layout,
        False,
        pad_between_seqs,
        declarative_packed=declarative_packed,
    )
    logging.info("[test_dpa_qkv_layout_thd]: pad_between_seqs = False")
    pad_between_seqs = False
    test_dot_product_attention(
        dtype,
        model_configs,
        model,
        False,
        qkv_layout,
        False,
        pad_between_seqs,
        declarative_packed=declarative_packed,
    )


qkv_layouts_thd_packed = [l for l in qkv_layouts_thd if any(c.isdigit() for c in l)]


@pytest.mark.skipif(
    get_device_compute_capability() < (9, 0), reason="THD is only supported on Hopper+."
)
@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_layout_thd])
@pytest.mark.parametrize("model", ["layout_0_0"])
@pytest.mark.parametrize("qkv_layout", qkv_layouts_thd_packed)
def test_dpa_qkv_layout_thd_declarative(dtype, model_configs, model, qkv_layout):
    """Declarative packed thd inputs, see test_dpa_qkv_layout_declarative."""
    test_dpa_qkv_layout_thd(dtype, model_configs, model, qkv_layout, declarative_packed=True)


def make_cu_seqlens(seqlens: torch.Tensor) -> torch.Tensor:
    """Construct CUDA cumulative sequence lengths from per-sequence lengths."""
    cu_seqlens = torch.zeros(seqlens.numel() + 1, dtype=torch.int32, device=seqlens.device)
    cu_seqlens[1:] = torch.cumsum(seqlens, dim=0)
    return cu_seqlens


def make_dot_product_attention(
    dtype: torch.dtype,
    config: ModelConfig,
    qkv_format: str,
    *,
    get_rng_state_tracker=None,
    is_training: bool = True,
    attention_type: str = None,
) -> DotProductAttention:
    """Construct a configured DotProductAttention test module."""
    block = DotProductAttention(
        config.num_heads,
        (config.head_dim_qk, config.head_dim_v),
        num_gqa_groups=config.num_gqa_groups,
        attention_dropout=config.dropout_p,
        qkv_format=qkv_format,
        attn_mask_type=config.attn_mask_type,
        sequence_parallel=False,
        tp_size=1,
        get_rng_state_tracker=get_rng_state_tracker,
        tp_group=None,
        layer_number=1,
        attention_type=config.attn_type if attention_type is None else attention_type,
        softmax_type=config.softmax_type,
        return_max_logit=config.return_max_logit,
        softcap=config.softcap,
    ).to(dtype=dtype, device="cuda")
    if not is_training:
        block = block.eval()
    if is_training and config.softmax_type != "vanilla":
        block.softmax_offset.requires_grad = True
    return block


class _Seqlens(NamedTuple):
    """Sequence lengths for one test case, before and after inter-sequence padding."""

    q: torch.Tensor
    kv: torch.Tensor
    cu_q: torch.Tensor
    cu_kv: torch.Tensor
    q_after_pad: torch.Tensor
    kv_after_pad: torch.Tensor
    cu_q_after_pad: torch.Tensor
    cu_kv_after_pad: torch.Tensor
    pad_len: Union[List[int], torch.Tensor]


def _generate_seqlens(
    config: ModelConfig,
    qkv_format: str,
    pad_between_seqs: bool,
) -> _Seqlens:
    """Draw the sequence lengths for one test case."""
    if "padding" in config.attn_mask_type or qkv_format == "thd":
        if config.attn_type == "self":
            seqlens_q = torch.randint(
                1, config.max_seqlen_q, [config.batch_size], dtype=torch.int32, device="cuda"
            )
            seqlens_kv = seqlens_q
        if config.attn_type == "cross":
            if config.max_seqlen_q > 1:
                seqlens_q = torch.randint(
                    1, config.max_seqlen_q, [config.batch_size], dtype=torch.int32, device="cuda"
                )
            else:
                seqlens_q = torch.ones([config.batch_size], dtype=torch.int32, device="cuda")
            seqlens_kv = torch.randint(
                1, config.max_seqlen_kv, [config.batch_size], dtype=torch.int32, device="cuda"
            )
    else:
        seqlens_q = torch.full(
            [config.batch_size], config.max_seqlen_q, dtype=torch.int32, device="cuda"
        )
        seqlens_kv = torch.full(
            [config.batch_size], config.max_seqlen_kv, dtype=torch.int32, device="cuda"
        )
    cu_seqlens_q = make_cu_seqlens(seqlens_q)
    cu_seqlens_kv = make_cu_seqlens(seqlens_kv)

    seqlens_q_after_pad = seqlens_q.clone()
    seqlens_kv_after_pad = seqlens_kv.clone()
    cu_seqlens_q_after_pad = cu_seqlens_q.clone()
    cu_seqlens_kv_after_pad = cu_seqlens_kv.clone()
    pad_len = [0] * config.batch_size
    if pad_between_seqs:
        max_pad_len = 3
        pad_len = torch.randint(0, max_pad_len + 1, [config.batch_size], device="cuda")  # 3
        seqlens_q_after_pad = seqlens_q + pad_len
        seqlens_kv_after_pad = seqlens_kv + pad_len
        cu_seqlens_q_after_pad[1:] = torch.cumsum(seqlens_q_after_pad, dim=0)
        cu_seqlens_kv_after_pad[1:] = torch.cumsum(seqlens_kv_after_pad, dim=0)

    return _Seqlens(
        seqlens_q,
        seqlens_kv,
        cu_seqlens_q,
        cu_seqlens_kv,
        seqlens_q_after_pad,
        seqlens_kv_after_pad,
        cu_seqlens_q_after_pad,
        cu_seqlens_kv_after_pad,
        pad_len,
    )


def run_dot_product_attention(
    dtype: torch.dtype,
    config: ModelConfig,
    backend: str,
    ckpt_attn: bool,
    qkv_layout: str,
    pad_between_seqs: bool,
    is_training: bool,
    declarative_packed: bool = False,
    forward_kwargs: Dict[str, Any] = None,
) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor, torch.Tensor]]:
    """Run DotProductAttention module with one forward pass and one backward pass.

    With declarative_packed=True (packed qkv_layout only), the packed buffer is
    passed to DotProductAttention directly via qkv_layer/kv_layer instead of
    slicing it into q/k/v views, and input gradients are read off the packed
    buffer itself."""
    # Set RNG and environment varables
    reset_rng_states()
    os.environ["NVTE_FLASH_ATTN"] = "0"
    os.environ["NVTE_FUSED_ATTN"] = "0"
    os.environ["NVTE_UNFUSED_ATTN"] = "0"
    if backend == "FlashAttention":
        os.environ["NVTE_FLASH_ATTN"] = "1"
    if backend == "FusedAttention":
        os.environ["NVTE_FUSED_ATTN"] = "1"
    if backend == "UnfusedDotProductAttention":
        os.environ["NVTE_UNFUSED_ATTN"] = "1"
    _attention_backends["backend_selection_requires_update"] = True

    # Create seqlens
    qkv_format = "".join([i for i in qkv_layout.split("_")[0] if i.isalpha()])
    (
        seqlens_q,
        seqlens_kv,
        cu_seqlens_q,
        cu_seqlens_kv,
        seqlens_q_after_pad,
        seqlens_kv_after_pad,
        cu_seqlens_q_after_pad,
        cu_seqlens_kv_after_pad,
        pad_len,
    ) = _generate_seqlens(config, qkv_format, pad_between_seqs)

    # Create attention mask if padding
    attention_mask = None
    if "padding" in config.attn_mask_type:
        if config.attn_type == "self":
            attention_mask_q = torch.Tensor([]).to(dtype=torch.bool)
            for i in range(config.batch_size):
                attention_mask_q = torch.cat(
                    [
                        attention_mask_q,
                        torch.Tensor(
                            [False] * seqlens_q[i] + [True] * (config.max_seqlen_q - seqlens_q[i])
                        )
                        .to(dtype=torch.bool)
                        .unsqueeze(0)
                        .unsqueeze(0)
                        .unsqueeze(0),
                    ],
                    dim=0,
                )
            attention_mask = attention_mask_q.to(device="cuda")
        if config.attn_type == "cross":
            attention_mask_q = torch.Tensor([]).to(dtype=torch.bool)
            attention_mask_kv = torch.Tensor([]).to(dtype=torch.bool)
            for i in range(config.batch_size):
                attention_mask_q = torch.cat(
                    [
                        attention_mask_q,
                        torch.Tensor(
                            [False] * seqlens_q[i] + [True] * (config.max_seqlen_q - seqlens_q[i])
                        )
                        .to(dtype=torch.bool)
                        .unsqueeze(0)
                        .unsqueeze(0)
                        .unsqueeze(0),
                    ],
                    dim=0,
                )
                attention_mask_kv = torch.cat(
                    [
                        attention_mask_kv,
                        torch.Tensor(
                            [False] * seqlens_kv[i]
                            + [True] * (config.max_seqlen_kv - seqlens_kv[i])
                        )
                        .to(dtype=torch.bool)
                        .unsqueeze(0)
                        .unsqueeze(0)
                        .unsqueeze(0),
                    ],
                    dim=0,
                )
            attention_mask = (
                attention_mask_q.to(device="cuda"),
                attention_mask_kv.to(device="cuda"),
            )

    alibi_slopes = None
    if config.attn_bias_type == "alibi" and config.alibi_type == "custom":
        if config.bias_shape == "1hss":
            alibi_slopes = (
                torch.randn(config.num_heads).abs().to(dtype=torch.float32, device="cuda")
            )
        if config.bias_shape == "bhss":
            alibi_slopes = (
                torch.randn(config.batch_size, config.num_heads)
                .abs()
                .to(dtype=torch.float32, device="cuda")
            )

    # Create input tensors
    dim_to_num = {
        "b": config.batch_size,
        "sq": config.max_seqlen_q,
        "skv": config.max_seqlen_kv,
        "h": config.num_heads,
        "hg": config.num_gqa_groups,
        "dqk": config.head_dim_qk,
        "dv": config.head_dim_v,
        "t": cu_seqlens_q_after_pad[-1],
        "tg": cu_seqlens_kv_after_pad[-1],
        "3": 3,
        "2": 2,
        "1": 1,
    }
    inp = []
    inp_orig = []
    for i, layout in enumerate(qkv_layout.split("_")):
        layout = "_".join(layout)
        if i == 0:
            layout = layout.replace("s", "sq")
        else:
            layout = layout.replace("s", "skv")
            layout = layout.replace("h", "hg")
            layout = layout.replace("t", "tg")
        if i == 2:
            layout = layout.replace("d", "dv")
        else:
            layout = layout.replace("d", "dqk")
        tensor_shape = [dim_to_num[j] for j in layout.split("_")]
        tensor = 0.1 * torch.randn(tensor_shape, dtype=dtype, device="cuda")
        # tensor: with padding tokens
        # tensor_orig: without padding tokens
        tensor_orig = tensor
        if qkv_format == "thd" and pad_between_seqs:
            tensor_orig = torch.Tensor([]).to(device="cuda", dtype=dtype)
            if layout in ["t_h_dqk", "t_3_h_dqk", "t_h_3_dqk"]:
                for i in range(1, config.batch_size + 1):
                    valid_range = (
                        cu_seqlens_q_after_pad[i - 1],
                        cu_seqlens_q_after_pad[i] - pad_len[i - 1],
                    )
                    pad_range = (
                        cu_seqlens_q_after_pad[i] - pad_len[i - 1],
                        cu_seqlens_q_after_pad[i],
                    )
                    tensor[pad_range[0] : pad_range[1]] = 0.0
                    tensor_orig = torch.cat(
                        [tensor_orig, tensor[valid_range[0] : valid_range[1]]], dim=0
                    )
            if layout in ["tg_hg_dqk", "tg_2_hg_dqk", "tg_hg_2_dqk", "tg_hg_dv"]:
                for i in range(1, config.batch_size + 1):
                    valid_range = (
                        cu_seqlens_kv_after_pad[i - 1],
                        cu_seqlens_kv_after_pad[i] - pad_len[i - 1],
                    )
                    pad_range = (
                        cu_seqlens_kv_after_pad[i] - pad_len[i - 1],
                        cu_seqlens_kv_after_pad[i],
                    )
                    tensor[pad_range[0] : pad_range[1]] = 0.0
                    tensor_orig = torch.cat(
                        [tensor_orig, tensor[valid_range[0] : valid_range[1]]], dim=0
                    )
        tensor_count = 1
        split_dim = 0
        for dim, l in enumerate(layout.split("_")):
            if l.isdigit():
                tensor_count = int(l)
                split_dim = dim
                break
        if declarative_packed and split_dim != 0:
            # The packed buffer is the autograd leaf; q/k/v below are non-leaf
            # views of it, and DPA receives the buffer via qkv_layer/kv_layer.
            tensor.requires_grad_()
            packed_tensor = tensor
            packed_interleave_dim = split_dim - tensor.dim()
        tensors = torch.split(tensor, 1, dim=split_dim) if split_dim != 0 else [tensor]
        tensors_orig = (
            torch.split(tensor_orig, 1, dim=split_dim) if split_dim != 0 else [tensor_orig]
        )
        for j in range(tensor_count):
            if split_dim != 0:
                inp.append(tensors[j].squeeze(split_dim))
                inp_orig.append(tensors_orig[j].squeeze(split_dim))
            else:
                inp.append(tensors[j])
                inp_orig.append(tensors_orig[j])
    for i in range(3):
        if inp[i].is_leaf:
            inp[i].requires_grad = True
        if inp_orig[i].is_leaf:
            inp_orig[i].requires_grad = True

    # Create output gradient
    qkv_format_kv = "_".join(qkv_format)
    qkv_format_kv = qkv_format_kv.replace("s", "sq")
    qkv_format_kv = qkv_format_kv.replace("d", "dv")
    out_grad_shape = [dim_to_num[i] for i in qkv_format_kv.split("_")]
    out_grad_shape_new = [*out_grad_shape[:-2], out_grad_shape[-2] * out_grad_shape[-1]]
    out_grad = 0.001 * torch.randint(0, 200, out_grad_shape_new, dtype=dtype, device="cuda")
    out_grad_orig = out_grad
    if qkv_format == "thd" and pad_between_seqs:
        out_grad_orig = torch.Tensor([]).to(device="cuda", dtype=dtype)
        if qkv_format_kv == "t_h_dv":
            for i in range(1, config.batch_size + 1):
                valid_range = (
                    cu_seqlens_q_after_pad[i - 1],
                    cu_seqlens_q_after_pad[i] - pad_len[i - 1],
                )
                pad_range = (cu_seqlens_q_after_pad[i] - pad_len[i - 1], cu_seqlens_q_after_pad[i])
                out_grad[pad_range[0] : pad_range[1]] = 0.0
                out_grad_orig = torch.cat(
                    [out_grad_orig, out_grad[valid_range[0] : valid_range[1]]], dim=0
                )

    # Create bias
    if config.attn_bias_type in ["no_bias", "alibi"]:
        bias = None
    if config.attn_bias_type == "post_scale_bias":
        shape = "_".join(config.bias_shape)
        # For 1hss, 11ss, b1ss, bhss
        shape_cache = shape
        shape = shape.replace("_s_s", "_sq_skv")
        # For 111s
        if shape == shape_cache:
            shape = shape.replace("_1_s", "_1_skv")
        tensor_shape = [dim_to_num[j] for j in shape.split("_")]
        bias = torch.randn(tensor_shape, dtype=dtype, device="cuda")
        # For 111s, dbias calculation is not supported as of cuDNN 9.18
        if config.bias_shape == "111s":
            bias.requires_grad = False

    # Create RNG
    _DUMMY_CUDA_RNG_STATE_TRACKER = CudaRNGStatesTracker()
    _DUMMY_CUDA_RNG_STATE_TRACKER.add("model-parallel-rng", seed)

    def get_dummy_cuda_rng_tracker() -> CudaRNGStatesTracker:
        """Get cuda rng tracker."""
        return _DUMMY_CUDA_RNG_STATE_TRACKER

    # Set up model
    block = make_dot_product_attention(
        dtype,
        config,
        qkv_format,
        get_rng_state_tracker=get_dummy_cuda_rng_tracker,
        is_training=is_training,
    )

    # Run a forward and backward pass
    if backend in ["UnfusedDotProductAttention"]:
        q = inp_orig[0]
        k = inp_orig[1]
        v = inp_orig[2]
        d_out = out_grad_orig
    if backend in ["FusedAttention", "FlashAttention"]:
        q = inp[0]
        k = inp[1]
        v = inp[2]
        d_out = out_grad
    packed_kwargs = {}
    if declarative_packed:
        assert backend in ["FusedAttention", "FlashAttention"]
        packed_kwargs["qkv_interleave_dim"] = packed_interleave_dim
        if len(qkv_layout.split("_")) == 1:
            packed_kwargs["qkv_layer"] = packed_tensor
            q, k, v = None, None, None
        else:
            packed_kwargs["kv_layer"] = packed_tensor
            k, v = None, None
    dpa_forward_kwargs = dict(
        window_size=config.window_size,
        attention_mask=attention_mask,
        qkv_format=qkv_format,
        max_seqlen_q=config.max_seqlen_q,
        max_seqlen_kv=config.max_seqlen_kv,
        cu_seqlens_q=cu_seqlens_q,
        cu_seqlens_kv=cu_seqlens_kv,
        cu_seqlens_q_padded=(
            cu_seqlens_q_after_pad if backend in ["FusedAttention", "FlashAttention"] else None
        ),
        cu_seqlens_kv_padded=(
            cu_seqlens_kv_after_pad if backend in ["FusedAttention", "FlashAttention"] else None
        ),
        attn_mask_type=config.attn_mask_type,
        checkpoint_core_attention=ckpt_attn,
        core_attention_bias_type=config.attn_bias_type,
        core_attention_bias=bias,
        alibi_slopes=alibi_slopes,
        fast_zero_fill=True,
        pad_between_seqs=pad_between_seqs,
        # Only pass num_splits when exercising the FlashAttention path
        num_splits=config.num_splits if backend == "FlashAttention" else 1,
    )
    if forward_kwargs is not None:
        dpa_forward_kwargs.update(forward_kwargs)
    out = block(q, k, v, **packed_kwargs, **dpa_forward_kwargs)
    max_logit = None
    if config.return_max_logit:
        out, max_logit = out
    if is_training:
        out.backward(d_out)

    q_grad, k_grad, v_grad = None, None, None
    if is_training:
        if declarative_packed:
            # Input gradients live on the packed buffer; slice them back out so
            # the cross-backend comparisons below stay uniform with the
            # separate-q/k/v path.
            assert (
                packed_tensor.grad is not None and packed_tensor.grad.shape == packed_tensor.shape
            )
            packed_grads = [
                packed_tensor.grad.select(packed_interleave_dim, j)
                for j in range(packed_tensor.shape[packed_interleave_dim])
            ]
            if len(qkv_layout.split("_")) == 1:
                q_grad, k_grad, v_grad = packed_grads
            else:
                q_grad = q.grad
                k_grad, v_grad = packed_grads
        else:
            q_grad, k_grad, v_grad = q.grad, k.grad, v.grad

    d_softmax_offset = None
    if is_training and config.softmax_type != "vanilla":
        d_softmax_offset = block.softmax_offset.grad

    if backend in ["UnfusedDotProductAttention"]:
        return out, max_logit, (q_grad, k_grad, v_grad, d_softmax_offset)
    if backend == "FlashAttention" and qkv_format == "thd" and pad_between_seqs:
        tensors_and_boundaries = [("out", out, cu_seqlens_q, cu_seqlens_q_after_pad)]
        if is_training:
            tensors_and_boundaries.extend(
                [
                    ("dq", q_grad, cu_seqlens_q, cu_seqlens_q_after_pad),
                    ("dk", k_grad, cu_seqlens_kv, cu_seqlens_kv_after_pad),
                    ("dv", v_grad, cu_seqlens_kv, cu_seqlens_kv_after_pad),
                ]
            )
        for tensor_name, tensor, cu_seqlens, cu_seqlens_padded in tensors_and_boundaries:
            padding_mask = get_thd_padding_mask(tensor.shape[0], cu_seqlens, cu_seqlens_padded)
            assert (
                torch.count_nonzero(tensor[padding_mask]).item() == 0
            ), f"{backend} left nonzero values in {tensor_name} padding"

    if backend in ["FusedAttention", "FlashAttention"]:
        if qkv_format == "thd" and pad_between_seqs:
            out_orig = torch.Tensor([]).to(device="cuda", dtype=dtype)
            if is_training:
                q_grad_orig = torch.Tensor([]).to(device="cuda", dtype=dtype)
                k_grad_orig = torch.Tensor([]).to(device="cuda", dtype=dtype)
                v_grad_orig = torch.Tensor([]).to(device="cuda", dtype=dtype)
            for i in range(1, config.batch_size + 1):
                valid_range_q = (
                    cu_seqlens_q_after_pad[i - 1],
                    cu_seqlens_q_after_pad[i] - pad_len[i - 1],
                )
                valid_range_kv = (
                    cu_seqlens_kv_after_pad[i - 1],
                    cu_seqlens_kv_after_pad[i] - pad_len[i - 1],
                )
                out_orig = torch.cat([out_orig, out[valid_range_q[0] : valid_range_q[1]]], dim=0)
                if is_training:
                    q_grad_orig = torch.cat(
                        [q_grad_orig, q_grad[valid_range_q[0] : valid_range_q[1]]], dim=0
                    )
                    k_grad_orig = torch.cat(
                        [k_grad_orig, k_grad[valid_range_kv[0] : valid_range_kv[1]]], dim=0
                    )
                    v_grad_orig = torch.cat(
                        [v_grad_orig, v_grad[valid_range_kv[0] : valid_range_kv[1]]], dim=0
                    )
            if is_training:
                return (
                    out_orig,
                    max_logit,
                    (q_grad_orig, k_grad_orig, v_grad_orig, d_softmax_offset),
                )
            else:
                return out_orig, max_logit, (None, None, None, d_softmax_offset)
        else:
            return out, max_logit, (q_grad, k_grad, v_grad, d_softmax_offset)


model_configs_te_layer = {
    # test: ModelConfig(b, sq, hq, dqk)
    "te_1_0": ModelConfig(2, 128, 16, 64, attn_bias_type="post_scale_bias"),
    "te_1_1": ModelConfig(
        4, 128, 16, 64, attn_mask_type="causal", attn_bias_type="post_scale_bias"
    ),
    "te_1_2": ModelConfig(
        2, 128, 16, 64, attn_mask_type="padding", attn_bias_type="post_scale_bias"
    ),
    "te_1_3": ModelConfig(2, 128, 16, 64, max_seqlen_kv=256, attn_mask_type="padding"),
    "te_2_0": ModelConfig(1, 2048, 16, 64, attn_mask_type="causal"),
    "te_2_1": ModelConfig(2, 2048, 16, 64),
    "te_2_2": ModelConfig(1, 2048, 16, 64, attn_mask_type="padding"),
    "te_2_3": ModelConfig(
        1, 2048, 16, 64, max_seqlen_kv=4096, attn_mask_type="padding_causal_bottom_right"
    ),
    "te_3_0": ModelConfig(4, 128, 16, 64, attn_mask_type="causal", attn_bias_type="alibi"),
    "te_3_1": ModelConfig(4, 2048, 16, 64, attn_mask_type="causal", attn_bias_type="alibi"),
}


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("model_configs", [model_configs_te_layer])
@pytest.mark.parametrize("model", model_configs_te_layer.keys())
@pytest.mark.parametrize("ckpt_attn", [False])
@pytest.mark.parametrize("qkv_format", ["sbhd", "bshd", "thd"])
@pytest.mark.parametrize("fused_qkv_params", [False])
@pytest.mark.parametrize("RoPE", [False])
def test_transformer_layer(
    dtype, model_configs, model, ckpt_attn, qkv_format, fused_qkv_params, RoPE
):
    """Test TransformerLayer module"""

    # Get configs
    config = model_configs[model]
    tols = dict(atol=5e-2, rtol=5e-2)

    # Test backend availability
    is_training = True
    # Get the token counts for THD and use them for both support query and actual execution
    num_tokens_q, num_tokens_kv = None, None
    if qkv_format == "thd":
        reset_rng_states()
        seqlens = _generate_seqlens(config, qkv_format, pad_between_seqs=False)
        num_tokens_q = int(seqlens.cu_q[-1])
        num_tokens_kv = int(seqlens.cu_kv[-1])
    available_backends, _, fused_attn_backends = get_available_attention_backends(
        config,
        qkv_dtype=dtype,
        qkv_layout=(
            qkv_format.replace("hd", "h3d") if fused_qkv_params else qkv_format.replace("hd", "3hd")
        ),
        is_training=is_training,
        deterministic=_deterministic,
        num_tokens_q=num_tokens_q,
        num_tokens_kv=num_tokens_kv,
    )
    flash_attn_supported, fused_attn_supported, unfused_attn_supported = available_backends
    if not fused_attn_supported:
        is_training = False
        available_backends, _, fused_attn_backends = get_available_attention_backends(
            config,
            qkv_dtype=dtype,
            qkv_layout=(
                qkv_format.replace("hd", "h3d")
                if fused_qkv_params
                else qkv_format.replace("hd", "3hd")
            ),
            is_training=is_training,
            deterministic=_deterministic,
            num_tokens_q=num_tokens_q,
            num_tokens_kv=num_tokens_kv,
        )
        flash_attn_supported, fused_attn_supported, unfused_attn_supported = available_backends

    # Skip if only unfused backend is supported
    if (len(fused_attn_backends) + flash_attn_supported + unfused_attn_supported) < 2:
        pytest.skip("Less than two backends to compare.")
    # Skip if qkv_format = thd and "padding" not in attn_mask_type
    if qkv_format == "thd" and "padding" not in config.attn_mask_type:
        pytest.skip("THD requires padding mask.")

    # UnfusedDotProductAttention backend
    if unfused_attn_supported:
        unfused_attn_fwd, unfused_attn_bwd = _run_transformer_layer(
            dtype,
            config,
            "UnfusedDotProductAttention",
            ckpt_attn,
            qkv_format,
            fused_qkv_params,
            RoPE,
            is_training,
        )

    # FusedAttention backend
    if fused_attn_supported:
        fused_attn_fwd, fused_attn_bwd = _run_transformer_layer(
            dtype,
            config,
            "FusedAttention",
            ckpt_attn,
            qkv_format,
            fused_qkv_params,
            RoPE,
            is_training,
        )

    # FlashAttention backend
    if flash_attn_supported:
        flash_attn_fwd, flash_attn_bwd = _run_transformer_layer(
            dtype,
            config,
            "FlashAttention",
            ckpt_attn,
            qkv_format,
            fused_qkv_params,
            RoPE,
            is_training,
        )

    logging.info(f"[test_transformer_layer]: is_training = {is_training}")
    if unfused_attn_supported and fused_attn_supported:
        logging.info("[test_transformer_layer]: unfused attn vs fused attn")
        torch.testing.assert_close(fused_attn_fwd, unfused_attn_fwd, **tols)
        torch.testing.assert_close(fused_attn_bwd, unfused_attn_bwd, **tols)
    if unfused_attn_supported and flash_attn_supported:
        logging.info("[test_transformer_layer]: unfused attn vs flash attn")
        torch.testing.assert_close(flash_attn_fwd, unfused_attn_fwd, **tols)
        torch.testing.assert_close(flash_attn_bwd, unfused_attn_bwd, **tols)
    if fused_attn_supported and flash_attn_supported:
        logging.info("[test_transformer_layer]: fused attn vs flash attn")
        torch.testing.assert_close(fused_attn_fwd, flash_attn_fwd, **tols)
        torch.testing.assert_close(fused_attn_bwd, flash_attn_bwd, **tols)


@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_te_layer])
@pytest.mark.parametrize("model", ["te_1_2", "te_2_0"])
@pytest.mark.parametrize("qkv_format", ["bshd", "sbhd"])
def test_te_layer_misc(dtype, model_configs, model, qkv_format):
    """Test TransformerLayer module with miscellaneous settings"""
    ckpt_attn = True
    fused_qkv_params = True
    RoPE = True
    test_transformer_layer(
        dtype, model_configs, model, ckpt_attn, qkv_format, fused_qkv_params, RoPE
    )


@pytest.mark.parametrize("dtype", param_types_lean)
@pytest.mark.parametrize("model_configs", [model_configs_te_layer])
@pytest.mark.parametrize("model", ["te_2_0", "te_2_1", "te_2_2"])
def test_te_layer_mqa_gqa(dtype, model_configs, model):
    """Test TransformerLayer module with MQA/GQA"""

    def find_factors(x):
        f = []
        for i in range(2, x + 1):
            if x % i == 0:
                f.append(i)
        return f

    ckpt_attn = True
    qkv_format = "bshd"
    fused_qkv_params = True
    RoPE = True
    config = model_configs[model]
    num_querys_per_gqa_group = find_factors(config.num_heads)

    for num_q_per_gqa_group in num_querys_per_gqa_group:
        config.num_gqa_groups = config.num_heads // num_q_per_gqa_group
        test_transformer_layer(
            dtype, model_configs, model, ckpt_attn, qkv_format, fused_qkv_params, RoPE
        )


def _run_transformer_layer(
    dtype: torch.dtype,
    config: ModelConfig,
    backend: str,
    ckpt_attn: bool,
    qkv_format: str,
    fused_qkv_params: bool,
    RoPE: bool,
    is_training: bool,
) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor, torch.Tensor]]:
    """Run TransformerLayer module with one forward pass and one backward pass"""

    # Set RNG and environment variables
    reset_rng_states()
    os.environ["NVTE_FLASH_ATTN"] = "0"
    os.environ["NVTE_FUSED_ATTN"] = "0"
    os.environ["NVTE_UNFUSED_ATTN"] = "0"
    if backend == "FlashAttention":
        os.environ["NVTE_FLASH_ATTN"] = "1"
    if backend == "FusedAttention":
        os.environ["NVTE_FUSED_ATTN"] = "1"
    if backend == "UnfusedDotProductAttention":
        os.environ["NVTE_UNFUSED_ATTN"] = "1"
    _attention_backends["backend_selection_requires_update"] = True

    # Create input tensor
    if qkv_format == "sbhd":
        inp = torch.randn(
            config.max_seqlen_q,
            config.batch_size,
            config.hidden_size,
            dtype=dtype,
            device="cuda",
            requires_grad=True,
        )
        inp_enc = torch.randn(
            config.max_seqlen_kv,
            config.batch_size,
            config.hidden_size,
            dtype=dtype,
            device="cuda",
            requires_grad=True,
        )
    if qkv_format == "bshd":
        inp = torch.randn(
            config.batch_size,
            config.max_seqlen_q,
            config.hidden_size,
            dtype=dtype,
            device="cuda",
            requires_grad=True,
        )
        inp_enc = torch.randn(
            config.batch_size,
            config.max_seqlen_kv,
            config.hidden_size,
            dtype=dtype,
            device="cuda",
            requires_grad=True,
        )

    # Create seqlens
    if "padding" in config.attn_mask_type or qkv_format == "thd":
        if config.attn_type == "self":
            seqlens_q = torch.randint(
                1, config.max_seqlen_q, [config.batch_size], dtype=torch.int32, device="cuda"
            )
            seqlens_kv = seqlens_q
        if config.attn_type == "cross":
            if config.max_seqlen_q > 1:
                seqlens_q = torch.randint(
                    1, config.max_seqlen_q, [config.batch_size], dtype=torch.int32, device="cuda"
                )
            else:
                seqlens_q = torch.ones([config.batch_size], dtype=torch.int32, device="cuda")
            seqlens_kv = torch.randint(
                1, config.max_seqlen_kv, [config.batch_size], dtype=torch.int32, device="cuda"
            )
    else:
        seqlens_q = torch.full(
            [config.batch_size], config.max_seqlen_q, dtype=torch.int32, device="cuda"
        )
        seqlens_kv = torch.full(
            [config.batch_size], config.max_seqlen_kv, dtype=torch.int32, device="cuda"
        )
    cu_seqlens_q = torch.zeros(config.batch_size + 1, dtype=torch.int32, device="cuda")
    cu_seqlens_kv = torch.zeros(config.batch_size + 1, dtype=torch.int32, device="cuda")
    cu_seqlens_q[1:] = torch.cumsum(seqlens_q, dim=0)
    cu_seqlens_kv[1:] = torch.cumsum(seqlens_kv, dim=0)
    if qkv_format == "thd":
        inp = torch.randn(
            cu_seqlens_q[-1],
            config.hidden_size,
            dtype=dtype,
            device="cuda",
            requires_grad=True,
        )
        inp_enc = torch.randn(
            cu_seqlens_kv[-1],
            config.hidden_size,
            dtype=dtype,
            device="cuda",
            requires_grad=True,
        )

    sigma = 0.02
    init_method = init_method_normal(sigma)
    output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)

    layer_number = 1
    drop_path_rate = 0.0
    drop_path_rates = [rate.item() for rate in torch.linspace(0, drop_path_rate, config.num_layers)]

    # Create bias
    bias = None
    if config.attn_bias_type == "post_scale_bias":
        bias = torch.randn(
            1,
            config.num_heads,
            config.max_seqlen_q,
            config.max_seqlen_kv,
            dtype=dtype,
            device="cuda",
        )

    # Create RoPE
    rotary_pos_emb = None
    if RoPE:
        PE = RotaryPositionEmbedding(dim=config.head_dim_qk)
        rotary_pos_emb = PE(config.max_seqlen_q).to(device="cuda")

    # Set up model
    block = TransformerLayer(
        config.hidden_size,
        4 * config.hidden_size,
        config.num_heads,
        num_gqa_groups=config.num_gqa_groups,
        layernorm_epsilon=1e-5,
        hidden_dropout=0.0,
        attention_dropout=config.dropout_p,
        init_method=init_method,
        output_layer_init_method=output_layer_init_method,
        layer_number=layer_number,
        kv_channels=config.head_dim_qk,
        self_attn_mask_type=config.attn_mask_type,
        tp_group=None,
        tp_size=1,
        params_dtype=dtype,
        get_rng_state_tracker=None,
        fuse_wgrad_accumulation=False,
        seq_length=config.max_seqlen_q,
        micro_batch_size=config.batch_size,
        sequence_parallel=False,
        apply_residual_connection_post_layernorm=False,
        output_layernorm=False,
        layer_type="encoder" if config.attn_type == "self" else "decoder",
        drop_path_rate=drop_path_rates[layer_number - 1],
        set_parallel_mode=True,
        fuse_qkv_params=fused_qkv_params,
        zero_centered_gamma=False,
        qkv_weight_interleaved=False,
        ub_tp_comm_overlap=False,
        bias=True,
        attn_input_format=qkv_format,
    ).to(dtype=dtype, device="cuda")
    if not is_training:
        block = block.eval()

    # Create ALiBi slopes
    alibi_slopes = None
    if config.attn_bias_type == "alibi" and config.alibi_type == "custom":
        alibi_slopes = torch.randn(config.num_heads).abs().to(dtype=torch.float32, device="cuda")

    # Run a forward and backward pass
    out = block(
        inp,
        self_attn_mask_type=config.attn_mask_type,
        encoder_output=inp_enc if config.attn_type == "cross" else None,
        enc_dec_attn_mask_type=config.attn_mask_type if config.attn_type == "cross" else None,
        checkpoint_core_attention=False,
        rotary_pos_emb=rotary_pos_emb,
        core_attention_bias_type=config.attn_bias_type,
        core_attention_bias=bias,
        alibi_slopes=alibi_slopes,
        max_seqlen_q=config.max_seqlen_q,
        max_seqlen_kv=config.max_seqlen_kv,
        cu_seqlens_q=cu_seqlens_q,
        cu_seqlens_kv=cu_seqlens_kv,
    )
    if is_training:
        loss = out.sum()
        loss.backward()

    return out, inp.grad


model_configs_fp8_extra_state = {
    # test: ModelConfig(b, sq, hq, dqk)
    "large": ModelConfig(2, 128, 4, 128, num_layers=1),
}


@pytest.mark.skipif(not fp8_attn_available, reason=reason_for_no_fp8_attn)
@pytest.mark.parametrize("model", ["large"])
@pytest.mark.parametrize("dtype", [torch.float16, torch.bfloat16])
def test_dpa_fp8_extra_state(model, dtype):
    """Test DotProductAttention module in FP8 with checkpointing"""
    config = model_configs_fp8_extra_state[model]
    # Test backend availability
    is_training = True
    fp8_recipe = recipe.DelayedScaling(
        margin=0,
        fp8_format=recipe.Format.HYBRID,
        amax_history_len=1,
        amax_compute_algo="most_recent",
        fp8_dpa=True,
    )
    fp8_meta = {}
    fp8_meta["recipe"] = fp8_recipe
    available_backends, _, fused_attn_backends = get_available_attention_backends(
        config,
        qkv_dtype=torch.float8_e4m3fn,
        nominal_dtype=dtype,
        qkv_layout="sb3hd",
        is_training=is_training,
        deterministic=_deterministic,
        fp8=True,
        fp8_meta=fp8_meta,
    )
    flash_attn_supported, fused_attn_supported, unfused_attn_supported = available_backends
    if not fused_attn_supported and not flash_attn_supported:
        pytest.skip("No attention backend available.")

    outputs = _run_dpa_fp8_extra_state(dtype, config, checkpoint=False)
    outputs_checkpoint = _run_dpa_fp8_extra_state(dtype, config, checkpoint=True)
    outputs_checkpoint_v1_6 = _run_dpa_fp8_extra_state(
        dtype, config, mimic_v1_6=True, checkpoint=True
    )

    # Check that results match
    tols = dtype_tols(dtype)
    if dtype in (torch.float16, torch.bfloat16):
        tols.update(dict(rtol=2e-2, atol=2e-3))
    for i, (ref, test) in enumerate(zip(outputs, outputs_checkpoint)):
        torch.testing.assert_close(
            test,
            ref,
            **tols,
        )
    for i, (ref, test) in enumerate(zip(outputs, outputs_checkpoint_v1_6)):
        torch.testing.assert_close(
            test,
            ref,
            **tols,
        )


def _run_dpa_fp8_extra_state(dtype, config, checkpoint=False, mimic_v1_6=False):
    """Run DotProductAttention module in FP8 with checkpointing"""
    steps = 10
    path = "checkpoint.pt"
    fp8_enabled = True
    fp8_recipe = recipe.DelayedScaling(
        margin=0,
        fp8_format=recipe.Format.HYBRID,
        amax_history_len=1,
        amax_compute_algo="most_recent",
        fp8_dpa=fp8_enabled,
        fp8_mha=False,
    )

    reset_rng_states()
    hidden_states = torch.randn(
        (config.max_seqlen_q, config.batch_size, config.hidden_size),
        dtype=dtype,
        device="cuda",
        requires_grad=True,
    )

    def get_model(dtype, config):
        sigma = 0.023
        init_method = init_method_normal(sigma)
        output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)

        with quantized_model_init(enabled=fp8_enabled, recipe=fp8_recipe):
            block = TransformerLayer(
                config.hidden_size,
                4 * config.hidden_size,
                config.num_heads,
                init_method=init_method,
                output_layer_init_method=output_layer_init_method,
                hidden_dropout=0.0,
                attention_dropout=0.0,
                fuse_qkv_params=True,
                params_dtype=dtype,
                device="cuda",
            )
        return block

    block = get_model(dtype, config)
    for i in range(steps // 2):
        with autocast(enabled=fp8_enabled, recipe=fp8_recipe):
            output = block(hidden_states, None)
            loss = output.sum()
            loss.backward()

    if checkpoint:
        sd = block.state_dict()
        if mimic_v1_6:
            sd["self_attention.core_attention.fused_attention._extra_state"] = sd[
                "self_attention.core_attention._extra_state"
            ]
            del sd["self_attention.core_attention._extra_state"]
        torch.save(sd, path)

        param_grads = []
        for p in block.parameters():
            if p.requires_grad:
                param_grads.append(p.grad.clone())

        _cpu_rng_state_new = torch.get_rng_state()
        _cuda_rng_state_new = torch.cuda.get_rng_state()

        del block
        block = get_model(dtype, config)
        block.load_state_dict(torch.load(path, weights_only=False))
        torch.set_rng_state(_cpu_rng_state_new)
        torch.cuda.set_rng_state(_cuda_rng_state_new)

        for p in block.parameters():
            if p.requires_grad:
                p.grad = param_grads.pop(0)

        assert not param_grads, "Oops!"

    for i in range((steps + 1) // 2):
        with autocast(enabled=fp8_enabled, recipe=fp8_recipe):
            output = block(hidden_states, None)
            loss = output.sum()
            loss.backward()

    torch.cuda.synchronize()

    if os.path.exists(path):
        os.remove(path)

    outputs = [output, hidden_states.grad]
    for p in block.parameters():
        if p.requires_grad:
            outputs.append(p.grad)

    return outputs


attn_mask_type = "causal"
model_configs_fp8_vs_f16 = {
    # test: ModelConfig(b, sq, hq, dqk)
    "fp8_9": ModelConfig(
        2,
        2048,
        128,
        192,
        head_dim_v=128,
    ),
    "fp8_10": ModelConfig(
        2,
        2048,
        128,
        192,
        head_dim_v=128,
        attn_mask_type="causal",
    ),
    "fp8_11": ModelConfig(
        2,
        2048,
        128,
        192,
        head_dim_v=128,
        attn_mask_type="causal_bottom_right",
    ),
    "fp8_12": ModelConfig(1, 8192, 32, 128, num_gqa_groups=4, attn_mask_type="causal"),
    "fp8_13": ModelConfig(
        2, 8192, 32, 128, num_gqa_groups=4, attn_mask_type="causal", window_size=(128, 0)
    ),
    "fp8_14": ModelConfig(2, 4096, 64, 64, num_gqa_groups=8, attn_mask_type="causal"),
    "fp8_15": ModelConfig(1, 8192, 64, 64, attn_mask_type="causal", window_size=(128, 0)),
    "fp8_16": ModelConfig(
        1, 8192, 64, 64, num_gqa_groups=8, attn_mask_type="causal", softmax_type="learnable"
    ),
    "fp8_17": ModelConfig(
        2, 4096, 64, 64, attn_mask_type="causal", window_size=(128, 0), softmax_type="learnable"
    ),
    "fp8_18": ModelConfig(1, 8192, 32, 128, num_gqa_groups=4, attn_mask_type="padding"),
    "fp8_19": ModelConfig(2, 2048, 16, 128, attn_mask_type="padding_causal"),
    "fp8_20": ModelConfig(2, 2048, 24, 128, num_gqa_groups=12, attn_mask_type="padding_causal"),
}

param_types_fp8_vs_f16 = [torch.float16, torch.bfloat16]
qkv_layout_fp8_vs_f16 = ["sbh3d", "bshd_bshd_bshd", "sbhd_sbhd_sbhd", "thd_thd_thd"]
qkv_format_fp8_vs_f16 = ["bshd", "sbhd", "thd"]


def _get_fp8_vs_f16_config(model, qkv_layout):
    config = copy.copy(model_configs_fp8_vs_f16[model])
    # THD is variable-length, so it requires the corresponding padding-aware mask type.
    if qkv_layout.startswith("thd"):
        config.attn_mask_type = {
            "no_mask": "padding",
            "causal": "padding_causal",
            "causal_bottom_right": "padding_causal_bottom_right",
        }.get(config.attn_mask_type, config.attn_mask_type)
    return config


def _dpa_fp8_vs_f16_seqlens(config, qkv_format):
    """Draw the sequence lengths for one test_dpa_fp8_vs_f16 case."""
    if "padding" in config.attn_mask_type or qkv_format == "thd":
        if config.attn_type == "self":
            seqlens_q = torch.randint(
                1, config.max_seqlen_q, [config.batch_size], dtype=torch.int32, device="cuda"
            )
            seqlens_kv = seqlens_q
        if config.attn_type == "cross":
            seqlens_q = torch.randint(
                1, config.max_seqlen_q, [config.batch_size], dtype=torch.int32, device="cuda"
            )
            seqlens_kv = torch.randint(
                1, config.max_seqlen_kv, [config.batch_size], dtype=torch.int32, device="cuda"
            )
    else:
        seqlens_q = torch.full(
            [config.batch_size], config.max_seqlen_q, dtype=torch.int32, device="cuda"
        )
        seqlens_kv = torch.full(
            [config.batch_size], config.max_seqlen_kv, dtype=torch.int32, device="cuda"
        )
    return seqlens_q, seqlens_kv


def _mha_fp8_vs_f16_seqlens(config, qkv_format):
    """Draw the sequence lengths for one test_mha_fp8_vs_f16 case.

    These come from a dedicated generator rather than the default one, because the module the run
    builds beforehand consumes randomness the backend probe cannot replay."""
    gen = torch.Generator(device="cuda")
    gen.manual_seed(seed)

    def draw(high, count):
        return torch.randint(1, high, [count], dtype=torch.int32, device="cuda", generator=gen)

    if "padding" in config.attn_mask_type or qkv_format == "thd":

        def random_seqlens(max_seqlen):
            if qkv_format != "thd":
                return draw(max_seqlen, config.batch_size)
            # Reserve seven positions so total-token alignment only increases the final length.
            return torch.cat((draw(max_seqlen, config.batch_size - 1), draw(max_seqlen - 6, 1)))

        if config.attn_type == "self":
            seqlens_q = random_seqlens(config.max_seqlen_q)
            seqlens_kv = seqlens_q
        if config.attn_type == "cross":
            seqlens_q = random_seqlens(config.max_seqlen_q)
            seqlens_kv = random_seqlens(config.max_seqlen_kv)
    else:
        seqlens_q = torch.full(
            [config.batch_size], config.max_seqlen_q, dtype=torch.int32, device="cuda"
        )
        seqlens_kv = torch.full(
            [config.batch_size], config.max_seqlen_kv, dtype=torch.int32, device="cuda"
        )
    if qkv_format == "thd":
        # FP8 Linear flattens THD input to [t, h*d], so align total tokens for cuBLAS.
        seqlens_q[-1] += -seqlens_q.sum() % 8
        seqlens_kv[-1] += -seqlens_kv.sum() % 8
    return seqlens_q, seqlens_kv


@pytest.mark.skipif(not fp8_attn_available, reason=reason_for_no_fp8_attn)
@pytest.mark.parametrize("dtype", param_types_fp8_vs_f16)
@pytest.mark.parametrize("model", model_configs_fp8_vs_f16.keys())
@pytest.mark.parametrize("qkv_format", qkv_format_fp8_vs_f16)
@pytest.mark.parametrize("input_layernorm", [True, False])
@pytest.mark.parametrize("fp8_dpa_bwd", [True, False])
@pytest.mark.parametrize("RoPE", [True, False])
@pytest.mark.parametrize("is_training", [True, False])
@pytest.mark.parametrize("scaling_mode", ["delayed", "current", "mxfp8"])
def test_mha_fp8_vs_f16(
    dtype,
    model,
    qkv_format,
    input_layernorm,
    fp8_dpa_bwd,
    RoPE,
    is_training,
    scaling_mode,
):
    """Test MultiHeadAttention module in FP8"""
    if not is_training and fp8_dpa_bwd:
        pytest.skip("fp8_dpa_bwd=True not applicable for inference")

    os.environ["NVTE_FP8_DPA_BWD"] = "1" if fp8_dpa_bwd else "0"
    config = _get_fp8_vs_f16_config(model, qkv_format)

    # Test backend availability
    if scaling_mode == "delayed":
        fp8_recipe = recipe.DelayedScaling(
            margin=0,
            fp8_format=recipe.Format.HYBRID,
            amax_history_len=1,
            amax_compute_algo="most_recent",
            fp8_dpa=True,
            fp8_mha=True,
        )
    elif scaling_mode == "current":
        fp8_recipe = recipe.Float8CurrentScaling(
            fp8_format=recipe.Format.HYBRID,
            fp8_dpa=True,
            fp8_mha=True,
        )
    elif scaling_mode == "mxfp8":
        fp8_recipe = recipe.MXFP8BlockScaling(
            fp8_format=recipe.Format.E4M3,
            fp8_dpa=True,
            fp8_mha=False,
        )
    fp8_meta = {}
    fp8_meta["recipe"] = fp8_recipe
    # Get the token counts for THD and use them for both support query and actual execution
    num_tokens_q, num_tokens_kv = None, None
    if qkv_format == "thd":
        seqlens_q, seqlens_kv = _mha_fp8_vs_f16_seqlens(config, qkv_format)
        num_tokens_q = int(seqlens_q.sum())
        num_tokens_kv = int(seqlens_kv.sum())
    available_backends, _, _ = get_available_attention_backends(
        config,
        qkv_dtype=torch.float8_e4m3fn,
        nominal_dtype=dtype,
        qkv_layout=qkv_format.replace("hd", "h3d"),
        fp8=True,
        fp8_meta=fp8_meta,
        is_training=is_training,
        deterministic=_deterministic,
        num_tokens_q=num_tokens_q,
        num_tokens_kv=num_tokens_kv,
    )
    flash_attn_supported, fused_attn_supported_fp8, unfused_attn_supported = available_backends
    available_backends, _, fused_attn_backends = get_available_attention_backends(
        config,
        qkv_dtype=dtype,
        qkv_layout=qkv_format.replace("hd", "h3d"),
        is_training=is_training,
        deterministic=_deterministic,
        num_tokens_q=num_tokens_q,
        num_tokens_kv=num_tokens_kv,
    )
    _, fused_attn_supported_f16, _ = available_backends
    if flash_attn_supported + fused_attn_supported_fp8 < 1:
        pytest.skip("No FP8 attention backend available.")
    if not fused_attn_supported_f16:
        pytest.skip("No reference backend available.")

    if flash_attn_supported:
        os.environ["NVTE_FLASH_ATTN"] = "1"
        os.environ["NVTE_FUSED_ATTN"] = "0"
        os.environ["NVTE_UNFUSED_ATTN"] = "0"
        _attention_backends["backend_selection_requires_update"] = True
        logging.info("[test_mha_fp8_vs_f16]: run with fp8_mha = True")
        flash_attn_fwd_fp8, param_names, flash_attn_bwd_fp8 = _run_mha_fp8_vs_f16(
            dtype, config, True, qkv_format, input_layernorm, RoPE, is_training, fp8_recipe
        )

    if fused_attn_supported_fp8:
        os.environ["NVTE_FLASH_ATTN"] = "0"
        os.environ["NVTE_FUSED_ATTN"] = "1"
        os.environ["NVTE_UNFUSED_ATTN"] = "0"
        _attention_backends["backend_selection_requires_update"] = True
        logging.info("[test_mha_fp8_vs_f16]: run with fp8_mha = True")
        fused_attn_fwd_fp8, param_names, fused_attn_bwd_fp8 = _run_mha_fp8_vs_f16(
            dtype, config, True, qkv_format, input_layernorm, RoPE, is_training, fp8_recipe
        )

    if fused_attn_supported_f16:
        os.environ["NVTE_FLASH_ATTN"] = "0"
        os.environ["NVTE_FUSED_ATTN"] = "1"
        os.environ["NVTE_UNFUSED_ATTN"] = "0"
        _attention_backends["backend_selection_requires_update"] = True
        logging.info("[test_mha_fp8_vs_f16]: run with fp8_mha = False")
        fused_attn_fwd_f16, param_names, fused_attn_bwd_f16 = _run_mha_fp8_vs_f16(
            dtype, config, False, qkv_format, input_layernorm, RoPE, is_training, fp8_recipe
        )

    atol = 5e-1
    rtol = 5e-1
    rmse_tol = 0.15
    if flash_attn_supported and fused_attn_supported_f16:
        logging.debug("========== {:^25s} ==========".format("flash fp8 vs fused f16:"))
        logging.debug("========== {:^25s} ==========".format("forward output"))
        compare_and_assert(
            flash_attn_fwd_fp8,
            fused_attn_fwd_f16,
            "flash_attn_fwd_fp8",
            "fused_attn_fwd_f16",
            atol,
            rtol,
            rmse_tol,
            True,
        )
    if fused_attn_supported_fp8 and fused_attn_supported_f16:
        logging.debug("========== {:^25s} ==========".format("fused fp8 vs fused f16:"))
        logging.debug("========== {:^25s} ==========".format("forward output"))
        compare_and_assert(
            fused_attn_fwd_fp8,
            fused_attn_fwd_f16,
            "fused_attn_fwd_fp8",
            "fused_attn_fwd_f16",
            atol,
            rtol,
            rmse_tol,
            True,
        )

        if is_training:
            for i in range(len(param_names[:1])):
                logging.debug("========== {:^25s} ==========".format(param_names[i]))
                compare_and_assert(
                    fused_attn_bwd_fp8[i],
                    fused_attn_bwd_f16[i],
                    f"fused_attn_bwd_fp8[{i}]",
                    f"fused_attn_bwd_f16[{i}]",
                    atol,
                    rtol,
                    rmse_tol,
                    True,
                )


def _run_mha_fp8_vs_f16(
    dtype, config, fp8_mha, qkv_format, input_layernorm, RoPE, is_training, fp8_recipe
):
    """Run MultiHeadAttention module in FP8"""
    reset_rng_states()
    _DUMMY_CUDA_RNG_STATE_TRACKER = CudaRNGStatesTracker()
    _DUMMY_CUDA_RNG_STATE_TRACKER.add("model-parallel-rng", seed)

    def get_dummy_cuda_rng_tracker() -> CudaRNGStatesTracker:
        """Get cuda rng tracker."""
        return _DUMMY_CUDA_RNG_STATE_TRACKER

    with quantized_model_init(enabled=fp8_mha, recipe=fp8_recipe):
        rotary_pos_emb = None
        if RoPE:
            PE = RotaryPositionEmbedding(dim=config.head_dim_qk)
            rotary_pos_emb = PE(config.max_seqlen_q).to(device="cuda")
        mha = MultiheadAttention(
            hidden_size=config.hidden_size,
            num_attention_heads=config.num_heads,
            kv_channels=config.head_dim_qk,
            num_gqa_groups=config.num_gqa_groups,
            attention_dropout=config.dropout_p,
            layer_number=1,
            bias=True,
            get_rng_state_tracker=get_dummy_cuda_rng_tracker,
            params_dtype=dtype,
            input_layernorm=input_layernorm,
            fuse_qkv_params=True,
            attention_type="self",
            qkv_weight_interleaved=True,
            qkv_format=qkv_format,
            window_size=config.window_size,
            softmax_type=config.softmax_type,
        ).to(dtype=dtype, device="cuda")
        if not is_training:
            mha = mha.eval()

    seqlens_q, seqlens_kv = _mha_fp8_vs_f16_seqlens(config, qkv_format)
    cu_seqlens_q = torch.zeros(config.batch_size + 1, dtype=torch.int32, device="cuda")
    cu_seqlens_kv = torch.zeros(config.batch_size + 1, dtype=torch.int32, device="cuda")
    cu_seqlens_q[1:] = torch.cumsum(seqlens_q, dim=0)
    cu_seqlens_kv[1:] = torch.cumsum(seqlens_kv, dim=0)

    dim_to_num = {
        "b": config.batch_size,
        "sq": config.max_seqlen_q,
        "skv": config.max_seqlen_kv,
        "h": config.num_heads,
        "hg": config.num_gqa_groups,
        "d": config.head_dim_qk,
        "t": cu_seqlens_q[-1],
        "tg": cu_seqlens_kv[-1],
        "3": 3,
        "2": 2,
        "1": 1,
    }
    layout = "_".join(qkv_format)
    layout = layout.replace("s", "sq")
    tensor_shape = [dim_to_num[j] for j in layout.split("_")]
    tensor = 0.01 * torch.randint(-100, 100, tensor_shape, dtype=dtype, device="cuda")
    hidden_states = tensor.view(*tensor.shape[:-2], -1)
    if is_training:
        hidden_states.requires_grad = True
    tensor = 0.01 * torch.randn(tensor_shape, dtype=dtype, device="cuda")
    out_grad = tensor.view(*tensor.shape[:-2], -1)

    with autocast(enabled=fp8_mha, recipe=fp8_recipe):
        out = mha(
            hidden_states,
            attn_mask_type=config.attn_mask_type,
            checkpoint_core_attention=False,
            core_attention_bias_type=config.attn_bias_type,
            is_first_microbatch=None,
            rotary_pos_emb=rotary_pos_emb,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_kv=cu_seqlens_kv,
        )
    if is_training:
        out.backward(out_grad)

    param_names = []
    param_names.append("hidden_states.grad")
    params = []
    params.append(hidden_states)
    for name, param in mha.named_parameters():
        if param.requires_grad:
            param_names.append(name + ".grad")
            params.append(param)

    if is_training:
        return out, param_names, tuple(x.grad for x in params)
    return out, param_names, tuple(None for x in params)


@pytest.mark.skipif(not fp8_attn_available, reason=reason_for_no_fp8_attn)
@pytest.mark.parametrize("dtype", param_types_fp8_vs_f16)
@pytest.mark.parametrize("model", model_configs_fp8_vs_f16.keys())
@pytest.mark.parametrize("qkv_layout", qkv_layout_fp8_vs_f16)
@pytest.mark.parametrize("fp8_dpa_bwd", [True, False])
@pytest.mark.parametrize("is_training", [True, False])
@pytest.mark.parametrize("scaling_mode", ["delayed", "current", "mxfp8"])
def test_dpa_fp8_vs_f16(dtype, model, qkv_layout, fp8_dpa_bwd, is_training, scaling_mode):
    """Test DotProductAttention module in FP8"""
    config = _get_fp8_vs_f16_config(model, qkv_layout)
    if config.num_heads != config.num_gqa_groups and "3" in qkv_layout:
        pytest.skip("qkv_layout not applicable for MQA/GQA")
    if not is_training and fp8_dpa_bwd:
        pytest.skip("fp8_dpa_bwd=True not applicable for inference")

    # TODO(cyang): think of another way to verify dropout results
    # test cuDNN FP8 dropout
    # 1. we modify the config here to not affect mha_fp8_vs_f16 tests
    # 2. there is no other backend that implements dropout the same way as cuDNN FP8, and as an
    #    indirect verification method, we create Q/K/V as all 1s and check if O is all 1s
    # 3. we avoid running FP16/BF16 kernels as they do not have dropout support on Blackwell
    # if "padding" not in config.attn_mask_type and "causal" not in config.attn_mask_type:
    #    if get_device_compute_capability() >= (10, 0):
    #        config.dropout_p = 0.1

    os.environ["NVTE_FP8_DPA_BWD"] = "1" if fp8_dpa_bwd else "0"
    os.environ["NVTE_UnfusedDPA_Emulate_FP8"] = "1"

    # Test backend availability
    if scaling_mode == "delayed":
        fp8_recipe = recipe.DelayedScaling(
            margin=0,
            fp8_format=recipe.Format.HYBRID,
            amax_history_len=1,
            amax_compute_algo="most_recent",
            fp8_dpa=True,
        )
    elif scaling_mode == "current":
        fp8_recipe = recipe.Float8CurrentScaling(
            fp8_format=recipe.Format.HYBRID,
            fp8_dpa=True,
        )
    elif scaling_mode == "mxfp8":
        fp8_recipe = recipe.MXFP8BlockScaling(
            fp8_format=recipe.Format.E4M3,
            fp8_dpa=True,
            fp8_mha=False,
        )
    fp8_meta = {}
    fp8_meta["recipe"] = fp8_recipe
    # Get the token counts for THD and use them for both support query and actual execution
    qkv_format = "".join([i for i in qkv_layout.split("_")[0] if i.isalpha()])
    num_tokens_q, num_tokens_kv = None, None
    if qkv_format == "thd":
        reset_rng_states()
        seqlens_q, seqlens_kv = _dpa_fp8_vs_f16_seqlens(config, qkv_format)
        num_tokens_q = int(seqlens_q.sum())
        num_tokens_kv = int(seqlens_kv.sum())
    available_backends, _, _ = get_available_attention_backends(
        config,
        qkv_dtype=torch.float8_e4m3fn,
        nominal_dtype=dtype,
        qkv_layout=qkv_layout,
        fp8=True,
        fp8_meta=fp8_meta,
        is_training=is_training,
        deterministic=_deterministic,
        num_tokens_q=num_tokens_q,
        num_tokens_kv=num_tokens_kv,
    )
    flash_attn_supported, fused_attn_supported_fp8, unfused_attn_supported = available_backends
    available_backends, _, _ = get_available_attention_backends(
        config,
        qkv_dtype=dtype,
        qkv_layout=qkv_layout,
        is_training=is_training,
        deterministic=_deterministic,
        num_tokens_q=num_tokens_q,
        num_tokens_kv=num_tokens_kv,
    )
    _, fused_attn_supported_f16, _ = available_backends
    if flash_attn_supported + fused_attn_supported_fp8 < 1:
        pytest.skip("No FP8 attention backend available.")
    if not fused_attn_supported_f16:
        pytest.skip("No reference backend available.")

    if flash_attn_supported:
        os.environ["NVTE_FLASH_ATTN"] = "1"
        os.environ["NVTE_FUSED_ATTN"] = "0"
        os.environ["NVTE_UNFUSED_ATTN"] = "0"
        _attention_backends["backend_selection_requires_update"] = True
        logging.info("[test_dpa_fp8_vs_f16]: run with fp8_dpa = True (FlashAttention)")
        flash_attn_fwd_fp8, flash_attn_bwd_fp8 = _run_dpa_fp8_vs_f16(
            dtype, config, True, qkv_layout, is_training, fp8_recipe
        )

    if unfused_attn_supported:
        os.environ["NVTE_FLASH_ATTN"] = "0"
        os.environ["NVTE_FUSED_ATTN"] = "0"
        os.environ["NVTE_UNFUSED_ATTN"] = "1"
        _attention_backends["backend_selection_requires_update"] = True
        logging.info("[test_dpa_fp8_vs_f16]: run with fp8_dpa = True (UnfusedDotProductAttention)")
        unfused_attn_fwd_fp8, unfused_attn_bwd_fp8 = _run_dpa_fp8_vs_f16(
            dtype, config, True, qkv_layout, is_training, fp8_recipe
        )

    if fused_attn_supported_fp8:
        os.environ["NVTE_FLASH_ATTN"] = "0"
        os.environ["NVTE_FUSED_ATTN"] = "1"
        os.environ["NVTE_UNFUSED_ATTN"] = "0"
        _attention_backends["backend_selection_requires_update"] = True
        logging.info("[test_dpa_fp8_vs_f16]: run with fp8_dpa = True (FusedAttention)")
        fused_attn_fwd_fp8, fused_attn_bwd_fp8 = _run_dpa_fp8_vs_f16(
            dtype, config, True, qkv_layout, is_training, fp8_recipe
        )

    if fused_attn_supported_f16:
        os.environ["NVTE_FLASH_ATTN"] = "0"
        os.environ["NVTE_FUSED_ATTN"] = "1"
        os.environ["NVTE_UNFUSED_ATTN"] = "0"
        if config.dropout_p == 0.0:
            # test cuDNN FP8 dropout: need a FP16/BF16 reference on Blackwell
            logging.info("[test_dpa_fp8_vs_f16]: run with fp8_dpa = False (FusedAttention)")
            fused_attn_fwd_f16, fused_attn_bwd_f16 = _run_dpa_fp8_vs_f16(
                dtype, config, False, qkv_layout, is_training, fp8_recipe
            )

    atol = 5e-1
    rtol = 5e-2
    rmse_tol = 0.11
    bwd_names = ["dq", "dk", "dv", "d_softmax_offset"]
    if flash_attn_supported and fused_attn_supported_f16:
        logging.debug("========== {:^25s} ==========".format("flash fp8 vs fused f16:"))
        logging.debug("========== {:^25s} ==========".format("forward output"))
        compare_and_assert(
            flash_attn_fwd_fp8,
            fused_attn_fwd_f16,
            "flash_attn_fwd_fp8",
            "fused_attn_fwd_f16",
            atol,
            rtol,
            rmse_tol,
            True,
        )
    if unfused_attn_supported and fused_attn_supported_f16:
        logging.debug("========== {:^25s} ==========".format("unfused fp8 vs fused f16:"))
        logging.debug("========== {:^25s} ==========".format("forward output"))
        compare_and_assert(
            unfused_attn_fwd_fp8,
            fused_attn_fwd_f16,
            "unfused_attn_fwd_fp8",
            "fused_attn_fwd_f16",
            atol,
            rtol,
            rmse_tol,
            True,
        )
        if is_training:
            for i, _ in enumerate(fused_attn_bwd_f16):
                logging.debug("========== {:^25s} ==========".format(bwd_names[i]))
                compare_and_assert(
                    unfused_attn_bwd_fp8[i],
                    fused_attn_bwd_f16[i],
                    f"unfused_attn_bwd_fp8[{i}]",
                    f"fused_attn_bwd_f16[{i}]",
                    atol,
                    rtol,
                    rmse_tol,
                    True,
                )
    if fused_attn_supported_fp8 and fused_attn_supported_f16:
        if config.dropout_p != 0.0:
            # test cuDNN FP8 dropout
            assert torch.all(
                fused_attn_fwd_fp8 == 1
            ), "fused_attn_fwd_fp8 must be all 1s when Q/K/V are all 1s."
        else:
            logging.debug("========== {:^25s} ==========".format("fused fp8 vs fused f16:"))
            logging.debug("========== {:^25s} ==========".format("forward output"))
            compare_and_assert(
                fused_attn_fwd_fp8,
                fused_attn_fwd_f16,
                "fused_attn_fwd_fp8",
                "fused_attn_fwd_f16",
                atol,
                rtol,
                rmse_tol,
                True,
            )
            if is_training:
                for i, _ in enumerate(fused_attn_bwd_f16):
                    logging.debug("========== {:^25s} ==========".format(bwd_names[i]))
                    compare_and_assert(
                        fused_attn_bwd_fp8[i],
                        fused_attn_bwd_f16[i],
                        f"fused_attn_bwd_fp8[{i}]",
                        f"fused_attn_bwd_f16[{i}]",
                        atol,
                        rtol,
                        rmse_tol,
                        True,
                    )
    os.environ["NVTE_UnfusedDPA_Emulate_FP8"] = "0"


def _run_dpa_fp8_vs_f16(dtype, config, fp8_dpa, qkv_layout, is_training, fp8_recipe):
    """Run DotProductAttention module in FP8"""
    reset_rng_states()
    _DUMMY_CUDA_RNG_STATE_TRACKER = CudaRNGStatesTracker()
    _DUMMY_CUDA_RNG_STATE_TRACKER.add("model-parallel-rng", seed)

    def get_dummy_cuda_rng_tracker() -> CudaRNGStatesTracker:
        """Get cuda rng tracker."""
        return _DUMMY_CUDA_RNG_STATE_TRACKER

    qkv_format = "".join([i for i in qkv_layout.split("_")[0] if i.isalpha()])
    with quantized_model_init(enabled=fp8_dpa):
        dpa = DotProductAttention(
            config.num_heads,
            (config.head_dim_qk, config.head_dim_v),
            num_gqa_groups=config.num_gqa_groups,
            attention_dropout=config.dropout_p,
            sequence_parallel=False,
            tp_size=1,
            get_rng_state_tracker=get_dummy_cuda_rng_tracker,
            tp_group=None,
            layer_number=1,
            attention_type="self",
            qkv_format=qkv_format,
            softmax_type=config.softmax_type,
        ).to(dtype=dtype, device="cuda")
        if not is_training:
            dpa = dpa.eval()

    seqlens_q, seqlens_kv = _dpa_fp8_vs_f16_seqlens(config, qkv_format)
    cu_seqlens_q = torch.zeros(config.batch_size + 1, dtype=torch.int32, device="cuda")
    cu_seqlens_kv = torch.zeros(config.batch_size + 1, dtype=torch.int32, device="cuda")
    cu_seqlens_q[1:] = torch.cumsum(seqlens_q, dim=0)
    cu_seqlens_kv[1:] = torch.cumsum(seqlens_kv, dim=0)

    dim_to_num = {
        "b": config.batch_size,
        "sq": config.max_seqlen_q,
        "skv": config.max_seqlen_kv,
        "h": config.num_heads,
        "hg": config.num_gqa_groups,
        "dqk": config.head_dim_qk,
        "dv": config.head_dim_v,
        "t": cu_seqlens_q[-1],
        "tg": cu_seqlens_kv[-1],
        "3": 3,
        "2": 2,
        "1": 1,
    }
    inp = []
    for i, layout in enumerate(qkv_layout.split("_")):
        layout = "_".join(layout)
        if i == 0:
            layout = layout.replace("s", "sq")
        else:
            layout = layout.replace("s", "skv")
            layout = layout.replace("h", "hg")
            layout = layout.replace("t", "tg")
        if i == 2:
            layout = layout.replace("d", "dv")
        else:
            layout = layout.replace("d", "dqk")
        tensor_shape = [dim_to_num[j] for j in layout.split("_")]
        if config.dropout_p == 0.0:
            tensor = torch.randn(tensor_shape, dtype=dtype, device="cuda")
        else:
            # test cuDNN FP8 dropout
            tensor = torch.ones(tensor_shape, dtype=dtype, device="cuda")
        tensor_count = 1
        split_dim = 0
        for dim, l in enumerate(layout.split("_")):
            if l.isdigit():
                tensor_count = int(l)
                split_dim = dim
                break
        tensors = torch.split(tensor, 1, dim=split_dim) if split_dim != 0 else [tensor]
        for j in range(tensor_count):
            if split_dim != 0:
                inp.append(tensors[j].squeeze(split_dim))
            else:
                inp.append(tensors[j])
    for i in range(3):
        inp[i].requires_grad = True

    qkv_format_kv = "_".join(qkv_format)
    qkv_format_kv = qkv_format_kv.replace("s", "sq")
    qkv_format_kv = qkv_format_kv.replace("d", "dv")
    out_grad_shape = [dim_to_num[i] for i in qkv_format_kv.split("_")]
    out_grad_shape_new = [*out_grad_shape[:-2], out_grad_shape[-2] * out_grad_shape[-1]]
    out_grad = torch.randn(out_grad_shape_new, dtype=dtype, device="cuda")

    with autocast(enabled=fp8_dpa, recipe=fp8_recipe):
        out = dpa(
            inp[0],
            inp[1],
            inp[2],
            qkv_format=qkv_format,
            window_size=config.window_size,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_kv=cu_seqlens_kv,
            max_seqlen_q=config.max_seqlen_q,
            max_seqlen_kv=config.max_seqlen_kv,
            attn_mask_type=config.attn_mask_type,
            checkpoint_core_attention=False,
            core_attention_bias_type=config.attn_bias_type,
            fp8_output=fp8_dpa,
        )
    if is_training:
        out.backward(out_grad)
    d_softmax_offset = None
    if is_training and config.softmax_type != "vanilla":
        d_softmax_offset = dpa.softmax_offset.grad

    if is_training:
        return out, (inp[0].grad, inp[1].grad, inp[2].grad, d_softmax_offset)
    return out, (None, None, None, d_softmax_offset)


model_configs_fp8 = {
    # test: ModelConfig(b, sq, hq, dqk)
    "fp8_1": ModelConfig(1, 512, 1, 64),
    "fp8_2": ModelConfig(4, 512, 16, 64),
    "fp8_3": ModelConfig(1, 2048, 1, 128),
    "fp8_4": ModelConfig(2, 2048, 24, 128),
    "fp8_5": ModelConfig(1, 512, 1, 64, attn_mask_type="causal"),
    "fp8_6": ModelConfig(4, 512, 16, 64, attn_mask_type="causal"),
    "fp8_7": ModelConfig(1, 2048, 1, 128, attn_mask_type="causal"),
    "fp8_8": ModelConfig(2, 2048, 24, 128, attn_mask_type="causal"),
}
param_types_fp8 = [torch.float16, torch.bfloat16]


@pytest.mark.skipif(not fp8_attn_available, reason=reason_for_no_fp8_attn)
@pytest.mark.parametrize("dtype", param_types_fp8)
@pytest.mark.parametrize("model", model_configs_fp8)
def test_custom_mha_fp8_vs_f16(dtype, model):
    """Test FP8 dot product attention implementations based on cuDNN frontend
    v0.9 and v1.0+. Each test compares results from a custom implementation of
    an FP8 MHA module, i.e. Custom_MHA_FP8(), to results from an F16 MHA
    implementation, i.e. transformer_engine.pytorch.attention.MultiHeadAttention.
    Both paths take F16 input and output. QKV layout is bs3hd"""

    config = model_configs_fp8[model]

    # Test backend availability
    is_training = True
    fp8_meta = {}
    fp8_recipe = recipe.DelayedScaling(
        margin=0,
        fp8_format=recipe.Format.HYBRID,
        amax_history_len=1,
        amax_compute_algo="most_recent",
        fp8_dpa=True,
    )
    fp8_meta["recipe"] = fp8_recipe
    available_backends, _, fused_attn_backends = get_available_attention_backends(
        config,
        qkv_dtype=torch.float8_e4m3fn,
        nominal_dtype=dtype,
        qkv_layout="bs3hd",
        fp8=True,
        fp8_meta=fp8_meta,
        is_training=is_training,
        deterministic=_deterministic,
    )
    flash_attn_supported, fused_attn_supported, unfused_attn_supported = available_backends
    if not (fused_attn_backends and unfused_attn_supported):
        pytest.skip("Not enough backends to run this test with.")

    fused_attn_fwd_fp8, fused_attn_bwd_fp8 = _run_custom_mha_fp8(dtype, config, "FusedAttention")
    unfused_attn_fwd_f16, unfused_attn_bwd_f16 = _run_ref_mha_f16(
        dtype, config, "UnfusedDotProductAttention"
    )

    atol = 5e-1
    rtol = 5e-1
    rmse_tol = 0.13
    compare_and_assert(
        fused_attn_fwd_fp8,
        unfused_attn_fwd_f16,
        "fused_attn_fwd_fp8",
        "unfused_attn_fwd_f16",
        atol,
        rtol,
        rmse_tol,
        True,
    )
    compare_and_assert(
        fused_attn_bwd_fp8,
        unfused_attn_bwd_f16,
        "fused_attn_bwd_fp8",
        "unfused_attn_bwd_f16",
        atol,
        rtol,
        rmse_tol,
        True,
    )


def _run_custom_mha_fp8(dtype, config, backend):
    """Run Custom_MHA_FP8 with FP8 FusedAttention backend. Both input and output
    are in F16. QKV GEMM, DPA, and projection GEMM are calculated in FP8."""
    reset_rng_states()
    os.environ["NVTE_FLASH_ATTN"] = "0"
    os.environ["NVTE_FUSED_ATTN"] = "0"
    os.environ["NVTE_UNFUSED_ATTN"] = "0"
    if backend == "FlashAttention":
        os.environ["NVTE_FLASH_ATTN"] = "1"
    if backend == "FusedAttention":
        os.environ["NVTE_FUSED_ATTN"] = "1"
    if backend == "UnfusedDotProductAttention":
        os.environ["NVTE_UNFUSED_ATTN"] = "1"
    _attention_backends["backend_selection_requires_update"] = True

    inp = 0.0001 * torch.randint(
        -100,
        100,
        (config.batch_size * config.max_seqlen_q, config.num_heads * config.head_dim_qk),
        dtype=dtype,
        device="cuda",
        requires_grad=True,
    )
    seqlens = torch.full([config.batch_size], config.max_seqlen_q, dtype=torch.int32, device="cuda")
    cu_seqlens = torch.zeros(config.batch_size + 1, device="cuda", dtype=torch.int32)
    cu_seqlens[1:] = torch.cumsum(seqlens, dim=0)

    out_grad = 0.01 * torch.randn(
        config.batch_size * config.max_seqlen_q,
        config.num_heads * config.head_dim_qk,
        dtype=dtype,
        device="cuda",
    )
    torch.save(out_grad, "out_grad.pt")

    fp8_recipe = recipe.DelayedScaling(
        margin=0,
        fp8_format=recipe.Format.HYBRID,
        amax_history_len=1,
        amax_compute_algo="most_recent",
        fp8_dpa=True,
    )

    mha = Custom_MHA_FP8(config).to(dtype=dtype, device="cuda")
    with autocast(enabled=True, recipe=fp8_recipe):
        out = mha(inp, cu_seqlens, config.max_seqlen_q)
    out.backward(out_grad)

    out = torch.load("out.pt")
    dqkv = torch.load("dqkv.pt")
    return (
        out.view(config.batch_size, config.max_seqlen_q, -1),
        dqkv.view(
            config.batch_size, config.max_seqlen_q, 3, config.num_heads, config.head_dim_qk
        ).contiguous(),
    )


def _run_ref_mha_f16(dtype, config, backend):
    """Run reference F16 FusedAttention. Both input and output
    are in F16. QKV GEMM, DPA, and projection GEMM are also in F16."""

    os.environ["NVTE_FLASH_ATTN"] = "0"
    os.environ["NVTE_FUSED_ATTN"] = "0"
    os.environ["NVTE_UNFUSED_ATTN"] = "0"
    if backend == "FlashAttention":
        os.environ["NVTE_FLASH_ATTN"] = "1"
    if backend == "FusedAttention":
        os.environ["NVTE_FUSED_ATTN"] = "1"
    if backend == "UnfusedDotProductAttention":
        os.environ["NVTE_UNFUSED_ATTN"] = "1"
    _attention_backends["backend_selection_requires_update"] = True

    inp = torch.load("qkv.pt").to(device="cuda")
    inp.requires_grad = True
    seqlens = torch.full([config.batch_size], config.max_seqlen_q, dtype=torch.int32, device="cuda")
    cu_seqlens = torch.zeros(config.batch_size + 1, device="cuda", dtype=torch.int32)
    cu_seqlens[1:] = torch.cumsum(seqlens, dim=0)
    out_grad = (
        torch.load("out_grad.pt").to(device="cuda").view(config.batch_size, config.max_seqlen_q, -1)
    )

    _DUMMY_CUDA_RNG_STATE_TRACKER = CudaRNGStatesTracker()
    _DUMMY_CUDA_RNG_STATE_TRACKER.add("model-parallel-rng", seed)

    def get_dummy_cuda_rng_tracker() -> CudaRNGStatesTracker:
        """Get cuda rng tracker."""
        return _DUMMY_CUDA_RNG_STATE_TRACKER

    block = DotProductAttention(
        config.num_heads,
        config.head_dim_qk,
        attention_dropout=config.dropout_p,
        sequence_parallel=False,
        tp_size=1,
        get_rng_state_tracker=get_dummy_cuda_rng_tracker,
        tp_group=None,
        layer_number=1,
        attention_type="self",
        qkv_format="bshd",
    ).to(dtype=dtype, device="cuda")

    q = inp[:, :, 0, :, :]
    k = inp[:, :, 1, :, :]
    v = inp[:, :, 2, :, :]
    out = block(q, k, v, attn_mask_type=config.attn_mask_type)
    out.backward(out_grad)

    return out, inp.grad


_CUBLASLT_WORKSPACE_SIZE_BYTES = 33_554_432  # 32MiB
_2X_ACC_FPROP = False
_2X_ACC_DGRAD = False
_2X_ACC_WGRAD = False

META_QKV = FP8FwdTensorIdx.GEMM1_OUTPUT
META_DQKV = FP8BwdTensorIdx.GRAD_OUTPUT1
META_O = FP8FwdTensorIdx.GEMM2_INPUT
META_DO = FP8BwdTensorIdx.GRAD_INPUT2
META_S = FP8FwdTensorIdx.GEMM3_OUTPUT
META_DP = FP8BwdTensorIdx.GRAD_INPUT3


class _custom_mha_fp8(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        inp: torch.Tensor,
        qkv_weight: torch.Tensor,
        qkv_bias: torch.Tensor,
        cu_seqlens: torch.Tensor,
        num_heads: int,
        p_dropout: float,
        max_s: int,
        fast_zero_fill: bool,
        fp8_meta: Dict[str, Any],
        is_training: bool,
        mask_type: str,
        quantizers: list[Quantizer],
    ) -> torch.Tensor:
        qkv_dtype = inp.dtype

        assert inp.dim() == 2
        in_features = qkv_weight.shape[-1]
        h = num_heads
        d = in_features // h
        b = cu_seqlens.numel() - 1

        input_quantizer = quantizers["scaling_fwd"][FP8FwdTensorIdx.GEMM1_INPUT]
        qkv_quantizer = quantizers["scaling_fwd"][FP8FwdTensorIdx.GEMM2_INPUT]
        qkv_weight_quantizer = quantizers["scaling_fwd"][FP8FwdTensorIdx.GEMM1_WEIGHT]
        o_quantizer = quantizers["scaling_fwd"][FP8FwdTensorIdx.GEMM1_OUTPUT]
        dO_quantizer = quantizers["scaling_bwd"][FP8BwdTensorIdx.GRAD_OUTPUT1]
        dQKV_quantizer = quantizers["scaling_bwd"][FP8BwdTensorIdx.GRAD_INPUT1]
        s_quantizer = quantizers["scaling_bwd"][FP8BwdTensorIdx.GRAD_OUTPUT2]
        dP_quantizer = quantizers["scaling_bwd"][FP8BwdTensorIdx.GRAD_OUTPUT3]

        inp_fp8 = input_quantizer(inp)

        qkv_weight_fp8 = qkv_weight_quantizer(qkv_weight)

        qkv, *_ = ext.general_gemm(
            qkv_weight_fp8,
            inp_fp8,
            bias=qkv_bias,
            out_dtype=qkv_weight_fp8.dtype,
            quantization_params=qkv_quantizer,
            use_split_accumulator=_2X_ACC_FPROP,
        )
        qkv_layout = "bs3hd"
        o_format = "bshd"
        qkv = qkv.view(-1, 3, h, d)
        qkv_fp16 = qkv.dequantize().view(b, max_s, 3, h, d).contiguous()
        torch.save(qkv_fp16, "qkv.pt")
        qkv = qkv.view(b, max_s, 3, h, d)  # bs3hd

        # FMHA
        q_data = qkv._data[:, :, 0, :, :]
        k_data = qkv._data[:, :, 1, :, :]
        v_data = qkv._data[:, :, 2, :, :]
        q = qkv.make_like(tensor=qkv, data=q_data, shape=q_data.shape)
        k = qkv.make_like(tensor=qkv, data=k_data, shape=k_data.shape)
        v = qkv.make_like(tensor=qkv, data=v_data, shape=v_data.shape)

        out, aux_ctx_tensors = fused_attn_fwd(
            is_training,
            max_s,
            max_s,
            cu_seqlens,
            cu_seqlens,
            q,
            k,
            v,
            qkv_dtype,
            FusedAttnBackend["FP8"],
            attn_scale=None,
            dropout=p_dropout,
            fast_zero_fill=fast_zero_fill,
            qkv_layout=qkv_layout,
            o_format=o_format,
            attn_bias_type="no_bias",
            attn_mask_type=mask_type,
            rng_gen=None,
            o_quantizer=o_quantizer,
            s_quantizer=s_quantizer,
        )

        tensors_to_save, tensor_objects = prepare_for_saving(q, k, v, inp_fp8, qkv_weight_fp8, out)

        ctx.save_for_backward(*tensors_to_save)
        ctx.tensor_objects = tensor_objects
        ctx.aux_ctx_tensors = aux_ctx_tensors
        ctx.qkv_dtype = qkv_dtype
        ctx.fp8_meta = fp8_meta
        ctx.cu_seqlens = cu_seqlens
        ctx.p_dropout = p_dropout
        ctx.max_s = max_s
        ctx.fast_zero_fill = fast_zero_fill
        ctx.hidden_size = in_features
        ctx.num_heads = num_heads
        ctx.mask_type = mask_type
        ctx.dtype = inp.dtype
        ctx.qkv_layout = qkv_layout
        ctx.o_format = o_format

        ctx.dQKV_quantizer = dQKV_quantizer
        ctx.dO_quantizer = dO_quantizer
        ctx.dP_quantizer = dP_quantizer
        ctx.S_quantizer = s_quantizer

        out = out.view(-1, in_features)  # (bs)(hd)
        out_fp16 = out.dequantize()
        torch.save(out_fp16, "out.pt")  # (bs)(hd)
        return out_fp16

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> Tuple[Union[torch.Tensor, None], ...]:
        with torch.cuda.nvtx.range("_DPA"):
            (q, k, v, inp_fp8, qkv_weight_fp8, out) = restore_from_func_ctx(ctx)

            proj_dgrad = ctx.dO_quantizer(grad_output)

            dq, dk, dv, *rest = fused_attn_bwd(
                ctx.max_s,
                ctx.max_s,
                ctx.cu_seqlens,
                ctx.cu_seqlens,
                q,
                k,
                v,
                out,
                proj_dgrad.view_as(out),
                ctx.qkv_dtype,
                ctx.aux_ctx_tensors,
                FusedAttnBackend["FP8"],
                None,
                None,
                ctx.S_quantizer,
                ctx.dP_quantizer,
                ctx.dQKV_quantizer,
                attn_scale=None,
                dropout=ctx.p_dropout,
                fast_zero_fill=ctx.fast_zero_fill,
                qkv_layout=ctx.qkv_layout,
                o_format=ctx.o_format,
                do_format=ctx.o_format,
                dqkv_layout=ctx.qkv_layout,
                attn_bias_type="no_bias",
                attn_mask_type=ctx.mask_type,
            )
            dim = 2
            dqkv = torch.Tensor().to(device=dq._data.device, dtype=dq._data.dtype)
            dqkv_shape = list(dq._data.shape)
            dqkv_shape.insert(dim, 3)
            dqkv_stride = list(dq._data.stride())
            dqkv_stride.insert(dim, int(dqkv_stride[-3] / 3))
            dqkv.set_(
                dq._data.untyped_storage(), dq._data.storage_offset(), dqkv_shape, dqkv_stride
            )  # bs3hd

            dqkv_c = dqkv.view(-1, 3 * ctx.hidden_size)
            dqkv_c = dq.make_like(tensor=dq, data=dqkv_c, shape=dqkv_c.shape)
            dqkv_c_fp16 = dqkv_c.dequantize()
            torch.save(dqkv_c_fp16, "dqkv.pt")

            qkv_bgrad, dqkv = ext.bgrad_quantize(dqkv_c_fp16, ctx.dQKV_quantizer)
            dqkv_c._transpose = None
            dqkv_c._create_transpose()

            # QKV DGRAD
            qkv_dgrad, *_ = ext.general_gemm(
                qkv_weight_fp8,
                dqkv_c,
                ctx.dtype,
                use_split_accumulator=_2X_ACC_DGRAD,
                layout="NN",
            )

            # QKV WGRAD
            qkv_wgrad, *_ = ext.general_gemm(
                inp_fp8,
                dqkv,
                ctx.dtype,
                use_split_accumulator=_2X_ACC_WGRAD,
                layout="NT",
            )

        return (
            qkv_dgrad,
            qkv_wgrad,
            qkv_bgrad,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
        )


class Custom_MHA_FP8(TransformerEngineBaseModule):
    def __init__(self, config, params_dtype: torch.dtype = torch.float32):
        super().__init__()
        self.p_dropout = config.dropout_p
        self.h = config.num_heads
        self.hidden_size = config.hidden_size
        self.head_dim = config.head_dim_qk
        self.fast_zero_fill = True
        self.mask_type = config.attn_mask_type

        self.qkv_weight = torch.nn.Parameter(
            torch.empty(
                self.hidden_size * 3,
                self.hidden_size,
                device=torch.cuda.current_device(),
                dtype=params_dtype,
            )
        )
        self.qkv_bias = torch.nn.Parameter(
            torch.empty(
                self.hidden_size * 3,
                device=torch.cuda.current_device(),
                dtype=params_dtype,
            )
        )
        with torch.no_grad():
            self.qkv_bias.zero_()
            self.qkv_weight.fill_(1.0)

    def forward(
        self,
        inp: torch.Tensor,
        cu_seqlens,
        max_s,
    ) -> torch.Tensor:
        with self.prepare_forward_ctx(inp, num_gemms=3) as inp:
            out = _custom_mha_fp8.apply(
                inp,
                self.qkv_weight,
                self.qkv_bias,
                cu_seqlens,
                self.h,
                self.p_dropout,
                max_s,
                self.fast_zero_fill,
                self.fp8_meta,
                self.training,
                self.mask_type,
                self.quantizers,
            )
        return out
