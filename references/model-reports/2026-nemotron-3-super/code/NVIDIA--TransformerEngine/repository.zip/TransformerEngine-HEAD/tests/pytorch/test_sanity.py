# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.

from typing import Optional, List

import torch
import pytest
import os
import copy

import transformer_engine
import transformer_engine.pytorch as te
from transformer_engine.pytorch.quantization import FP8GlobalStateManager
from transformer_engine.pytorch.utils import (
    init_method_normal,
    scaled_init_method_normal,
)
from transformer_engine.pytorch import (
    autocast,
    quantized_model_init,
    LayerNormLinear,
    Linear,
    GroupedLinear,
    LayerNormMLP,
    TransformerLayer,
    RMSNorm,
    LayerNorm,
    Float8CurrentScalingQuantizer,
    Float8Quantizer,
    Float8Tensor,
    MXFP8Tensor,
    checkpoint,
    QuantizedTensor,
    is_bf16_available,
)
from transformer_engine.common import recipe
from transformer_engine.pytorch.cpp_extensions import general_gemm
from transformer_engine.pytorch.tensor.utils import replace_raw_data
from transformer_engine.pytorch.module import (
    _common as module_common,
    is_module_grouped_tensor_path_supported,
    layernorm_linear,
    layernorm_mlp,
    linear,
)
from utils import ModelConfig, recipe_id, skip_unsupported_backward_override

# Only run FP8 tests on supported devices.
fp8_available, reason_for_no_fp8 = te.is_fp8_available(return_reason=True)
fp8_block_scaling_available, _ = te.is_fp8_block_scaling_available(return_reason=True)
mxfp8_available, reason_for_no_mxfp8 = te.is_mxfp8_available(return_reason=True)
nvfp4_available, _ = te.is_nvfp4_available(return_reason=True)

# Record initial RNG state from script run.
seed = 1234
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)

NVTE_TEST_NVINSPECT_ENABLED = int(os.environ.get("NVTE_TEST_NVINSPECT_ENABLED", "0"))


if NVTE_TEST_NVINSPECT_ENABLED:
    # The sanity tests should work the same,
    # when debug=True. I fed them with dummy feature
    # to prevent switching off debug, which can happen if
    # no feature is active.
    import nvdlfw_inspect.api as debug_api

    debug_api.initialize(
        os.environ["NVTE_TEST_NVINSPECT_CONFIG_FILE"],
        feature_dirs=os.environ["NVTE_TEST_NVINSPECT_FEATURE_DIRS"],
    )


def is_fp8_supported(config: ModelConfig):
    if (
        config.max_seqlen_q * config.batch_size % 16
        or config.max_seqlen_kv * config.batch_size % 16
    ):
        return False
    if config.hidden_size % 16 or config.hidden_size_kv % 16:
        return False
    return True


model_configs = {
    "126m": ModelConfig(2, 2048, 12, 64, num_layers=12),
    "small": ModelConfig(2, 32, 2, 32, num_layers=2),
    "weird": ModelConfig(3, 37, 3, 23, num_layers=2),
    "large": ModelConfig(2, 128, 4, 128, num_layers=1),
}


def nvfp4_vanilla():
    return recipe.NVFP4BlockScaling(
        disable_rht=True,
        disable_stochastic_rounding=True,
        disable_2d_quantization=True,
    )


def nvfp4_row_scaled():
    nvfp4_recipe = recipe.NVFP4BlockScaling(
        disable_rht=True,
        disable_stochastic_rounding=True,
        disable_2d_quantization=True,
        row_scaled_activation=True,
        backward_override="dequantized",
    )
    nvfp4_recipe.fp4_quant_fwd_inp = recipe.QParams()
    nvfp4_recipe.fp4_quant_fwd_weight = recipe.QParams()
    nvfp4_recipe.fp4_quant_bwd_grad = recipe.QParams()
    return nvfp4_recipe


def nvfp4_4over6():
    nvfp4_recipe = recipe.NVFP4BlockScaling(
        disable_rht=True,
        disable_stochastic_rounding=True,
        nvfp4_4over6="all",
    )
    nvfp4_recipe.fp4_quant_fwd_inp = recipe.QParams()
    nvfp4_recipe.fp4_quant_fwd_weight = recipe.QParams(fp4_2d_quantization=True)
    nvfp4_recipe.fp4_quant_bwd_grad = recipe.QParams()
    return nvfp4_recipe


fp8_recipes = []
if mxfp8_available:
    fp8_recipes.append(recipe.MXFP8BlockScaling())
if nvfp4_available:
    fp8_recipes.append(nvfp4_vanilla())
    fp8_recipes.append(nvfp4_4over6())
if fp8_block_scaling_available:
    fp8_recipes.append(recipe.Float8BlockScaling())
if fp8_available:
    fp8_recipes.append(recipe.Float8CurrentScaling())
    fp8_recipes.append(recipe.DelayedScaling())
fp8_recipes.append(None)

param_types = [torch.float32, torch.float16]
if is_bf16_available():  # bf16 requires sm_80 or higher
    param_types.append(torch.bfloat16)

all_boolean = [True, False]
batch_sizes_with_zero = [0, 1, 2]

all_activations = [
    "gelu",
    "geglu",
    "glu",
    "qgelu",
    "qgeglu",
    "relu",
    "reglu",
    "srelu",
    "sreglu",
    "silu",
    "swiglu",
    "clamped_swiglu",
]
all_normalizations = ["LayerNorm", "RMSNorm"]


def _disable_wgrads(block):
    for p in block.parameters():
        p.requires_grad = False


@pytest.fixture(autouse=True)
def reset_global_fp8_state():
    yield
    FP8GlobalStateManager.reset()


def check_grouped_weight(
    module: GroupedLinear, num_gemms: int, out_features: int, in_features: int
):
    """
    Verify GroupedLinear exposes one grouped weight parameter with shape
    [num_gemms, out_features, in_features].
    """
    weight_params = [(name, p) for name, p in module.named_parameters() if "weight" in name]
    assert len(weight_params) == 1, f"Expected 1 grouped weight parameter, got {len(weight_params)}"
    name, weight = weight_params[0]
    assert name == "weight", f"Expected grouped parameter name 'weight', got {name}"
    assert tuple(weight.shape) == (num_gemms, out_features, in_features), (
        "Grouped weight has unexpected shape. "
        f"Expected {(num_gemms, out_features, in_features)}, got {tuple(weight.shape)}"
    )


def check_grouped_bias(module: GroupedLinear, num_gemms: int, out_features: int):
    """Verify GroupedLinear exposes one grouped bias parameter with shape [num_gemms, out_features]."""
    bias_params = [(name, p) for name, p in module.named_parameters() if name == "bias"]
    assert len(bias_params) == 1, f"Expected 1 grouped bias parameter, got {len(bias_params)}"
    name, bias = bias_params[0]
    assert name == "bias", f"Expected grouped parameter name 'bias', got {name}"
    assert tuple(bias.shape) == (num_gemms, out_features), (
        "Grouped bias has unexpected shape. "
        f"Expected {(num_gemms, out_features)}, got {tuple(bias.shape)}"
    )


def _test_sanity_e2e_amp(block, dtype, config, fp8_recipe, skip_wgrad):
    te_inp_hidden_states = torch.randn(
        (config.max_seqlen_q, config.batch_size, config.hidden_size),
        dtype=torch.float32,
        device="cuda",
        requires_grad=True,
    )
    te_inp_hidden_states.retain_grad()
    te_inp_attn_mask = torch.randint(
        2,
        (1, 1, config.max_seqlen_q, config.max_seqlen_kv),
        dtype=torch.bool,
        device="cuda",
    )

    if skip_wgrad:
        _disable_wgrads(block)

    use_fp8 = fp8_recipe is not None
    with torch.autocast(device_type="cuda", enabled=True, dtype=dtype):
        with autocast(enabled=use_fp8, recipe=fp8_recipe):
            te_out = block(te_inp_hidden_states, attention_mask=te_inp_attn_mask)
        loss = te_out.sum()

    loss.backward()
    torch.cuda.synchronize()

    assert te_out.dtype == dtype, "AMP wrong output type."
    assert te_inp_hidden_states.grad is not None, "Gradient should not be empty"
    assert te_inp_hidden_states.grad.dtype == torch.float32, "AMP wrong dgrad type."
    for name, p in block.named_parameters():
        if p.requires_grad:
            assert p.grad.dtype == torch.float32, f"AMP wrong wgrad type for {name}."


def _test_sanity_e2e_gradient_accumulation_fusion(block, dtype, config, fp8_recipe, skip_wgrad):
    te_inp_hidden_states = torch.randn(
        (config.max_seqlen_q, config.batch_size, config.hidden_size),
        dtype=dtype,
        device="cuda",
        requires_grad=True,
    )
    te_inp_attn_mask = torch.randint(
        2,
        (1, 1, config.max_seqlen_q, config.max_seqlen_kv),
        dtype=torch.bool,
        device="cuda",
    )

    if skip_wgrad:
        _disable_wgrads(block)

    for name, p in block.named_parameters():
        if "layer_norm_weight" in name:
            continue
        elif "weight" in name and p.requires_grad:
            p.main_grad = torch.zeros_like(p)
            p.grad_added_to_main_grad = False  # Should be set to True after backward

    use_fp8 = fp8_recipe is not None
    with autocast(enabled=use_fp8, recipe=fp8_recipe):
        te_out = block(te_inp_hidden_states, attention_mask=te_inp_attn_mask)
    loss = te_out.sum()
    loss.backward()
    torch.cuda.synchronize()

    failed_grads = []
    failed_grad_added_flags = []
    for name, p in block.named_parameters():
        if "layer_norm_weight" in name:
            continue
        elif "weight" in name and p.requires_grad:
            if not torch.count_nonzero(p.main_grad) > 0:
                failed_grads.append(name)
            if not getattr(p, "grad_added_to_main_grad", False):
                failed_grad_added_flags.append(name)
    assert len(failed_grads) == 0, f"Gradient not accumulated for {failed_grads}."
    assert (
        len(failed_grad_added_flags) == 0
    ), f"grad_added_to_main_grad not set to True for {failed_grad_added_flags}."


def _test_sanity_e2e(block, dtype, config, fp8_recipe, skip_wgrad):
    te_inp_hidden_states = torch.randn(
        (config.max_seqlen_q, config.batch_size, config.hidden_size),
        dtype=dtype,
        device="cuda",
        requires_grad=True,
    )

    if skip_wgrad:
        _disable_wgrads(block)

    use_fp8 = fp8_recipe is not None
    with autocast(enabled=use_fp8, recipe=fp8_recipe):
        te_out = block(te_inp_hidden_states)
    loss = te_out.sum()
    loss.backward()
    torch.cuda.synchronize()


def _test_sanity_e2e_bert(block, dtype, config, fp8_recipe, skip_wgrad):
    te_inp_hidden_states = torch.randn(
        (config.max_seqlen_q, config.batch_size, config.hidden_size),
        dtype=dtype,
        device="cuda",
        requires_grad=True,
    )

    te_inp_attn_mask = torch.randint(
        2,
        (config.batch_size, 1, 1, config.max_seqlen_q),
        dtype=torch.bool,
        device="cuda",
    )

    if skip_wgrad:
        _disable_wgrads(block)

    use_fp8 = fp8_recipe is not None
    with autocast(enabled=use_fp8, recipe=fp8_recipe):
        te_out = block(te_inp_hidden_states, attention_mask=te_inp_attn_mask)
    loss = te_out.sum()
    loss.backward()
    torch.cuda.synchronize()


def _test_sanity_e2e_T5(block, dtype, config, fp8_recipe, skip_wgrad):
    te_inp_hidden_states = torch.randn(
        (config.max_seqlen_q, config.batch_size, config.hidden_size),
        dtype=dtype,
        device="cuda",
        requires_grad=True,
    )
    te_inp_attn_mask = torch.randint(
        2,
        (1, 1, config.max_seqlen_q, config.max_seqlen_kv),
        dtype=torch.bool,
        device="cuda",
    )

    enc_dec_attn_mask = torch.randint(
        2,
        (config.batch_size, 1, 1, config.max_seqlen_kv),
        dtype=torch.bool,
        device="cuda",
    )

    if skip_wgrad:
        _disable_wgrads(block)

    use_fp8 = fp8_recipe is not None
    with autocast(enabled=use_fp8, recipe=fp8_recipe):
        te_out = block(
            te_inp_hidden_states,
            attention_mask=te_inp_attn_mask,
            encoder_output=te_inp_hidden_states,
            enc_dec_attn_mask=enc_dec_attn_mask,
        )
    loss = te_out.sum()
    loss.backward()
    torch.cuda.synchronize()


def _test_sanity_common(
    block, dtype, config, fp8_recipe, skip_wgrad, skip_dgrad, microbatching=True
):
    if skip_dgrad and skip_wgrad:
        pytest.skip("No gradient computation; Skipping to avoid PyTorch RuntimeError.")

    te_inp = torch.randn(
        (config.max_seqlen_q, config.batch_size, config.hidden_size),
        dtype=dtype,
        device="cuda",
        requires_grad=not skip_dgrad,
    )

    if skip_wgrad:
        _disable_wgrads(block)

    use_fp8 = fp8_recipe is not None
    with autocast(enabled=use_fp8, recipe=fp8_recipe):
        if not microbatching:
            te_out = block(te_inp)
        else:
            _ = block(te_inp, is_first_microbatch=True)
            te_out = block(te_inp, is_first_microbatch=False)
    if isinstance(te_out, tuple):
        te_out = te_out[0]
    loss = te_out.sum()
    loss.backward()
    torch.cuda.synchronize()


def _test_sanity_normalization_amp(block, dtype, config, skip_wgrad, skip_dgrad):
    if skip_dgrad and skip_wgrad:
        pytest.skip("No gradient computation; Skipping to avoid PyTorch RuntimeError.")

    te_inp = torch.randn(
        (config.max_seqlen_q, config.batch_size, config.hidden_size),
        device="cuda",
        requires_grad=True,
    )
    te_inp.retain_grad()

    with torch.autocast(device_type="cuda", enabled=True, dtype=dtype):
        te_out = block(te_inp)
        loss = te_out.sum()
    loss.backward()

    torch.cuda.synchronize()

    assert te_out.dtype == dtype, "AMP wrong output type."
    assert te_inp.grad is not None, "Gradient should not be empty"
    assert te_inp.grad.dtype == torch.float32, "AMP wrong dgrad type."
    for name, p in block.named_parameters():
        if p.requires_grad:
            assert p.grad.dtype == torch.float32, f"AMP wrong wgrad type for {name}."


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("model", ["small", "weird"])
@pytest.mark.parametrize("skip_wgrad", all_boolean)
@pytest.mark.parametrize("skip_dgrad", all_boolean)
@pytest.mark.parametrize("normalization", all_normalizations)
def test_sanity_normalization_amp(dtype, model, skip_wgrad, skip_dgrad, normalization):
    config = model_configs[model]
    module = RMSNorm if normalization == "RMSNorm" else LayerNorm

    block = module(config.hidden_size).to(dtype=torch.float32).cuda()
    _test_sanity_normalization_amp(block, dtype, config, skip_wgrad, skip_dgrad)


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize(
    "fp8_recipe",
    fp8_recipes + ([nvfp4_row_scaled()] if nvfp4_available else []),
    ids=recipe_id,
)
@pytest.mark.parametrize("backward_override", [None, "high_precision", "dequantized"])
@pytest.mark.parametrize("model", ["small", "weird"])
@pytest.mark.parametrize("skip_wgrad", all_boolean)
@pytest.mark.parametrize("zero_centered_gamma", all_boolean)
@pytest.mark.parametrize("skip_dgrad", all_boolean)
@pytest.mark.parametrize("normalization", all_normalizations)
@pytest.mark.parametrize("microbatching", all_boolean)
def test_sanity_layernorm_linear(
    dtype,
    fp8_recipe,
    backward_override,
    model,
    skip_wgrad,
    zero_centered_gamma,
    skip_dgrad,
    normalization,
    microbatching,
):
    config = model_configs[model]

    skip_unsupported_backward_override("layernorm_linear", fp8_recipe, backward_override)
    if fp8_recipe is not None:
        fp8_recipe = copy.deepcopy(fp8_recipe)
        fp8_recipe.backward_override = backward_override

    if fp8_recipe is not None:
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    sigma = 0.023
    init_method = init_method_normal(sigma)

    block = LayerNormLinear(
        config.hidden_size,
        config.hidden_size * 3,
        init_method=init_method,
        zero_centered_gamma=zero_centered_gamma,
        normalization=normalization,
        params_dtype=dtype,
        device="cuda",
    )
    _test_sanity_common(block, dtype, config, fp8_recipe, skip_wgrad, skip_dgrad, microbatching)


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize(
    "fp8_recipe",
    fp8_recipes + ([nvfp4_row_scaled()] if nvfp4_available else []),
    ids=recipe_id,
)
@pytest.mark.parametrize("backward_override", [None, "high_precision", "dequantized"])
@pytest.mark.parametrize("model", ["small", "weird"])
@pytest.mark.parametrize("skip_wgrad", all_boolean)
@pytest.mark.parametrize("skip_dgrad", all_boolean)
@pytest.mark.parametrize("microbatching", all_boolean)
def test_sanity_linear(
    dtype, fp8_recipe, backward_override, model, skip_wgrad, skip_dgrad, microbatching
):
    config = model_configs[model]

    skip_unsupported_backward_override("linear", fp8_recipe, backward_override)
    if fp8_recipe is not None:
        fp8_recipe = copy.deepcopy(fp8_recipe)
        fp8_recipe.backward_override = backward_override

    if fp8_recipe is not None:
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    sigma = 0.023
    output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)

    block = Linear(
        config.hidden_size,
        config.hidden_size,
        init_method=output_layer_init_method,
        params_dtype=dtype,
        device="cuda",
    )
    _test_sanity_common(block, dtype, config, fp8_recipe, skip_wgrad, skip_dgrad, microbatching)


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("bs", batch_sizes_with_zero)
@pytest.mark.parametrize("model", ["small", "weird"])
@pytest.mark.parametrize(
    "fp8_recipe",
    fp8_recipes + ([nvfp4_row_scaled()] if nvfp4_available else []),
    ids=recipe_id,
)
@pytest.mark.parametrize("backward_override", [None, "high_precision", "dequantized"])
@pytest.mark.parametrize("fp8_model_params", all_boolean)
@pytest.mark.parametrize("use_bias", all_boolean)
def test_sanity_linear_with_zero_tokens(
    dtype, bs, model, fp8_recipe, backward_override, fp8_model_params, use_bias
):
    config = model_configs[model]
    ffn_hidden_size = 4 * config.hidden_size
    num_tokens = bs * config.max_seqlen_q

    skip_unsupported_backward_override("linear", fp8_recipe, backward_override)
    if fp8_recipe is not None:
        fp8_recipe = copy.deepcopy(fp8_recipe)
        fp8_recipe.backward_override = backward_override

    if fp8_recipe is not None:
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    use_fp8 = fp8_recipe is not None
    with quantized_model_init(enabled=use_fp8 and fp8_model_params, recipe=fp8_recipe):
        te_linear = Linear(
            config.hidden_size, ffn_hidden_size, bias=use_bias, params_dtype=dtype
        ).cuda()

    inp_hidden_states = torch.randn(
        num_tokens, config.hidden_size, dtype=dtype, requires_grad=True
    ).cuda()
    with autocast(enabled=use_fp8, recipe=fp8_recipe):
        out = te_linear(inp_hidden_states)
    loss = out.sum()
    loss.backward()
    torch.cuda.synchronize()
    assert out.shape == (num_tokens, ffn_hidden_size)


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("bs", batch_sizes_with_zero)
@pytest.mark.parametrize("model", ["small", "weird"])
@pytest.mark.parametrize(
    "fp8_recipe",
    fp8_recipes + ([nvfp4_row_scaled()] if nvfp4_available else []),
    ids=recipe_id,
)
@pytest.mark.parametrize("backward_override", [None, "high_precision", "dequantized"])
@pytest.mark.parametrize("fp8_model_params", all_boolean)
@pytest.mark.parametrize("use_bias", all_boolean)
@pytest.mark.parametrize("single_param", all_boolean)
@pytest.mark.parametrize("empty_split", ["first", "last", "middle"])
@pytest.mark.parametrize("num_gemms", [4])
def test_sanity_grouped_linear(
    dtype,
    bs,
    model,
    fp8_recipe,
    backward_override,
    fp8_model_params,
    use_bias,
    single_param,
    num_gemms,
    empty_split,
):
    config = model_configs[model]
    ffn_hidden_size = 4 * config.hidden_size
    # Small batch size used to catch bug from https://github.com/NVIDIA/TransformerEngine/pull/1527.
    bs = bs * 16
    num_tokens = bs * config.max_seqlen_q * (num_gemms - 1)
    skip_unsupported_backward_override("grouped_linear", fp8_recipe, backward_override)
    if fp8_recipe is not None:
        fp8_recipe = copy.deepcopy(fp8_recipe)
        fp8_recipe.backward_override = backward_override
    if single_param and not is_module_grouped_tensor_path_supported(
        fp8_recipe,
        dtype,
    ):
        pytest.skip("Single grouped parameters require the native grouped-tensor path")
    if single_param:
        # Single grouped parameters intentionally have no split-quantize fallback, so this
        # test must satisfy the native grouped kernels' shape contract. MCore pads each
        # expert's token count to 256; TE requires at least 128-row alignment. Weight K must
        # be 64-aligned.
        tokens_per_nonempty_expert = bs * config.max_seqlen_q
        if tokens_per_nonempty_expert % 128 != 0:
            pytest.skip("Single grouped parameters require each nonempty m_split to be 128-aligned")
        k_alignment = 64
        if config.hidden_size % k_alignment != 0:
            pytest.skip(f"Single grouped parameters require GEMM K to be {k_alignment}-aligned")

    if fp8_recipe is not None:
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4():
            if dtype != torch.bfloat16:
                pytest.skip("NVFP4 GroupedLinear requires BF16")
            if single_param and not fp8_model_params:
                pytest.skip(
                    "NVFP4 single grouped BF16 primary weights require unsupported non-RHT "
                    "grouped weight quantization; enable quantized model initialization"
                )

    use_fp8 = fp8_recipe is not None
    with quantized_model_init(enabled=use_fp8 and fp8_model_params, recipe=fp8_recipe):
        te_grouped_linear = GroupedLinear(
            num_gemms,
            config.hidden_size,
            ffn_hidden_size,
            bias=use_bias,
            params_dtype=dtype,
            single_grouped_weight=single_param,
            single_grouped_bias=single_param,
            use_grouped_tensor=single_param,
        ).cuda()

    # Verify grouped linear exposes a single grouped weight parameter(and bias when applicable).
    if fp8_recipe is None or not (fp8_recipe.delayed() or fp8_recipe.float8_current_scaling()):
        if single_param:
            check_grouped_weight(te_grouped_linear, num_gemms, ffn_hidden_size, config.hidden_size)
            if use_bias:
                check_grouped_bias(te_grouped_linear, num_gemms, ffn_hidden_size)

    inp_hidden_states = torch.randn(
        num_tokens, config.hidden_size, dtype=dtype, requires_grad=True
    ).cuda()
    m_splits = [bs * config.max_seqlen_q] * num_gemms
    if empty_split == "first":
        m_splits[0] = 0
    elif empty_split == "last":
        m_splits[-1] = 0
    elif empty_split == "middle":
        m_splits[num_gemms // 2] = 0
    if single_param:
        m_splits = torch.tensor(m_splits, dtype=torch.int64, device="cuda")

    if NVTE_TEST_NVINSPECT_ENABLED and single_param:
        # DebugQuantizer operates on per-GEMM tensors, while single grouped parameters
        # intentionally have no split-quantize fallback.
        with pytest.raises(
            RuntimeError,
            match="TE debug features do not support single grouped parameters",
        ):
            with autocast(enabled=use_fp8, recipe=fp8_recipe):
                te_grouped_linear(inp_hidden_states, m_splits)
        return

    with autocast(enabled=use_fp8, recipe=fp8_recipe):
        out = te_grouped_linear(inp_hidden_states, m_splits)
    loss = out.sum()
    loss.backward()
    torch.cuda.synchronize()
    assert out.shape == (num_tokens, ffn_hidden_size)


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("fp8_recipe", fp8_recipes, ids=recipe_id)
@pytest.mark.parametrize("model", ["small", "weird"])
@pytest.mark.parametrize("skip_wgrad", all_boolean)
@pytest.mark.parametrize("zero_centered_gamma", all_boolean)
@pytest.mark.parametrize("skip_dgrad", all_boolean)
@pytest.mark.parametrize("activation", all_activations)
@pytest.mark.parametrize("normalization", all_normalizations)
@pytest.mark.parametrize("microbatching", all_boolean)
@pytest.mark.parametrize("checkpoint", all_boolean)
def test_sanity_layernorm_mlp(
    dtype,
    fp8_recipe,
    model,
    skip_wgrad,
    zero_centered_gamma,
    skip_dgrad,
    activation,
    normalization,
    microbatching,
    checkpoint,
):
    config = model_configs[model]

    if fp8_recipe is not None:
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    sigma = 0.023
    init_method = init_method_normal(sigma)
    output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)
    activation_params = None if activation != "clamped_swiglu" else {"limit": 7.0, "alpha": 1.702}
    block = LayerNormMLP(
        config.hidden_size,
        4 * config.hidden_size,
        init_method=init_method,
        output_layer_init_method=output_layer_init_method,
        zero_centered_gamma=zero_centered_gamma,
        activation=activation,
        activation_params=activation_params,
        normalization=normalization,
        params_dtype=dtype,
        device="cuda",
        checkpoint=checkpoint,
    )
    _test_sanity_common(block, dtype, config, fp8_recipe, skip_wgrad, skip_dgrad, microbatching)


@pytest.mark.parametrize(
    "kind",
    ["linear", "lnlinear", "rmslinear", "mlp_gelu", "rmsmlp_swiglu"],
)
@pytest.mark.parametrize(
    "shape,noncontiguous",
    [
        ((128,), False),
        ((2, 4, 4, 128), False),
        ((2, 4, 4, 128), True),
    ],
)
def test_sanity_logical_activation_shapes(kind, shape, noncontiguous, monkeypatch):
    """Modules preserve unusual logical shapes without restoration views."""
    kwargs = dict(device="cuda", params_dtype=torch.bfloat16, bias=True)
    if kind == "linear":
        module = Linear(128, 256, **kwargs)
        reference_module = Linear(128, 256, **kwargs)
        module_impl = linear
        output_bias = module.bias
    elif kind.endswith("linear"):
        module_kwargs = dict(
            normalization="RMSNorm" if kind == "rmslinear" else "LayerNorm",
            return_layernorm_output=True,
        )
        module = LayerNormLinear(128, 256, **module_kwargs, **kwargs)
        reference_module = LayerNormLinear(128, 256, **module_kwargs, **kwargs)
        module_impl = layernorm_linear
        output_bias = module.bias
    else:
        module_kwargs = dict(
            normalization="RMSNorm" if kind.startswith("rms") else "LayerNorm",
            activation="gelu" if kind == "mlp_gelu" else "swiglu",
            return_layernorm_output=True,
        )
        module = LayerNormMLP(128, 256, **module_kwargs, **kwargs)
        reference_module = LayerNormMLP(128, 256, **module_kwargs, **kwargs)
        module_impl = layernorm_mlp
        output_bias = module.fc2_bias
    reference_module.load_state_dict(module.state_dict())

    storage_shape = (*shape[:-1], shape[-1] * 2) if noncontiguous else shape
    x = torch.randn(storage_shape, device="cuda", dtype=torch.bfloat16)
    if noncontiguous:
        x = x[..., ::2]
        assert not x.is_contiguous()
    x = x.detach().requires_grad_()
    reference_x = x.detach().reshape(-1, x.shape[-1]).clone().requires_grad_()

    seen_gemm_layouts = []
    general_gemm_ = module_impl.general_gemm
    check_logical_shapes = True

    def checked_gemm(a, b, *args, **kwargs):
        # Fprop and dgrad retain activation rank; wgrad contracts token dimensions.
        out = general_gemm_(a, b, *args, **kwargs)
        if check_logical_shapes:
            assert b.ndim == len(shape)
            if kwargs.get("layout", "TN") != "NT":
                assert out[0].ndim == len(shape)
            seen_gemm_layouts.append(kwargs.get("layout", "TN"))
        return out

    monkeypatch.setattr(module_impl, "general_gemm", checked_gemm)

    seen_norm_stages = []
    if kind != "linear":
        norm = "rmsnorm" if kind.startswith("rms") else "layernorm"
        for suffix in ("fwd", "bwd"):
            tex = module_common.tex if suffix == "fwd" else module_impl.tex
            norm_ = getattr(tex, f"{norm}_{suffix}")

            def checked_norm(*args, _norm=norm_, _suffix=suffix, **kwargs):
                if check_logical_shapes:
                    assert args[0].ndim == len(shape)
                    seen_norm_stages.append(_suffix)
                return _norm(*args, **kwargs)

            monkeypatch.setattr(tex, f"{norm}_{suffix}", checked_norm)

    outputs = module(x)
    outputs = outputs if isinstance(outputs, tuple) else (outputs,)
    for output in outputs:
        assert output.shape[:-1] == shape[:-1]
        assert output._base is None
    sum(output.sum() for output in outputs).backward()

    check_logical_shapes = False
    reference_outputs = reference_module(reference_x)
    reference_outputs = (
        reference_outputs if isinstance(reference_outputs, tuple) else (reference_outputs,)
    )
    sum(output.sum() for output in reference_outputs).backward()

    assert x.grad is not None and x.grad.shape == x.shape
    assert len(outputs) == len(reference_outputs)
    for output, reference_output in zip(outputs, reference_outputs):
        reference_output = reference_output.reshape(*shape[:-1], reference_output.shape[-1])
        torch.testing.assert_close(output, reference_output, rtol=0, atol=0)
    torch.testing.assert_close(x.grad, reference_x.grad.reshape(shape), rtol=0, atol=0)
    for (name, parameter), (reference_name, reference_parameter) in zip(
        module.named_parameters(), reference_module.named_parameters()
    ):
        assert name == reference_name
        assert parameter.grad is not None and parameter.grad.shape == parameter.shape
        torch.testing.assert_close(parameter.grad, reference_parameter.grad, rtol=0, atol=0)
    num_tokens = x.numel() // x.shape[-1]
    torch.testing.assert_close(
        output_bias.grad,
        torch.full_like(output_bias, num_tokens),
        rtol=0,
        atol=0,
    )
    assert {"TN", "NN", "NT"}.issubset(seen_gemm_layouts)
    if kind != "linear":
        assert set(seen_norm_stages) == {"fwd", "bwd"}


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("fp8_recipe", fp8_recipes, ids=recipe_id)
@pytest.mark.parametrize("model", ["small"])
@pytest.mark.parametrize("skip_wgrad", all_boolean)
@pytest.mark.parametrize("bias", all_boolean)
@pytest.mark.parametrize("activation", ["gelu", "swiglu"])
@pytest.mark.parametrize("normalization", all_normalizations)
@pytest.mark.parametrize("parallel_attention_mlp", all_boolean)
def test_sanity_gpt(
    dtype,
    fp8_recipe,
    model,
    skip_wgrad,
    bias,
    activation,
    normalization,
    parallel_attention_mlp,
):
    config = model_configs[model]

    if fp8_recipe is not None:
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    sigma = 0.023
    init_method = init_method_normal(sigma)
    output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)

    block = TransformerLayer(
        config.hidden_size,
        4 * config.hidden_size,
        config.num_heads,
        init_method=init_method,
        output_layer_init_method=output_layer_init_method,
        hidden_dropout=0.1,
        attention_dropout=0.1,
        kv_channels=config.kv_channels,
        params_dtype=dtype,
        apply_residual_connection_post_layernorm=False,
        output_layernorm=False,
        bias=bias,
        activation=activation,
        normalization=normalization,
        device="cuda",
        parallel_attention_mlp=parallel_attention_mlp,
    )

    _test_sanity_e2e(block, dtype, config, fp8_recipe, skip_wgrad)


def test_sanity_gpt_126m():
    fp8_recipe = None
    if fp8_available:
        fp8_recipe = recipe.DelayedScaling(
            margin=0,
            fp8_format=recipe.Format.E4M3,
            amax_history_len=16,
            amax_compute_algo="most_recent",
        )
    test_sanity_gpt(
        dtype=param_types[-1],
        fp8_recipe=fp8_recipe,
        model="126m",
        skip_wgrad=False,
        bias=True,
        activation="gelu",
        normalization="LayerNorm",
        parallel_attention_mlp=False,
    )


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("fp8_recipe", fp8_recipes, ids=recipe_id)
@pytest.mark.parametrize("model", ["small"])
@pytest.mark.parametrize("skip_wgrad", all_boolean)
@pytest.mark.parametrize("normalization", all_normalizations)
def test_sanity_bert(dtype, fp8_recipe, model, skip_wgrad, normalization):
    config = model_configs[model]

    if fp8_recipe is not None:
        if not fp8_available:
            pytest.skip(reason_for_no_fp8)
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    sigma = 0.023
    init_method = init_method_normal(sigma)
    output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)

    block = TransformerLayer(
        config.hidden_size,
        4 * config.hidden_size,
        config.num_heads,
        init_method=init_method,
        output_layer_init_method=output_layer_init_method,
        hidden_dropout=0.1,
        attention_dropout=0.1,
        kv_channels=config.kv_channels,
        params_dtype=dtype,
        apply_residual_connection_post_layernorm=True,
        output_layernorm=True,
        self_attn_mask_type="causal",
        normalization=normalization,
        device="cuda",
    )

    _test_sanity_e2e_bert(block, dtype, config, fp8_recipe, skip_wgrad)


def test_sanity_bert_126m():
    fp8_recipe = recipe.DelayedScaling(
        margin=0,
        fp8_format=recipe.Format.E4M3,
        amax_history_len=1,
        amax_compute_algo="most_recent",
    )
    test_sanity_bert(
        dtype=param_types[-1],
        fp8_recipe=fp8_recipe,
        model="126m",
        skip_wgrad=False,
        normalization="LayerNorm",
    )


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("fp8_recipe", fp8_recipes, ids=recipe_id)
@pytest.mark.parametrize("model", ["small"])
@pytest.mark.parametrize("skip_wgrad", all_boolean)
@pytest.mark.parametrize("normalization", all_normalizations)
def test_sanity_T5(dtype, fp8_recipe, model, skip_wgrad, normalization):
    config = model_configs[model]

    if fp8_recipe is not None:
        if not fp8_available:
            pytest.skip(reason_for_no_fp8)
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    sigma = 0.023
    init_method = init_method_normal(sigma)
    output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)

    block = TransformerLayer(
        config.hidden_size,
        4 * config.hidden_size,
        config.num_heads,
        init_method=init_method,
        output_layer_init_method=output_layer_init_method,
        hidden_dropout=0.1,
        attention_dropout=0.1,
        kv_channels=config.kv_channels,
        params_dtype=dtype,
        apply_residual_connection_post_layernorm=False,
        output_layernorm=False,
        layer_type="decoder",
        normalization=normalization,
        device="cuda",
    )

    _test_sanity_e2e_T5(block, dtype, config, fp8_recipe, skip_wgrad)


def test_sanity_T5_126m():
    fp8_recipe = recipe.DelayedScaling(
        margin=0,
        fp8_format=recipe.Format.E4M3,
        amax_history_len=1,
        amax_compute_algo="most_recent",
    )
    test_sanity_T5(
        dtype=param_types[-1],
        fp8_recipe=fp8_recipe,
        model="126m",
        skip_wgrad=False,
        normalization="LayerNorm",
    )


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("fp8_recipe", fp8_recipes, ids=recipe_id)
@pytest.mark.parametrize("model", ["small"])
@pytest.mark.parametrize("skip_wgrad", all_boolean)
def test_sanity_amp_and_nvfuser(dtype, fp8_recipe, model, skip_wgrad):
    config = model_configs[model]

    if fp8_recipe is not None:
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    sigma = 0.023
    init_method = init_method_normal(sigma)
    output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)

    block = TransformerLayer(
        config.hidden_size,
        4 * config.hidden_size,
        config.num_heads,
        init_method=init_method,
        output_layer_init_method=output_layer_init_method,
        hidden_dropout=0.1,
        attention_dropout=0.1,
        kv_channels=config.kv_channels,
        params_dtype=torch.float32,
        device="cuda",
    )

    _test_sanity_e2e_amp(block, dtype, config, fp8_recipe, skip_wgrad)


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("fp8_recipe", fp8_recipes, ids=recipe_id)
@pytest.mark.parametrize("model", ["small"])
def test_sanity_drop_path(dtype, fp8_recipe, model):
    config = model_configs[model]

    if fp8_recipe is not None:
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    sigma = 0.023
    init_method = init_method_normal(sigma)
    output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)

    block = TransformerLayer(
        config.hidden_size,
        4 * config.hidden_size,
        config.num_heads,
        init_method=init_method,
        output_layer_init_method=output_layer_init_method,
        hidden_dropout=0.1,
        attention_dropout=0.1,
        kv_channels=config.kv_channels,
        params_dtype=dtype,
        apply_residual_connection_post_layernorm=False,
        output_layernorm=False,
        drop_path_rate=1.0,
        device="cuda",
    )

    _test_sanity_e2e(block, dtype, config, fp8_recipe, False)


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("fp8_recipe", fp8_recipes, ids=recipe_id)
@pytest.mark.parametrize("model", ["small"])
@pytest.mark.parametrize("skip_wgrad", all_boolean)
def test_sanity_fused_qkv_params(dtype, fp8_recipe, model, skip_wgrad):
    config = model_configs[model]

    if fp8_recipe is not None:
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    sigma = 0.023
    init_method = init_method_normal(sigma)
    output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)

    block = TransformerLayer(
        config.hidden_size,
        4 * config.hidden_size,
        config.num_heads,
        init_method=init_method,
        output_layer_init_method=output_layer_init_method,
        hidden_dropout=0.1,
        attention_dropout=0.1,
        kv_channels=config.kv_channels,
        params_dtype=dtype,
        apply_residual_connection_post_layernorm=False,
        output_layernorm=False,
        fuse_qkv_params=True,
        device="cuda",
    )

    _test_sanity_e2e(block, dtype, config, fp8_recipe, skip_wgrad)


@pytest.mark.parametrize("dtype", param_types)
@pytest.mark.parametrize("fp8_recipe", fp8_recipes, ids=recipe_id)
@pytest.mark.parametrize("model", ["small"])
@pytest.mark.parametrize("skip_wgrad", all_boolean)
def test_sanity_gradient_accumulation_fusion(dtype, fp8_recipe, model, skip_wgrad):
    config = model_configs[model]

    if fp8_recipe is not None:
        if not is_fp8_supported(config):
            pytest.skip("Model config does not support FP8")
        if fp8_recipe.nvfp4() and dtype == torch.float16:
            pytest.skip("FP16 output for NVFP4 not supported")

    sigma = 0.023
    init_method = init_method_normal(sigma)
    output_layer_init_method = scaled_init_method_normal(sigma, config.num_layers)

    block = TransformerLayer(
        config.hidden_size,
        4 * config.hidden_size,
        config.num_heads,
        init_method=init_method,
        output_layer_init_method=output_layer_init_method,
        hidden_dropout=0.1,
        attention_dropout=0.1,
        kv_channels=config.kv_channels,
        params_dtype=dtype,
        apply_residual_connection_post_layernorm=False,
        output_layernorm=False,
        fuse_qkv_params=True,
        fuse_wgrad_accumulation=True,
        device="cuda",
    )

    _test_sanity_e2e_gradient_accumulation_fusion(block, dtype, config, fp8_recipe, skip_wgrad)


def _wgrad_fusion_module(module: str, hidden: int, dtype: torch.dtype):
    """A module that accumulates its weight gradients into ``main_grad``, and its forward."""
    kwargs = dict(params_dtype=dtype, device="cuda", fuse_wgrad_accumulation=True)
    if module == "Linear":
        block = Linear(hidden, hidden, bias=False, **kwargs)
    elif module == "LayerNormLinear":
        block = LayerNormLinear(hidden, hidden, bias=False, **kwargs)
    elif module == "LayerNormMLP":
        block = LayerNormMLP(hidden, 2 * hidden, bias=False, **kwargs)
    elif module == "GroupedLinear":
        block = GroupedLinear(2, hidden, hidden, bias=False, **kwargs)
        return block, lambda x: block(x, [x.shape[0] // 2, x.shape[0] - x.shape[0] // 2])
    else:
        block = te.ops.Linear(
            hidden, hidden, bias=False, device="cuda", dtype=dtype, accumulate_into_main_grad=True
        )
    return block, block


@pytest.mark.skipif(torch.cuda.device_count() < 2, reason="Needs two GPUs.")
# GroupedLinear is left out: its multi-stream cuBLAS GEMM keeps the streams of the first device
# it runs on, so its forward pass fails on a second device before any weight gradient.
@pytest.mark.parametrize("module", ["Linear", "LayerNormLinear", "LayerNormMLP", "ops.Linear"])
@pytest.mark.parametrize("zero_out_wgrad", all_boolean)
def test_sanity_dummy_wgrad_device(module, zero_out_wgrad):
    """The cached dummy weight gradient is on the weight's device when the same module shape
    runs backward on one GPU and then on another."""
    dtype, hidden, tokens = torch.bfloat16, 128, 64
    for device in (0, 1):
        with torch.cuda.device(device):
            block, forward = _wgrad_fusion_module(module, hidden, dtype)
            weights = [
                p
                for name, p in block.named_parameters()
                if "weight" in name and "layer_norm" not in name
            ]
            for p in weights:
                p.main_grad = torch.zeros(p.shape, dtype=torch.float32, device="cuda")
                p.grad_added_to_main_grad = False
                p.zero_out_wgrad = zero_out_wgrad
            x = torch.randn(tokens, hidden, dtype=dtype, device="cuda")
            forward(x).backward(torch.randn(tokens, hidden, dtype=dtype, device="cuda"))
            for p in weights:
                assert p.grad is not None and p.grad.device == p.device


@pytest.mark.parametrize(
    "module", ["Linear", "LayerNormLinear", "LayerNormMLP", "GroupedLinear", "ops.Linear"]
)
@pytest.mark.parametrize("zero_out_wgrad", all_boolean)
def test_sanity_zero_tensor_dummy_wgrad(module, zero_out_wgrad):
    """``zero_tensor_dummy_wgrad`` makes the dummy weight gradient a ZeroTensor.

    The module runs twice before one backward pass, as an LM head shared by the main and MTP
    heads does, so autograd adds the two dummy weight gradients. ``main_grad`` must not
    change, and ``zero_out_wgrad`` keeps its zero-filled dummy.
    """
    dtype, hidden, tokens = torch.bfloat16, 128, 64
    torch.manual_seed(seed)
    block, forward = _wgrad_fusion_module(module, hidden, dtype)
    weights = [
        p for name, p in block.named_parameters() if "weight" in name and "layer_norm" not in name
    ]
    inputs = [torch.randn(tokens, hidden, dtype=dtype, device="cuda") for _ in range(2)]
    grad_outputs = [torch.randn(tokens, hidden, dtype=dtype, device="cuda") for _ in range(2)]

    main_grads = {}
    for zero_tensor_dummy_wgrad in (False, True):
        for p in weights:
            p.main_grad = torch.zeros(p.shape, dtype=torch.float32, device="cuda")
            p.grad_added_to_main_grad = False
            p.zero_out_wgrad = zero_out_wgrad
            p.zero_tensor_dummy_wgrad = zero_tensor_dummy_wgrad
            p.grad = None
        outputs = [forward(x) for x in inputs]
        torch.autograd.backward(outputs, grad_outputs)
        main_grads[zero_tensor_dummy_wgrad] = [p.main_grad for p in weights]
        for p in weights:
            assert p.grad_added_to_main_grad
            assert p.grad is not None
            if zero_tensor_dummy_wgrad and not zero_out_wgrad:
                assert p.grad._is_zerotensor()
            elif zero_out_wgrad:
                assert not p.grad._is_zerotensor()
                assert torch.count_nonzero(p.grad) == 0
    for reference, main_grad in zip(main_grads[False], main_grads[True]):
        assert torch.count_nonzero(reference) > 0
        torch.testing.assert_close(main_grad, reference, rtol=0, atol=0)


def test_model_multiple_cast():
    a = torch.zeros((16, 16), device="cuda")
    m = Linear(16, 32)

    y = m(a)
    assert y.dtype == torch.float32

    m.half()
    a = a.half()

    y2 = m(a)
    assert y2.dtype == torch.float16


@pytest.mark.parametrize("N", [32])
@pytest.mark.parametrize("offset", [1, 3, 5])
@pytest.mark.parametrize("datatype", param_types)
def test_sanity_gemm_with_unalignment(N, offset, datatype):
    scratchpad = torch.randn(N * N + 2 * offset, device="cuda", dtype=datatype)
    inp = torch.reshape(scratchpad[offset:-offset], (N, N))
    weight = torch.reshape(scratchpad[offset * 2 :], (N, N))

    _ = general_gemm(A=weight, B=inp)
    torch.cuda.synchronize()


def test_sanity_general_gemm_non_fp8_bias_dtype_must_match_out():
    """BF16 bias + FP32 out must raise on the non-FP8/FP4 path (issue 3562)."""
    E, H, T = 128, 256, 64
    weight = torch.randn(E, H, dtype=torch.bfloat16, device="cuda")
    inp = torch.randn(T, H, dtype=torch.bfloat16, device="cuda")
    bias = torch.randn(E, dtype=torch.bfloat16, device="cuda")
    with pytest.raises(RuntimeError, match="bias dtype must match output dtype"):
        general_gemm(weight, inp, torch.float32, layout="TN", bias=bias)


@pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8)
@pytest.mark.parametrize("N", [32])
@pytest.mark.parametrize("datatype", [torch.float16, torch.bfloat16])
def test_sanity_fp8_gemm_with_unalignment(N, datatype):
    offset = 16
    scratchpad = torch.randn(N, N * N + offset, device="cuda", dtype=datatype)

    scales = torch.ones(1).cuda().squeeze()
    amaxes = torch.ones(1).cuda().squeeze()
    dtype = te.DType.kFloat8E4M3
    fp8_quantizer = Float8Quantizer(scales, amaxes, dtype)

    outp_type = datatype

    scratchpad_fp8 = fp8_quantizer(scratchpad)
    inp_fp8 = torch.reshape(scratchpad_fp8[0][:-offset], (N, N))
    weight_fp8 = torch.reshape(scratchpad_fp8[0][offset:], (N, N))
    general_gemm(
        weight_fp8,
        inp_fp8,
        outp_type,
        bias=None,
        use_split_accumulator=False,
    )
    torch.cuda.synchronize()


@pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8)
def test_replace_raw_data_for_float8tensor():
    """Test the functionality of replace_raw_data"""
    torch.manual_seed(12345)
    torch.cuda.manual_seed(12345)

    fp8_quantizer = Float8CurrentScalingQuantizer(fp8_dtype=te.DType.kFloat8E4M3, device="cuda")
    fp8_tensor = fp8_quantizer.make_empty([128, 128], dtype=torch.bfloat16, device="cuda")
    random_bf16_data = torch.randn(fp8_tensor.shape, dtype=torch.bfloat16, device="cuda")
    fp8_quantizer.update_quantized(random_bf16_data, fp8_tensor)

    attrs_to_check = [
        "_quantizer",
        "_fp8_dtype",
        "_scale_inv",
        "_transpose",
        "_transpose_invalid",
    ]
    attrs = {}
    for attr in attrs_to_check:
        attrs[attr] = getattr(fp8_tensor, attr)

    old_data = fp8_tensor._data
    new_data = torch.empty_like(old_data)
    replace_raw_data(fp8_tensor, new_data)

    # Make sure the new_data is properly assigned.
    assert fp8_tensor._data.data_ptr() != old_data.data_ptr()
    assert fp8_tensor._data.data_ptr() == new_data.data_ptr()
    # Make sure the values are not changed.
    torch.testing.assert_close(old_data, fp8_tensor._data, atol=0, rtol=0)
    # Make sure other attributes are not changed (totally identical)
    for attr in attrs_to_check:
        assert id(getattr(fp8_tensor, attr)) == id(attrs[attr])


@pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8)
def test_quantized_model_init_high_precision_init_val():
    """Test quantized_model_init with preserve_high_precision_init_val=True"""
    with quantized_model_init(preserve_high_precision_init_val=True):
        model = Linear(768, 768)

    weight = model.weight

    assert isinstance(weight, QuantizedTensor), "Weight should be QuantizedTensor"
    assert hasattr(weight, "_high_precision_init_val"), "_high_precision_init_val not found"
    assert hasattr(weight, "get_high_precision_init_val"), "get_high_precision_init_val() not found"
    assert hasattr(
        weight, "clear_high_precision_init_val"
    ), "clear_high_precision_init_val() not found"

    high_precision = weight.get_high_precision_init_val()
    assert high_precision.device.type == "cpu", "high_precision_init_val is not on the CPU"

    new_weight = weight._get_quantizer().make_empty(
        shape=weight.shape, dtype=weight.dtype, device=weight.device
    )
    weight._get_quantizer().update_quantized(high_precision.to(weight.device), new_weight)

    torch.testing.assert_close(
        new_weight.dequantize(dtype=weight.dtype),
        weight.dequantize(dtype=weight.dtype),
        rtol=0,
        atol=0,
    )

    weight.clear_high_precision_init_val()
    assert weight.get_high_precision_init_val() is None, "clear_high_precision_init_val() not work"
    assert not hasattr(
        weight, "._high_precision_init_val"
    ), "clear_high_precision_init_val() not work"


@pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8)
@pytest.mark.parametrize("move", ["cuda", "cpu", "half"])
def test_quantized_param_attrs_survive_apply(move):
    """Attributes attached to a quantized parameter survive nn.Module._apply.

    Quantized parameters implement the flatten protocol, so ``_apply`` moves them
    with ``swap_tensors``, which exchanges the parameter's whole ``__dict__``.
    Anything attached from the outside rides out on the discarded tensor unless
    the module re-attaches it.
    """
    with quantized_model_init(preserve_high_precision_init_val=True):
        model = Linear(64, 64)

    weight = model.weight
    expected = weight.get_high_precision_init_val()
    weight.probe_attr = "attached-from-outside"

    if move == "cuda":
        model = model.cuda()
    elif move == "cpu":
        model = model.cpu()
    else:
        model = model.half()

    weight = model.weight
    assert hasattr(weight, "get_high_precision_init_val"), f"accessor lost by .{move}()"
    assert hasattr(weight, "clear_high_precision_init_val"), f"accessor lost by .{move}()"
    torch.testing.assert_close(weight.get_high_precision_init_val(), expected, rtol=0, atol=0)
    assert weight.probe_attr == "attached-from-outside", f"custom attr lost by .{move}()"

    # The accessor must read the surviving parameter, not the discarded one.
    weight.clear_high_precision_init_val()
    assert weight.get_high_precision_init_val() is None


@pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
def test_grouped_linear_single_param_preserves_high_precision_init():
    """Grouped MXFP8 and discrete weights produce identical FP32 master initialization."""
    num_gemms = 3

    def make_module(single_grouped_weight):
        torch.manual_seed(1234)
        torch.cuda.manual_seed(1234)
        with quantized_model_init(
            enabled=True,
            recipe=recipe.MXFP8BlockScaling(),
            preserve_high_precision_init_val=True,
        ):
            return GroupedLinear(
                num_gemms=num_gemms,
                in_features=32,
                out_features=64,
                bias=False,
                params_dtype=torch.bfloat16,
                single_grouped_weight=single_grouped_weight,
            ).cuda()

    discrete_module = make_module(False)
    grouped_module = make_module(True)
    discrete_init_vals = [
        getattr(discrete_module, f"weight{i}").get_high_precision_init_val()
        for i in range(num_gemms)
    ]
    expected_grouped_init = torch.stack(discrete_init_vals, dim=0)

    grouped_weight = grouped_module.weight
    assert hasattr(grouped_weight, "get_high_precision_init_val")
    assert hasattr(grouped_weight, "clear_high_precision_init_val")
    grouped_init = grouped_weight.get_high_precision_init_val()
    assert grouped_init.device.type == "cpu"
    assert grouped_init.shape == grouped_weight.shape
    torch.testing.assert_close(
        grouped_init,
        expected_grouped_init,
        rtol=0,
        atol=0,
    )

    # This is the exact layout consumed when constructing the FP32 optimizer master.
    discrete_master = expected_grouped_init.float()
    grouped_master = grouped_init.float()
    torch.testing.assert_close(grouped_master, discrete_master, rtol=0, atol=0)

    grouped_weight.clear_high_precision_init_val()
    assert grouped_weight.get_high_precision_init_val() is None


@pytest.mark.skipif(not mxfp8_available, reason=reason_for_no_mxfp8)
def test_grouped_linear_rejects_partial_high_precision_init():
    """Packing fails rather than mixing preserved and dequantized initialization."""
    with quantized_model_init(
        enabled=True,
        recipe=recipe.MXFP8BlockScaling(),
        preserve_high_precision_init_val=True,
    ):
        module = GroupedLinear(
            num_gemms=2,
            in_features=32,
            out_features=64,
            bias=False,
            params_dtype=torch.bfloat16,
            single_grouped_weight=False,
        ).cuda()

    module.weight0.clear_high_precision_init_val()
    with pytest.raises(
        RuntimeError,
        match="inconsistent high-precision initialization state",
    ):
        module.make_grouped_weights()


def test_sanity_checkpointing_on_callables():
    """Test that TE checkpointing works correctly on callable modules."""

    # torch.autograf.function
    class MyFunction(torch.autograd.Function):
        @staticmethod
        def forward(ctx, inp):
            return inp

        @staticmethod
        def backward(ctx, grad_output):
            return grad_output

    module = MyFunction.apply
    inp = torch.randn(10, 10, device="cuda", requires_grad=True)

    out_checkpoint = checkpoint(module, inp)
    out_checkpoint.sum().backward()
    grad_checkpoint = inp.grad

    out_standard = module(inp)
    out_standard.sum().backward()
    grad_standard = inp.grad

    # Assert that gradients are the same
    torch.testing.assert_close(grad_checkpoint, grad_standard)


@pytest.mark.skipif(not fp8_available, reason=reason_for_no_fp8)
def test_linear_frozen_weights_memory_default_recipe():
    """Test that memory usage is optimized when weights are frozen for MXFP8."""
    dim = 1024
    linear = Linear(dim, dim, bias=False)
    x = torch.randn(dim, dim, requires_grad=True, device="cuda")

    # Freeze weights
    linear.weight.requires_grad = False

    # Forward and backward pass with FP8
    with autocast():
        o = linear(x)
        g_o = torch.randn_like(o)

    max_memory_before_backward = torch.cuda.max_memory_allocated()
    o.backward(g_o)
    max_memory_after_backward = torch.cuda.max_memory_allocated()

    memory_diff = (max_memory_after_backward - max_memory_before_backward) / 1e6
    assert memory_diff < 5.5, (
        f"Memory usage with frozen weights ({memory_diff}MB) should be less than 5.5MB as the"
        " grad_output should be quantized only columnwise."
    )


@pytest.mark.parametrize(
    "module_name",
    ("Linear", "LayerNormLinear", "LayerNormMLP", "GroupedLinear", "ops.Linear"),
)
@pytest.mark.parametrize(
    "quantization",
    (None, "fp8_delayed_scaling", "fp8_current_scaling", "mxfp8"),
)
def test_inference_mode(
    module_name: str,
    quantization: Optional[str],
) -> None:
    """Test heuristics for initializing quantized weights"""

    # Tensor dimensions
    sequence_length = 32
    hidden_size = 32

    # Skip invalid configurations
    if quantization in ("fp8_delayed_scaling", "fp8_current_scaling") and not fp8_available:
        pytest.skip(reason_for_no_fp8)
    if quantization == "mxfp8" and not mxfp8_available:
        pytest.skip(reason_for_no_mxfp8)

    # Construct quantization recipe
    with_quantization = quantization not in (None, "None")
    quantization_recipe = None
    if quantization == "fp8_delayed_scaling":
        quantization_recipe = recipe.DelayedScaling()
    elif quantization == "fp8_current_scaling":
        quantization_recipe = recipe.Float8CurrentScaling()
    elif quantization == "mxfp8":
        quantization_recipe = recipe.MXFP8BlockScaling()

    # Construct module
    module = None
    with torch.no_grad():
        with quantized_model_init(enabled=with_quantization, recipe=quantization_recipe):
            if module_name == "Linear":
                module = Linear(hidden_size, hidden_size)
            elif module_name == "LayerNormLinear":
                module = LayerNormLinear(hidden_size, hidden_size)
            elif module_name == "LayerNormMLP":
                module = LayerNormMLP(hidden_size, hidden_size)
            elif module_name == "GroupedLinear":
                module = GroupedLinear(1, hidden_size, hidden_size)
            elif module_name == "ops.Linear":
                module = transformer_engine.pytorch.ops.Linear(hidden_size, hidden_size)

    def check_weights():
        """Helper function to check that weight parameters have expected data"""
        for param in module.parameters():
            if isinstance(param, Float8Tensor):
                assert param._data is not None, "Missing FP8 data"
                assert (
                    param._transpose is None and param._transpose_invalid
                ), "FP8 transpose is not expected for inference"
            if isinstance(param, MXFP8Tensor):
                assert param._rowwise_data is not None, "Missing row-wise MXFP8 data"
                assert (
                    param._columnwise_data is None
                ), "Column-wise MXFP8 data is not expected for inference"

    # Check that modules have expected weights after initialization
    check_weights()

    # Check that modules have expected weights after forward pass
    with torch.inference_mode():
        x = torch.zeros(sequence_length, hidden_size, device="cuda")
        kwargs = {}
        if module_name == "GroupedLinear":
            kwargs["m_splits"] = [sequence_length]
        with autocast(enabled=with_quantization, recipe=quantization_recipe):
            y = module(x, **kwargs)
    check_weights()
