# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.

"""FP8 conversion helpers (f32<->fp8 e4m3/e5m2/e8m0, fused mul+cvt PTX wrappers) for the CuTeDSL kernels."""

import functools
import logging
from typing import Callable

import cutlass
from cutlass import cute
from cutlass import Uint8
from cutlass import Float32, Int64, Int32, Uint16, Uint32
from cutlass import Float8E5M2, Float8E8M0FNU, Float8E4M3FN
from cutlass.cutlass_dsl import BaseDSL

logger = logging.getLogger("transformer_engine.cutedsl.utils_fp8")


@cute.jit
def cvt_f32_to_fp8e8m0fnu(val: Float32) -> Float8E8M0FNU:
    """Convert float32 to fp8e8m0fnu.

    Architecture-specific Blackwell targets use the native conversion
    instruction. Older and baseline targets use the same bit-level software
    conversion as ptx::float_to_e8m0.
    """
    arch = BaseDSL._get_dsl().get_arch_enum()
    result = Uint8(0).bitcast(Float8E8M0FNU)
    # The instruction is available only in architecture-conditional or
    # family-specific Blackwell targets (sm_XXXa/sm_XXXf), not baseline ones.
    if cutlass.const_expr(arch in cutlass.Arch.BlackwellArchs() and arch.suffix in ("a", "f")):
        result = cvt_f32_to_fp8e8m0fnu_native(val)
    else:
        FP32_MANTISSA_BITS = 23
        if cute.math.isnan(val):
            result = Uint8(0xFF).bitcast(Float8E8M0FNU)
        elif cute.math.isinf(val):
            result = Uint8(0xFE).bitcast(Float8E8M0FNU)
        elif val == Float32(0.0):
            result = Uint8(0).bitcast(Float8E8M0FNU)
        else:
            val_u32 = val.bitcast(Uint32)
            exponent = (val_u32 >> Uint32(FP32_MANTISSA_BITS)) & Uint32(0xFF)
            mantissa = val_u32 & Uint32(0x7FFFFF)
            if (mantissa > Uint32(0) and exponent != Uint32(0xFE)) and not (
                exponent == Uint32(0) and mantissa <= Uint32(0x400000)
            ):
                exponent += Uint32(1)
            result = Uint8(exponent).bitcast(Float8E8M0FNU)
    return result


@cute.jit
def cvt_f32_to_fp8e8m0fnu_native(val: Float32) -> Float8E8M0FNU:
    """Native float32 -> fp8e8m0fnu conversion for Blackwell family targets.

    The x2 instruction packs the conversion of its second input into the low
    byte, so converting (0.0, val) and truncating the result extracts e8m0(val).
    """
    result_i16 = cute.arch.inline_ptx(
        "cvt.rp.satfinite.ue8m0x2.f32 {$w0}, 0f00000000, {$r0};",
        write_only_types=[Uint16],
        read_only_args=[val],
    )
    return Uint8(result_i16).bitcast(Float8E8M0FNU)


def _build_mul_f32x2_cvt_f32x4_to_fp8x4(fp8_dtype, relu: bool = False) -> Callable[..., Uint32]:
    """Build a fused 4-wide `f32x4 * f32x2 -> fp8x4` PTX wrapper.

    Multiplies four f32 inputs by a broadcast inverse scale -- an f32x2 pair (s, s),
    which the DSL transports in an Int64 register -- and converts to FP8, packing
    the four bytes into one
    uint32: byte i = fp8(v_i * s). Two `mul.f32x2` + two `cvt...x2.f32` — the
    f32-input form of this op family (CUDA ptx::mul_cvt_4x).

    mul, not fma-against-zeros. CUDA's specialized/grouped kernels use ptx::mul_cvt_4x
    (fma, so a -0 product becomes +0) while its general kernel multiplies scalars
    (keeping -0); we use mul throughout, so a -0 product keeps its sign everywhere.
    That is the one input on which these ops can disagree with CUDA, and only in the
    encoding of zero -- the value is the same.
    """
    out_op = "e5m2x2" if fp8_dtype is Float8E5M2 else "e4m3x2"
    asm = (
        "{\n"
        ".reg.b64 vp0; .reg.b64 vp1; .reg.b64 vp2; .reg.b64 vp3;\n\t"
        ".reg.b32 vs0; .reg.b32 vs1; .reg.b32 vs2; .reg.b32 vs3;\n\t"
        ".reg.b16 vo0; .reg.b16 vo1;\n\t"
        "mov.b64 vp0, {{$r0}, {$r1}};\n\t"
        "mov.b64 vp2, {{$r2}, {$r3}};\n\t"
        "mul.f32x2 vp1, vp0, {$r4};\n\t"
        "mul.f32x2 vp3, vp2, {$r4};\n\t"
        "mov.b64 {vs0, vs1}, vp1;\n\t"
        "mov.b64 {vs2, vs3}, vp3;\n\t"
        # cvt d, a, b => d[15:8]=fp8(a), d[7:0]=fp8(b); feed (hi, lo) so the low
        # byte holds the earlier element.
        f"cvt.rn.satfinite{'.relu' if relu else ''}.{out_op}.f32 vo0, vs1, vs0;\n\t"
        f"cvt.rn.satfinite{'.relu' if relu else ''}.{out_op}.f32 vo1, vs3, vs2;\n\t"
        "mov.b32 {$w0}, {vo0, vo1};\n\t"
        "}"
    )

    @cute.jit
    def fn(v0: Float32, v1: Float32, v2: Float32, v3: Float32, scale_2x: Int64) -> Uint32:
        return cute.arch.inline_ptx(
            asm,
            write_only_types=[Uint32],
            read_only_args=[v0, v1, v2, v3, scale_2x],
        )

    return fn


def mul_f32x2_cvt_f32x4_to_fp8x4(fp8_dtype, relu: bool = False) -> Callable[..., Uint32]:
    """Return the fused 4-wide f32->FP8 multiply+cast op for the given FP8 format.

    The op takes (v0, v1, v2, v3, scale_2x) and returns a uint32 of four packed
    fp8 bytes, byte i = fp8(v_i * scale). `scale_2x` is pack_f32x2(s, s)."""
    return _build_mul_f32x2_cvt_f32x4_to_fp8x4(fp8_dtype, relu)


def _build_mul_f32x4_cvt_f32x4_to_fp8x4(fp8_dtype, relu: bool = False) -> Callable[..., Uint32]:
    """Build a fused elementwise `f32x4 * f32x4 -> fp8x4` PTX wrapper.

    General elementwise multiply-and-convert: byte i = fp8(a_i * b_i). Two
    fma.rn.f32x2 against packed zeros + two cvt...x2.f32 (same sequence as
    CUDA's mul_cvt_4x(out, floatx4, floatx4) in ptx.cuh). fma (not mul) so a
    -0 product flushes to +0."""
    out_op = "e4m3x2" if fp8_dtype is Float8E4M3FN else "e5m2x2"
    asm = (
        "{\n"
        ".reg.b64 va0; .reg.b64 va1; .reg.b64 vb0; .reg.b64 vb1;\n\t"
        ".reg.b64 vr0; .reg.b64 vr1; .reg.b64 zeros;\n\t"
        ".reg.b32 vs0; .reg.b32 vs1; .reg.b32 vs2; .reg.b32 vs3;\n\t"
        ".reg.b16 vo0; .reg.b16 vo1;\n\t"
        "mov.b64 zeros, {0x0, 0x0};\n\t"
        "mov.b64 va0, {{$r0}, {$r1}};\n\t"
        "mov.b64 va1, {{$r2}, {$r3}};\n\t"
        "mov.b64 vb0, {{$r4}, {$r5}};\n\t"
        "mov.b64 vb1, {{$r6}, {$r7}};\n\t"
        "fma.rn.f32x2 vr0, va0, vb0, zeros;\n\t"
        "fma.rn.f32x2 vr1, va1, vb1, zeros;\n\t"
        "mov.b64 {vs0, vs1}, vr0;\n\t"
        "mov.b64 {vs2, vs3}, vr1;\n\t"
        # cvt d, a, b => d[15:8]=fp8(a), d[7:0]=fp8(b); feed (hi, lo) so the low
        # byte holds the earlier element.
        f"cvt.rn.satfinite{'.relu' if relu else ''}.{out_op}.f32 vo0, vs1, vs0;\n\t"
        f"cvt.rn.satfinite{'.relu' if relu else ''}.{out_op}.f32 vo1, vs3, vs2;\n\t"
        "mov.b32 {$w0}, {vo0, vo1};\n\t"
        "}"
    )

    @cute.jit
    def fn(
        a0: Float32,
        a1: Float32,
        a2: Float32,
        a3: Float32,
        b0: Float32,
        b1: Float32,
        b2: Float32,
        b3: Float32,
    ) -> Uint32:
        return cute.arch.inline_ptx(
            asm,
            write_only_types=[Uint32],
            read_only_args=[a0, a1, a2, a3, b0, b1, b2, b3],
        )

    return fn


def mul_f32x4_cvt_f32x4_to_fp8x4(fp8_dtype, relu: bool = False) -> Callable[..., Uint32]:
    """Return the fused elementwise f32x4*f32x4 -> FP8x4 op for the given FP8 format.

    The op takes (a0..a3, b0..b3) and returns a uint32 of four packed fp8
    bytes, byte i = fp8(a_i * b_i)."""
    return _build_mul_f32x4_cvt_f32x4_to_fp8x4(fp8_dtype, relu)


def _build_mul_f32x2_cvt_packed16x4_to_fp8x4(
    in_dtype, fp8_dtype, relu: bool = False
) -> Callable[..., Uint32]:
    """Build a fused `2x <in_fmt>x2 * f32x2 -> fp8x4` PTX wrapper.

    16-bit-input form of _build_mul_f32x2_cvt_f32x4_to_fp8x4: widens four packed
    bf16/f16 elements to f32 inside the asm, multiplies by the broadcast
    (s, s) pair, and converts: byte i = fp8(elt_i * s). The two u16 cvt
    results combine into the u32 via a register-pair mov (free)."""
    in_fmt = "f16" if in_dtype is cutlass.Float16 else "bf16"
    out_op = "e4m3x2" if fp8_dtype is Float8E4M3FN else "e5m2x2"
    if in_fmt == "bf16":
        # bf16 -> fp32 conversion can be performed with a bitwise permute with zeros
        vb_decl = ""
        widen = (
            "prmt.b32 v1, 0x0, {$r0}, 0x5410;\n\t"
            "prmt.b32 v2, 0x0, {$r0}, 0x7632;\n\t"
            "prmt.b32 v3, 0x0, {$r1}, 0x5410;\n\t"
            "prmt.b32 v4, 0x0, {$r1}, 0x7632;\n\t"
        )
    else:
        # fp16 -> fp32 changes exponent width and bias which can't be done by a simple bitwise permute, so it needs a real conversion.
        vb_decl = ".reg.b16 vb1; .reg.b16 vb2; .reg.b16 vb3; .reg.b16 vb4;\n\t"
        widen = (
            "mov.b32 {vb1, vb2}, {$r0};\n\t"
            "mov.b32 {vb3, vb4}, {$r1};\n\t"
            "cvt.f32.f16 v1, vb1;\n\t"
            "cvt.f32.f16 v2, vb2;\n\t"
            "cvt.f32.f16 v3, vb3;\n\t"
            "cvt.f32.f16 v4, vb4;\n\t"
        )
    asm = (
        "{\n"
        ".reg.b64 vp0; .reg.b64 vp1; .reg.b64 vq0; .reg.b64 vq1;\n\t"
        ".reg.b32 v1; .reg.b32 v2; .reg.b32 v3; .reg.b32 v4;\n\t"
        f"{vb_decl}"
        ".reg.b16 vo0; .reg.b16 vo1;\n\t"
        f"{widen}"
        "mov.b64 vp0, {v1, v2};\n\t"
        "mov.b64 vq0, {v3, v4};\n\t"
        "mul.f32x2 vp1, vp0, {$r2};\n\t"
        "mul.f32x2 vq1, vq0, {$r2};\n\t"
        "mov.b64 {v2, v1}, vp1;\n\t"
        "mov.b64 {v4, v3}, vq1;\n\t"
        # cvt d, a, b => d[15:8]=fp8(a), d[7:0]=fp8(b); feed (hi, lo) so the
        # low byte holds the earlier element.
        f"cvt.rn.satfinite{'.relu' if relu else ''}.{out_op}.f32 vo0, v1, v2;\n\t"
        f"cvt.rn.satfinite{'.relu' if relu else ''}.{out_op}.f32 vo1, v3, v4;\n\t"
        "mov.b32 {$w0}, {vo0, vo1};\n\t"
        "}"
    )

    @cute.jit
    def fn(lo_2x: Int32, hi_2x: Int32, scale_2x: Int64) -> Uint32:
        return cute.arch.inline_ptx(
            asm,
            write_only_types=[Uint32],
            read_only_args=[lo_2x, hi_2x, scale_2x],
        )

    return fn


def mul_f32x2_cvt_packed16x4_to_fp8x4(
    dtype, fp8_dtype, relu: bool = False
) -> Callable[..., Uint32]:
    """Return the fused packed16x4 * broadcast-scale -> FP8x4 op.

    The op takes (lo_2x, hi_2x, scale_2x): two i32s of packed bf16/f16 pairs
    (elements 0-1, 2-3) and a pack_f32x2(s, s) pair; returns a uint32 of four
    packed fp8 bytes, byte i = fp8(elt_i * s)."""
    return _build_mul_f32x2_cvt_packed16x4_to_fp8x4(dtype, fp8_dtype, relu)


@cute.jit
def cvt_f32x2_to_fp8e4m3x2(val_hi: Float32, val_lo: Float32, relu: bool = False) -> Uint16:
    """Convert two float32 values to two packed fp8e4m3fn bytes in one instruction.

    Returns a uint16 where bits [7:0] = fp8(val_lo), bits [15:8] = fp8(val_hi), which
    is the instruction's own result width.
    """
    return cute.arch.inline_ptx(
        f"cvt.rn.satfinite{'.relu' if relu else ''}.e4m3x2.f32 {{$w0}}, {{$r0}}, {{$r1}};",
        write_only_types=[Uint16],
        read_only_args=[val_hi, val_lo],
    )


@cute.jit
def cvt_f32x2_to_fp8e5m2x2(val_hi: Float32, val_lo: Float32, relu: bool = False) -> Uint16:
    """Convert two float32 values to two packed fp8e5m2 bytes in one instruction.

    Returns a uint16 where bits [7:0] = fp8(val_lo), bits [15:8] = fp8(val_hi), which
    is the instruction's own result width.
    """
    return cute.arch.inline_ptx(
        f"cvt.rn.satfinite{'.relu' if relu else ''}.e5m2x2.f32 {{$w0}}, {{$r0}}, {{$r1}};",
        write_only_types=[Uint16],
        read_only_args=[val_hi, val_lo],
    )


def get_cvt_f32x2_to_fp8x2_func(fp8_dtype, relu: bool = False) -> Callable[..., Uint16]:
    """Returns the float32x2 -> float8x2 conversion function for the given FP8 type.

    With `relu=True` the returned op uses `cvt.rn.satfinite.relu`, which clamps negatives to 0
    as part of the conversion, so a fused relu activation costs no extra instruction."""
    fn = cvt_f32x2_to_fp8e5m2x2 if fp8_dtype is Float8E5M2 else cvt_f32x2_to_fp8e4m3x2
    if relu:
        return functools.partial(fn, relu=True)
    return fn
