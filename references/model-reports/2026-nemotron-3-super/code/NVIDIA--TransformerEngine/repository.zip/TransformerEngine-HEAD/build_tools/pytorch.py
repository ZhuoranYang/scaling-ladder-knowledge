# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# See LICENSE for license information.

"""PyTorch related extensions."""

import os
from pathlib import Path
from importlib import metadata

import setuptools

from .utils import (
    all_files_in_dir,
    cuda_version,
    get_cuda_include_dirs,
    debug_build_enabled,
    get_bolt_build_flags,
    nccl_ep_enabled,
    setup_mpi_flags,
)
from typing import List


def install_requirements() -> List[str]:
    """Install dependencies for TE/PyTorch extensions."""
    return [
        "torch>=2.1",
        "einops",
        "onnxscript",
        "onnx",
        "packaging",
        "pydantic",
        "nvdlfw-inspect",
        "nvidia-cudnn-frontend>=1.29.0",
    ]


def test_requirements() -> List[str]:
    """Test dependencies for TE/PyTorch extensions."""
    return [
        "numpy",
        "torchvision",
        "transformers",
        "torchao==0.13",
        "onnxruntime",
        "onnxruntime_extensions",
    ]


def setup_pytorch_extension(
    csrc_source_files,
    csrc_header_files,
    common_header_files,
) -> setuptools.Extension:
    """Setup CUDA extension for PyTorch support"""

    # Source files
    sources = all_files_in_dir(Path(csrc_source_files), name_extension="cpp")

    # Header files
    include_dirs = get_cuda_include_dirs()
    include_dirs.extend(
        [
            common_header_files,
            common_header_files / "common",
            common_header_files / "common" / "include",
            csrc_header_files,
        ]
    )

    # Compiler flags
    cxx_flags = ["-O3", "-fvisibility=hidden"]
    if debug_build_enabled():
        cxx_flags.append("-g")
        cxx_flags.append("-UNDEBUG")
    else:
        cxx_flags.append("-g0")

    bolt_cxx_flags, linker_flags = get_bolt_build_flags()
    cxx_flags.extend(bolt_cxx_flags)

    # Version-dependent CUDA options
    try:
        version = cuda_version()
    except FileNotFoundError:
        print("Could not determine CUDA version")
    else:
        if version < (12, 0):
            raise RuntimeError("Transformer Engine requires CUDA 12.0 or newer")

    setup_mpi_flags(include_dirs, cxx_flags)

    # ProcessGroupNCCL class declarations are gated on USE_C10D_NCCL. get_nccl_comm_ptr
    # borrows the raw ncclComm_t from that backend and is used by both NCCL EP and the
    # cuSolverMp path, so the macro is needed regardless of the NCCL EP gate below.
    cxx_flags.append("-DUSE_C10D_NCCL")

    # Mirror the NCCL EP gate from setup.py / common CMake. When disabled, the
    # ep.cpp source no-ops at the #ifdef boundary; without the define it would
    # produce undefined references to nvte_ep_*.
    if nccl_ep_enabled():
        cxx_flags.append("-DNVTE_WITH_NCCL_EP")
        # PyTorch's symm-mem headers gate the NCCL_HAS_SYMMEM_* feature macros on
        # USE_NCCL. The EP extension shares the symm-mem NCCL comm with torch, so
        # it needs those macros visible.
        cxx_flags.append("-DUSE_NCCL")

    library_dirs = []
    libraries = []
    if bool(int(os.getenv("NVTE_ENABLE_NVSHMEM", 0))):
        assert (
            os.getenv("NVSHMEM_HOME") is not None
        ), "NVSHMEM_HOME must be set when compiling with NVTE_ENABLE_NVSHMEM=1"
        nvshmem_home = Path(os.getenv("NVSHMEM_HOME"))
        include_dirs.append(nvshmem_home / "include")
        library_dirs.append(nvshmem_home / "lib")
        libraries.append("nvshmem_host")
        cxx_flags.append("-DNVTE_ENABLE_NVSHMEM")

    if bool(int(os.getenv("NVTE_WITH_CUBLASMP", 0))):
        cxx_flags.append("-DNVTE_WITH_CUBLASMP")

    # Construct PyTorch CUDA extension
    sources = [str(path) for path in sources]
    include_dirs = [str(path) for path in include_dirs]
    from torch.utils.cpp_extension import CppExtension

    return CppExtension(
        name="transformer_engine_torch",
        sources=[str(src) for src in sources],
        include_dirs=[str(inc) for inc in include_dirs],
        extra_compile_args={"cxx": cxx_flags},
        extra_link_args=linker_flags,
        libraries=[str(lib) for lib in libraries],
        library_dirs=[str(lib_dir) for lib_dir in library_dirs],
    )
