..
    Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.

    See LICENSE for license information.

Transformer Engine documentation
=================================================

.. ifconfig:: "dev" in release

   .. warning::
      You are currently viewing unstable developer preview of the documentation.
      To see the documentation for the latest stable release, refer to:

      * `Release Notes <https://docs.nvidia.com/deeplearning/transformer-engine/release_notes.html>`_
      * `Developer Guide <https://docs.nvidia.com/deeplearning/transformer-engine/index.html>`_ (stable version of this page)

.. include:: ../README.rst
   :start-after: overview-begin-marker-do-not-remove
   :end-before: overview-end-marker-do-not-remove

.. toctree::
   :hidden:

   Home <self>

.. toctree::
   :hidden:
   :caption: Getting Started

   installation
   getting_started/index
   support_matrix
   faq
   release_notes.md

.. toctree::
   :hidden:
   :caption: Project

   project_updates
   ecosystem
   resources

.. toctree::
   :hidden:
   :caption: Python API documentation

   api/common
   api/framework


.. toctree::
   :hidden:
   :caption: Features

   features/low_precision_training/index.rst
   features/mixture_of_experts/mixture_of_experts.rst
   features/other_optimizations/index.rst


.. toctree::
   :hidden:
   :caption: Examples and Tutorials

   examples/fp8_primer.ipynb
   examples/advanced_optimizations.ipynb
   examples/te_llama/tutorial_accelerate_hf_llama_with_te.ipynb
   examples/te_gemma/tutorial_generation_gemma_with_te.ipynb
   examples/te_mixtral/tutorial_accelerate_hf_mixtral_with_te.ipynb
   examples/onnx/onnx_export.ipynb
   examples/te_jax_integration.rst
   examples/op_fuser/op_fuser.rst
   examples/gemm_profiling/gemm_profiling.rst

.. toctree::
   :hidden:
   :caption: Advanced

   api/c/index
   debug
   envvars
   examples/attention/attention.ipynb
   examples/attention/cp_ag_thd_dpa_jax_deep_dive.ipynb
