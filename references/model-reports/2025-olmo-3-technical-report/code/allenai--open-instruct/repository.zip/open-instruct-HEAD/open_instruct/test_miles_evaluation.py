"""CPU contracts for independent, lossy background evaluation."""

import asyncio
import copy
import hashlib
import importlib
import json
import subprocess
import sys
import threading
from contextlib import nullcontext
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest.mock import AsyncMock, Mock

import pytest

from open_instruct.miles.configuration.config import CoreConfig
from open_instruct.miles.configuration.run_spec import RunSpec
from open_instruct.miles.errors import InputError
from open_instruct.miles.evaluation import evaluation, evaluation_runner, evaluation_submit


@pytest.fixture
def run(tmp_path):
    return RunSpec.from_dict(
        {
            "schema_version": 1,
            "name": "eval-test",
            "model": {"source": "model", "format": "hf"},
            "output": {"root": str(tmp_path / "run")},
            "data": {"tasks": [{"task": "multiplication", "train_count": 8}]},
            "training": {"num_rollouts": 6},
            "evaluation": {
                "mode": "background",
                "interval": 2,
                "image": "01M2XGZM2N1V4DQVMYHM52KBHZ",
                "revision": "a" * 40,
                "tasks": [{"task": "gsm8k"}, {"task": "arc_easy", "interval": 3}],
            },
            "launch": {"secrets": {"WANDB_API_KEY": "main-wandb", "BEAKER_TOKEN": "submitter"}},
        }
    )


def test_grouping_and_final_deduplication(run):
    config = run.evaluation
    assert evaluation.groups(config, 1, 6) == []
    assert len(evaluation.groups(config, 6, 6)) == 1
    assert [x["task"] for x in evaluation.groups(config, 6, 6)[0]] == ["gsm8k", "arc_easy"]
    config["tasks"][1]["generation"] = {"temperature": 0.5}
    assert len(evaluation.groups(config, 6, 6)) == 2
    assert len(evaluation.groups(config, 5, 5)) == 2
    config.update(initial=False, final=False)
    assert evaluation.groups(config, 0, 6) == []
    assert evaluation.groups(config, 5, 5) == []


def test_plan_and_independent_eval_tasks(run):
    plan = run.plan()["evaluation"]
    assert [x["update"] for x in plan["milestones"]] == [0, 2, 3, 4, 6]
    assert "eval-snapshots/update-00000006/hf" in plan["milestones"][-1]["snapshot"]
    assert plan["secrets"] == {"WANDB_API_KEY": "main-wandb"}
    assert plan["mounts"] == run.launch["weka_mounts"]
    assert "eval_interval" not in run.compile().miles
    assert "eval_prompt_data" not in run.compile().miles
    assert RunSpec.from_dict(run.to_dict()).evaluation == run.evaluation


@pytest.mark.parametrize("initial", [False, True])
@pytest.mark.parametrize("final", [False, True])
def test_zero_interval_preserves_independent_endpoints(run, initial, final):
    document = run.to_dict()
    document["evaluation"].update(interval=0, initial=initial, final=final)
    for task in document["evaluation"]["tasks"]:
        task.pop("interval")
    run = RunSpec.from_dict(document)
    expected = ([0] if initial else []) + ([6] if final else [])
    assert [point["update"] for point in run.plan()["evaluation"]["milestones"]] == expected
    args = SimpleNamespace(background_evaluation=evaluation.runtime(run, run.compile().miles))
    for update in range(7):
        groups = evaluation.groups(run.evaluation, update, 6)
        assert sum(map(len, groups)) == (2 if update in expected else 0)
        assert evaluation.training_snapshot(args, update) == (
            str(evaluation.snapshot(run.output["root"], update)) if update in expected else None
        )


@pytest.mark.parametrize("global_interval, task_interval", [(0, 3), (3, 0)])
def test_task_interval_can_enable_or_disable_periodic_evaluation(run, global_interval, task_interval):
    document = run.to_dict()
    document["evaluation"]["interval"] = global_interval
    document["evaluation"]["tasks"][0].pop("interval")
    document["evaluation"]["tasks"][1]["interval"] = task_interval
    run = RunSpec.from_dict(document)
    milestones = run.plan()["evaluation"]["milestones"]
    assert [point["update"] for point in milestones] == [0, 3, 6]
    assert [task["task"] for group in milestones[1]["groups"] for task in group] == [
        "arc_easy" if task_interval else "gsm8k"
    ]
    assert all(sum(map(len, point["groups"])) == 2 for point in (milestones[0], milestones[-1]))


def test_omitted_interval_retains_default(run):
    document = run.to_dict()
    document["training"]["num_rollouts"] = 45
    document["evaluation"].pop("interval")
    for task in document["evaluation"]["tasks"]:
        task.pop("interval")
    run = RunSpec.from_dict(document)
    assert [point["update"] for point in run.plan()["evaluation"]["milestones"]] == [0, 20, 40, 45]


@pytest.mark.parametrize("value", [-1, True, None, 1.5, "0"])
@pytest.mark.parametrize("per_task", [False, True])
def test_invalid_intervals_fail_before_launch(run, value, per_task):
    document = run.to_dict()
    target = document["evaluation"]["tasks"][0] if per_task else document["evaluation"]
    target["interval"] = value
    with pytest.raises(InputError, match="interval must be a nonnegative integer"):
        RunSpec.from_dict(document)


def test_background_jobs_restart_after_preemption(run):
    receipt = {
        "evaluation": evaluation.runtime(run, run.compile().miles),
        "training": {"name": run.name},
        "tasks": run.evaluation["tasks"],
        "update": 2,
        "runner_sha256": hashlib.sha256(Path(evaluation_runner.__file__).read_bytes()).hexdigest(),
    }
    task = evaluation.specification(receipt)["tasks"][0]
    assert task["context"] == {"priority": "high", "autoResume": True}
    assert "minRuntime" not in task["context"]


@pytest.mark.parametrize(
    "patch",
    [
        {"training": {"eval_interval": 2}},
        {"miles": {"eval_num_gpus": 1}},
        {"data": {"tasks": [{"task": "multiplication", "train_count": 8, "eval_count": 1}]}},
        {"evaluation": {"mode": "background", "image": "moving-tag"}},
        {"evaluation": {"mode": "shared", "interval": 2}},
    ],
)
def test_reject_conflicts(run, patch):
    with pytest.raises(InputError):
        RunSpec.from_dict(run.to_dict() | patch)


@pytest.mark.parametrize(
    "field,value", [("interval", -1), ("gpus", True), ("submit_timeout", -1), ("revision", "main")]
)
def test_reject_invalid_config(run, field, value):
    document = run.to_dict()
    document["evaluation"][field] = value
    with pytest.raises(InputError):
        RunSpec.from_dict(document)


def coordinator(run):
    return evaluation.Coordinator(
        evaluation.runtime(run, run.compile().miles),
        {"name": run.name, "wandb": {"mode": "offline", "id": "abc", "entity": "team", "project": "test"}},
    )


def test_single_submission_resume_and_failure(run, monkeypatch):
    calls = []

    def submit(receipt, path):
        calls.append(receipt)
        receipt["status"] = "submitted"
        receipt["experiment_id"] = "experiment"
        evaluation.state.atomic_json(path, receipt)

    monkeypatch.setattr(evaluation, "submit", submit)
    first = coordinator(run)
    first.dispatch(6, "checkpoint")
    first.worker.join(2)
    first.dispatch(6, "checkpoint")
    coordinator(run).dispatch(6, "checkpoint")
    assert len(calls) == 1
    manifest = next((Path(run.output["root"]) / "evaluation").glob("update-*.json"))
    assert json.loads(manifest.read_text())["experiment_id"] == "experiment"


def test_busy_worker_drops_without_waiting(run, monkeypatch):
    entered, release = threading.Event(), threading.Event()

    def submit(*args):
        entered.set()
        release.wait(5)

    monkeypatch.setattr(evaluation, "submit", submit)
    manager = coordinator(run)
    try:
        manager.dispatch(2, "checkpoint")
        assert entered.wait(1)
        assert manager.worker.daemon
        manager.dispatch(3, "checkpoint")
        receipts = list((Path(run.output["root"]) / "evaluation").glob("update-00000003-*.json"))
        assert json.loads(receipts[0].read_text())["status"] == "skipped_busy"
    finally:
        release.set()
        manager.worker.join(2)


def test_collection_batch_submits_all_milestones_and_drops_next_busy_batch(run, monkeypatch):
    entered, release = threading.Event(), threading.Event()
    submitted = []

    def submit(receipt, path):
        submitted.append(receipt["update"])
        entered.set()
        assert release.wait(5)

    monkeypatch.setattr(evaluation, "submit", submit)
    manager = coordinator(run)
    try:
        manager.dispatch_batch([(2, "snapshot-2"), (3, "snapshot-3")])
        assert entered.wait(1)
        manager.dispatch_batch([(4, "snapshot-4"), (6, "snapshot-6")])
        receipts = [json.loads(p.read_text()) for p in (Path(run.output["root"]) / "evaluation").glob("*.json")]
        assert {r["update"]: r["status"] for r in receipts} == {
            2: "pending",
            3: "pending",
            4: "skipped_busy",
            6: "skipped_busy",
        }
    finally:
        release.set()
        manager.worker.join(2)
    assert submitted == [2, 3]
    # Neither accepted nor dropped claims are retried after a driver restart.
    coordinator(run).dispatch_batch([(2, "snapshot-2"), (3, "snapshot-3"), (4, "snapshot-4"), (6, "snapshot-6")])
    assert submitted == [2, 3]


@pytest.mark.parametrize(
    "error",
    [subprocess.TimeoutExpired("beaker", 30), subprocess.CalledProcessError(1, "beaker"), ValueError("bad JSON")],
)
def test_submission_timeout_and_failure_are_durable(run, monkeypatch, error):
    def fail(*args, **kwargs):
        assert kwargs["timeout"] == 30
        raise error

    monkeypatch.setattr(evaluation.subprocess, "run", fail)
    checkpoint_path = evaluation.snapshot(run.output["root"], 6)
    checkpoint_path.mkdir(parents=True)
    (checkpoint_path / ".complete").touch()
    manager = coordinator(run)
    manager.dispatch(6, checkpoint_path)
    manager.worker.join(2)
    receipts = [
        p
        for p in (Path(run.output["root"]) / "evaluation").glob("update-*.json")
        if not p.name.endswith("beaker.json")
    ]
    receipt = json.loads(receipts[0].read_text())
    assert receipt["status"] == "submission_failed"
    assert receipt["error"] == type(error).__name__
    coordinator(run).dispatch(6, "checkpoint")
    assert len(receipts) == 1


def test_publisher_uses_secondary_and_checkpoint_axis(tmp_path, monkeypatch):
    (tmp_path / "metrics.json").write_text(
        json.dumps({"tasks": [{"task": "gsm8k", "metrics": {"accuracy": {"exact": 0.5}}}]})
    )
    writer = Mock()
    sdk = SimpleNamespace(Api=Mock(), Settings=Mock(side_effect=lambda **kw: kw), init=Mock(return_value=writer))
    monkeypatch.setattr(evaluation_runner.importlib, "import_module", lambda name: sdk)
    receipt = {
        "update": 4,
        "group_id": "a",
        "training": {"wandb": {"id": "main", "entity": "team", "project": "p", "mode": "online"}},
    }
    evaluation_runner.publish(receipt, tmp_path)
    kwargs = sdk.init.call_args.kwargs
    assert kwargs["id"] == "main" and "config" not in kwargs and "resume" not in kwargs
    assert kwargs["settings"]["x_primary"] is False
    assert kwargs["settings"]["x_update_finish_state"] is False
    writer.log.assert_called_once_with({"eval/checkpoint_update": 4, "eval/gsm8k/accuracy/exact": 0.5})
    writer.define_metric.assert_any_call("eval/*", step_metric="eval/checkpoint_update", step_sync=False)
    writer.finish.assert_called_once()
    # Ordinary resume and an explicit publish to the same destination are no-ops.
    evaluation_runner.publish(receipt, tmp_path)
    evaluation_runner.publish(receipt, tmp_path, wandb_run="team/p/main")
    assert sdk.init.call_count == writer.log.call_count == 1
    receipt["training"]["wandb"]["mode"] = "offline"
    evaluation_runner.publish(receipt, tmp_path)
    assert json.loads((tmp_path / "publication.json").read_text())["status"] == "published"
    evaluation_runner.publish(receipt, tmp_path, wandb_run="team/p/main")
    assert sdk.init.call_count == 1
    # A deliberate change of destination still publishes.
    evaluation_runner.publish(receipt, tmp_path, wandb_run="team/p/other")
    assert sdk.init.call_count == writer.log.call_count == 2
    assert sdk.init.call_args.kwargs["id"] == "other"
    evaluation_runner.publish({**receipt, "update": 5}, tmp_path, wandb_run="team/p/other")
    assert sdk.init.call_count == writer.log.call_count == 3


@pytest.mark.parametrize("status", ["failed", "deferred"])
def test_unsuccessful_publication_can_retry(tmp_path, monkeypatch, status):
    (tmp_path / "metrics.json").write_text(
        json.dumps({"tasks": [{"task": "gsm8k", "metrics": {"accuracy": {"exact": 0.5}}}]})
    )
    (tmp_path / "publication.json").write_text(json.dumps({"status": status}))
    sdk = SimpleNamespace(Api=Mock(), Settings=Mock(), init=Mock(return_value=Mock()))
    monkeypatch.setattr(evaluation_runner.importlib, "import_module", lambda name: sdk)
    receipt = {
        "update": 4,
        "group_id": "a",
        "training": {"wandb": {"id": "main", "entity": "team", "project": "p", "mode": "online"}},
    }
    evaluation_runner.publish(receipt, tmp_path)
    sdk.init.assert_called_once()
    assert json.loads((tmp_path / "publication.json").read_text())["status"] == "published"


def test_offline_and_failed_upload_preserve_results(tmp_path, monkeypatch):
    original = '{"tasks":[]}'
    (tmp_path / "metrics.json").write_text(original)
    receipt = {"training": {"wandb": {"mode": "offline"}}}
    assert evaluation_runner.try_publish(receipt, tmp_path)
    assert json.loads((tmp_path / "publication.json").read_text())["status"] == "deferred"
    assert not evaluation_runner.try_publish(receipt, tmp_path, wandb_run="team/project/run")
    assert (tmp_path / "metrics.json").read_text() == original
    assert json.loads((tmp_path / "publication.json").read_text())["status"] == "failed"


def test_empty_provider_outputs_reject_apparently_successful_metrics(tmp_path):
    (tmp_path / "metrics.json").write_text(
        json.dumps({"tasks": [{"task": "ifeval_ood", "metrics": {"accuracy": {"exact": 0.0}}, "instances_failed": 0}]})
    )
    (tmp_path / "ifeval_ood-abc-predictions.jsonl").write_text(json.dumps({"doc_id": 0, "model_output": []}) + "\n")
    with pytest.raises(ValueError, match="Missing model outputs"):
        evaluation_runner.scores(tmp_path)


def test_prediction_validation_accepts_a_returned_empty_completion(tmp_path):
    # A real EOS-only completion is distinct from the provider returning no outputs.
    (tmp_path / "gsm8k-abc-predictions.jsonl").write_text(
        json.dumps({"doc_id": 0, "model_output": [{"text": ""}]}) + "\n"
    )
    evaluation_runner.validate_predictions(tmp_path)


def test_prediction_validation_requires_nonempty_artifacts(tmp_path):
    with pytest.raises(ValueError, match="No evaluation predictions"):
        evaluation_runner.validate_predictions(tmp_path)
    (tmp_path / "gsm8k-abc-predictions.jsonl").touch()
    with pytest.raises(ValueError, match="Empty evaluation predictions"):
        evaluation_runner.validate_predictions(tmp_path)


def test_evaluator_command_keeps_task_overrides(run):
    config = run.evaluation
    config["gpus"] = 2
    config["provider_kwargs"] = {"context_length": 34816, "disable_cuda_graph": True, "profile": "generic"}
    tasks = copy.deepcopy(config["tasks"])
    tasks[0]["generation"] = {"max_tokens": 32, "temperature": 0.0}
    tasks[0]["scoring"] = {"limit": 2}
    args = evaluation_runner.command({"checkpoint": "/frozen/hf", "tasks": tasks, "evaluation": config}, "/output")
    assert args[args.index("--model") + 1] == "/frozen/hf"
    assert "max_tokens=32" in args
    assert "limit=2" in args
    assert "--save-predictions" in args
    assert "--save-requests" in args
    assert "provider.kind=sglang" in args
    assert "provider.kwargs.model_registration=olmo_sglang:register" in args
    assert "provider.kwargs.tensor_parallel_size=2" in args
    assert "provider.kwargs.context_length=34816" in args
    assert "provider.kwargs.disable_cuda_graph=true" in args
    assert not any("vllm" in arg or "base_url" in arg for arg in args)


@pytest.mark.parametrize(
    "key", ["model_path", "tokenizer_path", "tp_size", "tensor_parallel_size", "dp_size", "model_registration"]
)
def test_evaluator_provider_cannot_override_snapshot_or_allocation(run, key):
    document = run.to_dict()
    document["evaluation"]["provider_kwargs"] = {key: "override"}
    with pytest.raises(InputError, match="cannot override"):
        RunSpec.from_dict(document)


@pytest.mark.parametrize("section", ["generation", "scoring"])
@pytest.mark.parametrize("key", ["provider.kind", "provider.kwargs.tp_size", "provider"])
def test_task_overrides_cannot_switch_evaluation_provider(run, section, key):
    document = run.to_dict()
    document["evaluation"]["tasks"][0][section] = {key: "override"}
    with pytest.raises(InputError, match="not task overrides"):
        RunSpec.from_dict(document)


def test_legacy_server_args_require_migration(run):
    document = run.to_dict()
    document["evaluation"]["server_args"] = ["--disable-cuda-graph"]
    with pytest.raises(InputError, match="replaced by provider_kwargs"):
        RunSpec.from_dict(document)


@pytest.mark.parametrize(
    "stop_mode",
    (
        "complete",
        "deadline",
        "deadline_off_cadence",
        "debug",
        "complete_endpoints",
        "deadline_endpoints",
        "debug_endpoints",
    ),
)
@pytest.mark.parametrize("initial", [False, True])
@pytest.mark.parametrize("export_hf", [None, "final-hf"])
def test_driver_never_uses_shared_evaluation_or_joins_worker(run, monkeypatch, stop_mode, initial, export_hf):
    deadline_stop = stop_mode.startswith("deadline")
    complete = stop_mode.startswith("complete")
    debug = stop_mode.startswith("debug")
    endpoints = stop_mode.endswith("endpoints")
    # Import the real driver with CPU stand-ins for the external actor runtime.
    imported = {}

    def module(name, **attrs):
        value = ModuleType(name)
        value.__dict__.update(attrs)
        monkeypatch.setitem(sys.modules, name, value)
        imported[name] = value
        return value

    manager = SimpleNamespace(get=AsyncMock(return_value={}), dispose=AsyncMock(), save=AsyncMock())
    learner = SimpleNamespace(
        update_weights=AsyncMock(),
        train=AsyncMock(),
        dispose=AsyncMock(),
        execute_workers=AsyncMock(),
        save_model=AsyncMock(),
        finalize_checkpoint=AsyncMock(),
        export_hf=AsyncMock(),
    )
    inference = SimpleNamespace(prepare_rollout=AsyncMock(), dispose=AsyncMock())
    workers = SimpleNamespace(dispose=SimpleNamespace(remote=AsyncMock()))
    placement = SimpleNamespace(
        create_rollout_components=AsyncMock(return_value=(inference, manager, 1)),
        create_training_models=AsyncMock(return_value=(learner, None)),
        update_weights=AsyncMock(),
    )
    module("ray", is_initialized=lambda: True)
    module("miles")
    module(
        "miles.ray",
        placement_group=placement,
        wiring=SimpleNamespace(launch_worker_manager=lambda *a, **kw: workers, shutdown_worker_manager=AsyncMock()),
    )
    module("miles.ray.rollout")
    shared = Mock(side_effect=AssertionError("shared evaluator must not be constructed"))
    module("miles.ray.rollout.eval_dispatch", EvalDispatcher=shared)
    module("miles.utils", object_store=SimpleNamespace(init_instance=lambda *a, **kw: None))
    module(
        "miles.utils.compiler_cache",
        startup_cache=SimpleNamespace(
            prepare=Mock(), finish=AsyncMock(), configure_specs=Mock(), publish_progress=Mock()
        ),
    )
    module("miles.utils.data", remove_rollout_data_refs=lambda *a: None)
    module("miles.utils.hf_utils.config", HF_EXPORT_COMPLETE_MARKER=".complete")
    module("miles.utils.misc", should_run_periodic_action=lambda *a: False)
    module("miles.utils.tracking_utils")
    module(
        "miles.utils.tracking_utils.tracking",
        define_step_key_metric_group=lambda *a: None,
        finish_tracking=lambda: None,
        init_tracking=lambda args: None,
    )
    module("miles.backends.core_utils.publication.rolling_publication", RollingPublication=Mock())
    # Load under a private module name so monkeypatch cleanup leaves no stale driver.
    spec = importlib.util.spec_from_file_location(
        "test_background_driver", Path(evaluation.__file__).parents[1] / "execution/driver.py"
    )
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    monkeypatch.setattr(driver, "time", SimpleNamespace(monotonic=Mock(side_effect=[0, 2])))
    monkeypatch.setattr(driver, "stage", lambda *a, **kw: nullcontext())
    monkeypatch.setattr(driver.throughput, "report", lambda *a: {"warnings": []})
    monkeypatch.setattr(driver.startup_cache, "prepare", lambda *a, **kw: None)
    monkeypatch.setattr(driver.startup_cache, "finish", AsyncMock())
    entered, release = threading.Event(), threading.Event()
    worker_threads = []

    def blocked_submit(receipt, path):
        worker_threads.append(threading.current_thread())
        entered.set()
        release.wait(5)
        raise RuntimeError("independent evaluator submission failed")

    monkeypatch.setattr(evaluation, "submit", blocked_submit)

    async def train_step(rollout_id, batch):
        for update in range(rollout_id * 4 + 1, (rollout_id + 1) * 4 + 1):
            target = evaluation.training_snapshot(args, update)
            if target:
                Path(target).mkdir(parents=True)
                (Path(target) / ".complete").touch()

    learner.train.side_effect = train_step
    args = SimpleNamespace(
        olmo_core=SimpleNamespace(
            publication_mode="barrier", diagnostic_interval=0, max_run_seconds=1 if deadline_stop else None
        ),
        background_evaluation=evaluation.runtime(run, run.compile().miles),
        fully_async=False,
        offload_rollout=False,
        check_weight_update_equal=False,
        use_wandb=False,
        wandb_team="team",
        wandb_project="test",
        wandb_mode="offline",
        start_rollout_id=0,
        num_rollout=2,
        rollout_batch_size=8,
        n_samples_per_prompt=8,
        global_batch_size=16,
        hf_checkpoint="initial",
        save_trigger_sentinel=None,
        save="native-checkpoints",
        save_interval=None,
        update_weights_interval=1,
        debug_exit_after_rollout=1 if debug else None,
    )
    args.background_evaluation.update(initial=initial, total_updates=8)
    if endpoints:
        args.background_evaluation["interval"] = 0
        for task in args.background_evaluation["tasks"]:
            task["interval"] = 0
    if stop_mode == "deadline_off_cadence":
        for task, interval in zip(args.background_evaluation["tasks"], (3, 5)):
            task["interval"] = interval
    try:
        result = asyncio.run(driver.train(args, export_hf=export_hf))
        if endpoints and debug and not initial:
            assert not worker_threads
        else:
            assert entered.wait(1)
            assert worker_threads[0].is_alive()  # train returned while submission is still blocked.
        expected = [0, 1] if complete else [0]
        assert result["completed_rollout_ids"] == expected
        assert learner.train.await_count == len(expected)
        assert result["stopped_for_time"] == deadline_stop
        if deadline_stop:
            manager.save.assert_awaited_once_with(0)
            learner.save_model.assert_awaited_once_with(0, force_sync=True)
            learner.finalize_checkpoint.assert_awaited_once_with(0)
        if stop_mode in ("deadline_off_cadence", "deadline_endpoints") and export_hf is None:
            learner.export_hf.assert_awaited_once_with(0, str(evaluation.snapshot(run.output["root"], 4)))
        elif debug or export_hf is None:
            learner.export_hf.assert_not_awaited()
        else:
            learner.export_hf.assert_awaited_once_with(expected[-1], "final-hf")
        receipts = [json.loads(p.read_text()) for p in (Path(run.output["root"]) / "evaluation").glob("*.json")]
        if endpoints:
            expected_updates = ({0} if initial else set()) | ({8} if complete else {4} if deadline_stop else set())
            assert {r["update"] for r in receipts} == expected_updates
            for receipt in receipts:
                assert receipt["status"] == ("skipped_busy" if initial and receipt["update"] else "pending")
                assert {task["task"] for task in receipt["tasks"]} == {"gsm8k", "arc_easy"}
            # No intermediate backend exports; the deadline export is requested from the actor above.
            markers = list((Path(run.output["root"]) / "eval-snapshots").glob("*/hf/.complete"))
            assert markers == ([evaluation.snapshot(run.output["root"], 8) / ".complete"] if complete else [])
        periodic = () if endpoints else (3, 4) if stop_mode == "deadline_off_cadence" else (2, 3, 4)
        for update in periodic:
            milestone = [r for r in receipts if r["update"] == update]
            assert len(milestone) == 1
            assert milestone[0]["status"] == ("skipped_busy" if initial else "pending")
        if complete and not endpoints:
            assert all(r["status"] == "skipped_busy" for r in receipts if r["update"] > 4)
            assert any(r["update"] == 8 for r in receipts)
        if deadline_stop:
            final = [r for r in receipts if r["update"] == 4]
            assert len(final) == 1
            assert final[0]["checkpoint"] == (export_hf or str(evaluation.snapshot(run.output["root"], 4)))
            assert {t["task"] for t in final[0]["tasks"]} == {"gsm8k", "arc_easy"}
        shared.assert_not_called()
    finally:
        release.set()
        for thread in worker_threads:
            thread.join(2)


@pytest.mark.parametrize("value", (0, -1, True, float("inf"), float("nan")))
def test_wall_clock_budget_must_be_finite_and_positive(value):
    with pytest.raises(InputError):
        CoreConfig(max_run_seconds=value)


def test_incomplete_snapshot_never_submitted(run, monkeypatch):
    network = Mock()
    monkeypatch.setattr(evaluation.subprocess, "run", network)
    manager = coordinator(run)
    manager.dispatch(6, evaluation.snapshot(run.output["root"], 6))
    manager.worker.join(2)
    network.assert_not_called()
    receipt = next((Path(run.output["root"]) / "evaluation").glob("update-*.json"))
    assert json.loads(receipt.read_text())["status"] == "submission_failed"


def test_submitter_reads_nested_beaker_workload_id(monkeypatch, capsys):
    client = SimpleNamespace(
        experiment=SimpleNamespace(
            create=Mock(return_value=SimpleNamespace(experiment=SimpleNamespace(id="accepted-experiment")))
        )
    )
    monkeypatch.setattr(evaluation_submit, "Beaker", SimpleNamespace(from_env=lambda **kwargs: nullcontext(client)))
    monkeypatch.setattr(evaluation_submit.signal, "alarm", Mock())
    monkeypatch.setattr(sys, "argv", ["submit", "spec.json", "ai2/workspace", "unique-name", "30"])
    evaluation_submit.main()
    assert json.loads(capsys.readouterr().out) == {"id": "accepted-experiment"}
    client.experiment.create.assert_called_once_with(spec="spec.json", name="unique-name")
    evaluation_submit.signal.alarm.assert_called_once_with(30)


def test_submission_diagnostics_redact_credentials(monkeypatch):
    monkeypatch.setenv("BEAKER_TOKEN", "sensitive-test-token")
    monkeypatch.setenv("WANDB_API_KEY", "sensitive-test-key")
    result = evaluation_submit.diagnostic(
        ValueError("rejected sensitive-test-token sensitive-test-key Bearer unknown-credential")
    )
    assert result["error"] == "ValueError"
    assert result["message"] == "rejected [REDACTED] [REDACTED] Bearer [REDACTED]"


def test_all_writers_define_training_and_background_axes():
    run = Mock()
    evaluation_runner.define_metrics(run)
    calls = run.define_metric.call_args_list
    groups = {call.args[0]: call.kwargs for call in calls if call.args[0].endswith("/*")}
    assert groups == {
        "train/*": {"step_metric": "train/step", "step_sync": True},
        "rollout/*": {"step_metric": "rollout/step", "step_sync": True},
        "multi_turn/*": {"step_metric": "rollout/step", "step_sync": True},
        "passrate/*": {"step_metric": "rollout/step", "step_sync": True},
        "perf/*": {"step_metric": "rollout/step", "step_sync": True},
        "eval/*": {"step_metric": "eval/checkpoint_update", "step_sync": False},
    }
