"""Coordinate rollout collection, Core optimizer updates and policy publication for
one training attempt. The driver connects MILES actors to Open Instruct rewards,
records and evaluation, and places checkpoint and shutdown boundaries around work
that must be recoverable. It supports barrier, refresh and engine-drain publication
while leaving model execution and weight transport to the pinned runtime.
"""

import os
import time
from functools import partial
from pathlib import Path

import ray
import wandb
from miles.backends.core_utils.publication.rolling_publication import RollingPublication
from miles.ray import placement_group, wiring
from miles.ray.rollout.eval_dispatch import EvalDispatcher
from miles.utils import object_store
from miles.utils.compiler_cache import startup_cache
from miles.utils.data import remove_rollout_data_refs
from miles.utils.hf_utils.config import HF_EXPORT_COMPLETE_MARKER
from miles.utils.misc import should_run_periodic_action
from miles.utils.tracking_utils.tracking import define_step_key_metric_group, finish_tracking, init_tracking

from open_instruct import logger_utils
from open_instruct.miles.configuration import throughput
from open_instruct.miles.evaluation import evaluation as background_eval
from open_instruct.miles.execution import serving
from open_instruct.miles.execution.timing import evaluation_stage, stage
from open_instruct.miles.infrastructure import infra_timeouts

logger = logger_utils.setup_logger(__name__)


async def train(args, *, export_hf=None):
    if getattr(args, "cluster_backend", "ray") != "ray":
        raise ValueError("Core currently requires the Ray cluster backend")
    budget = getattr(args.olmo_core, "max_run_seconds", None)
    deadline = time.monotonic() + budget if budget is not None else None
    stopped_for_time = False
    for warning in throughput.report(vars(args), args.olmo_core)["warnings"]:
        logger.warning("Throughput [%s]: %s", warning["code"], warning["message"])
    with stage(args, "startup_cache_prepare"):
        startup_cache.prepare(args, application_root=Path(__file__).resolve().parents[3])
    worker_manager = None
    manager = None
    inference = None
    learner = None
    failure = None
    completed = []
    rolling = None
    refresh = args.olmo_core.publication_mode == "refresh"
    try:
        # Start local Ray before W&B creates WANDB_SERVICE. Otherwise raylet
        # inherits the driver's service connection, and offline worker writers
        # collide with the primary run. Preserve an already connected cluster.
        if not ray.is_initialized():
            ray.init(address=os.environ.get("RAY_ADDRESS") or "local")
        # Tracking assigns the run ID before Miles serializes args into worker
        # specs. Later mutations in the driver cannot reach those worker copies.
        init_tracking(args)
        define_step_key_metric_group("errors", "errors/elapsed_seconds")
        with stage(args, "placement"):
            worker_manager = wiring.launch_worker_manager(args, transform_specs=partial(serving.configure_specs, args))
        object_store.init_instance(args, contribute_segment=False)
        with stage(args, "serving_startup"):
            inference, manager, rollouts_per_epoch = await placement_group.create_rollout_components(args)
        with stage(args, "trainer_startup"):
            learner, _ = await placement_group.create_training_models(args, manager)

        async def publish(rollout_id=None):
            # Refresh safety belongs to the engine pause/update/resume boundary.
            # Producer admission acknowledgments can queue behind response work;
            # existing requests already cross publication without this group gate.
            if args.fully_async and not refresh:
                await manager.core_publication_boundary(True)
            if args.offload_rollout:
                await inference.onload_weights()
            await infra_timeouts.wait_for(
                placement_group.update_weights(args, learner, manager, inference, rollout_id=rollout_id),
                timeout=args.olmo_core.engine_update_timeout if refresh else None,
                operation="Core weight publication",
            )
            interval = args.olmo_core.diagnostic_interval
            fresh_initial = rollout_id is None and args.start_rollout_id == 0
            diagnostic = interval > 0 and (rollout_id is None or (rollout_id + 1) % interval == 0)
            if args.check_weight_update_equal and (rollout_id is None or diagnostic):
                if not fresh_initial:
                    # The startup snapshot is the original HF checkpoint. It
                    # cannot validate trained/restored weights. Instead measure
                    # an exact current-state publication round trip, including
                    # reset so an omitted tensor cannot pass as unchanged.
                    await inference.check_weights(action="snapshot", selector=args.check_weight_update_selector)
                    await inference.check_weights(
                        action="reset_tensors",
                        selector=args.check_weight_update_selector,
                        skip_list=args.check_weight_update_skip_list,
                    )
                    await infra_timeouts.wait_for(
                        placement_group.update_weights(args, learner, manager, inference, rollout_id=rollout_id),
                        timeout=args.olmo_core.engine_update_timeout if refresh else None,
                        operation="Core weight publication",
                    )
                await inference.check_weights(
                    action="compare",
                    allow_quant_error=args.check_weight_update_allow_quant_error,
                    selector=args.check_weight_update_selector,
                    skip_list=args.check_weight_update_skip_list,
                )
            if args.offload_rollout:
                await inference.onload_kv()
            if args.fully_async and not refresh:
                await manager.core_publication_boundary(False)

        with stage(args, "initial_publication"):
            await publish()
        if args.olmo_core.publication_mode == "engine_drain":
            rolling = RollingPublication(args, learner, manager, inference)
            with stage(args, "engine_drain_startup"):
                await rolling.initialize()
        background = getattr(args, "background_evaluation", None)
        evaluation = None if background else EvalDispatcher(args, learner, manager)
        coordinator = None
        collection_snapshots = []
        if background:
            tracking = {
                "id": getattr(args, "wandb_run_id", None),
                "entity": args.wandb_team,
                "project": args.wandb_project,
                "mode": args.wandb_mode,
            }
            if args.use_wandb and wandb.run is not None:
                tracking.update(
                    id=wandb.run.id,
                    entity=wandb.run.entity,
                    project=wandb.run.project,
                    mode="offline" if wandb.run.settings.mode in {"offline", "dryrun"} else "online",
                )
            coordinator = background_eval.Coordinator(
                background,
                {
                    "name": background["name"],
                    "root": background["root"],
                    "wandb": tracking,
                    "beaker_experiment_id": os.environ.get("BEAKER_EXPERIMENT_ID"),
                },
            )
            if args.start_rollout_id == 0 and background["initial"]:
                coordinator.dispatch(0, args.hf_checkpoint)
        if (
            evaluation is not None
            and args.eval_interval is not None
            and not args.skip_eval_before_train
            and args.start_rollout_id == 0
        ):
            with evaluation_stage(args, args.start_rollout_id, initial=True):
                await evaluation.dispatch(args.start_rollout_id, hf_dir=args.hf_checkpoint)
        for rollout_id in range(args.start_rollout_id, args.num_rollout):
            # In async mode the managed producer fills the bounded queue while
            # learning runs; dequeue happens only after the preceding publication.
            with stage(args, "generation_wait", rollout_id):
                if rolling is None:
                    await inference.prepare_rollout(rollout_id)
                batch = await manager.get(rollout_id)
            if args.offload_rollout:
                await inference.offload()
            try:
                with stage(args, "training", rollout_id):
                    await learner.train(rollout_id, batch)
                completed.append(rollout_id)
                # Persist newly compiled kernels even when model checkpointing is
                # disabled. This schedules bounded background CPU work, not a save.
                startup_cache.publish_progress(args, rollout_id)
                if coordinator is not None and background is not None:
                    collection_snapshots = []
                    per_collection = args.rollout_batch_size * args.n_samples_per_prompt // args.global_batch_size
                    for update in range(rollout_id * per_collection + 1, (rollout_id + 1) * per_collection + 1):
                        target = background_eval.snapshot(background["root"], update)
                        if (target / HF_EXPORT_COMPLETE_MARKER).is_file():
                            collection_snapshots.append((update, target))
                if rolling is not None:
                    await rolling.optimizer_step_completed()
            finally:
                remove_rollout_data_refs(args, batch)
            if rolling is not None:
                # Publish the completed optimizer version before the next collection.
                with stage(args, "publication", rollout_id):
                    await rolling.publish()
            if refresh:
                with stage(args, "publication", rollout_id):
                    await publish(rollout_id)
            sentinel = args.save_trigger_sentinel and os.path.exists(args.save_trigger_sentinel)
            stopped_for_time = deadline is not None and time.monotonic() >= deadline
            if (
                (stopped_for_time and getattr(args, "save", None))
                or sentinel
                or should_run_periodic_action(rollout_id, args.save_interval, rollouts_per_epoch, args.num_rollout)
            ):
                # The async data source snapshots its cursor and pristine pending
                # prompt ledger under one lock. Completed-but-unused and in-flight
                # groups regenerate on resume; live inference need not finish or
                # pause. No new training batch is consumed until this save commits.
                with stage(args, "checkpoint", rollout_id):
                    await manager.save(rollout_id)
                    await learner.save_model(rollout_id, force_sync=True)
                    await learner.finalize_checkpoint(rollout_id)
                if sentinel:
                    os.remove(args.save_trigger_sentinel)
            if rolling is None and not refresh and (rollout_id + 1) % args.update_weights_interval == 0:
                with stage(args, "publication", rollout_id):
                    await publish(rollout_id)
            if evaluation is not None and should_run_periodic_action(
                rollout_id, args.eval_interval, rollouts_per_epoch, args.num_rollout
            ):
                with evaluation_stage(args, rollout_id):
                    await evaluation.dispatch(rollout_id, force=rollout_id == args.num_rollout - 1)
            if stopped_for_time:
                logger.info("Graceful wall-clock stop after completed rollout %s (budget=%ss)", rollout_id, budget)
            if coordinator is not None and background is not None and not (stopped_for_time and background["final"]):
                coordinator.dispatch_batch(collection_snapshots)
                collection_snapshots = []
            if stopped_for_time:
                break
            if (
                args.debug_exit_after_rollout is not None
                and rollout_id - args.start_rollout_id + 1 >= args.debug_exit_after_rollout
            ):
                break
        if evaluation is not None:
            await evaluation.drain()
        # A deliberate debug stop leaves a resumable workflow, not a final export.
        # Otherwise the first process creates the final directory and the resumed
        # process cannot export its newer weights there (the exporter is exclusive).
        reached_end = (completed[-1] + 1 if completed else args.start_rollout_id) == args.num_rollout
        if export_hf is not None and (reached_end or stopped_for_time):
            if args.fully_async:
                await manager.core_publication_boundary(True)
            with stage(args, "final_hf_export"):
                await learner.export_hf(completed[-1] if completed else args.start_rollout_id - 1, export_hf)
        if stopped_for_time and coordinator is not None and background is not None and background["final"]:
            last = completed[-1]
            update = (last + 1) * args.rollout_batch_size * args.n_samples_per_prompt // args.global_batch_size
            target = export_hf or str(background_eval.snapshot(background["root"], update))
            if (
                export_hf is None
                and not (background_eval.snapshot(background["root"], update) / HF_EXPORT_COMPLETE_MARKER).is_file()
            ):
                with stage(args, "final_evaluation_export"):
                    await learner.export_hf(last, target)
            # Merge the periodic and final task sets at this update before claiming receipts.
            collection_snapshots = [(step, path) for step, path in collection_snapshots if step != update]
            collection_snapshots.append((update, target))
            coordinator.dispatch_batch(collection_snapshots, final=True)
    except BaseException as error:
        failure = error
        raise
    finally:
        cleanup_error = None
        if rolling is not None:
            try:
                await rolling.close(failed=failure is not None)
            except BaseException as error:
                cleanup_error = error
                logger.exception("Engine drain cleanup failed")
        for component, operation, timeout, cleanup_stage in (
            # Async generation must stop, but the servers must remain alive while
            # both sides collectively destroy the weight-update NCCL group.
            (
                manager if args.fully_async else None,
                # A failed refresh can leave engines paused or partly updated.
                # Cancel owned work instead of waiting for it to generate more.
                lambda: manager.core_publication_boundary(
                    True, **({"abort": True} if refresh and failure is not None else {})
                ),
                (
                    args.olmo_core.engine_drain_timeout + args.olmo_core.engine_update_timeout
                    if rolling or refresh
                    else 60
                ),
                "final_generation_drain",
            ),
            (learner, lambda: learner.execute_workers("close_weight_transport"), 60, "close_weight_transport"),
            (manager, lambda: manager.dispose(), 120, "rollout_dispose"),
            (learner, lambda: learner.dispose(), 60, "trainer_dispose"),
            (inference, lambda: inference.dispose(), 60, "inference_dispose"),
            (worker_manager, lambda: wiring.shutdown_worker_manager(worker_manager), 120, "worker_dispose"),
        ):
            if component is None:
                continue
            try:
                with stage(args, cleanup_stage):
                    await infra_timeouts.wait_for(operation(), timeout=timeout, operation=cleanup_stage)
            except BaseException as error:
                cleanup_error = cleanup_error or error
                logger.exception("Core RL cleanup %s failed (deadline=%ss)", cleanup_stage, timeout)
        try:
            await startup_cache.finish(args, success=failure is None and cleanup_error is None)
        except Exception:
            logger.exception("Optional compiler-cache finalization failed")
        try:
            # The pinned Miles finish_tracking() has no exit-code parameter.
            # Finish W&B's run explicitly on failure before generic backend teardown.
            if (failure is not None or cleanup_error is not None) and wandb.run is not None:
                wandb.run.finish(exit_code=1)
        except Exception:
            logger.exception("Failed to mark W&B run as failed")
        finally:
            finish_tracking()
        if failure is None and cleanup_error is not None:
            raise cleanup_error
    return {
        "completed_rollout_ids": completed,
        "start_rollout_id": args.start_rollout_id,
        "export_hf": export_hf,
        "stopped_for_time": stopped_for_time,
    }
