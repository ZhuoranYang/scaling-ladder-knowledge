"""
DPO training using OLMo-core's Trainer.

This module provides DPO (Direct Preference Optimization) training using
OLMo-core's native training infrastructure.
"""

import os
import pathlib
import shutil
from typing import Any

import torch
import torch.distributed as dist
import transformers
from olmo_core import optim as olmo_optim
from olmo_core import train
from olmo_core.config import DType
from olmo_core.distributed import utils as distributed_utils
from olmo_core.distributed.parallel import DataParallelType
from olmo_core.train import callbacks
from olmo_core.train.callbacks import ProfilerCallback
from olmo_core.train.train_module.transformer import config as transformer_config

from open_instruct import data_loader as data_loader_lib
from open_instruct import (
    dataset_transformation,
    dpo_utils,
    logger_utils,
    model_utils,
    olmo_core_train_modules,
    olmo_core_utils,
    utils,
)
from open_instruct.olmo_core_callbacks import PerfCallback
from open_instruct.padding_free_collator import TensorDataCollatorWithFlatteningDPO

logger = logger_utils.setup_logger(__name__)


def export_to_hf(
    model: torch.nn.Module,
    tokenizer: transformers.PreTrainedTokenizerBase,
    save_dir: str,
    original_model_name_or_path: str,
    is_main_process: bool,
):
    """Export an FSDP-wrapped model to HuggingFace format.

    All ranks must call this function as state_dict() and full_tensor() are collective operations.
    Only the main process saves to disk.
    """
    logger.info("Gathering FSDP state dict...")
    state_dict = model.state_dict()
    state_dict = {k: v.full_tensor().cpu() if hasattr(v, "full_tensor") else v.cpu() for k, v in state_dict.items()}

    if is_main_process:
        logger.info(f"Exporting model to HuggingFace format at {save_dir}")
        olmo_core_utils.save_state_dict_as_hf(state_dict, save_dir, original_model_name_or_path, tokenizer)


def _setup_callbacks(args: dpo_utils.DPOExperimentConfig, dp_world_size: int):
    """Return callbacks dict."""
    json_config = dpo_utils.config_to_json_serializable(vars(args))
    run_name = args.run_name or args.exp_name
    trainer_callbacks: dict[str, callbacks.Callback] = olmo_core_utils.build_base_callbacks(
        config_dict=json_config,
        run_name=run_name,
        checkpointing_steps=args.checkpointing_steps,
        ephemeral_save_interval=args.ephemeral_save_interval,
        with_tracking=args.with_tracking,
        wandb_project=args.wandb_project,
        wandb_entity=args.wandb_entity,
        save_async=False,
        max_checkpoints=args.keep_last_n_checkpoints,
    )
    slack_webhook_url = os.environ.get("SLACK_WEBHOOK_URL")
    if args.send_slack_alerts and slack_webhook_url:
        trainer_callbacks["slack"] = callbacks.SlackNotifierCallback(name=run_name, webhook_url=slack_webhook_url)
    model_dims = utils.ModelDims.from_hf_config(args.model_name_or_path)
    trainer_callbacks["perf"] = PerfCallback(
        model_dims=model_dims,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        dp_world_size=dp_world_size,
        tensor_parallel_degree=args.tensor_parallel_degree,
    )
    if args.profiling:
        trainer_callbacks["profiler"] = ProfilerCallback(
            skip_first=5, wait=1, warmup=2, active=3, repeat=1, profile_memory=True
        )
    return trainer_callbacks


def _handle_post_training(
    args: dpo_utils.DPOExperimentConfig, model, tokenizer, trainer_callbacks, beaker_config, is_main_process: bool
):
    """Save HF model, copy to beaker, launch evals, push to hub."""
    hf_model_path = os.path.join(args.output_dir, "hf_model")
    export_to_hf(model, tokenizer, hf_model_path, args.model_name_or_path, is_main_process)

    if distributed_utils.is_distributed():
        dist.barrier()

    output_path = pathlib.Path(args.output_dir).resolve()
    beaker_output_path = pathlib.Path("/output").resolve()
    if (
        args.try_auto_save_to_beaker
        and is_main_process
        and utils.is_beaker_job()
        and beaker_config is not None
        and len(beaker_config.beaker_dataset_id_urls) > 0
        and output_path != beaker_output_path
    ):
        shutil.copytree(hf_model_path, "/output", dirs_exist_ok=True)

    if utils.is_beaker_job() and is_main_process and args.try_launch_beaker_eval_jobs:
        wandb_url = None
        if args.with_tracking:
            wandb_tracker = trainer_callbacks.get("wandb")
            if wandb_tracker is not None and hasattr(wandb_tracker, "run") and wandb_tracker.run is not None:
                wandb_url = wandb_tracker.run.get_url()
        if args.hf_repo_revision is not None:
            eval_path = hf_model_path
            if beaker_config is not None and beaker_config.beaker_dataset_ids:
                eval_path = beaker_config.beaker_dataset_ids[-1]
            utils.launch_ai2_evals_on_weka(
                path=eval_path,
                leaderboard_name=args.hf_repo_revision,
                oe_eval_max_length=args.oe_eval_max_length,
                wandb_url=wandb_url,
                oe_eval_tasks=args.oe_eval_tasks,
                eval_workspace=args.eval_workspace,
                eval_priority=args.eval_priority,
                oe_eval_gpu_multiplier=args.oe_eval_gpu_multiplier,
            )

    if args.push_to_hub and is_main_process:
        model_utils.push_folder_to_hub(hf_model_path, args.hf_repo_id, args.hf_repo_revision)


def main(args: dpo_utils.DPOExperimentConfig, tc: dataset_transformation.TokenizerConfig) -> None:
    """Main entry point for DPO training with OLMo-core."""
    if args.use_lora:
        raise ValueError("LoRA is not supported with OLMo-core DPO training. Use dpo_tune_cache.py instead.")

    if args.context_parallel_degree > 1:
        raise NotImplementedError(
            "Context parallelism is not supported with DPO (requires batch_shard_by_document integration)."
        )

    if args.dpo_use_paged_optimizer:
        raise ValueError("dpo_use_paged_optimizer is not supported with OLMo-core DPO training.")

    if args.use_8bit_optimizer:
        raise ValueError("use_8bit_optimizer is not supported with OLMo-core DPO training.")

    # DPO's DPOExperimentConfig uses inheritance, not composition, so args satisfies both
    # ModelConfig and DatasetConfig. TODO(finbarrtimbers): refactor to use composition.
    tokenizer = olmo_core_utils.setup_tokenizer_and_cache(args, args, tc)

    transform_fn_args = [{"max_seq_length": args.max_seq_length}, {}]
    ref_cache_hash = dpo_utils.compute_reference_cache_hash(args, tc)
    reference_cache_path = pathlib.Path(dpo_utils.REFERENCE_LOGPROBS_CACHE_PATH) / f"{ref_cache_hash}.pt"
    logger.info(f"Reference logprobs cache path: {reference_cache_path}")

    if args.cache_dataset_only:
        olmo_core_utils.load_dataset_distributed(args, tc, transform_fn_args, is_main_process=True)
        logger.info("Dataset cached successfully. Exiting because --cache_dataset_only was set.")
        return

    global_rank, world_size, is_main_process = olmo_core_utils.setup_distributed_env(seed=args.seed)
    tp_degree = args.tensor_parallel_degree
    dp_rank = global_rank // tp_degree
    dp_world_size = world_size // tp_degree

    dataset = olmo_core_utils.load_dataset_distributed(args, tc, transform_fn_args, is_main_process)
    dataset = dataset.shuffle(seed=args.seed)
    # After the shuffle so a subset is a random sample, and before the reference-logprob
    # pass, whose cache hash covers max_train_samples (and, for subsets, the seed).
    if args.max_train_samples is not None and args.max_train_samples < len(dataset):
        logger.info(f"Limiting training samples to {args.max_train_samples} from {len(dataset)}.")
        dataset = dataset.select(range(args.max_train_samples))
        # Reindex densely: the reference cache is allocated at subset size and scattered
        # by this column, so retained pre-shuffle indices would run out of bounds.
        dataset = dataset.remove_columns("index").add_column("index", range(len(dataset)))
    dataset.set_format(type="pt")

    beaker_config = utils.setup_experiment_paths(args, is_main_process)

    if is_main_process:
        os.makedirs(args.output_dir, exist_ok=True)
    if distributed_utils.is_distributed():
        dist.barrier()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model, model_config = olmo_core_utils.setup_model(args)
    if is_main_process:
        olmo_core_utils.verify_can_save_as_hf(model_config, args.model_name_or_path)

    if args.packing:
        logger.info("Using packing/padding-free collation")
        collator = TensorDataCollatorWithFlatteningDPO(
            return_position_ids=True, return_flash_attn_kwargs=True, max_seq_length=args.max_seq_length
        )
    else:
        collator = dpo_utils.DataCollatorForSeq2SeqDPO(tokenizer=tokenizer, model=None, padding="longest")

    rank_batch_size = args.per_device_train_batch_size * args.gradient_accumulation_steps
    global_batch_size = rank_batch_size * dp_world_size
    data_loader = data_loader_lib.HFDataLoader(
        dataset=dataset,
        batch_size=global_batch_size,
        seed=args.seed,
        dp_rank=dp_rank,
        dp_world_size=dp_world_size,
        work_dir=args.output_dir,
        collator=collator,
        device=device,
        drop_last=True,
        fs_local_rank=global_rank,
    )
    # 4x batch size: forward-only (no backward), so no activation storage needed.
    # With packing, the collator's token budget controls the actual forward-pass size
    # and the overflow mechanism in HFDataLoader ensures no examples are dropped.
    # We could probably have logic to use a longer sequence length here when packing
    # is enabled, but for simplicity we just keep the 4x increase in batch size regardless of packing.
    # We want the batch size to be as large as possible so that we always pack efficiently.
    cache_batch_size = int(args.per_device_train_batch_size * 4 * dp_world_size)
    cache_data_loader = data_loader_lib.HFDataLoader(
        dataset=dataset,
        batch_size=cache_batch_size,
        seed=args.seed,
        dp_rank=dp_rank,
        dp_world_size=dp_world_size,
        work_dir=args.output_dir,
        collator=collator,
        device=device,
        # We need to process every example to cache reference logprobs, so we can't drop the last batch.
        drop_last=False,
        fs_local_rank=global_rank,
    )

    forward_fn = dpo_utils.concatenated_forward_olmo if args.concatenated_forward else dpo_utils.separate_forward_olmo
    forward_kwargs: dict[str, Any] = {}
    if args.packing:
        forward_kwargs["packing"] = True
    average_log_prob = args.loss_type.is_average_loss

    cache_kwargs = dict(
        dataloader=cache_data_loader,
        average_log_prob=average_log_prob,
        forward_fn=forward_fn,
        forward_kwargs=forward_kwargs,
        full_dataset_size=len(dataset),
        device=device,
        cache_path=reference_cache_path,
        is_main_process=is_main_process,
        model_dims=utils.ModelDims.from_hf_config(args.model_name_or_path),
        use_lora=False,
        disable_adapter_context=None,
    )

    data_loader.reshuffle(epoch=0)
    num_training_steps = len(data_loader) * args.num_epochs
    effective_steps = args.max_train_steps if args.max_train_steps is not None else num_training_steps
    if args.optimizer_type == "muon":
        optim_config = olmo_optim.MuonConfig(
            lr=args.learning_rate, weight_decay=args.weight_decay, **(args.optimizer_kwargs or {})
        )
    elif args.optimizer_type == "adamw":
        optim_config = olmo_optim.AdamWConfig(
            lr=args.learning_rate, weight_decay=args.weight_decay, fused=args.fused_optimizer
        )
    else:
        raise ValueError(f"Unknown optimizer_type: {args.optimizer_type!r}. Must be 'adamw' or 'muon'.")
    scheduler = olmo_core_utils.build_scheduler(args.lr_scheduler_type, args.warmup_ratio, effective_steps)
    dp_config = transformer_config.TransformerDataParallelConfig(
        name=DataParallelType.hsdp,
        num_replicas=args.fsdp_num_replicas,
        shard_degree=args.fsdp_shard_degree,
        param_dtype=DType.bfloat16,
        reduce_dtype=DType.float32,
        wrapping_strategy=transformer_config.TransformerDataParallelWrappingStrategy.blocks,
    )
    ac_config = olmo_core_utils.build_ac_config(
        args.activation_memory_budget,
        args.compile_model,
        args.activation_checkpointing_mode,
        args.activation_checkpointing_modules,
    )

    train_module = olmo_core_train_modules.DPOTrainModule(
        model=model,
        optim=optim_config,
        sample_microbatch_size=args.per_device_train_batch_size,
        max_sequence_length=args.max_seq_length,
        dpo_config=args,
        attn_implementation=args.attn_implementation,
        dp_config=dp_config,
        # Passing degree=1 is functionally correct but adds DTensor overhead with no benefit,
        # as apply_tp would wrap all layers unnecessarily. Pass None to skip TP entirely.
        tp_config=(
            transformer_config.TransformerTensorParallelConfig(degree=args.tensor_parallel_degree)
            if args.tensor_parallel_degree > 1
            else None
        ),
        ac_config=ac_config,
        compile_model=args.compile_model,
        max_grad_norm=args.max_grad_norm,
        scheduler=scheduler,
        device=device,
    )

    olmo_core_utils.reload_hf_checkpoint_after_parallelization(train_module, args.model_name_or_path, args.output_dir)

    logger.info("Caching reference logprobs...")
    train_module.reference_cache = dpo_utils.build_reference_logprobs_cache(model=train_module.model, **cache_kwargs)

    if args.cache_logprobs_only:
        logger.info("--cache_logprobs_only set, exiting after cache build.")
        if dist.is_initialized():
            dist.barrier()
            dist.destroy_process_group()
        return

    trainer_callbacks = _setup_callbacks(args, dp_world_size)

    if args.max_train_steps is not None:
        max_duration = train.Duration.steps(args.max_train_steps)
    else:
        max_duration = train.Duration.steps(num_training_steps)

    trainer = train.TrainerConfig(
        save_folder=args.output_dir,
        max_duration=max_duration,
        metrics_collect_interval=args.logging_steps,
        callbacks=trainer_callbacks,
        save_overwrite=True,
    ).build(train_module, data_loader)

    trainer.epoch = 0

    logger.info("Starting training...")
    trainer.fit()
    logger.info("Training complete.")

    _handle_post_training(args, train_module.model, tokenizer, trainer_callbacks, beaker_config, is_main_process)

    train.teardown_training_environment()


if __name__ == "__main__":
    from open_instruct.utils import ArgumentParserPlus

    parser = ArgumentParserPlus((dpo_utils.DPOExperimentConfig, dataset_transformation.TokenizerConfig))
    args, tc = parser.parse()
    main(args, tc)
