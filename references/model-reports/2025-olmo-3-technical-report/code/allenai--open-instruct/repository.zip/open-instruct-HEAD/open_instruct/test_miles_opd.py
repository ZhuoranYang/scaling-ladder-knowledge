"""CPU checks for OPD configuration and allocation boundaries."""

import asyncio
import contextlib
import copy
import importlib.util
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import pytest

from open_instruct.miles.configuration import options, specs
from open_instruct.miles.distillation import opd_config, opd_launch, opd_prepare, opd_retention, opd_runtime
from open_instruct.miles.distillation import opd_rewards as rewards
from open_instruct.miles.errors import InputError
from open_instruct.miles.execution import cluster, launch, workflow

CONFIG = Path(__file__).resolve().parents[1] / "tests/miles/fixtures/opd/qwen35-4b-tiny.toml"
PREPARED = {
    "model": "/assets/Qwen3.5-4B-851bf6e806ef",
    "teacher": "/assets/Qwen3.5-9B-c20223623576",
    "data": {"prompt_data": "/assets/data/train.jsonl", "eval_prompt_data": ["gsm8k", "/assets/data/eval.jsonl"]},
}


def native(spec):
    arguments = opd_runtime.native_arguments(spec, PREPARED, "/assets/ckpt", "http://127.0.0.1:1/generate", [])
    values = {}
    flags = set()
    index = 0
    while index < len(arguments):
        key = arguments[index]
        if index + 1 < len(arguments) and not arguments[index + 1].startswith("--"):
            values.setdefault(key, arguments[index + 1])
            index += 2
        else:
            flags.add(key)
            index += 1
    return values, flags


def test_opd_dispatch_and_gpu_isolation():
    spec = specs.load(CONFIG)
    assert isinstance(spec, opd_config.OPDRunSpec)
    assert spec.allocation()["roles"] == {"trainer": [0, 1], "student": [2], "teacher": [3]}
    task = launch.specification("test-image", spec)["tasks"][0]
    assert task["resources"]["gpuCount"] == 4
    assert task["context"]["autoResume"] is False
    assert task["constraints"] == {"cluster": ["ai2/holmes"]}
    assert {"name": "WANDB_MODE", "value": "offline"} in task["envVars"]
    assert specs.from_dict(spec.to_dict()).to_dict() == spec.to_dict()
    assert spec.document["model"]["revision"] == opd_config.REVISIONS["Qwen/Qwen3.5-4B"]
    assert spec.document["model"]["architecture"] == "qwen3.5-4B"


def test_async_opd_selects_safe_eval_and_measured_restartable_queue():
    spec = specs.load(
        CONFIG, ["miles.fully_async=true", "miles.max_weight_staleness=3", "distillation.use_rollout_logprobs=true"]
    )
    values, flags = native(spec)
    assert "--fully-async" in flags
    assert "--eval-function-path" not in values
    assert values["--custom-async-data-buffer-path"] == opd_config.ASYNC_BUFFER
    assert values["--data-source-path"] == opd_config.ASYNC_SOURCE
    assert "--use-rollout-logprobs" in flags and "--use-tis" not in flags
    assert specs.from_dict(spec.to_dict()).to_dict() == spec.to_dict()


@pytest.mark.parametrize("fully_async", [None, False, True])
@pytest.mark.parametrize("timing", [None, "", "/tmp/opd-timing", "0"])
def test_opd_timing_requires_async_driver(fully_async, timing):
    overrides = []
    if fully_async is not None:
        overrides.append(f"miles.fully_async={str(fully_async).lower()}")
    if fully_async:
        overrides += ["miles.max_weight_staleness=3", "distillation.use_rollout_logprobs=true"]
    if timing is not None:
        overrides.append(f"launch.env.OI_OPD_TIMING={json.dumps(timing)}")
    # Like the runtime, any nonempty value enables timing, including "0".
    if timing and not fully_async:
        with pytest.raises(InputError, match=r"launch.env.OI_OPD_TIMING requires miles.fully_async=true"):
            specs.load(CONFIG, overrides)
    else:
        spec = specs.load(CONFIG, overrides)
        assert spec.launch["env"].get("OI_OPD_TIMING") == timing


@pytest.mark.parametrize(
    "override, message",
    [
        ("miles.max_weight_staleness=0", "max_weight_staleness"),
        ("miles.update_weights_interval=2", "update_weights_interval"),
        ("training.optimizer_steps_per_rollout=2", "one optimizer step"),
        ("distillation.use_rollout_logprobs=false", "use_rollout_logprobs"),
        ("miles.use_tis=true", "use_tis"),
        ("miles.colocate=true", "colocate"),
        ('miles.pause_generation_mode="abort"', "abort"),
        ("miles.async_data_buffer_capacity_factor=0.01", "at least one group"),
    ],
)
def test_async_opd_rejects_unqualified_semantics(override, message):
    with pytest.raises(InputError, match=message):
        specs.load(
            CONFIG,
            [
                "miles.fully_async=true",
                "miles.max_weight_staleness=3",
                "distillation.use_rollout_logprobs=true",
                override,
            ],
        )


def test_cpu_preparation_requires_saturn():
    with pytest.raises(InputError, match="ai2/saturn"):
        specs.load(CONFIG, ['training.phase="prepare"'])
    spec = specs.load(CONFIG, ['training.phase="prepare"', 'launch.cluster="ai2/saturn"'])
    task = launch.specification("test-image", spec)["tasks"][0]
    assert task["resources"]["gpuCount"] == 0
    assert task["constraints"] == {"cluster": ["ai2/saturn"]}


@pytest.mark.parametrize(
    "override",
    [
        'trainer.backend="olmo-core"',
        "launch.auto_resume=true",
        "distillation.log_prob_top_k=10",
        "distillation.task_reward_weight=0.5",
        'model.source="Qwen/Qwen3.5-1.7B"',  # no pinned revision and no architecture profile
        'model.architecture="qwen2.5-7B"',
        'teacher.revision="main"',
        "trainer.gpus=3",
        "inference.gpus=3 inference.tensor_parallel_size=2",
        "launch.gpus_per_replica=8",
        "trainer.gpus=8",
        "training.eval_interval=-1",
        'tracking.wandb_mode="online"',
        'tracking.wandb_mode="verbose"',
    ],
)
def test_unsupported_paths_fail_before_launch(override):
    with pytest.raises(InputError):
        specs.load(CONFIG, override.split(" "))


def test_mounts_and_credentials_checked_before_build():
    document = specs.load(CONFIG).to_dict()
    document["launch"]["weka_mounts"] = []
    with pytest.raises(InputError, match="WEKA"):
        launch.specification("test-image", specs.from_dict(document))
    document = copy.deepcopy(specs.load(CONFIG).to_dict())
    document["launch"]["env"]["HF_TOKEN"] = "placeholder"
    with pytest.raises(InputError, match="secrets"):
        launch.specification("test-image", specs.from_dict(document))


def test_opd_task_data_needs_one_registered_task_with_evaluation():
    document = specs.load(CONFIG).to_dict()
    document["data"]["tasks"] = [{"task": "math", "train_count": 16, "eval_count": 8}]
    assert specs.from_dict(document).document["data"]["tasks"][0]["task"] == "math"
    for tasks in (
        [{"task": "gsm8k", "train_count": 16}],
        [{"task": "gsm8k", "train_count": 16, "eval_count": 8}, {"task": "math", "train_count": 16}],
    ):
        document["data"]["tasks"] = tasks
        with pytest.raises(InputError, match="eval_count"):
            specs.from_dict(document)
    document["data"]["tasks"] = [{"task": "dapo", "train_count": 16, "eval_count": 8}]
    with pytest.raises(InputError, match="data.tasks\\[0\\].task"):
        specs.from_dict(document)


def test_opd_accepts_prerendered_prompts_with_registry(tmp_path):
    document = specs.load(CONFIG).to_dict()
    document["data"] = {
        "prompt_data": "data/train.jsonl",
        "eval_prompt_data": ["dapo_math_holdout", "data/dapo_math_holdout.jsonl", "math_500", "data/math_500.jsonl"],
        "reward_config": "data/verifiers.json",
    }
    spec = specs.from_dict(document, config_path=tmp_path / "run.toml")
    assert spec.document["data"]["prompt_data"] == str(tmp_path / "data/train.jsonl")
    assert spec.document["data"]["eval_prompt_data"][1] == str(tmp_path / "data/dapo_math_holdout.jsonl")
    for missing in ("eval_prompt_data", "reward_config"):
        broken = copy.deepcopy(document)
        del broken["data"][missing]
        with pytest.raises(InputError, match="prompt_data"):
            specs.from_dict(broken, config_path=tmp_path / "run.toml")


def test_registered_verifiers_score_held_out_samples(tmp_path):
    registry = tmp_path / "verifiers.json"
    registry.write_text(
        json.dumps(
            {
                "gsm8k": {"factory": "open_instruct.ground_truth_utils.GSM8KVerifier"},
                "math": {"factory": "open_instruct.ground_truth_utils.MathVerifier"},
            }
        )
    )

    async def run():
        results = []
        for name, response, target in (
            ("gsm8k", "The answer is 7. #### 7", "7"),
            ("math", "So the value is \\boxed{\\frac{1}{2}}.", "\\frac{1}{2}"),
            ("math", "So the value is \\boxed{3}.", "\\frac{1}{2}"),
        ):
            sample = SimpleNamespace(
                tokens=[1, 2, 3],
                response_length=2,
                response=response,
                prompt="q",
                metadata={"verifiers": [{"name": name, "target": target, "weight": 1.0}], "query": "q"},
            )
            results.append(await rewards.score(sample, str(registry)))
        return results

    assert asyncio.run(run()) == [1.0, 1.0, 0.0]


def test_opd_honors_host_and_shared_memory_settings():
    spec = specs.load(CONFIG, ['launch.memory="128 GiB"', 'launch.shared_memory="48 GiB"'])
    task = launch.specification("test-image", spec)["tasks"][0]
    assert task["resources"]["sharedMemory"] == "48 GiB"
    assert task["resources"]["memory"] == "128 GiB"


def test_opd_verifier_zeroes_truncated_correct_answers(tmp_path):
    registry = tmp_path / "verifiers.json"
    registry.write_text(json.dumps({"gsm8k": {"factory": "open_instruct.ground_truth_utils.GSM8KVerifier"}}))
    sample = SimpleNamespace(
        tokens=[1, 2, 3],
        response_length=2,
        response="The answer is 7. #### 7",
        prompt="q",
        status="truncated",
        loss_mask=[1, 1],
        metadata={"verifiers": [{"name": "gsm8k", "target": "7", "weight": 1.0}], "query": "q"},
    )
    assert asyncio.run(rewards.score(sample, str(registry))) == 0.0
    assert sample.metadata["reward_gate"] == "truncated"
    assert sample.loss_mask == [1, 1]


def _child_pid(path):
    deadline = time.monotonic() + 10
    while not (path.exists() and path.read_text().strip()):
        assert time.monotonic() < deadline, "child pid was not written"
        time.sleep(0.05)
    return int(path.read_text())


def _assert_exits(pid):
    deadline = time.monotonic() + 10
    stat = Path(f"/proc/{pid}/stat")
    while True:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return
        # A killed child reparented to a slow reaper lingers as a zombie on Linux.
        # The process can disappear before opening stat (ENOENT) or while reading it (ESRCH).
        with contextlib.suppress(FileNotFoundError, ProcessLookupError):
            if stat.read_text().rsplit(")", 1)[1].split()[0] == "Z":
                return
        assert time.monotonic() < deadline, f"process {pid} survived group cleanup"
        time.sleep(0.05)


@pytest.mark.parametrize("error", [FileNotFoundError, ProcessLookupError])
def test_assert_exits_handles_process_disappearing_during_stat_read(error):
    with (
        mock.patch.object(os, "kill", side_effect=[None, ProcessLookupError]) as probe,
        mock.patch.object(Path, "read_text", side_effect=error) as read_stat,
    ):
        _assert_exits(12345)
    read_stat.assert_called_once()
    assert probe.call_count == 2


@pytest.mark.skipif(
    sys.platform == "darwin", reason="macOS killpg reports EPERM for a group left with only reparented zombies"
)
def test_process_group_cleanup_reaches_children_that_outlive_their_leader(tmp_path):
    pid_file = tmp_path / "survivor"
    leader = subprocess.Popen(["sh", "-c", f"sleep 300 & echo $! > {pid_file}"], start_new_session=True)
    leader.wait(timeout=10)
    survivor = _child_pid(pid_file)
    os.kill(survivor, 0)
    cluster.terminate(leader)
    _assert_exits(survivor)


def test_run_group_timeout_terminates_the_whole_group(tmp_path):
    pid_file = tmp_path / "worker"
    with pytest.raises(subprocess.TimeoutExpired):
        opd_runtime.run_group(["sh", "-c", f"sleep 300 & echo $! > {pid_file}; wait"], timeout=1)
    _assert_exits(_child_pid(pid_file))


@pytest.mark.skipif(
    sys.platform == "darwin", reason="macOS killpg reports EPERM for a group left with only reparented zombies"
)
def test_run_group_raises_on_failure_and_cleans_up(tmp_path):
    pid_file = tmp_path / "worker"
    with pytest.raises(subprocess.CalledProcessError):
        opd_runtime.run_group(["sh", "-c", f"sleep 300 & echo $! > {pid_file}; exit 3"], timeout=30)
    _assert_exits(_child_pid(pid_file))


def test_local_fingerprint_tracks_weights_and_tokenizer(tmp_path):
    (tmp_path / "config.json").write_text("{}")
    (tmp_path / "model.safetensors").write_bytes(b"a")
    (tmp_path / "tokenizer_config.json").write_text("{}")
    stamps = {opd_prepare.local_fingerprint(tmp_path, False)}
    assert opd_prepare.local_fingerprint(tmp_path, False) in stamps
    (tmp_path / "model.safetensors").write_bytes(b"ab")
    stamps.add(opd_prepare.local_fingerprint(tmp_path, False))
    (tmp_path / "tokenizer_config.json").write_text('{"eos_token": "x"}')
    stamps.add(opd_prepare.local_fingerprint(tmp_path, False))
    stamps.add(opd_prepare.local_fingerprint(tmp_path, True))
    assert len(stamps) == 4


def test_local_checkpoints_resolve_against_the_run_file(tmp_path):
    teacher = tmp_path / "teacher-step_100"
    teacher.mkdir()
    document = specs.load(CONFIG).to_dict()
    document["teacher"] = {"source": "./teacher-step_100"}
    document["model"] = {"source": str(tmp_path / "student"), "architecture": "qwen3.5-4B"}
    spec = specs.from_dict(document, config_path=tmp_path / "run.toml")
    assert spec.document["teacher"]["source"] == str(teacher.resolve())
    assert spec.document["teacher"]["revision"] == ""
    assert spec.document["model"]["source"] == str((tmp_path / "student").resolve())
    document["teacher"]["revision"] = opd_config.REVISIONS["Qwen/Qwen3.5-9B"]
    with pytest.raises(InputError, match="must not specify revision"):
        specs.from_dict(document, config_path=tmp_path / "run.toml")
    document["teacher"]["revision"] = ""
    del document["model"]["architecture"]
    with pytest.raises(InputError, match="model.architecture"):
        specs.from_dict(document, config_path=tmp_path / "run.toml")


def test_default_native_arguments_match_the_exercised_prototype():
    values, flags = native(specs.load(CONFIG))
    assert values["--save-interval"] == "1"
    assert values["--eval-interval"] == "2"
    assert values["--n-samples-per-eval-prompt"] == "1"
    assert values["--eval-temperature"] == "0.0"
    assert values["--wandb-project"] == "open-instruct-opd"
    assert values["--wandb-mode"] == "offline"
    assert values["--actor-num-gpus-per-node"] == "2"
    assert values["--num-gpus-per-node"] == "3"
    assert values["--rollout-num-gpus"] == "1"
    assert values["--tensor-model-parallel-size"] == "2"
    assert "--use-wandb" in flags
    assert "--use-rollout-logprobs" not in flags
    assert "--wandb-team" not in values


def test_relaxed_training_and_topology_settings_reach_native_arguments():
    spec = specs.load(
        CONFIG,
        [
            "training.num_rollouts=100",
            "training.save_interval=10",
            "training.eval_interval=20",
            "trainer.gpus=4",
            "inference.gpus=2",
            "inference.tensor_parallel_size=2",
            "teacher.gpus=2",
            "inference.max_running_requests=64",
            "inference.eval_temperature=0.6",
            "inference.eval_top_p=0.8",
            "inference.eval_max_response_length=1024",
            "inference.eval_samples_per_prompt=4",
            "training.optimizer_steps_per_rollout=4",
            'optimizer.lr_decay_style="cosine"',
            "optimizer.lr_warmup_iters=10",
            "optimizer.min_lr=1e-7",
            "optimizer.weight_decay=0.01",
            "optimizer.adam_beta2=0.999",
            'training.loss_aggregation="token"',
            "distillation.use_rollout_logprobs=true",
            'tracking.wandb_mode="disabled"',
            'model.source="Qwen/Qwen3.5-9B"',
        ],
    )
    assert spec.allocation() == {
        "replicas": 1,
        "gpus_per_replica": 8,
        "ray_gpus": 6,
        "roles": {"trainer": [0, 1, 2, 3], "student": [4, 5], "teacher": [6, 7]},
    }
    assert spec.document["model"]["architecture"] == "qwen3.5-9B"
    assert launch.specification("test-image", spec)["tasks"][0]["resources"]["gpuCount"] == 8
    assert any("topology" in warning for warning in spec.plan()["warnings"])
    values, flags = native(spec)
    assert values["--save-interval"] == "10"
    assert values["--eval-interval"] == "20"
    assert values["--num-rollout"] == "100"
    assert values["--eval-temperature"] == "0.6"
    assert values["--eval-top-p"] == "0.8"
    assert values["--eval-max-response-len"] == "1024"
    assert values["--rollout-top-p"] == "1.0"
    assert values["--n-samples-per-eval-prompt"] == "4"
    # 4 prompts x 2 samples per rollout split into 4 optimizer steps of 2 samples.
    assert values["--global-batch-size"] == "2"
    assert values["--lr-decay-style"] == "cosine"
    assert values["--lr-warmup-iters"] == "10"
    assert values["--min-lr"] == "1e-07"
    assert values["--lr-decay-iters"] == "400"
    assert values["--weight-decay"] == "0.01"
    assert values["--adam-beta1"] == "0.9"
    assert values["--adam-beta2"] == "0.999"
    assert "--calculate-per-token-loss" in flags
    assert values["--sglang-max-running-requests"] == "64"
    assert values["--sglang-max-total-tokens"] == str(2048 * 64)
    assert values["--actor-num-gpus-per-node"] == "4"
    assert values["--num-gpus-per-node"] == "6"
    assert values["--rollout-num-gpus"] == "2"
    assert values["--rollout-num-gpus-per-engine"] == "2"
    assert "--use-rollout-logprobs" in flags
    assert "--use-wandb" not in flags
    assert "--wandb-mode" not in values


def test_resume_loads_the_latest_checkpoint_and_keeps_the_scheduler_step(tmp_path):
    overrides = [f'output.root="{tmp_path}"', "training.resume=true"]
    values, flags = native(specs.load(CONFIG, overrides))
    assert "--load" not in values
    assert "--use-checkpoint-opt-param-scheduler" not in flags
    checkpoints = tmp_path / "checkpoints"
    checkpoints.mkdir()
    (checkpoints / "latest_checkpointed_iteration.txt").write_text("179\n")
    values, flags = native(specs.load(CONFIG, overrides))
    assert values["--load"] == str(checkpoints)
    # Megatron restores the scheduler's step count from the checkpoint; without this switch
    # Miles steps it again by the checkpoint iteration and a late resume trains at LR 0.
    assert "--use-checkpoint-opt-param-scheduler" in flags
    values, flags = native(specs.load(CONFIG, [f'output.root="{tmp_path}"', "training.resume=false"]))
    assert "--load" not in values
    assert "--use-checkpoint-opt-param-scheduler" not in flags


def test_fingerprint_ignores_an_empty_native_passthrough_table():
    document = specs.load(CONFIG).to_dict()
    assert document["miles"] == {}
    without = {key: value for key, value in document.items() if key != "miles"}
    assert workflow.fingerprint(document) == workflow.fingerprint(without)
    assert workflow.fingerprint({**document, "miles": {"use_tis": True}}) != workflow.fingerprint(document)
    # Architecture profiles and tokenizer files are hashed as lists.
    assert workflow.fingerprint(["--num-layers", "36"]) == workflow.fingerprint(["--num-layers", "36"])


def test_default_schedule_is_one_constant_lr_step_per_rollout():
    values, flags = native(specs.load(CONFIG))
    assert values["--global-batch-size"] == "8"
    assert values["--lr-decay-style"] == "constant"
    assert values["--min-lr"] == "0.0"
    assert values["--rollout-top-p"] == "1.0"
    assert values["--eval-max-response-len"] == values["--rollout-max-response-len"]
    assert "--lr-decay-iters" not in values
    assert values["--weight-decay"] == "0.0"
    assert values["--adam-beta2"] == "0.98"
    assert "--calculate-per-token-loss" not in flags


def test_native_passthrough_adds_options_the_schema_does_not_model():
    spec = specs.load(CONFIG, ["miles.use_tis=true", "miles.tis_clip=2.0", "miles.eps_clip_high=0.28"])
    assert spec.document["miles"] == {"use_tis": True, "tis_clip": 2.0, "eps_clip_high": 0.28}
    values, flags = native(spec)
    assert "--use-tis" in flags
    assert values["--tis-clip"] == "2.0"
    assert values["--eps-clip-high"] == "0.28"
    assert any("eps_clip_high" in warning and "tis_clip" in warning for warning in spec.plan()["warnings"])
    assert spec.plan()["spec"]["miles"] == spec.document["miles"]


def test_native_passthrough_replaces_hard_coded_native_arguments_once():
    spec = specs.load(
        CONFIG, ["miles.clip_grad=0.5", "miles.sglang_mem_fraction_static=0.7", "miles.rollout_shuffle=false"]
    )
    arguments = opd_runtime.native_arguments(spec, PREPARED, "/assets/ckpt", "http://127.0.0.1:1/generate", [])
    assert arguments.count("--clip-grad") == 1
    assert arguments.count("--sglang-mem-fraction-static") == 1
    assert "--rollout-shuffle" not in arguments
    values, flags = native(spec)
    assert values["--clip-grad"] == "0.5"
    assert values["--sglang-mem-fraction-static"] == "0.7"
    # Everything the schema owns is still there, once, with the schema's value.
    assert arguments.count("--weight-decay") == 1
    assert values["--weight-decay"] == "0.0"
    assert values["--eval-prompt-data"] == "gsm8k"


def test_native_passthrough_accepts_flag_spellings_and_empty_tables():
    spec = specs.load(CONFIG, ["miles.no_use_checkpoint_lr_scheduler=true"])
    assert spec.document["miles"] == {"use_checkpoint_lr_scheduler": False}
    assert "--no-use-checkpoint-lr-scheduler" in native(spec)[1]
    assert specs.load(CONFIG).document["miles"] == {}
    assert specs.load(CONFIG).plan()["warnings"] == ["Experimental sampled-token OPD; runtime qualification required."]


@pytest.mark.parametrize(
    ("override", "hint"),
    [
        ("miles.weight_decay=0.1", "optimizer.weight_decay"),
        ("miles.num_rollout=5", "training.num_rollouts"),
        ("miles.calculate_per_token_loss=true", "training.loss_aggregation"),
        ("miles.use_rollout_logprobs=true", "distillation.use_rollout_logprobs"),
        ("miles.opd_kl_coef=0.5", "distillation.kl_coef"),
        ('miles.opd_type="megatron"', "OPD teacher"),
        ('miles.save="/elsewhere"', "output.root"),
        ("miles.rollout_num_gpus=2", "inference.gpus"),
        ("miles.not_a_miles_option=1", "Unknown MILES option"),
        ("miles=3", "[miles]"),
    ],
)
def test_native_passthrough_rejects_owned_and_unknown_options(override, hint):
    with pytest.raises(InputError, match=re.escape(hint)):
        specs.load(CONFIG, [override])


def test_every_owned_native_option_exists_in_the_pinned_parser():
    index = options.option_index()
    for name in opd_config.OWNED_NATIVE_OPTIONS:
        assert name in index and index[name]["dest"] == name, name


def test_qwen3_replication_models_resolve_to_upstream_profiles():
    spec = specs.load(CONFIG, ['model.source="Qwen/Qwen3-4B-Base"', 'teacher.source="Qwen/Qwen3-8B"'])
    assert spec.document["model"]["architecture"] == "qwen3-4B"
    assert spec.document["model"]["revision"] == opd_config.REVISIONS["Qwen/Qwen3-4B-Base"]
    assert spec.document["teacher"]["revision"] == opd_config.REVISIONS["Qwen/Qwen3-8B"]


@pytest.mark.parametrize(
    "override, message",
    [
        ("training.optimizer_steps_per_rollout=3", "must divide"),
        ("inference.eval_top_p=1.5", "inference.eval_top_p"),
        ("inference.eval_max_response_length=4096", "exceed eval_max_response_length"),
        ('optimizer.lr_decay_style="step"', "optimizer.lr_decay_style"),
        ("optimizer.min_lr=1e-3", "min_lr must not exceed"),
        ("optimizer.weight_decay=-0.1", "optimizer.weight_decay"),
        ("optimizer.adam_beta2=1.0", "optimizer.adam_beta2"),
        ('training.loss_aggregation="mean"', "training.loss_aggregation"),
        (["inference.top_p=0.9", "distillation.use_rollout_logprobs=true"], "inference.top_p must be 1.0"),
    ],
)
def test_schedule_and_sampling_knobs_are_validated(override, message):
    with pytest.raises(InputError, match=message):
        specs.load(CONFIG, override if isinstance(override, list) else [override])


def test_online_tracking_requires_a_wandb_secret():
    document = specs.load(CONFIG).to_dict()
    document["tracking"] = {"wandb_mode": "online", "wandb_project": "opd", "wandb_entity": "allenai-team1"}
    document["launch"]["secrets"] = {"WANDB_API_KEY": "kevinfarhat_WANDB_API_KEY"}
    spec = specs.from_dict(document)
    values, _ = native(spec)
    assert values["--wandb-mode"] == "online"
    assert values["--wandb-team"] == "allenai-team1"
    assert values["--wandb-project"] == "opd"
    task = launch.specification("test-image", spec)["tasks"][0]
    assert {"name": "WANDB_MODE", "value": "online"} in task["envVars"]
    assert {"name": "WANDB_API_KEY", "secret": "kevinfarhat_WANDB_API_KEY"} in task["envVars"]


def test_repository_profiles_render_through_the_miles_loader():
    miles = Path(os.environ.get("MILES_SOURCE", "")) / "miles/utils/external_utils/model_args_utils.py"
    if not miles.is_file():
        pytest.skip("Set MILES_SOURCE to a Miles checkout to render architecture profiles")
    spec = importlib.util.spec_from_file_location("model_args_utils", miles)
    module = importlib.util.module_from_spec(spec)
    sys.modules["model_args_utils"] = module
    spec.loader.exec_module(module)
    for profile in opd_config.PROFILES:
        directory = opd_runtime.PROFILES if (opd_runtime.PROFILES / f"{profile}.py").exists() else None
        rendered = module.load_model_args(profile, model_script_dir=directory or miles.parents[3] / "scripts/models")
        if profile.startswith("qwen3.5"):
            assert "--spec miles_plugins.models.qwen3_5 get_qwen3_5_spec" in rendered
        else:
            assert "--vocab-size 151936" in rendered
    two_b = module.load_model_args("qwen3.5-2B", model_script_dir=opd_runtime.PROFILES).split()
    assert two_b[two_b.index("--num-layers") + 1] == "24"
    assert "--untie-embeddings-and-output-weights" not in two_b
    assert specs.load(CONFIG, ['model.source="Qwen/Qwen3.5-2B"']).document["model"]["architecture"] == "qwen3.5-2B"


def _repository_profile(profile):
    path = opd_runtime.PROFILES / f"{profile}.py"
    spec = importlib.util.spec_from_file_location(f"profile_{profile.replace('.', '_').replace('-', '_')}", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.model_args().split()


@pytest.mark.parametrize(
    "profile, layers, hidden, ffn, heads",
    [("qwen3-1.7B", "28", "2048", "6144", "16"), ("qwen3-4B", "36", "2560", "9728", "32")],
)
def test_qwen3_profiles_pin_the_unpadded_vocabulary(profile, layers, hidden, ffn, heads):
    # mbridge scatters the 151936-row HF embedding across TP ranks unpadded; Megatron would
    # otherwise pad to 152064 under TP2 and the conversion fails on a size mismatch.
    args = _repository_profile(profile)
    values = {args[i]: args[i + 1] for i in range(len(args) - 1) if args[i].startswith("--")}
    assert values["--vocab-size"] == values["--padded-vocab-size"] == "151936"
    assert int(values["--padded-vocab-size"]) % 128 == 0
    assert (values["--num-layers"], values["--hidden-size"], values["--ffn-hidden-size"]) == (layers, hidden, ffn)
    assert values["--num-attention-heads"] == heads and values["--num-query-groups"] == "8"
    assert values["--rotary-base"] == "1000000" and values["--kv-channels"] == "128"
    assert "--untie-embeddings-and-output-weights" not in args  # Qwen3-Base 1.7B/4B tie embeddings
    assert "--qk-layernorm" in args and "--swiglu" in args


def test_code_overlay_is_off_by_default(monkeypatch):
    monkeypatch.delenv("MILES_CODE_OVERLAY", raising=False)
    spec = specs.load(CONFIG)
    assert opd_launch.code_overlay() == ""
    assert "oi-overlay" not in launch.specification("test-image", spec)["tasks"][0]["arguments"][0]


def test_code_overlay_fetches_head_before_training(monkeypatch):
    monkeypatch.setenv("MILES_CODE_OVERLAY", "1")
    spec = specs.load(CONFIG)
    command = launch.specification("test-image", spec)["tasks"][0]["arguments"][0]
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    assert "fetch -q --depth 1 https://github.com/" in command
    assert "GIT_LFS_SKIP_SMUDGE=1 git -C /tmp/oi-overlay checkout -q FETCH_HEAD" in command
    assert revision in command
    for directory in opd_launch.OVERLAY_DIRS:
        assert f"cp -r /tmp/oi-overlay/{directory}/. /opt/core-rl/{directory}/" in command
    assert command.index("cp -r /tmp/oi-overlay/open_instruct/.") < command.index(
        "python -m open_instruct.miles train"
    )


def test_teacher_eos_remap_reads_the_prepared_generation_config(tmp_path):
    (tmp_path / "generation_config.json").write_text(json.dumps({"eos_token_id": [151645, 151643]}))
    remap = opd_prepare.teacher_eos_remap(tmp_path)
    assert remap == {151643: 151645}
    assert opd_prepare.eos_remap_environment(remap) == "151643:151645"
    assert opd_prepare.eos_remap_environment({4: 9, 3: 9}) == "3:9,4:9"
    (tmp_path / "generation_config.json").write_text(json.dumps({"eos_token_id": 151645}))
    with pytest.raises(InputError, match="own stop id"):
        opd_prepare.teacher_eos_remap(tmp_path)


def test_align_eos_with_teacher_default_and_validation():
    spec = specs.load(CONFIG)
    assert spec.document["model"]["align_eos_with_teacher"] is False
    with pytest.raises(InputError, match="align_eos_with_teacher"):
        specs.load(CONFIG, ['model.align_eos_with_teacher="yes"'])
    assert (
        specs.load(CONFIG, ["model.align_eos_with_teacher=true"]).document["model"]["align_eos_with_teacher"] is True
    )


def test_eos_token_ids_puts_teacher_eos_first_and_keeps_learner_eos():
    assert opd_prepare.eos_token_ids({"eos_token_id": 151643}, 151645) == [151645, 151643]
    assert opd_prepare.eos_token_ids({"eos_token_id": [151645, 151643]}, 151645) == [151645, 151643]
    assert opd_prepare.eos_token_ids({}, 7) == [7]


def test_eopd_selects_the_custom_loss_and_forwards_its_settings():
    values, flags = native(specs.load(CONFIG))
    assert "--loss-type" not in values and "--custom-loss-function-path" not in values
    assert not opd_runtime.eopd_settings(specs.load(CONFIG)).enabled
    spec = specs.load(
        CONFIG, ["distillation.use_rollout_logprobs=true", "distillation.eopd=true", "distillation.eopd_tau=0.7"]
    )
    values, flags = native(spec)
    assert values["--loss-type"] == "custom_loss"
    assert values["--custom-loss-function-path"] == "open_instruct.miles.distillation.eopd_loss.policy_loss"
    assert values["--opd-log-prob-top-k"] == "0"  # the upstream top-k reverse-KL path stays off
    assert "--use-opd" in flags and "--use-rollout-logprobs" in flags
    assert opd_runtime.eopd_settings(spec).environment() == {
        "OI_OPD_EOPD_TOP_K": "16",
        "OI_OPD_EOPD_ALPHA": "1.0",
        "OI_OPD_EOPD_TAU": "0.7",
    }


@pytest.mark.parametrize(
    ("override", "message"),
    [
        (["distillation.eopd_top_k=0"], "positive integer"),
        (["distillation.eopd_alpha=0"], "> 0"),
        (["distillation.eopd_tau=-1"], ">= 0"),
        (['distillation.eopd="yes"'], "distillation.eopd"),
    ],
)
def test_eopd_knobs_are_validated(override, message):
    with pytest.raises(InputError, match=message):
        specs.load(CONFIG, override)


def test_eopd_tiny_smoke_config_mirrors_the_opd_tiny_run():
    folder = CONFIG.parent
    opd = specs.load(folder / "eopd-opd-qwen3-tiny.toml").to_dict()
    eopd = specs.load(folder / "eopd-eopd-qwen3-tiny.toml").to_dict()
    assert eopd["distillation"] == opd["distillation"] | {"eopd": True}
    for section in ("model", "teacher", "training", "trainer", "inference", "optimizer", "data"):
        assert eopd[section] == opd[section], section
    assert eopd["output"]["root"] != opd["output"]["root"]


def test_keep_checkpoints_installs_the_post_save_hook_without_changing_the_run_identity():
    values, _ = native(specs.load(CONFIG))
    assert "--custom-megatron-post-save-hook-path" not in values
    spec = specs.load(CONFIG, ["training.keep_checkpoints=2"])
    values, _ = native(spec)
    assert values["--custom-megatron-post-save-hook-path"] == opd_retention.POST_SAVE_HOOK
    # Retention decides what stays on disk, not what is trained: an existing run root still
    # resumes after the knob is added or tightened.
    assert workflow.fingerprint(spec.to_dict()) == workflow.fingerprint(specs.load(CONFIG).to_dict())
    with pytest.raises(InputError, match="nonnegative integer"):
        specs.load(CONFIG, ["training.keep_checkpoints=-1"])


def test_prune_checkpoints_keeps_the_newest_completed_iterations(tmp_path, monkeypatch):
    save_root = tmp_path / "checkpoints"
    for iteration in (19, 39, 59, 79, 99):
        (save_root / f"iter_{iteration:07d}").mkdir(parents=True)
        (save_root / f"iter_{iteration:07d}" / "model.pt").write_bytes(b"x")
    (save_root / "rollout").mkdir()
    # Without the marker nothing is known to be complete.
    assert opd_retention.prune_checkpoints(save_root, 2) == []
    (save_root / "latest_checkpointed_iteration.txt").write_text("79\n")
    removed = opd_retention.prune_checkpoints(save_root, 2)
    assert [path.name for path in removed] == ["iter_0000019", "iter_0000039"]
    # iter_0000099 is newer than the marker (a save in progress) and is never touched.
    assert sorted(path.name for path in save_root.glob("iter_*")) == ["iter_0000059", "iter_0000079", "iter_0000099"]
    assert opd_retention.prune_checkpoints(save_root, 0) == []
    assert opd_retention.prune_checkpoints(save_root, 2) == []
    monkeypatch.setenv(opd_retention.KEEP_ENV, "1")
    opd_retention.post_save(None, 79, str(save_root / "iter_0000079"), None)
    assert sorted(path.name for path in save_root.glob("iter_*")) == ["iter_0000079", "iter_0000099"]
    assert (save_root / "rollout").is_dir()
