"""Plan evaluation milestones and submit ready policy snapshots to Beaker in the
background. A single coordinator claims milestone receipts and gives submission a
bounded window, allowing the training driver to continue while separate evaluator
jobs run. Busy submissions are recorded as skipped under the best-effort policy;
snapshot creation belongs to the trainer and evaluator execution to the worker.
"""

import argparse
import base64
import hashlib
import json
import re
import shlex
import subprocess
import sys
import threading
import uuid
from pathlib import Path

from open_instruct import logger_utils
from open_instruct.miles.errors import InputError
from open_instruct.miles.evaluation import evaluation_runner
from open_instruct.miles.infrastructure import artifacts as state
from open_instruct.miles.infrastructure import infra_timeouts

logger = logger_utils.setup_logger(__name__)

# Gated downloads used by the maintained safety panel. Keep planning offline;
# this is a narrow guard for known models, not a claim about arbitrary HF repos.
GATED_JUDGE_MODELS = {"allenai/wildguard", "google/gemma-2b"}
# olmo-eval task families whose datasets are gated, keyed by the task name before "_" or ":".
GATED_TASK_DATASETS = {"gpqa": "Idavidrein/gpqa"}


def parse(value, launch):
    value = dict(value)
    allowed = {
        "mode",
        "interval",
        "initial",
        "final",
        "tasks",
        "image",
        "revision",
        "gpus",
        "cluster",
        "workspace",
        "budget",
        "secrets",
        "submit_timeout",
        "timeout",
        "provider_kwargs",
        "external_server_args",
    }
    if "server_args" in value:
        raise InputError("evaluation.server_args was replaced by provider_kwargs; use SGLang Python option names")
    if set(value) - allowed:
        raise InputError(f"Unknown evaluation fields: {sorted(set(value) - allowed)}")
    mode = value.setdefault("mode", "shared")
    if mode not in ("shared", "background"):
        raise InputError("evaluation.mode must be shared or background")
    if mode == "shared":
        if set(value) != {"mode"}:
            raise InputError(
                "evaluation settings require mode=background; shared evaluation uses existing data/miles fields"
            )
        return value
    defaults = dict(
        interval=20, initial=True, final=True, gpus=1, submit_timeout=30, timeout="3h", secrets={}, provider_kwargs={}
    )
    for key, default in defaults.items():
        value.setdefault(key, default)
    value.setdefault("external_server_args", [])
    for key in ("cluster", "workspace", "budget"):
        value.setdefault(key, launch[key])
    if type(value["interval"]) is not int or value["interval"] < 0:
        raise InputError("evaluation.interval must be a nonnegative integer (0 disables periodic evaluation)")
    for key in ("gpus", "submit_timeout"):
        if type(value[key]) is not int or value[key] < 1:
            raise InputError(f"evaluation.{key} must be a positive integer")
    for key in ("initial", "final"):
        if type(value[key]) is not bool:
            raise InputError(f"evaluation.{key} must be boolean")
    if not isinstance(value.get("image"), str) or not re.fullmatch(r"[0-9A-HJKMNP-TV-Z]{26}", value["image"]):
        raise InputError("evaluation.image must be an immutable Beaker image ID")
    if not isinstance(value.get("revision"), str) or not re.fullmatch(r"[0-9a-f]{40}", value["revision"]):
        raise InputError("evaluation.revision must pin the full olmo-eval Git commit")
    for key in ("cluster", "workspace", "budget", "timeout"):
        if not isinstance(value[key], str) or not value[key].strip():
            raise InputError(f"evaluation.{key} must be a nonempty string")
    secrets = value["secrets"]
    if not isinstance(secrets, dict) or any(
        not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key) or not isinstance(secret, str) or not secret
        for key, secret in secrets.items()
    ):
        raise InputError("evaluation.secrets must map environment names to Beaker secret references")
    value["secrets"] = {
        key: secret for key, secret in launch["secrets"].items() if key in {"WANDB_API_KEY", "HF_TOKEN"}
    } | secrets
    kwargs = value["provider_kwargs"]
    if not isinstance(kwargs, dict) or any(not re.fullmatch(r"[a-z][a-z0-9_]*", key) for key in kwargs):
        raise InputError("evaluation.provider_kwargs must be a table of SGLang Python options")
    reserved = {
        "model",
        "model_name",
        "model_path",
        "tokenizer",
        "tokenizer_path",
        "revision",
        "host",
        "port",
        "tp_size",
        "tensor_parallel_size",
        "dp_size",
        "nnodes",
        "node_rank",
        "base_gpu_id",
        "gpu_id_step",
        "model_registration",
    }
    if reserved.intersection(kwargs):
        raise InputError(
            "evaluation.provider_kwargs cannot override snapshot, tokenizer, model registration or GPU allocation"
        )
    # Resolve against the checkpoint and assigned GPU inside the evaluator, not
    # the training cluster. Explicit generic remains available for unqualified models.
    value["provider_kwargs"] = kwargs = {"profile": "auto", **kwargs}
    server_args = value["external_server_args"]
    if not isinstance(server_args, list) or any(not isinstance(arg, str) for arg in server_args):
        raise InputError("evaluation.external_server_args must be a list of SGLang arguments for SciCode")
    server_reserved = {"--model", "--model-path", "--tokenizer-path", "--port", "--host", "--tp", "--tp-size"}
    if any(arg.split("=")[0] in server_reserved for arg in server_args):
        raise InputError("evaluation.external_server_args cannot override snapshot, tokenizer, port or GPU allocation")
    tasks = value.get("tasks")
    if not isinstance(tasks, list) or not tasks:
        raise InputError("evaluation.tasks must be a nonempty list of olmo-eval tasks")
    names = set()
    for task in tasks:
        if not isinstance(task, dict) or set(task) - {
            "task",
            "interval",
            "generation",
            "scoring",
            "harness",
            "harness_preset",
            "kind",
            "arguments",
            "auxiliary_gpus",
        }:
            raise InputError(
                "evaluation.tasks accept task, interval, generation, scoring, harness, harness_preset, kind, arguments and auxiliary_gpus"
            )
        name = task.get("task")
        if not isinstance(name, str) or not name or name in names:
            raise InputError("evaluation task names must be nonempty and unique")
        names.add(name)
        auxiliary_gpus = task.get("auxiliary_gpus", 0)
        if type(auxiliary_gpus) is not int or auxiliary_gpus < 0:
            raise InputError("evaluation task auxiliary_gpus must be a nonnegative integer")
        kind = task.get("kind", "task")
        if kind not in ("task", "external"):
            raise InputError("evaluation task kind must be task or external")
        if kind == "external":
            if server_args and kwargs["profile"] != "generic":
                raise InputError(
                    "Profiled SciCode evaluation uses evaluation.provider_kwargs for serving settings. "
                    "Remove external_server_args, or select profile=generic for a manually configured server."
                )
            if not server_args:
                try:
                    evaluation_runner.scicode_server_options(kwargs)
                except ValueError as error:
                    raise InputError(str(error)) from error
            if name != "scicode":
                raise InputError("Only scicode external evaluation has a supported artifact validation contract")
            if any(task.get(key) for key in ("generation", "scoring", "harness", "harness_preset")):
                raise InputError(
                    "External evaluation uses arguments instead of generation, scoring or harness settings"
                )
            arguments = task.get("arguments", {})
            if not isinstance(arguments, dict) or arguments.get("split") != "validation":
                raise InputError("SciCode development evaluation requires arguments.split=validation")
            if not isinstance(arguments.get("h5py_host_path"), str) or not arguments["h5py_host_path"]:
                raise InputError("SciCode requires arguments.h5py_host_path for its reference data")
        elif "arguments" in task:
            raise InputError("evaluation task arguments require kind=external")
        preset = task.get("harness_preset", "default")
        if not isinstance(preset, str) or not preset:
            raise InputError("evaluation task harness_preset must be a nonempty string")
        harness = task.get("harness", {})
        if not isinstance(harness, dict) or any(not isinstance(key, str) or not key for key in harness):
            raise InputError("evaluation task harness must be a table of flat olmo-eval harness overrides")
        if any(key == "provider" or key.startswith("provider.") for key in harness):
            raise InputError("evaluation task harness cannot override the frozen checkpoint provider")
        task.setdefault("interval", value["interval"])
        if type(task["interval"]) is not int or task["interval"] < 0:
            raise InputError("evaluation task interval must be a nonnegative integer (0 disables periodic evaluation)")
        for key in ("generation", "scoring"):
            task.setdefault(key, {})
            if not isinstance(task[key], dict):
                raise InputError(f"evaluation task {key} must be an override table")
            if any(name == "provider" or name.startswith("provider.") for name in task[key]):
                raise InputError("Use evaluation.provider_kwargs for provider options, not task overrides")
        # No credential values are accepted in overrides; use evaluator secrets.
        encoded = json.dumps(task).lower()
        if any(word in encoded for word in ("api_key", "password", "access_token", "api-key")):
            raise InputError("Use evaluation.secrets for credentials, not task overrides")
    validate_judge_credentials(value)
    return value


def validate_judge_credentials(config):
    """Reject known gated managed-judge and dataset downloads without an evaluator secret."""
    if config["secrets"].get("HF_TOKEN", "").strip():
        return
    affected = []
    for task in config["tasks"]:
        if task.get("kind", "task") != "task" or not (config["initial"] or config["final"] or task["interval"] > 0):
            continue
        dataset = GATED_TASK_DATASETS.get(re.split(r"[_:]", task["task"], maxsplit=1)[0])
        if dataset:
            affected.append(f"{task['task']} (dataset={dataset})")
        harness = task.get("harness", {})
        for key, model in harness.items():
            if not re.fullmatch(r"auxiliary_providers\.[^.]+\.(model|tokenizer)", key):
                continue
            provider = key.rsplit(".", 1)[0]
            if (
                isinstance(model, str)
                and model in GATED_JUDGE_MODELS
                and harness.get(f"{provider}.kind") == "vllm_server"
                and not harness.get(f"{provider}.base_url")
            ):
                affected.append(f"{task['task']} ({key}={model})")
    if affected:
        raise InputError(
            "Background evaluation requires an HF_TOKEN Beaker secret reference for gated judges or datasets: "
            + "; ".join(affected)
            + '. Set evaluation.secrets.HF_TOKEN = "your-beaker-secret-name" or launch.secrets.HF_TOKEN '
            "(inherited by evaluation). The token's HF account must have accepted each model's or dataset's access terms. "
            "A token in the local environment is not forwarded to evaluator jobs."
        )


def groups(config, update, total):
    """Merge coincident initial/periodic/final milestones, grouped by harness settings."""
    selected = {}
    for task in config["tasks"]:
        due = config["initial"] if update == 0 else task["interval"] > 0 and update % task["interval"] == 0
        due = due or (update == total and config["final"])
        if due:
            key = json.dumps(
                {
                    "generation": task["generation"],
                    "kind": task.get("kind", "task"),
                    "harness_preset": task.get("harness_preset", "default"),
                    "harness": task.get("harness", {}),
                    "auxiliary_gpus": task.get("auxiliary_gpus", 0),
                },
                sort_keys=True,
            )
            selected.setdefault(key, []).append(task)
    return list(selected.values())


def total_updates(options):
    return (
        options["num_rollout"]
        * options["rollout_batch_size"]
        * options["n_samples_per_prompt"]
        // options["global_batch_size"]
    )


def snapshot(root, update):
    return Path(root) / "eval-snapshots" / f"update-{update:08d}" / "hf"


def plan(spec, options):
    config = spec.evaluation
    if config["mode"] != "background":
        return config
    total = total_updates(options)
    updates = {0} if config["initial"] else set()
    if config["final"]:
        updates.add(total)
    for task in config["tasks"]:
        if task["interval"] > 0:
            updates.update(range(task["interval"], total + 1, task["interval"]))
    return {
        **config,
        "mounts": spec.launch["weka_mounts"],
        "milestones": [
            {
                "update": update,
                "groups": groups(config, update, total),
                "snapshot": str(snapshot(spec.output["root"], update)),
            }
            for update in sorted(updates)
        ],
        "initial_checkpoint_reuse": spec.conversion["hf_output"],
        "retention": "manual cleanup only",
    }


def runtime(spec, options):
    return {
        **spec.evaluation,
        "root": spec.output["root"],
        "name": spec.name,
        "mounts": spec.launch["weka_mounts"],
        "total_updates": total_updates(options),
    }


def specification(receipt):
    config = receipt["evaluation"]
    # Carry the committed runner to the independent evaluator image. No source
    # checkout, dependency resolution or moving branch is used at job startup.
    runner = Path(__file__).with_name("evaluation_runner.py").read_bytes()
    if hashlib.sha256(runner).hexdigest() != receipt["runner_sha256"]:
        raise InputError("Evaluator runner differs from the recorded source; use its committed checkout")
    payload = base64.b64encode(json.dumps(receipt).encode()).decode()
    source = base64.b64encode(runner).decode()
    setup = f"import base64,pathlib; pathlib.Path('/tmp/evaluate.py').write_bytes(base64.b64decode({source!r})); pathlib.Path('/tmp/evaluation.json').write_bytes(base64.b64decode({payload!r}))"
    sandbox = any(
        task.get("kind") == "external" or task.get("harness_preset") == "codex_python"
        for task in receipt.get("tasks", [])
    )
    sandbox_env = (
        [{"name": name, "value": "1"} for name in ("BEAKER_ALLOW_SUBCONTAINERS", "BEAKER_SKIP_DOCKER_SOCKET")]
        if sandbox
        else []
    )
    return {
        "version": "v2",
        "budget": config["budget"],
        "description": f"MILES background evaluation {receipt['training']['name']} update {receipt['update']}",
        "tasks": [
            {
                "name": "evaluation",
                "image": {"beaker": config["image"]},
                "command": ["bash", "-c"],
                "arguments": [
                    f"set -euo pipefail\npython -c {shlex.quote(setup)}\npython /tmp/evaluate.py run /tmp/evaluation.json"
                ],
                "datasets": [{"mountPath": m["mount_path"], "source": {"weka": m["weka"]}} for m in config["mounts"]],
                "result": {"path": "/output"},
                "resources": {
                    "gpuCount": config["gpus"] + max(task.get("auxiliary_gpus", 0) for task in receipt["tasks"]),
                    "sharedMemory": "32 GiB",
                },
                "constraints": {"cluster": [config["cluster"]]},
                "context": {"priority": "high", "autoResume": True},
                "timeout": config["timeout"],
                "envVars": sandbox_env
                + [{"name": name, "secret": secret} for name, secret in config["secrets"].items()],
            }
        ],
    }


def submit(receipt, path):
    """One attempt with a hard process deadline. Timeout means ambiguous submission."""
    spec_path = path.with_suffix(".beaker.json")
    try:
        if receipt["update"] and not (Path(receipt["checkpoint"]) / ".complete").is_file():
            raise ValueError("Snapshot completion marker missing; refusing submission")
        state.atomic_json(spec_path, specification(receipt))
        with infra_timeouts.watch(
            "background evaluation submission", previous_timeout=receipt["evaluation"]["submit_timeout"]
        ):
            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "open_instruct.miles.evaluation.evaluation_submit",
                    str(spec_path),
                    receipt["evaluation"]["workspace"],
                    f"miles-eval-{hashlib.sha256(receipt['evaluation']['root'].encode()).hexdigest()[:10]}-{receipt['update']}-{receipt['group_id']}",
                    str(int(infra_timeouts.seconds(receipt["evaluation"]["submit_timeout"]))),
                ],
                capture_output=True,
                text=True,
                timeout=infra_timeouts.seconds(receipt["evaluation"]["submit_timeout"]),
                check=True,
            )
        response = json.loads(result.stdout)
        experiment = response[0] if isinstance(response, list) else response
        receipt.update(status="submitted", experiment_id=experiment["id"])
    except Exception as error:
        # Do not persist child stdout/stderr: tools may echo credential values.
        receipt.update(
            status="submission_failed",
            error=type(error).__name__,
            diagnostic="Submission failed or timed out; inspect Beaker before manual resubmission. No automatic retry.",
        )
        if isinstance(error, subprocess.CalledProcessError):
            receipt["exit_code"] = error.returncode
            try:
                # Only the controlled child emits this redacted JSON diagnostic.
                detail = json.loads((error.stderr or "").splitlines()[-1])
                if isinstance(detail, dict) and set(detail) == {"error", "message"}:
                    receipt["submission_error"] = detail
            except (ValueError, IndexError):
                pass
        logger.warning(
            "BACKGROUND EVALUATION GAP at update %s: %s; receipt %s",
            receipt["update"],
            receipt.get("submission_error", type(error).__name__),
            path,
        )
    state.atomic_json(path, receipt)


class Coordinator:
    """Driver-only submitter, with one daemon worker and no pending queue or join."""

    def __init__(self, config, training):
        self.config = config
        self.training = training
        self.worker = None

    def dispatch(self, update, checkpoint, *, final=False):
        self.dispatch_batch([(update, checkpoint)], final=final)

    def dispatch_batch(self, milestones, *, final=False):
        """Accept one collection together; final includes all tasks at its last update."""
        try:
            self._dispatch_batch(milestones, final=final)
        except Exception as error:
            # Local receipt/submission preparation is independent of trainer health.
            logger.warning("BACKGROUND EVALUATION GAP: cannot record/submit collection (%s)", type(error).__name__)

    def _dispatch_batch(self, milestones, *, final=False):
        busy = self.worker is not None and self.worker.is_alive()
        receipts = []
        for index, (update, checkpoint) in enumerate(milestones):
            try:
                receipts.extend(
                    self._receipts(update, checkpoint, busy=busy, final=final and index == len(milestones) - 1)
                )
            except Exception as error:
                logger.warning(
                    "BACKGROUND EVALUATION GAP at update %s: cannot record (%s)", update, type(error).__name__
                )
        if receipts:
            self.worker = threading.Thread(
                target=self._submit, args=(receipts,), daemon=True, name="miles-evaluation-submit"
            )
            self.worker.start()

    def _receipts(self, update, checkpoint, *, busy, final=False):
        if update == 0:
            state.atomic_json(
                snapshot(self.config["root"], 0).parent / "reference.json",
                {"checkpoint": str(checkpoint), "update": 0, "reuse_initial_hf": True},
            )
        receipts = []
        for tasks in groups(self.config, update, update if final else self.config["total_updates"]):
            key = hashlib.sha256(json.dumps(tasks, sort_keys=True).encode()).hexdigest()[:16]
            path = Path(self.config["root"]) / "evaluation" / f"update-{update:08d}-{key}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            # Exclusive claim also protects against a duplicate coordinator call.
            try:
                with path.open("x") as stream:
                    json.dump({"status": "claimed", "update": update}, stream)
            except FileExistsError:
                continue  # Including ambiguous/failed attempts: never retry automatically.
            receipt = dict(
                schema_version=1,
                update=update,
                checkpoint=str(checkpoint),
                tasks=tasks,
                group_id=key,
                evaluation=self.config,
                training=self.training,
                status="pending",
                runner_sha256=hashlib.sha256(
                    Path(__file__).with_name("evaluation_runner.py").read_bytes()
                ).hexdigest(),
            )
            if busy:
                receipt.update(status="skipped_busy", diagnostic="Submission worker busy; milestone dropped")
                logger.warning("BACKGROUND EVALUATION GAP at update %s: submission worker busy", update)
            state.atomic_json(path, receipt)
            if receipt["status"] == "pending":
                receipts.append((receipt, path))
        return receipts

    @staticmethod
    def _submit(receipts):
        for receipt, path in receipts:
            try:
                submit(receipt, path)
            except Exception as error:
                logger.warning("BACKGROUND EVALUATION GAP: receipt %s (%s)", path, type(error).__name__)


def main():
    parser = argparse.ArgumentParser(description="Manually resubmit one evaluation receipt; no automatic retries")
    parser.add_argument("command", choices=("resubmit",))
    parser.add_argument("receipt", type=Path)
    args = parser.parse_args()
    receipt = json.loads(args.receipt.read_text())
    # Preserve the old receipt/results and make the explicit new attempt reviewable.
    receipt.update(status="pending", group_id=uuid.uuid4().hex[:16], resubmission_of=str(args.receipt))
    receipt.pop("experiment_id", None)
    receipt.pop("error", None)
    path = args.receipt.with_name(f"{args.receipt.stem}-manual-{receipt['group_id']}.json")
    state.atomic_json(path, receipt)
    submit(receipt, path)
    print(path)
    if receipt["status"] != "submitted":
        raise SystemExit(1)


if __name__ == "__main__":
    main()


def training_snapshot(args, update):
    """Return a requested export path for the backend after an optimizer update."""
    config = args.background_evaluation
    if groups(config, update, config["total_updates"]):
        return str(snapshot(config["root"], update))
    return None
