"""Translate a validated run into a Beaker experiment and retain its launch receipt.
The specification carries GPU placement, replica coordination, mounts and scheduling
settings into the job; submission records the experiment identity for later queries.
Status reads the newest attempt for each task and replica, and result collection
retains small run artifacts so users can inspect progress and failures after exit.
"""

import base64
import json
import os
import shlex
import subprocess
import tempfile
import uuid
from pathlib import Path
from typing import Any

from open_instruct.miles.configuration import advisories, specs, topology
from open_instruct.miles.configuration import config as miles_config
from open_instruct.miles.distillation import opd_config, opd_launch
from open_instruct.miles.errors import InputError
from open_instruct.miles.execution import workflow

ROOT = Path(__file__).resolve().parents[3]


def receipt_path(spec):
    directory = Path(os.environ.get("MILES_LAUNCH_RECEIPTS", Path.home() / ".cache/open-instruct/miles/launches"))
    key = workflow.fingerprint({"name": spec.name, "root": spec.output["root"]})[:16]
    return directory / f"{spec.name}-{key}.json"


def specification(image, spec, *, hostnames=None, compiled=None):
    if isinstance(spec, opd_config.OPDRunSpec):
        if hostnames is not None:
            raise InputError("OPD uses a single cluster allocation; hostname overrides are unsupported")
        return opd_launch.specification(image, spec)
    config = compiled if compiled is not None else spec.compile()
    layout = topology.plan(spec, config)
    host_networking = layout["replicas"] > 1 or bool(spec.judges["judging"]["bindings"])
    allocated = layout["gpus_per_replica"]
    mounts = spec.launch["weka_mounts"]

    def check_mounts(value, name="run"):
        if isinstance(value, dict):
            for key, child in value.items():
                check_mounts(child, f"{name}.{key}")
        elif isinstance(value, list):
            for index, child in enumerate(value):
                check_mounts(child, f"{name}[{index}]")
        elif (
            isinstance(value, str)
            and value.startswith("/weka/")
            and not any(Path(value).is_relative_to(m["mount_path"]) for m in mounts)
        ):
            raise InputError(
                f"{name} ({value}) requires a corresponding launch.weka_mounts entry; add the WEKA filesystem and its mount_path."
            )

    check_mounts(spec.to_dict())
    if (layout["replicas"] > 1 or spec.evaluation["mode"] == "background") and not any(
        Path(os.path.normpath(spec.output["root"])).is_relative_to(os.path.normpath(mount["mount_path"]))
        for mount in mounts
    ):
        raise InputError(
            "Beaker multi-node runs and background evaluation require output.root inside a shared "
            "launch.weka_mounts entry"
        )
    sensitive = [
        name
        for name in spec.launch["env"]
        if name.upper().endswith(("_TOKEN", "_API_KEY", "_PASSWORD", "_SECRET", "_PRIVATE_KEY", "_ACCESS_KEY"))
    ]
    if sensitive:
        raise InputError(f"Use launch.secrets for credential environment variables: {sorted(sensitive)}")
    payload = base64.b64encode(json.dumps(spec.to_dict()).encode()).decode()
    setup = (
        f"import base64,pathlib; pathlib.Path('/output/submitted-run.json').write_bytes(base64.b64decode({payload!r}))"
    )
    collect = f"from open_instruct.miles.execution.launch import collect_results; collect_results({spec.output['root']!r}, '/output')"
    preflight = ""
    if config.core.attention_backend in miles_config.PREFLIGHT_ATTENTION_BACKENDS:
        preflight = (
            f"python -m open_instruct.miles.execution.preflight_attention --backend {config.core.attention_backend}\n"
        )
    cleanup = "status=$?; python -c " + shlex.quote(collect) + ' || true; exit "$status"'
    workload = preflight + (
        "python -m open_instruct.miles.execution.cluster /output/submitted-run.json"
        if host_networking
        else "python -m open_instruct.miles train /output/submitted-run.json"
    )
    command = (
        "set -euo pipefail\ncd /opt/core-rl\nmkdir -p /output\n"
        f"python -c {shlex.quote(setup)}\n"
        f"trap {shlex.quote(cleanup)} EXIT\n"
        "python -m open_instruct.miles.execution.preflight_network "
        f"--replicas {layout['replicas']} --network-mode {'host' if host_networking else 'bridge'} "
        "-- bash -euo pipefail -c " + shlex.quote(workload) + " 2>&1 | tee /output/run.log\n"
    )
    env = {
        "OI_MILES_LAUNCH_ID": uuid.uuid4().hex,
        "TOKENIZERS_PARALLELISM": "false",
        "OMP_NUM_THREADS": "2",
        "NCCL_CUMEM_ENABLE": "1",
        "HF_HOME": "/tmp/hf-cache",
        "SGLANG_EXTERNAL_MODEL_PACKAGE": "olmo_sglang.models",
        **spec.launch["env"],
    }
    task: dict[str, Any] = dict(
        name=spec.name,
        image={"beaker": image},
        command=["bash", "-c"],
        arguments=[command],
        datasets=[{"mountPath": mount["mount_path"], "source": {"weka": mount["weka"]}} for mount in mounts],
        result={"path": "/output"},
        resources={
            "gpuCount": allocated,
            "memory": spec.launch["memory"],
            "sharedMemory": spec.launch["shared_memory"],
        },
        context={
            "priority": spec.launch["priority"],
            "minRuntime": spec.launch["min_runtime"],
            "autoResume": spec.launch["auto_resume"],
        },
        constraints={"cluster": [spec.launch["cluster"]]},
        timeout=spec.launch["timeout"],
        envVars=[{"name": key, "value": value} for key, value in env.items() if key not in spec.launch["secrets"]]
        + [{"name": key, "secret": value} for key, value in spec.launch["secrets"].items()],
    )
    # Cluster bootstrap advertises the physical node IP for Ray and judges,
    # including single-node runs with judge bindings. That address requires
    # host networking; bridge networking can strand local GCS clients.
    if host_networking:
        task["hostNetworking"] = True
    if layout["replicas"] > 1:
        # The supported multi-node hardware has eight GPUs per physical node.
        # Partial allocations could put two replicas on one host, which the
        # physical-IP placement contract cannot represent.
        if allocated != 8:
            raise InputError(
                "Multi-node Beaker launches require full eight-GPU nodes: set launch.gpus_per_replica=8. "
                "Partial-node replica placement is unsupported."
            )
        task.update(
            replicas=layout["replicas"],
            leaderSelection=True,
            hostNetworking=True,
            propagateFailure=True,
            propagatePreemption=True,
            synchronizedStartTimeout="60m",
        )
    if hostnames is not None:
        if len(hostnames) < layout["replicas"] or len(set(hostnames)) != len(hostnames):
            raise InputError("Launch requires enough distinct physical hostnames")
        # One shared allowlist preserves native replica-group scheduling.
        # Beaker makes cluster and hostname constraints mutually exclusive.
        task["constraints"] = {"hostname": hostnames}
    return dict(
        version="v2", budget=spec.launch["budget"], description=f"MILES/Core researcher run: {spec.name}", tasks=[task]
    )


def collect_results(root, destination):
    """Keep small provenance/metric artifacts in Beaker; checkpoints stay on WEKA."""
    root, destination = Path(root), Path(destination)
    if destination.resolve().is_relative_to(root.resolve()):
        raise InputError("Result destination must be outside the run directory")
    copied = []
    for directory, dirs, files in os.walk(root, followlinks=False):
        # Checkpoint tensor trees and HF descriptors can contain tens of
        # thousands of files. Retain their parent completion manifests only.
        dirs[:] = sorted(
            name
            for name in dirs
            if name not in {"hf", "export-hf", "eval-snapshots", "model"} and not name.startswith(".")
        )
        for name in sorted(files):
            path = Path(directory) / name
            if (
                path.is_symlink()
                or path.suffix not in (".json", ".jsonl", ".log")
                or path.stat().st_size > 32 * 1024 * 1024
            ):
                continue
            relative = path.relative_to(root)
            target = destination / "run" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(path.read_bytes())
            copied.append(str(relative))
    return copied


def run(path, overrides):
    spec = specs.load(path, overrides)
    # Reuse one compilation for allocation, validation and warning output.
    if isinstance(spec, opd_config.OPDRunSpec):
        specification("pending-build", spec)
        planned = spec.plan()
    else:
        compiled = spec.compile()
        specification("pending-build", spec, compiled=compiled)
        planned = spec.plan(compiled)
    advisories.emit(planned)
    with tempfile.TemporaryDirectory(prefix="miles-submitted-run-") as directory:
        frozen = Path(directory) / "run.json"
        workflow.write_json(frozen, spec.to_dict())
        command = ["bash", "./scripts/train/build_image_and_launch.sh", "--miles", str(frozen)]
        subprocess.run(command, cwd=ROOT, check=True)


def submit(image, spec):
    # Resolve aliases before submission so the receipt and task name one image.
    images = json.loads(subprocess.check_output(["beaker", "image", "get", image, "--format", "json"], text=True))
    metadata = images[0] if isinstance(images, list) else images
    resolved_image = metadata["id"]
    compiled = None if isinstance(spec, opd_config.OPDRunSpec) else spec.compile()
    document = specification(resolved_image, spec, compiled=compiled)
    # Preserve the exact submitted source, parameters, and image in the receipt.
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    with tempfile.TemporaryDirectory(prefix="miles-workflow-") as directory:
        path = Path(directory) / "experiment.json"
        workflow.write_json(path, document)
        response = subprocess.check_output(
            ["beaker", "experiment", "create", str(path), "--workspace", spec.launch["workspace"], "--format", "json"],
            text=True,
        )
    experiments = json.loads(response)
    experiment = experiments[0] if isinstance(experiments, list) else experiments
    receipt = dict(
        experiment_id=experiment["id"],
        image=resolved_image,
        requested_image=image,
        revision=revision,
        spec_sha256=workflow.fingerprint(spec.to_dict()),
        spec=spec.to_dict(),
        allocation=spec.allocation() if isinstance(spec, opd_config.OPDRunSpec) else topology.plan(spec, compiled),
        placements=[
            {
                "task": task["name"],
                "hostnames": task["constraints"].get("hostname", []),
                "gpus": task["resources"]["gpuCount"],
                "replicas": task.get("replicas", 1),
            }
            for task in document["tasks"]
        ],
    )
    target = receipt_path(spec)
    if target.exists():
        old = json.loads(target.read_text())
        workflow.write_json(target.with_name(f"{target.stem}-{old['experiment_id']}.json"), old)
    workflow.write_json(target, receipt)
    print(
        json.dumps({**receipt, "receipt": str(target), "url": f"https://beaker.org/ex/{experiment['id']}"}, indent=2)
    )
    return receipt


def _job_summary(job):
    summary = {key: job[key] for key in ("id", "name", "execution", "status", "node", "requests") if key in job}
    details = job.get("status", {})
    code = details.get("exitCode")
    if details.get("canceled"):
        # Beaker CLI emits numeric cancellation codes. Also accept protobuf JSON names.
        cancellation = details.get("canceledCode")
        if cancellation in (
            1,
            2,
            9,
            "CANCELATION_CODE_SYSTEM_PREEMPTION",
            "CANCELATION_CODE_USER_PREEMPTION",
            "CANCELATION_CODE_SIBLING_TASK_PREEMPTION",
        ):
            state = "preempted"
        elif cancellation in (
            6,
            10,
            11,
            "CANCELATION_CODE_NODE_UNAVAILABLE",
            "CANCELATION_CODE_HEALTHCHECK_FAILED",
            "CANCELATION_CODE_SIBLING_TASK_RETRY",
        ):
            state = "interrupted"
        else:
            state = "canceled"
        reason = details.get("canceledFor") or details.get("message")
    else:
        reason = details.get("message") or details.get("failedSchedulingMessage")
        if details.get("failed") or (code is not None and code != 0):
            state = "failed"
        elif code == 0:
            state = "succeeded"
        elif details.get("exited") or details.get("finalized"):
            # Stopped, but Beaker has not supplied a success/failure outcome.
            state = "stopped"
        elif details.get("started"):
            state = "running"
        else:
            # A scheduling blocker can be temporary; it does not imply a terminal failure.
            state = "pending"
    return {**summary, "state": state, "reason": reason}


def status(spec):
    target = receipt_path(spec)
    if not target.is_file():
        raise InputError(
            f"No launch receipt: {target}. Launch this run with the run command, or set MILES_LAUNCH_RECEIPTS to the directory holding its receipt."
        )
    receipt = json.loads(target.read_text())
    response = json.loads(
        subprocess.check_output(
            ["beaker", "experiment", "get", receipt["experiment_id"], "--format", "json"], text=True
        )
    )
    experiment = response[0] if isinstance(response, list) else response
    # Return all attempts in chronological order; an older preempted job is not the current status.
    jobs = list(experiment.get("jobs", []))
    if not jobs:
        jobs = [job for task in experiment.get("tasks", []) for job in task.get("jobs", [])]
    jobs.sort(key=lambda job: (job.get("status", {}).get("created", job.get("created", "")), job.get("id", "")))
    jobs = [_job_summary(job) for job in jobs]
    latest_by_replica = {}
    for job in jobs:
        execution = job.get("execution", {})
        key = (execution.get("task") or job.get("name") or "main", execution.get("replicaRank", 0))
        latest_by_replica[key] = job
    current = list(latest_by_replica.values())
    expected = receipt.get("allocation", {}).get("replicas", 1)
    states = {job["state"] for job in current}
    if len(current) == expected and states == {"succeeded"}:
        state = "complete"
    else:
        state = next(
            (
                candidate
                for candidate in ("failed", "canceled", "preempted", "interrupted", "stopped", "running")
                if candidate in states
            ),
            "pending",
        )
    return dict(
        receipt=str(target),
        experiment_id=receipt["experiment_id"],
        url=f"https://beaker.org/ex/{receipt['experiment_id']}",
        config_matches_submission=receipt["spec_sha256"] == workflow.fingerprint(spec.to_dict()),
        state=state,
        auto_resume=receipt.get("spec", {}).get("launch", {}).get("auto_resume"),
        expected_replicas=expected,
        current_jobs=current,
        latest_job=jobs[-1] if jobs else None,
        attempts=jobs,
    )
