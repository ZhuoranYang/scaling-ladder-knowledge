"""Validate judge services and their named rubric bindings in a researcher run file.
The configuration separates managed services, which consume GPUs in the allocation,
from external endpoints and describes how dataset verifier names use each service.
It produces the registry consumed by preparation and reward workers so those stages
agree on model identity, rubric and request limits.
"""

import copy
import re
from urllib.parse import urlsplit

from open_instruct.miles.configuration import constraints, validation
from open_instruct.miles.errors import InputError

REGISTRY_ENV = "OI_MILES_JUDGE_REGISTRY"
DEFAULT_REQUEST_TIMEOUT = 600
PROFILES = {
    "open-instruct/" + name: name
    for name in ("general-quality", "general-quality_ref", "general-web_instruct_general_verifier")
}


def require_binding(name, bindings, verifier_spec=None):
    """Reject judge-dependent data even when the run has no judge configuration."""
    named_factory = "open_instruct.miles.rewards.judge_registry.NamedJudgeVerifier"
    factory = verifier_spec.get("factory") if isinstance(verifier_spec, dict) else None
    if name not in bindings and (name.startswith("general-") or factory == named_factory):
        raise InputError(
            f"Missing named judge binding for verifier {name!r}. "
            f'Configure [judging.bindings."{name}"] with a configured judge and rubric, '
            "or remove the dataset requiring this verifier."
        )


def parse(document):
    judges = copy.deepcopy(document.get("judges", {}))
    rubrics = copy.deepcopy(document.get("rubrics", {}))
    routing = copy.deepcopy(document.get("judging", {}))
    for name, value in (("judges", judges), ("rubrics", rubrics), ("judging", routing)):
        validation.mapping(value, name)
    validation.fields(routing, "judging", constraints.STRUCTURED_FIELDS["judging"])
    bindings = routing.get("bindings", {})
    validation.mapping(bindings, "judging.bindings")
    for name, service in judges.items():
        if not re.fullmatch(r"[a-z][a-z0-9_-]*", name):
            raise InputError("judge names must be lowercase identifiers")
        validation.mapping(service, f"judges.{name}")
        validation.fields(service, f"judges.{name}", constraints.STRUCTURED_FIELDS["judges.NAME"])
        validation.text(service.get("model"), f"judges.{name}.model")
        mode = service.get("mode")
        if mode not in ("managed", "external"):
            raise InputError("judge mode must be managed or external")
        for key, default in (
            ("max_context_length", 40960),
            ("max_concurrent_calls", 16),
            ("timeout", DEFAULT_REQUEST_TIMEOUT),
        ):
            service.setdefault(key, default)
            validation.integer(service[key], f"judges.{name}.{key}")
        if mode == "managed":
            validation.boolean(service.get("cuda_graphs", False), f"judges.{name}.cuda_graphs")
            if service.get("context_extension", "none") not in ("none", "qwen3-yarn-128k"):
                raise InputError("Managed judge context_extension must be none or qwen3-yarn-128k")
            if service.get("context_extension") == "qwen3-yarn-128k" and (
                service["model"] != "Qwen/Qwen3-32B" or service["max_context_length"] > 131072
            ):
                raise InputError("qwen3-yarn-128k requires Qwen/Qwen3-32B with context at most 131072")
            service.setdefault("backend", "sglang")
            service.setdefault("gpus", 1)
            service.setdefault("tensor_parallel_size", 1)
            service.setdefault("chat_template", "qwen3-no-thinking")
            if service["backend"] != "sglang" or service["chat_template"] != "qwen3-no-thinking":
                raise InputError("Managed judges currently support SGLang with qwen3-no-thinking")
            for key in ("gpus", "tensor_parallel_size"):
                validation.integer(service[key], f"judges.{name}.{key}")
            if service["gpus"] != service["tensor_parallel_size"]:
                raise InputError("judge gpus must equal tensor_parallel_size")
            if not re.fullmatch(r"[a-f0-9]{40}", str(service.get("revision", ""))):
                raise InputError("managed judge requires an immutable 40-character revision")
            if not isinstance(service.get("prepared_dir"), str) or not service["prepared_dir"].startswith("/"):
                raise InputError("managed judge requires an absolute prepared_dir cached before GPU allocation")
            if "endpoint" in service:
                raise InputError("The launcher resolves managed judge endpoints")
        else:
            endpoint = urlsplit(service.get("endpoint", ""))
            if (
                endpoint.scheme not in ("http", "https")
                or not endpoint.hostname
                or endpoint.username
                or endpoint.password
            ):
                raise InputError("external judge requires an HTTP(S) endpoint without credentials")
            managed_fields = set(service) & {
                "backend",
                "chat_template",
                "context_extension",
                "cuda_graphs",
                "gpus",
                "prepared_dir",
                "revision",
                "tensor_parallel_size",
            }
            if managed_fields:
                raise InputError(
                    f"external judge cannot specify managed fields in judges.{name}: {', '.join(sorted(managed_fields))}"
                )
    for name, rubric in rubrics.items():
        validation.mapping(rubric, f"rubrics.{name}")
        validation.fields(rubric, f"rubrics.{name}", constraints.STRUCTURED_FIELDS["rubrics.NAME"])
        if rubric.get("profile") not in PROFILES:
            raise InputError("rubric requires a supported open-instruct/general-* profile")
        rubric.setdefault("max_response_tokens", 2048)
        rubric.setdefault("temperature", 1.0)
        validation.integer(rubric["max_response_tokens"], f"rubrics.{name}.max_response_tokens")
        validation.number(rubric["temperature"], f"rubrics.{name}.temperature")
        if rubric["temperature"] < 0:
            raise InputError("rubric temperature must be nonnegative")
    for name, binding in bindings.items():
        validation.mapping(binding, f"binding {name}")
        validation.fields(binding, f"binding {name}", constraints.STRUCTURED_FIELDS["judging.bindings.VERIFIER"])
        if binding.get("judge") not in judges or binding.get("rubric") not in rubrics:
            raise InputError(f"binding {name} references an unknown judge or rubric")
        if rubrics[binding["rubric"]]["max_response_tokens"] >= judges[binding["judge"]]["max_context_length"]:
            raise InputError("judge output reservation must be smaller than its context")
    if judges and not bindings:
        raise InputError("named judges require explicit verifier bindings")
    return {"judges": judges, "rubrics": rubrics, "judging": {"bindings": bindings}}


def registry(sections):
    active = {binding["judge"] for binding in sections["judging"]["bindings"].values()}
    return copy.deepcopy(
        {
            "schema_version": 1,
            "judges": {name: sections["judges"][name] for name in sorted(active)},
            "rubrics": sections["rubrics"],
            "bindings": sections["judging"]["bindings"],
        }
    )
