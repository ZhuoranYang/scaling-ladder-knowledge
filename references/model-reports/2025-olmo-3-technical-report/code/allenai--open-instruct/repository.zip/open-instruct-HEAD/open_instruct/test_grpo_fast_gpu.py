"""GPU tests for generation with tool invocation.

These tests require CUDA and will be skipped if not available.

To run:

    ./scripts/train/build_image_and_launch.sh scripts/test/run_gpu_pytest.sh

Updating expected test data:

When generation behavior changes (due to vLLM/model updates), the determinism tests
will fail. To update the expected data:

1. Delete the outdated expected file(s) from open_instruct/test_data/:
       rm open_instruct/test_data/generation_with_tools_expected.json

2. Commit the deletion:
       git add -A && git commit -m "Remove outdated expected data for regeneration"

3. Run the GPU tests on Beaker:
       ./scripts/train/build_image_and_launch.sh scripts/test/run_gpu_pytest.sh

4. The test will generate new expected data and fail with "Re-run test to verify."
   Get the result dataset ID from the experiment:
       beaker experiment get <EXPERIMENT_ID> --format json | jq -r '.[] | .jobs[0].result.beaker'

5. Fetch the generated file from the result dataset:
       beaker dataset fetch <RESULT_DATASET_ID> --output /tmp/beaker-results
       cp /tmp/beaker-results/test_data/generation_with_tools_expected.json open_instruct/test_data/

6. Commit the new expected file and re-run tests to verify:
       git add -A && git commit -m "Update expected test data"
       ./scripts/train/build_image_and_launch.sh scripts/test/run_gpu_pytest.sh
"""

import inspect
import json
import logging
import pathlib
import subprocess
import time
import unittest

import datasets
import ray
import torch
from packaging import version
from parameterized import parameterized
from ray.util import queue as ray_queue
from ray.util.placement_group import placement_group
from transformers import AutoTokenizer

import open_instruct.vllm_utils as vllm_utils_module
from open_instruct import grpo_utils
from open_instruct.data_types import GenerationResult, PromptRequest
from open_instruct.environments.tools.utils import ParsedEnvConfig
from open_instruct.ground_truth_utils import RewardConfig
from open_instruct.grpo_fast import create_tool_pools
from open_instruct.test_grpo_fast import TestGrpoFastBase
from open_instruct.utils import maybe_update_beaker_description
from open_instruct.vllm_utils import SamplingConfig, create_vllm_engines

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info(f"vllm_utils module file: {vllm_utils_module.__file__}")
logger.info(f"create_vllm_engines signature: {inspect.signature(create_vllm_engines)}")

maybe_update_beaker_description()

TEST_DATA_DIR = pathlib.Path(__file__).parent / "test_data"


class TestGeneration(TestGrpoFastBase):
    """Tests for tool invocation with vLLM."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.server_process = subprocess.Popen(
            ["uv", "run", "uvicorn", "tool_server:app", "--host", "0.0.0.0", "--port", "1212"],
            cwd="open_instruct/environments/tools/servers/python_server",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True,
        )
        time.sleep(3)
        cls.tool_api_endpoint = "http://localhost:1212/execute"

    @classmethod
    def tearDownClass(cls):
        if cls.server_process:
            cls.server_process.terminate()
            try:
                cls.server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                cls.server_process.kill()
                cls.server_process.wait()
        super().tearDownClass()

    def _setup_engine_and_generate(
        self,
        tokenizer_name,
        prompt,
        pools=None,
        tool_definitions=None,
        tool_parser_type="legacy",
        max_steps=None,
        max_tokens=50,
    ):
        """Helper to create vLLM engine and run generation."""
        tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)

        param_prompt_Q = ray_queue.Queue(maxsize=100)
        inference_results_Q = ray_queue.Queue(maxsize=100)
        eval_results_Q = ray_queue.Queue(maxsize=100)
        self._ray_queues.extend([param_prompt_Q, inference_results_Q, eval_results_Q])

        prompt_token_ids = tokenizer.encode(prompt, return_tensors="pt").tolist()[0]
        generation_config = SamplingConfig(temperature=0.0, top_p=1.0, max_tokens=max_tokens, seed=42, logprobs=1)
        request = PromptRequest(
            prompt=prompt_token_ids, index=0, prompt_id="test_0", generation_config=generation_config
        )

        pg = placement_group([{"GPU": 1, "CPU": 1}], strategy="PACK")
        ray.get(pg.ready())

        train_dataset = datasets.Dataset.from_dict(
            {"ground_truth": [["4"]], "dataset": ["test"], "prompt": [prompt], "index": [0]}
        )
        reward_config = RewardConfig()

        engines = create_vllm_engines(
            num_engines=1,
            tensor_parallel_size=1,
            enforce_eager=True,
            tokenizer_name_or_path=tokenizer_name,
            pretrain=tokenizer_name,
            revision="main",
            seed=42,
            enable_prefix_caching=False,
            max_model_len=2048,
            vllm_gpu_memory_utilization=0.5,
            single_gpu_mode=True,
            pg=pg,
            prompt_queue=param_prompt_Q,
            results_queue=inference_results_Q,
            eval_results_queue=eval_results_Q,
            pools=pools or {},
            tool_parser_type=tool_parser_type,
            tool_definitions=tool_definitions,
            max_steps=max_steps or 5,
            reward_config=reward_config,
            train_dataset=train_dataset,
        )

        ray.get(engines[0].ready.remote())
        param_prompt_Q.put(request)
        result = inference_results_Q.get(timeout=120)
        param_prompt_Q.put(None)

        return result

    TOOL_PROMPT = "Write 3 separate Python code blocks. Block 1 prints '1'. Block 2 prints '2'. Block 3 prints '3'. Surround each block with <code> and </code> tags. Execute each separately.\n\nBlock 1: <code>"
    NO_TOOL_PROMPT = "What is 2 + 2? Answer:"

    @parameterized.expand([("with_tools", TOOL_PROMPT, True, 1024), ("without_tools", NO_TOOL_PROMPT, False, 256)])
    @unittest.skipUnless(torch.cuda.is_available(), "CUDA not available")
    def test_generation_deterministic(self, name: str, prompt: str, use_tools: bool, max_tokens: int):
        """Test generation produces expected output and tool invocation behavior."""
        cuda_version = torch.version.cuda
        assert cuda_version is not None
        if not use_tools and version.Version(cuda_version).major == 12:
            test_data_filename = f"generation_{name}_cuda12_expected.json"
        else:
            test_data_filename = f"generation_{name}_expected.json"
        test_data_path = TEST_DATA_DIR / test_data_filename

        tokenizer_name = "Qwen/Qwen3-0.6B"
        pools = None
        tool_definitions = None
        if use_tools:
            pools, _ = create_tool_pools(
                [ParsedEnvConfig(name="python", call_name="code", config={"api_endpoint": self.tool_api_endpoint})],
                pool_size=4,
            )
            # Collect tool definitions from pool for the parser
            actor = ray.get(list(pools.values())[0].acquire.remote())
            tool_definitions = ray.get(actor.get_tool_definitions.remote())
            list(pools.values())[0].release.remote(actor)
        max_steps = 5 if use_tools else None

        result = self._setup_engine_and_generate(
            tokenizer_name=tokenizer_name,
            prompt=prompt,
            pools=pools,
            tool_definitions=tool_definitions,
            max_steps=max_steps,
            max_tokens=max_tokens,
        )

        if use_tools:
            self.assertTrue(
                result.request_info.tool_calleds[0],
                "Tool should have been called when model generates text with stop string.",
            )

        if not test_data_path.exists():
            tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
            test_data = {
                "model": tokenizer_name,
                "seed": 42,
                "temperature": 0.0,
                "prompt": prompt,
                "use_tools": use_tools,
                "expected_token_ids": result.responses[0],
                "expected_text": tokenizer.decode(result.responses[0]),
            }
            test_data_path.write_text(json.dumps(test_data, indent=2))
            self.skipTest(f"Test data generated at {test_data_path}. Re-run test to verify.")

        expected = json.loads(test_data_path.read_text())
        self.assertEqual(result.responses[0], expected["expected_token_ids"])


class TestVLLMQueueSystem(TestGrpoFastBase):
    """Tests for the vLLM queue-based system."""

    @unittest.skipUnless(torch.cuda.is_available(), "CUDA not available")
    def test_vllm_queue_system_single_prompt(self):
        """Test the new queue-based vLLM system with a single prompt 'What is the capital of France?'"""
        tokenizer_name = "Qwen/Qwen3-0.6B"
        tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)

        test_prompt = "What is the capital of France?"
        prompt_token_ids = tokenizer.encode(test_prompt, return_tensors="pt").tolist()[0]

        param_prompt_Q = ray_queue.Queue(maxsize=1)
        inference_results_Q = ray_queue.Queue(maxsize=1)

        self._ray_queues.extend([param_prompt_Q, inference_results_Q])

        train_dataset = datasets.Dataset.from_dict(
            {"ground_truth": [["Paris"]], "dataset": ["test"], "prompt": [test_prompt], "index": [0]}
        )
        reward_config = RewardConfig()

        engines = create_vllm_engines(
            num_engines=1,
            tensor_parallel_size=1,
            enforce_eager=True,
            tokenizer_name_or_path=tokenizer_name,
            pretrain=tokenizer_name,
            revision="main",
            seed=42,
            enable_prefix_caching=False,
            max_model_len=2048,
            vllm_gpu_memory_utilization=0.5,
            prompt_queue=param_prompt_Q,
            results_queue=inference_results_Q,
            reward_config=reward_config,
            train_dataset=train_dataset,
        )

        ray.get(engines[0].ready.remote())
        generation_config = SamplingConfig(temperature=0.0, top_p=1.0, max_tokens=5, seed=42)
        request = PromptRequest(
            prompt=prompt_token_ids, index=0, prompt_id="test_0", generation_config=generation_config
        )

        param_prompt_Q.put(request)
        result = inference_results_Q.get()

        self.assertIsInstance(result, GenerationResult)

        self.assertGreater(len(result.responses), 0)
        response_ids = result.responses[0]

        generated_text = tokenizer.decode(response_ids, skip_special_tokens=True)

        self.assertIsInstance(generated_text, str)
        self.assertGreater(len(generated_text), 0)

        param_prompt_Q.put(None)


def _has_flash_attn_2() -> bool:
    try:
        import flash_attn  # noqa: F401, PLC0415

        return torch.cuda.is_available()
    except ImportError:
        return False


@unittest.skipUnless(_has_flash_attn_2(), "flash_attention_2 + CUDA required")
class TestPackedSequenceLogprobs(unittest.TestCase):
    """Verify that attention_mask=None with packed position_ids produces
    the same logprobs as running each sub-sequence independently.

    This only holds with flash_attention_2, which constructs the intra-document
    mask from position_ids. sdpa and eager attention ignore position resets and
    will apply the full causal mask across the pack.
    """

    def _get_model_and_tokenizer(self):
        from transformers import AutoModelForCausalLM  # noqa: PLC0415

        model_name = "hf-internal-testing/tiny-random-LlamaForCausalLM"
        try:
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            model = AutoModelForCausalLM.from_pretrained(
                model_name, attn_implementation="flash_attention_2", dtype=torch.bfloat16
            ).cuda()
        except Exception as e:
            self.skipTest(f"Could not load model {model_name}: {e}")
        model.eval()
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token_id = tokenizer.eos_token_id or 0
        return model, tokenizer

    def test_packed_matches_individual(self):
        model, tokenizer = self._get_model_and_tokenizer()

        seq_a = torch.tensor([[5, 10, 15, 20]], dtype=torch.long, device="cuda")
        seq_b = torch.tensor([[7, 14, 21]], dtype=torch.long, device="cuda")

        with torch.no_grad():
            logprob_a, _ = grpo_utils.forward_for_logprobs(
                model,
                seq_a,
                None,
                torch.arange(seq_a.shape[1], device="cuda").unsqueeze(0),
                pad_token_id=tokenizer.pad_token_id,
                temperature=1.0,
            )
            logprob_b, _ = grpo_utils.forward_for_logprobs(
                model,
                seq_b,
                None,
                torch.arange(seq_b.shape[1], device="cuda").unsqueeze(0),
                pad_token_id=tokenizer.pad_token_id,
                temperature=1.0,
            )

            packed = torch.cat([seq_a, seq_b], dim=1)
            packed_position_ids = torch.cat(
                [torch.arange(seq_a.shape[1], device="cuda"), torch.arange(seq_b.shape[1], device="cuda")], dim=0
            ).unsqueeze(0)

            logprob_packed, _ = grpo_utils.forward_for_logprobs(
                model, packed, None, packed_position_ids, pad_token_id=tokenizer.pad_token_id, temperature=1.0
            )

        a_len = seq_a.shape[1] - 1
        b_len = seq_b.shape[1] - 1

        # seq_a portion should match logprob_a
        torch.testing.assert_close(logprob_packed[:, :a_len], logprob_a, rtol=1e-2, atol=1e-2)
        # seq_b portion should match logprob_b (would differ if mask wasn't applied per-document)
        torch.testing.assert_close(logprob_packed[:, -b_len:], logprob_b, rtol=1e-2, atol=1e-2)


if __name__ == "__main__":
    unittest.main()
