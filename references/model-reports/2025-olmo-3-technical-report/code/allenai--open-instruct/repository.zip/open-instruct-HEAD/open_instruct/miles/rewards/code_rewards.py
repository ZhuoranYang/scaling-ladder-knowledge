#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Score generated Python programs through an external code-execution service.
The adapter extracts the submitted code, sends its tests to the service and turns
pass results into the existing Open Instruct reward, including the optional runtime
penalty. Bounded HTTP retries and per-response diagnostics distinguish failed tests
from service failures, with zero reward or an exception according to the configured
failure policy.
"""

from __future__ import annotations

import asyncio
import math
import os
import re
import time
from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any

import requests

from open_instruct import logger_utils
from open_instruct.miles.infrastructure import infra_timeouts
from open_instruct.miles.rewards import service

logger = logger_utils.setup_logger(__name__)

_CODE_BLOCK_PATTERN = re.compile(r"```(?:python)?(.*?)```", re.DOTALL)


@dataclass(frozen=True, kw_only=True)
class CodeVerifierConfig:
    """Validated execution-service settings for one code verifier call."""

    api_url: str
    max_execution_time: float
    pass_rate_reward_threshold: float
    apply_perf_penalty: bool
    failure_policy: str = "zero"


def extract_python_code(model_output: str) -> str:
    """Return the last fenced Python block, or the complete response."""
    matches = _CODE_BLOCK_PATTERN.findall(model_output)
    return matches[-1].strip() if matches else model_output


def code_verifier_config(args: Any, *, stdio: bool = False) -> CodeVerifierConfig:
    """Resolve code verifier settings from compatible args and environment."""
    url = getattr(args, "code_api_url", None) or os.environ.get("OI_MILES_CODE_API_URL")
    if not url:
        base = os.environ.get("CODE_API_URL", "http://localhost:1234").rstrip("/")
        url = f"{base}/test_program"
    if stdio:
        if not str(url).endswith("/test_program"):
            raise ValueError("code_stdio requires a code API URL ending in /test_program")
        url = str(url)[: -len("/test_program")] + "/test_program_stdio"
    max_execution_time = service.number_setting(
        args, "code_max_execution_time", "OI_MILES_CODE_MAX_EXECUTION_TIME", 1.0
    )
    threshold = service.number_setting(
        args, "code_pass_rate_reward_threshold", "OI_MILES_CODE_PASS_RATE_REWARD_THRESHOLD", 0.0
    )
    if max_execution_time <= 0:
        raise ValueError("OI_MILES_CODE_MAX_EXECUTION_TIME must be positive")
    if not 0 <= threshold <= 1:
        raise ValueError("OI_MILES_CODE_PASS_RATE_REWARD_THRESHOLD must be between zero and one")
    failure_policy = getattr(args, "code_failure_policy", None)
    if failure_policy is None:
        failure_policy = os.environ.get("OI_MILES_CODE_FAILURE_POLICY", "zero")
    if failure_policy not in {"zero", "raise"}:
        raise ValueError("OI_MILES_CODE_FAILURE_POLICY must be 'zero' or 'raise'")
    return CodeVerifierConfig(
        api_url=str(url),
        failure_policy=failure_policy,
        max_execution_time=max_execution_time,
        pass_rate_reward_threshold=threshold,
        apply_perf_penalty=service.bool_setting(
            args, "code_apply_perf_penalty", "OI_MILES_CODE_APPLY_PERF_PENALTY", False
        ),
    )


# The code service is an external API gateway that returns transient 5xx errors
# under load. urllib3 retries only idempotent methods by default, so the scoring
# POSTs must be allowed explicitly; the backoff grows 1, 2, 4 seconds. With the
# 30-second request timeout, a dead gateway costs at most about two minutes per
# sample before the configured failure policy applies. The earlier eight-retry
# budget took 517-530 seconds per failed sample and stalled whole prompt groups.
RETRY = requests.adapters.Retry(
    total=3,
    backoff_factor=1.0,
    status_forcelist=[502, 503, 504],
    allowed_methods=frozenset({"GET", "POST"}),
    raise_on_status=False,
)
# Worst-case seconds one sample can spend inside the HTTP layer at the default
# 30-second timeout: (total + 1) attempts plus the exponential backoff sleeps.
RETRY_WORST_CASE_SECONDS = (RETRY.total + 1) * 30.0 + sum(
    min(RETRY.backoff_factor * 2**i, 120) for i in range(RETRY.total)
)


# HTTP 500 is not in the session retry list because this harness can also return it
# for a program error, which no retry fixes. In RL runs, though, 4.0-4.9% of calls
# returned 500 and 8 of 8 replayed programs then returned 200: most are transient
# service faults that scored a correct sample zero. Repeat a 500 a few times, with
# these sleeps between attempts, and reject the sample only if every attempt fails.
HTTP_500_RETRY_SLEEPS = (1.0, 2.0)


def _get_session() -> Any:
    return service.http_session(pool_size=100, retries=RETRY)


def _score_response(result: Any, *, config: CodeVerifierConfig) -> float:
    if not isinstance(result, dict):
        raise RuntimeError("code service response must be an object")
    passes = result.get("results")
    if not isinstance(passes, list):
        raise RuntimeError("code service response requires a results list")
    if any(isinstance(value, bool) is False and not isinstance(value, int | float) for value in passes):
        raise RuntimeError("code service results must be numeric")
    pass_rate = sum(float(value) for value in passes) / len(passes) if passes else 0.0
    score = 0.0 if pass_rate < config.pass_rate_reward_threshold else pass_rate
    if not config.apply_perf_penalty or score <= 0:
        return score
    runtimes = result.get("runtimes")
    if not isinstance(runtimes, list) or len(runtimes) != len(passes):
        raise RuntimeError("performance-penalized code rewards require aligned runtimes")
    penalized = [
        float(passed) * (config.max_execution_time - float(runtime)) / config.max_execution_time
        for passed, runtime in zip(passes, runtimes, strict=True)
    ]
    return sum(penalized) / len(penalized) if penalized else 0.0


async def code_score(args: Any, prediction: str, target: Any, *, stdio: bool = False) -> float:
    """Execute one completion against its tests and return its pass-rate reward."""
    score, _ = await execute(args, prediction, target, stdio=stdio)
    return score


async def execute(args: Any, prediction: str, target: Any, *, stdio: bool = False) -> tuple[float, dict]:
    """Score one completion and describe the service outcome for per-sample diagnostics."""
    config = code_verifier_config(args, stdio=stdio)
    program = extract_python_code(prediction)
    payload = {"program": program, "tests": target, "max_execution_time": config.max_execution_time}
    timeout = max(30.0, min(300.0, config.max_execution_time * 10))

    diagnostics = {
        "status": "ok",
        "http_status": None,
        "http_500_retries": 0,
        "program_chars": len(program),
        "tests": len(target) if isinstance(target, list) else -1,
        "stdio": stdio,
        "failure_policy": config.failure_policy,
    }

    def post() -> Any:
        response = infra_timeouts.request(
            _get_session(),
            "post",
            config.api_url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=timeout,
        )
        diagnostics["http_status"] = response.status_code
        return response

    def request() -> Any:
        try:
            response = post()
            for retry, sleep in enumerate(HTTP_500_RETRY_SLEEPS, start=1):
                if response.status_code != 500:
                    break
                time.sleep(sleep)
                diagnostics["http_500_retries"] = retry
                response = post()
            response.raise_for_status()
            return response.json()
        except requests.HTTPError as error:
            status = getattr(error.response, "status_code", None)
            if status is not None and (400 <= status < 500 and status != 429 or status == 500):
                # Preserve the existing rejection category for client errors
                # and an HTTP 500 that persisted through HTTP_500_RETRY_SLEEPS
                # (this harness can emit 500 for program errors). HTTP status
                # alone does not establish the underlying cause.
                # Gateway and transport failures use the
                # configured failure policy after the HTTP retries finish.
                logger.warning(
                    "code verifier rejected a sample with HTTP %s (program %d chars, %d tests); scoring it zero",
                    status,
                    len(program),
                    len(target) if isinstance(target, list) else -1,
                )
                diagnostics["status"] = "rejected"
                return {"results": []}
            raise

    started = time.monotonic()
    stage = "request"
    try:
        result = await asyncio.to_thread(request)
        stage = "response"
        score = _score_response(result, config=config)
        if not math.isfinite(score):
            raise RuntimeError(f"code verifier returned non-finite score {score!r}")
    except Exception as error:
        # Match original Open Instruct's continue-with-zero behavior, while
        # distinguishing missing/invalid grading from an actual failed test.
        # Config validation stays outside this try; cancellation is not caught.
        diagnostics.update(
            status="service_error", error_stage=stage, error_type=type(error).__name__, error=str(error)[:1000]
        )
        if config.failure_policy == "raise":
            raise RuntimeError(f"code verifier request failed for {config.api_url}: {error}") from error
        logger.warning(
            "code verifier service failure after %.2fs; assigning zero reward and continuing: %s",
            time.monotonic() - started,
            diagnostics,
        )
        score = 0.0
    finally:
        diagnostics["elapsed_seconds"] = time.monotonic() - started
    return score, diagnostics


@dataclass
class ServiceConfig:
    api_url: str
    stdio: bool = False
    max_execution_time: float = 1.0
    pass_rate_reward_threshold: float = 0.99
    failure_policy: str | None = None


class CodeVerifier:
    get_config_class = staticmethod(lambda: ServiceConfig)

    def __init__(self, verifier_config):
        self.config = verifier_config

    async def async_call(self, tokens, prediction, label, **kwargs):
        args = SimpleNamespace(
            code_api_url=self.config.api_url,
            code_failure_policy=self.config.failure_policy,
            code_max_execution_time=self.config.max_execution_time,
            code_pass_rate_reward_threshold=self.config.pass_rate_reward_threshold,
        )
        score, diagnostics = await execute(args, prediction, label, stdio=self.config.stdio)
        return SimpleNamespace(score=score, cost=0.0, diagnostics=diagnostics)
