import dataclasses
from dataclasses import dataclass, field
from typing import Any

import torch


class ShutdownSentinel:
    """Sentinel value to signal thread shutdown via queue."""


@dataclass
class TokenStatistics:
    """Container for token statistics from inference."""

    num_prompt_tokens: int
    num_response_tokens: int
    generation_time: float
    earliest_start_time: float | None = None


@dataclass
class ToolCallStats:
    """Statistics for a single tool call."""

    tool_name: str
    success: bool
    runtime: float


@dataclass
class RequestInfo:
    """Container for tool usage information used in queue payloads."""

    num_calls: list[int]
    timeouts: list[int]
    tool_errors: list[str]
    tool_outputs: list[str]
    tool_runtimes: list[float]
    tool_calleds: list[bool]
    tool_call_stats: list[list[ToolCallStats]] = field(default_factory=list)
    rollout_states: list[dict] = field(default_factory=list)
    """Per-sample rollout state dicts (rewards, step_count, done, info) — always present."""


@dataclass
class GenerationResult:
    """Container for generation results returned via Ray queues."""

    responses: list[list[int]]
    finish_reasons: list[str]
    masks: list[list[int]]
    request_info: RequestInfo
    index: int | None
    prompt_id: str | None
    token_statistics: TokenStatistics | None = None
    start_time: float = 0.0
    logprobs: list[list[float]] = field(default_factory=list)
    reward_scores: list[float] | None = None
    reward_metrics: dict[str, Any] | None = None
    model_step: int = 0


@dataclass
class EnvConfigEntry:
    """Entry for a single environment configuration."""

    env_name: str
    is_text_env: bool
    kwargs: dict[str, Any] = field(default_factory=dict)


@dataclass
class EnvConfig:
    """Wrapper for environment configuration + related metadata."""

    max_steps: int = 100
    env_configs: dict[str, EnvConfigEntry] = field(default_factory=dict)
    """Mapping from env_name to its configuration entry."""


@dataclass
class PromptRequest:
    """Container for prompt requests sent via Ray queues.

    Note: We intentionally type `generation_config` as `Any` to avoid importing
    heavy dependencies (e.g., vLLM) at import time in deserializers like Ray's
    `_QueueActor`.
    """

    prompt: list[int]
    generation_config: Any
    index: int
    prompt_id: str
    is_eval: bool = False
    active_tools: list[str] | None = None
    """List of tool names that are active for this sample. If None, all tools are active."""
    env_config: EnvConfig = field(default_factory=EnvConfig)
    ground_truth: Any = None
    """Optional ground truth override (e.g. from evolving rubrics). When set, the vLLM
    engine uses this instead of looking up the ground truth from the dataset."""


@dataclass
class CollatedBatchData:
    """Container for collated batch data passed to training workers."""

    query_responses: list[torch.Tensor]
    attention_masks: list[torch.Tensor]
    position_ids: list[torch.Tensor]
    advantages: list[torch.Tensor]
    response_masks: list[torch.Tensor]
    vllm_logprobs: list[torch.Tensor]

    def __getitem__(self, idx: int | slice) -> "CollatedBatchData":
        return CollatedBatchData(**{f.name: getattr(self, f.name)[idx] for f in dataclasses.fields(self)})

    def __len__(self) -> int:
        return len(self.query_responses)

    def to(self, device: torch.device, non_blocking: bool = True) -> "CollatedBatchData":
        return dataclasses.replace(
            self,
            **{
                f.name: [t.to(device, non_blocking=non_blocking) for t in getattr(self, f.name)]
                for f in dataclasses.fields(self)
            },
        )
