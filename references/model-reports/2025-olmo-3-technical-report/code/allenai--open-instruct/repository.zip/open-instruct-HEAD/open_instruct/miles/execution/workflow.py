"""Execute the preparation, training and export stages described by a run file.
The workflow prepares model and data artifacts, records their identities and tracks
attempts so recovery can reuse compatible outputs and reject changed inputs. GPU
runtime parsing and training are deferred until execution, keeping the same run
specification usable for planning and submission on a CPU-only machine.
"""

import asyncio
import copy
import fcntl
import hashlib
import importlib
import json
import os
import shutil
import sys
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

from open_instruct import logger_utils
from open_instruct.miles.configuration import advisories, inference_profiles, topology
from open_instruct.miles.errors import InputError
from open_instruct.miles.evaluation import evaluation
from open_instruct.miles.infrastructure import artifacts
from open_instruct.miles.rewards import judging

logger = logger_utils.setup_logger(__name__)


def write_json(path, document):
    artifacts.atomic_json(Path(path), document)


def fingerprint(document):
    # OPD checkpoint retention is operational, and its empty native override
    # table was historically optional. Preserve that run identity on resume.
    if isinstance(document, dict) and document.get("training", {}).get("algorithm") == "opd":
        document = {key: value for key, value in document.items() if not (key == "miles" and value == {})}
        document["training"] = {key: value for key, value in document["training"].items() if key != "keep_checkpoints"}
    return hashlib.sha256(json.dumps(document, sort_keys=True).encode()).hexdigest()


def recovery_configuration_matches(root, previous, document):
    """Allow recovery policy changes and normalize historical launch defaults.

    Authenticate the recorded full specification before normalizing it, including
    older runs that hashed auto_resume or predate the explicit host-memory field.
    """
    if previous["spec_sha256"] == fingerprint(document):
        return True
    path = Path(root) / "run-spec.json"
    if not path.is_file():
        return False
    recorded = json.loads(path.read_text())
    if fingerprint(recorded) != previous["spec_sha256"]:
        return False
    if "memory" in document["launch"]:
        # Launchers requested this amount before it became a configurable field.
        # Do not use current loader defaults: this authenticates the historical
        # resource commitment even if future launch defaults change.
        # Preserve explicit saved values so actual resource changes still fail.
        recorded.setdefault("launch", {}).setdefault("memory", "256 GiB")
    for key in ("auto_resume", "max_retries"):
        if key in document["launch"]:
            recorded.setdefault("launch", {})[key] = document["launch"][key]
    return recorded == document


def record_attempt(root, limit):
    """Append this start to the run's attempt ledger, refusing once the cap is reached.

    Beaker restarts a preempted task without limit, so a run that is preempted before it
    can save advances nothing and restarts forever. Each restart is a fresh process with
    no memory of the last, so the ledger on the shared filesystem is the only thing that
    can count them.

    `limit` counts *retries*, so the first start is never refused and -1 disables the cap.
    It counts every restart, including ones that made progress; a cap on unproductive
    restarts alone would need the checkpoint state, which is not resolved this early.
    """
    path = Path(root) / "attempts.json"
    attempts = json.loads(path.read_text()) if path.is_file() else []
    if limit >= 0 and len(attempts) > limit:
        raise InputError(
            f"Run reached launch.max_retries={limit} after {len(attempts)} starts: {root}. "
            "Raise launch.max_retries to allow more, or choose a new output.root."
        )
    attempts.append(dict(attempt=len(attempts), started_unix=time.time()))
    write_json(path, attempts)
    return attempts


def model_identity(source):
    """Record checkpoint metadata and shard identity without hashing tens of GB."""
    source = Path(source)
    if not source.is_dir():
        raise InputError(
            f"Model directory does not exist: {source}. Check model.source and its mount in launch.weka_mounts."
        )
    files = []
    for path in sorted(source.rglob("*")):
        if not path.is_file() or path.name == "workflow-model.json":
            continue
        stat = path.stat()
        item = dict(path=str(path.relative_to(source)), size=stat.st_size, mtime_ns=stat.st_mtime_ns)
        if path.suffix in (".json", ".jinja") or path.name == ".metadata":
            item["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        files.append(item)
    if not files:
        raise InputError(f"Empty model directory: {source}")
    return dict(path=str(source), files=files)


def prepare_model(spec):
    source = Path(spec.model["source"])
    target = Path(spec.conversion["hf_output"])
    if source.resolve() == target.resolve() or source.resolve() in target.resolve().parents:
        raise InputError("Prepared model output must not be inside its read-only source")
    template = spec.model.get("hf_template")
    identity = dict(source=model_identity(source), format=spec.model["format"], conversion=spec.conversion)
    if template:
        template_path = Path(template)
        if not template_path.exists():
            raise InputError(
                f"model.hf_template not found: {template}. Check the path and the job's WEKA mounts; "
                "omit hf_template to use the checkpoint's own tokenizer and chat template."
            )
        if template_path.is_dir():
            if not any((template_path / name).is_file() for name in ("tokenizer.json", "tokenizer_config.json")):
                raise InputError(
                    f"model.hf_template directory has no tokenizer assets (tokenizer.json or tokenizer_config.json): "
                    f"{template}"
                )
        elif template_path.suffix != ".jinja":
            raise InputError(f"model.hf_template must be a tokenizer directory or a .jinja chat template: {template}")
        identity["template"] = (
            model_identity(template)
            if Path(template).is_dir()
            else {"path": template, "sha256": hashlib.sha256(Path(template).read_bytes()).hexdigest()}
        )
    marker = target / "workflow-model.json"
    if marker.exists():
        recorded = json.loads(marker.read_text())
        if recorded["identity"] != identity:
            raise InputError("Prepared model identity changed; choose a new output.root")
        if recorded.get("prepared_files") != model_identity(target)["files"]:
            raise InputError("Prepared model files changed or lack an integrity inventory")
        return str(target)
    if target.exists():
        raise InputError(
            f"Refusing to adopt an incomplete or unrelated prepared model: {target}. Choose a new output.root."
        )
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = target.with_name(f".{target.name}.preparing-{uuid.uuid4().hex}")
    staging.mkdir()
    try:
        if spec.model["format"] == "hf":
            if not (source / "config.json").is_file() or not list(source.glob("*.safetensors")):
                raise InputError(f"Expected an HF config and safetensors weights in {source}")
            for path in source.iterdir():
                if path.name == "workflow-model.json":
                    continue
                destination = staging / path.name
                if path.is_file() and path.suffix == ".safetensors":
                    destination.symlink_to(path.resolve())
                elif path.is_dir():
                    shutil.copytree(path, destination, symlinks=False)
                else:
                    # Tokenizer.save_pretrained overwrites these files. Never
                    # allow those writes to follow a link into the source.
                    shutil.copy2(path, destination)
        else:
            _convert_native(spec, staging)
        if template:
            template_path = Path(template)
            if template_path.is_dir():
                tokenizer_utils = importlib.import_module("open_instruct.tokenizer_utils")
                tokenizer = tokenizer_utils.load_tokenizer(template_path, trust_remote_code=True)
                # A stale standalone template overrides tokenizer_config in
                # Transformers. Remove only our copied templates before saving.
                (staging / "chat_template.jinja").unlink(missing_ok=True)
                if (staging / "chat_templates").exists():
                    shutil.rmtree(staging / "chat_templates")
                tokenizer.save_pretrained(staging)
                # Stop-token ids belong with the template (Olmo 3.5 ends answers
                # with eos but tool calls with <|im_end|>); carry them along.
                if (template_path / "generation_config.json").is_file():
                    shutil.copyfile(template_path / "generation_config.json", staging / "generation_config.json")
                rendered = tokenizer.chat_template or ""
            else:
                shutil.copyfile(template_path, staging / "chat_template.jinja")
                rendered = template_path.read_text()
            for placeholder in ("[CUTOFF_DATE]",):
                if placeholder in rendered:
                    logger.warning(
                        "Chat template %s contains the literal placeholder %s; every prompt will render it verbatim",
                        template_path,
                        placeholder,
                    )
        if model_identity(source) != identity["source"]:
            raise InputError("Source model changed during preparation")
        write_json(staging / marker.name, {"identity": identity, "prepared_files": model_identity(staging)["files"]})
        staging.rename(target)
    except BaseException:
        # Retain a failed conversion for inspection; never present it as complete.
        raise
    return str(target)


def _convert_native(spec, target):
    converter = importlib.import_module("olmo_core.nn.hf.convert_checkpoint")
    core_config = importlib.import_module("olmo_core.config")
    torch = importlib.import_module("torch")
    saved = converter.load_config(spec.model["source"])
    if not saved or "model" not in saved or "dataset" not in saved:
        raise InputError("Native input must include its saved model and tokenizer configuration")
    converter.convert_checkpoint_to_hf(
        spec.model["source"],
        target,
        copy.deepcopy(saved["model"]),
        copy.deepcopy(saved["dataset"]["tokenizer"]),
        dtype=core_config.DType(spec.conversion.get("dtype", "bfloat16")),
        max_sequence_length=spec.compile().core.max_sequence_length,
        device=torch.device(spec.conversion.get("device", "cpu")),
        validate=False,
    )


def parse_runtime(config):
    try:
        native = importlib.import_module("miles.utils.arguments")
    except ModuleNotFoundError as error:
        if error.name not in {"miles", "miles.utils", "miles.utils.arguments"}:
            raise
        raise InputError(
            "MILES is not installed in this environment. Use plan for local config checks; validate/train require the pinned MILES/Core runtime image."
        ) from error
    original = sys.argv
    try:
        sys.argv = [original[0], *config.arguments()]
        args = native.parse_args()
    finally:
        sys.argv = original
    if args.train_backend != "olmo_core":
        raise InputError(
            "This MILES installation does not select the olmo_core backend; use the pinned MILES/Core runtime image built by scripts/train/build_image_and_launch.sh --miles."
        )
    if args.load:
        checkpoint = importlib.import_module("miles.backends.core_utils.checkpoint")
        _, manifest = checkpoint.resume_manifest(args.load)
        args.start_rollout_id = manifest["clock"]["next_rollout_id"]
    return args


def train_config(config, *, export_hf=None, background_evaluation=None):
    args = parse_runtime(config)
    args.background_evaluation = background_evaluation
    args.core_evaluation_snapshot = (
        "open_instruct.miles.evaluation.evaluation.training_snapshot" if background_evaluation else None
    )
    os.environ.setdefault("SGLANG_EXTERNAL_MODEL_PACKAGE", "olmo_sglang.models")
    driver = importlib.import_module("open_instruct.miles.execution.driver")
    return asyncio.run(driver.train(args, export_hf=export_hf))


@contextmanager
def run_directory(spec):
    root = Path(spec.output["root"])
    root.mkdir(parents=True, exist_ok=True)
    with (root / ".workflow.lock").open("a") as stream:
        try:
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise InputError(
                f"Another process owns this run: {root}. Wait for it to finish or choose a different output.root. "
                "If the previous node disappeared, check the previous attempt and shared-filesystem lock "
                "recovery before retrying; ownership may not yet have been released. "
                "Do not delete the lock file to bypass an active or recovering lock."
            ) from error
        document = spec.to_dict()
        identity = fingerprint(document)
        path = root / "workflow.json"
        if path.exists():
            previous = json.loads(path.read_text())
            if not recovery_configuration_matches(root, previous, document):
                raise InputError("Run configuration changed; choose a new output.root")
            if previous["status"] == "complete":
                raise InputError(f"Run already completed: {root}. Choose a new output.root for another run.")
            if not spec.launch["auto_resume"]:
                raise InputError(
                    f"Run already exists and launch.auto_resume is false: {root}. "
                    "Set launch.auto_resume=true to resume, or choose a new output.root."
                )
        # Runs recorded before this field existed carry no cap, and resuming one must not
        # depend on the field being present in the older specification.
        attempts = record_attempt(root, spec.launch.get("max_retries", -1))
        state = dict(spec_sha256=identity, status="preparing", started_unix=time.time(), attempt=len(attempts) - 1)
        write_json(root / "run-spec.json", document)
        write_json(root / "plan.json", spec.plan())
        write_json(path, state)
        try:
            yield root, state
        except BaseException as error:
            state.update(status="failed", error=f"{type(error).__name__}: {error}", finished_unix=time.time())
            write_json(path, state)
            raise


def execute(spec):
    with run_directory(spec) as (root, state):
        hf = prepare_model(spec)
        data = importlib.import_module("open_instruct.miles.datasets.run_data")
        planned = spec.compile({"hf_checkpoint": hf})
        prepared = data.prepare_data(
            spec.data,
            Path(hf),
            root / "prepared" / "data",
            max_prompt_length=planned.miles.get("rollout_max_prompt_len", 2048),
            seed=planned.miles.get("seed", 17),
            registry_overrides={
                name: {
                    "factory": "open_instruct.miles.rewards.judge_registry.NamedJudgeVerifier",
                    "config": {"name": name},
                }
                for name in spec.judges["judging"]["bindings"]
            },
        )
        registry_module = importlib.import_module("open_instruct.miles.rewards.judge_registry")
        resolved = judging.registry(spec.judges)
        if spec.judges["judging"]["bindings"]:
            resolved = registry_module.registry()
            if resolved is None:
                raise InputError("Named judges require the managed launcher (or a resolved registry)")
        registry_module.validate_data(prepared, resolved)
        config = spec.compile({**prepared, "hf_checkpoint": hf})
        profile = getattr(config, "inference_profile", None)
        inventory_root = os.environ.get("OI_MILES_INFERENCE_REPORT_DIR")
        if profile and profile.get("selected") in inference_profiles.PROFILES:
            layout = topology.plan(spec, config)
            if inventory_root:
                hardware = inference_profiles.check_cluster_hardware(profile, inventory_root, layout)
            elif layout["replicas"] == 1:
                hardware = inference_profiles.check_hardware(profile, node=layout["nodes"][0])
            else:
                raise InputError(
                    "A matched multi-node inference profile requires per-replica GPU inventories; "
                    "use the managed cluster launcher instead of direct train."
                )
        else:
            hardware = []
        write_json(root / "inference-profile.json", {"profile": profile, "hardware": hardware})
        checkpoint_root = Path(config.miles["save"])
        if spec.launch["auto_resume"] and (checkpoint_root / "core-latest.json").exists():
            config.miles["load"] = str(checkpoint_root)
        resolved_plan = config.plan()
        write_json(root / "resolved-plan.json", resolved_plan)
        advisories.emit(resolved_plan)
        state.update(status="training", training_started_unix=time.time())
        write_json(root / "workflow.json", state)
        result = train_config(
            config,
            export_hf=spec.output["hf_dir"] if spec.output["export_hf"] else None,
            **(
                {"background_evaluation": evaluation.runtime(spec, config.miles)}
                if spec.evaluation["mode"] == "background"
                else {}
            ),
        )
        # A deliberate debug exit is successful execution, not a completed run.
        completed = result.get("completed_rollout_ids") if result else None
        complete = (
            completed is None
            or bool(result.get("stopped_for_time"))
            or ((completed[-1] + 1 if completed else result["start_rollout_id"]) == config.miles.get("num_rollout"))
        )
        state.update(status="complete" if complete else "stopped", finished_unix=time.time(), result=result)
        write_json(root / "workflow.json", state)
        return state
