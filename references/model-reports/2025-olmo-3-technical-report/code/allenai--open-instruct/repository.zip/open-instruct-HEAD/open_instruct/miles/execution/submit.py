"""Submit the run file once the committed-image wrapper has selected its image.
This small command-line bridge loads the configuration and overrides, then either
renders the Beaker specification for inspection or passes it to the launch module.
Keeping image construction outside this step allows the same submission code to
use a newly built image or an explicitly reused one.
"""

import argparse
import json
from pathlib import Path

from open_instruct.miles.configuration import specs
from open_instruct.miles.execution import launch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image")
    parser.add_argument("config", type=Path)
    parser.add_argument("--set", dest="overrides", action="append", default=[])
    parser.add_argument("--render-only", action="store_true")
    options = parser.parse_args()
    spec = (
        specs.from_dict(
            json.loads(options.config.read_text()), config_path=options.config, overrides=options.overrides
        )
        if options.config.suffix == ".json"
        else specs.load(options.config, options.overrides)
    )
    if options.render_only:
        print(json.dumps(launch.specification(options.image, spec), indent=2))
    else:
        launch.submit(options.image, spec)


if __name__ == "__main__":
    main()
