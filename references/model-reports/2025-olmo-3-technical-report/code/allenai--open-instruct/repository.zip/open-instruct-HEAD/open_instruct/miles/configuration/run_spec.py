"""Turn a researcher-facing run file into a complete plan for the MILES workflow.
RunSpec validates model, data, training, serving, judge and launch settings, resolves
paths and overrides, and translates the sections into lower-level MILES/Core options.
It describes preparation, GPU allocation and output locations without executing
those stages, so the CLI can plan and review a run before reserving compute.
"""

import copy
import dataclasses
import math
import re
from pathlib import Path
from typing import Any

from open_instruct.miles.configuration import (
    async_capacity,
    constraints,
    inference_profiles,
    options,
    topology,
    validation,
)
from open_instruct.miles.configuration.config import CoreConfig, RunConfig
from open_instruct.miles.datasets import mixture, run_data
from open_instruct.miles.errors import InputError
from open_instruct.miles.evaluation import evaluation
from open_instruct.miles.infrastructure import gpu_hardware
from open_instruct.miles.rewards import judging

RUN_SECTIONS = ("training", "trainer", "inference", "optimizer", "async", "tracking", "runtime")
WORKFLOW_SECTIONS = {"model", "conversion", "data", "output", "launch", "compiler_cache", "records", "selection"}
CORE_FIELDS = {field.name for field in dataclasses.fields(CoreConfig)}
BEAKER_MIN_RUNTIME_LIMIT_SECONDS = 8 * 3600
JUPITER_CLUSTER = "ai2/jupiter"
SATURN_CLUSTER = "ai2/saturn"
TITAN_CLUSTER = "ai2/titan"
COMPAT_DRIVER_CLUSTERS = (JUPITER_CLUSTER, SATURN_CLUSTER, TITAN_CLUSTER)
JUPITER_LD_LIBRARY_PATH = "/usr/local/cuda/compat:/usr/local/nvidia/lib:/usr/local/nvidia/lib64:/usr/local/cuda/lib64"
# Names that change when the trainer is replaced, rather than native switches.
FIELD_MAP = {
    "trainer_num_nodes": "miles.actor_num_nodes",
    "num_gpus": "miles.actor_num_gpus_per_node",
    "rollout_gpus_per_node": "miles.num_gpus_per_node",
    "rollout_tensor_parallel_size": "miles.rollout_num_gpus_per_engine",
    "rollout_expert_parallel_size": "miles.sglang_ep_size",
    "expert_parallel_size": "core.expert_parallel_size",
    "activation_recompute": "core.activation_checkpointing",
    "fp32_lm_head": "core.fp32_lm_head",
    "replay_rollout_data": "miles.load_debug_rollout_data",
    "replay_rollout_data_subsample": "miles.load_debug_rollout_data_subsample",
    "num_rollouts": "miles.num_rollout",
    "collect_dashboard": "miles.use_miles_dashboard",
    "samples_per_prompt": "miles.n_samples_per_prompt",
    "eval_max_response_length": "miles.eval_max_response_len",
    "max_response_length": "miles.rollout_max_response_len",
    "learning_rate": "miles.lr",
    "max_weight_staleness": "core.max_policy_lag",
    "max_train_rollout_logprob_abs_diff": "core.max_train_rollout_logprob_abs_diff",
    "comparison_id": "miles.wandb_group",
    # Serving prefix cache and request routing, named as in the Megatron implementation.
    "mamba_radix_cache_strategy": "miles.sglang_mamba_radix_cache_strategy",
    "router_policy": "miles.sglang_router_policy",
    "router_cache_threshold": "miles.router_cache_threshold",
    "router_balance_abs_threshold": "miles.router_balance_abs_threshold",
    "router_balance_rel_threshold": "miles.router_balance_rel_threshold",
    "enable_mixed_chunk": "miles.sglang_enable_mixed_chunk",
}
# Retain the existing name for callers inspecting migration guidance.
UNSUPPORTED_FIELDS = {name: rule.message for name, rule in constraints.UNSUPPORTED_RUN_FIELDS.items()}
PATH_OPTIONS = {
    "load",
    "ref_load",
    "save",
    "save_debug_rollout_data",
    "load_debug_rollout_data",
    "wandb_dir",
    "eval_hf_dir",
}


def _table(document, name, allowed=None, *, required=False):
    value = document.get(name, {})
    if not isinstance(value, dict) or (required and not value):
        raise InputError(f"[{name}] must be a {'nonempty ' if required else ''}table")
    validation.mapping(value, f"[{name}]")
    if allowed is not None:
        validation.fields(value, f"[{name}]", allowed)
    return copy.deepcopy(value)


def _text(value, name):
    return validation.text(value, name)


def _boolean(value, name):
    return validation.boolean(value, name)


def _positive(value, name):
    return validation.integer(value, name)


def _path(value, base, name):
    path = Path(_text(value, name)).expanduser()
    return str(path if path.is_absolute() else (base / path).resolve())


def _eval_paths(value, base):
    if not isinstance(value, list) or len(value) % 2:
        raise InputError("data.eval_prompt_data must alternate dataset names and JSONL paths")
    return [
        _path(item, base, "data.eval_prompt_data") if index % 2 else _text(item, "eval dataset name")
        for index, item in enumerate(value)
    ]


def _apply_overrides(document, overrides):
    for override in overrides or []:
        key, separator, raw = validation.text(override, "Override").partition("=")
        parts = key.split(".")
        environment_key = len(parts) == 3 and parts[:2] in (["launch", "env"], ["launch", "secrets"])
        valid_parts = (
            re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", parts[-1])
            if environment_key
            else all(re.fullmatch(r"[a-z][a-z0-9_]*", part) for part in parts)
        )
        if not separator or not valid_parts:
            raise InputError("Overrides must be SECTION.KEY=TOML_VALUE")
        value = validation.override_value(key, raw)
        current = document
        for part in parts[:-1]:
            current = current.setdefault(part, {})
            if not isinstance(current, dict):
                raise InputError(f"Override {key} traverses a non-table value")
        current[parts[-1]] = value


@dataclasses.dataclass(frozen=True)
class RunSpec:
    name: str
    config_path: Path
    model: dict[str, Any]
    data: dict[str, Any]
    output: dict[str, Any]
    launch: dict[str, Any]
    conversion: dict[str, Any]
    compiler_cache: dict[str, Any]
    sections: dict[str, dict[str, Any]]
    core: dict[str, Any]
    miles: dict[str, Any]
    judges: dict[str, Any]
    evaluation: dict[str, Any]
    records: dict[str, Any] = dataclasses.field(default_factory=dict)
    selection: dict[str, Any] = dataclasses.field(default_factory=dict)

    @classmethod
    def load(cls, path: str | Path, overrides: list[str] | None = None) -> "RunSpec":
        path = Path(path).expanduser().resolve()
        document = validation.read_document(path)
        return cls.from_dict(document, config_path=path, overrides=overrides)

    @classmethod
    def from_dict(
        cls, payload: dict, config_path: str | Path = Path("run.toml"), overrides: list[str] | None = None
    ) -> "RunSpec":
        """Load a serialized specification; relative paths use the original config directory."""
        if not isinstance(payload, dict):
            raise InputError("Run specification must be a mapping")
        document = copy.deepcopy(payload)
        path = Path(config_path).expanduser().resolve()
        _apply_overrides(document, overrides)
        allowed = {
            "schema_version",
            "name",
            "core",
            "miles",
            *WORKFLOW_SECTIONS,
            *RUN_SECTIONS,
            "judges",
            "rubrics",
            "judging",
            "evaluation",
        }
        if set(document) & {"validation", "conversion_validation"}:
            raise InputError(
                "Megatron conversion/parity thresholds do not apply to Core; use separate Core parity probes"
            )
        validation.fields(document, "run sections", allowed)
        if type(document.get("schema_version")) is not int or document["schema_version"] != 1:
            raise InputError("schema_version must be 1")
        name = _text(document.get("name"), "name")
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", name):
            raise InputError("name must contain only letters, digits, dots, underscores and hyphens")
        base = path.parent
        model = _table(document, "model", constraints.STRUCTURED_FIELDS["model"], required=True)
        model["source"] = _path(model.get("source"), base, "model.source")
        if model.get("reference_hf") is not None:
            raise InputError(
                "model.reference_hf describes baseline conversion validation, which is not implemented here; "
                "use miles.ref_load for a frozen KL reference"
            )
        model.setdefault("format", "hf")
        if model["format"] not in ("hf", "olmo_core"):
            raise InputError("model.format must be hf or olmo_core; Megatron checkpoints are not Core inputs")
        if model["format"] == "olmo_core" and not model.get("hf_template"):
            raise InputError("model.hf_template is required for an olmo_core input")
        # For an HF input, hf_template is optional: a tokenizer directory or a
        # chat_template.jinja that replaces the template shipped with the checkpoint.
        for key in ("hf_template",):
            if key in model:
                model[key] = _path(model[key], base, f"model.{key}")
        output = _table(document, "output", constraints.STRUCTURED_FIELDS["output"], required=True)
        output["root"] = _path(output.get("root"), base, "output.root")
        if "rollout_sample_rate" in output:
            output["rollout_sample_rate"] = min(
                validation.number(output["rollout_sample_rate"], "output.rollout_sample_rate"), 1.0
            )
        output["export_hf"] = _boolean(output.get("export_hf", False), "output.export_hf")
        output["hf_dir"] = _path(output.get("hf_dir", str(Path(output["root"]) / "export-hf")), base, "output.hf_dir")
        conversion = _table(document, "conversion", constraints.STRUCTURED_FIELDS["conversion"])
        conversion["hf_output"] = _path(
            conversion.get("hf_output", str(Path(output["root"]) / "prepared" / "hf")), base, "conversion.hf_output"
        )
        data = cls._data(_table(document, "data", required=True), base)
        run_data.validate_data(data)
        launch = cls._launch(_table(document, "launch"), base)
        cache = _table(document, "compiler_cache", constraints.STRUCTURED_FIELDS["compiler_cache"])
        if "max_storage_bytes" in cache:
            validation.integer(cache["max_storage_bytes"], "compiler_cache.max_storage_bytes", minimum=0)
        if "publish_interval_seconds" in cache:
            validation.number(
                cache["publish_interval_seconds"], "compiler_cache.publish_interval_seconds", exclusive_min=True
            )
        for key in ("enabled", "restore", "diagnostics"):
            if key in cache:
                _boolean(cache[key], f"compiler_cache.{key}")
        if "shared_root" in cache:
            cache["shared_root"] = _path(cache["shared_root"], base, "compiler_cache.shared_root")
        records = cls._records(_table(document, "records", constraints.STRUCTURED_FIELDS["records"]), base)
        selection = _table(document, "selection", constraints.STRUCTURED_FIELDS["selection"])
        if selection:
            if set(selection) != {"table", "sha256"}:
                raise InputError("[selection] needs both table and sha256; `records select` prints the digest")
            selection["table"] = _path(selection["table"], base, "selection.table")
        result = cls(
            name,
            path,
            model,
            data,
            output,
            launch,
            conversion,
            cache,
            {section: _table(document, section) for section in RUN_SECTIONS},
            _table(document, "core", CORE_FIELDS),
            _table(document, "miles"),
            judging.parse(document),
            evaluation.parse(_table(document, "evaluation"), launch),
            records,
            selection,
        )
        result.compile()
        return result

    def to_dict(self) -> dict[str, Any]:
        """Serialize the run contract, with filesystem paths independent of submitter cwd."""
        payload: dict[str, Any] = {
            "schema_version": 1,
            "name": self.name,
            "model": self.model,
            "data": self.data,
            "output": self.output,
            "launch": self.launch,
            "conversion": self.conversion,
            "compiler_cache": self.compiler_cache,
            **({"records": self.records} if self.records else {}),
            **({"selection": self.selection} if self.selection else {}),
            **({"evaluation": self.evaluation} if self.evaluation["mode"] == "background" else {}),
            **self.sections,
            "core": self.core,
            "miles": self.miles,
            **self.judges,
        }
        payload = copy.deepcopy(payload)
        for section in (*RUN_SECTIONS, "core", "miles"):
            for key, value in payload[section].items():
                if key in PATH_OPTIONS | {
                    "replay_rollout_data",
                    "model_config",
                    "reward_config",
                    "compiler_cache_root",
                    "records_root",
                    "selection_table",
                    "prompt_mixture",
                }:
                    payload[section][key] = _path(value, self.config_path.parent, f"{section}.{key}")
        return payload

    @staticmethod
    def _records(records, base):
        """Recording is opt-in and needs an explicit shared store; other fields are validated by CoreConfig."""
        if not records:
            return {}
        records["enabled"] = _boolean(records.get("enabled", False), "records.enabled")
        if "root" in records:
            records["root"] = _path(records["root"], base, "records.root")
        elif records["enabled"]:
            raise InputError("records.root is required when records.enabled = true; use a shared absolute store path")
        return records

    @staticmethod
    def _data(data, base):
        allowed = constraints.STRUCTURED_FIELDS["data"]
        if unknown := set(data) - allowed:
            raise InputError(f"Unknown [data] fields: {sorted(unknown)}")
        selectors = [key for key in ("tasks", "sources", "recipe", "rl_manifest", "prompt_data") if key in data]
        if len(selectors) != 1:
            raise InputError(
                f"data must select exactly one of tasks, sources, recipe, rl_manifest or prompt_data; found {selectors or 'none'}. Remove competing selectors or add data.tasks."
            )
        data.setdefault("seed", 17)
        if type(data["seed"]) is not int or data["seed"] < 0:
            raise InputError("data.seed must be a nonnegative integer")
        data["shuffle"] = _boolean(data.get("shuffle", True), "data.shuffle")
        if "sources" in data:
            run_data.validate_data(data)
            data["sources"] = [
                {
                    "name": source["name"],
                    "fraction": source["fraction"],
                    **{
                        key: value
                        for key, value in RunSpec._data(mixture.source_data(source, data), base).items()
                        if key not in ("seed", "shuffle")
                    },
                }
                for source in data["sources"]
            ]
        for key in ("rl_manifest", "prompt_data", "reward_config"):
            if key in data:
                data[key] = _path(data[key], base, f"data.{key}")
        if "eval_prompt_data" in data:
            data["eval_prompt_data"] = _eval_paths(data["eval_prompt_data"], base)
        if "recipe" in data:
            _text(data["recipe"], "data.recipe")
        if "tasks" in data:
            if not isinstance(data["tasks"], list) or not data["tasks"]:
                raise InputError("data.tasks must be a nonempty array of task tables")
            names = []
            for index, task in enumerate(data["tasks"]):
                if not isinstance(task, dict) or set(task) - {"task", "train_count", "eval_count", "prompt_wrapper"}:
                    raise InputError("data.tasks entries accept task, train_count, eval_count and prompt_wrapper")
                names.append(_text(task.get("task"), f"data.tasks[{index}].task"))
                if "train_count" not in task and "eval_count" not in task:
                    raise InputError("Each task must set train_count or eval_count")
                for key in ("train_count", "eval_count"):
                    if key in task:
                        _positive(task[key], f"data.tasks[{index}].{key}")
                if "prompt_wrapper" in task:
                    _text(task["prompt_wrapper"], "data.tasks.prompt_wrapper")
            if len(names) != len(set(names)):
                raise InputError("data.tasks must not repeat task names")
            if not any("train_count" in task for task in data["tasks"]):
                raise InputError("data.tasks must select training data")
        return data

    @staticmethod
    def _launch(launch, base):
        allowed = constraints.STRUCTURED_FIELDS["launch"]
        if unknown := set(launch) - allowed:
            raise InputError(f"Unknown [launch] fields: {sorted(unknown)}")
        defaults = dict(
            workspace="ai2/open-instruct-dev",
            budget="ai2/oe-other",
            cluster="ai2/holmes",
            priority="high",
            min_runtime="0s",
            auto_resume=True,
            max_retries=-1,
            memory="256 GiB",
            shared_memory="200 GiB",
            timeout="3h",
        )
        launch = defaults | launch
        coordination = launch.setdefault("coordination", {})
        validation.mapping(coordination, "launch.coordination")
        validation.fields(coordination, "launch.coordination", {"startup_timeout", "heartbeat_timeout"})
        for key, default in (("startup_timeout", 1200), ("heartbeat_timeout", 120)):
            coordination.setdefault(key, default)
            _positive(coordination[key], f"launch.coordination.{key}")
        for key in ("workspace", "budget", "cluster", "priority", "memory", "shared_memory"):
            _text(launch[key], f"launch.{key}")
        for key in ("min_runtime", "timeout"):
            seconds = validation.duration(launch[key], f"launch.{key}", allow_blank=key == "min_runtime")
            if seconds == 0:
                # Freeze equivalent zero/blank inputs as a Beaker-compatible duration.
                launch[key] = "0s"
        if launch["priority"] not in ("low", "normal", "high", "urgent"):
            raise InputError("launch.priority must be low, normal, high or urgent")
        _boolean(launch["auto_resume"], "launch.auto_resume")
        if type(launch["max_retries"]) is not int or launch["max_retries"] < -1:
            raise InputError(
                "launch.max_retries must be -1 for no cap, or the number of automatic restarts to allow; "
                f"got {launch['max_retries']!r}."
            )
        if "gpus_per_replica" in launch:
            _positive(launch["gpus_per_replica"], "launch.gpus_per_replica")
        for key in ("env", "secrets"):
            launch.setdefault(key, {})
            if not isinstance(launch[key], dict) or any(not isinstance(value, str) for value in launch[key].values()):
                raise InputError(f"launch.{key} must map names to strings")
            validation.mapping(launch[key], f"launch.{key}")
            if any(not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name) for name in launch[key]):
                raise InputError(f"launch.{key} names must be valid environment-variable identifiers")
        validation.ray_cpus(launch["env"])
        if duplicate := set(launch["env"]) & set(launch["secrets"]):
            raise InputError(f"launch.env and launch.secrets overlap: {sorted(duplicate)}")
        if launch["cluster"] in COMPAT_DRIVER_CLUSTERS and "LD_LIBRARY_PATH" not in launch["secrets"]:
            # The pinned CUDA runtime needs forward-compatibility libraries on
            # Jupiter's, Saturn's and Titan's older host drivers. Explicit environment values win.
            launch["env"].setdefault("LD_LIBRARY_PATH", JUPITER_LD_LIBRARY_PATH)
        reserved = {
            "OI_MILES_REPLICA_RANK",
            "OI_MILES_REPLICA_COUNT",
            "OI_MILES_LAUNCH_ID",
            "OI_MILES_JUDGE_REGISTRY",
            "RAY_ADDRESS",
            "PYTHONPATH",
            "CUDA_VISIBLE_DEVICES",
            "RANK",
            "LOCAL_RANK",
            "WORLD_SIZE",
            "MASTER_ADDR",
            "MASTER_PORT",
        }
        if managed := reserved & (set(launch["env"]) | set(launch["secrets"])):
            raise InputError(f"The launcher/runtime owns these environment variables: {sorted(managed)}")
        launch.setdefault("weka_mounts", [{"weka": "oe-training-default", "mount_path": "/weka/oe-training-default"}])
        if not isinstance(launch["weka_mounts"], list):
            raise InputError("launch.weka_mounts must be an array of tables")
        seen_filesystems = set()
        seen_paths = []
        for mount in launch["weka_mounts"]:
            if not isinstance(mount, dict) or set(mount) != {"weka", "mount_path"}:
                raise InputError("Each launch.weka_mounts entry requires weka and mount_path")
            _text(mount["weka"], "launch.weka_mounts.weka")
            mount["mount_path"] = _path(mount["mount_path"], base, "launch.weka_mounts.mount_path")
            mount_path = Path(mount["mount_path"])
            if mount_path == Path("/") or any(
                mount_path == previous or mount_path in previous.parents or previous in mount_path.parents
                for previous in seen_paths
            ):
                raise InputError("launch.weka_mounts paths must be distinct, nonoverlapping and below filesystem root")
            if mount["weka"] in seen_filesystems:
                raise InputError("launch.weka_mounts must not repeat a filesystem")
            seen_filesystems.add(mount["weka"])
            seen_paths.append(mount_path)
        return launch

    def compile(self, prepared: dict | None = None) -> RunConfig:
        """Resolve settings using optional model JSON, without loading weights or GPU libraries."""
        prepared = prepared or {}
        if unknown := set(prepared) - {
            "hf_checkpoint",
            "prompt_data",
            "eval_prompt_data",
            "reward_config",
            "manifest",
            "prompt_mixture",
            "train_sources",
        }:
            raise InputError(f"Unknown prepared fields: {sorted(unknown)}")
        root = Path(self.output["root"])
        base = self.config_path.parent
        values = {"core": {}, "miles": {}}
        origins = {}
        controls = {}

        def put(target: str, value: Any, origin: str):
            section, key = target.split(".", 1)
            if target == "miles.save_debug_rollout_data":
                raise InputError(f"{origin}: use output.rollout_sample_rate; the run owns the capture path")
            if target == "miles.rollout_sample_rate":
                value = min(validation.number(value, origin), 1.0)
            if section == "miles":
                record, value = options.resolve_option(key, value)
                key = record["dest"]
                target = f"miles.{key}"
                if key == "max_weight_staleness":
                    section, key = "core", "max_policy_lag"
                    target = "core.max_policy_lag"
            if (section == "miles" and key in PATH_OPTIONS) or (
                section == "core" and key in ("model_config", "reward_config", "compiler_cache_root", "prompt_mixture")
            ):
                value = _path(value, base, target)
            try:
                if section == "miles":
                    options.encode_options({key: value})
                    validation.runtime_values({key: value})
                else:
                    core_values: dict[str, Any] = {key: value}
                    CoreConfig(**core_values)
            except InputError as error:
                raise InputError(f"{origin}: {error}") from error
            if target in origins and values[section][key] != value:
                raise InputError(f"Conflicting settings for {target}: {origins[target]} and {origin}")
            origins[target] = origin
            values[section][key] = value

        for section in RUN_SECTIONS:
            for key, value in self.sections[section].items():
                origin = f"{section}.{key}"
                control = constraints.SPECIAL_CONTROLS.get(key)
                if key == "profile" and section == "inference":
                    controls["inference_profile"] = (value, origin)
                elif control == "gpus" and section in ("trainer", "inference"):
                    put(
                        "miles.actor_num_gpus_per_node" if section == "trainer" else "miles.rollout_num_gpus",
                        value,
                        origin,
                    )
                elif key in constraints.UNSUPPORTED_RUN_FIELDS:
                    rule = constraints.UNSUPPORTED_RUN_FIELDS[key]
                    raise constraints.error(f"{origin} is unsupported: {rule.message}", rule.category)
                elif control == "deferred":
                    if key in controls and controls[key][0] != value:
                        raise InputError(f"Conflicting settings for {key}")
                    controls[key] = (value, origin)
                elif control == "radix_cache":
                    value = _boolean(value, origin)
                    put("miles.sglang_disable_radix_cache", not value if key == "radix_cache" else value, origin)
                elif control == "trainer_diagnostics":
                    put("core.diagnostic_interval", int(_boolean(value, origin)), origin)
                elif control == "recompute_mode":
                    if value not in ("full", "off"):
                        raise InputError(f"{origin}: Core supports full/off block recomputation, not selective mode")
                    put("core.activation_checkpointing", value == "full", origin)
                elif control == "trainer_flash_attention_version":
                    if type(value) is not int or value not in (2, 3, 4):
                        raise InputError(f"{origin} must be 2, 3 or 4")
                    put("core.attention_backend", f"flash_{value}", origin)
                elif control == "dynamic_batching":
                    put("miles.use_dynamic_batch_size", _boolean(value, origin), origin)
                elif key in FIELD_MAP:
                    put(FIELD_MAP[key], value, origin)
                elif key in CORE_FIELDS:
                    put(f"core.{key}", value, origin)
                else:
                    put(f"miles.{key}", value, origin)
        for key, value in self.core.items():
            if key in (
                "model_config",
                "reward_config",
                "compiler_cache_root",
                "records_root",
                "selection_table",
                "prompt_mixture",
            ):
                value = _path(value, base, f"core.{key}")
            put(f"core.{key}", value, f"core.{key}")
        for key, value in options.normalize_options(self.miles).items():
            put(f"miles.{key}", value, f"miles.{key}")
        for key, field in {
            "enabled": "compiler_cache",
            "shared_root": "compiler_cache_root",
            "restore": "compiler_cache_restore",
            "diagnostics": "compiler_cache_diagnostics",
            "max_storage_bytes": "compiler_cache_max_storage_bytes",
            "publish_interval_seconds": "compiler_cache_publish_interval_seconds",
        }.items():
            if key in self.compiler_cache:
                put(f"core.{field}", self.compiler_cache[key], f"compiler_cache.{key}")
        if self.records.get("enabled"):
            for key, field in {
                "root": "records_root",
                "responses": "records_responses",
                "response_sample_rate": "records_response_sample_rate",
            }.items():
                if key in self.records:
                    put(f"core.{field}", self.records[key], f"records.{key}")
        for key in ("table", "sha256"):
            if key in self.selection:
                put(f"core.selection_{key}", self.selection[key], f"selection.{key}")
        if "rollout_sample_rate" in self.output:
            put("miles.rollout_sample_rate", self.output["rollout_sample_rate"], "output.rollout_sample_rate")
        core, miles = values["core"], values["miles"]
        # Check explicit scalar types before doing any batch/topology arithmetic.
        options.encode_options(miles)
        validation.runtime_values(miles)
        # Cross-field capacity validation below waits for the profile's cache
        # strategy and pools; scalar validation stays ahead of derived arithmetic.
        CoreConfig(**core)
        if "placement_mode" in controls:
            placement, origin = controls["placement_mode"]
            if placement not in ("colocated", "disaggregated"):
                raise InputError("inference.placement_mode must be colocated or disaggregated")
            put("miles.colocate", placement == "colocated", origin)
        asynchronous = _boolean(miles.get("fully_async", False), "async.fully_async")
        miles.setdefault("colocate", not asynchronous)
        miles.setdefault("actor_num_nodes", 1)
        miles.setdefault("actor_num_gpus_per_node", 2)
        world = _positive(miles["actor_num_nodes"], "trainer_num_nodes") * _positive(
            miles["actor_num_gpus_per_node"], "trainer.gpus"
        )
        miles.setdefault("rollout_num_gpus", world if miles["colocate"] else 1)
        miles.setdefault("rollout_num_gpus_per_engine", 1)
        _positive(miles["rollout_num_gpus"], "inference.gpus")
        tp = _positive(miles["rollout_num_gpus_per_engine"], "inference.rollout_tensor_parallel_size")
        if miles["rollout_num_gpus"] % tp:
            raise InputError(
                f"inference.gpus={miles['rollout_num_gpus']} must be divisible by "
                f"rollout_tensor_parallel_size={tp}; allocate a multiple of {tp} GPUs or lower tensor parallelism."
            )
        if miles["colocate"] and miles["rollout_num_gpus"] != world:
            raise InputError(
                f"Colocated inference.gpus must equal the total trainer GPUs ({world}); got {miles['rollout_num_gpus']}."
            )
        allocated = world if miles["colocate"] else world + miles["rollout_num_gpus"]
        per_node = self.launch.get("gpus_per_replica", min(8, allocated))
        miles.setdefault("num_gpus_per_node", per_node)
        if miles["actor_num_gpus_per_node"] > miles["num_gpus_per_node"]:
            raise InputError("trainer.gpus exceeds the declared physical num_gpus_per_node")
        core.setdefault("expert_parallel_size", min(2, world) if world % 2 == 0 else 1)
        # FlashAttention 4 (CuTe) runs only on Blackwell; the runtime also provides FlashAttention 3 for
        # Jupiter's H100s and FlashAttention 2 for Saturn's A100s.
        core.setdefault(
            "attention_backend",
            gpu_hardware.CLUSTERS.get(self.launch.get("cluster"), {}).get("attention_backend", "flash_4"),
        )
        core.setdefault("row_specialization", "dynamic")
        # Roll native checkpoints by default: keep the newest committed one (the
        # final save is always the newest). Set core.checkpoint_keep_every to also
        # keep milestones, or unset checkpoint_keep_last explicitly to keep all.
        core.setdefault("checkpoint_keep_last", 1)
        # Provisional async starting point; explicit study limits still win.
        # Policy drift depends on the full recipe, not optimizer-step age alone.
        core.setdefault("max_policy_lag", 6 if asynchronous else 0)
        if "max_context_length" in controls:
            length, origin = controls["max_context_length"]
            _positive(length, origin)
            for target in ("core.max_sequence_length", "miles.sglang_context_length", "miles.rollout_max_context_len"):
                put(target, length, origin)
        length = core.setdefault("max_sequence_length", miles.get("rollout_max_context_len", 6144))
        miles.setdefault("rollout_max_context_len", length)
        miles.setdefault("sglang_context_length", length)
        miles.setdefault("rollout_max_response_len", min(4096, length // 2 if length <= 4096 else 4096))
        response = _positive(miles["rollout_max_response_len"], "inference.max_response_length")
        if response >= miles["rollout_max_context_len"]:
            raise InputError(
                f"max_response_length={response} must be smaller than max_context_length={miles['rollout_max_context_len']}; "
                "leave room for the prompt or increase the context limit."
            )
        miles.setdefault("rollout_max_prompt_len", miles["rollout_max_context_len"] - response)
        if (
            miles["rollout_max_context_len"] > length
            or miles["rollout_max_context_len"] > miles["sglang_context_length"]
        ):
            raise InputError(
                f"Rollout context {miles['rollout_max_context_len']} exceeds Core ({length}) or SGLang "
                f"({miles['sglang_context_length']}) context capacity; use inference.max_context_length to set all three."
            )
        selector = controls.get("inference_profile", ("generic", ""))[0]
        try:
            metadata, metadata_path = inference_profiles.model_metadata(self.model, prepared)
        except InputError:
            if selector != "generic":
                raise
            # Generic is an escape hatch; advisory metadata must not make it fail.
            metadata, metadata_path = None, None
        profile = inference_profiles.resolve(
            selector, self.launch["cluster"], metadata, miles, require_model_metadata="hf_checkpoint" in prepared
        )
        profile["model_metadata_path"] = metadata_path
        miles.update(profile["preset_values"])
        miles.setdefault("sglang_disable_radix_cache", True)
        validation.inference_capacity(miles)
        defaults = {
            "fully_async": asynchronous,
            "offload_train": False,
            "offload_rollout": False,
            "micro_batch_size": 1,
            "rollout_batch_size": 8,
            "n_samples_per_prompt": 8,
            "num_rollout": 100,
            "rollout_temperature": 1.0,
            "rollout_seed": self.data["seed"],
            "seed": self.data["seed"],
            "input_key": "input",
            "label_key": "label",
            "metadata_key": "metadata",
            "custom_rm_path": "open_instruct.miles.rewards.rewards.registered_reward",
            "custom_rollout_log_function_path": "open_instruct.miles.rollout.rollout_metrics.log_rollout_data",
            "rollout_global_dataset": True,
            "rollout_shuffle": self.data["shuffle"],
            "loss_type": "policy_loss",
            "advantage_estimator": "grpo",
            "calculate_per_token_loss": False,
            "use_rollout_logprobs": False,
            "grpo_std_normalization": False,
            "eps_clip": 0.2,
            "eps_clip_high": 0.28,
            "kl_loss_coef": 0.0,
            "entropy_coef": 0.0,
            "lr": 1e-6,
            "lr_decay_style": "constant",
            "lr_warmup_iters": 0,
            "weight_decay": 0.0,
            "adam_beta1": 0.9,
            "adam_beta2": 0.95,
            "adam_eps": 1e-8,
            "clip_grad": 1.0,
            "update_weight_buffer_size": 1073741824,
            "update_weights_interval": 1,
            "sglang_max_running_requests": 64,
            "sglang_mem_fraction_static": 0.4 if miles["colocate"] else 0.6,
            "sglang_max_mamba_cache_size": 128,
            "sglang_cuda_graph_backend_decode": "full",
            "sglang_cuda_graph_max_bs_decode": 64,
            "sglang_cuda_graph_backend_prefill": "disabled",
            "sglang_sampling_backend": "pytorch",
            "sglang_attention_backend": "triton",
            "use_wandb": False,
            "wandb_run_name": self.name,
            "save": str(root / "checkpoints"),
            "save_debug_rollout_data": str(root / "rollouts" / "{rollout_id}.pt"),
            "rollout_sample_rate": 0.0,
            "wandb_dir": str(root / "wandb"),
            "async_save": False,
        }
        for key, value in defaults.items():
            miles.setdefault(key, value)
        # HTTP permits cover the entire request, including response delivery and
        # decoding. Leave transport headroom without increasing GPU batch/cache
        # limits. Preserve explicit limits, including deliberately small checks.
        miles.setdefault(
            "sglang_server_concurrency", miles["sglang_max_running_requests"] * (2 if asynchronous else 1)
        )
        miles.setdefault("global_batch_size", miles["rollout_batch_size"] * miles["n_samples_per_prompt"])
        miles.setdefault("sglang_max_total_tokens", max(524288, miles["sglang_max_running_requests"] * length))
        if controls.get("policy_drift_action", ("fail", ""))[0] != "fail":
            raise InputError("policy_drift_action=warn is not implemented by Core; select fail")
        correction = controls.get("off_policy_correction", ("tis", ""))[0]
        if correction != "tis":
            raise InputError(
                "off_policy_correction supports tis; other corrections require an explicitly qualified custom_tis_function_path"
            )
        if "off_policy_correction" in controls:
            # An explicit algorithm choice must take effect in either schedule,
            # and must agree with any native switch supplied alongside it.
            put("miles.use_tis", True, controls["off_policy_correction"][1])
        miles.setdefault("use_tis", asynchronous and not miles["use_rollout_logprobs"])
        if miles["use_tis"] and miles["use_rollout_logprobs"]:
            raise InputError(
                "use_tis and use_rollout_logprobs cannot both be enabled; use use_tis=true with use_rollout_logprobs=false for trainer-scored correction."
            )
        if asynchronous:
            if not (miles["use_tis"] or miles["use_rollout_logprobs"]):
                raise InputError("Async training requires TIS or an explicit rollout-logprob policy anchor")
            miles.setdefault("async_max_concurrent_samples", async_capacity.producer_default(miles))
            miles.setdefault("async_data_buffer_capacity_factor", 1.0)
            miles.setdefault("async_unused_samples_handler", "retry")
            # MILES upstream also defaults its fully-async producer to sample backfill:
            # a finished sibling frees its slot instead of idling until its slowest
            # sibling and rewards finish. Training still consumes whole groups.
            miles.setdefault("rollout_submission_granularity", "sample")
        if "kl_loss_coef" in miles and miles["kl_loss_coef"] > 0:
            miles.setdefault("use_kl_loss", True)
        if miles.get("use_kl_loss"):
            miles.setdefault("ref_load", prepared.get("hf_checkpoint", self.conversion["hf_output"]))
        save_enabled = _boolean(controls.get("save_checkpoints", (True, ""))[0], "training.save_checkpoints")
        if save_enabled:
            miles.setdefault("save_interval", miles["num_rollout"])
        elif "miles.save_interval" in origins:
            raise InputError("save_checkpoints=false conflicts with an explicit save_interval")
        if "sources" in self.data:
            put("core.prompt_provider", "mixture", "data.sources")
            put(
                "core.prompt_mixture",
                prepared.get("prompt_mixture", str(root / "prepared" / "data" / "mixture.json")),
                "data.sources",
            )
        generated = {
            "hf_checkpoint": self.conversion["hf_output"],
            "prompt_data": self.data.get(
                "prompt_data",
                str(
                    root
                    / "prepared"
                    / "data"
                    / (f"source-{self.data['sources'][0]['name']}.jsonl" if "sources" in self.data else "train.jsonl")
                ),
            ),
            "reward_config": self.data.get("reward_config", str(root / "prepared" / "data" / "verifiers.json")),
        }
        for key in generated:
            value = str(prepared.get(key, generated[key]))
            target = f"core.{key}" if key == "reward_config" else f"miles.{key}"
            if target in origins and values[target.split(".")[0]][key] != value:
                raise InputError(f"{target} conflicts with workflow preparation; set model/data fields instead")
            values[target.split(".")[0]][key] = value
        mixture_evals = []
        for source in self.data.get("sources", []):
            labels = source.get("eval_prompt_data", [])[::2]
            if source.get("rl_manifest") or any(task.get("eval_count") for task in source.get("tasks", [])):
                labels = ["eval"]
            for label in labels:
                name = f"eval-{source['name']}-{label}"
                mixture_evals.extend([name, str(root / "prepared" / "data" / f"{name}.jsonl")])
        if self.evaluation["mode"] == "background":
            conflicts = [
                key
                for key in origins
                if key.startswith("miles.eval_")
                or key in {"miles.skip_eval_before_train", "miles.n_samples_per_eval_prompt"}
            ]
            if (
                conflicts
                or mixture_evals
                or self.data.get("eval_prompt_data")
                or any(task.get("eval_count") for task in self.data.get("tasks", []))
            ):
                raise InputError(
                    f"background evaluation conflicts with shared-engine evaluation: {conflicts or 'data held-out evaluation'}"
                )
            miles.pop("eval_prompt_data", None)
            miles.pop("eval_interval", None)
            miles["skip_eval_before_train"] = True
        else:
            eval_data = prepared.get(
                "eval_prompt_data", mixture_evals if "sources" in self.data else self.data.get("eval_prompt_data")
            )
            if eval_data is None and (
                "tasks" not in self.data or any(task.get("eval_count") for task in self.data["tasks"])
            ):
                eval_data = ["heldout", str(root / "prepared" / "data" / "eval.jsonl")]
            if eval_data:
                put("miles.eval_prompt_data", eval_data, "data.eval_prompt_data")
                miles.setdefault("eval_interval", 20)
                miles.setdefault("skip_eval_before_train", False)
                miles.setdefault("eval_temperature", 0.0)
                miles.setdefault("n_samples_per_eval_prompt", 1)
                miles.setdefault("eval_max_response_len", response)
            elif miles.get("eval_interval") is not None:
                raise InputError(
                    "eval_interval requires prepared held-out data; set data.tasks[].eval_count or data.eval_prompt_data, or remove eval_interval."
                )
        if "miles.wandb_mode" in origins and "miles.use_wandb" not in origins:
            miles["use_wandb"] = miles.get("wandb_mode") != "disabled"
        for key in PATH_OPTIONS:
            if key in miles:
                miles[key] = _path(miles[key], base, f"miles.{key}")
        for key in ("save_interval", "eval_interval"):
            if key in miles:
                _positive(miles[key], f"miles.{key}")
        if "async_data_buffer_capacity_factor" in miles:
            capacity = miles["async_data_buffer_capacity_factor"]
            if type(capacity) not in (int, float) or not math.isfinite(capacity) or capacity <= 0:
                raise InputError("async_data_buffer_capacity_factor must be finite and positive")
        profile["values"] = {
            key: {"value": miles[key], "source": origins.get(f"miles.{key}", profile["selected"])}
            for key in inference_profiles.PROFILE_KEYS
            if key in miles
        }
        profile["warnings"], profile["tips"] = inference_profiles.advise(
            profile,
            self.launch["cluster"],
            metadata,
            miles,
            {key.removeprefix("miles.") for key in origins if key.startswith("miles.")},
        )
        result = RunConfig(CoreConfig(**core), miles, inference_profile=profile)
        result.validate()
        if result.core.reward_final_answer_only and self.judges["judging"]["bindings"]:
            raise InputError(
                "core.reward_final_answer_only is incompatible with judging.bindings "
                "(managed or external named judges); set reward_final_answer_only=false "
                "or use text verifiers without named judge bindings."
            )
        return result

    def launch_warnings(self, miles) -> list[str]:
        warnings = []
        min_runtime = validation.duration(self.launch["min_runtime"], "launch.min_runtime")
        timeout = validation.duration(self.launch["timeout"], "launch.timeout")
        if min_runtime > BEAKER_MIN_RUNTIME_LIMIT_SECONDS:
            warnings.append(
                f"launch.min_runtime={self.launch['min_runtime']} exceeds Beaker's usual 8h limit; "
                "submission fails unless the workspace has been granted a longer minimum runtime."
            )
        periodic = miles.get("save_interval", miles["num_rollout"]) < miles["num_rollout"]
        if (timeout == 0 or timeout > min_runtime) and not (periodic and self.launch["auto_resume"]):
            execution_limit = (
                f"may run until launch.timeout={self.launch['timeout']}"
                if timeout
                else "has no explicit execution timeout"
            )
            warnings.append(
                f"The job can be preempted after launch.min_runtime={self.launch['min_runtime']} and "
                f"{execution_limit}; without periodic checkpoints "
                "(training.save_interval below the collection count) and launch.auto_resume, "
                "a preemption after that window loses training progress."
            )
        return warnings

    def plan(self, compiled=None) -> dict[str, Any]:
        compiled = compiled if compiled is not None else self.compile()
        runtime = compiled.plan()
        return {
            "schema_version": 1,
            "name": self.name,
            "config_path": str(self.config_path),
            "model": self.model,
            "conversion": self.conversion,
            "data": self.data,
            "output": self.output,
            "launch": self.launch,
            "launch_warnings": self.launch_warnings(compiled.miles),
            "compiler_cache": self.compiler_cache,
            "records": self.records,
            "selection": self.selection,
            "runtime": runtime,
            "evaluation": evaluation.plan(self, compiled.miles),
            **self.judges,
            "allocation": topology.plan(self, compiled),
            "runtime_validated": False,
            "stages": ["prepare_model", "prepare_data", "validate", "train"]
            + (["export_hf"] if self.output["export_hf"] else []),
        }
