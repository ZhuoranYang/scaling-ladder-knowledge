# Taken and modified from https://github.com/huggingface/trl
# Copyright 2024 The AllenAI Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""This file is copied from https://github.com/OpenRLHF/OpenRLHF"""

import argparse
import asyncio
import dataclasses
import os
import queue
import sys
import threading
import time
from collections import defaultdict
from collections.abc import Awaitable, Callable
from concurrent import futures
from typing import Any, TypedDict

import aiohttp
import backoff
import deepspeed
import openai
import ray
import torch
import torch.distributed
import uvicorn
import vllm
from ray.util import queue as ray_queue
from ray.util.placement_group import PlacementGroup, placement_group
from ray.util.scheduling_strategies import PlacementGroupSchedulingStrategy
from torch.distributed._composable.fsdp import FSDPModule
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP
from vllm.config import WeightTransferConfig
from vllm.distributed.weight_transfer.base import WeightTransferInitRequest, WeightTransferUpdateRequest
from vllm.distributed.weight_transfer.ipc_engine import IPCTrainerSendWeightsArgs, IPCWeightTransferEngine
from vllm.distributed.weight_transfer.nccl_engine import NCCLTrainerSendWeightsArgs, NCCLWeightTransferEngine
from vllm.entrypoints.openai.api_server import build_app, init_app_state
from vllm.entrypoints.openai.cli_args import make_arg_parser
from vllm.utils.argparse_utils import FlexibleArgumentParser
from vllm.v1.core import kv_cache_utils
from vllm.v1.kv_cache_interface import MambaSpec

from open_instruct import logger_utils, utils
from open_instruct.data_types import (
    EnvConfig,
    EnvConfigEntry,
    GenerationResult,
    PromptRequest,
    RequestInfo,
    TokenStatistics,
    ToolCallStats,
)
from open_instruct.dataset_transformation import GROUND_TRUTHS_KEY, RAW_PROMPT_KEY, VERIFIER_SOURCE_KEY
from open_instruct.environments.base import EnvCall, RolloutState, StepResult
from open_instruct.environments.tools.parsers import ToolParser, create_tool_parser
from open_instruct.ground_truth_utils import RewardConfig

logger = logger_utils.setup_logger(__name__)

# ---------------------------------------------------------------------------
# Monkey-patch: vLLM 0.18.0 hybrid model dtype serialization bug
#
# vLLM's MambaSpec.dtypes field is typed as tuple[torch.dtype] (fixed-length,
# exactly 1 element). Hybrid models like Olmo-Hybrid-Instruct-DPO-7B have
# Mamba layers with 2 state tensors of different dtypes, producing a 2-element
# tuple. When the EngineCore subprocess serializes collective_rpc results back
# to the client via msgspec, the fixed-length tuple type is enforced and the
# deserialization fails:
#   msgspec.ValidationError: Expected `array` of length 1, got 2 - at `$.dtypes`
#
# The client-side decoder (in serial_utils._convert_result) dynamically imports
# MambaSpec and calls msgspec.convert(data, MambaSpec), which checks the live
# type annotations. By widening dtypes to tuple[torch.dtype, ...] (variable-
# length), msgspec accepts any number of dtypes during deserialization.
#
# Upstream fix: change dtypes annotation in vllm/v1/kv_cache_interface.py.
# ---------------------------------------------------------------------------
MambaSpec.__dataclass_fields__["dtypes"].type = tuple[torch.dtype, ...]
MambaSpec.__annotations__["dtypes"] = tuple[torch.dtype, ...]

NUM_PREFETCH_WORKERS = 2
DRAIN_ACTIVE_TASKS_SLEEP_S = 1
SHOULD_STOP_TIMEOUT_S = 0.1
INFERENCE_INIT_TIMEOUT_S = 1200
VLLM_HEALTH_CHECK_TIMEOUT_S = 600.0


def model_dims_from_vllm_config(vllm_config: "vllm.config.VllmConfig") -> utils.ModelDims:
    model_config = vllm_config.model_config
    hidden_size = model_config.get_hidden_size()
    intermediate_size = getattr(model_config.hf_text_config, "intermediate_size", 4 * hidden_size)
    sliding_window = getattr(model_config.hf_text_config, "sliding_window", None)
    num_layers = model_config.get_num_layers(vllm_config.parallel_config)
    num_sliding_window_layers = 0

    if sliding_window is not None:
        layer_types = getattr(model_config.hf_text_config, "layer_types", None)
        num_sliding_window_layers = layer_types.count("sliding_attention") if layer_types is not None else num_layers

    return utils.ModelDims(
        num_layers=num_layers,
        hidden_size=hidden_size,
        intermediate_size=intermediate_size,
        vocab_size=model_config.get_vocab_size(),
        num_attn_heads=model_config.hf_text_config.num_attention_heads,
        num_kv_heads=model_config.hf_text_config.num_key_value_heads,
        head_dim=model_config.get_head_size(),
        sliding_window=sliding_window,
        num_sliding_window_layers=num_sliding_window_layers,
        device_name=utils.get_device_name(torch.cuda.get_device_name(0)) if torch.cuda.is_available() else None,
    )


class WeightUpdateInfo(TypedDict):
    names: list[str]
    dtype_names: list[str]
    shapes: list[list[int]]
    packed: bool


class WeightUpdateRPCArgs(TypedDict):
    update_info: WeightUpdateInfo


@dataclasses.dataclass
class SamplingConfig:
    temperature: float
    top_p: float = 1.0
    max_tokens: int = 256
    min_tokens: int = 0
    n: int = 1
    stop: list[str] | None = None
    seed: int | None = None
    logprobs: int | None = 1


@dataclasses.dataclass
class CompletionOutput:
    index: int
    token_ids: list[int]
    logprobs: list[float]
    finish_reason: str
    cumulative_logprob: float = 0.0
    mask: list[int] | None = None
    rollout_state: dict = dataclasses.field(default_factory=dict)
    """Rollout state dict — rewards, step_count, done, tool_output, tool_error, etc."""


@dataclasses.dataclass
class RequestOutput:
    request_id: str
    prompt_token_ids: list[int]
    outputs: list[CompletionOutput]
    finished: bool = True


def process_tool_tokens(
    tool_outputs: list[str],
    tool_parser: ToolParser,
    tokenizer,
    current_prompt_len: int,
    current_response_len: int,
    max_model_len: int,
    max_tokens: int,
    mask_tool_use: bool,
    role: str = "tool",
) -> tuple[list[int], list[float], list[int], int]:
    """Format, tokenize, and truncate tool outputs.

    Args:
        tool_outputs: Raw outputs from tool calls.
        tool_parser: Parser to format tool outputs.
        tokenizer: Tokenizer to encode formatted output.
        current_prompt_len: Current length of the prompt (for truncation).
        current_response_len: Current length of the response (for truncation).
        max_model_len: Maximum model sequence length.
        max_tokens: Maximum response tokens.
        mask_tool_use: Whether to mask tool tokens in loss computation.
        role: Chat role for formatting (e.g. "tool", "user" for text envs).

    Returns:
        Tuple of (tokens, logprobs, masks, excess).
    """
    formatted_output = tool_parser.format_tool_outputs(tool_outputs, role=role)
    try:
        tokens = tokenizer.encode(formatted_output, add_special_tokens=False)
    except TypeError:
        logger.warning("tokenizer.encode failed on tool output (len=%d), using empty tokens", len(formatted_output))
        tokens = []

    tokens, excess = truncate_tool_output_tokens(
        tokens,
        current_prompt_len=current_prompt_len,
        current_response_len=current_response_len,
        max_model_len=max_model_len,
        max_tokens=max_tokens,
    )

    logprobs = [0.0] * len(tokens)
    masks = [0 if mask_tool_use else 1] * len(tokens)

    return tokens, logprobs, masks, excess


def assert_threaded_actor(instance):
    """Assert that an instance's class is suitable for use in a threaded (non-async) Ray actor.

    This function performs two checks:
      1. The class must not define any `async def` methods
         (including async generators, staticmethods, or classmethods).
      2. There must not be a running asyncio event loop in the current thread.

    Args:
        instance: The instance whose class to inspect.

    Raises:
        AssertionError: If the class defines one or more async methods, or a running asyncio event loop is detected.
    """
    try:
        loop = asyncio.get_running_loop()
        raise AssertionError(
            f"{instance.__class__.__name__} must run in a threaded Ray actor (no running event loop). "
            f"Detected RUNNING loop={loop!r} on thread='{threading.current_thread().name}'. "
            f"Python={sys.version.split()[0]}."
        )
    except RuntimeError:
        return


def truncate_tool_output_tokens(
    tool_output_token_ids: list[int],
    current_prompt_len: int,
    current_response_len: int,
    max_model_len: int,
    max_tokens: int,
) -> tuple[list[int], int]:
    """Truncate tool output tokens to fit within max_model_len and max_tokens.

    Args:
        tool_output_token_ids: Token IDs from the tool output to potentially truncate.
        current_prompt_len: Number of tokens in the current prompt (original + accumulated).
        current_response_len: Number of tokens in the response so far (for max_tokens check).
        max_model_len: Maximum total sequence length the model can handle.
        max_tokens: Maximum number of response tokens allowed.

    Returns:
        A tuple of (truncated_tokens, excess) where excess is the number of tokens
        that exceeded max_model_len (0 if no truncation due to max_model_len).
    """
    total_len = current_prompt_len + len(tool_output_token_ids)
    excess = max(0, total_len - max_model_len)
    if excess > 0:
        tool_output_token_ids = tool_output_token_ids[:-excess] if excess < len(tool_output_token_ids) else []

    remaining = max(0, max_tokens - current_response_len)
    return tool_output_token_ids[:remaining], excess


# Edited from: https://github.com/OpenRLHF/OpenRLHF/pull/971/files
# Turns out Ray doesnt necessarily place bundles together,
# so this function is used to get the bundle indices of a placement group
# and ensure that the bundles placed on the same node are grouped together.
# avoids unnecessary communication for TP>1 with vllm.
def get_bundle_indices_list(placement_group: ray.util.placement_group) -> list[int]:
    pg_infos = ray.util.placement_group_table(placement_group)

    node_id_to_bundles = defaultdict(list)
    for bundle, node_id in pg_infos["bundles_to_node_id"].items():
        node_id_to_bundles[node_id].append(bundle)

    flattened_bundle_indices = []
    for bundles in node_id_to_bundles.values():
        flattened_bundle_indices.extend(bundles)
    return flattened_bundle_indices


def make_request_id(request: PromptRequest) -> str:
    """Generate a unique tracking key for a request."""
    prefix = "eval" if request.is_eval else "train"
    return f"{prefix}_{request.prompt_id}"


def split_request_id(full_request_id: str) -> dict:
    """Split request ID into base ID and request index.

    >>> split_request_id("train_0_43039_0")
    {'base_id': 'train_0_43039', 'request_index': 0}
    >>> split_request_id("eval_0_12345_2")
    {'base_id': 'eval_0_12345', 'request_index': 2}
    """
    parts = full_request_id.split("_")
    return {"base_id": "_".join(parts[:-1]), "request_index": int(parts[-1])}


def process_completed_request(request_id, outs, current_time, use_tools, request_metadata, dataset_lookup=None):
    """Process a completed request with all its samples and return the result.

    Args:
        request_id: The base request ID
        outs: List of RequestOutput objects for all sub-requests
        current_time: Current timestamp for performance metrics
        use_tools: Boolean indicating if tools were used
        request_metadata: Dictionary containing metadata for all requests
        dataset_lookup: Optional callable ``(index, is_eval) -> dict`` that resolves
            the dataset example for this request, applying any ground-truth overrides
            from the request metadata.

    Returns:
        Tuple of (result, is_eval, example) where example is the resolved dataset
        row (with any ground-truth override applied), or None if no dataset_lookup
        was provided.
    """
    final_output = RequestOutput(
        request_id=request_id,
        prompt_token_ids=outs[0].prompt_token_ids,
        outputs=[completion for out in outs for completion in out.outputs],
    )

    total_generation_tokens = sum(len(completion.token_ids) for out in outs for completion in out.outputs)
    metadata = request_metadata[request_id]

    response_ids = [list(out.token_ids) for out in final_output.outputs]
    finish_reasons = [out.finish_reason for out in final_output.outputs]

    logprobs = []
    for idx, out in enumerate(final_output.outputs):
        assert len(out.token_ids) == len(out.logprobs), (
            f"CompletionOutput {idx}: token_ids length ({len(out.token_ids)}) != logprobs length ({len(out.logprobs)})"
        )
        logprobs.append(out.logprobs)

    if use_tools:
        rollout_states = [out.rollout_state for out in final_output.outputs]
        masks = [getattr(out, "mask", [1] * len(out.token_ids)) for out in final_output.outputs]
        num_calls = [rs.get("step_count", 0) for rs in rollout_states]
        timeouts = [rs.get("timeout", False) for rs in rollout_states]
        tool_errors = [rs.get("tool_error", "") for rs in rollout_states]
        tool_outputs = [rs.get("tool_output", "") for rs in rollout_states]
        tool_runtimes = [rs.get("tool_runtime", 0.0) for rs in rollout_states]
        tool_calleds = [rs.get("step_count", 0) > 0 for rs in rollout_states]
        tool_call_stats = [[ToolCallStats(**s) for s in rs.get("tool_call_stats", [])] for rs in rollout_states]
    else:
        rollout_states = [{} for _ in response_ids]
        masks = [[1] * len(resp) for resp in response_ids]
        num_calls = [0] * len(response_ids)
        timeouts = [False] * len(response_ids)
        tool_errors = [""] * len(response_ids)
        tool_outputs = [""] * len(response_ids)
        tool_runtimes = [0.0] * len(response_ids)
        tool_calleds = [False] * len(response_ids)
        tool_call_stats = [[] for _ in response_ids]

    result = GenerationResult(
        responses=response_ids,
        finish_reasons=finish_reasons,
        masks=masks,
        request_info=RequestInfo(
            num_calls=num_calls,
            timeouts=timeouts,
            tool_errors=tool_errors,
            tool_outputs=tool_outputs,
            tool_runtimes=tool_runtimes,
            tool_calleds=tool_calleds,
            tool_call_stats=tool_call_stats,
            rollout_states=rollout_states,
        ),
        index=metadata["index"],
        prompt_id=metadata["prompt_id"],
        token_statistics=TokenStatistics(
            num_prompt_tokens=len(metadata["prompt_token_ids"]),
            num_response_tokens=total_generation_tokens,
            generation_time=current_time - metadata["start_time"],
        ),
        start_time=metadata["start_time"],
        logprobs=logprobs,
        model_step=metadata.get("model_step"),
    )
    is_eval = metadata["is_eval"]

    example = None
    if dataset_lookup is not None:
        example = dataset_lookup(metadata["index"], is_eval)
        ground_truth_from_request = metadata.get("ground_truth")
        if ground_truth_from_request is not None and not is_eval:
            example[GROUND_TRUTHS_KEY] = ground_truth_from_request

    return result, is_eval, example


def ray_noset_visible_devices(env_vars=os.environ):
    # Refer to
    # https://github.com/ray-project/ray/blob/161849364a784442cc659fb9780f1a6adee85fce/python/ray/_private/accelerators/nvidia_gpu.py#L95-L96
    # https://github.com/ray-project/ray/blob/161849364a784442cc659fb9780f1a6adee85fce/python/ray/_private/accelerators/amd_gpu.py#L102-L103
    # https://github.com/ray-project/ray/blob/161849364a784442cc659fb9780f1a6adee85fce/python/ray/_private/accelerators/npu.py#L94-L95
    # https://github.com/ray-project/ray/blob/161849364a784442cc659fb9780f1a6adee85fce/python/ray/_private/accelerators/hpu.py#L116-L117
    # https://github.com/ray-project/ray/blob/161849364a784442cc659fb9780f1a6adee85fce/python/ray/_private/accelerators/neuron.py#L108-L109
    # https://github.com/ray-project/ray/blob/161849364a784442cc659fb9780f1a6adee85fce/python/ray/_private/accelerators/tpu.py#L171-L172
    # https://github.com/ray-project/ray/blob/161849364a784442cc659fb9780f1a6adee85fce/python/ray/_private/accelerators/intel_gpu.py#L97-L98
    NOSET_VISIBLE_DEVICES_ENV_VARS_LIST = [
        "RAY_EXPERIMENTAL_NOSET_CUDA_VISIBLE_DEVICES",
        "RAY_EXPERIMENTAL_NOSET_ROCR_VISIBLE_DEVICES",
        "RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES",
        "RAY_EXPERIMENTAL_NOSET_HABANA_VISIBLE_MODULES",
        "RAY_EXPERIMENTAL_NOSET_NEURON_RT_VISIBLE_CORES",
        "RAY_EXPERIMENTAL_NOSET_TPU_VISIBLE_CHIPS",
        "RAY_EXPERIMENTAL_NOSET_ONEAPI_DEVICE_SELECTOR",
    ]
    return any(env_vars.get(env_var) for env_var in NOSET_VISIBLE_DEVICES_ENV_VARS_LIST)


@backoff.on_exception(backoff.constant, (aiohttp.ClientError, RuntimeError, TimeoutError), max_time=60, interval=0.5)
async def _check_health(port: int) -> None:
    async with (
        aiohttp.ClientSession() as session,
        session.get(
            f"http://127.0.0.1:{port}/health", timeout=aiohttp.ClientTimeout(total=VLLM_HEALTH_CHECK_TIMEOUT_S)
        ) as response,
    ):
        if response.status != 200:
            raise RuntimeError(f"vLLM server health check failed with status {response.status}")


def _prefetch_worker(actor: "LLMRayActor") -> None:
    while True:
        if actor._should_stop() or len(actor.active_tasks) >= actor.inference_batch_size:
            time.sleep(DRAIN_ACTIVE_TASKS_SLEEP_S)
            continue

        request = actor.prompt_queue.get()
        add_request(actor, request)


def add_request(actor: "LLMRayActor", request: PromptRequest) -> None:
    request_id = make_request_id(request)
    sampling_params = dataclasses.replace(request.generation_config, n=1)

    actor.request_metadata[request_id] = {
        "is_eval": request.is_eval,
        "index": request.index,
        "prompt_id": request.prompt_id,
        "model_step": actor.current_model_step,
        "sampling_params": sampling_params,
        "original_sampling_params": request.generation_config,
        "prompt_token_ids": list(request.prompt),
        "start_time": time.perf_counter(),
        "active_tools": request.active_tools,
        "env_config": request.env_config,
        "ground_truth": request.ground_truth,
    }

    for j in range(request.generation_config.n):
        seed = request.generation_config.seed + j if request.generation_config.seed is not None else None
        sub_sampling_params = dataclasses.replace(sampling_params, seed=seed)
        sub_request_id = f"{request_id}_{j}"
        actor.active_tasks[sub_request_id] = asyncio.run_coroutine_threadsafe(
            process_request(actor, sub_request_id, sub_sampling_params), actor.loop
        )


FALLBACK_CHAT_TEMPLATE = "{% for message in messages %}{{ message['content'] }}{% endfor %}"


def _create_server_args(model_path: str, has_chat_template: bool) -> argparse.Namespace:
    parser = FlexibleArgumentParser()
    parser = make_arg_parser(parser)
    cli_args = ["--model", model_path]
    if not has_chat_template:
        cli_args.extend(["--chat-template", FALLBACK_CHAT_TEMPLATE])
    args = parser.parse_args(cli_args)
    args.disable_fastapi_docs = True
    return args


def accumulate_completions(actor: "LLMRayActor", sub_request: dict) -> futures.Future | None:
    base_request_id = sub_request["base_request_id"]
    expected_n = sub_request["expected_n"]

    if base_request_id not in actor.request_outputs:
        actor.request_outputs[base_request_id] = {
            "outputs": [],
            "expected_n": expected_n,
            "use_tools": sub_request["use_tools"],
        }

    actor.request_outputs[base_request_id]["outputs"].append(sub_request["request_output"])

    if len(actor.request_outputs[base_request_id]["outputs"]) == expected_n:
        return asyncio.run_coroutine_threadsafe(finalize_completed_request(actor, base_request_id), actor.loop)

    return None


async def finalize_completed_request(actor: "LLMRayActor", base_request_id: str) -> None:
    outputs = actor.request_outputs[base_request_id]["outputs"]
    ordered_outs = sorted(outputs, key=lambda x: split_request_id(x.request_id)["request_index"])

    current_time = time.perf_counter()

    def _dataset_lookup(index: int, is_eval_req: bool) -> dict:
        ds = actor.eval_dataset if is_eval_req else actor.train_dataset
        idx_map = actor._eval_index_map if is_eval_req else actor._train_index_map
        return dict(ds[idx_map[index]])

    result, is_eval, example = process_completed_request(
        base_request_id,
        ordered_outs,
        current_time,
        actor.request_outputs[base_request_id]["use_tools"],
        actor.request_metadata,
        dataset_lookup=_dataset_lookup,
    )

    actor.request_outputs.pop(base_request_id)
    actor.request_metadata.pop(base_request_id, None)

    result.reward_scores, result.reward_metrics = await compute_rewards(actor, result, example)
    results_queue = actor.eval_results_queue if is_eval else actor.results_queue
    results_queue.put(result)


async def compute_rewards(actor: "LLMRayActor", result: GenerationResult, example: dict) -> tuple[list[float], dict]:
    decoded_responses = actor.llm_engine.tokenizer.batch_decode(result.responses, skip_special_tokens=True)

    k = len(result.responses)
    k_ground_truths = [example[GROUND_TRUTHS_KEY]] * k
    k_datasets = [example[VERIFIER_SOURCE_KEY]] * k
    k_raw_queries = [example[RAW_PROMPT_KEY]] * k

    scores, metrics = await actor.reward_fn(
        result.responses,
        decoded_responses,
        k_ground_truths,
        k_datasets,
        result.finish_reasons,
        result.request_info,
        k_raw_queries,
    )
    return scores, metrics


class LLMRayActor:
    """Ray actor for LLM generation with optional tool support."""

    def __init__(
        self,
        *args,
        tool_parser_type: str = "legacy",
        tool_definitions: list[dict] | None = None,
        tool_stop_sequences: list[str] | None = None,
        max_steps: int = 5,
        per_turn_max_tokens: int | None = None,
        tool_call_timeout: float = 1800.0,
        mask_tool_use: bool = True,
        pools: dict[str, ray.actor.ActorHandle] | None = None,
        bundle_indices: list[int] | None = None,
        prompt_queue: ray_queue.Queue,
        results_queue: ray_queue.Queue,
        eval_results_queue: ray_queue.Queue,
        actor_manager: ray.actor.ActorHandle,
        inflight_updates: bool,
        reward_config: RewardConfig | None = None,
        train_dataset=None,
        eval_dataset=None,
        **kwargs,
    ):
        assert_threaded_actor(self)
        self._tool_definitions = tool_definitions
        self._tool_stop_sequences = tool_stop_sequences
        self._init_config(
            max_steps,
            per_turn_max_tokens,
            tool_call_timeout,
            mask_tool_use,
            pools,
            inflight_updates,
            reward_config,
            train_dataset,
            eval_dataset,
        )
        self._init_queues(prompt_queue, results_queue, eval_results_queue, actor_manager)

        noset_visible_devices = kwargs.pop("noset_visible_devices")
        distributed_executor_backend = kwargs.get("distributed_executor_backend")
        self._setup_gpu_visibility(noset_visible_devices, distributed_executor_backend)
        self._setup_and_start_async_engine(args, bundle_indices, kwargs)
        self._init_openai_client()
        self.inference_batch_size = self.get_kv_cache_info()
        self._init_executor()
        # comes after executor as it requires tokenizer access.
        self._init_tool_parser(tool_parser_type)

    def _init_config(
        self,
        max_steps: int,
        per_turn_max_tokens: int | None,
        tool_call_timeout: float,
        mask_tool_use: bool,
        pools: dict[str, ray.actor.ActorHandle] | None,
        inflight_updates: bool,
        reward_config: RewardConfig | None,
        train_dataset,
        eval_dataset,
    ) -> None:
        self.max_steps = max_steps
        self.per_turn_max_tokens = per_turn_max_tokens
        self.tool_call_timeout = tool_call_timeout
        self.mask_tool_use = mask_tool_use
        self.pools: dict[str, ray.actor.ActorHandle] = pools or {}
        self.inflight_updates = inflight_updates
        self.request_metadata = {}
        self.active_tasks = {}
        self.request_outputs = {}
        self.reward_config = reward_config
        self.train_dataset = train_dataset
        self.eval_dataset = eval_dataset
        self.current_model_step: int = 0
        self._train_index_map: dict[int, int] = (
            {train_dataset[i]["index"]: i for i in range(len(train_dataset))} if train_dataset is not None else {}
        )
        self._eval_index_map: dict[int, int] = (
            {eval_dataset[i]["index"]: i for i in range(len(eval_dataset))} if eval_dataset is not None else {}
        )
        self.reward_fn = reward_config.build() if reward_config else None
        self.tool_parser: ToolParser  # Set in _init_tool_parser

    def _init_queues(self, prompt_queue, results_queue, eval_results_queue, actor_manager) -> None:
        self.completion_queue = queue.Queue()
        self.prompt_queue = prompt_queue
        self.results_queue = results_queue
        self.eval_results_queue = eval_results_queue
        self.actor_manager = actor_manager

        # For caching should_stop status.
        self._last_should_stop_update = float("-inf")
        self._should_stop_value = False

    def _init_executor(self) -> None:
        max_workers = NUM_PREFETCH_WORKERS
        self.executor = futures.ThreadPoolExecutor(max_workers=max_workers)
        self._prefetch_future = self.executor.submit(_prefetch_worker, self)
        self._process_future = self.executor.submit(self.process_from_queue)

    def _init_tool_parser(self, tool_parser_type: str) -> None:
        self.tool_parser = create_tool_parser(
            parser_type=tool_parser_type,
            tokenizer=self.llm_engine.tokenizer,
            tool_definitions=self._tool_definitions,
            stop_sequences=self._tool_stop_sequences,
        )

    def _setup_gpu_visibility(self, noset_visible_devices: bool, distributed_executor_backend: str) -> None:
        # a hack to make the script work.
        # stop ray from manipulating *_VISIBLE_DEVICES
        # at the top-level when the distributed_executor_backend is ray.
        if distributed_executor_backend == "ray":
            os.environ.pop("CUDA_VISIBLE_DEVICES", None)
            os.environ.pop("ROCR_VISIBLE_DEVICES", None)
        elif noset_visible_devices:
            # We need to set CUDA_VISIBLE_DEVICES to the ray assigned GPU
            # when the distributed_executor_backend is not ray and
            # RAY_EXPERIMENTAL_NOSET_*_VISIBLE_DEVICES is set.
            os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(str(g) for g in ray.get_gpu_ids())

    def _setup_and_start_async_engine(self, args, bundle_indices, kwargs) -> None:
        num_gpus = kwargs.pop("num_gpus")
        if bundle_indices is not None:
            os.environ["VLLM_RAY_PER_WORKER_GPUS"] = str(num_gpus)
            os.environ["VLLM_RAY_BUNDLE_INDICES"] = ",".join(map(str, bundle_indices))
            logger.debug(f"creating LLM with bundle_indices={bundle_indices}")

        # Force vLLM-native generation defaults at the engine level so
        # model-provided HF generation_config (e.g., max_new_tokens=2048)
        # cannot cap request max_tokens via OpenAI serving defaults.
        kwargs["generation_config"] = "vllm"
        engine_args = vllm.AsyncEngineArgs(*args, **kwargs)
        engine_args.disable_log_stats = True
        engine_args.disable_cascade_attn = True

        init_complete = threading.Event()
        self.loop = None
        self.llm_engine = None
        self.client = None
        self.server_port = None

        async def _init_engine_and_server():
            running_loop = asyncio.get_running_loop()
            assert running_loop == self.loop, f"Loop mismatch! running={running_loop}, actor.loop={self.loop}"

            engine_client = vllm.AsyncLLMEngine.from_engine_args(engine_args, start_engine_loop=False)

            tokenizer = engine_client.tokenizer
            inner_tokenizer = getattr(tokenizer, "tokenizer", tokenizer)
            has_chat_template = getattr(inner_tokenizer, "chat_template", None) is not None
            args = _create_server_args(engine_client.vllm_config.model_config.model, has_chat_template)
            app = build_app(args)
            await init_app_state(engine_client, app.state, args)

            # There is a TOCTOU race: another process could claim the port between
            # find_free_port() and uvicorn binding. Unlikely in practice.
            self.server_port = utils.find_free_port()

            logger.info(f"Starting vLLM OpenAI API server on port {self.server_port}")

            config = uvicorn.Config(app, host="127.0.0.1", port=self.server_port, log_level="warning")
            asyncio.create_task(uvicorn.Server(config).serve())

            # Yield control to allow the server task to start before returning.
            await asyncio.sleep(0.1)

            return engine_client

        def _run_loop():
            try:
                self.loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self.loop)
                self.llm_engine = self.loop.run_until_complete(_init_engine_and_server())
            finally:
                # Signal completion to the waiting main thread even if init failed.
                init_complete.set()
            self.loop.run_forever()

        self.loop_thread = threading.Thread(target=_run_loop, daemon=True)
        self.loop_thread.start()

        if init_complete.wait(timeout=INFERENCE_INIT_TIMEOUT_S):
            if self.llm_engine is None:
                raise RuntimeError("vLLM engine initialization failed. Check Ray worker logs for details.")
            return
        message = "timed out" if self.loop_thread.is_alive() else "thread died before completing"
        raise RuntimeError(f"vLLM engine {message}")

    def _init_openai_client(self) -> None:
        base_url = f"http://127.0.0.1:{self.server_port}/v1"
        self.client = openai.AsyncOpenAI(base_url=base_url, api_key="EMPTY", timeout=3600)
        self.model_name = self.llm_engine.vllm_config.model_config.model

        logger.info(f"Waiting for vLLM OpenAI API server to be ready at {base_url}")

        asyncio.run(_check_health(self.server_port))
        logger.info("vLLM OpenAI API server is ready")

    def get_model_dims(self):
        return model_dims_from_vllm_config(self.llm_engine.vllm_config)

    def _should_stop(self) -> bool:
        if self.actor_manager is None:
            return self._should_stop_value
        if (time.perf_counter() - self._last_should_stop_update) > SHOULD_STOP_TIMEOUT_S:
            should_stop_ref = self.actor_manager.should_stop.remote()
            ready_refs, _ = ray.wait([should_stop_ref], timeout=SHOULD_STOP_TIMEOUT_S)
            if ready_refs:
                self._should_stop_value = ray.get(ready_refs[0])
                self._last_should_stop_update = time.perf_counter()
            else:
                ray.cancel(should_stop_ref)
        return self._should_stop_value

    def process_from_queue(self) -> None:
        finalize_futures: list[futures.Future] = []
        while True:
            completion_future = accumulate_completions(self, self.completion_queue.get())
            if completion_future is not None:
                finalize_futures.append(completion_future)

            done, not_done = futures.wait(finalize_futures, timeout=0)
            [future.result() for future in done]
            finalize_futures = list(not_done)

    def init_weight_transfer_engine(self, request: WeightTransferInitRequest) -> None:
        return self._run_async(self.llm_engine.init_weight_transfer_engine(request))

    def _run_async(self, coro: Awaitable[Any]) -> Any:
        future = asyncio.run_coroutine_threadsafe(coro, self.loop)
        return future.result()

    def sleep(self) -> None:
        return self._run_async(self.llm_engine.sleep(level=0, mode="keep"))

    def wake_up(self) -> None:
        return self._run_async(self.llm_engine.wake_up(tags=["scheduling"]))

    def update_weights(self, update_info: WeightUpdateRPCArgs, model_step: int | None = None) -> None:
        # IPCWeightTransferEngine.trainer_send_weights (vllm) calls this RPC with
        # `dict(update_info=...)` and no model_step; NCCL callers pass model_step explicitly.
        while not self.inflight_updates and len(self.active_tasks) > 0:
            self.check_background_threads()
            time.sleep(DRAIN_ACTIVE_TASKS_SLEEP_S)
        self._run_async(self.llm_engine.update_weights(WeightTransferUpdateRequest(**update_info)))
        if model_step is not None:
            self.current_model_step = model_step

    def reset_prefix_cache(self) -> None:
        return self._run_async(self.llm_engine.reset_prefix_cache())

    def ready(self) -> bool:
        return True

    def set_model_step(self, model_step: int) -> None:
        self.current_model_step = model_step

    def check_background_threads(self) -> None:
        if self._prefetch_future.done():
            self._prefetch_future.result()
        if self._process_future.done():
            self._process_future.result()
        for task in self.active_tasks.values():
            if task.done():
                task.result()
        if not self.loop_thread.is_alive():
            raise RuntimeError(
                "vLLM engine loop thread has died. Check logs for errors in EngineCore or async engine."
            )

    def get_kv_cache_info(self) -> int:
        """Get KV cache max concurrency from the vLLM engine."""
        kv_cache_specs = self._run_async(self.llm_engine.collective_rpc("get_kv_cache_spec"))

        vllm_config = self.llm_engine.vllm_config
        gpu_memory_utilization = vllm_config.cache_config.gpu_memory_utilization
        total_gpu_memory = torch.cuda.get_device_properties(0).total_memory
        available_memory = int(gpu_memory_utilization * total_gpu_memory)

        kv_cache_groups = kv_cache_utils.get_kv_cache_groups(vllm_config, kv_cache_specs[0])

        kv_cache_config = kv_cache_utils.get_kv_cache_config_from_groups(
            vllm_config, kv_cache_groups, available_memory
        )

        max_concurrency = kv_cache_utils.get_max_concurrency_for_kv_cache_config(vllm_config, kv_cache_config)

        return int(max_concurrency)


def _register_tool_dispatch(
    pool_name: str,
    target_actor: Any,
    target_tools: list[dict[str, Any]] | None,
    target_response_role: str,
    existing_actor_map: dict[str, Any],
) -> tuple[dict[str, Any], set[str], dict[str, str]]:
    """Map individual tool names exposed by a pool actor for dispatch.

    Returns (actor_map entries, tool names, response_role entries) to merge
    into the caller's tables.  Raises on name clashes with existing actors.
    """
    actor_map: dict[str, Any] = {}
    tool_names: set[str] = set()
    response_roles: dict[str, str] = {}
    if not target_tools:
        return actor_map, tool_names, response_roles
    for tool_def in target_tools:
        name = tool_def["function"]["name"]
        existing = existing_actor_map.get(name)
        if existing is not None and existing != target_actor:
            raise ValueError(
                f"Target '{pool_name}' exposes tool name '{name}' that clashes with "
                "another active target. Rename one side to avoid ambiguous dispatch."
            )
        actor_map[name] = target_actor
        tool_names.add(name)
        response_roles[name] = target_response_role
    return actor_map, tool_names, response_roles


@dataclasses.dataclass
class PoolSetup:
    """Result of acquiring and resetting all configured tool/env pools for a request."""

    acquired: dict[str, tuple[Any, Any]]
    actor_map: dict[str, Any]
    allowed_tools: set[str]
    tool_response_roles: dict[str, str]
    active_env_names: list[str]
    text_env_names: list[str]


async def _acquire_and_reset_pools(
    pools: dict[str, Any], configured_tools: set[str], env_config: EnvConfig, allowed_tools: set[str]
) -> PoolSetup:
    """Acquire an actor from each pool and reset it with per-env kwargs.

    Populates the actor dispatch map (pool names + individual tool names)
    and discovers text environments.
    """
    acquired: dict[str, tuple[Any, Any]] = {}
    actor_map: dict[str, Any] = {}
    tool_response_roles: dict[str, str] = {}
    active_env_names: list[str] = []
    text_env_names: list[str] = []

    for pool_name in sorted(configured_tools):
        pool = pools.get(pool_name)
        if pool is None:
            raise ValueError(f"No pool for target '{pool_name}'. Available: {list(pools.keys())}")

        target_actor = await pool.acquire.remote()
        acquired[pool_name] = (pool, target_actor)
        actor_map[pool_name] = target_actor
        active_env_names.append(pool_name)

        entry = env_config.env_configs.get(pool_name, EnvConfigEntry(env_name=pool_name, is_text_env=False))
        _, target_tools = await target_actor.reset.remote(**entry.kwargs)
        target_response_role = await target_actor.get_response_role.remote()
        tool_response_roles[pool_name] = target_response_role

        new_actors, new_tools, new_roles = _register_tool_dispatch(
            pool_name, target_actor, target_tools, target_response_role, actor_map
        )
        actor_map.update(new_actors)
        allowed_tools.update(new_tools)
        tool_response_roles.update(new_roles)

        if entry.is_text_env:
            text_env_names.append(pool_name)
            allowed_tools.add(pool_name)

    if len(text_env_names) > 1:
        raise ValueError(f"Only one text environment may be active per rollout, got: {sorted(text_env_names)}")

    unresolved = allowed_tools - set(actor_map.keys())
    if unresolved:
        raise ValueError(
            f"Some allowed tools have no active dispatch target: {sorted(unresolved)}. "
            f"Active targets: {sorted(actor_map.keys())}"
        )

    return PoolSetup(
        acquired=acquired,
        actor_map=actor_map,
        allowed_tools=allowed_tools,
        tool_response_roles=tool_response_roles,
        active_env_names=active_env_names,
        text_env_names=text_env_names,
    )


async def process_request(actor: LLMRayActor, sub_request_id: str, sampling_params: SamplingConfig):
    """Process a single async request with tool/environment support."""
    await _check_health(actor.server_port)

    response_tokens: list[int] = []
    response_logprobs: list[float] = []
    response_masks: list[int] = []
    cumulative_logprob = 0.0
    rollout = RolloutState()

    base_request_id = split_request_id(sub_request_id)["base_id"]
    request_metadata = actor.request_metadata[base_request_id]
    original_prompt = request_metadata["prompt_token_ids"]
    active_tools = request_metadata["active_tools"]
    env_config: EnvConfig = request_metadata.get("env_config", EnvConfig())
    current_prompt = list(original_prompt)
    max_model_len = actor.llm_engine.model_config.max_model_len

    configured_tools = set(actor.pools.keys())
    allowed_tools = configured_tools & set(active_tools) if active_tools is not None else set(configured_tools)

    max_steps = env_config.max_steps

    output = None
    pool_setup = PoolSetup(
        acquired={},
        actor_map={},
        allowed_tools=allowed_tools,
        tool_response_roles={},
        active_env_names=[],
        text_env_names=[],
    )
    try:
        unknown_targets = set(env_config.env_configs) - configured_tools
        if unknown_targets:
            raise ValueError(
                f"env_config references envs/tools that are not configured: {sorted(unknown_targets)}. "
                f"Available envs/tools: {sorted(configured_tools)}"
            )

        pool_setup = await _acquire_and_reset_pools(actor.pools, configured_tools, env_config, allowed_tools)
        actor_map = pool_setup.actor_map
        allowed_tools = pool_setup.allowed_tools
        tool_response_roles = pool_setup.tool_response_roles
        text_env_names = pool_setup.text_env_names

        while rollout.step_count < max_steps:
            if rollout.done:
                break

            remaining_budget = sampling_params.max_tokens - len(response_masks)
            remaining_room = max_model_len - len(current_prompt)
            per_turn_budget = actor.per_turn_max_tokens if actor.per_turn_max_tokens is not None else remaining_budget
            current_max_tokens = max(1, min(remaining_budget, remaining_room, per_turn_budget))
            if remaining_budget <= 0 or remaining_room <= 0:
                break

            current_sampling_params = dataclasses.replace(sampling_params, max_tokens=current_max_tokens)
            params_dict = dataclasses.asdict(current_sampling_params)
            min_tokens = params_dict.pop("min_tokens", 0)
            api_response = await actor.client.completions.create(
                model=actor.model_name,
                prompt=current_prompt,
                extra_body={
                    "return_token_ids": True,
                    "cache_salt": base_request_id,
                    "include_stop_str_in_output": True,
                    "skip_special_tokens": False,
                    "min_tokens": min_tokens,
                },
                **params_dict,
            )

            output = api_response.choices[0]
            model_tokens = list(output.token_ids)
            response_tokens.extend(model_tokens)
            current_prompt.extend(model_tokens)

            assert output.logprobs and output.logprobs.token_logprobs, "logprobs must be available"
            for logprob in output.logprobs.token_logprobs:
                response_logprobs.append(logprob)
                cumulative_logprob += logprob
            response_masks.extend([1] * len(model_tokens))

            tool_calls = [tc for tc in actor.tool_parser.get_tool_calls(output.text) if tc.name in allowed_tools]

            # Text envs: inject a shadow tool call so dispatch handles it uniformly
            for text_env_name in text_env_names:
                tool_calls.append(EnvCall(id="", name=text_env_name, args={"text": output.text}))

            if not tool_calls:
                break

            observations: list[tuple[str, str]] = []
            for tc in tool_calls:
                if rollout.step_count >= max_steps:
                    break

                target = actor_map.get(tc.name)
                if target is None:
                    raise ValueError(
                        f"Model called tool '{tc.name}' but no active dispatch target exists. "
                        f"Available targets: {sorted(actor_map.keys())}"
                    )

                rollout.step_count += 1

                try:
                    step_result: StepResult = await asyncio.wait_for(
                        target.step.remote(EnvCall(id=str(rollout.step_count), name=tc.name, args=tc.args)),
                        timeout=actor.tool_call_timeout,
                    )
                    observations.append((step_result.result, tool_response_roles.get(tc.name, "tool")))
                    rollout.tool_output += step_result.result
                    rollout.rewards.append(step_result.reward)
                    if step_result.done:
                        rollout.done = True
                    meta = step_result.metadata or {}
                    rollout.timeout = rollout.timeout or meta.get("timeout", False)
                    rollout.tool_error += meta.get("error", "")
                    rollout.tool_runtime += meta.get("runtime", 0.0)
                    rollout.tool_call_stats.append(
                        ToolCallStats(
                            tool_name=tc.name,
                            success=not meta.get("error") and not meta.get("timeout", False),
                            runtime=meta.get("runtime", 0.0),
                        )
                    )
                except asyncio.TimeoutError:
                    error_msg = f"Step '{tc.name}' timed out after {actor.tool_call_timeout}s. Args: {tc.args}"
                    logger.warning(error_msg)
                    observations.append((error_msg, "tool"))
                    rollout.tool_error += error_msg
                    rollout.timeout = True
                    rollout.rewards.append(0.0)
                    rollout.tool_call_stats.append(
                        ToolCallStats(tool_name=tc.name, success=False, runtime=actor.tool_call_timeout)
                    )
                except Exception as e:
                    error_msg = f"Step '{tc.name}' failed: {e}. Args: {tc.args}"
                    logger.warning(error_msg)
                    observations.append((error_msg, "tool"))
                    rollout.tool_error += error_msg
                    rollout.rewards.append(0.0)
                    rollout.tool_call_stats.append(ToolCallStats(tool_name=tc.name, success=False, runtime=0.0))

                if rollout.done:
                    break

            if observations:
                exceeded_context_budget = False
                for observation, response_role in observations:
                    tokens, logprobs, masks, excess = process_tool_tokens(
                        [observation],
                        actor.tool_parser,
                        actor.llm_engine.tokenizer,
                        len(current_prompt),
                        len(response_masks),
                        max_model_len,
                        sampling_params.max_tokens,
                        actor.mask_tool_use,
                        role=response_role,
                    )
                    response_tokens.extend(tokens)
                    response_logprobs.extend(logprobs)
                    response_masks.extend(masks)
                    current_prompt.extend(tokens)
                    if excess > 0:
                        exceeded_context_budget = True
                        break
                if exceeded_context_budget:
                    break
    finally:
        env_metrics: dict[str, dict[str, float]] = {}
        for env_name in pool_setup.active_env_names:
            if env_name in pool_setup.acquired:
                _, env_act = pool_setup.acquired[env_name]
                env_metrics[env_name] = await env_act.get_metrics.remote()
        if len(env_metrics) == 1:
            env_name, metrics = next(iter(env_metrics.items()))
            rollout.info["env_name"] = env_name
            rollout.info.update(metrics)
        elif env_metrics:
            rollout.info["env_metrics"] = env_metrics
        for pool, acq_actor in pool_setup.acquired.values():
            pool.release.remote(acq_actor)

    if len(response_tokens) == 0:
        eos_token_id = actor.llm_engine.tokenizer.eos_token_id
        response_tokens.append(eos_token_id)
        response_masks.append(1)
        response_logprobs.append(float("nan"))

    finish_reason = output.finish_reason if output else "stop"

    complete_output = CompletionOutput(
        index=split_request_id(sub_request_id)["request_index"],
        token_ids=response_tokens,
        cumulative_logprob=cumulative_logprob,
        logprobs=response_logprobs,
        finish_reason=finish_reason,
        mask=response_masks,
        rollout_state=dataclasses.asdict(rollout),
    )

    actor.active_tasks.pop(sub_request_id, None)
    actor.completion_queue.put(
        {
            "base_request_id": base_request_id,
            "expected_n": request_metadata["original_sampling_params"].n,
            "request_output": RequestOutput(
                request_id=sub_request_id,
                prompt_token_ids=request_metadata["prompt_token_ids"],
                outputs=[complete_output],
            ),
            "use_tools": bool(actor.pools),
        }
    )


def get_cuda_arch_list() -> str:
    """Get CUDA compute capabilities and format them for TORCH_CUDA_ARCH_LIST."""
    if not torch.cuda.is_available():
        return ""

    cuda_capabilities = []
    for i in range(torch.cuda.device_count()):
        major, minor = torch.cuda.get_device_capability(i)
        cuda_capabilities.append(f"{major}.{minor}")

    # Remove duplicates and sort
    cuda_capabilities = sorted(set(cuda_capabilities))
    cuda_arch_list = ";".join(cuda_capabilities)
    logger.info(
        f"Detected CUDA compute capabilities: {cuda_capabilities}, setting TORCH_CUDA_ARCH_LIST={cuda_arch_list}"
    )
    return cuda_arch_list


def create_vllm_engines(
    num_engines: int,
    tensor_parallel_size: int,
    enforce_eager: bool,
    tokenizer_name_or_path: str,
    pretrain: str,
    revision: str | None,
    seed: int,
    enable_prefix_caching: bool,
    max_model_len: int,
    vllm_gpu_memory_utilization: float = 0.9,
    single_gpu_mode: bool = False,
    pg: PlacementGroup | None = None,
    tool_parser_type: str = "legacy",
    tool_definitions: list[dict] | None = None,
    tool_stop_sequences: list[str] | None = None,
    max_steps: int = 5,
    per_turn_max_tokens: int | None = None,
    mask_tool_use: bool = True,
    pools: dict[str, ray.actor.ActorHandle] | None = None,
    prompt_queue=None,
    results_queue=None,
    eval_results_queue=None,
    actor_manager=None,
    inflight_updates: bool = False,
    reward_config: RewardConfig | None = None,
    train_dataset=None,
    eval_dataset=None,
    trust_remote_code: bool = False,
    vllm_attention_backend: str | None = None,
) -> list[ray.actor.ActorHandle]:
    vllm_engines = []
    # Use "mp" (multiprocessing) for TP > 1 when running inside a Ray actor.
    # Using "ray" executor causes placement group context loss in vLLM v1's
    # subprocess-based EngineCore architecture. See: https://github.com/vllm-project/vllm/issues/30016
    distributed_executor_backend = "uni" if tensor_parallel_size == 1 else "mp"
    use_hybrid_engine = pg is not None
    if tensor_parallel_size != 1 and use_hybrid_engine:
        raise ValueError("tensor_parallel_size > 1 is not supported with single_gpu_mode")
    # In single_gpu_mode, use 0.5 GPU so we can schedule 2 instances on the same GPUs.
    # Otherwise, request tensor_parallel_size GPUs so Ray sets CUDA_VISIBLE_DEVICES
    # correctly for the "mp" distributed executor backend.
    num_gpus = 0.5 if use_hybrid_engine and single_gpu_mode else tensor_parallel_size

    logger.info(f"num_gpus: {num_gpus}")

    if not use_hybrid_engine:
        # Create a placement group to ensure that all engines are packed.
        # Each bundle reserves tensor_parallel_size GPUs for one engine.
        bundles = [{"GPU": tensor_parallel_size, "CPU": tensor_parallel_size} for _ in range(num_engines)]
        pg = placement_group(bundles, strategy="PACK")
        ray.get(pg.ready())

    # ensure we use bundles on the same node where possible if tp>1.
    bundle_indices_list = get_bundle_indices_list(pg)

    for i in range(num_engines):
        if use_hybrid_engine:
            bundle_indices = bundle_indices_list[i * tensor_parallel_size : (i + 1) * tensor_parallel_size]
        else:
            bundle_indices = [bundle_indices_list[i]]

        scheduling_strategy = PlacementGroupSchedulingStrategy(
            placement_group=pg,
            placement_group_capture_child_tasks=True,
            placement_group_bundle_index=bundle_indices[0],
        )

        vllm_engines.append(
            ray.remote(LLMRayActor)
            .options(
                num_cpus=num_gpus,
                num_gpus=num_gpus,
                scheduling_strategy=scheduling_strategy,
                runtime_env=ray.runtime_env.RuntimeEnv(
                    env_vars={
                        "VLLM_ENABLE_V1_MULTIPROCESSING": "0",
                        "TORCH_CUDA_ARCH_LIST": get_cuda_arch_list(),
                        "RAY_ACCEL_ENV_VAR_OVERRIDE_ON_ZERO": "0",
                    }
                ),
            )
            .remote(
                model=pretrain,
                revision=revision,
                tokenizer=tokenizer_name_or_path,
                tokenizer_revision=revision,
                weight_transfer_config=WeightTransferConfig(backend="ipc" if use_hybrid_engine else "nccl"),
                tensor_parallel_size=tensor_parallel_size,
                enforce_eager=enforce_eager,
                dtype="bfloat16",
                seed=seed + i,
                distributed_executor_backend=distributed_executor_backend,
                enable_prefix_caching=enable_prefix_caching,
                max_model_len=max_model_len,
                gpu_memory_utilization=vllm_gpu_memory_utilization,
                logprobs_mode="processed_logprobs",
                bundle_indices=bundle_indices,
                num_gpus=0.2 if use_hybrid_engine else 1,
                noset_visible_devices=ray_noset_visible_devices(),
                prompt_queue=prompt_queue,
                results_queue=results_queue,
                eval_results_queue=eval_results_queue,
                actor_manager=actor_manager,
                tool_parser_type=tool_parser_type,
                tool_definitions=tool_definitions,
                tool_stop_sequences=tool_stop_sequences,
                max_steps=max_steps,
                per_turn_max_tokens=per_turn_max_tokens,
                mask_tool_use=mask_tool_use,
                pools=pools,
                inflight_updates=inflight_updates,
                reward_config=reward_config,
                train_dataset=train_dataset,
                eval_dataset=eval_dataset,
                trust_remote_code=trust_remote_code,
                attention_backend=vllm_attention_backend,
                language_model_only=True,
            )
        )

    utils.ray_get_with_progress(
        [engine.ready.remote() for engine in vllm_engines], "Initializing vLLM engines", timeout=1200
    )

    return vllm_engines


def _get_fsdp2_submodules(model: torch.nn.Module) -> list[tuple[str, FSDPModule]]:
    """Get all FSDP2-wrapped submodules (excluding the root if it's FSDP2)."""
    fsdp_modules = []
    for name, module in model.named_modules():
        if isinstance(module, FSDPModule) and module is not model:
            fsdp_modules.append((name, module))
    return fsdp_modules


def _prepare_params_for_sync(
    params: list[tuple[str, torch.nn.Parameter]], name_mapper: Callable[[str], str] | None
) -> list[tuple[str, torch.Tensor]]:
    """Map parameter names and clone into contiguous tensors for NCCL send.

    DS3 gathered tensors may be non-contiguous or views into temporary buffers.
    Cloning ensures we send independent, contiguous tensors over NCCL.
    """
    return [(name_mapper(n) if name_mapper else n, p.data.contiguous().clone()) for n, p in params]


def _collect_weight_metadata(
    model: torch.nn.Module, name_mapper: Callable[[str], str] | None
) -> tuple[list[str], list[str], list[list[int]]]:
    """Collect weight metadata (names, dtypes, shapes) without full parameter gathering.

    For DeepSpeed stage 3, uses ds_shape. For FSDP2 DTensors, .shape returns global shape.
    For FSDP1, param.shape returns full shape when parameters are registered (not flat).
    """
    names: list[str] = []
    dtype_names: list[str] = []
    shapes: list[list[int]] = []
    for name, param in model.named_parameters():
        mapped_name = name_mapper(name) if name_mapper else name
        names.append(mapped_name)
        dtype_names.append(str(param.dtype).split(".")[-1])
        shape = getattr(param, "ds_shape", param.shape)
        shapes.append(list(shape))
    return names, dtype_names, shapes


def _broadcast_weights_ipc(
    model: torch.nn.Module,
    vllm_engines: list[ray.actor.ActorHandle],
    name_mapper: Callable[[str], str] | None,
    gather_whole_model: bool,
    model_step: int,
) -> list[ray.ObjectRef]:
    """Broadcast weights using IPC backend (same-GPU / single_gpu_mode)."""
    is_rank_0 = torch.distributed.get_rank() == 0
    params = list(model.named_parameters())
    deepspeed_stage_3 = any(hasattr(p, "ds_id") for p in model.parameters())

    if isinstance(model, FSDP):
        ctx = FSDP.summon_full_params(model, writeback=False, rank0_only=False)
    else:
        ctx = deepspeed.zero.GatheredParameters(model.parameters(), enabled=deepspeed_stage_3)

    with ctx:
        if is_rank_0:
            mapped_params = [(name_mapper(n) if name_mapper else n, p.data) for n, p in params]
            for engine in vllm_engines:
                trainer_args = IPCTrainerSendWeightsArgs(mode="ray", llm_handle=engine)
                IPCWeightTransferEngine.trainer_send_weights(iterator=iter(mapped_params), trainer_args=trainer_args)
            return [engine.set_model_step.remote(model_step) for engine in vllm_engines]
    return []


def broadcast_weights_to_vllm(
    model: torch.nn.Module,
    vllm_engines: list[ray.actor.ActorHandle],
    model_update_group: Any | None,
    model_step: int,
    name_mapper: Callable[[str], str] | None = None,
    gather_whole_model: bool = True,
) -> list[ray.ObjectRef]:
    """Broadcast model weights to vLLM engines using the native weight transfer API.

    Must be called on ALL ranks when using DeepSpeed stage 3 or FSDP,
    since gathering is a collective operation. Only rank 0 sends weights.

    When model_update_group is None, uses IPC backend (single GPU mode).
    Otherwise uses NCCL backend.

    `model_step` is stamped onto each vLLM engine as part of the weight-update RPC,
    so no separate `set_model_step` call is needed.
    """
    if isinstance(model, FSDP) and not gather_whole_model:
        raise ValueError("FSDP1 does not support per-parameter gathering. Set gather_whole_model=True.")

    is_rank_0 = not torch.distributed.is_initialized() or torch.distributed.get_rank() == 0
    if is_rank_0:
        ray.get([engine.sleep.remote() for engine in vllm_engines])

    if model_update_group is None and is_rank_0:
        return _broadcast_weights_ipc(model, vllm_engines, name_mapper, gather_whole_model, model_step)

    fsdp_submodules = _get_fsdp2_submodules(model) if isinstance(model, FSDPModule) else None
    use_packed = False
    trainer_args = NCCLTrainerSendWeightsArgs(group=model_update_group, packed=use_packed)

    if isinstance(model, FSDPModule):
        if not fsdp_submodules:
            raise ValueError("FSDP2 model has no FSDP submodules.")
        if not gather_whole_model:
            raise ValueError(
                "FSDP2 weight sync requires gather_whole_model=True. "
                "Per-block iteration deadlocks on the CUDA stream because reshard/unshard "
                "collectives interleave with the trainer->vLLM NCCL sends."
            )
        for _, block in fsdp_submodules:
            block.unshard()
        # The root FSDPModule wraps params not inside any submodule (e.g. model.norm,
        # lm_head). _get_fsdp2_submodules excludes the root, so unshard it explicitly
        # or those root-level DTensor params will fail NCCL broadcast with an illegal
        # memory access (their `.contiguous().clone()` produces a buffer with global
        # stride backed by only the local shard).
        model.unshard()
        torch.cuda.synchronize()
        try:
            if is_rank_0:
                mapped_params = _prepare_params_for_sync(list(model.named_parameters()), name_mapper)
                names = [n for n, _ in mapped_params]
                dtype_names = [str(t.dtype).split(".")[-1] for _, t in mapped_params]
                shapes = [list(t.shape) for _, t in mapped_params]
                update_info = {"names": names, "dtype_names": dtype_names, "shapes": shapes, "packed": use_packed}
                refs = [
                    engine.update_weights.remote({"update_info": update_info}, model_step) for engine in vllm_engines
                ]
                NCCLWeightTransferEngine.trainer_send_weights(iterator=iter(mapped_params), trainer_args=trainer_args)
            else:
                refs = []
        finally:
            for _, block in fsdp_submodules:
                block.reshard()
            model.reshard()
        return refs

    names, dtype_names, shapes = _collect_weight_metadata(model, name_mapper)

    if is_rank_0:
        update_info = {"names": names, "dtype_names": dtype_names, "shapes": shapes, "packed": use_packed}
        refs = [engine.update_weights.remote({"update_info": update_info}, model_step) for engine in vllm_engines]
    else:
        refs = []

    params = list(model.named_parameters())
    deepspeed_stage_3 = any(hasattr(p, "ds_id") for p in model.parameters())

    if isinstance(model, FSDP):
        batches = [(FSDP.summon_full_params(model, writeback=False, rank0_only=False), params)]
    elif gather_whole_model:
        batches = [(deepspeed.zero.GatheredParameters(model.parameters(), enabled=deepspeed_stage_3), params)]
    else:
        batches = [
            (deepspeed.zero.GatheredParameters([param], enabled=deepspeed_stage_3), [(name, param)])
            for name, param in params
        ]

    for ctx, batch_params in batches:
        with ctx:
            if is_rank_0:
                mapped_params = _prepare_params_for_sync(batch_params, name_mapper)
                NCCLWeightTransferEngine.trainer_send_weights(iterator=iter(mapped_params), trainer_args=trainer_args)

    return refs
