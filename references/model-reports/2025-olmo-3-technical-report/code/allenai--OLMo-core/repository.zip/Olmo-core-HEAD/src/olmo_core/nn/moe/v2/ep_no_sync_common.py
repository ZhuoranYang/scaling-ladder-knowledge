from __future__ import annotations

import os
import time
from typing import TYPE_CHECKING, Optional, Tuple, Union, cast

import torch
import torch.distributed as dist

from olmo_core._nvtx import nvtx
from olmo_core.distributed.utils import get_rank

from ...moe.utils import (
    moe_unpermute_1d_fused_drop_no_compile,
    moe_unpermute_no_compile,
)

if TYPE_CHECKING:
    from olmo_core.nn.ddp.block import OLMoDDPTransformerBlock


def padded_local_expert_splits_for_capacity(
    recv_splits_by_src_local: torch.Tensor,
    *,
    rank_capacity: int,
) -> torch.Tensor:
    local_splits = recv_splits_by_src_local.sum(dim=0, dtype=torch.long)
    if local_splits.numel() == 0:
        return local_splits

    # No-sync dispatch buffers are padded to the receiving rank capacity. The
    # row layout keeps real expert chunks first and puts tail padding in the
    # final local expert chunk, matching build_chunk_te_routing_map().
    pad = torch.clamp(
        local_splits.new_full((), rank_capacity) - local_splits.sum(dtype=torch.long),
        min=0,
    )
    padded_splits = local_splits.clone()
    padded_splits[-1] = padded_splits[-1] + pad
    return padded_splits


def _ep_sync_debug_enabled() -> bool:
    verbose = os.getenv("OLMO_ROWWISE_VERBOSE_DEBUG_PRINT") or os.getenv(
        "OLMO_TBO_VERBOSE_DEBUG_PRINT", "0"
    )
    if (verbose or "").strip().lower() not in {
        "1",
        "true",
        "yes",
        "on",
    }:
        return False
    ranks = os.getenv("OLMO_ROWWISE_DEBUG_RANKS") or os.getenv("OLMO_TBO_DEBUG_RANKS")
    if not ranks or not dist.is_available() or not dist.is_initialized():
        return True
    rank = str(dist.get_rank())
    return rank in {part.strip() for part in ranks.split(",") if part.strip()}


def _ep_sync_rank_tag() -> str:
    if not dist.is_available() or not dist.is_initialized():
        return "rank=? local_rank=?"
    return f"rank={dist.get_rank()} local_rank={os.getenv('LOCAL_RANK', '?')}"


def _ep_sync_tensor_desc(name: str, tensor: torch.Tensor) -> str:
    return f"{name}=tensor"


def _ep_sync_debug_print(label: str, **tensors: torch.Tensor) -> None:
    if not _ep_sync_debug_enabled():
        return
    parts = ["[OLMO_ROWWISE_SYNC_DEBUG]", _ep_sync_rank_tag(), label]
    parts.extend(_ep_sync_tensor_desc(name, tensor) for name, tensor in tensors.items())
    print(" | ".join(str(part) for part in parts), flush=True)


def rowwise_stage_debug_enabled() -> bool:
    if os.getenv("OLMO_ROWWISE_STAGE_DEBUG", "0").strip().lower() not in {
        "1",
        "true",
        "yes",
        "on",
    }:
        return False
    ranks = os.getenv("OLMO_ROWWISE_STAGE_DEBUG_RANKS") or os.getenv("OLMO_TBO_DEBUG_RANKS")
    if not ranks or not dist.is_available() or not dist.is_initialized():
        return True
    if ranks.strip().lower() in {"all", "*"}:
        return True
    rank = str(dist.get_rank())
    return rank in {part.strip() for part in ranks.split(",") if part.strip()}


def rowwise_stage_debug_print(label: str, **fields: object) -> None:
    if not rowwise_stage_debug_enabled():
        return
    parts = ["[OLMO_ROWWISE_STAGE]", f"t={time.perf_counter():.6f}", _ep_sync_rank_tag(), label]
    parts.extend(f"{name}={value}" for name, value in fields.items())
    print(" | ".join(str(part) for part in parts), flush=True)


def rowwise_stage_debug_sync(label: str, device: torch.device | None = None) -> None:
    if os.getenv("OLMO_ROWWISE_STAGE_DEBUG_SYNC", "0").strip().lower() not in {
        "1",
        "true",
        "yes",
        "on",
    }:
        return
    rowwise_stage_debug_print(f"{label}:sync-enter")
    if device is None:
        torch.cuda.synchronize()
    else:
        torch.cuda.synchronize(device)
    rowwise_stage_debug_print(f"{label}:sync-exit")


@nvtx.annotate("_build_keep_reorder")
def build_keep_reorder(
    requested_splits: torch.Tensor,
    keep_splits: torch.Tensor,
    num_out_tokens: int,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    requested = requested_splits.to(dtype=torch.long)
    keep = keep_splits.to(dtype=torch.long)
    token_ids = torch.arange(num_out_tokens, device=keep.device, dtype=torch.long)

    requested_ends = torch.cumsum(requested, dim=0)

    max_expert_idx = requested.numel() - 1
    expert_ids = torch.searchsorted(
        requested_ends,
        token_ids,
        right=True,
    ).clamp_max(max_expert_idx)
    starts = requested_ends - requested
    pos_in_chunk = token_ids - starts.index_select(0, expert_ids)
    keep_mask = pos_in_chunk < keep.index_select(0, expert_ids)

    # Stable partition: keep rows first, then dropped rows.
    keep_i64 = keep_mask.to(dtype=torch.long)
    drop_i64 = (~keep_mask).to(dtype=torch.long)
    keep_rank = torch.cumsum(keep_i64, dim=0) - 1
    drop_rank = torch.cumsum(drop_i64, dim=0) - 1
    num_kept = keep_i64.sum(dtype=torch.long)
    packed_pos = torch.where(keep_mask, keep_rank, num_kept + drop_rank)

    reorder_indices = torch.empty_like(token_ids)
    reorder_indices.scatter_(0, packed_pos, token_ids)

    inverse_reorder_indices = packed_pos
    packed_keep_mask = keep_mask.index_select(0, reorder_indices)
    return reorder_indices, inverse_reorder_indices, packed_keep_mask


@nvtx.annotate("SyncTokenCount", color="green")
def sync_tail_drop_allowed_splits_single_a2a(
    block: OLMoDDPTransformerBlock,
    requested_splits: torch.Tensor,
    *,
    rank_capacity: int,
    return_keep_matrix: bool = False,
) -> Union[
    Tuple[torch.Tensor, torch.Tensor, torch.Tensor],
    Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor],
]:
    """
    Tail-drop keep-split sync with a single all-gather.
    Each EP rank receives every rank's requested splits, then computes the
    same keep policy locally using the shared `rank_capacity`.
    """
    self = block
    assert self.num_local_routed_experts is not None
    requested = requested_splits.to(dtype=torch.long)
    expected_splits = self.ep_world_size * self.num_local_routed_experts
    if requested.numel() != expected_splits:
        raise RuntimeError(
            "requested_splits size mismatch: "
            f"got {requested.numel()}, expected {expected_splits}"
        )

    gathered_payload = torch.empty(
        expected_splits * self.ep_world_size,
        device=requested.device,
        dtype=requested.dtype,
    )
    _ep_sync_debug_print(
        (
            "sync_tail_drop:all_gather-enter "
            f"block={self.block_idx} ep_world_size={self.ep_world_size} "
            f"num_local_experts={self.num_local_routed_experts} rank_capacity={rank_capacity}"
        ),
        requested=requested,
        gathered_payload=gathered_payload,
    )
    dist.all_gather_into_tensor(
        gathered_payload,
        requested,
        group=self.ep_pg,
    )
    _ep_sync_debug_print(
        f"sync_tail_drop:all_gather-exit block={self.block_idx}",
        requested=requested,
        gathered_payload=gathered_payload,
    )

    gathered_payload_2d = gathered_payload.view(self.ep_world_size, expected_splits)
    global_requested = gathered_payload_2d.view(
        self.ep_world_size,
        self.ep_world_size,
        self.num_local_routed_experts,
    )

    # Flatten in local-expert-major then source-rank order for each destination rank.
    counts_flat = global_requested.permute(2, 0, 1).reshape(-1, self.ep_world_size)
    cumsum_counts = torch.cumsum(counts_flat, dim=0)
    kept_cumsum = torch.clamp(cumsum_counts, max=rank_capacity)
    prev = torch.cat(
        [
            torch.zeros((1, self.ep_world_size), device=requested.device, dtype=torch.long),
            kept_cumsum[:-1],
        ],
        dim=0,
    )
    kept_flat = kept_cumsum - prev
    keep_from_src_dest_local = kept_flat.view(
        self.num_local_routed_experts,
        self.ep_world_size,
        self.ep_world_size,
    ).permute(1, 2, 0)

    local_rank = get_rank(self.ep_pg)
    allowed_splits = keep_from_src_dest_local[local_rank].reshape(-1)
    allowed_splits = torch.minimum(allowed_splits, requested)

    recv_splits_by_src_local = keep_from_src_dest_local[:, local_rank, :]
    send_side_drop_token_count = requested.sum() - allowed_splits.sum()
    if return_keep_matrix:
        return (
            allowed_splits,
            recv_splits_by_src_local,
            send_side_drop_token_count,
            keep_from_src_dest_local,
        )
    return (
        allowed_splits,
        recv_splits_by_src_local,
        send_side_drop_token_count,
    )


@nvtx.annotate("_restore_drop_unpermute_1d")
def restore_drop_unpermute_1d(
    block: OLMoDDPTransformerBlock,
    *,
    combine_out: torch.Tensor,
    local_inverse_reorder_indices: torch.Tensor,
    packed_keep_mask: torch.Tensor,
    num_kept: torch.Tensor,
    reversed_local_x_permutation_mapping: torch.Tensor,
    local_x_global_routed_expert_weights: torch.Tensor,
    hidden_shape_before_permute: torch.Size,
    row_id_map_is_packed: bool = False,
    backward_grad_input_buffer: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    self = block
    assert self.routed_experts_router is not None
    merging_probs = local_x_global_routed_expert_weights.view(
        -1,
        self.routed_experts_router.top_k,
    )
    backend = self.ep.restore_unpermute_backend

    if backend == "te_fused":
        return cast(
            torch.Tensor,
            moe_unpermute_1d_fused_drop_no_compile(
                inp=combine_out,
                row_id_map=reversed_local_x_permutation_mapping,
                local_inverse_reorder_indices=local_inverse_reorder_indices,
                packed_keep_mask=packed_keep_mask,
                merging_probs=merging_probs,
                num_kept=num_kept,
                row_id_map_is_packed=row_id_map_is_packed,
                backward_grad_input_buffer=backward_grad_input_buffer,
                map_type="index",
            ),
        )
    if backend == "te_unfused":
        if row_id_map_is_packed:
            restored_local_x = combine_out
        else:
            with nvtx.annotate("RestoreDrop", color="green"):
                restored_local_x = combine_out.index_select(
                    0,
                    local_inverse_reorder_indices,
                )
                restored_keep_mask = packed_keep_mask.index_select(
                    0,
                    local_inverse_reorder_indices,
                )
                restored_local_x = torch.where(
                    restored_keep_mask.unsqueeze(-1),
                    restored_local_x,
                    torch.zeros_like(restored_local_x),
                )
        return cast(
            torch.Tensor,
            moe_unpermute_no_compile(
                inp=restored_local_x,
                row_id_map=reversed_local_x_permutation_mapping,
                merging_probs=merging_probs,
                restore_shape=hidden_shape_before_permute,
                map_type="index",
            ),
        )
    if backend == "cuda":
        raise RuntimeError(
            "EP restore_unpermute_backend='cuda' is not implemented yet. "
            "TODO: add a custom CUDA path mirroring TE _moe_unpermute_index_map semantics."
        )
    raise RuntimeError(f"Unhandled EP restore_unpermute_backend: {backend}")
