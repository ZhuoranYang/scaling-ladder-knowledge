import logging
import os
from collections import OrderedDict
from contextlib import contextmanager
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

import torch
import torch.distributed as dist
from torch.nn.modules import Module

if dist.is_available():
    from torch.distributed.distributed_c10d import ReduceOp, _get_default_group
    from torch.distributed.utils import _verify_param_shape_across_processes
else:
    _get_default_group = None

if TYPE_CHECKING:
    from torch.utils.hooks import RemovableHandle


__all__ = ["MultiGroupDistributedDataParallel"]

logger = logging.getLogger(__name__)


@dataclass
class _GradBucket:
    process_group: Any
    storage_dtype: torch.dtype
    comm_dtype: torch.dtype
    reduce_scatter: bool
    params: list[torch.nn.Parameter]
    ranges: list[tuple[int, int]]
    local_ranges: list[tuple[int, int]]
    numel: int
    local_numel: int
    flat_storage: torch.Tensor
    flat_comm: Optional[torch.Tensor]
    flat_reduced_storage: Optional[torch.Tensor]
    flat_reduced_comm: Optional[torch.Tensor]


class MultiGroupDistributedDataParallel(Module):
    """
    A data-parallel module wrapper that all-reduces gradients across one or more process groups.

    Unlike :class:`torch.nn.parallel.DistributedDataParallel`, gradients are accumulated into
    flat, pre-allocated **bucket views** (each parameter's ``.grad`` is a view into a contiguous
    bucket), and different parameters may be assigned to different process groups via
    :data:`param_process_group_fn` — useful when subsets of the model are replicated over
    different device meshes. Bucketed all-reduces are launched (overlapped with the backward
    pass) as each bucket fills, and :meth:`finalize_grad_reduce` must be called after
    ``loss.backward()`` to wait for them to complete.

    Optionally, gradients can be accumulated and/or reduced in fp32 for numerical stability with
    low-precision parameters.

    Usage::

        ddp = MultiGroupDistributedDataParallel(model)
        out = ddp(inputs)
        out.loss.backward()
        ddp.finalize_grad_reduce()  # required: waits for the overlapped all-reduces
        optimizer.step()

    :param module: The module to wrap. All parameters must be materialized (no meta/uninitialized
        params) and the module must not have buffers when using :data:`param_process_group_fn`.
    :param init_sync: If ``True``, broadcast parameters from rank 0 within each process group at
        construction so all ranks start from identical weights.
    :param process_group: The default process group. Defaults to the global group.
    :param bucket_cap_mb: Soft cap (in MiB) on the size of each gradient bucket.
    :param param_process_group_fn: Optional ``(name, param) -> process_group`` mapping assigning
        parameters to process groups. Defaults to a single (default) process group for all params.
    :param accumulate_grads_in_fp32: Accumulate gradients into an fp32 buffer (requires
        :data:`reduce_grads_in_fp32`).
    :param reduce_grads_in_fp32: All-reduce gradients in fp32 regardless of parameter dtype.
    """

    def __init__(
        self,
        module: Module,
        dim: int = 0,
        init_sync: bool = True,
        process_group: Any = None,
        bucket_cap_mb: Optional[float] = None,
        param_process_group_fn: Optional[Callable[[str, torch.nn.Parameter], Any]] = None,
        accumulate_grads_in_fp32: bool = False,
        reduce_grads_in_fp32: bool = False,
        use_reduce_scatter: bool = False,
    ) -> None:
        super().__init__()

        if process_group is None:
            if _get_default_group is None:
                self.process_group = None
            else:
                self.process_group = _get_default_group()
        else:
            self.process_group = process_group

        if hasattr(module, "_ddp_params_and_buffers_to_ignore"):
            self.parameters_to_ignore = set(module._ddp_params_and_buffers_to_ignore)
        else:
            self.parameters_to_ignore = set()

        self._module_parameters = [
            p for n, p in module.named_parameters() if n not in self.parameters_to_ignore
        ]

        self._param_to_name = {p: n for n, p in module.named_parameters()}

        # this is the order to launch grad reduce
        self._reversed_module_parameters = list(reversed(self._module_parameters))

        if not any(p.requires_grad for p in self._module_parameters):
            raise RuntimeError(
                "DistributedDataParallel is not needed when a module doesn't have any parameter that requires a gradient.",
            )

        is_multi_device_module = len({p.device for p in self._module_parameters}) > 1
        if is_multi_device_module:
            raise NotImplementedError(
                "DistributedDataParallel with parameters on multiple devices is not supported yet."
            )
        distinct_device_types = {
            p.device.type for p in self._module_parameters if p.device is not None
        }

        self.device_type = next(iter(distinct_device_types))

        self.dim = dim
        self.module = module
        self.device = next(iter(self._module_parameters)).device
        self.require_backward_grad_sync = True
        self.require_forward_param_sync = True
        self.overlap_grad_reduce = True

        # Multi-process-group support.
        if param_process_group_fn is None:
            # default to single process group
            def param_process_group_fn(_name, _param):
                return self.process_group

        self._param_process_group_fn = param_process_group_fn

        self._accumulate_grads_in_fp32 = accumulate_grads_in_fp32
        self._reduce_grads_in_fp32 = reduce_grads_in_fp32
        self.use_reduce_scatter = use_reduce_scatter
        self._reduce_scatter_configured = not use_reduce_scatter
        self._reduce_scatter_params: set[torch.nn.Parameter] = set()
        self._reduce_scatter_pack_scratch: Dict[tuple[torch.device, torch.dtype], torch.Tensor] = {}
        # Opt-in profiling experiment; leave the existing production path unchanged.
        self._reduce_scatter_single_param_fast_path = (
            os.environ.get("OLMO_PROFILE_RS_SINGLE_PARAM_FAST_PATH", "0") == "1"
        )
        self._vectorized_fp32_grad_add = (
            os.environ.get("OLMO_PROFILE_FP32_GRAD_ADD_VECTORIZE", "0") == "1"
        )

        if self._accumulate_grads_in_fp32 and not self._reduce_grads_in_fp32:
            raise ValueError("accumulate_grads_in_fp32 requires reduce_grads_in_fp32 to be True")

        # Check that a module does not have Uninitialized parameters
        for param in self._module_parameters:
            if isinstance(param, torch.nn.parameter.UninitializedParameter):
                raise RuntimeError(
                    "Modules with uninitialized parameters can't be used with `DistributedDataParallel`. "
                    "Run a dummy forward pass to correctly initialize the modules",
                )
            # disable meta device parameters
            if param.device.type == "meta":
                raise RuntimeError(
                    "Modules with meta device parameters can't be used with `DistributedDataParallel`. "
                    "Please initialize all parameters before wrapping with DistributedDataParallel.",
                )
        # used for intra-node param sync and inter-node sync as well
        self.broadcast_bucket_size = int(250 * 1024 * 1024)

        # reduction bucket size
        if bucket_cap_mb is None:
            # default case (bucket cap is 250 MiB)
            bucket_cap_mb = 250

        self.bucket_bytes_cap = int(bucket_cap_mb * 1024 * 1024)

        # Whether to perform input tensor CPU to GPU copies on a side-stream
        self.use_side_stream_for_tensor_copies = (
            os.environ.get("PYTORCH_DDP_USE_SIDE_STREAM", "1") == "1"
        )

        # build param <-> process group mapping
        self.process_group_to_params: Dict[Any, List[torch.nn.Parameter]] = {}
        self.param_to_process_group: Dict[torch.nn.Parameter, Any] = {}

        # This wrapper reduces parameter *gradients* only; module buffers are left untouched and are
        # not synchronized across ranks (as with torch DDP's broadcast_buffers=False). Non-gradient
        # state such as MoE router score_bias or RoPE caches is therefore fine on a buffered module.
        #
        # TODO(revisit): we previously rejected any buffered module outright (guard below). Removed
        # so MoE models (router score_bias buffer) can be wrapped. Revisit whether any buffer needs
        # cross-rank consistency; if so, this wrapper should broadcast/handle it rather than ignore.
        #   named_buffers = list(self.module.named_buffers())
        #   if len(named_buffers) > 0:
        #       raise NotImplementedError(
        #           "DDP with param_process_group_fn does not support buffers yet."
        #       )

        for name, param in self.module.named_parameters():
            if name in self.parameters_to_ignore:
                continue
            pg = self._param_process_group_fn(name, param)

            if pg is None:
                pg = self.process_group

            self.param_to_process_group[param] = pg
            if pg not in self.process_group_to_params:
                self.process_group_to_params[pg] = []
            self.process_group_to_params[pg].append(param)

        if init_sync:
            self.init_sync()

        self._comm_hooks: list[tuple[object, object]] = []

        self._grad_buckets: list[_GradBucket] = []
        self._param_to_bucket_idx: Dict[torch.nn.Parameter, int] = {}
        self._param_to_bucket_view: Dict[torch.nn.Parameter, torch.Tensor] = {}
        self._param_to_reduced_grad_view: Dict[torch.nn.Parameter, torch.Tensor] = {}
        self._bucket_ready_count: list[int] = []
        self._grad_reduce_hooks: list[tuple[Any, int]] = []
        self._grad_views_need_rebind = False
        self._warned_grad_view_rebind = False
        self._forwards_since_finalize = 0
        self._profile_forward_epoch = 0
        self._profile_external_written = {}
        self._has_started_forward = False

        self._build_grad_buckets()
        self._bind_bucket_views(zero_buffers=True, reason="initialization")

        self._fp32_acc_hooks = []
        if self._accumulate_grads_in_fp32:
            # Only the non-ignored params have bucket views; installing the fp32 hook on an ignored
            # param would make it index a missing _param_to_bucket_view entry during backward.
            for p in self._module_parameters:
                if not p.requires_grad:
                    continue
                self._fp32_acc_hooks.append(
                    p.register_post_accumulate_grad_hook(self._fp32_post_grad_acc_hook)
                )

        # Register the AccumulateGrad post hooks that drive this wrapper's
        # own bucket readiness/gradient-reduction path.
        self._accum_grad_hooks: list[RemovableHandle] = []

        self._param_grad_ready: OrderedDict[torch.nn.Parameter, bool] = OrderedDict()
        self._next_reduce_bucket_idx = 0

        # Hooks that control bucketed gradient reduction.
        self._register_accum_grad_hook()
        # Experimental, explicitly exclusive expert-leaf accumulation. Bind after
        # materialization so meta->CUDA parameter replacement cannot lose ownership.
        for child in module.modules():
            if getattr(child, "_profile_rounded_wgrad", False):
                if not self._accumulate_grads_in_fp32 or not self._reduce_grads_in_fp32:
                    raise RuntimeError("Rounded wgrad probe requires FP32 accumulation/reduction")
                for param in (child.w_up_gate, child.w_down):
                    if param not in self._param_to_bucket_view:
                        raise RuntimeError("Rounded wgrad parameter is not managed by this DDP")
                    self._profile_external_written[param] = -1
                    param._olmo_profile_begin_external_grad = self._profile_begin_external_grad

    def __getattr__(self, name: str) -> Any:
        """Forward missing attributes to the wrapped module."""
        try:
            return super().__getattr__(name)  # nn.Module logic first
        except AttributeError:
            return getattr(self.module, name)

    def __getitem__(self, key: int) -> Any:
        return self.module.__getitem__(key)  # type: ignore[operator]

    def _get_storage_dtype_for_param(self, param: torch.nn.Parameter) -> torch.dtype:
        if self._accumulate_grads_in_fp32:
            return torch.float32
        return param.dtype

    def _get_comm_dtype_for_storage(self, storage_dtype: torch.dtype) -> torch.dtype:
        if self._reduce_grads_in_fp32:
            return torch.float32
        return storage_dtype

    def _get_param_grad_buffer(self, param: torch.nn.Parameter) -> Optional[torch.Tensor]:
        if self._accumulate_grads_in_fp32:
            return getattr(param, "_main_grad_fp32", None)
        return param.grad

    def _set_param_grad_buffer(
        self, param: torch.nn.Parameter, buffer: Optional[torch.Tensor]
    ) -> None:
        if self._accumulate_grads_in_fp32:
            param._main_grad_fp32 = buffer  # type: ignore[attr-defined]
        else:
            param.grad = buffer

    def _is_expected_grad_view(self, current: torch.Tensor, expected: torch.Tensor) -> bool:
        return (
            current.dtype == expected.dtype
            and current.device == expected.device
            and current.shape == expected.shape
            and current.stride() == expected.stride()
            and current.data_ptr() == expected.data_ptr()
        )

    def _build_grad_buckets(self) -> None:
        params_in_reduce_order = [p for p in self._reversed_module_parameters if p.requires_grad]

        current_params: list[torch.nn.Parameter] = []
        current_ranges: list[tuple[int, int]] = []
        current_numel = 0
        current_bucket_bytes = 0
        current_process_group = None
        current_storage_dtype: Optional[torch.dtype] = None
        current_comm_dtype: Optional[torch.dtype] = None
        current_reduce_scatter = False

        def flush_current_bucket() -> None:
            nonlocal current_params
            nonlocal current_ranges
            nonlocal current_numel
            nonlocal current_bucket_bytes
            nonlocal current_process_group
            nonlocal current_storage_dtype
            nonlocal current_comm_dtype
            nonlocal current_reduce_scatter

            if not current_params:
                return

            assert current_storage_dtype is not None
            assert current_comm_dtype is not None
            assert current_process_group is not None

            world_size = dist.get_world_size(current_process_group)
            local_ranges: list[tuple[int, int]] = []
            local_numel = 0
            if current_reduce_scatter:
                for param in current_params:
                    if param.numel() % world_size != 0:
                        raise RuntimeError(
                            "Reduce-scatter requires every optimizer-sharded parameter "
                            f"to be divisible by its replica-group size; parameter "
                            f"'{self._param_to_name.get(param, '<unnamed>')}' has "
                            f"{param.numel()} elements for group size {world_size}."
                        )
                    param_local_numel = param.numel() // world_size
                    local_ranges.append((local_numel, local_numel + param_local_numel))
                    local_numel += param_local_numel

            flat_storage = torch.zeros(
                current_numel, device=self.device, dtype=current_storage_dtype
            )
            flat_comm = None
            if current_comm_dtype != current_storage_dtype:
                flat_comm = torch.empty(current_numel, device=self.device, dtype=current_comm_dtype)

            flat_reduced_storage = None
            flat_reduced_comm = None
            if current_reduce_scatter:
                flat_reduced_storage = torch.empty(
                    local_numel, device=self.device, dtype=current_storage_dtype
                )
                if current_comm_dtype != current_storage_dtype:
                    flat_reduced_comm = torch.empty(
                        local_numel, device=self.device, dtype=current_comm_dtype
                    )

            bucket_idx = len(self._grad_buckets)
            self._grad_buckets.append(
                _GradBucket(
                    process_group=current_process_group,
                    storage_dtype=current_storage_dtype,
                    comm_dtype=current_comm_dtype,
                    reduce_scatter=current_reduce_scatter,
                    params=list(current_params),
                    ranges=list(current_ranges),
                    local_ranges=local_ranges,
                    numel=current_numel,
                    local_numel=local_numel,
                    flat_storage=flat_storage,
                    flat_comm=flat_comm,
                    flat_reduced_storage=flat_reduced_storage,
                    flat_reduced_comm=flat_reduced_comm,
                )
            )

            for param, (start, end) in zip(current_params, current_ranges):
                self._param_to_bucket_idx[param] = bucket_idx
                self._param_to_bucket_view[param] = flat_storage[start:end].view_as(param)
            if current_reduce_scatter:
                assert flat_reduced_storage is not None
                for param, (start, end) in zip(current_params, local_ranges):
                    self._param_to_reduced_grad_view[param] = flat_reduced_storage[start:end]

            current_params = []
            current_ranges = []
            current_numel = 0
            current_bucket_bytes = 0
            current_process_group = None
            current_storage_dtype = None
            current_comm_dtype = None
            current_reduce_scatter = False

        for param in params_in_reduce_order:
            process_group = self.param_to_process_group[param]
            storage_dtype = self._get_storage_dtype_for_param(param)
            comm_dtype = self._get_comm_dtype_for_storage(storage_dtype)
            reduce_scatter = param in self._reduce_scatter_params
            param_bytes = param.numel() * torch.empty((), dtype=comm_dtype).element_size()

            should_flush = current_params and (
                process_group is not current_process_group
                or storage_dtype != current_storage_dtype
                or comm_dtype != current_comm_dtype
                or reduce_scatter != current_reduce_scatter
                or (current_bucket_bytes + param_bytes > self.bucket_bytes_cap)
            )
            if should_flush:
                flush_current_bucket()

            start = current_numel
            end = start + param.numel()
            current_params.append(param)
            current_ranges.append((start, end))
            current_numel = end
            current_bucket_bytes += param_bytes
            current_process_group = process_group
            current_storage_dtype = storage_dtype
            current_comm_dtype = comm_dtype
            current_reduce_scatter = reduce_scatter

        flush_current_bucket()
        self._bucket_ready_count = [0 for _ in self._grad_buckets]

    def configure_reduce_scatter_params(self, params: set[torch.nn.Parameter]) -> None:
        """Configure optimizer-sharded parameters before the first forward pass.

        The optimizer decides state placement after this wrapper is constructed. This
        method rebuilds the gradient buckets using that placement as the source of
        truth: optimizer-sharded parameters use reduce-scatter, while all other normal
        parameters remain on the all-reduce path.
        """
        if not self.use_reduce_scatter:
            if params:
                raise RuntimeError(
                    "Cannot configure reduce-scatter parameters when " "use_reduce_scatter=False."
                )
            return
        if self._has_started_forward:
            raise RuntimeError(
                "Reduce-scatter parameters must be configured before the first forward pass."
            )
        if self._grad_reduce_hooks:
            raise RuntimeError("Cannot rebuild gradient buckets while reductions are in flight.")

        unknown_params = params.difference(self.param_to_process_group)
        if unknown_params:
            raise RuntimeError(
                "Optimizer reduce-scatter placement includes parameters that are not "
                "managed by this DDP wrapper."
            )

        for param in self._module_parameters:
            if not param.requires_grad:
                continue
            self._set_param_grad_buffer(param, None)
            if self._accumulate_grads_in_fp32:
                param.grad = None
            if hasattr(param, "_olmo_ddp_reduced_grad_shard"):
                delattr(param, "_olmo_ddp_reduced_grad_shard")

        self._reduce_scatter_params = set(params)
        self._grad_buckets = []
        self._param_to_bucket_idx = {}
        self._param_to_bucket_view = {}
        self._param_to_reduced_grad_view = {}
        self._build_grad_buckets()
        self._bind_bucket_views(zero_buffers=True, reason="reduce-scatter configuration")
        self._next_reduce_bucket_idx = 0
        for param in self._param_grad_ready:
            self._param_grad_ready[param] = False
        self._reduce_scatter_configured = True

    def _bind_bucket_views(self, *, zero_buffers: bool, reason: str) -> None:
        if zero_buffers:
            for bucket in self._grad_buckets:
                bucket.flat_storage.zero_()

        rebound_count = 0
        none_count = 0
        for param, expected_view in self._param_to_bucket_view.items():
            current = self._get_param_grad_buffer(param)
            if current is None:
                none_count += 1
            elif not self._is_expected_grad_view(current, expected_view):
                raise RuntimeError(
                    "Detected an external gradient tensor replacement that breaks bucket views. "
                    "This mode requires grads to remain bucket views."
                )

            if current is not expected_view:
                self._set_param_grad_buffer(param, expected_view)
                rebound_count += 1

            # In fp32-accum mode, .grad must stay ephemeral and be consumed by the post-acc hook.
            if self._accumulate_grads_in_fp32:
                param.grad = None

        self._grad_views_need_rebind = False
        if rebound_count > 0 and reason != "initialization":
            if not self._warned_grad_view_rebind:
                logger.warning(
                    f"Rebound {rebound_count} gradient bucket view(s) because buffers were detached "
                    f"(reason={reason}, none={none_count})."
                )
                self._warned_grad_view_rebind = True

    def _ensure_grad_views_bound(self, *, allow_none_rebind: bool, where: str) -> None:
        if self._grad_views_need_rebind:
            if self._forwards_since_finalize > 0:
                raise RuntimeError(
                    f"Gradient buckets were marked for rebind in {where} after the training step started. "
                    "This usually indicates set_to_none=True between micro-batches."
                )
            self._bind_bucket_views(zero_buffers=True, reason=f"flagged@{where}")
            return

        has_none_binding = False
        for param, expected_view in self._param_to_bucket_view.items():
            current = self._get_param_grad_buffer(param)
            if current is None:
                has_none_binding = True
                continue
            if not self._is_expected_grad_view(current, expected_view):
                raise RuntimeError(
                    f"Gradient view integrity check failed in {where}: gradient tensor was replaced "
                    "with a non-bucket-view tensor."
                )

        if has_none_binding:
            if not allow_none_rebind:
                raise RuntimeError(
                    f"Found None gradient buffers in {where}. This usually means set_to_none=True ran "
                    "at an unexpected time. Rebind before backward by running a forward pass."
                )
            if self._forwards_since_finalize > 0 and not self._grad_views_need_rebind:
                raise RuntimeError(
                    f"Found detached gradient buffers in {where} after this training step already started. "
                    "Rebinding now would lose accumulated grads. This usually indicates an unexpected "
                    "set_to_none=True between micro-batches."
                )
            self._bind_bucket_views(zero_buffers=True, reason=f"none@{where}")

    def _fp32_post_grad_acc_hook(self, param: torch.Tensor):
        g = param.grad
        if g is None:
            return
        if param in self._profile_external_written:
            raise RuntimeError("External-accumulation parameter also received a native gradient")

        expected_view = self._param_to_bucket_view[param]
        main_grad = getattr(param, "_main_grad_fp32", None)
        if main_grad is None:
            raise RuntimeError(
                "FP32 grad bucket view is missing during backward. "
                "Likely caused by set_to_none=True after forward began."
            )
        if not self._is_expected_grad_view(main_grad, expected_view):
            raise RuntimeError(
                "FP32 grad buffer is not the expected bucket view. "
                "External grad buffer replacement is not supported in bucket-view mode."
            )

        if (
            self._vectorized_fp32_grad_add
            and g.is_cuda
            and g.dtype == torch.bfloat16
            and main_grad.dtype == torch.float32
            and g.numel() >= 64 * 1024 * 1024
            and g.is_contiguous()
            and main_grad.is_contiguous()
        ):
            from olmo_core.ops.grad_accum import gradient_add

            gradient_add(main_grad, g)
        else:
            main_grad.add_(g)
        param.grad = None

    def _get_reduce_scatter_pack_scratch(self, bucket: _GradBucket) -> torch.Tensor:
        key = (bucket.flat_storage.device, bucket.comm_dtype)
        scratch = self._reduce_scatter_pack_scratch.get(key)
        if scratch is None or scratch.numel() < bucket.numel:
            scratch = torch.empty(
                bucket.numel,
                device=bucket.flat_storage.device,
                dtype=bucket.comm_dtype,
            )
            self._reduce_scatter_pack_scratch[key] = scratch
        return scratch[: bucket.numel]

    def _launch_bucket_grad_reduce(self, bucket_idx: int) -> None:
        if self._comm_hooks:
            raise NotImplementedError("Comm hooks are not implemented in bucket-view mode.")

        bucket = self._grad_buckets[bucket_idx]
        world_size = dist.get_world_size(bucket.process_group)

        # Average over the bucket's replica group. Expert buckets use EP-DP here;
        # the optimizer applies the remaining EP-MP factor when building main_grad.
        if bucket.reduce_scatter:
            assert bucket.flat_reduced_storage is not None
            if self._reduce_scatter_single_param_fast_path and len(bucket.params) == 1:
                # A single parameter is already rank-major. In particular, an expert
                # parameter larger than the soft bucket cap needs no packing/copy-back.
                # Keep the collective input in per-bucket storage: shared scratch cannot
                # be reused until an asynchronous collective has finished reading it.
                if bucket.ranges != [(0, bucket.numel)] or bucket.local_ranges != [
                    (0, bucket.local_numel)
                ]:
                    raise RuntimeError(
                        "Single-parameter reduce-scatter requires contiguous bucket ranges"
                    )
                if bucket.storage_dtype == bucket.comm_dtype:
                    tensor_for_reduce = bucket.flat_storage
                    tensor_for_output = bucket.flat_reduced_storage
                else:
                    assert bucket.flat_comm is not None
                    assert bucket.flat_reduced_comm is not None
                    bucket.flat_comm.copy_(bucket.flat_storage)
                    tensor_for_reduce = bucket.flat_comm
                    tensor_for_output = bucket.flat_reduced_comm
            else:
                scratch = self._get_reduce_scatter_pack_scratch(bucket)
                packed = scratch.view(world_size, bucket.local_numel)

                for (full_start, full_end), (local_start, local_end) in zip(
                    bucket.ranges, bucket.local_ranges
                ):
                    local_numel = local_end - local_start
                    packed[:, local_start:local_end].copy_(
                        bucket.flat_storage[full_start:full_end].view(world_size, local_numel)
                    )

                if bucket.storage_dtype == bucket.comm_dtype:
                    bucket.flat_storage.copy_(scratch)
                    tensor_for_reduce = bucket.flat_storage
                    tensor_for_output = bucket.flat_reduced_storage
                else:
                    assert bucket.flat_comm is not None
                    assert bucket.flat_reduced_comm is not None
                    bucket.flat_comm.copy_(scratch)
                    tensor_for_reduce = bucket.flat_comm
                    tensor_for_output = bucket.flat_reduced_comm

            tensor_for_reduce.div_(world_size)
            handle = torch.distributed.reduce_scatter_tensor(
                tensor_for_output,
                tensor_for_reduce,
                op=ReduceOp.SUM,
                group=bucket.process_group,
                async_op=True,
            )
        else:
            if bucket.storage_dtype == bucket.comm_dtype:
                tensor_for_reduce = bucket.flat_storage
                tensor_for_reduce.div_(world_size)
            else:
                assert bucket.flat_comm is not None
                bucket.flat_comm.copy_(bucket.flat_storage)
                bucket.flat_comm.div_(world_size)
                tensor_for_reduce = bucket.flat_comm

            handle = torch.distributed.all_reduce(
                tensor_for_reduce,
                op=ReduceOp.SUM,
                group=bucket.process_group,
                async_op=True,
            )
        self._grad_reduce_hooks.append((handle, bucket_idx))

    def _maybe_kick_start_grad_reduce(self):
        while self._next_reduce_bucket_idx < len(self._grad_buckets):
            bucket = self._grad_buckets[self._next_reduce_bucket_idx]
            if self._bucket_ready_count[self._next_reduce_bucket_idx] < len(bucket.params):
                break

            self._launch_bucket_grad_reduce(self._next_reduce_bucket_idx)
            self._next_reduce_bucket_idx += 1

    def _notify_grad_ready(self, param):
        if not self.require_backward_grad_sync or self._param_grad_ready[param]:
            return
        self._param_grad_ready[param] = True
        bucket_idx = self._param_to_bucket_idx[param]
        self._bucket_ready_count[bucket_idx] += 1
        if self.overlap_grad_reduce:
            self._maybe_kick_start_grad_reduce()

    def _profile_begin_external_grad(self, param):
        """Fail closed on duplicate uses, detached buffers, or mixed native gradients."""
        if self._forwards_since_finalize < 1 or param.grad is not None:
            raise RuntimeError("External gradient outside a clean DDP accumulation window")
        if self._profile_external_written[param] == self._profile_forward_epoch:
            raise RuntimeError("External gradient parameter reused within one forward")
        if self._param_grad_ready[param]:
            raise RuntimeError("External gradient write after gradient reduction was scheduled")
        destination = getattr(param, "_main_grad_fp32", None)
        if destination is None or not self._is_expected_grad_view(
            destination, self._param_to_bucket_view[param]
        ):
            raise RuntimeError("External gradient destination is not the owned FP32 bucket view")
        self._profile_external_written[param] = self._profile_forward_epoch
        return destination, lambda: self._notify_grad_ready(param)

    def _register_accum_grad_hook(self):
        for index, param in enumerate(self._module_parameters):
            if not param.requires_grad:
                continue

            # set up param order
            self._param_grad_ready[param] = False

            # To ensure parameter gradients are reduced in the same order, the
            # hook only reports readiness. The AR or RS collective is launched
            # later in bucket order.
            self._accum_grad_hooks.append(
                param.register_post_accumulate_grad_hook(self._notify_grad_ready)
            )

    def finalize_grad_reduce(self):
        # Grad buffers should already be bound before backward starts. If they are detached here,
        # we cannot safely rebind without risking silent corruption.
        self._ensure_grad_views_bound(allow_none_rebind=False, where="finalize_grad_reduce")

        # In some cases (e.g. imbalanced MoE routing) a param's post-accumulate hook is never called
        # this step, so its grad_ready is never set. Mark those ready so their bucket can reduce.
        # Do NOT zero the bucket view here: it already holds the correct value — zero if the param
        # was never touched (buffers are zeroed at the start of the accumulation window), or the
        # accumulated grad if it was touched in an earlier `no_sync()` micro-batch but not the final
        # (synced) one. Zeroing would discard that accumulated grad.
        if self._next_reduce_bucket_idx < len(self._grad_buckets):
            for param in self._param_grad_ready.keys():
                if not self._param_grad_ready[param]:
                    self._param_grad_ready[param] = True
                    bucket_idx = self._param_to_bucket_idx[param]
                    self._bucket_ready_count[bucket_idx] += 1

            self._maybe_kick_start_grad_reduce()

        # now all grad reduce should have been launched
        assert self._next_reduce_bucket_idx == len(self._grad_buckets), (
            f"Not all bucket gradient reductions were launched: "
            f"{self._next_reduce_bucket_idx} vs {len(self._grad_buckets)}"
        )

        for idx, (handle, bucket_idx) in enumerate(self._grad_reduce_hooks):
            handle.wait()
            bucket = self._grad_buckets[bucket_idx]
            if bucket.reduce_scatter:
                assert bucket.flat_reduced_storage is not None
                if bucket.flat_reduced_comm is not None:
                    bucket.flat_reduced_storage.copy_(bucket.flat_reduced_comm)
                for param in bucket.params:
                    setattr(
                        param,
                        "_olmo_ddp_reduced_grad_shard",
                        self._param_to_reduced_grad_view[param],
                    )
            elif bucket.flat_comm is not None:
                bucket.flat_storage.copy_(bucket.flat_comm)
        self._grad_reduce_hooks = []

        self._next_reduce_bucket_idx = 0

        # mark all grads as not ready
        for key in self._param_grad_ready.keys():
            self._param_grad_ready[key] = False
        for bucket_idx in range(len(self._bucket_ready_count)):
            self._bucket_ready_count[bucket_idx] = 0
        self._forwards_since_finalize = 0
        self._sync_module_logical_grads_from_anchor()

    def init_sync(self):
        for process_group, parameters in self.process_group_to_params.items():
            # Verify model equivalence.
            _verify_param_shape_across_processes(process_group, parameters)

            for param in parameters:
                dist.broadcast(
                    param.data,
                    src=dist.get_global_rank(process_group, 0),
                    group=process_group,
                    async_op=False,
                )

    def __getstate__(self):
        # TODO: review if this works with multi-process-group DDP
        raise NotImplementedError("DDP serialization is not implemented.")

    def __setstate__(self, state):
        # TODO: review if this works with multi-process-group DDP
        raise NotImplementedError("DDP serialization is not implemented.")
        # If serializable, then the process group should be the default one

    @contextmanager
    def no_sync(self):
        r"""
        Context manager to disable gradient synchronizations across DDP processes.

        Within this context, gradients will be accumulated on module
        variables, which will later be synchronized in the first
        forward-backward pass exiting the context.

        Example::

            >>> # xdoctest: +SKIP("undefined variables")
            >>> ddp = torch.nn.parallel.DistributedDataParallel(model, pg)
            >>> with ddp.no_sync():
            >>>     for input in inputs:
            >>>         ddp(input).backward()  # no synchronization, accumulate grads
            >>> ddp(another_input).backward()  # synchronize grads

        .. warning::
            The forward pass should be included inside the context manager, or
            else gradients will still be synchronized.
        """
        old_require_backward_grad_sync = self.require_backward_grad_sync
        self.require_backward_grad_sync = False
        try:
            yield
        finally:
            self.require_backward_grad_sync = old_require_backward_grad_sync

    def _pre_forward(self, *inputs, **kwargs):
        if self.use_reduce_scatter and not self._reduce_scatter_configured:
            raise RuntimeError(
                "use_reduce_scatter=True requires optimizer placement to be "
                "configured before the first forward pass."
            )
        # This opt-in path owns one expert-gradient write per forward. Require its
        # backward to finish before starting another forward; interleaved pipeline
        # schedules would otherwise attribute recomputation to the newest epoch.
        if (
            torch.is_grad_enabled()
            and self._profile_forward_epoch > 0
            and any(
                epoch != self._profile_forward_epoch
                for epoch in self._profile_external_written.values()
            )
        ):
            raise RuntimeError(
                "Rounded wgrad requires backward after each forward; multiple outstanding "
                "forwards are unsupported"
            )
        self._ensure_grad_views_bound(allow_none_rebind=True, where="forward")
        self._has_started_forward = True
        self._forwards_since_finalize += 1
        if torch.is_grad_enabled():
            self._profile_forward_epoch += 1
        return inputs, kwargs

    def _post_forward(self, output):
        return output

    def forward(self, *inputs, **kwargs):
        with torch.autograd.profiler.record_function("MultiGroupDistributedDataParallel.forward"):
            inputs, kwargs = self._pre_forward(*inputs, **kwargs)
            output = self.module(*inputs, **kwargs)

            return self._post_forward(output)

    def train(self, mode=True):
        super().train(mode)
        return self

    def _zero_module_logical_grads(self, set_to_none: bool) -> None:
        zero_logical_grads = getattr(self.module, "zero_fp8_weight_store_grads", None)
        if zero_logical_grads is None:
            zero_logical_grads = getattr(self.module, "zero_mxfp8_expert_weight_grads", None)
        if zero_logical_grads is not None:
            zero_logical_grads(set_to_none=set_to_none)

    def _sync_module_logical_grads_from_anchor(self) -> None:
        sync_logical_grads = getattr(
            self.module,
            "sync_fp8_weight_store_grads_from_anchor",
            None,
        )
        if sync_logical_grads is None:
            sync_logical_grads = getattr(
                self.module,
                "sync_mxfp8_expert_weight_grads_from_anchor",
                None,
            )
        if sync_logical_grads is not None:
            sync_logical_grads()

    def zero_grad(self, set_to_none: bool = True):
        for param in self._reduce_scatter_params:
            if hasattr(param, "_olmo_ddp_reduced_grad_shard"):
                delattr(param, "_olmo_ddp_reduced_grad_shard")
        if not set_to_none:
            # Fast path for bucket-view mode: zero bucket storage once and keep view bindings.
            if self._grad_views_need_rebind:
                self._bind_bucket_views(zero_buffers=True, reason="zero_grad")
            else:
                for bucket in self._grad_buckets:
                    bucket.flat_storage.zero_()
                # In fp32-accum mode, .grad remains ephemeral.
                if self._accumulate_grads_in_fp32:
                    for param in self._module_parameters:
                        if param.requires_grad:
                            param.grad = None
            # Ignored params aren't in the reducer buckets; match Module.zero_grad(set_to_none=False)
            # by zeroing their existing grads (they're trained outside this reducer).
            if self.parameters_to_ignore:
                for name, param in self.module.named_parameters():
                    if name in self.parameters_to_ignore and param.grad is not None:
                        param.grad.detach_()
                        param.grad.zero_()
            self._forwards_since_finalize = 0
            self._zero_module_logical_grads(set_to_none=False)
            return

        super().zero_grad(set_to_none=True)
        if self._accumulate_grads_in_fp32:
            for param in self._module_parameters:
                if not param.requires_grad:
                    continue
                param._main_grad_fp32 = None  # type: ignore[attr-defined]

        self._forwards_since_finalize = 0
        self._grad_views_need_rebind = True
        self._zero_module_logical_grads(set_to_none=True)

    def set_main_grads_to_none(self):
        for param in self._reduce_scatter_params:
            if hasattr(param, "_olmo_ddp_reduced_grad_shard"):
                delattr(param, "_olmo_ddp_reduced_grad_shard")
        if hasattr(self.module, "set_main_grads_to_none"):
            self.module.set_main_grads_to_none()
        else:
            for param in self._module_parameters:
                if not param.requires_grad:
                    continue
                if hasattr(param, "_main_grad_fp32"):
                    param._main_grad_fp32 = None  # type: ignore[attr-defined]
            set_logical_main_grads_to_none = getattr(
                self.module,
                "set_fp8_weight_store_main_grads_to_none",
                None,
            )
            if set_logical_main_grads_to_none is None:
                set_logical_main_grads_to_none = getattr(
                    self.module,
                    "set_mxfp8_expert_weight_main_grads_to_none",
                    None,
                )
            if set_logical_main_grads_to_none is not None:
                set_logical_main_grads_to_none()
        self._grad_views_need_rebind = True
        self._forwards_since_finalize = 0

    def register_comm_hook(self, state: object, hook: Callable):
        raise NotImplementedError

    @property
    def _distributed_rank(self):
        return dist.get_rank(self.process_group)
