// External crates

use serde_json::json;
use std::fs;
use serde_json::Value;
use dashmap::DashMap;
use std::collections::HashMap;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::PathBuf;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Instant;

use anyhow::{Error, Result};
use clap::{Parser, Subcommand};
use rayon::prelude::*;
use serde_json;
use serde_yaml;
use gjson;

use mj_io::{
    build_pbar, expand_dirs, get_output_filename, read_pathbuf_to_mem, write_mem_to_pathbuf,
};
pub mod map_fxn;
pub mod partition;
pub mod utils;
pub mod groupfilter;
pub mod reservoir_sample;
pub use map_fxn::DataProcessor;
use datamap_rs::map_fxn::PipelineProcessor;
use datamap_rs::partition::{discrete_partition, range_partition};
use datamap_rs::reshard::reshard;
use datamap_rs::groupfilter::{group, group_filter};
use datamap_rs::reservoir_sample::reservoir_sample;
use datamap_rs::shuffle::shuffle; 
use datamap_rs::percentile_finder::percentile_finder;

/*
Map Config layout:

pipeline: list with:
    [{name,
     kwargs: {arg1: val1, ...}},
    ]

*/
/*============================================================
=                            ARGS                            =
============================================================*/

#[derive(Parser)]
#[clap(author, version, about, long_about = None)]
struct ArgParser {
    #[clap(subcommand)]
    command: Commands,

    #[arg(long, default_value_t = 0)]
    threads: usize,
}

#[derive(Subcommand, Debug)]
enum Commands {
    #[clap(arg_required_else_help = true)]
    Map {
        #[arg(required = true, long)]
        input_dir: PathBuf,

        #[arg(required = true, long)]
        output_dir: PathBuf,

        #[arg(required = true, long)]
        config: PathBuf,

        #[arg(long)]
        err_dir: Option<PathBuf>,

        #[arg(long)]
        delete_after_read: bool,
    },

    Reshard {
        #[arg(required = true, long)]
        input_dir: PathBuf,

        #[arg(required = true, long)]
        output_dir: PathBuf,

        #[arg(long, default_value_t = 0)]
        max_lines: usize,

        #[arg(long, default_value_t = 0)]
        max_size: usize,

        #[arg(long, default_value_t = 0.0)]
        subsample: f32,

        #[arg(long)]
        keep_dirs: bool,

        #[arg(long)]
        delete_after_read: bool,
    },

    ReservoirSample {
        #[arg(required=true, long)]
        input_dir: PathBuf,

        #[arg(required=true, long)]
        output_file: PathBuf,

        #[arg(required=true, long)]
        key: String,

        #[arg(required=true, long, default_value_t=100_000)]
        reservoir_size: usize,

        #[arg(long)]
        token_weighted: bool,

        #[arg(long, default_value_t=String::from("text"))]
        text_key: String,
    },

    PercentileFinder {
        #[arg(required=true, long, num_args = 1..)]
        input_dir: Vec<PathBuf>,

        #[arg(required=true, long)]
        output_file: PathBuf,

        #[arg(required=true, long)]
        score_key: String,

        #[arg(long, default_value_t=String::from("text"))]
        text_key: String,

        #[arg(long, default_value_t=String::from("cl100k"))]
        tokenizer: String,

        #[arg(long, default_value_t=100)]
        num_buckets: usize,

        #[arg(long, default_value_t=1.0)]
        subsample_rate: f32,
    },

    DiscretePartition {
        #[arg(required = true, long)]
        input_dir: PathBuf,

        #[arg(required = true, long)]
        output_dir: PathBuf,

        #[arg(long)]
        config: Option<PathBuf>,

        #[arg(long)]
        partition_key: Option<String>,  // Use this as the partition key if no config specified

        #[arg(long, default_value_t=false)]
        no_ft_label: bool
    },

    RangePartition {
        #[arg(required=true, long)]
        input_dir: PathBuf,

        #[arg(required=true, long)]
        output_dir: PathBuf,

        #[arg(long)]
        config: Option<PathBuf>,

        #[arg(long)]
        value: Option<String>,

        #[arg(long)]
        default_value: Option<f64>,

        #[arg(long, value_delimiter = ',')]
        range_groups: Option<Vec<f64>>,

        #[arg(long)]
        range_groups_json: Option<PathBuf>,

        #[arg(long)]
        num_buckets: Option<usize>,

        #[arg(long)]
        max_file_size: Option<usize>,

        #[arg(long)]
        bucket_name: Option<String>,
    },

    Group {
        #[arg(required = true, long)]
        input_dir: PathBuf,

        #[arg(required = true, long)]
        group_dir: PathBuf,

        #[arg(required = true, long)]
        config: PathBuf,

        #[arg(long)]
        subext: Option<String>,
    },

    GroupFilter {
        #[arg(required = true, long)]
        input_dir: PathBuf,

        #[arg(required = true, long)]
        output_dir: PathBuf,

        #[arg(required = true, long)]
        config: PathBuf,   

        #[arg(long, default_value_t=false)]             
        prev_sorted: bool
    },

    Shuffle {
        #[arg(required = true, long)]
        input_dir: PathBuf,

        #[arg(required = true, long)]
        output_dir: PathBuf,

        #[arg(required=true, long)]
        num_outputs: usize,

        #[arg(long, default_value_t=256_000_000)]
        max_len: usize,

        #[arg(long, default_value_t=false)]
        delete_after_read: bool
    },

    Count {
        #[arg(required=true, long)]
        input_dir: PathBuf,

        #[arg(required=true, long)]
        output_file: PathBuf,

        #[arg(long)] // If not None, points to string of key where we count total size
        count_bytes: Option<String>,

        #[arg(long)] // If not None, is a vec of keys pointing to usizes that we want to sum
        sum_keys: Option<Vec<String>>,

        #[arg(long, default_value_t=false)]
        count_per_doc: bool,

        #[arg(long, default_value_t=false)]
        split_by_dir: bool,
    },



}

/*============================================================
=                            UTILITIES                       =
============================================================*/

fn parse_config(config: &PathBuf) -> Result<serde_json::Value, Error> {
    // Handle either .yaml or .json config and return a Json value

    let file = File::open(config).unwrap();
    let reader = BufReader::new(file);

    let ext = config.extension().unwrap().to_str().unwrap();
    let parsed_config: serde_json::Value = match ext {
        "json" => serde_json::from_reader(reader).unwrap(),
        "yaml" => {
            let yaml_value: serde_yaml::Value = serde_yaml::from_reader(reader).unwrap();
            serde_json::to_value(yaml_value).unwrap()
        }
        _ => {
            return Err(Error::msg(format!("Weird config format: {:?}", config)));
        }
    };
    Ok(parsed_config.into())
}

fn write_output_lines(output_values: Vec<Value>, output_file: &PathBuf) -> Result<(), Error> {
    if output_values.len() == 0 {
        return Ok(());
    }

    let mut output_bytes: Vec<u8> = Vec::new();
    output_values.into_iter().for_each(|v| {
        output_bytes.extend(serde_json::to_vec(&v).unwrap());
        output_bytes.push(b'\n')
    });

    write_mem_to_pathbuf(&output_bytes, output_file)
}

fn print_global_stats_stuff(
    start_time: Instant,
    global_timer: DashMap<usize, AtomicUsize>,
    global_filter: DashMap<usize, usize>,
    processor: &PipelineProcessor,
) -> () {
    // Timing info
    let total_time = start_time.elapsed().as_secs();
    let step_times: HashMap<usize, usize> = global_timer
        .into_iter()
        .map(|(k, v)| (k, v.into_inner()))
        .collect();
    let total_step_time = step_times.values().sum::<usize>();
    let step_fracs: HashMap<usize, f64> = step_times
        .iter()
        .map(|(k, v)| (*k, *v as f64 / total_step_time as f64))
        .collect();

    // Filtering info
    let total_docs: usize = global_filter.iter().map(|e| *e.value()).sum::<usize>();
    let mut remaining_docs: usize = total_docs;

    // Print things
    println!("Finishing map in {:?} seconds", total_time);
    println!("Processed {:?} total documents", total_docs);
    println!("-------------------------------------------");
    for (i, el) in processor.pipeline.iter().enumerate() {
        println!("Step {:?} | {:?}", processor.steps[i], el);

        let step_time_pct = step_fracs.get(&i).unwrap();
        println!(
            "\t Spent {:.2}% of processing time in this step",
            step_time_pct * 100.0
        );

        let filter_entry = global_filter.get(&i).unwrap();
        let removed_in_this_step = filter_entry.value();

        let remaining_remove_pct =
            *removed_in_this_step as f32 / f32::max(0.0, remaining_docs as f32) * 100.0;
        let total_remove_pct =
            *removed_in_this_step as f32 / f32::max(0.0, total_docs as f32) * 100.0;
        remaining_docs -= removed_in_this_step;
        println!(
            "\t Removed {:?} docs | {:.2}% of remaining | {:.2}% of pool",
            removed_in_this_step, remaining_remove_pct, total_remove_pct
        );
    }

    println!("FINAL:");
    println!(
        "\t {:?} docs survived | {:.2}% of pool",
        remaining_docs,
        remaining_docs as f32 / f32::max(0.0, total_docs as f32) * 100.0
    );

    ()
}


/*============================================================
=                            GENERAL MAP                     =
============================================================*/

fn gen_map(
    input_dir: &PathBuf,
    output_dir: &PathBuf,
    config: &PathBuf,
    err_dir: Option<PathBuf>,
    delete_after_read: bool,
) -> Result<(), Error> {
    /* Generic mapping/filtration function.

    Processes each *.jsonl.* in input_dir and makes an identically named copy in output_dir
    with the changes specified in the config applied
    */

    // Setup data handlers
    let start_main = Instant::now();
    let all_files = expand_dirs(vec![input_dir.clone()], None).unwrap();
    let json_config = parse_config(config).unwrap();
    let processor = PipelineProcessor::new(&json_config).unwrap();

    // Setup logging utils
    let global_timer: DashMap<usize, AtomicUsize> = DashMap::new();
    let global_filter: DashMap<usize, usize> = DashMap::new();
    for i in 0..processor.pipeline.len() {
        global_timer.insert(i, AtomicUsize::new(0));
        global_filter.insert(i, 0);
    }
    global_filter.insert(usize::MAX, 0);
    let err_count: AtomicUsize = AtomicUsize::new(0);

    // Loop over input files
    let pbar = build_pbar(all_files.len(), "Files");
    all_files.par_iter().for_each(|p| {
        //let output_file = get_output_filename(p, input_dir, output_dir).unwrap();
        let err_file: Option<PathBuf> = if let Some(err_dir_real) = &err_dir {
            Some(get_output_filename(p, input_dir, &err_dir_real).unwrap())
        } else {
            None
        };
        let processor_clone = &processor;
        gen_map_single(
            p,
            input_dir,
            output_dir,
            err_file,
            &processor_clone,
            &global_timer,
            &global_filter,
            &err_count,
        )
        .unwrap();
        if delete_after_read {
            fs::remove_file(p).unwrap();
        }
        pbar.inc(1);
    });

    print_global_stats_stuff(start_main, global_timer, global_filter, &processor);
    Ok(())
}


fn gen_map_single(
    input_file: &PathBuf,
    input_dir: &PathBuf,
    output_dir: &PathBuf,
    err_file: Option<PathBuf>,
    processor: &PipelineProcessor,
    global_timer: &DashMap<usize, AtomicUsize>,
    global_filter: &DashMap<usize, usize>,
    err_count: &AtomicUsize,
) -> Result<(), Error> {
    /* Single-file mapping/filtration function

    Processes the contents of a single file, using file-centric mappers specified in the config and writes to output file
    */

    // Setup for processing
    let data = read_pathbuf_to_mem(input_file).unwrap();

    let lines: Vec<_> = data.lines().filter_map(|el| el.ok()).collect();

    // Process data
    let (output_lines, err_lines, timing_info, filter_info) =
        processor.process_lines(lines, input_file).unwrap();
    let err_lines_len = err_lines.len();

    output_lines.into_iter().for_each(|(k, v)| {
        let step_output_dir = if k < usize::MAX {
            output_dir.clone().join(processor.steps[k].to_string())
        } else {
            output_dir.clone().join("step_final")
        };
        let output_file = get_output_filename(input_file, input_dir, &step_output_dir).unwrap();
        write_output_lines(v, &output_file).unwrap();
    });

    if let Some(err_file_real) = err_file {
        let mut err_bytes: Vec<u8> = Vec::new();
        err_lines.into_iter().for_each(|line| {
            err_bytes.extend(line.as_bytes());
            err_bytes.push(b'\n');
        });
        if err_bytes.len() > 0 {
            write_mem_to_pathbuf(&err_bytes, &err_file_real).unwrap();
        }
    }

    // Do logging stuff
    let _ = err_count.fetch_add(err_lines_len, Ordering::SeqCst);
    timing_info.iter().for_each(|(k, v)| {
        global_timer
            .get(k)
            .unwrap()
            .fetch_add(*v as usize, Ordering::SeqCst);
    });

    filter_info.iter().for_each(|(k, v)| {
        global_filter.entry(*k).and_modify(|gv| *gv += v);
    });

    Ok(())
}

pub fn count(input_dir: &PathBuf, output_file: &PathBuf, count_bytes: Option<String>, count_per_doc: bool, sum_keys_opt: Option<Vec<String>>, split_by_dir: bool) -> Result<(), Error> {
    let start_main = Instant::now();
    let all_files = expand_dirs(vec![input_dir.clone()], None).unwrap();

    let total_doc_count : DashMap<String, usize> = DashMap::new();
    let total_file_sizes : DashMap<String, usize> = DashMap::new();  // uncompressed file sizes
    let total_text_bytes : DashMap<String, usize> = DashMap::new(); 
    let text_key: String = if let Some(text_key) = count_bytes {
        text_key
    } else {
        String::from("")
    };

    let sum_key_counter : DashMap<String, DashMap<String, usize>> = DashMap::new();
    let count_per_doc_opt: Option<DashMap<String, DashMap<PathBuf, usize>>> = if count_per_doc {
        Some(DashMap::new())
    } else {
        None
    };

    let pbar = build_pbar(all_files.len(), "files");

    all_files.into_par_iter().for_each(|p| {
        let dirname = if let Some(dir) = p.parent() {
            dir.to_str().unwrap()
        } else {
            ""
        }.to_string();
        let this_sum_key = sum_key_counter.entry(dirname.clone()).or_default();

        let contents = read_pathbuf_to_mem(&p).unwrap();
        let mut file_len = 0;
        let mut file_size = 0;
        let mut text_bytes = 0;
        let mut sum_key_path_counter: HashMap<String, usize> = if let Some(sum_keys) = &sum_keys_opt {
            sum_keys.iter().map(|el| (el.clone(), 0)).collect()
        } else {
            HashMap::new()
        };

        for line in contents.lines() {
            file_len += 1;
            let line = line.unwrap();
            file_size += line.len();
            if text_key.len() > 0 {
                let value = gjson::get(&line, &text_key);
                if value.exists() {
                    text_bytes += value.str().len();
                }
            }            
            for (k, v) in sum_key_path_counter.iter_mut() {
                let kval = gjson::get(&line, &k);
                if kval.exists() {
                    *v += kval.u64() as usize;
                }
            }
        }
        for (k, v) in sum_key_path_counter.iter() {
            this_sum_key.entry(k.clone()).and_modify(|og_v| *og_v += v).or_insert(*v);
        }
    
        total_doc_count.entry(dirname.clone()).and_modify(|og_v| *og_v += file_len).or_insert(file_len);
        total_file_sizes.entry(dirname.clone()).and_modify(|og_v| *og_v += file_size).or_insert(file_size);
        total_text_bytes.entry(dirname.clone()).and_modify(|og_v| *og_v += text_bytes).or_insert(text_bytes);
        if let Some(doc_counts) = &count_per_doc_opt {
            doc_counts.entry(dirname).or_default().entry(p).or_insert(text_bytes);
        }
        pbar.inc(1);
    });

    // aggregate step: aggregate based on dir name (or collapse all if split_by_dir == false)
    let agg_key = |dirname: String| -> String {
        if split_by_dir { dirname } else { String::from("") }
    };

    let total_doc_count: HashMap<String, usize> = total_doc_count
        .into_iter()
        .fold(HashMap::new(), |mut acc, (k, v)| {
            *acc.entry(agg_key(k)).or_insert(0) += v;
            acc
        });

    let total_file_sizes: HashMap<String, usize> = total_file_sizes
        .into_iter()
        .fold(HashMap::new(), |mut acc, (k, v)| {
            *acc.entry(agg_key(k)).or_insert(0) += v;
            acc
        });

    let total_text_bytes: HashMap<String, usize> = total_text_bytes
        .into_iter()
        .fold(HashMap::new(), |mut acc, (k, v)| {
            *acc.entry(agg_key(k)).or_insert(0) += v;
            acc
        });

    let sum_key_counter: HashMap<String, HashMap<String, usize>> = sum_key_counter
        .into_iter()
        .fold(HashMap::new(), |mut acc, (dirname, inner)| {
            let entry = acc.entry(agg_key(dirname)).or_insert_with(HashMap::new);
            for (sum_key, count) in inner.into_iter() {
                *entry.entry(sum_key).or_insert(0) += count;
            }
            acc
        });
    let output_json = if let Some(doc_counts) = count_per_doc_opt {
        let doc_counts: HashMap<PathBuf, usize> = doc_counts
            .into_iter()
            .flat_map(|(_, inner)| inner.into_iter())
            .collect();
        json!({
            "total_docs": total_doc_count,
            "total_file_size": total_file_sizes,
            "total_text_bytes": total_text_bytes,
            "per_file_text_bytes": doc_counts,
            "sum_keys": sum_key_counter
        })
    } else {
        json!({
            "total_docs": total_doc_count,
            "total_file_size": total_file_sizes,
            "total_text_bytes": total_text_bytes,
            "sum_keys": sum_key_counter
        })
    };

    let output_contents = serde_json::to_vec(&output_json).unwrap();
    write_mem_to_pathbuf(&output_contents, output_file).unwrap();

    let total_docs: usize = total_doc_count.values().sum();
    let total_bytes: usize = total_file_sizes.values().sum();
    let total_text: usize = total_text_bytes.values().sum();
    println!(
        "Saw {:?} docs ({:?} bytes) | {:?} text bytes | {:?} sum keys | in {:?} secs",
        total_docs, total_bytes, total_text, sum_key_counter, start_main.elapsed().as_secs()
    );

    Ok(())
}


/*============================================================
=                            MAIN                            =
============================================================*/
#[allow(unreachable_patterns)]
fn main() {
    let args = ArgParser::parse();
    let threads = args.threads;
    if threads != 0 {
        std::env::set_var("RAYON_NUM_THREADS", threads.to_string());
    }

    let result = match &args.command {
        Commands::Map {
            input_dir,
            output_dir,
            config,
            err_dir,
            delete_after_read,

        } => gen_map(input_dir, output_dir, config, err_dir.clone(), *delete_after_read),
        Commands::Reshard {
            input_dir,
            output_dir,
            max_lines,
            max_size,
            subsample,
            keep_dirs,
            delete_after_read,
        } => reshard(
            input_dir,
            output_dir,
            *max_lines,
            *max_size,
            *subsample,
            *keep_dirs,
            *delete_after_read,
        ),
        Commands::ReservoirSample {
            input_dir,
            output_file,
            key,
            reservoir_size,
            token_weighted,
            text_key
        } => reservoir_sample(input_dir, output_file, key, *reservoir_size, *token_weighted, &text_key.clone()),


        Commands::PercentileFinder {
            input_dir,
            output_file,
            score_key,
            tokenizer,
            text_key,
            num_buckets,
            subsample_rate
        } => percentile_finder(input_dir, output_file, score_key, text_key, tokenizer, *num_buckets, *subsample_rate),

        Commands::DiscretePartition {
            input_dir,
            output_dir,
            config,
            partition_key,
            no_ft_label
        } => discrete_partition(input_dir, output_dir, config, partition_key, *no_ft_label),

        Commands::RangePartition {
            input_dir,
            output_dir,
            config,
            value, default_value, range_groups, range_groups_json, num_buckets, max_file_size, bucket_name

        } => range_partition(input_dir, output_dir, config, value, default_value, range_groups, range_groups_json, num_buckets, max_file_size, bucket_name),
        Commands::Group {
            input_dir,
            group_dir,
            config,
            subext
        } => group(input_dir, group_dir, config, subext.clone()),
        Commands::GroupFilter {
            input_dir,
            output_dir,
            config,
            prev_sorted,
        } => group_filter(input_dir, output_dir, config, *prev_sorted),

        Commands::Shuffle {
            input_dir, output_dir, num_outputs, max_len, delete_after_read
        } => shuffle(input_dir, output_dir, *num_outputs, *max_len, *delete_after_read),

        Commands::Count {
            input_dir, output_file, count_bytes, count_per_doc, sum_keys, split_by_dir,
        } => count(input_dir, output_file, count_bytes.clone(), *count_per_doc, sum_keys.clone(), *split_by_dir),

        _ => Ok(()),
    };
    result.unwrap();
}
