# Hacktoberfest 2026 preparation — open PR cleanup tracker

This file tracks the cleanup of open pull requests ahead of [Hacktoberfest 2026](https://hacktoberfest.com) so the queue is ready for the October influx of contributions.

Each of the `scripts/close_pull_requests_with_*.sh` jobs is run one at a time by a maintainer. After each run, the affected lines below are checked off (`[ ]` -> `[x]`), their labels replaced with "closed by <script name>", and the totals table at the bottom updated.

Snapshot taken: **2026-09-02** -- **918** open pull requests.

Latest refresh: **2026-09-06** -- reconciled the tracker with the live PR queue: **84** more tracked PRs are now resolved (**10 merged**: #13862, #13903, #14038, #14260, #14291, #14307, #14346, #14562, #14663, #15182; **74 closed**). Approximately **669** pull requests remain open.

Notation: `<index>. [ ] #<pr_id> <labels>`

## Open pull requests

1. [x] #15158 merged
2. [x] #15156 merged
3. [x] #15147 closed
4. [x] #15146 closed by maintainer
5. [x] #15144 closed
6. [x] #15142 closed
7. [x] #15128 closed by close_pull_requests_with_failing_tests.sh
8. [x] #15117 merged
9. [x] #15108 merged
10. [x] #15107 merged
11. [x] #15105 merged
12. [x] #15103 closed
13. [x] #15102 closed
14. [x] #15101 closed
15. [x] #15092 merged
16. [x] #15091 merged
17. [x] #15090 merged
18. [x] #15086 closed
19. [x] #15084 merged
20. [x] #15076 merged
21. [x] #15074 closed
22. [x] #15072 merged
23. [x] #15063 merged
24. [x] #15057 closed by close_pull_requests_with_failing_tests.sh
25. [x] #15056 merged
26. [x] #15055 merged
27. [x] #15054 closed
28. [x] #15053 closed
29. [x] #15051 merged
30. [x] #15050 closed
31. [x] #15048 closed
32. [x] #15047 closed
33. [x] #15046 closed
34. [x] #15045 closed
35. [x] #15044 merged
36. [x] #15043 closed
37. [x] #15042 closed
38. [x] #15041 closed
39. [x] #15040 closed
40. [x] #15039 closed
41. [x] #15038 merged
42. [x] #15036 closed
43. [x] #15026 closed
44. [x] #15025 closed by close_pull_requests_with_failing_tests.sh
45. [x] #15024 closed
46. [x] #15023 merged
47. [x] #15021 closed by close_pull_requests_with_failing_tests.sh
48. [x] #15019 closed
49. [x] #15014 merged
50. [x] #15012 merged
51. [x] #15011 closed
52. [x] #15010 closed
53. [x] #15009 merged
54. [x] #15005 closed
55. [x] #15003 merged
56. [x] #15001 closed
57. [x] #14997 closed
58. [x] #14995 merged
59. [x] #14991 merged
60. [x] #14990 closed
61. [x] #14988 merged
62. [x] #14987 closed
63. [x] #14986 merged
64. [x] #14979 merged
65. [x] #14975 closed by close_pull_requests_with_failing_tests.sh
66. [x] #14974 closed by close_pull_requests_with_failing_tests.sh
67. [x] #14973 closed by close_pull_requests_with_require_tests.sh
68. [x] #14972 closed by close_pull_requests_with_failing_tests.sh
69. [x] #14967 closed
70. [x] #14939 merged
71. [x] #14938 closed by close_pull_requests_with_failing_tests.sh
72. [x] #14925 merged
73. [x] #14923 closed
74. [x] #14920 closed
75. [x] #14914 closed
76. [x] #14909 closed
77. [x] #14907 merged
78. [x] #14904 merged
79. [x] #14899 closed
80. [x] #14895 merged
81. [x] #14894 merged
82. [x] #14890 merged
83. [x] #14889 merged
84. [x] #14883 closed
85. [x] #14882 closed
86. [x] #14879 merged
87. [x] #14878 closed
88. [x] #14876 merged
89. [x] #14875 merged
90. [x] #14874 closed
91. [x] #14873 closed
92. [x] #14872 merged
93. [x] #14871 closed
94. [x] #14868 closed
95. [x] #14864 closed
96. [x] #14862 closed
97. [x] #14861 closed
98. [x] #14858 merged
99. [x] #14856 merged
100. [x] #14853 closed
101. [x] #14851 merged
102. [x] #14850 merged
103. [x] #14848 merged
104. [x] #14845 merged
105. [x] #14843 closed
106. [x] #14838 closed
107. [x] #14835 closed by close_pull_requests_with_failing_tests.sh
108. [x] #14833 merged
109. [x] #14832 closed
110. [x] #14829 closed
111. [x] #14827 closed
112. [x] #14826 closed
113. [x] #14824 closed by close_pull_requests_with_require_type_hints.sh
114. [x] #14823 closed
115. [x] #14821 merged
116. [x] #14819 closed
117. [x] #14818 closed by close_pull_requests_with_failing_tests.sh
118. [x] #14814 merged
119. [x] #14812 closed
120. [x] #14810 closed by close_pull_requests_with_require_type_hints.sh
121. [x] #14807 merged
122. [x] #14806 closed
123. [x] #14805 merged
124. [x] #14802 closed
125. [x] #14801 closed
126. [x] #14800 merged
127. [x] #14798 closed
128. [x] #14792 closed
129. [x] #14787 closed
130. [x] #14786 merged
131. [x] #14785 closed
132. [x] #14779 merged
133. [x] #14777 merged
134. [x] #14775 merged
135. [x] #14770 merged
136. [x] #14769 merged
137. [x] #14768 merged
138. [x] #14767 merged
139. [x] #14759 closed
140. [x] #14753 merged
141. [x] #14751 closed
142. [x] #14746 closed
143. [x] #14743 merged
144. [x] #14742 merged
145. [x] #14740 closed
146. [x] #14738 closed
147. [x] #14736 closed
148. [x] #14733 merged
149. [x] #14732 closed by close_pull_requests_with_require_tests.sh
150. [x] #14731 closed by close_pull_requests_with_failing_tests.sh
151. [x] #14729 closed
152. [x] #14728 merged
153. [x] #14727 closed by close_pull_requests_with_failing_tests.sh
154. [x] #14726 closed by close_pull_requests_with_require_type_hints.sh
155. [x] #14724 closed
156. [x] #14723 closed by close_pull_requests_with_failing_tests.sh
157. [x] #14721 closed
158. [x] #14718 closed
159. [x] #14717 closed by close_pull_requests_with_failing_tests.sh
160. [x] #14714 closed
161. [x] #14713 closed
162. [x] #14712 closed
163. [x] #14708 closed
164. [x] #14702 closed
165. [x] #14701 merged
166. [x] #14700 closed by close_pull_requests_with_failing_tests.sh
167. [x] #14694 closed
168. [x] #14690 closed by close_pull_requests_with_failing_tests.sh
169. [x] #14685 merged
170. [x] #14680 closed by close_pull_requests_with_failing_tests.sh
171. [x] #14677 closed by close_pull_requests_with_require_descriptive_names.sh
172. [x] #14673 closed
173. [x] #14668 closed
174. [x] #14665 merged
175. [x] #14663 merged
176. [x] #14660 closed by close_pull_requests_with_require_type_hints.sh
177. [x] #14657 closed
178. [x] #14655 closed
179. [x] #14654 merged
180. [x] #14652 merged
181. [x] #14647 closed
182. [x] #14641 merged
183. [x] #14637 merged
184. [x] #14635 merged
185. [x] #14634 merged
186. [x] #14633 merged
187. [x] #14630 merged
188. [x] #14627 closed
189. [x] #14626 closed
190. [x] #14625 closed by close_pull_requests_with_failing_tests.sh
191. [x] #14623 merged
192. [x] #14622 closed
193. [x] #14618 closed by close_pull_requests_with_failing_tests.sh
194. [x] #14617 closed by close_pull_requests_with_failing_tests.sh
195. [x] #14616 closed by close_pull_requests_with_failing_tests.sh
196. [x] #14613 closed
197. [x] #14611 closed
198. [x] #14610 closed
199. [x] #14609 closed
200. [x] #14608 closed
201. [x] #14607 merged
202. [x] #14602 merged
203. [x] #14594 closed by close_pull_requests_with_failing_tests.sh
204. [x] #14582 closed by close_pull_requests_with_require_tests.sh
205. [x] #14581 closed
206. [x] #14579 closed
207. [x] #14574 closed
208. [x] #14571 closed
209. [x] #14570 closed
210. [x] #14568 merged
211. [x] #14563 closed
212. [x] #14562 merged
213. [x] #14560 merged
214. [x] #14555 merged
215. [x] #14554 merged
216. [x] #14539 closed
217. [x] #14527 closed
218. [x] #14526 closed
219. [x] #14525 closed
220. [x] #14524 closed by close_pull_requests_with_failing_tests.sh
221. [x] #14523 closed
222. [x] #14518 closed by close_pull_requests_with_failing_tests.sh
223. [x] #14511 closed by close_pull_requests_with_failing_tests.sh
224. [x] #14510 closed by close_pull_requests_with_failing_tests.sh
225. [x] #14507 closed by close_pull_requests_with_failing_tests.sh
226. [x] #14506 merged
227. [x] #14504 closed
228. [x] #14495 merged
229. [x] #14492 closed
230. [x] #14486 closed by close_pull_requests_with_failing_tests.sh
231. [x] #14482 merged
232. [x] #14480 closed by close_pull_requests_with_failing_tests.sh
233. [x] #14478 closed by close_pull_requests_with_require_tests.sh
234. [x] #14477 closed
235. [x] #14472 closed
236. [x] #14468 closed by close_pull_requests_with_failing_tests.sh
237. [x] #14460 merged
238. [x] #14456 closed
239. [x] #14455 closed by close_pull_requests_with_failing_tests.sh
240. [x] #14440 closed
241. [x] #14437 merged
242. [x] #14436 closed
243. [x] #14432 merged
244. [x] #14415 closed
245. [x] #14414 merged
246. [x] #14410 closed
247. [x] #14409 closed
248. [x] #14402 closed by close_pull_requests_with_require_type_hints.sh
249. [x] #14398 merged
250. [x] #14364 closed
251. [x] #14363 closed
252. [x] #14360 closed
253. [x] #14357 merged
254. [x] #14352 closed by close_pull_requests_with_require_tests.sh
255. [x] #14351 merged
256. [x] #14346 merged
257. [x] #14342 closed by close_pull_requests_with_require_tests.sh
258. [x] #14336 closed by close_pull_requests_with_failing_tests.sh
259. [x] #14332 closed by close_pull_requests_with_failing_tests.sh
260. [x] #14331 closed by close_pull_requests_with_failing_tests.sh
261. [x] #14321 closed by close_pull_requests_with_require_descriptive_names.sh
262. [x] #14316 closed by close_pull_requests_with_require_type_hints.sh
263. [x] #14314 closed by close_pull_requests_with_require_tests.sh
264. [x] #14307 merged
265. [x] #14304 closed by close_pull_requests_with_failing_tests.sh
266. [x] #14303 closed by close_pull_requests_with_require_tests.sh
267. [x] #14300 closed by close_pull_requests_with_failing_tests.sh
268. [x] #14297 closed by close_pull_requests_with_failing_tests.sh
269. [x] #14291 merged
270. [x] #14290 closed by close_pull_requests_with_failing_tests.sh
271. [x] #14286 closed by close_pull_requests_with_failing_tests.sh
272. [x] #14285 closed by close_pull_requests_with_failing_tests.sh
273. [x] #14284 closed
274. [x] #14283 closed by close_pull_requests_with_failing_tests.sh
275. [x] #14278 closed
276. [x] #14277 closed
277. [x] #14275 merged
278. [x] #14272 closed by close_pull_requests_with_failing_tests.sh
279. [x] #14270 closed by close_pull_requests_with_failing_tests.sh
280. [x] #14269 closed by close_pull_requests_with_failing_tests.sh
281. [x] #14264 closed
282. [x] #14262 merged
283. [x] #14261 closed by close_pull_requests_with_failing_tests.sh
284. [x] #14260 merged
285. [x] #14256 closed by close_pull_requests_with_failing_tests.sh
286. [x] #14239 closed
287. [x] #14237 merged
288. [x] #14234 closed by close_pull_requests_with_failing_tests.sh
289. [x] #14233 merged
290. [x] #14229 merged
291. [x] #14227 closed by close_pull_requests_with_failing_tests.sh
292. [x] #14224 closed
293. [x] #14221 closed
294. [x] #14219 closed
295. [x] #14216 closed
296. [x] #14202 closed
297. [x] #14197 closed
298. [x] #14192 closed
299. [x] #14190 closed
300. [x] #14188 closed
301. [x] #14186 merged
302. [x] #14185 closed by close_pull_requests_with_require_type_hints.sh
303. [x] #14159 closed
304. [x] #14158 merged
305. [x] #14153 closed
306. [x] #14151 closed
307. [x] #14143 merged
308. [x] #14142 closed
309. [x] #14138 closed by close_pull_requests_with_require_type_hints.sh
310. [x] #14134 closed
311. [x] #14099 closed
312. [x] #14098 closed by close_pull_requests_with_failing_tests.sh
313. [x] #14096 closed by close_pull_requests_with_failing_tests.sh
314. [x] #14095 merged
315. [x] #14090 closed by close_pull_requests_with_require_type_hints.sh
316. [x] #14089 merged
317. [x] #14088 closed by close_pull_requests_with_failing_tests.sh
318. [x] #14086 closed by close_pull_requests_with_require_tests.sh
319. [x] #14085 closed by close_pull_requests_with_failing_tests.sh
320. [x] #14082 closed by close_pull_requests_with_require_descriptive_names.sh
321. [x] #14080 closed by close_pull_requests_with_failing_tests.sh
322. [x] #14079 closed
323. [x] #14065 closed
324. [x] #14061 closed by close_pull_requests_with_require_descriptive_names.sh
325. [x] #14059 merged
326. [x] #14058 closed
327. [x] #14057 closed by close_pull_requests_with_failing_tests.sh
328. [x] #14056 closed
329. [x] #14052 closed
330. [x] #14051 closed
331. [x] #14048 closed
332. [x] #14045 closed by close_pull_requests_with_require_tests.sh
333. [x] #14041 merged
334. [x] #14040 closed by close_pull_requests_with_failing_tests.sh
335. [x] #14038 merged
336. [x] #14037 closed
337. [x] #14036 closed
338. [x] #14035 merged
339. [x] #14034 closed by close_pull_requests_with_failing_tests.sh
340. [x] #14032 closed
341. [x] #14031 merged
342. [x] #14030 closed
343. [x] #14029 merged
344. [x] #14028 closed by close_pull_requests_with_require_descriptive_names.sh
345. [x] #14027 closed by close_pull_requests_with_require_tests.sh
346. [x] #14026 closed
347. [x] #14023 closed
348. [x] #14022 closed by close_pull_requests_with_require_descriptive_names.sh
349. [x] #14021 closed
350. [x] #14019 closed by close_pull_requests_with_require_tests.sh
351. [x] #14016 closed
352. [x] #14015 closed
353. [x] #14014 closed by close_pull_requests_with_require_type_hints.sh
354. [x] #14009 merged
355. [x] #14008 closed
356. [x] #14004 closed by close_pull_requests_with_require_tests.sh
357. [x] #14001 merged
358. [x] #14000 closed by close_pull_requests_with_failing_tests.sh
359. [x] #13994 closed
360. [x] #13993 closed
361. [x] #13991 closed
362. [x] #13990 closed
363. [x] #13989 closed by close_pull_requests_with_require_descriptive_names.sh
364. [x] #13987 merged
365. [x] #13984 closed
366. [x] #13983 closed by close_pull_requests_with_failing_tests.sh
367. [x] #13977 closed
368. [x] #13973 closed
369. [x] #13972 merged
370. [x] #13969 closed
371. [x] #13967 closed by close_pull_requests_with_failing_tests.sh
372. [x] #13966 closed
373. [x] #13964 closed
374. [x] #13963 closed
375. [x] #13962 closed
376. [x] #13960 merged
377. [x] #13958 closed by close_pull_requests_with_failing_tests.sh
378. [x] #13955 closed
379. [x] #13954 merged
380. [x] #13950 closed
381. [x] #13947 closed
382. [x] #13943 closed by close_pull_requests_with_failing_tests.sh
383. [x] #13942 closed by close_pull_requests_with_failing_tests.sh
384. [x] #13941 closed
385. [x] #13938 closed
386. [x] #13935 closed by close_pull_requests_with_failing_tests.sh
387. [x] #13934 closed
388. [x] #13924 closed
389. [x] #13916 closed by close_pull_requests_with_failing_tests.sh
390. [x] #13915 closed
391. [x] #13912 closed by close_pull_requests_with_require_descriptive_names.sh
392. [x] #13911 closed
393. [x] #13909 closed
394. [x] #13907 closed
395. [x] #13906 merged
396. [x] #13903 merged
397. [x] #13901 closed
398. [x] #13900 closed
399. [x] #13899 closed by close_pull_requests_with_failing_tests.sh
400. [x] #13897 closed by close_pull_requests_with_failing_tests.sh
401. [x] #13896 merged
402. [x] #13894 closed
403. [x] #13892 closed
404. [x] #13891 merged
405. [x] #13888 closed
406. [x] #13884 closed
407. [x] #13883 closed by close_pull_requests_with_require_tests.sh
408. [x] #13882 closed
409. [x] #13880 closed
410. [x] #13879 closed by close_pull_requests_with_failing_tests.sh
411. [x] #13878 closed by close_pull_requests_with_failing_tests.sh
412. [x] #13873 closed
413. [x] #13869 closed
414. [x] #13862 merged
415. [x] #13850 merged
416. [x] #13847 closed
417. [x] #13843 closed
418. [x] #13841 closed
419. [x] #13839 closed by close_pull_requests_with_failing_tests.sh
420. [x] #13836 closed
421. [x] #13835 closed
422. [x] #13831 merged
423. [x] #13830 closed
424. [x] #13827 merged
425. [x] #13826 merged
426. [x] #13825 closed
427. [x] #13824 closed
428. [x] #13823 closed by close_pull_requests_with_require_tests.sh
429. [x] #13822 closed by close_pull_requests_with_require_tests.sh
430. [x] #13818 closed
431. [x] #13816 closed by close_pull_requests_with_failing_tests.sh
432. [x] #13815 merged
433. [x] #13814 closed
434. [x] #13810 closed by close_pull_requests_with_failing_tests.sh
435. [x] #13808 closed
436. [x] #13807 closed
437. [x] #13806 closed
438. [x] #13802 closed
439. [x] #13799 closed by close_pull_requests_with_failing_tests.sh
440. [x] #13797 merged
441. [x] #13791 closed
442. [x] #13790 closed by close_pull_requests_with_failing_tests.sh
443. [x] #13789 closed by close_pull_requests_with_failing_tests.sh
444. [x] #13781 closed by close_pull_requests_with_require_tests.sh
445. [x] #13774 closed by close_pull_requests_with_require_tests.sh
446. [x] #13773 closed by close_pull_requests_with_require_type_hints.sh
447. [x] #13772 closed by close_pull_requests_with_require_descriptive_names.sh
448. [x] #13761 closed by close_pull_requests_with_require_tests.sh
449. [x] #13758 closed
450. [x] #13754 closed
451. [x] #13753 merged
452. [x] #13751 merged
453. [x] #13750 closed
454. [x] #13749 closed
455. [x] #13746 closed by close_pull_requests_with_failing_tests.sh
456. [x] #13745 closed by close_pull_requests_with_failing_tests.sh
457. [x] #13744 closed
458. [x] #13742 closed by close_pull_requests_with_require_tests.sh
459. [x] #13738 closed
460. [x] #13737 closed
461. [x] #13734 closed
462. [x] #13733 closed
463. [x] #13729 closed
464. [x] #13726 closed
465. [x] #13718 merged
466. [x] #13716 merged
467. [x] #13712 closed by close_pull_requests_with_require_tests.sh
468. [x] #13707 closed
469. [x] #13701 closed
470. [x] #13699 merged
471. [x] #13694 closed
472. [x] #13691 closed by close_pull_requests_with_require_descriptive_names.sh
473. [x] #13690 merged
474. [x] #13688 merged
475. [x] #13682 closed by close_pull_requests_with_require_type_hints.sh
476. [x] #13681 merged
477. [x] #13680 merged
478. [x] #13679 closed by close_pull_requests_with_require_descriptive_names.sh
479. [x] #13676 closed by close_pull_requests_with_require_descriptive_names.sh
480. [x] #13675 closed by close_pull_requests_with_require_descriptive_names.sh
481. [x] #13671 closed by close_pull_requests_with_failing_tests.sh
482. [x] #13661 closed
483. [x] #13658 closed by close_pull_requests_with_require_type_hints.sh
484. [x] #13655 closed by close_pull_requests_with_require_tests.sh
485. [x] #13653 closed by close_pull_requests_with_failing_tests.sh
486. [x] #13648 closed
487. [x] #13647 closed
488. [x] #13646 closed by close_pull_requests_with_failing_tests.sh
489. [x] #13645 closed
490. [x] #13644 closed by close_pull_requests_with_require_type_hints.sh
491. [x] #13641 closed
492. [x] #13640 closed
493. [x] #13639 closed
494. [x] #13637 merged
495. [x] #13636 closed by close_pull_requests_with_require_type_hints.sh
496. [x] #13635 closed
497. [x] #13634 merged
498. [x] #13631 merged
499. [x] #13623 merged
500. [x] #13619 merged
501. [x] #13615 merged
502. [x] #13609 closed
503. [x] #13606 closed
504. [x] #13605 closed by close_pull_requests_with_failing_tests.sh
505. [x] #13604 closed
506. [x] #13603 merged
507. [x] #13601 closed
508. [x] #13600 closed by close_pull_requests_with_require_tests.sh
509. [x] #13597 closed
510. [x] #13595 closed by close_pull_requests_with_failing_tests.sh
511. [x] #13593 closed
512. [x] #13589 merged
513. [x] #13588 merged
514. [x] #13586 closed
515. [x] #13585 closed by close_pull_requests_with_failing_tests.sh
516. [x] #13558 closed by close_pull_requests_with_failing_tests.sh
517. [x] #13555 closed
518. [x] #13554 closed
519. [x] #13552 closed by close_pull_requests_with_failing_tests.sh
520. [x] #13551 closed
521. [x] #13550 merged
522. [x] #13544 closed by close_pull_requests_with_failing_tests.sh
523. [x] #13541 closed by close_pull_requests_with_failing_tests.sh
524. [x] #13538 closed
525. [x] #13536 closed by close_pull_requests_with_failing_tests.sh
526. [x] #13535 merged
527. [x] #13534 merged
528. [x] #13531 closed
529. [x] #13529 merged
530. [x] #13528 merged
531. [x] #13527 merged
532. [x] #13526 closed by close_pull_requests_with_failing_tests.sh
533. [x] #13523 closed by close_pull_requests_with_require_tests.sh
534. [x] #13522 closed
535. [x] #13520 closed by close_pull_requests_with_failing_tests.sh
536. [x] #13519 closed
537. [x] #13514 closed
538. [x] #13510 merged
539. [x] #13506 closed by close_pull_requests_with_failing_tests.sh
540. [x] #13502 closed
541. [x] #13487 closed
542. [x] #13485 closed by close_pull_requests_with_failing_tests.sh
543. [x] #13484 merged
544. [x] #13483 merged
545. [x] #13482 closed
546. [x] #13475 merged
547. [x] #13472 closed
548. [x] #13471 closed
549. [x] #13469 closed
550. [x] #13468 closed
551. [x] #13462 closed
552. [x] #13457 closed by close_pull_requests_with_failing_tests.sh
553. [x] #13452 closed
554. [x] #13447 merged
555. [x] #13426 merged
556. [x] #13424 merged
557. [x] #13421 closed
558. [x] #13419 closed
559. [x] #13418 closed
560. [x] #13413 closed by close_pull_requests_with_require_descriptive_names.sh
561. [x] #13410 closed
562. [x] #13409 merged
563. [x] #13402 merged
564. [x] #13395 closed
565. [x] #13378 closed
566. [x] #13371 closed
567. [x] #13370 merged
568. [x] #13369 merged
569. [x] #13364 closed
570. [x] #13363 closed
571. [x] #13361 closed
572. [x] #13360 closed
573. [x] #13357 closed
574. [x] #13355 merged
575. [x] #13345 closed
576. [x] #13343 merged
577. [x] #13342 merged
578. [x] #13341 merged
579. [x] #13337 merged
580. [x] #13334 merged
581. [x] #13330 closed
582. [x] #13327 closed
583. [x] #13325 merged
584. [x] #13323 closed
585. [x] #13322 merged
586. [x] #13316 merged
587. [x] #13312 closed
588. [x] #13300 closed
589. [x] #13297 closed
590. [x] #13296 closed
591. [x] #13295 closed
592. [x] #13288 merged
593. [x] #13273 closed
594. [x] #13271 closed
595. [x] #13270 closed
596. [x] #13252 closed
597. [x] #13251 closed
598. [x] #13249 closed
599. [x] #13239 closed
600. [x] #13236 merged
601. [x] #13234 closed
602. [x] #13231 merged
603. [x] #13221 merged
604. [x] #13219 merged
605. [x] #13217 merged
606. [x] #13216 closed
607. [x] #13208 closed
608. [x] #13198 closed
609. [x] #13194 closed
610. [x] #13192 closed
611. [x] #13191 closed
612. [x] #13187 closed
613. [x] #13183 merged
614. [x] #13178 closed
615. [x] #13176 closed
616. [x] #13172 closed
617. [x] #13164 closed
618. [x] #13162 closed
619. [x] #13157 merged
620. [x] #13149 merged
621. [x] #13147 merged
622. [x] #13146 merged
623. [x] #13142 closed
624. [x] #13141 closed
625. [x] #13136 closed
626. [x] #13135 closed
627. [x] #13133 merged
628. [x] #13132 closed
629. [x] #13131 closed
630. [x] #13129 closed
631. [x] #13128 merged
632. [x] #13121 closed
633. [x] #13119 closed
634. [x] #13118 closed
635. [x] #13114 merged
636. [x] #13113 closed
637. [x] #13112 closed
638. [x] #13110 closed
639. [x] #13106 closed
640. [x] #13105 closed
641. [x] #13102 merged
642. [x] #13101 closed
643. [x] #13100 closed
644. [x] #13094 closed
645. [x] #13093 closed
646. [x] #13090 closed
647. [x] #13085 merged
648. [x] #13071 closed
649. [x] #13063 merged
650. [x] #13055 merged
651. [x] #13050 closed
652. [x] #13039 closed
653. [x] #13038 closed
654. [x] #13036 merged
655. [x] #13033 closed
656. [x] #13026 merged
657. [x] #13023 closed
658. [x] #13022 merged
659. [x] #13019 closed
660. [x] #13018 merged
661. [x] #13017 merged
662. [x] #13016 merged
663. [x] #13015 closed
664. [x] #13014 merged
665. [x] #13013 closed
666. [x] #13012 closed
667. [x] #13009 closed by close_pull_requests_with_failing_tests.sh
668. [x] #13007 closed
669. [x] #13002 closed
670. [x] #13000 merged
671. [x] #12999 merged
672. [x] #12998 closed
673. [x] #12989 closed
674. [x] #12980 closed
675. [x] #12976 closed
676. [x] #12974 merged
677. [x] #12956 closed by close_pull_requests_with_failing_tests.sh
678. [x] #12942 closed
679. [x] #12940 merged
680. [x] #12896 closed
681. [x] #12895 closed
682. [x] #12894 merged
683. [x] #12881 merged
684. [x] #12876 merged
685. [x] #12875 merged
686. [x] #12852 closed
687. [x] #12839 closed
688. [x] #12834 closed
689. [x] #12830 merged
690. [x] #12829 closed
691. [x] #12792 merged
692. [x] #12790 closed
693. [x] #12784 closed
694. [x] #12777 closed
695. [x] #12767 merged
696. [x] #12764 merged
697. [x] #12763 closed
698. [x] #12762 closed
699. [x] #12757 merged
700. [x] #12756 merged
701. [x] #12748 closed
702. [x] #12723 closed
703. [x] #12706 merged
704. [x] #12703 closed
705. [x] #12701 merged
706. [x] #12700 closed
707. [x] #12696 closed
708. [x] #12694 merged
709. [x] #12691 closed
710. [x] #12690 merged
711. [x] #12686 merged
712. [x] #12684 merged
713. [x] #12668 merged
714. [x] #12648 closed
715. [x] #12645 closed
716. [x] #12616 closed
717. [x] #12601 merged
718. [x] #12594 closed
719. [x] #12593 closed
720. [x] #12575 closed
721. [x] #12559 closed
722. [x] #12555 merged
723. [x] #12552 merged
724. [x] #12541 closed
725. [x] #12540 closed
726. [x] #12526 closed
727. [x] #12522 closed
728. [x] #12498 closed
729. [x] #12421 closed
730. [x] #12413 merged
731. [x] #12412 closed
732. [x] #12392 closed
733. [x] #12358 merged
734. [x] #12357 merged
735. [x] #12356 closed
736. [x] #12355 closed
737. [x] #12344 merged
738. [x] #12335 merged
739. [x] #12333 merged
740. [x] #12326 closed
741. [x] #12319 closed
742. [x] #12317 merged
743. [x] #12311 merged
744. [x] #12295 merged
745. [x] #12287 closed
746. [x] #12285 merged
747. [x] #12281 closed
748. [x] #12275 closed
749. [x] #12271 merged
750. [x] #12263 closed
751. [x] #12262 merged
752. [x] #12259 closed
753. [x] #12246 merged
754. [x] #12214 merged
755. [x] #12210 merged
756. [x] #12209 merged
757. [x] #12207 closed
758. [x] #12206 closed
759. [x] #12188 closed
760. [x] #12186 merged
761. [x] #12171 closed
762. [x] #12141 merged
763. [x] #12140 closed
764. [x] #12133 merged
765. [x] #12129 merged
766. [x] #12125 merged
767. [x] #12123 merged
768. [x] #12118 merged
769. [x] #12111 closed
770. [x] #12109 closed by maintainer (superseded by #13146)
771. [x] #12104 merged
772. [x] #12100 closed
773. [x] #12091 merged
774. [x] #12082 merged
775. [x] #12066 merged
776. [x] #12056 merged
777. [x] #12042 closed
778. [x] #12033 closed
779. [x] #12023 merged
780. [x] #12012 closed
781. [x] #11993 merged
782. [x] #11980 closed
783. [x] #11946 merged
784. [x] #11945 closed
785. [x] #11929 closed
786. [x] #11928 closed
787. [x] #11924 closed
788. [x] #11919 closed
789. [x] #11918 closed
790. [x] #11910 closed
791. [x] #11898 merged
792. [x] #11897 merged
793. [x] #11886 closed
794. [x] #11885 closed
795. [x] #11883 merged
796. [x] #11882 merged
797. [x] #11875 merged
798. [x] #11872 closed
799. [x] #11870 merged
800. [x] #11851 merged
801. [x] #11848 merged
802. [x] #11842 closed
803. [x] #11834 merged
804. [x] #11827 closed
805. [x] #11826 merged
806. [x] #11825 closed
807. [x] #11823 merged
808. [x] #11822 merged
809. [x] #11820 closed
810. [x] #11809 merged
811. [x] #11805 closed
812. [x] #11802 closed
813. [x] #11795 closed
814. [x] #11785 merged
815. [x] #11784 merged
816. [x] #11782 merged
817. [x] #11773 merged
818. [x] #11771 merged
819. [x] #11760 closed
820. [x] #11757 merged
821. [x] #11752 closed
822. [x] #11744 merged
823. [x] #11727 closed
824. [x] #11725 closed
825. [x] #11712 closed
826. [x] #11699 merged
827. [x] #11697 closed
828. [x] #11695 merged
829. [x] #11671 closed
830. [x] #11667 merged
831. [x] #11655 merged
832. [x] #11653 closed
833. [x] #11652 closed
834. [x] #11648 closed
835. [x] #11622 closed
836. [x] #11608 closed
837. [x] #11607 closed
838. [x] #11589 merged
839. [x] #11581 merged
840. [x] #11580 merged
841. [x] #11574 closed
842. [x] #11567 closed
843. [x] #11566 closed
844. [x] #11556 closed
845. [x] #11552 merged
846. [x] #11547 closed
847. [x] #11509 merged
848. [x] #11479 merged
849. [x] #11475 merged
850. [x] #11463 closed
851. [x] #11433 closed
852. [x] #11429 merged
853. [x] #11418 closed
854. [x] #11385 merged
855. [x] #11368 closed
856. [x] #11290 closed
857. [x] #11263 merged
858. [x] #11250 merged
859. [x] #11240 merged
860. [x] #11228 merged
861. [x] #11217 closed
862. [x] #11213 merged
863. [x] #11211 closed
864. [x] #11205 merged
865. [x] #11202 merged
866. [x] #11201 merged
867. [x] #11199 closed
868. [x] #11193 closed
869. [x] #11174 closed
870. [x] #11167 closed
871. [x] #11164 closed
872. [x] #11153 closed
873. [x] #11133 merged
874. [x] #11115 closed
875. [x] #11113 merged
876. [x] #11092 closed
877. [x] #10860 merged
878. [x] #10800 merged
879. [x] #10690 closed
880. [x] #10662 closed
881. [x] #10631 closed
882. [x] #10624 merged
883. [x] #10607 merged
884. [x] #10531 merged
885. [x] #10474 closed
886. [x] #10466 merged
887. [x] #10460 closed
888. [x] #10431 closed
889. [x] #10387 closed
890. [x] #10382 closed
891. [x] #10370 closed
892. [x] #10343 merged
893. [x] #10271 closed
894. [x] #10234 merged
895. [x] #10180 closed
896. [x] #10137 closed
897. [x] #10102 closed
898. [x] #10082 closed
899. [x] #10017 merged
900. [x] #9982 closed
901. [x] #9946 merged
902. [x] #9927 merged
903. [x] #9917 closed
904. [x] #9914 merged
905. [x] #9902 closed
906. [x] #9896 merged
907. [x] #9880 merged
908. [x] #9688 merged
909. [x] #9686 closed
910. [x] #9649 merged
911. [x] #9645 merged
912. [x] #9619 closed
913. [x] #9610 closed
914. [x] #9577 closed
915. [x] #9535 merged
916. [x] #9416 closed by maintainer (how-to-use, not an algorithm)
917. [x] #9414 merged
918. [x] #9388 merged

## Closed totals

| Script | PRs closed |
| --- | ---: |
| `close_pull_requests_with_awaiting_changes.sh` | 0 |
| `close_pull_requests_with_failing_tests.sh` | 94 |
| `close_pull_requests_with_require_descriptive_names.sh` | 14 |
| `close_pull_requests_with_require_tests.sh` | 24 |
| `close_pull_requests_with_require_type_hints.sh` | 15 |
| **Total** | **147** |

## Open pull requests grouped by algorithm directory

_Generated by examining the changed files of every open PR. Each PR appears in exactly one grouping. PRs touching more than one algorithm directory are under "Modifies multiple algorithm directories"; PRs touching only non-algorithm paths (e.g. `.github/`, `scripts/`, `docs/`) are under "Modifies no algorithm directories"; PRs that touch `DIRECTORY.md` without touching an algorithm directory are under "Modifies DIRECTORY.md"._

Total open pull requests: 770

audio_filters:
1. [x] #14979 merged

backtracking:
1. [x] #10102 closed
2. [x] #10662 closed
3. [x] #11589 merged
4. [x] #11980 closed
5. [x] #13106 closed
6. [x] #13198 closed
7. [x] #13288 merged
8. [x] #14364 closed
9. [x] #14504 closed
10. [x] #14568 merged
11. [x] #14890 merged
12. [x] #15001 closed
13. [x] #15042 closed
14. [x] #15055 merged
15. [x] #15090 merged

bit_manipulation:
1. [x] #9902 closed
2. [x] #10370 closed
3. [x] #11418 closed
4. [x] #11827 closed
5. [x] #12033 closed
6. [x] #12042 closed
7. [x] #13018 merged
8. [x] #13121 closed
9. [x] #13129 closed
10. [x] #13132 closed
11. [x] #13157 merged
12. [x] #13216 closed
13. [x] #13483 merged
14. [x] #13484 merged
15. [x] #13550 merged
16. [x] #13737 closed
17. [x] #13938 closed
18. [x] #13984 closed
19. [x] #14495 merged
20. [x] #14574 closed

blockchain:
1. [x] #11699 merged
2. [x] #11945 closed
3. [x] #11946 merged
4. [x] #12792 merged
5. [x] #12999 merged
6. [x] #13114 merged
7. [x] #13296 closed
8. [x] #13753 merged
9. [x] #14237 merged

boolean_algebra:
1. [x] #9917 closed
2. [x] #13236 merged
3. [x] #13701 closed
4. [x] #13807 closed
5. [x] #14792 closed

cellular_automata:
1. [x] #12109 closed by maintainer (superseded by #13146)
2. [x] #13146 merged
3. [x] #13827 merged

ciphers:
1. [x] #11785 merged
2. [x] #12123 merged
3. [x] #12319 closed
4. [x] #12541 closed
5. [x] #13100 closed
6. [x] #13102 merged
7. [x] #13147 merged
8. [x] #13217 merged
9. [x] #13421 closed
10. [x] #13452 closed
11. [x] #13825 closed
12. [x] #13966 closed
13. [x] #14414 merged
14. [x] #14753 merged
15. [x] #15108 merged

compression:
1. [x] #11842 closed
2. [x] #12392 closed

computer_vision:
1. [x] #11429 merged
2. [x] #12207 closed
3. [x] #13334 merged
4. [x] #13363 closed
5. [x] #13538 closed
6. [x] #13597 closed
7. [x] #14143 merged
8. [x] #14233 merged
9. [x] #14668 closed
10. [x] #14904 merged

control_algorithms:
1. [x] #12648 closed

conversions:
1. [x] #11113 merged
2. [x] #11115 closed
3. [x] #11213 merged
4. [x] #11919 closed
5. [x] #12209 merged
6. [x] #12210 merged
7. [x] #13295 closed
8. [x] #13593 closed
9. [x] #13634 merged
10. [x] #13744 closed
11. [x] #13808 closed
12. [x] #13826 merged
13. [x] #13831 merged
14. [x] #14041 merged
15. [x] #14079 closed
16. [x] #14570 closed
17. [x] #14571 closed
18. [x] #14635 merged
19. [x] #14871 closed
20. [x] #14872 merged
21. [x] #14879 merged

cpu_scheduling_algorithms:
1. [x] #12140 closed

data_compression:
1. [x] #14555 merged
2. [x] #14743 merged
3. [x] #14819 closed
4. [x] #14873 closed

data_structures:
1. [x] #9414 merged
2. [x] #9645 merged
3. [x] #9686 closed
4. [x] #9880 merged
5. [x] #9946 merged
6. [x] #10474 closed
7. [x] #10531 merged
8. [x] #10607 merged
9. [x] #11133 merged
10. [x] #11199 closed
11. [x] #11385 merged
12. [x] #11547 closed
13. [x] #11566 closed
14. [x] #11607 closed
15. [x] #11695 merged
16. [x] #11822 merged
17. [x] #11870 merged
18. [x] #11886 closed
19. [x] #11918 closed
20. [x] #11924 closed
21. [x] #12186 merged
22. [x] #12271 merged
23. [x] #12326 closed
24. [x] #12498 closed
25. [x] #12522 closed
26. [x] #13019 closed
27. [x] #13093 closed
28. [x] #13112 closed
29. [x] #13164 closed
30. [x] #13191 closed
31. [x] #13192 closed
32. [x] #13322 merged
33. [x] #13325 merged
34. [x] #13327 closed
35. [x] #13345 closed
36. [x] #13369 merged
37. [x] #13370 merged
38. [x] #13419 closed
39. [x] #13468 closed
40. [x] #13502 closed
41. [x] #13589 merged
42. [x] #13619 merged
43. [x] #13661 closed
44. [x] #13699 merged
45. [x] #13802 closed
46. [x] #14008 closed
47. [x] #14009 merged
48. [x] #14015 closed
49. [x] #14026 closed
50. [x] #14048 closed
51. [x] #14186 merged
52. [x] #14410 closed
53. [x] #14492 closed
54. [x] #14527 closed
55. [x] #14712 closed
56. [x] #14728 merged
57. [x] #14775 merged

digital_image_processing:
1. [x] #12275 closed
2. [x] #13141 closed
3. [x] #13149 merged

divide_and_conquer:
1. [x] #9688 merged
2. [x] #12552 merged
3. [x] #13300 closed
4. [x] #13519 closed
5. [x] #13738 closed
6. [x] #14095 merged
7. [x] #14363 closed
8. [x] #14925 merged

dynamic_programming:
1. [x] #10382 closed
2. [x] #11697 closed
3. [x] #11712 closed
4. [x] #11771 merged
5. [x] #12066 merged
6. [x] #13361 closed
7. [x] #13378 closed
8. [x] #13395 closed
9. [x] #13471 closed
10. [x] #13640 closed
11. [x] #13824 closed
12. [x] #13973 closed
13. [x] #14440 closed
14. [x] #14472 closed
15. [x] #14525 closed
16. [x] #14526 closed
17. [x] #14702 closed
18. [x] #14856 merged

electronics:
1. [x] #9535 merged
2. [x] #9649 merged
3. [x] #11727 closed
4. [x] #12356 closed
5. [x] #14031 merged
6. [x] #14275 merged

financial:
1. [x] #11368 closed
2. [x] #11826 merged
3. [x] #11851 merged
4. [x] #12357 merged
5. [x] #12358 merged
6. [x] #13888 closed
7. [x] #14506 merged
8. [x] #15051 merged

fractals:
1. [x] #12091 merged

full_wave_rectifier:
1. [x] #9896 merged

genetic_algorithm:
1. [x] #9577 closed
2. [x] #13234 closed
3. [x] #13645 closed
4. [x] #13647 closed

geodesy:
1. [x] #11648 closed
2. [x] #14351 merged
3. [x] #15056 merged

geometry:
1. [x] #11201 merged
2. [x] #11205 merged
3. [x] #12118 merged
4. [x] #12980 closed
5. [x] #13447 merged
6. [x] #13690 merged
7. [x] #13969 closed
8. [x] #14360 closed
9. [x] #15165 merged

graphics:
1. [x] #13113 closed
2. [x] #13750 closed
3. [x] #13751 merged
4. [x] #13906 merged
5. [x] #13909 closed
6. [x] #14029 merged

graphs:
1. [x] #11757 merged
2. [x] #11820 closed
3. [x] #11823 merged
4. [x] #11875 merged
5. [x] #11883 merged
6. [x] #11897 merged
7. [x] #11898 merged
8. [x] #12056 merged
9. [x] #12125 merged
10. [x] #12281 closed
11. [x] #12287 closed
12. [x] #12526 closed
13. [x] #12559 closed
14. [x] #12616 closed
15. [x] #12790 closed
16. [x] #12881 merged
17. [x] #13023 closed
18. [x] #13036 merged
19. [x] #13249 closed
20. [x] #14718 closed
21. [x] #14729 closed
22. [x] #14894 merged
23. [x] #15024 closed
24. [x] #15072 merged
25. [x] #15074 closed
26. [x] #15102 closed
27. [x] #15107 merged

greedy_methods:
1. [x] #10860 merged
2. [x] #11581 merged
3. [x] #11667 merged
4. [x] #14264 closed
5. [x] #14436 closed

half_wave_rectifier:
1. [x] #9388 merged

hashes:
1. [x] #10017 merged
2. [x] #11652 closed
3. [x] #13814 closed
4. [x] #14023 closed
5. [x] #14035 merged
6. [x] #14036 closed
7. [x] #14037 closed
8. [x] #14415 closed
9. [x] #14560 merged
10. [x] #14777 merged
11. [x] #14814 merged

haversine_calculation:
1. [x] #13119 closed

height_tree:
1. [x] #13172 closed

knapsack:
1. [x] #10180 closed
2. [x] #12896 closed

linear_algebra:
1. [x] #12876 merged
2. [x] #14647 closed
3. [x] #14826 closed
4. [x] #14827 closed
5. [x] #15044 merged

linear_programming:
1. [x] #14607 merged
2. [x] #14613 closed
3. [x] #15047 closed

machine_learning:
1. [x] #9610 closed
2. [x] #9619 closed
3. [x] #10387 closed
4. [x] #10800 merged
5. [x] #11240 merged
6. [x] #11250 merged
7. [x] #11263 merged
8. [x] #11567 closed
9. [x] #11622 closed
10. [x] #11671 closed
11. [x] #11802 closed
12. [x] #12111 closed
13. [x] #12246 merged
14. [x] #12262 merged
15. [x] #12668 merged
16. [x] #12700 closed
17. [x] #12748 closed
18. [x] #12756 merged
19. [x] #12767 merged
20. [x] #12784 closed
21. [x] #12976 closed
22. [x] #13026 merged
23. [x] #13085 merged
24. [x] #13101 closed
25. [x] #13105 closed
26. [x] #13118 closed
27. [x] #13208 closed
28. [x] #13221 merged
29. [x] #13270 closed
30. [x] #13271 closed
31. [x] #13273 closed
32. [x] #13337 merged
33. [x] #13355 merged
34. [x] #13357 closed
35. [x] #13402 merged
36. [x] #13410 closed
37. [x] #13510 merged
38. [x] #13522 closed
39. [x] #13555 closed
40. [x] #13615 merged
41. [x] #13635 closed
42. [x] #13637 merged
43. [x] #14016 closed
44. [x] #14021 closed
45. [x] #14065 closed
46. [x] #14224 closed
47. [x] #14579 closed
48. [x] #14608 closed
49. [x] #14637 merged
50. [x] #14665 merged
51. [x] #14733 merged
52. [x] #14740 closed
53. [x] #14800 merged
54. [x] #14851 merged
55. [x] #14853 closed
56. [x] #14858 merged
57. [x] #14874 closed
58. [x] #14923 closed

maths:
1. [x] #9927 merged
2. [x] #10343 merged
3. [x] #10466 merged
4. [x] #11202 merged
5. [x] #11211 closed
6. [x] #11463 closed
7. [x] #11509 merged
8. [x] #11773 merged
9. [x] #11784 merged
10. [x] #11834 merged
11. [x] #11848 merged
12. [x] #11929 closed
13. [x] #12104 merged
14. [x] #12285 merged
15. [x] #12344 merged
16. [x] #12703 closed
17. [x] #12757 merged
18. [x] #12829 closed
19. [x] #12830 merged
20. [x] #12852 closed
21. [x] #12875 merged
22. [x] #12974 merged
23. [x] #13017 merged
24. [x] #13055 merged
25. [x] #13063 merged
26. [x] #13110 closed
27. [x] #13131 closed
28. [x] #13176 closed
29. [x] #13251 closed
30. [x] #13252 closed
31. [x] #13360 closed
32. [x] #13409 merged
33. [x] #13426 merged
34. [x] #13527 merged
35. [x] #13528 merged
36. [x] #13529 merged
37. [x] #13535 merged
38. [x] #13554 closed
39. [x] #13588 merged
40. [x] #13603 merged
41. [x] #13623 merged
42. [x] #13631 merged
43. [x] #13648 closed
44. [x] #13733 closed
45. [x] #13749 closed
46. [x] #13815 merged
47. [x] #13818 closed
48. [x] #13835 closed
49. [x] #13850 merged
50. [x] #13862 merged
51. [x] #13882 closed
52. [x] #13950 closed
53. [x] #13990 closed
54. [x] #13991 closed
55. [x] #13993 closed
56. [x] #13994 closed
57. [x] #14001 merged
58. [x] #14052 closed
59. [x] #14059 merged
60. [x] #14089 merged
61. [x] #14099 closed
62. [x] #14134 closed
63. [x] #14142 closed
64. [x] #14153 closed
65. [x] #14158 merged
66. [x] #14190 closed
67. [x] #14202 closed
68. [x] #14216 closed
69. [x] #14229 merged
70. [x] #14239 closed
71. [x] #14409 closed
72. [x] #14539 closed
73. [x] #14554 merged
74. [x] #14562 merged
75. [x] #14563 closed
76. [x] #14602 merged
77. [x] #14633 merged
78. [x] #14634 merged
79. [x] #14652 merged
80. [x] #14713 closed
81. [x] #14724 closed
82. [x] #14736 closed
83. [x] #14742 merged
84. [x] #14767 merged
85. [x] #14768 merged
86. [x] #14769 merged
87. [x] #14779 merged
88. [x] #14812 closed
89. [x] #14845 merged
90. [x] #14850 merged
91. [x] #14864 closed
92. [x] #14876 merged
93. [x] #14889 merged
94. [x] #14895 merged
95. [x] #14988 merged
96. [x] #14995 merged
97. [x] #14997 closed
98. [x] #15014 merged
99. [x] #15019 closed
100. [x] #15038 merged
101. [x] #15039 closed
102. [x] #15048 closed
103. [x] #15084 merged
104. [x] #15103 closed
105. [x] #15144 closed

matrix:
1. [x] #12023 merged
2. [x] #12555 merged
3. [x] #12691 closed
4. [x] #12940 merged
5. [x] #13022 merged
6. [x] #13187 closed
7. [x] #13482 closed
8. [x] #13716 merged
9. [x] #13934 closed
10. [x] #13987 merged
11. [x] #14821 merged
12. [x] #15045 closed

networking_flow:
1. [x] #13128 merged

neural_network:
1. [x] #12082 merged
2. [x] #12214 merged
3. [x] #12421 closed
4. [x] #13133 merged
5. [x] #13514 closed
6. [x] #13680 merged
7. [x] #13681 merged
8. [x] #13718 merged

operating_system:
1. [x] #11574 closed

os_py:
1. [x] #13924 closed

other:
1. [x] #11882 merged
2. [x] #12413 merged
3. [x] #12540 closed
4. [x] #12834 closed
5. [x] #13183 merged
6. [x] #13462 closed
7. [x] #13907 closed

physics:
1. [x] #9914 merged
2. [x] #11580 merged
3. [x] #11608 closed
4. [x] #11744 merged
5. [x] #12129 merged
6. [x] #12333 merged
7. [x] #12335 merged
8. [x] #12686 merged
9. [x] #13002 closed
10. [x] #13312 closed
11. [x] #13323 closed
12. [x] #13341 merged
13. [x] #13342 merged
14. [x] #13343 merged
15. [x] #13487 closed
16. [x] #14030 closed
17. [x] #14357 merged
18. [x] #14432 merged
19. [x] #14437 merged
20. [x] #14623 merged
21. [x] #14787 closed
22. [x] #15012 merged

project_euler:
1. [x] #10082 closed
2. [x] #11164 closed
3. [x] #11167 closed
4. [x] #11174 closed
5. [x] #11433 closed
6. [x] #12684 merged
7. [x] #12690 merged
8. [x] #12694 merged
9. [x] #12701 merged
10. [x] #12706 merged
11. [x] #12763 closed
12. [x] #12764 merged
13. [x] #12777 closed
14. [x] #13013 closed
15. [x] #13475 merged
16. [x] #13531 closed
17. [x] #13639 closed
18. [x] #14694 closed
19. [x] #14798 closed
20. [x] #14801 closed
21. [x] #14990 closed

quantum:
1. [x] #10624 merged
2. [x] #12317 merged
3. [x] #13033 closed

recursions:
1. [x] #12141 merged

scheduling:
1. [x] #13896 merged

searches:
1. [x] #10690 closed
2. [x] #11825 closed
3. [x] #12594 closed
4. [x] #13609 closed
5. [x] #13836 closed
6. [x] #13841 closed
7. [x] #13869 closed
8. [x] #13891 merged
9. [x] #13900 closed
10. [x] #13901 closed
11. [x] #13954 merged
12. [x] #13955 closed
13. [x] #14051 closed
14. [x] #14056 closed
15. [x] #14159 closed
16. [x] #14456 closed
17. [x] #14523 closed
18. [x] #14581 closed
19. [x] #14622 closed
20. [x] #14626 closed
21. [x] #14627 closed
22. [x] #14641 merged
23. [x] #14657 closed
24. [x] #14708 closed
25. [x] #14802 closed
26. [x] #14806 closed
27. [x] #14807 merged
28. [x] #14862 closed
29. [x] #15005 closed
30. [x] #15086 closed
31. [x] #15091 merged
32. [x] #15092 merged
33. [x] #15101 closed

sorts:
1. [x] #10271 closed
2. [x] #11290 closed
3. [x] #11552 merged
4. [x] #11725 closed
5. [x] #11752 closed
6. [x] #11809 merged
7. [x] #11910 closed
8. [x] #11993 merged
9. [x] #12012 closed
10. [x] #12100 closed
11. [x] #12295 merged
12. [x] #12355 closed
13. [x] #12593 closed
14. [x] #12601 merged
15. [x] #12696 closed
16. [x] #13219 merged
17. [x] #13316 merged
18. [x] #13424 merged
19. [x] #13534 merged
20. [x] #13551 closed
21. [x] #13641 closed
22. [x] #13688 merged
23. [x] #13758 closed
24. [x] #13911 closed
25. [x] #13960 merged
26. [x] #13962 closed
27. [x] #13963 closed
28. [x] #13972 merged
29. [x] #13977 closed
30. [x] #14151 closed
31. [x] #14398 merged
32. [x] #14460 merged
33. [x] #14482 merged
34. [x] #14609 closed
35. [x] #14610 closed
36. [x] #14701 merged
37. [x] #14738 closed
38. [x] #14746 closed
39. [x] #14759 closed
40. [x] #14785 closed
41. [x] #14786 merged
42. [x] #14805 merged
43. [x] #14823 closed
44. [x] #14829 closed
45. [x] #14861 closed
46. [x] #14868 closed
47. [x] #14875 merged
48. [x] #14882 closed
49. [x] #14883 closed
50. [x] #14899 closed
51. [x] #14914 closed
52. [x] #14920 closed
53. [x] #14939 merged
54. [x] #14967 closed
55. [x] #14991 merged
56. [x] #15003 merged
57. [x] #15009 merged
58. [x] #15011 closed
59. [x] #15023 merged
60. [x] #15026 closed
61. [x] #15036 closed
62. [x] #15040 closed
63. [x] #15041 closed
64. [x] #15050 closed
65. [x] #15054 closed
66. [x] #15063 merged
67. [x] #15117 merged

strings:
1. [x] #10234 merged
2. [x] #10460 closed
3. [x] #11092 closed
4. [x] #11217 closed
5. [x] #11475 merged
6. [x] #11479 merged
7. [x] #11556 closed
8. [x] #11782 merged
9. [x] #12133 merged
10. [x] #12188 closed
11. [x] #12206 closed
12. [x] #12311 merged
13. [x] #12839 closed
14. [x] #12895 closed
15. [x] #13014 merged
16. [x] #13039 closed
17. [x] #13297 closed
18. [x] #13371 closed
19. [x] #13601 closed
20. [x] #13606 closed
21. [x] #13694 closed
22. [x] #13707 closed
23. [x] #13941 closed
24. [x] #13947 closed
25. [x] #14058 closed
26. [x] #14188 closed
27. [x] #14219 closed
28. [x] #14630 merged
29. [x] #14654 merged
30. [x] #14655 closed
31. [x] #14673 closed
32. [x] #14685 merged
33. [x] #14721 closed
34. [x] #14751 closed
35. [x] #14770 merged
36. [x] #14832 closed
37. [x] #14833 merged
38. [x] #14843 closed
39. [x] #14848 merged
40. [x] #14907 merged
41. [x] #14909 closed
42. [x] #15010 closed
43. [x] #15043 closed
44. [x] #15046 closed
45. [x] #15053 closed

tests:
1. [x] #13231 merged

triage:
1. [x] #14611 closed

web_programming:
1. [x] #11193 closed
2. [x] #11655 merged
3. [x] #13000 merged
4. [x] #13016 merged
5. [x] #13797 merged

Modifies multiple algorithm directories:
1. [x] #10431 closed
2. [x] #11153 closed
3. [x] #11228 merged
4. [x] #11653 closed
5. [x] #11760 closed
6. [x] #11805 closed
7. [x] #11872 closed
8. [x] #11885 closed
9. [x] #12171 closed
10. [x] #12259 closed
11. [x] #12263 closed
12. [x] #12412 closed
13. [x] #12645 closed
14. [x] #12723 closed
15. [x] #12762 closed
16. [x] #12942 closed
17. [x] #12989 closed
18. [x] #13007 closed
19. [x] #13012 closed
20. [x] #13015 closed
21. [x] #13071 closed
22. [x] #13090 closed
23. [x] #13094 closed
24. [x] #13136 closed
25. [x] #13162 closed
26. [x] #13364 closed
27. [x] #13418 closed
28. [x] #13469 closed
29. [x] #13734 closed
30. [x] #13754 closed
31. [x] #13791 closed
32. [x] #13892 closed
33. [x] #13894 closed
34. [x] #13903 merged
35. [x] #13915 closed
36. [x] #14038 merged
37. [x] #14192 closed
38. [x] #14197 closed
39. [x] #14260 merged
40. [x] #14262 merged
41. [x] #14277 closed
42. [x] #14278 closed
43. [x] #14284 closed
44. [x] #14291 merged
45. [x] #14307 merged
46. [x] #14346 merged
47. [x] #14477 closed
48. [x] #14714 closed
49. [x] #14838 closed
50. [x] #14986 merged
51. [x] #14987 closed
52. [x] #15076 merged
53. [x] #15147 closed

Modifies no algorithm directories:
1. [x] #9982 closed
2. [x] #10137 closed
3. [x] #10631 closed
4. [x] #11795 closed
5. [x] #11928 closed
6. [x] #12575 closed
7. [x] #12894 merged
8. [x] #12998 closed
9. [x] #13038 closed
10. [x] #13050 closed
11. [x] #13135 closed
12. [x] #13142 closed
13. [x] #13178 closed
14. [x] #13194 closed
15. [x] #13330 closed
16. [x] #13472 closed
17. [x] #13586 closed
18. [x] #13604 closed
19. [x] #13726 closed
20. [x] #13729 closed
21. [x] #13806 closed
22. [x] #13830 closed
23. [x] #13843 closed
24. [x] #13847 closed
25. [x] #13873 closed
26. [x] #13880 closed
27. [x] #13884 closed
28. [x] #13964 closed
29. [x] #14032 closed
30. [x] #14221 closed
31. [x] #14663 merged
32. [x] #14878 closed
33. [x] #15105 merged
34. [x] #15142 closed
35. [x] #15180 merged
36. [x] #15182 merged

Modifies DIRECTORY.md:
1. [x] #13239 closed

## Creates a new root directory

_As requested by @cclauss on #15184: open PRs that add a **new top-level directory** to the repository (a directory that does not exist on `master`). These need a maintainer decision on whether the new category belongs in the collection before the code review matters, so they are grouped separately from the by-directory listing above. Each PR was confirmed to add at least one file under a top-level path that is absent from `master`._

Total PRs that create a new root directory: 13

compression:
1. [x] #11842 closed
2. [x] #12392 closed

control_algorithms:
1. [x] #12648 closed

cpu_scheduling_algorithms:
1. [x] #12140 closed

full_wave_rectifier:
1. [x] #9896 merged

half_wave_rectifier:
1. [x] #9388 merged

haversine_calculation:
1. [x] #13119 closed

height_tree:
1. [x] #13172 closed

operating_system:
1. [x] #11574 closed

os_py:
1. [x] #13924 closed

recursions:
1. [x] #12141 merged

tests:
1. [x] #13231 merged

triage:
1. [x] #14611 closed

## Open issues

Snapshot taken: **2026-09-06** -- **144** open issues (**21** `bug`, **82** `enhancement`, **23** `awaiting triage`, **2** `help wanted`; issues can carry more than one label).

Same notation as the PR tracker: `<index>. [ ] #<id> <labels>`, checked off (`[x]`) once the issue is closed or resolved. See **[Triage recommendations](#triage-recommendations)** below for a first pass at which of these we can close.

1. [x] #15199 closed
2. [ ] #15187 no labels
3. [x] #15085 closed
4. [ ] #15081 no labels
5. [x] #15075 closed
6. [x] #15071 closed
7. [x] #15002 closed
8. [x] #14998 closed
9. [x] #14971 closed
10. [x] #14970 closed
11. [x] #14950 closed
12. [x] #14898 closed
13. [x] #14887 closed
14. [x] #14886 closed
15. [x] #14885 closed
16. [x] #14881 closed
17. [x] #14866 closed
18. [x] #14844 closed
19. [x] #14834 closed
20. [x] #14817 closed
21. [x] #14813 closed
22. [x] #14773 closed
23. [x] #14675 closed
24. [x] #14649 closed
25. [x] #14606 closed
26. [x] #14593 closed
27. [x] #14592 closed
28. [x] #14591 closed
29. [x] #14584 closed
30. [x] #14577 closed
31. [x] #14500 closed
32. [x] #14479 closed
33. [x] #14464 closed
34. [x] #14425 closed
35. [x] #14084 closed
36. [x] #13999 closed
37. [x] #13919 closed
38. [x] #13918 closed
39. [x] #13917 closed
40. [x] #13905 closed
41. [x] #13904 closed
42. [x] #13861 closed
43. [x] #13845 closed
44. [x] #13844 closed
45. [x] #13840 closed
46. [x] #13760 closed
47. [x] #13662 closed
48. [x] #13656 closed
49. [x] #13643 closed
50. [x] #13612 closed
51. [x] #13569 closed
52. [x] #13546 closed
53. [x] #13537 closed
54. [x] #13516 closed
55. [ ] #13513 enhancement
56. [x] #13509 closed
57. [x] #13508 closed
58. [x] #13501 closed
59. [x] #13499 closed
60. [x] #13488 closed
61. [x] #13445 closed
62. [x] #13432 closed
63. [x] #13400 closed
64. [x] #13396 closed
65. [x] #13379 closed
66. [x] #13372 closed
67. [x] #13358 closed
68. [x] #13326 closed
69. [x] #13311 closed
70. [x] #13304 closed
71. [x] #13235 closed
72. [x] #13226 closed
73. [x] #13205 closed
74. [x] #13203 closed
75. [x] #13171 closed
76. [ ] #13116 enhancement
77. [x] #13031 closed
78. [x] #13029 closed
79. [x] #13010 closed
80. [x] #13008 closed
81. [x] #12987 closed
82. [x] #12970 closed
83. [x] #12949 closed
84. [x] #12943 closed
85. [x] #12939 closed
86. [x] #12867 closed
87. [x] #12826 closed
88. [x] #12775 closed
89. [x] #12714 closed
90. [x] #12622 closed
91. [x] #12569 closed
92. [x] #12513 closed
93. [x] #12496 closed
94. [x] #12495 closed
95. [x] #12322 closed
96. [x] #12321 closed
97. [x] #12318 closed
98. [x] #12306 closed
99. [x] #12233 closed
100. [x] #12218 closed
101. [x] #12192 closed
102. [x] #12142 closed
103. [x] #12128 closed
104. [x] #12127 closed
105. [x] #12124 closed
106. [x] #12108 closed
107. [x] #12107 closed
108. [x] #12069 closed
109. [x] #12064 closed
110. [x] #12043 closed
111. [x] #11972 closed
112. [x] #11947 closed
113. [x] #11938 closed
114. [x] #11894 closed
115. [x] #11871 closed
116. [x] #11844 closed
117. [x] #11841 closed
118. [x] #11837 closed
119. [x] #11812 closed
120. [x] #11756 closed
121. [x] #11578 closed
122. [x] #11534 closed
123. [x] #11517 closed
124. [x] #11316 closed
125. [x] #11308 closed
126. [x] #11225 closed
127. [x] #10941 closed
128. [x] #10837 closed
129. [x] #10713 closed
130. [x] #10703 closed
131. [x] #10634 closed
132. [x] #10563 closed
133. [x] #8990 closed
134. [x] #8847 closed
135. [x] #8818 closed
136. [x] #8785 closed
137. [x] #8780 closed
138. [x] #8083 closed
139. [x] #8070 closed
140. [x] #8067 closed
141. [x] #7968 closed
142. [x] #7854 closed
143. [ ] #6252 no labels
144. [x] #6216 closed

### Triage recommendations

A first pass at *which open issues we can close*, ordered by confidence. Grouped so a maintainer can act on a whole bucket at once. I verified each claim against the current `master` tree before listing it; where a claim depends on something I can't see (e.g. a rebuilt container), it's marked **verify**.

**A. Close now — not a real issue / spam**

- **#15002 "Sin gravedad"** — spam. Body is an advertising link to an adult cam site, reports "Python 5.0", and attaches a video. No algorithmic content. Close and, if possible, report the author.

**B. Close now — obsolete (target no longer in the tree)**

- **#13226 "Inconsistent behavior for missing values in `coordinate_compression.py`"** — the file `data_structures/coordinate_compression.py` no longer exists on `master`; the module the bug is about has been removed. Nothing left to fix.

**C. Close as fixed/duplicate once the linked PR merges**

- **#15085 "[BUG] `jump_search` raises `IndexError` for empty list input"** — still reproduces on `master`, but a fix is already in the review queue: **#14807** (canonical `jump_search([]) -> -1` guard + doctest, which I've approved) with **#15101** as a duplicate of it. Close #15085 as fixed the moment #14807 merges; no separate fix PR is needed.

**D. Stale feature requests with no implementation ("please add algorithm X", ≥1 year, no PR)**

These are standing "it would be nice to have …" requests that never produced a PR. They're not bugs and nothing in the tree depends on them; leaving them open makes the issue list look busier than the actual work. Recommend closing with a friendly "we'd still welcome a PR for this — closing to keep the tracker actionable; comment and we'll reopen" note. Candidates (all `enhancement`, 600–1500 days old, zero linked PR):

- #8067 XGBoost classification/regression · #8083 caching algorithms · #11517 sliding window · #11578 genetic algorithm for function optimization · #11837 LZ78 compression · #11844 transposition cipher · #11938 travelling salesman · #11947 wildcard matching with FFT · #11972 Grover's search (Qiskit) · #12043 Edmonds' Blossom · #12064 elliptic-curve crypto · #12069 LSTM · #12107 hollow-diamond pattern · #12108 ridge regression · #12124 adaptive/"stalin" merge sort · #12128 TSP in graphs · #12218 set-matrix-zero · #12318 Shor's algorithm · #12321 ART1 net · #12322 RBFNN · #12496 "addition of AI algorithms" · #12569 collision detection · #12622 PID/ADRC · #12939 transitive closure

**E. Likely already resolved — verify then close**

- **#10941 "Container build failed in codespaces"** and **#11812 "DevContainer setup fails"** — a working `.devcontainer/` (Dockerfile + `devcontainer.json` + `post_install`) is present and current on `master`; both reports predate it. **Verify** a fresh Codespace build is green, then close.
- **#11841 "computer_vision README.md link not working"** and **#11225 "Misformatted/linked wiki entry in python sorting"** — small doc-link reports; **verify** the referenced link resolves today and close if fixed.

**F. Keep open — real, reproducible, and good contributor material**

Confirmed still-live on `master` and each is a tidy, well-scoped fix (good `good first issue` candidates), so these should stay open:

- #14950 `radix_sort` doesn't raise on negative input (verified: silently mis-sorts) · #14898 `cyclic_sort` infinite loop on invalid input · #14649 `split` wrong result for multi-character separators · #15071 Kahn's topo-sort `pop(0)`/sparse-id bug · #15075 `matrix_exponentiation` self-referential annotation `NameError` · #14584 `run_simplex()` returns `{}` instead of raising · #12192 topological sort returns reversed list · #12233 avoid `log(0)` in KL divergence.

I can take a second pass through the remaining `awaiting triage` items (relabel or route) once the buckets above are actioned — just say the word.

## Automated statistics

_Generated automatically by `scripts/hacktoberfest_prep_update.py` on 2026-10-01 (UTC)._

- **Open issues:** 10
- **Open pull requests:** 0
- **Open PRs labelled `awaiting reviews`:** 0
- **Days until Hacktoberfest (2026-10-01):** 0
- **Issues to close per day to clear the backlog:** Hacktoberfest has started
- **Pull requests to merge or close per day to clear the backlog:** Hacktoberfest has started

**Top three directories to work on** (most open pull requests labelled `awaiting reviews`):

_No open `awaiting reviews` pull requests found._

