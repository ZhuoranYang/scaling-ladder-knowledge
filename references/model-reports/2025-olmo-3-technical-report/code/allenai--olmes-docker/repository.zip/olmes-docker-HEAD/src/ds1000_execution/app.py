# Based on: https://github.com/xlang-ai/DS-1000/blob/main/test_ds1000.py

import json

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from execution import check_correctness


app = FastAPI(title="DS1000 Execution Service", version="1.0.0")


class DS1000ExecutionRequest(BaseModel):
    res_id: str
    test: str
    timeout: float = 10.0


class DS1000ExecutionResponse(BaseModel):
    res_id: str
    tested_completion: str
    passed: int
    exec_result: str


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


@app.post("/execute", response_model=DS1000ExecutionResponse)
async def execute_code(request: DS1000ExecutionRequest):
    try:
        result = check_correctness(request.test, timeout=request.timeout)
        passed = 1 if result["passed"] else 0

        return DS1000ExecutionResponse(
            res_id=request.res_id,
            tested_completion=request.test,
            passed=passed,
            exec_result=result["result"],
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Handler for AWS Lambda
def handler(event, context):
    request = DS1000ExecutionRequest(**event)
    response = execute_code(request)
    return json.dumps(response.dict())
