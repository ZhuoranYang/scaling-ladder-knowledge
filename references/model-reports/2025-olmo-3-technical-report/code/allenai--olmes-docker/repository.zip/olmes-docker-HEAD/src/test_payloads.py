import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, Any

sys.path.insert(0, str(Path(__file__).parent))  # Add the src directory to the path so we can import the library

import olmo_docker as od

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def load_sample_payload(payload_path: str) -> Dict[str, Any]:
    """Load a sample payload from JSON file."""
    try:
        with open(payload_path, "r") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load payload from {payload_path}: {e}")
        raise


def test_bcb_with_sample_payload():
    """Test BCB execution environment with sample payload."""
    logger.info("Testing BCB execution environment with sample payload...")

    payload_path = "src/bcb_execution/sample_payloads/payload.json"
    payload = load_sample_payload(payload_path)

    logger.info(f"Loaded BCB payload: task_id={payload.get('task_id', 'unknown')}")

    try:
        with od.create_environment("bcb", auto_start=True) as env:
            logger.info("BCB container started successfully")

            # Execute the sample payload
            result = env.execute_code(
                solution=payload["solution"],
                test=payload["test"],
                res_id=str(payload["res_id"]),
                task_id=payload["task_id"],
                entry_point=payload["entry_point"],
                calibrate=payload.get("calibrate", True),
                no_gt=payload.get("no_gt", True),
                min_time_limit=payload.get("min_time_limit", 1),
                max_as_limit=payload.get("max_as_limit", 30 * 1024),
                max_data_limit=payload.get("max_data_limit", 30 * 1024),
                max_stack_limit=payload.get("max_stack_limit", 10),
                code_prompt=payload.get("code_prompt"),
                timeout=120.0,
            )

            logger.info(f"BCB execution result: {result}")
            passed = result.get("passed", False)

            if passed:
                logger.info("BCB test PASSED")
                return True
            else:
                logger.error(f"BCB test FAILED: {result.get('exec_result', 'Unknown error')}")
                return False

    except Exception as e:
        logger.error(f"BCB test failed with exception: {e}")
        return False


def test_ds1000_with_sample_payload():
    """Test DS1000 execution environment with sample payload."""
    logger.info("Testing DS1000 execution environment with sample payload...")

    payload_path = "src/ds1000_execution/sample_payloads/payload.json"
    payload = load_sample_payload(payload_path)

    logger.info(f"Loaded DS1000 payload: res_id={payload.get('res_id', 'unknown')}")

    try:
        with od.create_environment("ds1000", auto_start=True) as env:
            logger.info("DS1000 container started successfully")

            # Execute the sample payload
            result = env.execute_code(
                solution="",  # DS1000 doesn't separate solution from test
                test=payload["test"],
                entry_point="",  # Not used in DS1000
                res_id=str(payload["res_id"]),
                timeout_seconds=payload.get("timeout", 10.0),
                timeout=180.0,  # Give extra time for complex DS1000 operations
            )

            logger.info(f"DS1000 execution result: {result}")
            passed = result.get("passed", 0) == 1

            if passed:
                logger.info("DS1000 test PASSED")
                return True
            else:
                logger.error(f"DS1000 test FAILED: {result.get('exec_result', 'Unknown error')}")
                return False

    except Exception as e:
        logger.error(f"DS1000 test failed with exception: {e}")
        return False


def test_multipl_with_sample_payloads():
    """Test MultiPL execution environment with multiple language sample payloads."""
    logger.info("Testing MultiPL execution environment with sample payloads...")

    # Test different languages
    test_cases = [
        ("Python", "src/multiple_execution/sample_payloads/payload_python.json"),
        ("Java", "src/multiple_execution/sample_payloads/payload_java.json"),
        ("Rust", "src/multiple_execution/sample_payloads/payload_rust.json"),
    ]

    results = {}

    try:
        with od.create_environment("multipl", auto_start=True) as env:
            logger.info("MultiPL container started successfully")

            for language_name, payload_path in test_cases:
                logger.info(f"Testing {language_name}...")

                try:
                    payload = load_sample_payload(payload_path)
                    logger.info(f"Loaded {language_name} payload: res_id={payload.get('res_id', 'unknown')}")

                    # Execute the sample payload
                    result = env.execute_code(
                        solution=payload["completion"],
                        test=payload["test"],
                        entry_point="",  # Not used in MultiPL
                        res_id=str(payload["res_id"]),
                        language=payload["language"],
                        timeout=120.0,
                    )

                    logger.info(f"{language_name} execution result: {result}")
                    passed = result.get("passed", 0) == 1
                    results[language_name] = passed

                    if passed:
                        logger.info(f"{language_name} test PASSED")
                    else:
                        logger.error(f"{language_name} test FAILED: {result.get('exec_result', 'Unknown error')}")

                except Exception as e:
                    logger.error(f"{language_name} test failed with exception: {e}")
                    results[language_name] = False

                # Small delay between tests
                time.sleep(1)

        # Summary
        passed_count = sum(results.values())
        total_count = len(results)

        logger.info(f"MultiPL results: {passed_count}/{total_count} languages passed")
        for lang, passed in results.items():
            status = "PASSED" if passed else "FAILED"
            logger.info(f"  {lang}: {status}")

        return passed_count > 0  # Return True if at least one language passed

    except Exception as e:
        logger.error(f"MultiPL test failed with exception: {e}")
        return False


def test_additional_multipl_payloads():
    """Test additional MultiPL payloads for more comprehensive coverage."""
    logger.info("Testing additional MultiPL payloads...")

    additional_payloads = [
        "src/multiple_execution/sample_payloads/payload_cpp.json",
        "src/multiple_execution/sample_payloads/payload_js.json",
    ]

    results = {}

    try:
        with od.create_environment("multipl", auto_start=True) as env:
            logger.info("MultiPL container started for additional tests")

            for payload_path in additional_payloads:
                try:
                    payload = load_sample_payload(payload_path)
                    language = payload["language"]

                    logger.info(f"Testing additional {language} payload...")

                    result = env.execute_code(
                        solution=payload["completion"],
                        test=payload["test"],
                        entry_point="",  # Not used in MultiPL
                        res_id=str(payload["res_id"]),
                        language=payload["language"],
                        timeout=120.0,
                    )

                    passed = result.get("passed", 0) == 1
                    results[language] = passed

                    status = "PASSED" if passed else "FAILED"
                    logger.info(f"{language} additional test: {status}")

                except Exception as e:
                    logger.error(f"Additional test failed for {payload_path}: {e}")
                    results[Path(payload_path).stem] = False

        return results

    except Exception as e:
        logger.error(f"Additional MultiPL tests failed: {e}")
        return {}


def run_tests():
    """Run all tests and provide a comprehensive report."""
    logger.info("Starting comprehensive test suite with sample payloads...")

    test_results = {}

    # Test BCB
    test_results["BCB"] = test_bcb_with_sample_payload()

    # Test DS1000
    test_results["DS1000"] = test_ds1000_with_sample_payload()

    # Test MultiPL
    test_results["MultiPL_Core"] = test_multipl_with_sample_payloads()

    # Test additional MultiPL languages
    additional_results = test_additional_multipl_payloads()
    test_results.update({f"MultiPL_{k}": v for k, v in additional_results.items()})

    # Final report
    logger.info("COMPREHENSIVE TEST RESULTS:")
    logger.info("=" * 70)

    passed_tests = []
    failed_tests = []

    for test_name, result in test_results.items():
        status = "PASSED" if result else "FAILED"
        logger.info(f"{test_name:20}: {status}")

        if result:
            passed_tests.append(test_name)
        else:
            failed_tests.append(test_name)

    logger.info(f"Total tests: {len(test_results)}")
    logger.info(f"Passed: {len(passed_tests)}")
    logger.info(f"Failed: {len(failed_tests)}")

    if failed_tests:
        logger.info(f"Failed tests: {', '.join(failed_tests)}")

    success_rate = len(passed_tests) / len(test_results) * 100
    logger.info(f"Success rate: {success_rate:.1f}%")

    if success_rate == 100:
        logger.info("Test suite PASSED")
    else:
        logger.warning("Test suite FAILED")


if __name__ == "__main__":
    run_tests()
