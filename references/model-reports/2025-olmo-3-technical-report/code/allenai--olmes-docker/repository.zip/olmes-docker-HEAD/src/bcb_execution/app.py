import json
from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from execution import untrusted_check


app = FastAPI(title="BCB Execution Service", version="1.0.0")


class BCBExecutionRequest(BaseModel):
    solution: str
    test: str
    res_id: str
    task_id: str
    entry_point: str
    calibrate: bool = True
    no_gt: bool = True
    min_time_limit: int = 1
    max_as_limit: int = 30 * 1024
    max_data_limit: int = 30 * 1024
    max_stack_limit: int = 10
    gt_time_limit: int = 20
    code_prompt: Optional[str] = None


class BCBExecutionResponse(BaseModel):
    task_id: str
    res_id: str
    tested_completion: str
    passed: bool
    exec_result: str


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


@app.post("/execute", response_model=BCBExecutionResponse)
async def execute_code(request: BCBExecutionRequest):
    try:
        solution = request.solution
        
        if request.calibrate and request.code_prompt:
            solution = request.code_prompt + "\n    pass\n" + solution

        if not request.no_gt:
            raise HTTPException(
                status_code=501, 
                detail="Groundtruth execution is not implemented yet!"
            )

        stat, details = untrusted_check(
            code=solution,
            test_code=request.test,
            entry_point=request.entry_point,
            min_time_limit=request.min_time_limit,
            max_as_limit=request.max_as_limit,
            max_data_limit=request.max_data_limit,
            max_stack_limit=request.max_stack_limit,
            gt_time_limit=request.gt_time_limit,
        )

        passed = stat == "pass"

        return BCBExecutionResponse(
            task_id=request.task_id,
            res_id=request.res_id,
            tested_completion=solution,
            passed=passed,
            exec_result=json.dumps(details) if details else stat,
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Handler for AWS Lambda
def handler(event, context):
    request = BCBExecutionRequest(**event)
    response = execute_code(request)
    return json.dumps(response.dict())
