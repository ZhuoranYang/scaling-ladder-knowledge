import json

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from eval import check_correctness


app = FastAPI(title="MultiPL Execution Service", version="1.0.0")


class MultiPLExecutionRequest(BaseModel):
    res_id: str
    language: str
    completion: str
    test: str
    # timeout: float = 10.0  # TODO: pipe this through to safe_subprocess.run


class MultiPLExecutionResponse(BaseModel):
    res_id: str
    tested_completion: str
    passed: int
    exec_result: str


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


@app.post("/execute", response_model=MultiPLExecutionResponse)
async def execute_code(request: MultiPLExecutionRequest):
    try:
        result = check_correctness(request.language, request.completion, request.test)
        passed = 1 if result["status"] == "OK" and result["exit_code"] == 0 else 0

        return MultiPLExecutionResponse(
            res_id=request.res_id,
            tested_completion=result["tested_completion"],
            passed=passed,
            exec_result=result["status"],
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Handler for AWS Lambda
def handler(event, context):
    request = MultiPLExecutionRequest(**event)
    response = execute_code(request)
    return json.dumps(response.dict())
