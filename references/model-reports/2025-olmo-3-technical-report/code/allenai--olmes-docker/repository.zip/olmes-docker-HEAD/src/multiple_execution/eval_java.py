import os
import shutil
import tempfile
from pathlib import Path

from safe_subprocess import run

# Following files have problems:
# 137,
# 22: Any
# 148: Elipsis


def eval_script(path: Path):

    sys_env = os.environ.copy()
    javatuples_path = Path("/opt/lib/javatuples-1.2.jar")

    sys_env["CLASSPATH"] = f"{javatuples_path}"

    outdir = tempfile.mkdtemp(dir="/tmp")

    try:
        # Use UTF8 encoding with javac
        result = run(["javac", "-encoding", "UTF8", "-d", outdir, path], env=sys_env)

        if result.exit_code != 0:
            # Well, it's a compile error. May be a type error or
            # something. But, why break the set convention
            status = "SyntaxError"
        else:
            result = run(["java", "-ea", "-cp", f"{outdir}:{javatuples_path}", "Problem"], env=sys_env)
            if result.timeout:
                status = "Timeout"
            elif result.exit_code == 0:
                status = "OK"
            else:
                status = "Exception"

        return {
            "status": status,
            "exit_code": result.exit_code,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }

    finally:
        shutil.rmtree(outdir)
