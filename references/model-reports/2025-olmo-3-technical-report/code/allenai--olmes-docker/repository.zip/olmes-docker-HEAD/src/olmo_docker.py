import logging
import subprocess
import time
from pathlib import Path
from typing import Dict, Any, Optional, Union, Literal
import docker
import httpx
from docker.models.containers import Container


logger = logging.getLogger(__name__)

def get_docker_host_ip():
    """Get the Docker host IP from within a container."""
    try:
        # Try to get the Docker host IP from the default route
        result = subprocess.run(['ip', 'route'], capture_output=True, text=True, timeout=5)
        for line in result.stdout.split('\n'):
            if 'default' in line:
                docker_host_ip = line.split()[2]
                logger.info(f"Detected Docker host IP: {docker_host_ip}")
                return docker_host_ip
    except Exception as e:
        logger.error(f"Error detecting Docker host IP: {e}")
        
    # Fallback to common Docker host IPs
    docker_host_ip = '172.17.0.1'  # Default Docker bridge gateway
    logger.info(f"Using fallback Docker host IP: {docker_host_ip}")
    return docker_host_ip


class BaseExecutionEnvironment:
    """Base class for Docker-based code execution environments."""
    
    def __init__(
        self,
        image_name: str,
        dockerfile_path: Path,
        host_port: Optional[int] = None,
        memory_limit: str = "2g",
        cpu_limit: float = 1.0,
        timeout: int = 300,
        auto_start: bool = False,
    ):
        """
        Initialize the execution environment.
        
        Args:
            image_name: Name for the Docker image
            dockerfile_path: Path to the Dockerfile
            host_port: Host port to bind to (auto-assigned if None)
            memory_limit: Memory limit for container (e.g., "2g", "512m")
            cpu_limit: CPU limit for container (number of CPUs)
            timeout: Container startup timeout in seconds
            auto_start: Whether to automatically build and start the container
        """
        self.image_name = image_name
        self.dockerfile_path = dockerfile_path
        self.host_port = host_port
        self.memory_limit = memory_limit
        self.cpu_limit = cpu_limit
        self.timeout = timeout
        self.container_port = 8000
        
        self.docker_client = docker.from_env()
        self.container: Optional[Container] = None
        self._base_url: Optional[str] = None
        
        if auto_start:
            self.build_image()
            self.start_container()
    
    def build_image(self, force_rebuild: bool = False) -> None:
        """Build the Docker image."""
        try:
            if not force_rebuild:
                # Check if image already exists
                try:
                    self.docker_client.images.get(self.image_name)
                    logger.info(f"Image {self.image_name} already exists, skipping build")
                    return
                except docker.errors.ImageNotFound:
                    pass
            
            logger.info(f"Building Docker image {self.image_name}...")
            dockerfile_dir = self.dockerfile_path.parent
            
            image, build_logs = self.docker_client.images.build(
                path=str(dockerfile_dir),
                dockerfile=self.dockerfile_path.name,
                tag=self.image_name,
                rm=True,
                forcerm=True,
            )
            
            # Log build output
            for log in build_logs:
                if 'stream' in log:
                    logger.debug(log['stream'].strip())
                    
            logger.info(f"Successfully built image {self.image_name}")
            
        except Exception as e:
            logger.error(f"Failed to build image {self.image_name}: {e}")
            raise
    
    def start_container(self) -> str:
        """
        Start the Docker container and return the base URL.
        
        Returns:
            Base URL for making HTTP requests to the container
        """
        if self.container is not None:
            logger.warning("Container already running")
            return self._base_url
            
        try:
            logger.info(f"Starting container from image {self.image_name}...")
            
            # Port configuration
            ports = {f'{self.container_port}/tcp': self.host_port}
            
            # Environment variables to ensure HTTP mode
            environment = {'PYTHONUNBUFFERED': '1'}
            
            # Start container with HTTP server mode
            self.container = self.docker_client.containers.run(
                self.image_name,
                command=["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"],
                entrypoint="",  # Override the Lambda entrypoint
                detach=True,
                ports=ports,
                environment=environment,
                mem_limit=self.memory_limit,
                cpu_count=int(self.cpu_limit),
                remove=False,
            )
            
            # Wait for container to initialize
            time.sleep(3)
            
            # Check if container is still running
            self.container.reload()
            if self.container.status != 'running':
                logs = self.get_logs()
                raise RuntimeError(f"Container failed to start. Status: {self.container.status}. Logs: {logs}")
            
            # Get the actual host port
            port_info = self.container.attrs['NetworkSettings']['Ports'][f'{self.container_port}/tcp']
            if port_info:
                actual_host_port = int(port_info[0]['HostPort'])
            else:
                raise RuntimeError("Failed to get container port mapping")
            
            # DinD support: use Docker host IP instead of localhost
            docker_host_ip = get_docker_host_ip()
            self._base_url = f"http://{docker_host_ip}:{actual_host_port}"
            
            # Wait for container to be ready
            self._wait_for_container_ready()
            
            logger.info(f"Container started successfully at {self._base_url}")
            return self._base_url
            
        except Exception as e:
            logger.error(f"Failed to start container: {e}")
            self.stop_container()
            raise
    
    def stop_container(self) -> None:
        """Stop and remove the Docker container."""
        if self.container is not None:
            try:
                logger.info("Stopping container...")
                try:
                    self.container.reload()
                    if self.container.status in ['running', 'paused']:
                        self.container.stop(timeout=10)
                    self.container.remove(force=True)
                    logger.info("Container stopped and removed successfully")
                except docker.errors.NotFound:
                    logger.info("Container already removed")
                except Exception as e:
                    logger.error(f"Error stopping container: {e}")
                    try:
                        self.container.remove(force=True)
                        logger.info("Container force removed")
                    except docker.errors.NotFound:
                        logger.info("Container already removed")
                    except Exception as e2:
                        logger.error(f"Error force removing container: {e2}")
                finally:
                    self.container = None
                    self._base_url = None
            except Exception as e:
                logger.error(f"Unexpected error in stop_container: {e}")
                self.container = None
                self._base_url = None
    
    def _wait_for_container_ready(self) -> None:
        """Wait for the container to be ready to accept requests."""
        if not self._base_url:
            raise RuntimeError("Container not started")
            
        start_time = time.time()
        while time.time() - start_time < self.timeout:
            try:
                response = httpx.get(f"{self._base_url}/health", timeout=5.0)
                if response.status_code == 200:
                    logger.info("Container is ready")
                    return
            except (httpx.RequestError, httpx.TimeoutException):
                pass
            
            time.sleep(1)
        
        raise TimeoutError(f"Container failed to become ready within {self.timeout} seconds")
    
    def execute_code(self, **kwargs) -> Dict[str, Any]:
        """
        Execute code in the container. Should be implemented by subclasses.
        
        Returns:
            Dictionary with execution results
        """
        raise NotImplementedError("Subclasses must implement execute_code method")
    
    def is_running(self) -> bool:
        """Check if the container is currently running."""
        if self.container is None:
            return False
        
        try:
            self.container.reload()
            return self.container.status == 'running'
        except docker.errors.NotFound:
            self.container = None
            self._base_url = None
            return False
        except Exception:
            return False
    
    def get_logs(self, tail: int = 100) -> str:
        """Get container logs."""
        if self.container is None:
            return "No container running"
        
        try:
            return self.container.logs(tail=tail).decode('utf-8')
        except docker.errors.NotFound:
            return "Container not found (may have been removed)"
        except Exception as e:
            return f"Error getting logs: {e}"
    
    def get_execute_endpoint(self) -> str:
        return f"{self._base_url}/execute"
    
    def __enter__(self):
        """Context manager entry."""
        if not self.is_running():
            self.build_image()
            self.start_container()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.stop_container()


class BCBExecutionEnvironment(BaseExecutionEnvironment):
    """BigCodeBench execution environment."""
    
    def __init__(
        self,
        host_port: Optional[int] = None,
        memory_limit: str = "2g",
        cpu_limit: float = 1.0,
        timeout: int = 300,
        auto_start: bool = False,
    ):
        current_dir = Path(__file__).parent
        dockerfile_path = current_dir / "bcb_execution" / "Dockerfile"
        
        super().__init__(
            image_name="olmo-bcb-execution",
            dockerfile_path=dockerfile_path,
            host_port=host_port,
            memory_limit=memory_limit,
            cpu_limit=cpu_limit,
            timeout=timeout,
            auto_start=auto_start,
        )
    
    def execute_code(
        self,
        solution: str,
        test: str,
        entry_point: str,
        task_id: str = "default",
        res_id: str = "default",
        calibrate: bool = True,
        no_gt: bool = True,
        min_time_limit: int = 1,
        max_as_limit: int = 30 * 1024,
        max_data_limit: int = 30 * 1024,
        max_stack_limit: int = 10,
        gt_time_limit: int = 20,
        code_prompt: Optional[str] = None,
        timeout: float = 60.0,
        **kwargs
    ) -> Dict[str, Any]:
        """Execute BCB code with test cases."""
        if not self.is_running():
            raise RuntimeError("Container is not running. Call start_container() first.")
        
        payload = {
            "solution": solution,
            "test": test,
            "res_id": res_id,
            "task_id": task_id,
            "entry_point": entry_point,
            "calibrate": calibrate,
            "no_gt": no_gt,
            "min_time_limit": min_time_limit,
            "max_as_limit": max_as_limit,
            "max_data_limit": max_data_limit,
            "max_stack_limit": max_stack_limit,
            "gt_time_limit": gt_time_limit,
        }
        
        if code_prompt is not None:
            payload["code_prompt"] = code_prompt
        
        try:
            response = httpx.post(
                f"{self._base_url}/execute",
                json=payload,
                timeout=timeout,
            )
            response.raise_for_status()
            return response.json()
            
        except httpx.RequestError as e:
            logger.error(f"Request failed: {e}")
            raise RuntimeError(f"Failed to execute code: {e}")
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error {e.response.status_code}: {e.response.text}")
            raise RuntimeError(f"Execution failed with status {e.response.status_code}: {e.response.text}")


class DS1000ExecutionEnvironment(BaseExecutionEnvironment):
    """DS1000 execution environment."""
    
    def __init__(
        self,
        host_port: Optional[int] = None,
        memory_limit: str = "2g",
        cpu_limit: float = 1.0,
        timeout: int = 300,
        auto_start: bool = False,
    ):
        current_dir = Path(__file__).parent
        dockerfile_path = current_dir / "ds1000_execution" / "Dockerfile"
        
        super().__init__(
            image_name="olmo-ds1000-execution",
            dockerfile_path=dockerfile_path,
            host_port=host_port,
            memory_limit=memory_limit,
            cpu_limit=cpu_limit,
            timeout=timeout,
            auto_start=auto_start,
        )
    
    def execute_code(
        self,
        solution: str = "",
        test: str = "",
        entry_point: str = "",
        res_id: str = "default",
        timeout_seconds: float = 10.0,
        timeout: float = 60.0,
        **kwargs
    ) -> Dict[str, Any]:
        """Execute DS1000 data science code."""
        if not self.is_running():
            raise RuntimeError("Container is not running. Call start_container() first.")
        
        # For DS1000, combine solution and test
        full_test = solution + "\n" + test if solution else test
        
        payload = {
            "res_id": res_id,
            "test": full_test,
            "timeout": timeout_seconds,
        }
        
        try:
            response = httpx.post(
                f"{self._base_url}/execute",
                json=payload,
                timeout=timeout,
            )
            response.raise_for_status()
            return response.json()
            
        except httpx.RequestError as e:
            logger.error(f"Request failed: {e}")
            raise RuntimeError(f"Failed to execute code: {e}")
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error {e.response.status_code}: {e.response.text}")
            raise RuntimeError(f"Execution failed with status {e.response.status_code}: {e.response.text}")


class MultiPLExecutionEnvironment(BaseExecutionEnvironment):
    """MultiPL execution environment."""
    
    def __init__(
        self,
        host_port: Optional[int] = None,
        memory_limit: str = "2g",
        cpu_limit: float = 1.0,
        timeout: int = 300,
        auto_start: bool = False,
    ):
        current_dir = Path(__file__).parent
        dockerfile_path = current_dir / "multiple_execution" / "Dockerfile"
        
        super().__init__(
            image_name="olmo-multipl-execution",
            dockerfile_path=dockerfile_path,
            host_port=host_port,
            memory_limit=memory_limit,
            cpu_limit=cpu_limit,
            timeout=timeout,
            auto_start=auto_start,
        )
    
    def execute_code(
        self,
        solution: str,
        test: str,
        entry_point: str = "",
        res_id: str = "default",
        language: str = "python",
        timeout: float = 60.0,
        **kwargs
    ) -> Dict[str, Any]:
        """Execute multi-language code with test cases."""
        if not self.is_running():
            raise RuntimeError("Container is not running. Call start_container() first.")
        
        payload = {
            "res_id": res_id,
            "language": language,
            "completion": solution,
            "test": test,
        }
        
        try:
            response = httpx.post(
                f"{self._base_url}/execute",
                json=payload,
                timeout=timeout,
            )
            response.raise_for_status()
            return response.json()
            
        except httpx.RequestError as e:
            logger.error(f"Request failed: {e}")
            raise RuntimeError(f"Failed to execute code: {e}")
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error {e.response.status_code}: {e.response.text}")
            raise RuntimeError(f"Execution failed with status {e.response.status_code}: {e.response.text}")


def create_environment(
    env_type: Literal["bcb", "ds1000", "multipl"],
    host_port: Optional[int] = None,
    memory_limit: str = "2g",
    cpu_limit: float = 1.0,
    auto_start: bool = False,
) -> Union[BCBExecutionEnvironment, DS1000ExecutionEnvironment, MultiPLExecutionEnvironment]:
    """
    Create a Docker-based code execution environment.
    
    Args:
        env_type: Type of environment ("bcb", "ds1000", or "multipl")
        host_port: Host port to bind to (auto-assigned if None)
        memory_limit: Memory limit for container (e.g., "2g", "512m")
        cpu_limit: CPU limit for container (number of CPUs)
        auto_start: Whether to automatically build and start the container
        
    Returns:
        Specific ExecutionEnvironment instance based on env_type
        
    Example:
        >>> import olmo_docker as od
        >>> env = od.create_environment("bcb", host_port=8080, auto_start=True)
        >>> result = env.execute_code(
        ...     solution="def multiply(x, y): return x * y",
        ...     test="assert multiply(3, 4) == 12",
        ...     entry_point="multiply"
        ... )
        >>> env.stop_container()
    """
    env_type = env_type.lower()
    
    if env_type == "bcb":
        return BCBExecutionEnvironment(
            host_port=host_port,
            memory_limit=memory_limit,
            cpu_limit=cpu_limit,
            auto_start=auto_start,
        )
    elif env_type == "ds1000":
        return DS1000ExecutionEnvironment(
            host_port=host_port,
            memory_limit=memory_limit,
            cpu_limit=cpu_limit,
            auto_start=auto_start,
        )
    elif env_type == "multipl":
        return MultiPLExecutionEnvironment(
            host_port=host_port,
            memory_limit=memory_limit,
            cpu_limit=cpu_limit,
            auto_start=auto_start,
        )
    else:
        raise ValueError(f"Unsupported environment type: {env_type}. Supported: bcb, ds1000, multipl")
