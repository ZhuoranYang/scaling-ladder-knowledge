"""
Tests for define_template()'s redirect detection in extract.py.

Real MediaWiki's redirect magic word is localized per-wiki
(each wiki's own content language has its own translation,
e.g. Sindhi uses "چوريو" and Urdu uses "رجوع_مکرر", rather than
"REDIRECT"), separate from the interface language.
define_template() previously matched only the literal English keyword
-- a redirect page on a non-English wiki was never recognized as a
redirect at all, and its entire (often stale, pre-redirect leftover)
body text got treated as the template's real content instead.

Confirmed on a real Sindhi Wikipedia dump: a template ("سانچو:حوالا",
Template:References) starting with "#چوريو [[سانچو:حوالو]]" -- was
never resolved as a redirect, and its leftover body (a "reflist" CSS
construct) leaked a "list-style-type: decimal;" fragment into
extracted article text wherever the template was called.
Confirmed directly that treating it as a redirect eliminates this.
Two example pages that led to this were in the 2026-07-01 dump,
pages id 1869 and 1907.

Confirmed separately on a real Urdu Wikipedia dump: a template
("سانچہ:ص.م/فتح", used by the film infobox chain) starting with
"#رجوع_مکرر [[سانچہ:خانہ معلومات/آغاز]]" was never resolved as a
redirect either, which meant the target template supplying an
infobox's opening "{|" wikitable syntax was never reached -- leaving
a sibling template's "! scope=col ..." header-row fragment with no
"{|" to be paired with, so table-stripping had nothing to match and
the raw row leaked into extracted text. Real case: page id 1078623
("سنڈریلا 3: اے ٹوسٹ ان ٹائم", 2026-07-01 UR dump).

Fixed via an extensible redirectKeywords list (starting with
'REDIRECT', 'چوريو', and now 'رجوع_مکرر'), rather than a single
hardcoded English pattern -- more can be added as they're confirmed
on other wikis, without guessing translations for languages not yet
encountered.

False-positive surface, deliberately narrow and tested explicitly
below: matched via re.match() (position 0 of the template's first
line only, never later in a template's body), requires a real word
boundary after the keyword (so "REDIRECTED" etc. don't match), and
requires an actual wikilink following on that same line.

Run with:
    python -m unittest tests.test_redirect_keywords -v
or, from the tests/ directory:
    python -m unittest test_redirect_keywords -v
"""

import sys
import unittest

sys.path.insert(0, '..')  # allow running directly from tests/ without installing

import wikiextractor.extract as ex


class RedirectKeywordsTestCase(unittest.TestCase):

    def setUp(self):
        self.templates = {}
        self.redirects = {}
        ex.TemplateArg._parse_template.cache_clear()
        ex.Extractor._parse_template.cache_clear()


class EnglishRedirectStillWorksTests(RedirectKeywordsTestCase):
    """Regression coverage for the original, pre-existing behavior."""

    def test_uppercase_redirect(self):
        ex.define_template('Template:Foo', ['#REDIRECT [[Template:Bar]]'], self.templates, self.redirects)
        self.assertEqual(self.redirects.get('Template:Foo'), 'Template:Bar')
        self.assertNotIn('Template:Foo', self.templates)

    def test_lowercase_redirect_case_insensitive(self):
        ex.define_template('Template:Foo', ['#redirect [[Template:Bar]]'], self.templates, self.redirects)
        self.assertEqual(self.redirects.get('Template:Foo'), 'Template:Bar')

    def test_mixed_case_redirect(self):
        ex.define_template('Template:Foo', ['#Redirect [[Template:Bar]]'], self.templates, self.redirects)
        self.assertEqual(self.redirects.get('Template:Foo'), 'Template:Bar')

    def test_normal_non_redirect_template_unaffected(self):
        ex.define_template('Template:Normal', ['Some ordinary template text.'], self.templates, self.redirects)
        self.assertIsNone(self.redirects.get('Template:Normal'))
        self.assertIn('Template:Normal', self.templates)


class SindhiRedirectTests(RedirectKeywordsTestCase):
    """The new behavior this fix adds."""

    def test_sindhi_redirect_keyword(self):
        ex.define_template('سانچو:حوالا', ['#چوريو [[سانچو:حوالو]]'], self.templates, self.redirects)
        self.assertEqual(self.redirects.get('سانچو:حوالا'), 'سانچو:حوالو')
        self.assertNotIn('سانچو:حوالا', self.templates)

    def test_real_world_case_content_leak_is_gone(self):
        # The exact real case this fix was found on: once recognized
        # as a redirect, the template's stale, leftover body (the
        # "list-style-type" CSS construct) never gets treated as its
        # content in the first place.
        ex.define_template('سانچو:حوالا', [
            '#چوريو [[سانچو:حوالو]]\n'
            '<div class="reflist" style="list-style-type: decimal;">\n'
            '{{#tag:references}}</div>'
        ], self.templates, self.redirects)
        self.assertEqual(self.redirects.get('سانچو:حوالا'), 'سانچو:حوالو')
        self.assertNotIn('سانچو:حوالا', self.templates)


class UrduRedirectTests(RedirectKeywordsTestCase):
    """Urdu's own redirect keyword, "رجوع_مکرر" -- distinct from
    Sindhi's "چوريو" despite both being South Asian languages sharing
    the whole conversation's UR test corpus.

    Confirmed on a real Urdu Wikipedia dump: "سانچہ:ص.م/فتح"
    (Template:Infobox-open), used by the film infobox template chain,
    is a redirect to "سانچہ:خانہ معلومات/آغاز" via
    "#رجوع_مکرر [[سانچہ:خانہ معلومات/آغاز]]". Before this fix, that
    redirect was never recognized -- the literal redirect-arrow text
    got treated as "ص.م/فتح"'s own template content instead of being
    resolved to its target, so the target's opening "{|" wikitable
    syntax was never reached. A sibling template further down the
    chain still successfully emitted its own "! scope=col ..." wikitext
    header-row fragment, but with no "{|" ever generated to pair it
    with, dropNested()'s table-stripping had nothing to match, and the
    raw table row leaked verbatim into extracted article text --
    visible on real output for id 1078623 ("سنڈریلا 3: اے ٹوسٹ ان
    ٹائم", 2026-07-01 UR dump).

    Recognizing the redirect keyword is necessary but not alone
    sufficient to fix that specific leak -- the redirect's target
    template also has to actually be present in whatever templates
    file is loaded, which is a separate, likely related gap: template-
    dependency discovery presumably also needs to follow this same
    redirect chain, and would have hit the same unrecognized-keyword
    problem while doing so.
    """

    def test_urdu_redirect_keyword(self):
        ex.define_template('سانچہ:ص.م/فتح', ['#رجوع_مکرر [[سانچہ:خانہ معلومات/آغاز]]'], self.templates, self.redirects)
        self.assertEqual(self.redirects.get('سانچہ:ص.م/فتح'), 'سانچہ:خانہ معلومات/آغاز')
        self.assertNotIn('سانچہ:ص.م/فتح', self.templates)

    def test_real_world_case_table_leak_is_gone(self):
        # With the redirect keyword recognized AND the target template
        # actually available, the infobox's "{|" opener is reached and
        # the header row it should have wrapped gets correctly dropped
        # -- rather than leaking verbatim as in the real case above.
        ex.define_template('سانچہ:ص.م/فتح', ['#رجوع_مکرر [[سانچہ:خانہ معلومات/آغاز]]'], self.templates, self.redirects)
        ex.define_template('سانچہ:خانہ معلومات/آغاز', ['{| class="infobox"'], self.templates, self.redirects)
        ex.define_template('سانچہ:خانہ معلومات/اختتام', ['|}'], self.templates, self.redirects)
        ex.define_template('سانچہ:خ۔م/عنوان', ['! scope=col | {{{1}}}'], self.templates, self.redirects)

        wikitext = ('{{ص.م/فتح}}\n{{خ۔م/عنوان|Test}}\n{{خانہ معلومات/اختتام}}\n'
                    'Ordinary article prose follows.')
        # Real template resolution needs a real namespace prefix --
        # never set elsewhere in this file, since every other test
        # here checks define_template()'s own redirect detection
        # directly rather than going through full expansion. Without
        # templatePrefix set correctly below, fullyQualifiedTemplateTitle()
        # falls back to no prefix at all, every lookup misses, and this
        # test would pass trivially regardless of whether redirects is
        # even correct -- confirmed directly: without both templatePrefix
        # and redirects passed correctly here, "scope=col" leaks through
        # exactly as this test exists to catch.
        extractor = ex.Extractor('1', '1', 'https://x', 'Test', [wikitext],
                                  templates=self.templates, redirects=self.redirects,
                                  templatePrefix='سانچہ:')
        result = extractor.clean_text(wikitext)
        joined = '\n'.join(result)
        self.assertNotIn('scope=col', joined)
        self.assertIn('Ordinary article prose follows.', joined)


class SlovenianRedirectTests(RedirectKeywordsTestCase):
    """slwiki spells it "PREUSMERITEV".

    Confirmed on slwiki's "Sekunda" (page id 164), where two of the
    templates it reaches are redirects written that way:
    "Predloga:E" -> "Predloga:X10^" and "Predloga:Quote" ->
    "Predloga:Citatni blok". Unrecognized, each template's body was
    transcluded as ordinary text, so the article read

        ... podaljšalo definicijo za približno 1#PREUSMERITEV.

    where "1×10⁻¹⁰" belonged -- the keyword surviving because the
    wikilink after it is dropped as a link to a non-article page,
    leaving the bare magic word behind in the prose.
    """

    def test_slovenian_redirect_keyword(self):
        ex.define_template('Predloga:E', ['#PREUSMERITEV [[Predloga:X10^]]'],
                           self.templates, self.redirects)
        self.assertEqual(self.redirects.get('Predloga:E'), 'Predloga:X10^')
        self.assertNotIn('Predloga:E', self.templates)

    def test_real_world_case_keyword_leak_is_gone(self):
        ex.define_template('Predloga:E', ['#PREUSMERITEV [[Predloga:X10^]]'],
                           self.templates, self.redirects)
        ex.define_template('Predloga:X10^', ['{{{1|1}}}×10<sup>{{{2|}}}</sup>'],
                           self.templates, self.redirects)

        wikitext = 'podaljšalo definicijo za približno 1{{E|−10}}.'
        extractor = ex.Extractor('1', '1', 'https://x', 'Sekunda', [wikitext],
                                 templates=self.templates, redirects=self.redirects,
                                 templatePrefix='Predloga:')
        joined = '\n'.join(extractor.clean_text(wikitext))
        self.assertNotIn('PREUSMERITEV', joined)
        self.assertIn('1−10×10', joined)


class HindiRedirectTests(RedirectKeywordsTestCase):
    """hiwiki has two spellings in use, "अनुप्रेषित" and
    "पुनर्प्रेषित".

    Both turned up in a full hiwiki extraction, and both on
    lang-family templates, so articles quoting a name in another
    script lost it and kept the magic word instead::

        फ़ारसी (#अनुप्रेषित), एक भाषा है ...
        मदीना या अल-मदीना (अरबी: #अनुप्रेषित) ...

    where the Perso-Arabic and Arabic forms belonged.
    """

    def test_anupreshit_keyword(self):
        ex.define_template('साँचा:Fa', ['#अनुप्रेषित [[साँचा:फ़ारसी]]'],
                           self.templates, self.redirects)
        self.assertEqual(self.redirects.get('साँचा:Fa'), 'साँचा:फ़ारसी')
        self.assertNotIn('साँचा:Fa', self.templates)

    def test_punarpreshit_keyword(self):
        ex.define_template('साँचा:Ps', ['#पुनर्प्रेषित [[साँचा:लैंग]]'],
                           self.templates, self.redirects)
        self.assertEqual(self.redirects.get('साँचा:Ps'), 'साँचा:लैंग')

    def test_real_world_case_keyword_leak_is_gone(self):
        ex.define_template('साँचा:Fa', ['#अनुप्रेषित [[साँचा:फ़ारसी]]'],
                           self.templates, self.redirects)
        ex.define_template('साँचा:फ़ारसी', ['فارسی'],
                           self.templates, self.redirects)
        wikitext = 'फ़ारसी ({{Fa}}), एक भाषा है।'
        extractor = ex.Extractor('1', '1', 'https://x', 'फ़ारसी', [wikitext],
                                 templates=self.templates, redirects=self.redirects,
                                 templatePrefix='साँचा:')
        joined = '\n'.join(extractor.clean_text(wikitext))
        self.assertNotIn('अनुप्रेषित', joined)
        self.assertIn('فارسی', joined)


class PunjabiShahmukhiRedirectTests(RedirectKeywordsTestCase):
    """pnbwiki spells it "مڑجوڑ", which is not Urdu's "رجوع_مکرر"
    even though the two wikis share a script.

    This one empties articles outright rather than corrupting a
    phrase. The leaked keyword arrives at the head of the article's
    first line, since the template whose body leaks is called before
    any prose and the lead sentence continues on that same line. A
    line starting with '#' is a list item to compact(), which drops
    it -- so the lead paragraph goes too, and an article whose only
    prose is its lead extracts to nothing at all.

    Found by auditing the empty documents of a full pnbwiki
    extraction: "لاورن کاکس" (id 76804), "غنا علی" (id 64362),
    "عائشہ فاروق" (id 62180) and "ابھینا اہیر" (id 62251) are four of
    them, each an empty document whose expanded text began "#مڑجوڑ".
    """

    def test_punjabi_redirect_keyword(self):
        ex.define_template('سانچہ:Infobox person',
                           ['#مڑجوڑ [[سانچہ:خانہ معلومات شخصیت]]'],
                           self.templates, self.redirects)
        self.assertEqual(self.redirects.get('سانچہ:Infobox person'),
                         'سانچہ:خانہ معلومات شخصیت')
        self.assertNotIn('سانچہ:Infobox person', self.templates)

    def test_real_world_case_article_is_no_longer_empty(self):
        # The target template exists but renders to nothing, which is
        # the common shape; what matters is that the redirect resolves
        # instead of its body being transcluded as text.
        ex.define_template('سانچہ:Infobox person',
                           ['#مڑجوڑ [[سانچہ:خانہ معلومات شخصیت]]'],
                           self.templates, self.redirects)
        ex.define_template('سانچہ:خانہ معلومات شخصیت', [''],
                           self.templates, self.redirects)

        wikitext = ("{{Infobox person|name=Laverne}}'''لاویرن کوکس''' "
                    "اک امریکی اداکارہ اتے ایڈووکیٹ اے۔")
        extractor = ex.Extractor('1', '1', 'https://x', 'لاورن کاکس',
                                 [wikitext], templates=self.templates,
                                 redirects=self.redirects,
                                 templatePrefix='سانچہ:')
        joined = '\n'.join(extractor.clean_text(wikitext))
        self.assertNotIn('مڑجوڑ', joined)
        self.assertIn('لاویرن کوکس', joined)

    def test_the_two_perso_arabic_spellings_are_both_recognized(self):
        # Guards against the two being treated as interchangeable:
        # each wiki's own spelling needs its own entry.
        ex.define_template('سانچہ:Foo', ['#مڑجوڑ [[سانچہ:Bar]]'],
                           self.templates, self.redirects)
        ex.define_template('سانچہ:Baz', ['#رجوع_مکرر [[سانچہ:Qux]]'],
                           self.templates, self.redirects)
        self.assertEqual(self.redirects.get('سانچہ:Foo'), 'سانچہ:Bar')
        self.assertEqual(self.redirects.get('سانچہ:Baz'), 'سانچہ:Qux')


class FalsePositiveBoundaryTests(RedirectKeywordsTestCase):
    """The narrow, deliberately-tested false-positive surface: only
    matches at the very start of a template's first line, only as a
    whole word, only when a wikilink actually follows on that line.
    """

    def test_word_continuation_does_not_match(self):
        # "REDIRECTED" -- no word boundary right after "REDIRECT".
        ex.define_template('Template:Foo', ['#REDIRECTED to a new place [[Template:Bar]]'], self.templates, self.redirects)
        self.assertIsNone(self.redirects.get('Template:Foo'))
        self.assertIn('Template:Foo', self.templates)

    def test_keyword_not_at_start_of_first_line_does_not_match(self):
        ex.define_template('Template:Foo', ['Some text. #REDIRECT mentioned here [[Template:Bar]]'], self.templates, self.redirects)
        self.assertIsNone(self.redirects.get('Template:Foo'))
        self.assertIn('Template:Foo', self.templates)

    def test_keyword_with_no_wikilink_does_not_match(self):
        ex.define_template('Template:Foo', ['#REDIRECT to somewhere, no link here'], self.templates, self.redirects)
        self.assertIsNone(self.redirects.get('Template:Foo'))
        self.assertIn('Template:Foo', self.templates)

    def test_keyword_appearing_only_in_a_later_line_does_not_match(self):
        # Only the template's first line is ever checked.
        ex.define_template('Template:Foo', [
            'This is the real, first line of content.\n'
            '#REDIRECT [[Template:Bar]]\n'
        ], self.templates, self.redirects)
        self.assertIsNone(self.redirects.get('Template:Foo'))
        self.assertIn('Template:Foo', self.templates)


if __name__ == '__main__':
    unittest.main()
