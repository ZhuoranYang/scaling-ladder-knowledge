#!/usr/bin/env python3
"""
extract_page_range.py

Slice pages out of a (possibly bz2-compressed) MediaWiki XML dump,
producing a smaller, independently valid dump -- for bisecting which
page(s) cause wikiextractor to stall, or for pulling out one specific
page by its <id> to test or share.

Four modes:

  --count        Just stream through and report the total number of <page>
                 elements (fast, doesn't hold anything in memory).

  --find-id      Report the 0-based ordinal position of the page with a
                 given <id> (needed if you want to slice a --start/--end
                 range around it), and exit.

  --start/--end  Stream through once, and write out a new dump containing
                 only pages [start, end) (0-indexed, half-open range),
                 wrapped in the same <mediawiki>/<siteinfo> header and
                 </mediawiki> footer as the original, so wikiextractor can
                 process it as a standalone file.

  --extract-id   Find the page(s) with the given <id>(s) and write them out
                 as a standalone dump, in a single streaming pass (stops as
                 soon as all requested ids have been found, rather than
                 needing a separate --find-id pass first, and rather than
                 always reading to the end of the file). The simplest way
                 to pull out one or more specific pages. Accepts a single
                 id or a comma-separated list (e.g. --extract-id 49,59);
                 pages are written in the order they appear in the source
                 dump, not the order given on the command line.

--extract-templates (combine with --extract-id or --start/--end):
  After writing the requested page(s), also discover and append every
  template those pages actually reference, using
  extract_templates_by_id's own real-expansion-based discovery
  machinery (see that script's own module docstring for why this is
  used instead of a "{{" regex scanner) -- reused directly here via
  import, not reimplemented. Requires --templates (the large templates
  file to search). The result is a single, self-contained output file
  with both the page(s) and everything they need to fully re-extract,
  rather than needing extract_templates_by_id.py run separately
  afterward as a second step.

Usage:
    python extract_page_range.py --input urwiki-20260701-pages-articles-multistream.xml.bz2 --count

    python extract_page_range.py --input urwiki-20260701-pages-articles-multistream.xml.bz2 --find-id 2376854

    python extract_page_range.py --input urwiki-20260701-pages-articles-multistream.xml.bz2 \
        --start 0 --end 150000 --output half1.xml.bz2

    python extract_page_range.py --input urwiki-20260701-pages-articles-multistream.xml.bz2 \
        --start 150000 --end 300000 --output half2.xml.bz2

    python extract_page_range.py --input urwiki-20260701-pages-articles-multistream.xml.bz2 \
        --extract-id 2376854 --output single_page.xml.bz2

    python extract_page_range.py --input pnwiki-20260701-pages-articles.xml.bz2 \
        --extract-id 49,59 --output two_pages.xml.bz2

    python extract_page_range.py --input jawiki-20260901-pages-articles.xml.bz2 \
        --extract-id 4230 --output - | less

    python extract_page_range.py --input urwiki-20260701-pages-articles.xml.bz2 \
        --extract-id 2376854 --templates urwiki-templates.xml.bz2 --extract-templates \
        --output repro.xml.bz2
    # repro.xml.bz2 now has page 2376854 AND every template it needs,
    # ready to feed straight into wikiextractor on its own.

Binary search workflow (for bisecting a stall):
    1. --count to get total page count N.
    2. Split [0, N) in half, extract both halves, run wikiextractor on each
       (normal multiprocessing settings -- reproduce the stall).
    3. Whichever half stalls, split THAT range in half again. Repeat.
    4. Once the range is down to a few thousand pages, wikiextractor will
       finish (or stall) fast even with --processes 1, so you can switch to
       that for the final pinpointing and confirm the single offending
       article by watching the last debug line printed.
    5. Once you know the specific page id, --extract-id pulls it out
       directly for isolated testing, without repeating the bisection.
       Add --templates/--extract-templates to get a fully self-contained
       repro in one pass, rather than a second, separate script run.

Notes:
    - Streams the input; never holds the whole dump in memory (except
      the page text collected for --extract-templates' own discovery
      pass, which needs it in memory the same way
      extract_templates_by_id.py already does).
    - Detects <page> / </page> on their own (whitespace-trimmed) line, which
      is how Wikimedia dumps are always formatted. Page content is XML-escaped
      by the exporter, so a literal "<page>" line can't appear inside article
      text.
    - Output is written as .bz2 if the --output path ends in .bz2, otherwise
      as plain XML text. --output - writes the dump to stdout instead, always
      uncompressed; status lines and warnings go to stderr in every mode, so
      the dump on stdout stays clean enough to pipe.
    - Input bytes that are not valid UTF-8 stop the run, since the output is
      meant to be a faithful excerpt. --decode-errors replace substitutes
      U+FFFD and continues instead.
    - Line endings are preserved as they appear in the source rather than
      being translated, so an excerpt matches the span it came from byte for
      byte on every platform.
    - --extract-templates requires wikiextractor's extract.py and this
      script's own extract_templates_by_id.py to both be importable
      (e.g. both on $PYTHONPATH, or extract_templates_by_id.py in the
      same directory as this script) -- only imported when actually
      needed, so --count/--find-id/plain extraction never require them.
"""

import argparse
import bz2
import contextlib
import os
import re
import sys


def parse_id_list(s):
    """
    argparse type for --extract-id: accepts either a single id ("49")
    or a comma-separated list ("49,59"). Whitespace around each entry
    is tolerated. Returns a list of ints, in the order given (though
    do_extract_ids() writes pages in source-dump order regardless,
    not this order).
    """
    ids = []
    for part in s.split(','):
        part = part.strip()
        if not part:
            continue
        try:
            ids.append(int(part))
        except ValueError:
            raise argparse.ArgumentTypeError(
                f"invalid id {part!r} in --extract-id {s!r} -- expected an "
                f"integer, or a comma-separated list of integers")
    if not ids:
        raise argparse.ArgumentTypeError(f"--extract-id {s!r} contained no ids")
    return ids


def utf8_stdout():
    """Return sys.stdout, reconfigured to UTF-8 if it is not already.

    sys.stdout otherwise encodes with the locale's encoding, which on
    Windows is a legacy code page whenever stdout is redirected rather
    than attached to a console.
    """
    stream = sys.stdout
    encoding = (stream.encoding or '').lower().replace('-', '')
    if encoding not in ('utf8', 'utf8sig') and hasattr(stream, 'reconfigure'):
        stream.reconfigure(encoding='utf-8')
    return stream


def open_maybe_bz2_read(path, errors='strict'):
    # newline='' keeps line endings exactly as they are in the source,
    # so an excerpt is byte-identical to the span it came from.
    if path.endswith('.bz2'):
        return bz2.open(path, 'rt', encoding='utf-8', errors=errors, newline='')
    return open(path, 'r', encoding='utf-8', errors=errors, newline='')


@contextlib.contextmanager
def open_output(path):
    """Open the output, or hand back stdout for '-'.

    stdout is yielded without being closed afterwards: the caller does
    not own it, and closing it would take the rest of the program's
    output with it.
    """
    if path == '-':
        yield utf8_stdout()
        return
    if path.endswith('.bz2'):
        out = bz2.open(path, 'wt', encoding='utf-8', newline='')
    else:
        out = open(path, 'w', encoding='utf-8', newline='')
    try:
        yield out
    finally:
        out.close()


def line_ending(text):
    """The line ending used by a chunk of the source, for building a
    footer when the stream stops before reaching the real one."""
    return '\r\n' if '\r\n' in text else '\n'


def decoded_lines(f, input_path):
    """Iterate f, turning a decoding failure into an explanation.

    The output is meant to be a faithful excerpt of the input, so a
    byte that is not valid UTF-8 stops the run by default rather than
    being quietly replaced with U+FFFD in a page someone will later
    treat as a reproduction of the real one.
    """
    while True:
        try:
            line = next(f)
        except StopIteration:
            return
        except UnicodeDecodeError as err:
            raise SystemExit(
                f"ERROR: {input_path} is not valid UTF-8 ({err.reason} at "
                f"byte {err.start} of a decoded chunk).\n"
                f"       Re-run with --decode-errors replace to substitute "
                f"U+FFFD and continue; note that pages containing the bad "
                f"bytes will not match the source exactly.")
        yield line


def stream_pages(input_path, decode_errors='strict'):
    """
    Yields (header_text, page_text_generator) -- actually simpler: this is a
    generator-based single pass. We yield control via a small state machine
    so the caller can decide, page by page, whether to keep or skip it,
    without ever holding more than one page's text in memory at a time.

    Yields tuples: ('header', text) once, then ('page', text) per page,
    then ('footer', text) once.
    """
    with open_maybe_bz2_read(input_path, decode_errors) as f:
        header_lines = []
        in_page = False
        page_lines = []
        got_header = False

        for line in decoded_lines(f, input_path):
            stripped = line.strip()

            if not in_page and stripped == '<page>':
                if not got_header:
                    yield ('header', ''.join(header_lines))
                    got_header = True
                in_page = True
                page_lines = [line]
                continue

            if in_page:
                page_lines.append(line)
                if stripped == '</page>':
                    in_page = False
                    yield ('page', ''.join(page_lines))
                    page_lines = []
                continue

            if stripped == '</mediawiki>':
                yield ('footer', line)
                return

            header_lines.append(line)


def extract_wikitext(page_text):
    """Pulls just the <text>...</text> content out of one raw <page>
    block -- used to build the {id: wikitext} mapping
    extract_templates_by_id's discover_and_extract() expects, from
    pages we've already read for --extract-templates' sake."""
    m = re.search(r'<text[^>]*>(.*?)</text>', page_text, re.DOTALL)
    return m.group(1) if m else ''


def extract_templates_for_pages(out, page_texts_by_id, templates_path, max_passes):
    """
    Discovers and writes out every template referenced by the given
    pages, appending them to the same output file the page(s)
    themselves were just written to. Reuses
    extract_templates_by_id.discover_and_extract() directly rather
    than reimplementing the discovery logic -- see that script's own
    module docstring for why the real expansion machinery is used
    instead of a regex heuristic.

    page_texts_by_id: {id: wikitext}, exactly what discover_and_extract()
    expects (note: str ids here, matching how it keys its own frame/
    lookup bookkeeping -- callers should pass str(page_id), not int).
    """
    try:
        import extract_templates_by_id as etbi
    except ImportError:
        print("ERROR: --extract-templates requires extract_templates_by_id.py "
              "to be importable (same directory as this script, or on "
              "$PYTHONPATH).", file=sys.stderr)
        sys.exit(1)
    try:
        import wikiextractor.extract as ex
    except ImportError:
        print("ERROR: --extract-templates requires wikiextractor's extract.py "
              "to be importable (e.g. on $PYTHONPATH already).", file=sys.stderr)
        sys.exit(1)

    print(f"Discovering templates referenced by {len(page_texts_by_id)} page(s)...",
          file=sys.stderr)
    loaded_pages, never_found = etbi.discover_and_extract(
        ex, page_texts_by_id, templates_path, max_passes)

    for title, page_text in loaded_pages.items():
        out.write(page_text)

    print(f"Wrote {len(loaded_pages)} template(s):", file=sys.stderr)
    for title in loaded_pages:
        print(f"  {title}", file=sys.stderr)
    if never_found:
        missing = ', '.join(sorted(never_found))
        print(f"WARNING: {len(never_found)} referenced title(s) never found "
              f"in --templates: {missing}", file=sys.stderr)


def do_count(input_path, decode_errors='strict'):
    n = 0
    for kind, _ in stream_pages(input_path, decode_errors):
        if kind == 'page':
            n += 1
    print(f"Total pages: {n}")


def do_find_id(input_path, page_id, decode_errors='strict'):
    """Report the 0-based ordinal position of a page, given its <id>."""
    idx = 0
    for kind, text in stream_pages(input_path, decode_errors):
        if kind == 'page':
            # crude but fine: the first <id>...</id> in a page block is the
            # page id (revision/contributor ids come after it in the block).
            m = re.search(r'<id>(\d+)</id>', text)
            if m and m.group(1) == str(page_id):
                print(f"Page id {page_id} found at ordinal position {idx}")
                return idx
            idx += 1
    print(f"Page id {page_id} not found (scanned {idx} pages)")
    return None


def do_extract(input_path, output_path, start, end, templates_path=None,
                extract_templates=False, max_passes=20, decode_errors='strict'):
    header = None
    # Replaced by the source's own footer line if the stream reaches
    # it; a run that stops early never sees one.
    footer = '</mediawiki>\n'
    idx = 0
    kept = 0
    page_texts_by_id = {}  # only populated if extract_templates is set

    with open_output(output_path) as out:
        for kind, text in stream_pages(input_path, decode_errors):
            if kind == 'header':
                header = text
                out.write(header)
            elif kind == 'page':
                footer = '</mediawiki>' + line_ending(text)
                if start <= idx < end:
                    out.write(text)
                    kept += 1
                    if extract_templates:
                        id_m = re.search(r'<id>(\d+)</id>', text)
                        if id_m:
                            page_texts_by_id[id_m.group(1)] = extract_wikitext(text)
                idx += 1
                if idx >= end:
                    # We've collected everything we need; still need footer.
                    break
            elif kind == 'footer':
                footer = text
        if extract_templates and page_texts_by_id:
            extract_templates_for_pages(out, page_texts_by_id, templates_path, max_passes)
        out.write(footer)

    # stderr, so that --output - stays a clean dump on stdout.
    print(f"Wrote {kept} pages (requested range [{start}, {end})) to {output_path}",
          file=sys.stderr)
    if kept == 0:
        print("WARNING: 0 pages written -- check your --start/--end against the total "
              "page count (use --count first).", file=sys.stderr)


def do_extract_ids(input_path, output_path, page_ids, templates_path=None,
                    extract_templates=False, max_passes=20, decode_errors='strict'):
    """
    Find the page(s) with the given <id>(s) and write them out as a
    standalone dump. Single streaming pass: stops as soon as every
    requested id has been found, rather than requiring a separate
    --find-id pass beforehand, and rather than always reading to the
    end of the file regardless of how early the matches turn up.

    Pages are written in the order they're encountered in the source
    dump, not the order given in page_ids -- simpler, and matches how
    --start/--end already behaves.
    """
    header = None
    footer = '</mediawiki>\n'
    still_needed = set(page_ids)
    found_ids = []
    page_texts_by_id = {}  # only populated if extract_templates is set

    with open_output(output_path) as out:
        for kind, text in stream_pages(input_path, decode_errors):
            if kind == 'header':
                header = text
                out.write(header)
            elif kind == 'page':
                footer = '</mediawiki>' + line_ending(text)
                m = re.search(r'<id>(\d+)</id>', text)
                if m and int(m.group(1)) in still_needed:
                    out.write(text)
                    found_ids.append(int(m.group(1)))
                    still_needed.discard(int(m.group(1)))
                    if extract_templates:
                        page_texts_by_id[m.group(1)] = extract_wikitext(text)
                    if not still_needed:
                        break
            elif kind == 'footer':
                footer = text
        if extract_templates and page_texts_by_id:
            extract_templates_for_pages(out, page_texts_by_id, templates_path, max_passes)
        out.write(footer)

    # stderr, so that --output - stays a clean dump on stdout.
    print(f"Wrote {len(found_ids)} page(s) ({', '.join(str(i) for i in found_ids)}) "
          f"to {output_path}", file=sys.stderr)
    if still_needed:
        missing = ', '.join(str(i) for i in sorted(still_needed))
        print(f"WARNING: {len(still_needed)} id(s) not found: {missing}", file=sys.stderr)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--input', required=True, help='Path to the source dump (.xml or .xml.bz2)')
    ap.add_argument('--count', action='store_true', help='Just count total <page> elements and exit')
    ap.add_argument('--find-id', type=int, help='Report the ordinal position of the page with this <id> and exit')
    ap.add_argument('--extract-id', type=parse_id_list,
                     help='Find and write out the page(s) with this <id> -- a single '
                          'id, or a comma-separated list, e.g. 49,59 (requires --output)')
    ap.add_argument('--start', type=int, help='Start page index (0-based, inclusive)')
    ap.add_argument('--end', type=int, help='End page index (exclusive)')
    ap.add_argument('--output', help="Output path (.xml or .xml.bz2), or - for stdout "
                                      "(always uncompressed; status goes to stderr)")
    ap.add_argument('--decode-errors', choices=('strict', 'replace'), default='strict',
                     help='How to handle bytes in --input that are not valid UTF-8: stop '
                          '(default), or substitute U+FFFD and continue')
    ap.add_argument('--templates', help='Templates file to search when --extract-templates is given '
                                         '(.xml or .xml.bz2)')
    ap.add_argument('--extract-templates', action='store_true',
                     help='Also discover and append every template referenced by the extracted '
                          'page(s), using extract_templates_by_id\'s own discovery machinery. '
                          'Requires --templates, and either --extract-id or --start/--end.')
    ap.add_argument('--max-passes', type=int, default=20,
                     help='With --extract-templates: safety cap on transitive-dependency '
                          'discovery passes (default: 20)')
    args = ap.parse_args()

    if args.extract_templates and not args.templates:
        ap.error('--extract-templates requires --templates')

    if args.templates and not args.extract_templates:
        print("NOTE: --templates given without --extract-templates -- ignored.", file=sys.stderr)

    if args.extract_templates:
        # extract_templates_by_id.py is expected alongside this script;
        # make sure it's importable even if this script was invoked
        # from a different working directory.
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

    if args.count:
        do_count(args.input, decode_errors=args.decode_errors)
        return

    if args.find_id is not None:
        do_find_id(args.input, args.find_id, decode_errors=args.decode_errors)
        return

    if args.extract_id is not None:
        if not args.output:
            ap.error('--extract-id requires --output')
        do_extract_ids(args.input, args.output, args.extract_id,
                        templates_path=args.templates,
                        extract_templates=args.extract_templates,
                        max_passes=args.max_passes,
                        decode_errors=args.decode_errors)
        return

    if args.start is None or args.end is None or not args.output:
        ap.error('--start, --end, and --output are required unless --count is given')

    do_extract(args.input, args.output, args.start, args.end,
               templates_path=args.templates,
               extract_templates=args.extract_templates,
               max_passes=args.max_passes,
               decode_errors=args.decode_errors)


if __name__ == '__main__':
    try:
        main()
    except BrokenPipeError:
        # `--output - | head` and friends. Point the fd at devnull so
        # that the interpreter's own flush of stdout on the way out
        # does not raise a second time.
        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        sys.exit(1)
