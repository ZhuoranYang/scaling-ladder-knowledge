import argparse
import json

from datasets import load_dataset


DATASET_PATH = "allenai/litqa2_asta_bench"

parser = argparse.ArgumentParser(description="Evaluate responses to LitQA2 questions")
parser.add_argument(
    "--dev_trajectories",
    type=str,
    required=False,
    help="Path to the file containing development trajectories.",
)
parser.add_argument(
    "--test_trajectories",
    type=str,
    required=False,
    help="Path to the file containing test trajectories.",
)
parser.add_argument(
    "--output",
    type=str,
    help="Path to save the evaluation results as a JSON file.",
)
args = parser.parse_args()

assert args.dev_trajectories or args.test_trajectories, "At least one of --dev_trajectories or --test_trajectories must be provided."

trajectories_data = {}
output_data = {}

if args.dev_trajectories:
    data = [json.loads(line) for line in open(args.dev_trajectories, "r")]
    trajectories_data["dev"] = data
if args.test_trajectories:
    data = [json.loads(line) for line in open(args.test_trajectories, "r")]
    trajectories_data["test"] = data

for split, data in trajectories_data.items():
    eval_dataset = load_dataset(DATASET_PATH, split=split)
    answers_mapping = {d["id"]: d["ideal"] for d in eval_dataset}
    results = []
    for trajectory in data:
        trajectory_id = trajectory["id"]
        if trajectory_id not in answers_mapping:
            raise RuntimeError(f"ID {trajectory_id} not found in dataset.")
        
        if "error" in trajectory and trajectory["error"] is not None:
            correct = False
            correct_with_tool_calls = False
            processing_error = True
            instruction_error = False
            processing_error_type = "other"
            if "Max turns" in trajectory["error"]:
                processing_error_type = "Max turns exceeded"
            elif "Timed out" in trajectory["error"]:
                processing_error_type = "Timeout"
            elif "ContextWindowExceededError" in trajectory["error"]:
                processing_error_type = "Context window exceeded"
        else:
            answer_prefix = "The correct answer is:"
            instruction_error = answer_prefix.lower() not in trajectory["final_output"].lower()
            ideal_answer = answers_mapping[trajectory_id]
            answer_string = f"{answer_prefix} {ideal_answer}"
            correct = answer_string.lower() in trajectory["final_output"].lower()
            has_tool_calls = "tool_call" in [item["type"] for item in trajectory["trajectory"]]
            correct_with_tool_calls = has_tool_calls and correct
            processing_error = False
            processing_error_type = None
        results.append(
            {
                "correct": correct,
                "correct_with_tool_calls": correct_with_tool_calls,
                "processing_error": processing_error,
                "processing_error_type": processing_error_type,
                "instruction_error": instruction_error,
            }
        )

    output_data[split] = {
        "num_trajectories": len(results),
        "accuracy": sum(r["correct"] for r in results) / len(results),
        "accuracy_with_tool_calls": sum(r["correct_with_tool_calls"] for r in results) / len(results),
        "processing_errors": sum(r["processing_error"] for r in results) / len(results),
        "processing_error_types": {
            k: sum(1 for r in results if r["processing_error_type"] == k) / len(results)
            for k in set(r["processing_error_type"] for r in results)
            if k is not None
        },
        "instruction_errors": sum(r["instruction_error"] for r in results) / len(results),
    }

if args.output:
    with open(args.output, "w") as f:
        json.dump(output_data, f, indent=2)
else:
    print(json.dumps(output_data, indent=2))