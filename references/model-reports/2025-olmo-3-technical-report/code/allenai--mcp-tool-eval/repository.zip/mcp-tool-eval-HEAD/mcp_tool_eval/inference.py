import asyncio
import argparse
import json
import subprocess
import threading
import time
import socket
from typing import Optional
import requests

from tqdm import tqdm

from agents import Agent, Runner, ModelSettings
from agents import trace as trace
from agents.mcp import MCPServer, MCPServerStdio, create_static_tool_filter
from agents.extensions.models.litellm_model import LitellmModel

from mcp_tool_eval.config import SERVER_CONFIG, SYSTEM_PROMPTS

async def run(
    mcp_server: Optional[MCPServer],
    model: str,
    model_type: str,
    port: int,
    disable_thinking: bool,
    system_prompt: str,
    temperature: float,
    max_turns: int,
    data: list,
    output: str,
    max_concurrency: int,
    read_prompts_from_messages: bool
):
    if model_type == "openai":
        # Use OpenAI model with MCP server
        _model = model
        print("Using OpenAI model with MCP server.")
    else:
        model_name = model
        print(f"Using VLLM model: {model_name} on port {port}.")
        _model = LitellmModel(
            model=f"hosted_vllm/{model_name}",
            base_url=f"http://localhost:{port}/v1",
            api_key="EMPTY",
        )

    if disable_thinking:
        extra_body = {"chat_template_kwargs": {"enable_thinking": False}}
    else:
        extra_body = None
    model_settings = ModelSettings(
        # Always left-truncate inputs longer than the model's context length
        truncation="auto",
        temperature=temperature,
        extra_body=extra_body,
    )
    if mcp_server is None:
        agent = Agent(
            name="Assistant",
            instructions=system_prompt,
            model=_model,
            model_settings=model_settings,
        )
    else:
        agent = Agent(
            name="Assistant",
            instructions=system_prompt,
            model=_model,
            model_settings=model_settings,
            mcp_servers=[mcp_server],
        )
    messages = []
    ids = []
    for i, entry in enumerate(data):
        if read_prompts_from_messages is True:
            messages.append(entry["messages"][0]["content"])
        else:
            messages.append(entry["prompt"])
           
        ids.append(entry.get("id", f"query_{i}"))
    semaphore = asyncio.Semaphore(max_concurrency)

    async def process_query(id_, message):
        async with semaphore:
            result = None
            error = None
            try:
                result = await Runner.run(starting_agent=agent, input=message, max_turns=max_turns)
                final_output = result.final_output
            except Exception as e:
                print(f"Error processing query: {message}")
                print(f"Exception: {e}")
                error = str(e)
            if result:
                trajectory = []
                for item in result.new_items:
                    if item.type == "message_output_item":
                        trajectory.append(
                            {
                                "type": "message",
                                "content": {
                                    "content": item.raw_item.content[0].text,
                                    "role": item.raw_item.role,
                                }
                            }
                        )
                    elif item.type == "tool_call_item":
                        trajectory.append(
                            {
                                "type": "tool_call",
                                "content": {
                                    "name": item.raw_item.name,
                                    "arguments": item.raw_item.arguments,
                                }
                            }
                        )
                    elif item.type == "tool_call_output_item":
                        try:
                            json_output = json.loads(item.raw_item["output"])
                            trajectory.append(
                                {
                                    "type": "tool_call_output",
                                    "content": {
                                        "output": json_output,
                                        "type": "json"
                                    }
                                }
                            )
                        except json.JSONDecodeError:
                            trajectory.append(
                                {
                                    "type": "tool_call_output",
                                    "content": {
                                        "output": item.raw_item["output"],
                                        "type": "raw_text"
                                    }
                                }
                            )

                    elif item.type == "reasoning_item":
                        trajectory.append(
                            {
                                "type": "reasoning",
                                "content": item.raw_item.summary,
                            }
                        )
                    else:
                        raise ValueError(f"Unknown item type: {item.type}")
                return {
                    "id": id_,
                    "model": model,
                    "query": message,
                    "final_output": final_output,
                    "trajectory": trajectory,
                    "error": None,
                }
            else:
                return {
                    "id": id_,
                    "model": model,
                    "query": message,
                    "final_output": None,
                    "trajectory": None,
                    "error": error,
                }

    tasks = [process_query(id_, message) for id_, message in zip(ids, messages)]
    detailed_outputs = []
    for f in tqdm(asyncio.as_completed(tasks), total=len(tasks)):
        detailed_output = await f
        detailed_outputs.append(detailed_output)

    if output:
        print(f"Saving results to {output}.")
        with open(output, "w") as f:
            for item in detailed_outputs:
                f.write(json.dumps(item) + "\n")


async def main(
    model: str,
    model_type: str,
    port: int,
    disable_thinking: bool,
    mcp_server: str,
    system_prompt: str,
    temperature: float,
    max_turns: int,
    data: list,
    output: str,
    max_concurrency: int,
    read_prompts_from_messages: bool
):
    if mcp_server == "none":
        print("Not using any MCP server.")
        workflow_name = f"No MCP server with {model} on eval data"
        with trace(workflow_name=workflow_name):
            await run(
                None,
                model=model,
                model_type=model_type,
                port=port,
                disable_thinking=disable_thinking,
                system_prompt=system_prompt,
                temperature=temperature,
                max_turns=max_turns,
                data=data,
                output=output,
                max_concurrency=max_concurrency,
                read_prompts_from_messages=read_prompts_from_messages
            )
    else:
        print(f"Using MCP server: {mcp_server}.")
        server_config = SERVER_CONFIG[mcp_server]
        if "allowed_tools" in server_config:
            tool_filter = create_static_tool_filter(allowed_tool_names=server_config["allowed_tools"])
        else:
            tool_filter = None
        async with MCPServerStdio(
            cache_tools_list=True,  # Cache the tools list, for demonstration
            client_session_timeout_seconds=300,  # Large timeout for evaluation 
            params=server_config["params"],
            tool_filter=tool_filter
        ) as server:
            workflow_name = f"{mcp_server} with {model} on eval data"
            with trace(workflow_name=workflow_name):
                await run(
                    server,
                    model=model,
                    model_type=model_type,
                    port=port,
                    disable_thinking=disable_thinking,
                    system_prompt=system_prompt,
                    temperature=temperature,
                    max_turns=max_turns,
                    data=data,
                    output=output,
                    max_concurrency=max_concurrency,
                    read_prompts_from_messages=read_prompts_from_messages
                )


def start_vllm_server(
        model_name: str,
        port: int,
        tool_call_parser: str,
        reasoning_parser: str = None,
        extra_args: dict = {}
):
    vllm_args = [
        "vllm",
        "serve",
        model_name,
        "--port",
        str(port),
        "--enable-auto-tool-choice",
        "--tool-call-parser",
        tool_call_parser,
    ]
    if reasoning_parser:
        vllm_args.extend(["--reasoning-parser", reasoning_parser])
    if extra_args:
        for key, value in extra_args.items():
            vllm_args.extend([f"--{key}", str(value)])
    process = subprocess.Popen(
        vllm_args,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    
    stop_event = threading.Event()
    
    def _log_output(pipe, stop_event):
        # Read lines until stop event is set
        for line in iter(pipe.readline, ""):
            if stop_event.is_set():
                break
            else:
                print(line, end="")
        pipe.close()
        print("Server log tracking thread stopped successfully.")
    
    stdout_thread = threading.Thread(
        target=_log_output, args=(process.stdout, stop_event)
    )
    stderr_thread = threading.Thread(
        target=_log_output, args=(process.stderr, stop_event)
    )
    stdout_thread.start()
    stderr_thread.start()

    server_ready = False
    while not server_ready:
        # Check if the process has terminated unexpectedly
        if process.poll() is not None:
            # Output the captured logs
            stdout, stderr = process.communicate()
            print(stdout)
            print(stderr)
            raise Exception(
                f"Subprocess terminated unexpectedly with code {process.returncode}"
            )
        try:
            # Make a simple request to check if the server is up
            base_url = f"http://localhost:{port}/v1"
            response = requests.get(f"{base_url}/models")
            if response.status_code == 200:
                server_ready = True
                print("Server is ready!")
        except requests.exceptions.ConnectionError:
            # If the connection is not ready, wait and try again
            time.sleep(1)

    # Signal threads to stop reading output
    stop_event.set()
    return process


def stop_vllm_server(process: subprocess.Popen):
    # Terminate the vLLM server process
    print("Terminating vLLM server process.")
    process.terminate()
    try:
        process.wait(timeout=10)
        print("vLLM server process terminated successfully.")
    except subprocess.TimeoutExpired:
        print("vLLM server process did not terminate in time. Killing it.")
        process.kill()
        process.wait()
        print("vLLM server process killed.")


def _get_random_open_port():
    """
    Returns a random, available open port number.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))  # Bind to port 0 to let the OS assign an available port
        return s.getsockname()[1]  # Get the assigned port number


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Name of the model. Can either be an openai model or one served by vLLM.",
    )
    parser.add_argument(
        "--model_type",
        type=str,
        choices=["openai", "vllm"],
        default="openai",
        help="Type of model to use. 'openai' for OpenAI models, 'vllm' for models served by vLLM.",
    )
    parser.add_argument(
        "--tool_call_parser",
        type=str,
        help="Tool call parser to use if model type is vllm.",
    )
    parser.add_argument(
        "--reasoning_parser",
        type=str,
        help="Reasoning parser to use if model type is vllm and the model is a thinking model.",
    )
    parser.add_argument(
        "--extra_vllm_args",
        type=json.loads,
        default={},
        help="Extra arguments to pass to the vLLM server.",
    )
    parser.add_argument(
        "--disable_thinking",
        action="store_true",
        help="Disable thinking steps in the agent if the model is a thinking model.",
    )
    parser.add_argument(
        "--mcp_server",
        type=str,
        required=True,
        help="One of the keys from SERVER_CONFIG in eval/config.py or 'none' if not using a server.",
    )
    parser.add_argument(
        "--system_prompt",
        type=str,
        default="default",
        help="One of the keys from SYSTEM_PROMPTS in eval/config.py (default: 'default')",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=1.0,
        help="Temperature to use for sampling (default: 1.0)",
    )
    parser.add_argument(
        "--max_turns",
        type=int,
        default=10,
        help="Maximum number of turns to allow the agent to take (default: 10)"
    )
    parser.add_argument(
        "--data",
        type=str,
        required=True,
        help="HF dataset or a jsonl file containing queries.",
    )
    parser.add_argument(
        "--split",
        type=str,
        default="dev",
        help="Split of the dataset to use if HF dataset is passed. Defaults to 'dev'.",
    )
    parser.add_argument(
        "--output",
        type=str,
        help="Path to save the output results.",
    )
    parser.add_argument(
        "--max_concurrency",
        type=int,
        default=1,
        help="Maximum number of concurrent queries to run (default: 1)",
    )
    parser.add_argument(
        "--read_prompts_from_messages",
        action="store_true",
        help="Read prompts from 'messages' field instead of 'prompt' field in the dataset.",
    )
    args = parser.parse_args()
    if args.mcp_server not in SERVER_CONFIG and args.mcp_server != "none":
        raise ValueError(f"Invalid mcp_server {args.mcp_server}. Must be one of {list(SERVER_CONFIG.keys())} or 'none'.")
    if args.system_prompt not in SYSTEM_PROMPTS:
        raise ValueError(f"Invalid system_prompt {args.system_prompt}. Must be one of {list(SYSTEM_PROMPTS.keys())}.")
    if args.reasoning_parser and args.disable_thinking:
        raise ValueError("Cannot specify reasoning_parser and disable_thinking at the same time.")
    if args.data.endswith(".jsonl"):
        print(f"Reading data from file: {args.data}.")
        data = [json.loads(line) for line in open(args.data, "r")]
    else:
        print(f"Reading data from HF dataset: {args.data}.")
        from datasets import load_dataset
        dataset = load_dataset(args.data, split=args.split)
        data = [item for item in dataset]

    if args.model_type == "vllm":
        port = _get_random_open_port()
        print(f"Using random open port {port} for vLLM server.")
        process = start_vllm_server(
            model_name=args.model,
            port=port,
            tool_call_parser=args.tool_call_parser,
            reasoning_parser=args.reasoning_parser,
            extra_args=args.extra_vllm_args
        )
        try:
            asyncio.run(
                main(
                    model=args.model, 
                    model_type=args.model_type, 
                    port=port,
                    disable_thinking=args.disable_thinking,
                    mcp_server=args.mcp_server,
                    system_prompt=SYSTEM_PROMPTS[args.system_prompt],
                    temperature=args.temperature,
                    max_turns=args.max_turns,
                    data=data, 
                    output=args.output, 
                    max_concurrency=args.max_concurrency,
                    read_prompts_from_messages=args.read_prompts_from_messages
                )
            )
        finally:
            stop_vllm_server(process)
    else:
        asyncio.run(
            main(
                model=args.model, 
                model_type=args.model_type, 
                port=None,
                disable_thinking=args.disable_thinking,
                mcp_server=args.mcp_server,
                system_prompt=SYSTEM_PROMPTS[args.system_prompt],
                temperature=args.temperature,
                max_turns=args.max_turns,
                data=data, 
                output=args.output, 
                max_concurrency=args.max_concurrency,
                read_prompts_from_messages=args.read_prompts_from_messages
            )
        )
