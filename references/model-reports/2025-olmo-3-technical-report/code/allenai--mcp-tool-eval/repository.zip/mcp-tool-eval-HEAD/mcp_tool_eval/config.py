import os


def get_asta_args():
    asta_args = [
        "mcp-remote",
        "https://asta-tools.allen.ai/mcp/v1",
    ]
    s2_api_key = os.getenv("S2_API_KEY", None)
    if s2_api_key:
        print("Using S2 API key for Asta Tools authentication.")
        asta_args.extend([
            "--header",
            f"x-api-key:{s2_api_key}",
        ])
    return asta_args


def get_webmcp_env():
    s2_api_key = os.getenv("S2_API_KEY", None)
    if not s2_api_key:
        raise ValueError("S2_API_KEY environment variable is required for webmcp.")
    serper_api_key = os.getenv("SERPER_API_KEY", None)
    if not serper_api_key:
        raise ValueError("SERPER_API_KEY environment variable is required for webmcp.")
    return {
        "S2_API_KEY": s2_api_key,
        "SERPER_API_KEY": serper_api_key,
    }


# LazyDict for lazy evaluation of config values
class LazyDict(dict):
    def __getitem__(self, key):
        value = super().__getitem__(key)
        if callable(value):
            value = value()
            self[key] = value  # Cache the result
        return value

SERVER_CONFIG = LazyDict({
    "asta-tools": lambda: {
        "params": {
            "command": "npx",
            "args": get_asta_args(),
        },
    },
    "dr-tulu": lambda: {
        "params": {
            "command": "python",
            "args": ["-m", "dr_agent.mcp_backend.main", "--transport", "stdio"],
            "env": get_webmcp_env(),
        },
        "allowed_tools": [
            "semantic_scholar_snippet_search",
            "serper_google_webpage_search",
            "serper_fetch_webpage_content",
        ]
    },
})


OLMO3_LITQA2_SYSTEM_PROMPT = "You are a helpful function-calling AI assistant. You are provided with function signatures within <functions></functions> XML tags. You may call one or more functions to assist with the user query. Output any function calls within <function_calls></function_calls> XML tags. Don't make assumptions about what values to plug into functions."

OLMO3_SIMPLEQA_SYSTEM_PROMPT_NO_THINKING = "You are a helpful function-calling AI assistant. You are provided with function signatures within <functions></functions> XML tags. You may call one or more functions to assist with the user query. Output any function calls within <function_calls></function_calls> XML tags. Don't make assumptions about what values to plug into functions. You provide research assistance by answering questions via iterative reasoning and research.\n\n- Use external tools as needed. Format calls like: tool_name(query=...) (tools listed below).\n- Only answer when you have enough information for a complete response. If the problem asks for a specific, short-form answer, you can also put the answer string in the \\boxed\\{..\\} format.\n- Search results are provided as JSON containing one or more search results, each of which has a title, text, and optional URL. Please use these retrieved results to enhance your answer.\n\nNow, please think and search iteratively to find the answer to the following question:"

SYSTEM_PROMPTS = {
    "default": "You are a helpful assistant.",
    "olmo3_litqa2": OLMO3_LITQA2_SYSTEM_PROMPT,
    "olmo3_simpleqa_no_thinking": OLMO3_SIMPLEQA_SYSTEM_PROMPT_NO_THINKING,
}
