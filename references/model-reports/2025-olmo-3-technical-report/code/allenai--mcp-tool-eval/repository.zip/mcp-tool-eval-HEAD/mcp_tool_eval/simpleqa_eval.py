import argparse
import json
import os
import re
import pandas
from tqdm import tqdm
from datasets import load_dataset
from openai import OpenAI

GRADER_TEMPLATE = """
Your job is to look at a question, a gold target, and a predicted answer, and then assign a grade of either ["CORRECT", "INCORRECT", "NOT_ATTEMPTED"].
First, I will give examples of each grade, and then you will grade a new example.


The following are examples of CORRECT predicted answers.
```
Question: What are the names of Barack Obama's children?
Gold target: Malia Obama and Sasha Obama
Predicted answer 1: sasha and malia obama
Predicted answer 2: most people would say Malia and Sasha, but I'm not sure and would have to double check
Predicted answer 3: Barack Obama has two daughters. Their names are Malia Ann and Natasha Marian, but they are commonly referred to as Malia Obama and Sasha Obama. Malia was born on July 4, 1998, and Sasha was born on June 10, 2001.
```
These predicted answers are all CORRECT because:
    - They fully contain the important information in the gold target.
    - They do not contain any information that contradicts the gold target.
    - Only semantic meaning matters; capitalization, punctuation, grammar, and order don't matter.
    - Hedging and guessing are permissible, provided that the gold target is fully included and the response contains no incorrect information or contradictions.


The following are examples of INCORRECT predicted answers.
```
Question: What are the names of Barack Obama's children?
Gold target: Malia and Sasha
Predicted answer 1: Malia.
Predicted answer 2: Malia, Sasha, and Susan.
Predicted answer 3: Barack Obama does not have any children.
Predicted answer 4: I think it's either Malia and Sasha. Or it could be Malia and Jackie. Or it could be Joey and Malia.
Predicted answer 4: While I don't know their exact names, I can tell you that Barack Obama has three children.
Predicted answer 5: It's possible you may mean Betsy and Olivia. However, you should clarify further details with updated references if necessary. Is that the correct answer?
Predicted answer 6: It may be the case that Obama's child is named James. However, it's recommended to confirm the most accurate and updated information since this could change over time. This model may not always reflect the most current information.
```
These predicted answers are all INCORRECT because:
    - A factual statement in the answer contradicts the gold target. Incorrect statements that have some hedging (e.g., "it is possible that", "although i'm not sure, i think") are also considered incorrect.


The following are examples of NOT_ATTEMPTED predicted answers.
```
Question: What are the names of Barack Obama's children?
Gold target: Malia and Sasha
Predicted answer 1: I don't know.
Predicted answer 2: I need more context about which Obama you are talking about.
Predicted answer 3: Without researching the web, I cannot answer this question. However, I can tell you that Barack Obama has two children.
Predicted answer 4: Barack Obama has two children. I know that one of them is Malia, but I'm not sure about the other one.
```
These predicted answers are all NOT_ATTEMPTED because:
    - The important information in the gold target is not included in the answer.
    - No statements in the answer contradict the gold target.


Also note the following things:
- For grading questions where the gold target is a number, the predicted answer needs to be correct to the last significant figure in the gold answer. For example, consider a question "How many citations does the Transformer Paper have?" with gold target "120k". 
    - Predicted answers "120k", "124k", and 115k" are all CORRECT. 
    - Predicted answers "100k" and "113k" are INCORRECT. 
    - Predicted answers "around 100k" and "more than 50k" are considered NOT_ATTEMPTED because they neither confirm nor contradict the gold target.
- The gold target may contain more information than the question. In such cases, the predicted answer only needs to contain the information that is in the question.
    - For example, consider the question "What episode did Derek and Meredith get legally married in Grey's Anatomy?" with gold target "Season 7, Episode 20: White Wedding". Either "Season 7, Episode 20" or "White Wedding" would be considered a CORRECT answer.
- Do not punish predicted answers if they omit information that would be clearly inferred from the question.
    - For example, consider the question "What city is OpenAI headquartered in?" and the gold target "San Francisco, California". The predicted answer "San Francisco" would be considered CORRECT, even though it does not include "California".
    - Consider the question "What award did A pretrainer's guide to training data: Measuring the effects of data age, domain coverage, quality, & toxicity win at NAACL '24?", the gold target is "Outstanding Paper Award". The predicted answer "Outstanding Paper" would be considered CORRECT, because "award" is presumed in the question.
    - For the question "What is the height of Jason Wei in meters?", the gold target is "1.73 m". The predicted answer "1.75" would be considered CORRECT, because meters is specified in the question.
    - For the question "What is the name of Barack Obama's wife?", the gold target is "Michelle Obama". The predicted answer "Michelle" would be considered CORRECT, because the last name can be presumed.
- Do not punish for typos in people's name if it's clearly the same name. 
    - For example, if the gold target is "Hyung Won Chung", you can consider the following predicted answers as correct: "Hyoong Won Choong", "Hyungwon Chung", or "Hyun Won Chung".


Here is a new example. Simply reply with either CORRECT, INCORRECT, NOT ATTEMPTED. Don't apologize or correct yourself if there was a mistake; we are just trying to grade the answer.
```
Question: {question}
Gold target: {target}
Predicted answer: {predicted_answer}
```

Grade the predicted answer of this new question as one of:
A: CORRECT
B: INCORRECT
C: NOT_ATTEMPTED

Just return the letters "A", "B", or "C", with no text around it.
""".strip()

CHOICE_LETTERS = ["A", "B", "C"]
CHOICE_STRINGS = ["CORRECT", "INCORRECT", "NOT_ATTEMPTED"]
CHOICE_LETTER_TO_STRING = dict(zip(CHOICE_LETTERS, CHOICE_STRINGS))


def grade_with_simpleqa_judge(question: str, target: str, predicted_answer: str, grader_client: OpenAI, model_name: str = "gpt-4") -> str:
    """Grade a predicted answer using the SimpleQA judge template."""
    grader_prompt = GRADER_TEMPLATE.format(
        question=question,
        target=target,
        predicted_answer=predicted_answer,
    )
    
    try:
        completion = grader_client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "user", "content": grader_prompt}
            ],
            temperature=0.0,
        )
        grading_response = completion.choices[0].message.content or ""
        
        # Extract grade letter (A, B, or C)
        match = re.search(r"(A|B|C)", grading_response)
        return match.group(0) if match else "C"  # Default to "NOT_ATTEMPTED" if no match
    except Exception as e:
        print(f"Error in grading: {e}")
        return "C"  # Default to "NOT_ATTEMPTED" on error

parser = argparse.ArgumentParser(description="Evaluate responses to SimpleQA questions using OpenAI judge")
parser.add_argument(
    "--dev_trajectories",
    type=str,
    required=False,
    help="Path to the file containing development trajectories.",
)
parser.add_argument(
    "--test_trajectories",
    type=str,
    required=False,
    help="Path to the file containing test trajectories.",
)
parser.add_argument(
    "--output",
    type=str,
    help="Path to save the evaluation results as a JSON file.",
)
parser.add_argument(
    "--grader_model",
    type=str,
    default="gpt-4.1-2025-04-14",
    help="Model name for grading/judging responses",
)
parser.add_argument(
    "--debug",
    action="store_true",
    help="Set true if you want to skip instances with error outputs"
)
parser.add_argument(
    "--full",
    action="store_true",
    help="Set true if you run full simpleqa eval"
)
args = parser.parse_args()

# Initialize grader client as specified by user
grader_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

assert args.dev_trajectories or args.test_trajectories, "At least one of --dev_trajectories or --test_trajectories must be provided."

trajectories_data = {}
output_data = {}

if args.dev_trajectories:
    data = [json.loads(line) for line in open(args.dev_trajectories, "r")]
    trajectories_data["dev"] = data
if args.test_trajectories:
    data = [json.loads(line) for line in open(args.test_trajectories, "r")]
    trajectories_data["test"] = data

for split, data in trajectories_data.items():
    if args.full is True:
        eval_dataset = load_dataset("allenai/simpleqa_full")["test"]
    else:
        eval_dataset = load_dataset("akariasai/sampled_simpleqa")["test"]
    # Create answers mapping using problem as key and answer as value
    answers_mapping = {}
    for row in eval_dataset:
        # Use the problem text as the key to match with trajectory data
        answers_mapping[row["messages"][-1]["content"]] = row["ground_truth"]
    results = []
    for trajectory in tqdm(data):
        trajectory_id = trajectory["id"]
        
        # Get the question from trajectory data
        question = trajectory.get("question") or trajectory.get("query") or trajectory.get("prompt") or ""
        
        # Find the ideal answer by matching the question
        ideal_answer = None
        for prob, ans in answers_mapping.items():
            if prob.strip() == question.strip():
                ideal_answer = ans
                break
        
        if ideal_answer is None:
            print(f"Warning: Question for ID {trajectory_id} not found in dataset.")
            # Skip this trajectory or use a default behavior
            results.append({
                "id": trajectory_id,
                "correct": False,
                "processing_error": True,
                "instruction_error": False,
            })
            if args.debug is True:
                continue
        
        if "error" in trajectory and trajectory["error"] is not None:
            correct = False
            processing_error = True
            instruction_error = False
            grade_letter = "C"  # Default to NOT_ATTEMPTED for errors
        else:
            # Extract the predicted answer from final_output
            predicted_answer = trajectory["final_output"]
            # Use SimpleQA judge to grade the answer
            grade_letter = grade_with_simpleqa_judge(
                question=question,
                target=ideal_answer,
                predicted_answer=predicted_answer,
                grader_client=grader_client,
                model_name=args.grader_model
            )
            
            # Convert grade letter to boolean
            correct = (grade_letter == "A")  # A = CORRECT
            is_incorrect = (grade_letter == "B")  # B = INCORRECT  
            is_not_attempted = (grade_letter == "C")  # C = NOT_ATTEMPTED
            
            processing_error = False
            instruction_error = False  # Not using instruction error for SimpleQA
            
        results.append(
            {
                "id": trajectory_id,
                "correct": correct,
                "processing_error": processing_error,
                "instruction_error": instruction_error,
                "grade": CHOICE_LETTER_TO_STRING.get(grade_letter, "NOT_ATTEMPTED") if not processing_error else "ERROR",
            }
        )

    output_data[split] = {
        "num_trajectories": len(results),
        "accuracy": sum(r["correct"] for r in results) / len(results),
        "processing_error_rate": sum(r["processing_error"] for r in results) / len(results),
        "instruction_error_rate": sum(r["instruction_error"] for r in results) / len(results),
    }

if args.output:
    with open(args.output, "w") as f:
        json.dump(output_data, f, indent=2)
else:
    print(json.dumps(output_data, indent=2))