# Copyright (c) 2024, NVIDIA CORPORATION. All rights reserved.

from dataclasses import dataclass
from typing import Optional

import torch

from .utils import is_torch_min_version

VALID_SHARDING_STRATEGIES = ("no_shard", "optim", "optim_grads", "optim_grads_params")


@dataclass
class DistributedDataParallelConfig:
    """
    Megatron-FSDP `fully_shard` API sub-configuration
    derived from Megatron-Core DistributedDataParallel.
    """

    overlap_grad_reduce: bool = False
    """If true, overlap grad all-reduce / reduce-scatter with backward compute."""

    overlap_param_gather: bool = False
    """If true, overlap param all-gather with forward compute."""

    check_for_nan_in_grad: bool = False
    """
    If True, check for NaNs and Infs in gradients _before_ communication collective.
    Invoked by `start_grad_sync` such as in the Megatron-LM DDP training API.
    """

    bucket_size: Optional[int] = None
    """Maximum number of parameters in each bucket. If unspecified, MCore uses a default
       value of max(40000000, 1000000 * dp_size) parameters (larger DP sizes need larger
       buckets to ensure collectives do not become latency-bound)."""

    average_in_collective: bool = False
    """If true, compute average in collective directly, as opposed to dividing by the
       dp_size first and then computing sum in the collective."""

    fp8_param_gather: bool = False
    """If true, keep the compute param in fp8 (do not use any other intermediate dtype) and
       perform the param all-gather in fp8."""

    data_parallel_sharding_strategy: str = 'no_shard'
    """Sharding strategy for FSDP. Valid values are 'no_shard', 'optim',
      'optim_grads', 'optim_grads_params'."""

    expert_data_parallel_sharding_strategy: Optional[str] = None
    """Sharding strategy applied to expert (MoE) parameters on DP-Shard. Valid values are
      'no_shard', 'optim', 'optim_grads', 'optim_grads_params'. When set,
      `data_parallel_sharding_strategy` only applies to non-expert parameters, which allows
      trading DP-Shard communication against memory separately for the two parameter classes
      (e.g. 'optim' on non-experts and 'optim_grads_params' on experts). Expert parameters are
      already sharded over a narrower DP group than non-expert parameters when expert
      parallelism is enabled, so the two classes have very different traffic-per-byte.
      None is replaced with `data_parallel_sharding_strategy` during initialization."""

    gradient_reduce_div_fusion: bool = True
    """If true, perform gradient reduce and division fusion. Requires a single gradient
    communication dtype per coalesced bucket group when enabled."""

    suggested_communication_unit_size: int = None
    """Specifies the number of elements to communicate at once during
      FSDP (Fully Sharded Data Parallel) operations. 
      This flag also affects FSDP all-gather prefetch behavior. Setting a larger
      value increases the communication buffer size, while a smaller value
      disables prefetching and may degrade performance. Adjust this value
      based on your system's memory and performance requirements."""

    keep_fp8_transpose_cache: bool = False
    """If true, keep the fp8 transpose cache when using Megatron FSDP."""

    nccl_ub: bool = False
    """If true, allocate and register NCCL userbuffer for param and grad buffer.
      This flag enables SM efficient nccl algorithm that could improve the performance
      of FSDP and DP with comm_overlap. This flag will be much more effective when used
      together with sharp. 
      The follwoing will be the expected number of SM usage for various cases.
      (Note that this is just a reference number and the number of SM usage could vary 
      on message size, communication domain size and nccl version.)
      | Communication domain | use_sharp | SM usage of "AG/RS" |
      |----------------------|-----------|---------------------|
      | NVL                  | N/A       | 4 / 5               |
      | NVL+IB               | False     | 16 / 16             |
      | NVL+IB               | True      | 6 / 6               |
      | IB                   | False     | 1 / 4               |
      | IB                   | True      | 1 / 1               |
    """

    fsdp_double_buffer: bool = False
    """If true, use persistently allocated double buffers for the 
      temporary memory needed in the Megatron FSDP communications.
      This option will cause additional memory overhead, however, it is necessary for
      to register user buffer (nccl_ub=True) for the Megatron FSDP. 
      This option will be automatically set to True when nccl_ub=True.
    """

    fsdp_all_gather_in_start_param_sync: bool = True
    """
    If True, use all-gather during the initial Megatron-FSDP parameter
    synchronization step. This can increase overlap between the first
    parameter all-gather and computation, helping to better hide the
    initial communication cost. Should be deactivated when using
    full-iteration CG, or partial CG if AG/RS is launched beyond the
    CG capture scope but is waited on during the capture scope.
    """

    fsdp_db_use_persist_buf_on_alloc_fail: bool = False
    """Whether to fall back to persistent buffer when a bucket does not
       fit FSDP double buffer size. If true, FSDP will use the persistently 
       allocated buffer for the bucket that does not fit, it will enable NCCL 
       user buffer with the cost of more memory usage. If false, FSDP will use
       Dynamic memory allocator, NCCL user buffer won't not enabled, which 
       usually leads to low performance. 
    """

    outer_dp_sharding_strategy: str = 'no_shard'
    """
    Sharding strategy for outer data parallel group in Hybrid Sharded Data Parallel (HSDP) mode.
    Valid values are 'no_shard', 'optim'. This option is only effective when Hybrid FSDP is enabled.
    """

    disable_symmetric_registration: bool = False
    """If true, disable symmetric (window) registration for NCCL userbuffer registration.
      This option will force to use conventional (local) userbuffer registration 
      when nccl_ub is set.
    """

    fsdp_manual_registration: bool = False
    """If true, manually register the FSDP communication buffers to NCCL user buffer.
      This option is only effective when use_megatron_fsdp and nccl_ub is set.
      For symmetric registration with large models, the registration itself can take 
      a significant amount of time. This option minimizes the number of registration calls
      to minimize the registration time.
    """

    megatron_fsdp_main_params_dtype: Optional[torch.dtype] = torch.float32
    """Data type for the main weight buffer utilized for distributed optimization
      and quantization with Megatron-FSDP. If set to None, the model compute weight
      buffer will take the role of the main weights, or when no sharding is applied,
      the native model weights become the main weights. Defaults to torch.float32.
    """

    megatron_fsdp_main_grads_dtype: Optional[torch.dtype] = None
    """Data type for the main gradient buffer utilized for distributed optimization with
      Megatron-FSDP. If set to None, main gradients will match the dtype of the model
      compute parameters specified by the user model. Defaults to None.
    """

    megatron_fsdp_grad_comm_dtype: Optional[torch.dtype] = None
    """Data type for gradient gather / scatter communications. Can be utilized to reduce
      communication latency, but adds overhead for type-casting and copy operations.
      If using NCCL UBR v2.27+, gradient reduction may be performed in high-precision
      depending on the network domain (NVLink or IB), and can enable mixed-precision
      communication and accumulation, e.g. setting grad_comm_dtype to `BF16` can support
      `FP32` reduction even though we have `BF16` input and output communication buffers.
      If set to None, the `main_grads_dtype` is used. If using HSDP (either DP-Replicate
      or DP-Outer in `outer_dp_sharding_strategy`), `no_shard`, `optim`, or a
      `FixedPoolAllocator` (`fsdp_double_buffer`), allocating `dtype`-custom gradient
      communication buffers (per FSDP group) adds memory overhead. Defaults to None.
      No additional memory is allocated when `grad_comm_dtype == main_grads_dtype`.
    """

    megatron_fsdp_use_decoupled_grad: bool = False
    """If true, Megatron-FSDP's ParamAndGradBuffer uses the precision-aware optimizer
      gradient path (e.g. `decoupled_grad` on optimizer parameters) instead of casting
      main gradients to parameter dtype for `.grad`.
    """

    megatron_fsdp_cuda_graph_mode: bool = False
    """If set to True, Megatron-FSDP will practice CUDA graph-safe operations, such as
    not dereferencing `param.grad` after the optimizer step to preserve references for
    CUDA graph replay. Can affect memory utilization in some cases, such as when the
    gradient shard is not a view of the Megatron-FSDP sharded gradient buffer, so
    FusedAdam(use_decoupled_grad=True) + megatron_fsdp_use_decoupled_grad=True or
    setting megatron_fsdp_main_params_dtype == megatron_fsdp_main_grads_dtype is
    recommended to avoid casting the gradient to the parameter precision and creating
    a casted-copy of the gradient shard that cannot be dereferenced due to replay.
    """

    megatron_fsdp_enable_fine_grained_param_gather: bool = False
    """If set to True, enables fine-grained parameter gathering for Megatron-FSDP.
      This feature increases the overlap between parameter all-gather and forward computation,
      at the cost of more frequent communication calls.
      For MXFP8, this approach helps save memory during fine-grained activation
      recomputation, because MXFP8 forward and backward passes use different
      parameter representations (rowwise data for forward, colwise data for backward).
      In this mode, only the rowwise parameters of modules involved in recomputation
      will be unsharded.
    """

    megatron_fsdp_max_pool_double_buffer: bool = False
    """
    Builds a double buffer maxpool that can be recycled across asymmetric / hybrid
    FSDP units, instead of the symmetrical FixedPoolAllocator that requires exact
    parity between FSDP units, when using fsdp_double_buffer=True. Enables NCCL
    user buffer registration and CUDA graph replay for models with asymmetrical
    FSDP units, such as models with hybrid architectures (e.g. Mamba and MoE).
    """

    megatron_fsdp_padded_shards: bool = True
    """Megatron-FSDP v2 only. If true (default), pad each parameter group so every rank
    gets an equal shard. If false, pack the group without padding and split it into
    generally unequal per-rank shards at row boundaries (32-row block boundaries for
    MXFP8), which saves the padding memory and communication but is incompatible with
    nccl_ub (symmetric memory).
    """

    hfsdp_param_gather_overlap: bool = False
    """If true, pipeline HFSDP parameter gathers across the DP-Outer and DP-Inner
    communication domains. DP-Inner retains its size-based prefetch policy, while
    DP-Outer is prefetched one additional FSDP unit beyond the DP-Inner frontier.
    Only effective with ``outer_dp_sharding_strategy='optim'``.
    """

    def __post_init__(self):
        import os

        """Check the validity of the config."""
        if self.expert_data_parallel_sharding_strategy is None:
            self.expert_data_parallel_sharding_strategy = self.data_parallel_sharding_strategy
        for field_name in [
            "data_parallel_sharding_strategy",
            "expert_data_parallel_sharding_strategy",
        ]:
            strategy = getattr(self, field_name)
            if strategy not in VALID_SHARDING_STRATEGIES:
                raise ValueError(
                    f"[Megatron-FSDP] Invalid {field_name}: {strategy}. "
                    f"Valid values are {VALID_SHARDING_STRATEGIES}."
                )

        if self.nccl_ub and not is_torch_min_version("2.11.0a0"):
            if 'expandable_segments:True' in os.getenv('PYTORCH_CUDA_ALLOC_CONF', '').split(','):
                raise ValueError(
                    "PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True is currently not supported "
                    "with nccl_ub due to compatibility issue with torch.cuda.MemPool API."
                )

        if self.megatron_fsdp_max_pool_double_buffer:
            # MaxPoolAllocator is a type of double-buffer allocator.
            self.fsdp_double_buffer = True
