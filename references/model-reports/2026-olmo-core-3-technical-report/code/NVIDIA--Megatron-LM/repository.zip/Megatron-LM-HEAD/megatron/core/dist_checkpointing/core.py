# Copyright (c) 2022-2023, NVIDIA CORPORATION.  All rights reserved.

""" Module for managing distributed checkpoints metadata. """

import dataclasses
import json
import os
from dataclasses import asdict, dataclass
from typing import Optional

from megatron.core.msc_utils import maybe_msc

CONFIG_FNAME = 'metadata.json'


class CheckpointingException(Exception):
    """Base checkpointing related exception"""

    pass


@dataclass
class CheckpointingConfig:
    """Documents backends used in the checkpoint.

    Checkpoint config keeps track of formats used for storing the sharded tensors
    (sharded_backend).

    Note that versioning is not for the checkpoint content (which is application specific),
    but for the checkpoint format itself.
    """

    sharded_backend: str
    sharded_backend_version: int = 1


def check_is_distributed_checkpoint(checkpoint_dir):
    """Checks if `metadata.json` exists in the checkpoint and is a valid config.

    Args:
        checkpoint_dir: checkpoint directory

    Returns:
        bool: True if `metadata.json` exists in the checkpoint and is a valid config.
    """
    return maybe_load_config(checkpoint_dir) is not None


def maybe_load_config(checkpoint_dir: str) -> Optional[CheckpointingConfig]:
    """Returns checkpoint config if `checkpoint_dir` is a distributed checkpoint and None otherwise

    Args:
        checkpoint_dir: checkpoint directory

    Returns:
        CheckpointingConfig (optional): None if checkpoint is not a valid distributed checkpoint
    """
    config_path = os.path.join(checkpoint_dir, CONFIG_FNAME)
    if checkpoint_dir:
        if not maybe_msc.os.path.exists(config_path):
            return None
        with maybe_msc.open(config_path) as f:
            config_dict = json.load(f)
        known_fields = {f.name for f in dataclasses.fields(CheckpointingConfig)}
        return CheckpointingConfig(**{k: v for k, v in config_dict.items() if k in known_fields})
    return None


def save_config(config: CheckpointingConfig, checkpoint_dir: str):
    """Save given config to checkpoint directory.

    Args:
        config: checkpoint config
        checkpoint_dir: checkpoint directory

    Returns:
        None
    """
    config_path = os.path.join(checkpoint_dir, CONFIG_FNAME)
    with maybe_msc.open(config_path, 'w') as f:
        json.dump(asdict(config), f)
