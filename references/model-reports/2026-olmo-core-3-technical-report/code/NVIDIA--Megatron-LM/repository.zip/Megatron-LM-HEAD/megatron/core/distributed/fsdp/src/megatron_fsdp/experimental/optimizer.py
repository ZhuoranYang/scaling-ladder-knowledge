# Copyright (c) 2026, NVIDIA CORPORATION. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Optimizer adapter for the minimal Megatron-FSDP path."""

from itertools import chain
from typing import Any, NamedTuple

import torch
from torch import nn

from .parameter_group import get_containing_parameter_group, sync_model_weights_from_main_weights

__all__ = ["fully_shard_optimizer", "init_optimizer_state"]


def init_optimizer_state(optimizer: torch.optim.Optimizer) -> None:
    """Allocate optimizer state so a DCP load has DTensors to fill.

    :func:`~torch.distributed.checkpoint.state_dict.get_optimizer_state_dict` initializes empty
    optimizer state via torch's ``_init_optim_state``, but that assigns a parameter-dtype gradient.
    A Megatron-FSDP sharded parameter advertises the FSDP gradient dtype through ``grad_dtype``,
    which differs from the (main-weight) parameter dtype under mixed precision, and rejects a
    mismatched gradient. So initialize the state here with a ``grad_dtype``-matched zero gradient;
    the subsequent load overwrites it. This is a no-op once the state exists (for example after a
    training step).

    TODO: this function becomes unnecessary once torch's ``_init_optim_state`` honors a parameter's
    ``grad_dtype`` when it allocates the placeholder gradient (``torch.zeros_like(param)`` in
    ``torch/distributed/checkpoint/state_dict.py``); an upstream issue is being filed.

    Args:
        optimizer: Optimizer whose (possibly empty) state should be materialized.
    """
    if optimizer.state:
        return
    for group in optimizer.param_groups:
        for param in group["params"]:
            if param.grad is None:
                grad_dtype = getattr(param, "grad_dtype", None) or param.dtype
                param.grad = torch.zeros_like(param, dtype=grad_dtype)
    optimizer.step()
    optimizer.zero_grad()


def fully_shard_optimizer(
    optimizer: torch.optim.Optimizer, *, precision_aware: bool = False
) -> None:
    """Attach FSDP-aware step hooks to an optimizer instance.

    The adapted optimizer preserves its existing parameter groups, temporarily
    casts gradients around optimizer steps for FSDP sharded parameters whose
    data dtype differs from their grad dtype unless the optimizer is precision
    aware, and refreshes compute weights after each optimizer step.

    Alternatives considered:
        - Monkey-patching optimizer methods directly on the instance. This is
          more invasive and harder to compose than hooks.
        - Generating an FSDP-specific subclass per ``torch.optim.Optimizer``.
          This adds extra class-generation machinery, but would let us
          instrument ``zero_grad`` and ``__init__`` as well as ``step`` if needed.
        - Casting from ``main_grad.dtype`` to ``main_weight.dtype`` after the
          last microbatch and casting back before the first microbatch. This
          should be done from a root post-backward callback if needed later, so
          users do not need to call ``fully_shard_optimizer`` on an existing
          ``torch.optim.Optimizer``.
        - Letting the user set ``main_weight`` and ``main_grad`` to the same
          dtype. This is enough for an FSDP2 drop-in replacement path and lets
          optimizers stay unaware of FSDP precision handling.

    Args:
        optimizer: Optimizer instance to adapt in place.
        precision_aware: Whether the optimizer accepts FSDP's mixed-precision
            gradients without temporary casting.
    """

    class CastedGrad(NamedTuple):
        """Original grad tensor temporarily replaced during an optimizer step."""

        parameter: nn.Parameter
        original_grad: torch.Tensor

    def set_grad(parameter: nn.Parameter, grad: torch.Tensor) -> None:
        """Install a grad with matching grad_dtype on a sharded parameter."""
        # Clear the existing grad before switching grad_dtype; the sharded
        # parameter cannot advertise a new grad dtype while the old grad
        # object with the previous dtype is still attached.
        parameter.grad = None
        parameter.grad_dtype = grad.dtype
        parameter.grad = grad

    casted_grads: list[CastedGrad] = []

    def step_pre_hook(
        hooked_optimizer: torch.optim.Optimizer, args: tuple[Any, ...], kwargs: dict[str, Any]
    ) -> None:
        closure = kwargs.get("closure")
        if closure is None and len(args) > 1:
            closure = args[1]
        if closure is not None:
            # Step hooks run outside the base optimizer step, but closures run inside it.
            # We need to cast grads after the closure materializes them and before the
            # optimizer consumes them, which this hook-only adapter cannot intercept.
            raise NotImplementedError(
                "fully_shard_optimizer does not support optimizer.step closures."
            )
        assert not casted_grads
        for group in hooked_optimizer.param_groups:
            for parameter in group["params"]:
                if not isinstance(parameter, nn.Parameter):
                    raise TypeError(
                        "fully_shard_optimizer expected optimizer param groups to contain "
                        f"nn.Parameter values, got {type(parameter)!r}."
                    )
                if precision_aware or get_containing_parameter_group(parameter) is None:
                    continue
                if parameter.grad is None:
                    continue
                if parameter.grad.dtype == parameter.dtype:
                    continue

                casted_grads.append(CastedGrad(parameter, parameter.grad))
                set_grad(parameter, parameter.grad.to(dtype=parameter.dtype))

    def step_post_hook(
        hooked_optimizer: torch.optim.Optimizer, args: tuple[Any, ...], kwargs: dict[str, Any]
    ) -> None:
        del args, kwargs
        for parameter, original_grad in casted_grads:
            set_grad(parameter, original_grad)
        casted_grads.clear()

        sync_model_weights_from_main_weights(
            chain.from_iterable(group["params"] for group in hooked_optimizer.param_groups)
        )

    optimizer.register_step_pre_hook(step_pre_hook)
    optimizer.register_step_post_hook(step_post_hook)
