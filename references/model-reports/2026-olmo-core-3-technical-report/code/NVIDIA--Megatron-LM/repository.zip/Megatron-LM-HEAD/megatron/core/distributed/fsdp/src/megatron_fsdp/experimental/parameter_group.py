# Copyright (c) 2026, NVIDIA CORPORATION. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Parameter-group runtime state for the minimal Megatron-FSDP path."""

from collections.abc import Iterable
from contextlib import nullcontext
from dataclasses import dataclass
from weakref import ReferenceType, ref

import torch
import torch.distributed._symmetric_memory as symm_mem
from torch import nn
from torch.distributed import DeviceMesh
from torch.distributed.tensor import Partial, Replicate
from torch.distributed.tensor.placement_types import Placement

from ..mixed_precision import MixedPrecisionPolicy
from ..utils import HAVE_TE
from . import layout_builder
from .dbuffer import DBuffer
from .layout import GlobalLayout
from .module_utils import copy_parameter_attributes, get_parameter_owner
from .phase import Phase
from .placement import BlockAtomic, RowAtomic, ShardLayout, TensorAtomic

if HAVE_TE:
    from .quantized_dbuffer import QuantizedDBuffer, effective_dtype, update_mxfp8_tensor
else:
    QuantizedDBuffer = DBuffer

    def effective_dtype(tensor: torch.Tensor) -> torch.dtype:
        """Without TE, all parameters use their native storage dtype."""
        return tensor.dtype

    def update_mxfp8_tensor(*args, **kwargs) -> None:
        """Without TE, no parameter group holds MXFP8 weights to update."""
        raise RuntimeError("update_mxfp8_tensor requires Transformer Engine.")


_CONTAINING_PARAMETER_GROUP_ATTR = "_mfsdp_parameter_group"


def _contains_any_placement_type(
    *placement_groups: tuple[Placement, ...], placement_types: type | tuple[type, ...]
) -> bool:
    """Return whether any placement in ``placement_groups`` matches ``placement_types``."""
    for placements in placement_groups:
        for placement in placements:
            if isinstance(placement, placement_types):
                return True
    return False


def sync_model_weights_from_main_weights(parameters: Iterable[nn.Parameter]) -> None:
    """Sync MFSDP compute weights for parameter groups represented by ``parameters``.

    Parameters outside the experimental MFSDP path are ignored. A parameter group
    may own multiple parameters, but its compute-weight buffer is synced once.
    """
    seen_parameter_groups = set()
    for parameter in parameters:
        if (parameter_group := get_containing_parameter_group(parameter)) is None:
            continue
        if parameter_group in seen_parameter_groups:
            continue
        seen_parameter_groups.add(parameter_group)
        parameter_group.sync_model_weight_from_main_weight()


@dataclass(frozen=True, eq=False)
class FsdpParameter:
    """One physical parameter and its FSDP runtime representations."""

    # Tied weights register one physical parameter under multiple FQNs, all relative
    # to the containing group's owning_module.
    fqns: tuple[str, ...]
    sharded: nn.Parameter
    unsharded: nn.Parameter


class FsdpParameterGroup:
    """A dtype and requires-grad homogeneous group of FSDP-owned parameters."""

    # FsdpModule owns its parameter groups, so this backedge must be weak to avoid
    # a reference cycle that delays releasing CUDA storage until cyclic GC.
    _owning_module: ReferenceType[nn.Module]
    fsdp_parameters: tuple[FsdpParameter, ...]
    mesh: DeviceMesh
    dtype: torch.dtype
    requires_grad: bool
    main_weight: DBuffer
    model_weight: DBuffer | QuantizedDBuffer
    # Optimizer-layout representation of model_weight after an optimizer step.
    post_optimizer_model_weight: DBuffer | QuantizedDBuffer
    # sync_model_weight_from_main_weight() updates only this rank's optimizer-layout
    # view; the remaining model_weight slices must be all-gathered before compute.
    _model_weight_is_stale: bool
    main_grad: DBuffer | None
    # Optimizer-layout view into main_grad storage, avoiding a second allocation.
    # This is None exactly when main_grad is None.
    pre_optimizer_main_grad: DBuffer | None
    # zero_grad(set_to_none=False) clears only the current optimizer view. If final
    # reduction created a smaller view (e.g. ZeRO-1 or HFSDP), the remaining main_grad
    # storage is stale and must be cleared before the next accumulation begins.
    _main_grad_is_stale: bool
    # dtype of the reduce-scatter input (partial_grad): MixedPrecisionPolicy.grad_comm_dtype,
    # or main_grad's dtype when unset.
    grad_comm_dtype: torch.dtype
    # Full compute storage: persistent model_weight when replicated, otherwise a
    # temporary buffer populated by all-gather.
    _unsharded_model_weight: DBuffer | QuantizedDBuffer
    # BF16 shares one event across phases; sharded MXFP8 has independent rowwise
    # (forward) and columnwise (backward) events. Releasing storage clears its event.
    _unshard_events: dict[Phase, torch.cuda.Event]
    _symm_mem_pool: torch.cuda.MemPool | None
    grad_scale: float
    # Padded (equal) or unpadded (unequal) segments for RowAtomic/BlockAtomic layouts.
    shard_layout: ShardLayout

    def __init__(
        self,
        owning_module: nn.Module,
        fqn_to_parameter: dict[str, nn.Parameter],
        mesh: DeviceMesh,
        model_weight_placements: tuple[Placement, ...],
        main_grad_placements: tuple[Placement, ...],
        main_weight_placements: tuple[Placement, ...],
        mixed_precision_policy: MixedPrecisionPolicy,
        grad_scale: float = 1.0,
        use_symmetric_memory: bool = False,
        # TODO: Revisit passing owner assignments into the group constructor in a future PR.
        parameter_to_owner: dict[nn.Parameter, int] | None = None,
        shard_layout: ShardLayout = ShardLayout.PADDED,
    ) -> None:
        """Create persistent sharded buffers for a group of parameters.

        Args:
            owning_module: Closest FSDP root module that owns this parameter group.
            fqn_to_parameter: Root-module-relative FQNs and their parameters, in logical
                tensor order. Tied parameters count once.
            mesh: Parent device mesh containing the data-parallel axes.
            model_weight_placements: Compute-weight buffer placements.
            main_grad_placements: Main-gradient buffer placements.
            main_weight_placements: Main-weight buffer placements.
            mixed_precision_policy: Precision policy for main weights and gradients.
            use_symmetric_memory: Allocate communication staging buffers from PyTorch's
                NCCL symmetric-memory pool.
            grad_scale: Multiplier applied after the mesh-size averaging.
                See ``fully_shard``.
            parameter_to_owner: Construction-time mapping from original parameters to
                owner ranks in ``mesh``. Every TensorAtomic parameter needs an entry;
                entries for other parameters and non-TensorAtomic groups are ignored.
            shard_layout: Whether RowAtomic/BlockAtomic layouts pad to equal rank segments
                or pack without padding into generally unequal ones. See ``fully_shard``.
        """
        parameter_to_fqns, self.dtype, self.requires_grad = self._collect_parameter_metadata(
            fqn_to_parameter
        )
        self._owning_module = ref(owning_module)
        self._unshard_events = {}
        self.mesh = mesh
        self.grad_scale = grad_scale
        self.shard_layout = shard_layout
        if shard_layout is ShardLayout.UNPADDED and use_symmetric_memory:
            raise ValueError(
                "ShardLayout.UNPADDED is incompatible with use_symmetric_memory: NCCL "
                "symmetric-memory collectives require equal shard sizes."
            )
        parameters = tuple(parameter_to_fqns)

        if parameter_to_owner is not None and _contains_any_placement_type(
            model_weight_placements,
            main_grad_placements,
            main_weight_placements,
            placement_types=TensorAtomic,
        ):
            self._validate_parameter_to_owner(parameter_to_fqns, parameter_to_owner)
        self._initialize_buffers(
            parameters,
            parameter_to_owner,
            model_weight_placements,
            main_grad_placements,
            main_weight_placements,
            mixed_precision_policy,
            use_symmetric_memory,
        )
        self.fsdp_parameters = self._build_fsdp_parameters(parameter_to_fqns)

        # Building Parameter views requires live storage. Release temporary gather
        # storage afterward; replicated weights keep their persistent buffer.
        self.release_unsharded_storage()
        self._switch_to_sharded_parameters()

    @staticmethod
    def _collect_parameter_metadata(
        fqn_to_parameter: dict[str, nn.Parameter],
    ) -> tuple[dict[nn.Parameter, list[str]], torch.dtype, bool]:
        """Group tied parameters and validate their shared metadata."""
        if not fqn_to_parameter:
            raise ValueError("FsdpParameterGroup requires at least one parameter.")
        parameter_to_fqns: dict[nn.Parameter, list[str]] = {}
        for fqn, parameter in fqn_to_parameter.items():
            parameter_to_fqns.setdefault(parameter, []).append(fqn)

        # Python dicts preserve insertion order, so parameter_to_fqns and
        # fsdp_parameters define the same stable DBuffer tensor order.
        first_parameter = next(iter(parameter_to_fqns))
        dtype = effective_dtype(first_parameter)
        requires_grad = first_parameter.requires_grad
        for parameter, fqns in parameter_to_fqns.items():
            if effective_dtype(parameter) != dtype:
                raise ValueError(
                    f"Expected parameter {fqns!r} to have dtype {dtype}, "
                    f"got {effective_dtype(parameter)}."
                )
            if parameter.requires_grad != requires_grad:
                raise ValueError(
                    f"Expected parameter {fqns!r} to have requires_grad={requires_grad}, "
                    f"got {parameter.requires_grad}."
                )
        return parameter_to_fqns, dtype, requires_grad

    @staticmethod
    def _validate_parameter_to_owner(
        parameter_to_fqns: dict[nn.Parameter, list[str]],
        parameter_to_owner: dict[nn.Parameter, int],
    ) -> None:
        """Report by FQN the first parameter that has no owner assignment."""
        for parameter, fqns in parameter_to_fqns.items():
            if parameter not in parameter_to_owner:
                raise ValueError(f"parameter_to_owner is missing entries for parameters {fqns!r}.")

    def _build_layout(
        self,
        parameters: tuple[nn.Parameter, ...],
        parameter_to_owner: dict[nn.Parameter, int] | None,
        *placement_groups: tuple[Placement, ...],
    ) -> GlobalLayout:
        """Build the global layout shared by this group's buffers."""
        shapes = (parameter.shape for parameter in parameters)
        if not _contains_any_placement_type(*placement_groups, placement_types=TensorAtomic):
            # MXFP8 groups keep 32-row blocks on one rank; other dtypes pack rows.
            return layout_builder.build_row_atomic_layout(
                shapes,
                dp_size=self.mesh.size(),
                block_size=32 if self.dtype == torch.uint8 else 1,
                shard_layout=self.shard_layout,
            )
        if _contains_any_placement_type(
            *placement_groups, placement_types=(RowAtomic, BlockAtomic)
        ):
            raise ValueError(
                "TensorAtomic cannot be mixed with RowAtomic or BlockAtomic placements."
            )
        if self.mesh.ndim != 1:
            raise ValueError("TensorAtomic requires a 1-D data-parallel mesh.")
        if parameter_to_owner is None:
            raise ValueError("TensorAtomic placements require parameter_to_owner.")
        return layout_builder.build_for_tensor_atomic(
            shapes,
            dp_size=self.mesh.size(),
            tensor_owners=(parameter_to_owner[parameter] for parameter in parameters),
        )

    def _initialize_buffers(
        self,
        parameters: tuple[nn.Parameter, ...],
        parameter_to_owner: dict[nn.Parameter, int] | None,
        model_weight_placements: tuple[Placement, ...],
        main_grad_placements: tuple[Placement, ...],
        main_weight_placements: tuple[Placement, ...],
        mixed_precision_policy: MixedPrecisionPolicy,
        use_symmetric_memory: bool,
    ) -> None:
        """Build the shared layout and allocate weight and gradient buffers."""
        layout = self._build_layout(
            parameters,
            parameter_to_owner,
            model_weight_placements,
            main_grad_placements,
            main_weight_placements,
        )

        if use_symmetric_memory and not hasattr(symm_mem, "is_symm_mem_tensor"):
            raise RuntimeError("Symmetric-memory MFSDP requires PyTorch 2.12 or later.")

        main_weight_dtype = mixed_precision_policy.main_params_dtype or torch.float32

        self.main_weight = DBuffer(
            mesh=self.mesh,
            placements=main_weight_placements,
            layout=layout,
            dtype=main_weight_dtype,
            device=self.mesh.device_type,
        )
        for index, parameter in enumerate(parameters):
            if self.dtype == torch.uint8:
                # Use preserved values to initialize optimizer weights without
                # MXFP8 quantization error, then release TE's extra copy.
                initial_value = parameter.get_high_precision_init_val()
                if initial_value is None:
                    raise ValueError(
                        "MXFP8 parameters require preserved high-precision initialization values. "
                        "Use quantized_model_init(preserve_high_precision_init_val=True)."
                    )
                parameter.clear_high_precision_init_val()
            else:
                initial_value = parameter
            self.main_weight.copy_from(index, initial_value)

        if use_symmetric_memory:
            # PyTorch caches this in C++ and returns early when the backend is already NCCL.
            symm_mem.set_backend("NCCL")
            self._symm_mem_pool = symm_mem.get_mem_pool(self.main_weight.device)
        else:
            self._symm_mem_pool = None

        if main_weight_dtype == self.dtype and main_weight_placements == model_weight_placements:
            self.model_weight = self.main_weight
        else:
            with self._symmetric_memory_context():
                if self.dtype == torch.uint8:
                    self.model_weight = QuantizedDBuffer(
                        self.mesh, model_weight_placements, layout, self.main_weight.device
                    )
                else:
                    # Keep the configured compute-weight layout alive for the lifetime of this
                    # parameter group. The optimizer-layout sync buffer below is only a view
                    # into its local storage, so the first ZeRO-1 unshard can all-gather
                    # directly into this allocation.
                    self.model_weight = DBuffer(
                        mesh=self.mesh,
                        placements=model_weight_placements,
                        layout=layout,
                        dtype=self.dtype,
                        device=self.main_weight.device,
                    )
        self.post_optimizer_model_weight = self.model_weight.view(main_weight_placements)
        self.sync_model_weight_from_main_weight()
        unsharded_placements = (Replicate(),) * self.mesh.ndim
        if self.model_weight.placements == unsharded_placements:
            self._unsharded_model_weight = self.model_weight
        else:
            with self._symmetric_memory_context():
                if isinstance(self.model_weight, DBuffer):
                    self._unsharded_model_weight = DBuffer(
                        mesh=self.mesh,
                        placements=unsharded_placements,
                        layout=layout,
                        dtype=self.dtype,
                        device=self.main_weight.device,
                    )
                else:
                    self._unsharded_model_weight = QuantizedDBuffer(
                        self.mesh, unsharded_placements, layout, self.main_weight.device
                    )

        self.main_grad = None
        self.pre_optimizer_main_grad = None
        self._main_grad_is_stale = False
        grad_dtype = mixed_precision_policy.main_grads_dtype or parameters[0].dtype
        self.grad_comm_dtype = mixed_precision_policy.grad_comm_dtype or grad_dtype
        if not self.requires_grad:
            return

        # Keep main_grad persistent for the initial implementation. For micro-batch
        # size 1, this allocation could be delayed until post_backward and then
        # eagerly deallocated right after optimizer.step(), avoiding main_grad
        # storage during forward. That requires a separate lifetime contract with
        # the optimizer, so this version keeps the simpler persistent buffer.
        self.main_grad = DBuffer(
            mesh=self.mesh,
            placements=main_grad_placements,
            layout=layout,
            dtype=grad_dtype,
            device=self.main_weight.device,
        )
        self.pre_optimizer_main_grad = self.main_grad.view(main_weight_placements)

    def _build_fsdp_parameters(
        self, parameter_to_fqns: dict[nn.Parameter, list[str]]
    ) -> tuple[FsdpParameter, ...]:
        """Materialize parameter storage and build its FSDP representations."""
        fsdp_parameters: list[FsdpParameter] = []
        main_grad_dtype = self.main_grad.dtype if self.main_grad is not None else None
        for index, (parameter, fqns) in enumerate(parameter_to_fqns.items()):
            # No GEMM runs during initialization. MXFP8 scales stay compact until
            # the first unshard installs padded scales for compute.
            unsharded_tensor = self._unsharded_model_weight.get_tensor_view(index)
            if parameter.is_meta:
                # A meta Parameter cannot set .data to a real tensor because their
                # TensorImpl types are incompatible, so swap in a materialized Parameter.
                # Copy model metadata first since swap_tensors() also swaps attributes.
                materialized_parameter = nn.Parameter(
                    unsharded_tensor, requires_grad=parameter.requires_grad
                )
                copy_parameter_attributes(parameter, materialized_parameter)
                torch.utils.swap_tensors(parameter, materialized_parameter)
            else:
                parameter.data = unsharded_tensor
                parameter.grad = None
            # Parameter-owned markers must not retain their FSDP module tree.
            setattr(parameter, _CONTAINING_PARAMETER_GROUP_ATTR, ref(self))

            sharded_parameter = nn.Parameter(
                self.main_weight.get_dtensor(index), requires_grad=parameter.requires_grad
            )
            copy_parameter_attributes(parameter, sharded_parameter)
            if main_grad_dtype:
                sharded_parameter.grad_dtype = main_grad_dtype
            setattr(sharded_parameter, _CONTAINING_PARAMETER_GROUP_ATTR, ref(self))
            fsdp_parameters.append(
                FsdpParameter(fqns=tuple(fqns), sharded=sharded_parameter, unsharded=parameter)
            )
        return tuple(fsdp_parameters)

    def _symmetric_memory_context(self):
        if self._symm_mem_pool is None:
            return nullcontext()
        return torch.cuda.use_mem_pool(self._symm_mem_pool)

    def _set_module_parameter(self, fqns: tuple[str, ...], parameter: nn.Parameter) -> None:
        owning_module = self._owning_module()
        if owning_module is None:
            raise RuntimeError("FSDP parameter group outlived its owning module.")
        for fqn in fqns:
            module, parameter_name = get_parameter_owner(owning_module, fqn)
            module._parameters[parameter_name] = parameter

    def _switch_to_sharded_parameters(self) -> None:
        for fsdp_parameter in self.fsdp_parameters:
            self._set_module_parameter(fsdp_parameter.fqns, fsdp_parameter.sharded)

    def _switch_to_unsharded_parameters(self) -> None:
        """Expose each FsdpParameter's unsharded Parameter on its owning module."""
        for fsdp_parameter in self.fsdp_parameters:
            self._set_module_parameter(fsdp_parameter.fqns, fsdp_parameter.unsharded)

    def sync_model_weight_from_main_weight(self) -> None:
        """Refresh compute weights from optimizer weights."""
        if isinstance(self.post_optimizer_model_weight, DBuffer):
            self.main_weight.cast(
                self.post_optimizer_model_weight.dtype, out=self.post_optimizer_model_weight
            )
        else:
            self.post_optimizer_model_weight.quantize_(self.main_weight)
        self._model_weight_is_stale = (
            self.post_optimizer_model_weight.placements != self.model_weight.placements
        )

    @property
    def is_rowwise_unsharded(self) -> bool:
        """Whether MXFP8 rowwise planes occupy temporary gathered storage."""
        buffer = self._unsharded_model_weight
        if buffer is self.model_weight:
            return False
        # QuantizedDBuffer aliases DBuffer when TE is unavailable.
        if isinstance(buffer, DBuffer):
            return False
        return buffer.is_rowwise_allocated

    def unshard_parameters(self, phase: Phase | None = None) -> None:
        """Prepare this group's Parameters for the requested compute phase.

        On the caller-selected all-gather stream, refresh compute weights, gather
        missing data if sharded, update FsdpParameters, switch the module's
        Parameters to their unsharded representations, and record readiness.
        Reuse existing events so compute never waits for a later prefetch when its
        weights are already available.
        """
        requested_phases = (Phase.FORWARD, Phase.BACKWARD) if phase is None else (phase,)
        missing_phases = tuple(p for p in requested_phases if p not in self._unshard_events)
        if not missing_phases:
            return

        if self._model_weight_is_stale:
            self.post_optimizer_model_weight.redistribute(
                self.model_weight.placements, out=self.model_weight
            )
            self._model_weight_is_stale = False

        if self._unsharded_model_weight is self.model_weight:
            ready_phases = (Phase.FORWARD, Phase.BACKWARD)
        elif isinstance(self._unsharded_model_weight, DBuffer):
            self._allgather_model_weight()
            ready_phases = (Phase.FORWARD, Phase.BACKWARD)
        else:
            self._allgather_model_weight(
                rowwise=Phase.FORWARD in missing_phases, columnwise=Phase.BACKWARD in missing_phases
            )
            ready_phases = missing_phases
        self._install_unsharded_parameters(
            rowwise=Phase.FORWARD in ready_phases, columnwise=Phase.BACKWARD in ready_phases
        )
        self._switch_to_unsharded_parameters()
        event = torch.cuda.current_stream().record_event()
        for ready_phase in ready_phases:
            self._unshard_events[ready_phase] = event

    def wait_for_unshard(self, phase: Phase | None) -> None:
        """Make the current stream wait for this group's requested weights."""
        requested_phases = (Phase.FORWARD, Phase.BACKWARD) if phase is None else (phase,)
        # Fixed phase order, with one wait when BF16 shares an event across phases.
        for event in dict.fromkeys(self._unshard_events[p] for p in requested_phases):
            torch.cuda.current_stream().wait_event(event)

    def _install_unsharded_parameters(
        self, *, rowwise: bool = True, columnwise: bool = True
    ) -> None:
        """Update each FsdpParameter's unsharded data and scales from the weight buffer.

        ``rowwise`` and ``columnwise`` select the newly gathered MXFP8 planes to
        install, preserving planes already installed for the other phase. Regular
        compute weights ignore them. Replicated weights also need installation
        after optimizer updates because their padded MXFP8 scales are copies.
        """
        unsharded_model_weight = self._unsharded_model_weight
        for index, fsdp_parameter in enumerate(self.fsdp_parameters):
            tensor_view = unsharded_model_weight.get_tensor_view(index)
            # TE saves an MXFP8 Parameter itself for backward and reads its planes when
            # backward runs. Update that Parameter in place, preserving any planes
            # that were already gathered for the other phase.
            if isinstance(unsharded_model_weight, DBuffer):
                fsdp_parameter.unsharded.data = tensor_view
            else:
                update_mxfp8_tensor(
                    tensor_view, fsdp_parameter.unsharded, rowwise=rowwise, columnwise=columnwise
                )

    def _allgather_model_weight(self, *, rowwise: bool = True, columnwise: bool = True) -> None:
        """Allocate the gather buffer and fill it from sharded compute weights.

        ``rowwise`` and ``columnwise`` select the MXFP8 planes to gather. Regular
        compute weights ignore them and gather their whole buffer.
        """
        unsharded_model_weight = self._unsharded_model_weight
        if isinstance(unsharded_model_weight, DBuffer):
            buffers = (unsharded_model_weight,)
        else:
            buffers = unsharded_model_weight.planes_for(rowwise=rowwise, columnwise=columnwise)
        with self._symmetric_memory_context():
            for buffer in buffers:
                buffer.reallocate_storage()

        # This buffer backs unsharded Parameters whose views may be saved by autograd.
        # Autograd records a tensor's version counter when saving it for backward, and
        # in-place writes like the out= redistribution below increment that counter even
        # under no_grad. Without preserving it, backward can fail with "modified by an
        # inplace operation" even though FSDP only materialized internal storage.
        with torch.autograd._unsafe_preserve_version_counter(
            tuple(buffer.local_buffer for buffer in buffers)
        ):
            if isinstance(unsharded_model_weight, DBuffer):
                self.model_weight.redistribute(
                    unsharded_model_weight.placements, out=unsharded_model_weight
                )
            else:
                self.model_weight.redistribute(
                    unsharded_model_weight.placements,
                    out=unsharded_model_weight,
                    rowwise=rowwise,
                    columnwise=columnwise,
                )

    def reshard_parameters(self) -> None:
        """Install sharded DTensor parameters on the owning modules."""
        self._switch_to_sharded_parameters()

    def release_unsharded_storage(self, *, rowwise_only: bool = False) -> None:
        """Release gathered weights, or only their MXFP8 rowwise planes.

        The caller orders this release after compute on the all-gather stream.

        Storage is resized to zero instead of replacing parameter ``.data``: autograd
        may have saved views into the unsharded parameters during forward, and those
        views must follow the Storage when a later unshard reallocates it.
        """
        unsharded_model_weight = self._unsharded_model_weight
        if rowwise_only:
            del self._unshard_events[Phase.FORWARD]
        else:
            self._unshard_events.clear()

        # Clear readiness so the next unshard refreshes Parameter data/scales,
        # but never free persistent compute weights or their padded scale copies.
        if unsharded_model_weight is self.model_weight:
            return
        if isinstance(unsharded_model_weight, DBuffer):
            assert not rowwise_only
            unsharded_model_weight.release_storage()
            return
        unsharded_model_weight.release_storage(rowwise_only=rowwise_only)
        for parameter in self.fsdp_parameters:
            weight = parameter.unsharded
            # TE #3518 requires padded scale copies on the Parameter, separate
            # from the buffer's compact scales. Release these copies too.
            # https://github.com/NVIDIA/TransformerEngine/issues/3518
            if weight._rowwise_scale_inv is not None:
                weight._rowwise_scale_inv.untyped_storage().resize_(0)
            if not rowwise_only and weight._columnwise_scale_inv is not None:
                weight._columnwise_scale_inv.untyped_storage().resize_(0)
            # Keep an empty data view for TE's device queries when neither plane
            # remains. Otherwise, remove the released plane from the tensor.
            if rowwise_only and weight._columnwise_data is not None:
                weight.update_usage(rowwise_usage=False)

    def allocate_partial_grad_buffer(self) -> DBuffer:
        """Allocate the unreduced reduce-scatter input buffer."""
        assert self.main_grad is not None

        grads: list[torch.Tensor] = []
        for fsdp_parameter in self.fsdp_parameters:
            if fsdp_parameter.unsharded.grad is None:
                raise RuntimeError(f"Missing gradient for FSDP parameter {fsdp_parameter.fqns!r}.")
            grads.append(fsdp_parameter.unsharded.grad)
        with self._symmetric_memory_context():
            return DBuffer(
                mesh=self.mesh,
                placements=[Partial("avg")] * self.mesh.ndim,
                layout=self.main_weight.layout,
                dtype=self.grad_comm_dtype,
                device=grads[0].device,
            )

    def copy_gradients_to_partial_buffer(self, partial_grad: DBuffer) -> None:
        """Pack full local gradients into an existing reduce-scatter input buffer."""
        # A future fused-wgrad path can write directly into these buffer views.
        for index, fsdp_parameter in enumerate(self.fsdp_parameters):
            partial_grad.get_tensor_view(index).copy_(fsdp_parameter.unsharded.grad)
            fsdp_parameter.unsharded.grad = None

    def _has_sharded_grads(self) -> bool:
        has_any_grad = False
        has_any_missing_grad = False
        for fsdp_parameter in self.fsdp_parameters:
            if fsdp_parameter.sharded.grad is None:
                has_any_missing_grad = True
            else:
                has_any_grad = True
        if has_any_grad and has_any_missing_grad:
            raise RuntimeError("FSDP sharded gradients must be either all set or all None.")
        return has_any_grad

    def reduce_inner_gradients(self, partial_grad: DBuffer) -> None:
        """Reduce a packed partial gradient across DP-inner and accumulate into main_grad.

        main_grad rests at the DP-outer-Partial accumulation placement, accumulating
        each backward through the standard zero_grad contract, and ``.grad`` binds to
        it. The last-microbatch DP-outer reduction is applied separately by
        ``reduce_outer_gradients``; the caller (``_reduce_gradient_groups``)
        decides when and on which stream to run it, which is what lets the DP-outer
        reduction overlap the next group's DP-inner reduction.
        """
        assert self.main_grad is not None

        # zero_grad(set_to_none=True) clears sharded parameter grads, so this
        # backward can reduce directly into main_grad. zero_grad(set_to_none=False)
        # leaves sharded grads installed, so this backward accumulates into main_grad.
        has_sharded_grads = self._has_sharded_grads()
        if self._main_grad_is_stale:
            # In ZeRO-1 and HFSDP, zero_grad(set_to_none=False) only zeros the smaller
            # optimizer view. Clear the persistent full accumulation buffer before this
            # new step; set_to_none=True needs no clear because out= below overwrites it.
            if has_sharded_grads:
                self.main_grad.local_buffer.zero_()
            self._main_grad_is_stale = False

        if can_reduce_into_main_grad := (
            not has_sharded_grads and partial_grad.dtype == self.main_grad.dtype
        ):
            partial_grad.redistribute(self.main_grad.placements, out=self.main_grad)
            reduced_grad = self.main_grad
        else:
            reduced_grad = partial_grad.redistribute(self.main_grad.placements)

        # Scale this backward's contribution before accumulating it so repeated
        # backwards do not repeatedly scale the running total.
        if self.grad_scale != 1:
            reduced_grad.local_buffer.mul_(self.grad_scale)

        if reduced_grad is not self.main_grad:
            if has_sharded_grads:
                self.main_grad.local_buffer.add_(reduced_grad.local_buffer)
            else:
                self.main_grad.local_buffer.copy_(reduced_grad.local_buffer)

        self._install_sharded_grads(self.main_grad)

    def reduce_outer_gradients(self) -> None:
        """Finalize the deferred DP-outer reduction into the optimizer-layout view.

        All-reduce (HSDP) or reduce-scatter (HFSDP) the accumulator across DP-outer
        into ``pre_optimizer_main_grad`` (the persistent buffer's optimizer-layout
        view), then bind each sharded ``.grad`` to it. Runs after
        ``reduce_inner_gradients`` on the last microbatch; the caller can run it on
        its own stream to overlap the DP-inner reductions (see
        ``FsdpModule._reduce_gradient_groups``). main_grad and its view are
        persistent, so running on a separate stream needs no cross-stream free.
        """
        assert self.main_grad is not None
        assert self.pre_optimizer_main_grad is not None
        if self.pre_optimizer_main_grad is self.main_grad:
            # Optimizer layout equals the accumulation layout (e.g. plain DP): no
            # DP-outer axis to reduce, so grads already rest finalized.
            self._install_sharded_grads(self.main_grad)
            return
        self.main_grad.redistribute(self.main_weight.placements, out=self.pre_optimizer_main_grad)
        self._main_grad_is_stale = True
        self._install_sharded_grads(self.pre_optimizer_main_grad)

    def _install_sharded_grads(self, grad_buffer: DBuffer) -> None:
        """Bind each sharded parameter's ``.grad`` to the given reduced gradient buffer."""
        for index, fsdp_parameter in enumerate(self.fsdp_parameters):
            fsdp_parameter.sharded.grad = grad_buffer.get_dtensor(index)


def get_containing_parameter_group(parameter: nn.Parameter) -> FsdpParameterGroup | None:
    """Return the FSDP parameter group that owns ``parameter``, if any."""
    # This parameter-owned backedge must be weak; otherwise it forms a reference
    # cycle with the parameter group and delays releasing its CUDA storage.
    parameter_group_ref = getattr(parameter, _CONTAINING_PARAMETER_GROUP_ATTR, None)
    if parameter_group_ref is None:
        return None
    return parameter_group_ref()
