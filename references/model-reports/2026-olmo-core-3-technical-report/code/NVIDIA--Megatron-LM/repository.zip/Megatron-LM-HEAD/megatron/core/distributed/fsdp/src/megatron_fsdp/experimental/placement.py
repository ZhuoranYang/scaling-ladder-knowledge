# Copyright (c) 2026, NVIDIA CORPORATION. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""DBuffer placement definitions.

DBuffer uses PyTorch DTensor's ``Placement``, ``Replicate``, and ``Partial``
types directly. ``RowAtomic``, ``BlockAtomic``, and ``TensorAtomic`` are
DBuffer-specific dim-0 ``Shard`` placements whose local storage is part of one
flattened buffer. ``RowAtomic`` and ``BlockAtomic`` split the flattened buffer into
equal-size per-rank shards; ``TensorAtomic`` instead assigns every logical
tensor as a whole to one owner rank, so per-rank shards may differ in size.

=============  =============  ====================
Source         Destination    DBuffer operation
=============  =============  ====================
sharded        ``Replicate``  ``allgather()``
``Partial``    sharded        ``reduce_scatter()``
``Partial``    ``Replicate``  ``allreduce()``
``Replicate``  sharded        ``view()`` (local)
=============  =============  ====================
"""

import enum
from collections.abc import Iterable

from torch.distributed.tensor import Shard
from torch.distributed.tensor.placement_types import Placement

__all__ = ["BlockAtomic", "RowAtomic", "ShardLayout", "TensorAtomic", "changed_mesh_axis"]


class ShardLayout(enum.Enum):
    """How a ``RowAtomic`` / ``BlockAtomic`` group is split into per-rank segments."""

    PADDED = "padded"
    """Equal segments. The group is padded to a multiple of ``dp_size * LCM(row sizes)``
    (times the block size for ``BlockAtomic``)."""

    UNPADDED = "unpadded"
    """No padding. Tensors are packed back to back and segments end on the row/block
    boundary nearest to an even split."""


class RowAtomic(Shard):
    """DBuffer-specific dim-0 shard placement that keeps each row intact."""

    def __init__(self) -> None:
        super().__init__(0)

    def __eq__(self, other: object) -> bool:
        # PyTorch Shard.__eq__ compares only dim; DBuffer placements compare by type.
        return isinstance(other, RowAtomic)


class BlockAtomic(Shard):
    """Flattened dim-0 shard placement that keeps ``block_size`` rows together."""

    def __init__(self, block_size: int) -> None:
        if block_size <= 0:
            raise ValueError(f"BlockAtomic block_size must be positive, got {block_size}.")
        super().__init__(0)
        self.block_size = block_size

    def __eq__(self, other: object) -> bool:
        # PyTorch Shard.__eq__ compares only dim, so preserve the block size as well.
        return isinstance(other, BlockAtomic) and self.block_size == other.block_size

    def __repr__(self) -> str:
        return f"BlockAtomic(block_size={self.block_size})"


class TensorAtomic(Shard):
    """Dim-0 shard placement that assigns each logical tensor as a whole to one rank.

    With ``fully_shard``, use ``TensorAtomic()`` in ``Placements`` and supply only
    ``FsdpContext(parameter_to_owner=...)``. Each parameter group derives
    its tensor owners from that mapping and passes them to
    ``layout_builder.build_for_tensor_atomic``. Ownership is encoded by the layout's
    offsets; this placement stores no owner assignments.
    """

    def __init__(self) -> None:
        super().__init__(0)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, TensorAtomic)

    def __repr__(self) -> str:
        return "TensorAtomic()"


def changed_mesh_axis(
    old_placements: Iterable[Placement], new_placements: Iterable[Placement]
) -> int | None:
    """Return the changed mesh axis, requiring at most one placement change."""
    changed_axis = None
    for axis, (old_placement, new_placement) in enumerate(
        zip(old_placements, new_placements, strict=True)
    ):
        if old_placement == new_placement:
            continue
        if changed_axis is not None:
            raise NotImplementedError(
                "Expected at most one changed placement axis, "
                f"got changed axes {changed_axis} and {axis}."
            )
        changed_axis = axis
    return changed_axis
