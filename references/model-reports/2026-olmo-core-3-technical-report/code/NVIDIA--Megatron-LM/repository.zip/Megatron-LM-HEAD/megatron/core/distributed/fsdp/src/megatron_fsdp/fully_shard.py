# Copyright (c) 2025, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import types
from enum import IntEnum
from typing import Callable, Optional, Sequence, Type

import torch
from torch.distributed import DeviceMesh
from torch.distributed.device_mesh import init_device_mesh
from torch.distributed.tensor import DTensor

from .distributed_data_parallel_config import VALID_SHARDING_STRATEGIES
from .megatron_fsdp import MegatronFSDP
from .mixed_precision import MixedPrecisionPolicy
from .uneven_dtensor import preprocess_state_dict_for_uneven_dtensor
from .utils import FSDPDistributedIndex, create_updated_function_signature

try:
    # Default to Megatron-LM FW.
    from megatron.core.distributed.distributed_data_parallel_config import (
        DistributedDataParallelConfig,
    )
except ImportError:
    # Megatron-LM is not installed, use Megatron-FSDP as a standalone module.
    from .distributed_data_parallel_config import DistributedDataParallelConfig


logger = logging.getLogger(__name__)


class ShardingStrategy(IntEnum):
    """
    IntEnum to track the abbreviated sharding strategy for Megatron-FSDP.

    - `0` or `no_shard` implies that your model is not sharded. Similar memory usage to `DDP`.
    - `1` or `optim` implies that your optimizer state is sharded. Similar to optimizer
        state sharding in `ZeRO-DP`.
    - `2` or `optim_grads` implies that your optimizer state and gradients are sharded.
        Similar to optimizer state and gradient sharding in `ZeRO-2`.
    - `3` or `optim_grads_params` implies that your optimizer state, gradients, and
        training parameters are sharded. Similar to optimizer state, gradient, and
        training parameter sharding in `ZeRO-3`.
    """

    NO_SHARD = 0
    OPTIM = 1
    OPTIM_GRADS = 2
    OPTIM_GRADS_PARAMS = 3


def experimental_api(func: Callable) -> Callable:
    """
    Mark a function or class as experimental API in Megatron CI/CD.

    TODO(@cspades): Copied from megatron.core.utils to avoid depending on MCore
    for Megatron-FSDP. Should remove when the API is no longer experimental.
    """
    func._experimental_api = True
    return func


@experimental_api
def fully_shard_model(
    module: torch.nn.Module,
    device_mesh: Optional[DeviceMesh] = None,
    dp_shard_dim: Optional[str] = None,
    dp_outer_dim: Optional[str] = None,
    tp_dim: Optional[str] = None,
    hybrid_fsdp_group: Optional[torch.distributed.ProcessGroup] = None,
    hybrid_fsdp_expt_group: Optional[torch.distributed.ProcessGroup] = None,
    expt_device_mesh: Optional[DeviceMesh] = None,
    fsdp_group_ag: Optional[torch.distributed.ProcessGroup] = None,
    expt_fsdp_group_ag: Optional[torch.distributed.ProcessGroup] = None,
    fsdp_unit_modules: Optional[Sequence[Type[torch.nn.Module]] | Sequence[str]] = None,
    zero_dp_strategy: str | int = 3,
    expert_zero_dp_strategy: Optional[str | int] = None,
    outer_dp_sharding_strategy: str | int = 0,
    device: Optional[torch.device] = None,
    init_model_with_meta_device: bool = False,
    mixed_precision_policy: MixedPrecisionPolicy = MixedPrecisionPolicy(),
    overlap_grad_reduce: bool = True,
    overlap_param_gather: bool = True,
    sync_model_each_microbatch: bool = True,
    preproc_state_dict_for_dcp_ckpt: bool = True,
    report_nan_in_param_grad: bool = False,
    average_in_collective: bool = False,
    disable_bucketing: bool = False,
    calculate_per_token_loss: bool = False,
    keep_fp8_transpose_cache: bool = False,
    nccl_ub: bool = False,
    fsdp_double_buffer: bool = False,
    fsdp_db_use_persist_buf_on_alloc_fail: bool = False,
    disable_symmetric_registration: bool = False,
    enable_fine_grained_param_gather: bool = False,
    use_decoupled_grad: bool = False,
    cuda_graph_mode: bool = False,
    maxpool_double_buffer: bool = False,
    hfsdp_param_gather_overlap: bool = False,
) -> torch.nn.Module:
    """
    Fully-shard the model for Megatron-FSDP. This wraps the model in a MegatronFSDP
    class that schedules the sharding lifecycle of the model parameters and gradients
    during training and inference.

    The original `torch.nn.Module` can be accessed at `MegatronFSDP.module`.

    Args:
        module (torch.nn.Module):
            The PyTorch module fully-sharded and managed by Megatron-FSDP.

        device_mesh (Optional[DeviceMesh]):
            Device mesh object defining the topology for distributed training. If not provided,
            Megatron-FSDP will build a default FSDP DeviceMesh.

        dp_shard_dim (Optional[str]):
            Name of the data parallel sharding sub-mesh in the device_mesh. Supports
            a flattened DP-CP sub-mesh, in which case parameters, gradients, and
            optimizer state will be sharded across both DP and CP ranks.

        dp_outer_dim (Optional[str]):
            Name of the "outer" DP sub-mesh in the device_mesh for hybrid-sharding (HSDP),
            which supports "DP-Replicate" as well as optimizer state sharding (HFSDP).
            Defaults to None. Required for HSDP, which is enabled by this argument.

        tp_dim (Optional[str]):
            Name of the tensor parallel sub-mesh in the device_mesh, which is necessary
            for strided sharding between TP and FSDP (and fully-sharded HSDP) dimensions.
            Defaults to None. Required if TP is used in the model, or if TransformerEngine
            layers are utilized, as TE defaults to "TP=1".

        hybrid_fsdp_group (Optional[torch.distributed.ProcessGroup]):
            Cumulative data parallel process group for hybrid FSDP that can be manufactured
            by flattening the outer-FSDP (dp_outer_dim) and FSDP (dp_shard_dim) process groups
            or sub-meshes. Defaults to None. Required for HSDP, i.e. if dp_outer_dim is not None.

        expt_device_mesh (Optional[DeviceMesh]):
            Expert parallel device mesh object defining the topology for MoE distributed training.
            Utilizes the mesh dimension names specified by the *_dim arguments.

        fsdp_group_ag (Optional[torch.distributed.ProcessGroup]):
            Independent all-gather process group for overlapping all-gather and reduce-scatter
            operations. When provided, enables AG/RS overlap optimization for regular (non-expert)
            parameters. Users should create this group with the same ranks as the dp-cp group.
            Defaults to None.

        expt_fsdp_group_ag (Optional[torch.distributed.ProcessGroup]):
            Independent all-gather process group for expert parameters in MoE models. When provided,
            enables AG/RS overlap optimization for expert parameters. Users should create this group
            with the same ranks as the expert data parallel group. Defaults to None.

        fsdp_unit_modules (Optional[Sequence[Type[torch.nn.Module]] | Sequence[str]]):
            List of (sub-)module classes or (sub-)module class import paths that are "units",
            which are torch.nn.Module(s) that are sharded and scheduled by Megatron-FSDP.
            In particular, FSDP unit module parameters can be "safely" deallocated after
            the forward() or backward() pass without interfering with other computational
            operations that rely on those parameters in the complete PyTorch model.
            This information is utilized by Megatron-FSDP to optimally shard, gather, and
            overlap communications during the forward and backward pass of the module.
            Defaults to None, which is peak-memory-equivalent to DDP / "no_shard".

        zero_dp_strategy (str | int):
            Zero-redundancy sharding strategy for sharding data parallel parameters and gradients.
            - "no_shard" / 0: No optimizer, gradient, or parameter sharding. Similar
                memory usage to DDP.
            - "optim" / 1: Shards optimizer states (and main weights for mixed precision training),
                which is conceptually similar to optimizer state sharding in `ZeRO-DP`.
            - "optim_grads" / 2: Shards gradients and optimizer states, which is conceptually
                similar to "ZeRO-2".
            - "optim_grads_params" / 3: Shards parameters, gradients and optimizer states, which
                is conceptually similar to "ZeRO-3".
            Defaults to "optim_grads_params" / 3.

        expert_zero_dp_strategy (Optional[str | int]):
            Zero-redundancy sharding strategy applied to expert (MoE) parameters. Shares the
            same semantics as zero_dp_strategy. When set, zero_dp_strategy only applies to
            non-expert parameters, which allows the two parameter classes to trade DP-Shard
            communication against memory separately. Defaults to None, which applies
            zero_dp_strategy to every parameter.

        outer_dp_sharding_strategy (str | int):
            Sharding strategy for outer data parallel group in Hybrid Sharded Data Parallel (HSDP).
            Shares the same semantics as zero_dp_strategy, but only 'no_shard' / 0 (DP Replication)
            and 'optim' / 1 (Optimizer State Hybrid Sharding) are supported, and 'optim' / 1 is only
            supported when zero_dp_strategy='optim_grads_params'.
            This option is only effective when HSDP is enabled, i.e. when dp_outer_dim is not None.
            Defaults to "no_shard" / 0, which replicates model parameters across the dp_outer group.

        device (Optional[torch.device]):
            Target device for the sharded model. Used to migrate all parameters in the model
            to an expected device. If init_model_with_meta_device=True, this argument is ignored.
            Defaults to None.

        init_model_with_meta_device (bool):
            Utilized to initialize large models that do not fit on a single device, and requires
            implementing a custom Module.reset_parameters() or Module._reset_parameters() method.
            Defaults to False.

        mixed_precision_policy (megatron_fsdp.MixedPrecisionPolicy):
            Megatron-FSDP mixed-precision config that controls compute and communication precision.
            Default values are defined in `megatron_fsdp.MixedPrecisionPolicy`.

        overlap_grad_reduce (bool):
            Whether to overlap gradient reduce-scatter (or all-reduce) with backward compute.
            Defaults to True.

        overlap_param_gather (bool):
            Whether to overlap parameter all-gather with forward and backward compute.
            Defaults to True.

        hfsdp_param_gather_overlap (bool):
            Whether to pipeline HFSDP parameter all-gathers across DP-Outer and DP-Inner.
            Defaults to False.

        sync_model_each_microbatch (bool): Whether to sync parameters and install gradients on
            each training step. When disabled, Megatron-FSDP will overlap reduce-scatter with
            subsequent compute and delay HSDP gather and reduce operations per optimization cycle,
            which improves performance and throughput when using delayed optimization strategies
            such as gradient accumulation. Defaults to True, can be modified before the model
            forward / backward pass via MegatronFSDP.set_model_auto_sync(bool) or controlled
            with the (no_)sync context managers or microbatch_count and is_last_microbatch.

        preproc_state_dict_for_dcp_ckpt (bool):
            Whether to preprocess the unevenly-sharded state dict for DCP checkpointing,
            for both the model and the optimizer.
            Defaults to True.

        report_nan_in_param_grad (bool):
            Whether to precisely check for NaN values in gradients for every weight. Can
            significantly degrade performance. Defaults to False.

        average_in_collective (bool):
            Whether to average gradients in collective communication. Defaults to False.

        disable_bucketing (bool):
            Whether to disable gradient bucketing optimization, which permits more granular
            and precise communication of parameters and gradients. Defaults to False.

        calculate_per_token_loss (bool):
            Whether to calculate loss per token, which deactivates gradient scaling.
            Defaults to False.

        keep_fp8_transpose_cache (bool):
            Whether to keep the FP8 transpose cache when using a Megatron FSDP.
            Defaults to False.

        nccl_ub (bool):
            Whether to use NCCL UCC for communication. Defaults to False.

        fsdp_double_buffer (bool):
            Whether to use double buffer for FSDP. Defaults to False.

        fsdp_db_use_persist_buf_on_alloc_fail (bool):
            Whether to fall back to persistent buffer allocator when a bucket does not
            fit FSDP double buffer size.

        disable_symmetric_registration (bool):
            Whether to disable symmetric (window) registration for NCCL UB registration.
            This option forces conventional (local) UB registration when nccl_ub is set.
            Defaults to False.

        enable_fine_grained_param_gather (bool):
            Whether to enable "fine-grained" param all-gather, which can improve performance
            when using MXFP8 parameters with activation recomputation. Specifically, it
            unshards parameters per-Module instead of unsharding all sub-modules of an FSDP
            unit module simultaneously. Defaults to False.

        use_decoupled_grad (bool):
            If true, reduced gradients are installed into `Parameter.decoupled_grad` instead
            of `Parameter.grad`. Defaults to False.

        cuda_graph_mode (bool):
            If true, Megatron-FSDP will practice CUDA graph-safe operations, such as
            not dereferencing `param.grad` after the optimizer step to preserve references
            for CUDA graph replay. Can affect memory utilization in some cases, such as
            when the gradient shard is not a view of the Megatron-FSDP sharded gradient
            buffer, so `FusedAdam(use_decoupled_grad=True) + use_decoupled_grad=True` or
            setting `megatron_fsdp_main_params_dtype == megatron_fsdp_main_grads_dtype`
            is recommended to avoid casting the gradient to the parameter precision and
            creating a casted-copy of the gradient shard that cannot be dereferenced due
            to replay. Defaults to False.

        maxpool_double_buffer (bool):
            Builds a double buffer maxpool that can be recycled across asymmetric / hybrid
            FSDP units, instead of the symmetrical FixedPoolAllocator that requires exact
            parity between FSDP units, when using fsdp_double_buffer=True. Enables NCCL
            user buffer registration and CUDA graph replay for models with asymmetrical
            FSDP units, such as models with hybrid architectures (e.g. Mamba and MoE).

    Returns:
        model (MegatronFSDP): The wrapped Megatron-FSDP model configured for FSDP.
    """
    # If no DeviceMesh or FSDP dimension is provided, then build an FSDP DeviceMesh.
    # Modify arguments into arguments necessary for vanilla FSDP.
    if device_mesh is None:
        if dp_shard_dim is None:
            dp_shard_dim = "fsdp"
        if tp_dim is None:
            # Trivial TP dimension to seamlessly support TransformerEngine.
            tp_dim = "tp"
        # Deactivate DP-Outer, which needs to be consistent with Expert DeviceMesh.
        dp_outer_dim = None
        hybrid_fsdp_group = None
        outer_dp_sharding_strategy = ShardingStrategy.NO_SHARD
        device_mesh = init_device_mesh(
            device_type="cuda",
            mesh_shape=(torch.distributed.get_world_size(), 1),
            mesh_dim_names=(dp_shard_dim, tp_dim),
        )

    # Parse zero_dp_strategy and outer_dp_sharding_strategy.
    # TODO(@cspades): Integrate this Enum into MegatronFSDP.
    def _parse_zero_dp_strategy(strategy: ShardingStrategy | str | int) -> str:
        if isinstance(strategy, str):
            if strategy not in VALID_SHARDING_STRATEGIES:
                raise ValueError(
                    f"Invalid FSDP / Inner DP Sharding Strategy: {strategy}\n"
                    f"Valid Sharding Strategies: {VALID_SHARDING_STRATEGIES}"
                )
            return strategy

        # ShardingStrategy is an IntEnum, so the enum members also match the bare ints.
        match strategy:
            case ShardingStrategy.NO_SHARD:
                return "no_shard"
            case ShardingStrategy.OPTIM:
                return "optim"
            case ShardingStrategy.OPTIM_GRADS:
                return "optim_grads"
            case ShardingStrategy.OPTIM_GRADS_PARAMS:
                return "optim_grads_params"
            case _:
                raise ValueError(
                    f"Invalid FSDP / Inner DP Sharding Strategy: {strategy}\n"
                    f"Valid Sharding Strategies: {ShardingStrategy.NO_SHARD}, "
                    f"{ShardingStrategy.OPTIM}, {ShardingStrategy.OPTIM_GRADS}, "
                    f"{ShardingStrategy.OPTIM_GRADS_PARAMS}, "
                    f"{VALID_SHARDING_STRATEGIES}"
                )

    zero_dp_strategy = _parse_zero_dp_strategy(zero_dp_strategy)
    if expert_zero_dp_strategy is not None:
        expert_zero_dp_strategy = _parse_zero_dp_strategy(expert_zero_dp_strategy)
    if outer_dp_sharding_strategy == ShardingStrategy.NO_SHARD:
        outer_dp_sharding_strategy = "no_shard"
    elif outer_dp_sharding_strategy == ShardingStrategy.OPTIM:
        outer_dp_sharding_strategy = "optim"
    elif outer_dp_sharding_strategy in ["no_shard", "optim"]:
        # Valid string sharding strategy.
        pass
    else:
        # Invalid sharding strategy.
        raise ValueError(
            f"Invalid Hybrid DP-Outer Sharding Strategy: {outer_dp_sharding_strategy}\n"
            f"Valid Sharding Strategies: {ShardingStrategy.NO_SHARD}, "
            f"{ShardingStrategy.OPTIM}, no_shard, optim"
        )

    # Validate more arguments.
    _outer_fsdp_sharding = outer_dp_sharding_strategy == "optim"
    _replicated_grad_strategies = sorted(
        {
            strategy
            for strategy in (zero_dp_strategy, expert_zero_dp_strategy)
            if strategy in ("no_shard", "optim")
        }
    )
    if _outer_fsdp_sharding and _replicated_grad_strategies:
        # Sharding the optimizer state over DP-Outer constrains how DP-Shard handles
        # gradients, but deliberately not how it handles model weights.
        #
        # Gradients: the DP-Outer reduction reduce-scatters the gradient shard that the
        # DP-Shard reduction produced, so DP-Shard has to shard gradients. Replicating them
        # ('no_shard', 'optim') and reduce-scattering that over DP-Outer is well defined, but
        # it needs an all-reduce-then-reduce-scatter path that does not exist here, and it
        # would move the whole gradient over DP-Shard to reach the same placement that
        # 'optim_grads' reaches with a reduce-scatter. Rejected rather than mis-scaled.
        #
        # Model weights: no equivalent constraint, which is the point of this configuration.
        # A group whose weights are replicated reassembles the whole bucket from the DP-wide
        # weight shards rather than viewing a DP-Shard slice of it, so ZeRO-1/ZeRO-2 inner
        # sharding can sit under DP-Outer optimizer sharding instead of requiring ZeRO-3.
        raise ValueError(
            "Sharding with Hybrid (Fully) Sharded Data Parallel (HSDP) requires a "
            "zero_dp_strategy that shards gradients ('optim_grads', 2 or "
            f"'optim_grads_params', 3), but got {_replicated_grad_strategies}, because "
            "outer sharding is dependent on inner gradient sharding."
        )
    if (dp_outer_dim is None) ^ (hybrid_fsdp_group is None):
        # XOR - HSDP requires both or neither of dp_outer_dim and hybrid_fsdp_group
        # to be specified, so if XOR then raise an error.
        raise ValueError(
            f"dp_outer_dim={dp_outer_dim} and hybrid_fsdp_group={hybrid_fsdp_group} must be "
            "specified together for Hybrid FSDP (HSDP), or both set to None (for FSDP)."
        )
    if init_model_with_meta_device and zero_dp_strategy == "no_shard":
        raise ValueError(
            "Meta device initialization (init_model_with_meta_device=True) is not "
            "supported or necessary for the 'no_shard' / 0 sharding strategy."
        )

    # DDP Config for Megatron FSDP.
    ddp_config = DistributedDataParallelConfig(
        data_parallel_sharding_strategy=zero_dp_strategy,
        expert_data_parallel_sharding_strategy=expert_zero_dp_strategy,
        outer_dp_sharding_strategy=outer_dp_sharding_strategy,
        overlap_grad_reduce=overlap_grad_reduce,
        overlap_param_gather=overlap_param_gather,
        hfsdp_param_gather_overlap=hfsdp_param_gather_overlap,
        average_in_collective=average_in_collective,
        keep_fp8_transpose_cache=keep_fp8_transpose_cache,  # pylint: disable=C0301
        nccl_ub=nccl_ub,
        fsdp_double_buffer=fsdp_double_buffer or nccl_ub,
        fsdp_db_use_persist_buf_on_alloc_fail=fsdp_db_use_persist_buf_on_alloc_fail,
        disable_symmetric_registration=disable_symmetric_registration,
        megatron_fsdp_use_decoupled_grad=use_decoupled_grad,
        megatron_fsdp_cuda_graph_mode=cuda_graph_mode,
        megatron_fsdp_max_pool_double_buffer=maxpool_double_buffer,
    )

    # Create FSDPDistributedIndex.
    dist_index = FSDPDistributedIndex(
        device_mesh=device_mesh,
        # Always required for Megatron-FSDP.
        dp_shard_dim=dp_shard_dim,
        # Only required for HSDP.
        dp_outer_dim=dp_outer_dim,
        # TODO(@cspades): TP sub-mesh should be optional if not using TP, but is
        # required for Megatron, TransformerEngine (default TP=1), and strided
        # sharding when using DTensor-based TP.
        tp_dim=tp_dim,
        # Only required for HSDP.
        hybrid_fsdp_group=hybrid_fsdp_group,
        # Only required for HSDP + EP.
        hybrid_fsdp_expt_group=hybrid_fsdp_expt_group,
        # Access to flattened DP rank assignments for HSDP.
        hsdp_outer_dp_shard=_outer_fsdp_sharding,
        # Only required for Megatron-FSDP + EP.
        expt_device_mesh=expt_device_mesh,
        # AG groups for AG/RS overlap optimization.
        fsdp_group_ag=fsdp_group_ag,
        expt_fsdp_group_ag=expt_fsdp_group_ag,
    )

    # Wrap model in Megatron FSDP.
    model = MegatronFSDP(
        module=module,
        dist_index=dist_index,
        ddp_config=ddp_config,
        mixed_precision_policy=mixed_precision_policy,
        fsdp_unit_modules=fsdp_unit_modules,
        disable_bucketing=disable_bucketing,
        device=device,
        calculate_per_token_loss=calculate_per_token_loss,
        init_model_with_meta_device=init_model_with_meta_device,
        sync_model_each_microbatch=sync_model_each_microbatch,
        enable_fine_grained_param_gather_hook=enable_fine_grained_param_gather,
        report_nan_in_param_grad=report_nan_in_param_grad,
    )

    # Register a state dict post-hook to add Torch DCP metadata for writing checkpoints.
    if preproc_state_dict_for_dcp_ckpt and zero_dp_strategy != "no_shard":

        def remove_te_extra_state(state_dict):
            # Megatron-FSDP does not support FP8 extra state checkpointing in TE.
            extra_state_keys = [k for k in state_dict.keys() if k.endswith("_extra_state")]
            for key in extra_state_keys:
                state_dict.pop(key)

        def preprocess_dcp_and_te_extra_state(state_dict):
            # Preprocess the state dict for uneven DTensor checkpointing.
            remove_te_extra_state(state_dict)
            return preprocess_state_dict_for_uneven_dtensor(state_dict)

        model._register_state_dict_hook(
            lambda module, state_dict, prefix, local_metadata: preprocess_dcp_and_te_extra_state(
                state_dict
            )
        )

    # Return the wrapped Megatron-FSDP model.
    return model


@experimental_api
def fully_shard_optimizer(
    optimizer: torch.optim.Optimizer, preproc_state_dict_for_dcp_ckpt: bool = True
) -> torch.optim.Optimizer:
    """
    Fully shard the optimizer for Megatron-FSDP. This is an in-place operation on the optimizer
    instance, which modifies the optimizer to call methods exposed by the MegatronFSDP model API.

    The optimizer should be registered on the MegatronFSDP distributed model parameters:
    ```
        # Fully-shard the model.
        mfsdp_model = fully_shard_model(model, ...)

        # Register the fully-sharded parameters with the optimizer.
        # Use MegatronFSDP._replace_param_with_distributed_if_needed()
        # to swap to the distributed optimizer state parameters.
        optimizer = fully_shard_optimizer(Adam(params=mfsdp_model.parameters()))
    ```

    Args:
        optimizer (torch.optim.Optimizer):
            (Distributed) optimizer for training the model, which is extended to automatically
            execute necessary Megatron-FSDP operations during the training loop.

        preproc_state_dict_for_dcp_ckpt (bool):
            Whether to preprocess the state dict for DCP checkpointing. Defaults to True.

    Returns:
        optimizer (torch.optim.Optimizer): The in-place modified optimizer for Megatron-FSDP.
    """
    # Extract a reference to MegatronFSDP from the first registered Parameter.
    if not optimizer.param_groups:
        raise ValueError(
            f"[MegatronFSDP fully_shard_optimizer()] Provided optimizer doesn't "
            f"have any registered parameters: {optimizer}"
        )
    first_mfsdp_param = optimizer.param_groups[0][next(iter(optimizer.param_groups[0]))][0]
    if not getattr(first_mfsdp_param, "_megatron_fsdp_model", None):
        raise ValueError(
            f"[MegatronFSDP fully_shard_optimizer()] Could not retrieve a reference to "
            f"MegatronFSDP from the first registered Parameter: {first_mfsdp_param} \n"
            "Make sure the optimizer is registered to the MegatronFSDP distributed "
            "parameters via MegatronFSDP._replace_param_with_distributed_if_needed() "
            "before initializing the optimizer on the MegatronFSDP model. "
        )
    mfsdp_model = first_mfsdp_param._megatron_fsdp_model

    # Save a reference to the optimizer.step() and optimizer.zero_grad() methods.
    optimizer_step_base_func = type(optimizer).step
    optimizer_zero_grad_base_func = type(optimizer).zero_grad

    # Materialize lazy optimizer state so DCP has state tensors to load into. This
    # follows PyTorch DCP's `_init_optim_state`, which takes a synthetic zero-gradient
    # step before loading optimizer state.
    # TODO: Consider moving this initialization to the checkpoint-loading path, as in
    # the MFSDP v2 checkpoint API (#6024), where checkpoint state immediately
    # overwrites the synthetic state. Keeping it in fully_shard_optimizer() means that
    # fresh training may follow, so this synthetic step must be numerically inert.
    for group in optimizer.param_groups:
        for param in group["params"]:
            if param.numel() == 0 or (
                hasattr(param, "_local_tensor") and param._local_tensor.numel() == 0
            ):
                # Avoid FusedAdam errors on empty tensor input.
                continue
            # Optimizer state is built from wgrad.
            param.grad = torch.zeros_like(param)

    # A zero gradient alone does not make optimizer.step() inert. Set lr to zero
    # to prevent parameter updates. Also disable weight decay because optimizers
    # with coupled decay add it to the gradient before updating their persistent
    # moment buffers, independently of lr.
    optimizer_group_settings = []
    for group in optimizer.param_groups:
        optimizer_group_settings.append(
            (group, {key: group[key] for key in ("lr", "weight_decay") if key in group})
        )
        if "lr" in group:
            # Capturable optimizers may require lr to remain a device tensor.
            group["lr"] = (
                torch.zeros_like(group["lr"]) if isinstance(group["lr"], torch.Tensor) else 0.0
            )
        if "weight_decay" in group:
            group["weight_decay"] = 0.0
    # Allocate the state, then restore the caller's optimizer settings.
    optimizer.step()
    for group, settings in optimizer_group_settings:
        group.update(settings)

    # Optimizers advance their step counters even when lr is zero. Reset them so
    # the first real update uses step 1 for bias correction.
    for group in optimizer.param_groups:
        if "step" not in group:
            continue
        if isinstance(group["step"], torch.Tensor):
            group["step"].zero_()
        else:
            group["step"] = 0
    for state in optimizer.state.values():
        if "step" not in state:
            continue
        if isinstance(state["step"], torch.Tensor):
            state["step"].zero_()
        else:
            state["step"] = 0

    # Remove the synthetic gradients installed above.
    optimizer.zero_grad()

    # Define a new optimizer.step() method that distributes optimizer state and gradients,
    # waits for asynchronous gradient reduce-scatter work to be completed, and updates
    # model weights. These options can be turned off via arguments in optimizer.step().
    def megatron_fsdp_optimizer_step(optimizer, *args, **kwargs):
        # Extract extended kwargs.
        sync_grad_before_optimizer_step = kwargs.pop("sync_grad_before_optimizer_step", True)
        install_optimized_model_weights = kwargs.pop("install_optimized_model_weights", True)

        # Synchronize reduce-scatter and all-gather operations for all model gradients
        # and parameters, attach gradients to the optimizer state, and replace the raw
        # module parameters with Megatron-FSDP-managed optimizer parameters & states in
        # preparation for (distributed) optimization.
        # NOTE: Only necessary if MegatronFSDP.model_auto_sync = False, in which case
        # gradient synchronization is not automatically handled by MegatronFSDP during
        # the post-backward hook and we need to synchronize manually.
        if sync_grad_before_optimizer_step and not mfsdp_model.model_auto_sync:
            mfsdp_model.finish_grad_sync()

        # Execute the base optimizer.step() on the model optimizer named parameters.
        optimizer_step_base_func(optimizer, *args, **kwargs)

        # Update the raw module training parameters with optimized values.
        if install_optimized_model_weights:
            mfsdp_model.install_optimized_model_weights()

    # Define a new optimizer.zero_grad() method that zeros the gradient in both
    # the optimizer as well as the Megatron-FSDP gradient buffer. These options
    # can be turned off via arguments in optimizer.zero_grad().
    def megatron_fsdp_optimizer_zero_grad(optimizer, *args, **kwargs):
        # Extract extended kwargs.
        zero_grad_buffer = kwargs.pop("zero_grad_buffer", True)

        # Execute the base optimizer.zero_grad() on the model optimizer named parameters.
        optimizer_zero_grad_base_func(optimizer, *args, **kwargs)

        # Zero out the gradient in the Megatron-FSDP gradient buffer.
        if zero_grad_buffer:
            mfsdp_model.zero_grad_buffer()

    # Override the optimizer.step() and optimizer.zero_grad() methods to support
    # Megatron-FSDP operations.
    megatron_fsdp_optimizer_step.__signature__ = create_updated_function_signature(
        optimizer_step_base_func,
        sync_grad_before_optimizer_step=True,
        install_optimized_model_weights=True,
    )
    optimizer.step = types.MethodType(megatron_fsdp_optimizer_step, optimizer)
    megatron_fsdp_optimizer_zero_grad.__signature__ = create_updated_function_signature(
        optimizer_zero_grad_base_func, zero_grad_buffer=True
    )
    optimizer.zero_grad = types.MethodType(megatron_fsdp_optimizer_zero_grad, optimizer)

    if preproc_state_dict_for_dcp_ckpt:

        def dict_nested_shallow_copy(d: dict):
            """Create a nested shallow copy of a dict. Same values, different pointers."""
            if not isinstance(d, dict):
                return d
            return {
                k: dict_nested_shallow_copy(v) if isinstance(v, dict) else v for k, v in d.items()
            }

        def preprocess_optimizer_state_dict_for_uneven_dtensor(optimizer, state_dict):
            """
            Hook that mocks the global optimizer state for unevenly-distributed
            DTensors, as the optimizer state is only initialized for non-empty
            parameters, and preprocesses the optimizer `state_dict` DTensors
            in-place for Torch DCP.
            """
            # Retrieve a template optimizer state.
            optim_state_template = next(iter(optimizer.state.values())) if optimizer.state else {}
            # All-gather the optimizer state keys as this rank could have empty state.
            optim_state_dtensor_keys = [None] * torch.distributed.get_world_size()
            torch.distributed.all_gather_object(
                optim_state_dtensor_keys,
                [
                    # Only track keys associated with DTensors for DCP.
                    key
                    for key, val in optim_state_template.items()
                    if isinstance(val, DTensor)
                ],
            )
            optim_state_dtensor_keys = list(
                set([key for state in optim_state_dtensor_keys for key in state])
            )

            # NOTE(@cspades): Re-construct the Megatron-FSDP distributed parameter
            # to index mapping as implemented in torch.optim.Optimizer.state_dict():
            # https://github.com/pytorch/pytorch/blob/main/torch/optim/optimizer.py
            # Simply put, the index maps to the very first appearance of id(param)
            # looping through all parameters in all groups with memory address
            # equivalent to the distributed parameter managed by Megatron-FSDP.
            param_state_idx = {}
            idx = 0
            # For all empty parameters, mock empty DTensors for all empty parameters
            # of Megatron-FSDP's unevenly-distributed optimizer state into a shallow
            # copy of the state dictionary to synchronize and pre-process a global
            # variant of the optimizer state in preparation for Torch DCP. This allows
            # us to sync the non-empty DTensor shard metadata across sharding groups
            # while excluding empty DTensor shards from the optimizer checkpoint.
            optim_state_extended = dict_nested_shallow_copy(state_dict)
            for param_group in optimizer.param_groups:
                for param in param_group["params"]:
                    # Update the parameter state index.
                    # For shared params, use same index.
                    if id(param) not in param_state_idx:
                        # New parameter, assign an index.
                        param_state_idx[id(param)] = idx
                        idx += 1
                    if param in optimizer.state or not isinstance(param, DTensor):
                        # Only mock optimizer state for parameters that are missing state.
                        # No need to mock for non-DTensor params. Not relevant to DCP.
                        continue
                    for key in optim_state_dtensor_keys:
                        # Construct a mock DTensor state for the empty DTensor parameter.
                        param_idx = param_state_idx[id(param)]
                        optim_state_extended["state"].setdefault(param_idx, {})[key] = (
                            DTensor.from_local(
                                local_tensor=torch.empty(0, dtype=param.dtype, device=param.device),
                                device_mesh=param.device_mesh,
                                placements=param.placements,
                                shape=param.shape,
                                stride=param.stride(),
                            )
                        )

            # Synchronize and preprocess DTensor metadata for Torch DCP.
            preprocess_state_dict_for_uneven_dtensor(optim_state_extended)

        # Attach the optimizer state_dict() post-hook to prepare DTensors for Torch DCP.
        # args = (optimizer, state_dict)
        optimizer.register_state_dict_post_hook(
            lambda *args, **kwargs: preprocess_optimizer_state_dict_for_uneven_dtensor(
                args[0], args[1]
            )
        )

    # Return the in-place modified optimizer.
    return optimizer


@experimental_api
def fully_shard(
    module: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    device_mesh: Optional[DeviceMesh] = None,
    dp_shard_dim: Optional[str] = None,
    dp_outer_dim: Optional[str] = None,
    tp_dim: Optional[str] = None,
    hybrid_fsdp_group: Optional[torch.distributed.ProcessGroup] = None,
    hybrid_fsdp_expt_group: Optional[torch.distributed.ProcessGroup] = None,
    expt_device_mesh: Optional[DeviceMesh] = None,
    fsdp_group_ag: Optional[torch.distributed.ProcessGroup] = None,
    expt_fsdp_group_ag: Optional[torch.distributed.ProcessGroup] = None,
    fsdp_unit_modules: Optional[Sequence[Type[torch.nn.Module]] | Sequence[str]] = None,
    zero_dp_strategy: str | int = 3,
    expert_zero_dp_strategy: Optional[str | int] = None,
    outer_dp_sharding_strategy: str | int = 0,
    device: Optional[torch.device] = None,
    init_model_with_meta_device: bool = False,
    mixed_precision_policy: MixedPrecisionPolicy = MixedPrecisionPolicy(),
    overlap_grad_reduce: bool = True,
    overlap_param_gather: bool = True,
    sync_model_each_microbatch: bool = True,
    preproc_state_dict_for_dcp_ckpt: bool = True,
    report_nan_in_param_grad: bool = False,
    average_in_collective: bool = False,
    disable_bucketing: bool = False,
    calculate_per_token_loss: bool = False,
    keep_fp8_transpose_cache: bool = False,
    nccl_ub: bool = False,
    fsdp_double_buffer: bool = False,
    fsdp_db_use_persist_buf_on_alloc_fail: bool = False,
    disable_symmetric_registration: bool = False,
    enable_fine_grained_param_gather: bool = False,
    use_decoupled_grad: bool = False,
    cuda_graph_mode: bool = False,
    maxpool_double_buffer: bool = False,
    hfsdp_param_gather_overlap: bool = False,
) -> tuple[MegatronFSDP, torch.optim.Optimizer]:
    """
    Fully shard the model and the optimizer for Megatron-FSDP.

    Wraps the model as an Megatron-FSDP module, and modifies the optimizer to
    be compatible with the Megatron-FSDP training strategy.

    Args:
        Union of arguments from fully_shard_model and fully_shard_optimizer.

    Returns:
        torch.nn.Module: The wrapped Megatron-FSDP model configured for distributed training.
        torch.optim.Optimizer: The Megatron-FSDP-compliant optimizer for training the model.

    Note:
        This implementation uses NVIDIA's FSDP which includes optimizations specific
        to NVIDIA hardware and software stack.
    """

    model = fully_shard_model(
        module=module,
        device_mesh=device_mesh,
        dp_shard_dim=dp_shard_dim,
        dp_outer_dim=dp_outer_dim,
        tp_dim=tp_dim,
        hybrid_fsdp_group=hybrid_fsdp_group,
        hybrid_fsdp_expt_group=hybrid_fsdp_expt_group,
        expt_device_mesh=expt_device_mesh,
        fsdp_group_ag=fsdp_group_ag,
        expt_fsdp_group_ag=expt_fsdp_group_ag,
        fsdp_unit_modules=fsdp_unit_modules,
        zero_dp_strategy=zero_dp_strategy,
        expert_zero_dp_strategy=expert_zero_dp_strategy,
        outer_dp_sharding_strategy=outer_dp_sharding_strategy,
        device=device,
        init_model_with_meta_device=init_model_with_meta_device,
        mixed_precision_policy=mixed_precision_policy,
        overlap_grad_reduce=overlap_grad_reduce,
        overlap_param_gather=overlap_param_gather,
        hfsdp_param_gather_overlap=hfsdp_param_gather_overlap,
        sync_model_each_microbatch=sync_model_each_microbatch,
        preproc_state_dict_for_dcp_ckpt=preproc_state_dict_for_dcp_ckpt,
        report_nan_in_param_grad=report_nan_in_param_grad,
        average_in_collective=average_in_collective,
        disable_bucketing=disable_bucketing,
        calculate_per_token_loss=calculate_per_token_loss,
        keep_fp8_transpose_cache=keep_fp8_transpose_cache,
        nccl_ub=nccl_ub,
        fsdp_double_buffer=fsdp_double_buffer,
        fsdp_db_use_persist_buf_on_alloc_fail=fsdp_db_use_persist_buf_on_alloc_fail,
        disable_symmetric_registration=disable_symmetric_registration,
        use_decoupled_grad=use_decoupled_grad,
        cuda_graph_mode=cuda_graph_mode,
        maxpool_double_buffer=maxpool_double_buffer,
    )

    # Extend optimizer methods to support Megatron-FSDP operations.
    # Replace the optimizer module parameter references with
    # Megatron-FSDP-managed distributed parameters.
    model._replace_param_with_distributed_if_needed()
    optimizer.param_groups.clear()
    optimizer.state.clear()
    optimizer.add_param_group({"params": model.parameters()})
    fully_shard_optimizer(
        optimizer, preproc_state_dict_for_dcp_ckpt=preproc_state_dict_for_dcp_ckpt
    )

    # Return model and optimizer.
    return model, optimizer
