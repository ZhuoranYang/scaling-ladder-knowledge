# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

import enum


class ModelType(enum.Enum):
    """Model type."""

    encoder_or_decoder = 1
    # Retained so checkpoints written before the encoder/decoder model-type
    # cleanup can still be deserialized. New models should use
    # ``encoder_or_decoder``.
    encoder_and_decoder = 2
    retro_encoder = 3
    retro_decoder = 4


class Fp8Recipe(str, enum.Enum):
    """FP8 recipe names: delayed, tensorwise, mxfp8, blockwise, custom."""

    delayed = "delayed"
    tensorwise = "tensorwise"
    mxfp8 = "mxfp8"
    blockwise = "blockwise"
    custom = "custom"


class Fp4Recipe(str, enum.Enum):
    """FP4 recipe names: nvfp4, custom."""

    nvfp4 = "nvfp4"
    custom = "custom"
