# Copyright (c) 2022-2023, NVIDIA CORPORATION.  All rights reserved.

"""Utilities for exchanging data between ranks."""

import hashlib
import logging
import os
import pickle
from collections import defaultdict
from functools import reduce
from itertools import zip_longest
from typing import Any, Dict, List, NamedTuple, Optional, Set, Tuple, TypeVar, cast

import numpy as np
import torch

from megatron.core._rank_utils import safe_get_rank

from .core import CheckpointingException
from .dict_utils import nested_values
from .mapping import ShardedStateDict, ShardedTensor, is_main_replica
from .utils import _quantized_storage_tensors, _sharded_tensor_shard_id, _ShardId, debug_time

# TODO: remove TE references once the TE bug is fixed
# Check if Transformer Engine has Float8Tensor class

try:
    from transformer_engine.pytorch.float8_tensor import Float8Tensor

    HAVE_TE_FLOAT8TENSOR = True
except (ImportError, ModuleNotFoundError):
    # Float8Tensor not found
    HAVE_TE_FLOAT8TENSOR = False


def is_float8tensor(tensor: torch.Tensor) -> bool:
    """Check if a tensor is a Transformer Engine Float8Tensor"""
    return HAVE_TE_FLOAT8TENSOR and isinstance(tensor, Float8Tensor)


logger = logging.getLogger(__name__)


class ShardDistribution(NamedTuple):
    """Represents a distribution of ShardedTensors.

    Given distribution is valid only for a specific parallelization group,
    which is implicit here (not referenced by this class).

    Args:
        main_rank_for_shard (Dict[_ShardId, int]): specifies which rank should hold
            the main replica for a given shard
        shards_in_this_group (Set[_ShardId]): which shards have a main replica
            in this parallelization group
        shard_to_metadata (Dict[_ShardId, ShardedTensor]): maps ShardedTensor
            identifier to the original ShardedTensor
        all_ranks_for_shard (Dict[_ShardId, List[int]]): specifies which ranks
            need a given shard in a given parallelization group
    """

    main_rank_for_shard: Dict[_ShardId, int]
    shards_in_this_group: Set[_ShardId]
    shard_to_metadata: Dict[_ShardId, ShardedTensor]
    all_ranks_for_shard: Dict[_ShardId, List[int]]


def _shard_size(sh_ten: ShardedTensor):
    """Returns size in bytes of a given sharded tensor."""
    numel = np.prod(sh_ten.local_shape)
    return numel * torch._utils._element_size(sh_ten.dtype)


def _get_empty_tensor_for_exchange(
    shard_id: _ShardId,
    needed_shards: Dict[_ShardId, ShardedTensor],
    unneeded_shards: Dict[_ShardId, ShardedTensor],
    loaded_tensors: Dict[_ShardId, torch.Tensor],
) -> Tuple[torch.Tensor, Optional[torch.device]]:
    """Determines the empty tensor to use for exchange.

    If shard_id is needed by this rank, it will be in the `unloaded_shards`.
    Otherwise, the metadata for this tensor can be found in `shard_to_metadata`

    Args:
        shard_id (_ShardId): shard_id that will be exchanged
        needed_shards (Dict[_ShardId, ShardedTensor]): mapping from shard ids
            to metadata for shards needed by this rank
        unneeded_shards (Dict[_ShardId, ShardedTensor]): mapping from shard ids
            to metadata for shards that can be discarded after exchange
        loaded_tensors (Dict[_ShardId, torch.Tensor]): mapping where useful tensors
            are placed in

    Returns:
        Tuple[torch.Tensor, Optional[torch.device]]: empty CUDA tensor to be exchanged,
            and the device of the original state dict tensor (if there was any)
    """
    local_unloaded_sh_ten = needed_shards.get(shard_id)
    if local_unloaded_sh_ten is None:
        orig_device = None  # this tensor will be discarded anyway
        sh_ten = unneeded_shards[shard_id]
        if sh_ten.data is None:
            sh_ten.init_data("cuda")
            tensor = sh_ten.data
            sh_ten.data = None  # won't be used. free memory
        else:
            tensor = sh_ten.data
            if tensor.device.type == "cpu":
                tensor = torch.empty_like(tensor, device="cuda")
    else:
        local_unloaded_sh_ten.init_data("cuda")
        orig_device = local_unloaded_sh_ten.data.device
        tensor = local_unloaded_sh_ten.data
        if tensor.device.type == "cpu":
            tensor = torch.empty_like(tensor, device="cuda")
        loaded_tensors[shard_id] = tensor
    return tensor, orig_device


T = TypeVar("T")


def distribute_shards_to_ranks(
    shard_to_ranks: Dict[T, List[int]],
    shard_to_size: Dict[T, int],
    num_ranks: int,
    cross_parallelization_group_loads: Set[T],
) -> Dict[T, int]:
    """Computes uniform distribution of workload across ranks, based on sizes.

    Currently, the assignment is greedy, based on:
    1. Cross-parallelization group dependencies (shards with main rank in another group
       are assigned at the end to make sure the distribution for load and save
       is as similar as possible).
    2. Secondly, the coverage of each shard
        (how many ranks the shard is available on; lower coverage is assigned first)
    3. Then, the size of each shard (larger size is assigned first)
    4. Finally, shard id for differentiation.

    Last step is added because we rely on the fact that
    the assignment is deterministic on all ranks.

    Args:
        shard_to_ranks (Dict[T, List[int]]): mapping of rank access to shards
        shard_to_size (Dict[T, int]): sizes of each shard
        num_ranks (int): number of ranks in the parallelization group
        cross_parallelization_group_loads (Set[T]): Shards to load that are not in the main replica

    Returns (Dict[T, int]): assignment of shard to rank (which rank should do the work
        to achieve maximal uniformity)
    """
    shard_to_ranks = {k: tuple(v) for k, v in shard_to_ranks.items()}
    shard_to_saving_rank = {}
    rank_sizes = [(0, rank) for rank in range(num_ranks)]

    # start from tensors of lowest coverage, then go by tensor size from largest (hence minus size)
    for shard_id, shard_ranks in sorted(
        shard_to_ranks.items(),
        key=lambda sh_id_ranks: (
            # 0 if rank is not in cross_parallelization_group_loads
            # which means it has higher priority
            int(sh_id_ranks[0] in cross_parallelization_group_loads),
            len(sh_id_ranks[1]),
            -shard_to_size[sh_id_ranks[0]],
            sh_id_ranks[0],
        ),
    ):
        # assign greedily to the least occupied rank
        size, rank = min((size, rank) for size, rank in rank_sizes if rank in shard_ranks)

        shard_to_saving_rank[shard_id] = rank
        rank_sizes[rank] = (size + shard_to_size[shard_id], rank)

    logger.debug(f"distribute_shards_to_ranks distribution: {rank_sizes}")

    return shard_to_saving_rank


# Prefix of the per-parallelization-group cache files written/read by the
# PG-collective caching feature (see `determine_main_replica_uniform_distribution`).
PG_DIST_CACHE_FILE_PREFIX = "pg_dist"

# Process-global in-memory cache of the per-group distributions, keyed by the
# resolved cache file path (which uniquely identifies a (cache dir, group) pair,
# because the file name is derived from the group's ordered global ranks).
# Each entry holds the full {ignore_groups: ShardDistribution} map, so a single
# entry serves both the save and load variants. This memoization makes
# `determine_main_replica_uniform_distribution` idempotent within a job:
#   * CREATE runs the gather + write at most once per group (subsequent calls,
#     e.g. later saves or the second `replicate_local_replicas` call, hit memory
#     and skip the collective and the file write), and
#   * READ opens each group's file at most once per job.
# It is checked *before* the collective so every rank of a group hits or misses
# in lockstep, preserving collective symmetry.
_PG_DIST_CACHE: Dict[str, Dict[bool, "ShardDistribution"]] = {}


def _gather_shards_metadata(
    sharded_state_dict: ShardedStateDict, parallelization_group: torch.distributed.ProcessGroup
) -> List[List[ShardedTensor]]:
    """Runs the single expensive collective behind the load/save distribution.

    Every rank in the group contributes the metadata (no tensor data) of the
    ``ShardedTensor``s it holds; the result is the list of every rank's shard
    metadata, identical on all ranks of the group. This is the
    ``all_gather_object`` that the caching feature exists to eliminate on
    subsequent jobs.

    Decision: data is stripped with ``without_data()`` before the gather. Only
    the metadata (key, offsets, shape, dtype, replica_id) drives the
    distribution algorithm, and gathering it keeps the pickled payload tiny.

    Args:
        sharded_state_dict (ShardedStateDict): state dict whose local shards
            are advertised to the group.
        parallelization_group (ProcessGroup): group to gather within.

    Returns:
        List[List[ShardedTensor]]: per-rank lists of data-less ShardedTensors.
    """
    from ..utils import get_pg_size

    local_shards = list(
        sh_base
        for sh_base in nested_values(sharded_state_dict)
        if isinstance(sh_base, ShardedTensor)
    )
    local_shards_no_data = [ten.without_data() for ten in local_shards]

    all_shards: List[Optional[List[ShardedTensor]]] = [None] * get_pg_size(
        group=parallelization_group
    )
    torch.distributed.all_gather_object(
        all_shards, local_shards_no_data, group=parallelization_group
    )
    return cast(List[List[ShardedTensor]], all_shards)


def _build_shard_distribution(
    all_shards: List[List[ShardedTensor]], ignore_groups: bool
) -> ShardDistribution:
    """Computes a ShardDistribution from already-gathered shard metadata.

    This is the pure, deterministic post-gather logic of
    ``determine_main_replica_uniform_distribution`` factored out so that:
      * it can be run twice (for both ``ignore_groups`` variants) from a single
        gather when creating the cache, and
      * it has no dependence on the local rank, which is what makes the result
        identical on every rank of the group and therefore safe to persist and
        reload across jobs.

    Args:
        all_shards (List[List[ShardedTensor]]): gathered per-rank shard metadata
            (output of ``_gather_shards_metadata``).
        ignore_groups (bool): if True (load mode) include shards whose main
            replica lives outside this group; if False (save mode) restrict to
            shards with a main replica in this group.

    Returns:
        ShardDistribution: the computed distribution.
    """
    shard_to_ranks = defaultdict(list)
    shard_to_size = {}
    shard_to_metadata = {}
    group_has_main_replica: Set[_ShardId] = set()
    group_has_non_main_replica: Set[_ShardId] = set()

    for rank, rank_shards in enumerate(all_shards):
        for sh_ten in rank_shards:
            shard_id = _sharded_tensor_shard_id(sh_ten)
            shard_to_ranks[shard_id].append(rank)
            if shard_id not in shard_to_size:
                shard_to_size[shard_id] = _shard_size(sh_ten)
                shard_to_metadata[shard_id] = sh_ten
            if is_main_replica(sh_ten.replica_id):
                group_has_main_replica.add(shard_id)
            else:
                group_has_non_main_replica.add(shard_id)

    # we always include all main replicas, and non-main only if `ignore_groups`
    shards_in_this_group: Set[_ShardId] = group_has_main_replica
    if ignore_groups:
        shards_in_this_group = shards_in_this_group | group_has_non_main_replica
    # cross-parallel-group references are empty if `not ignore_groups`,
    # otherwise it's `group_has_non_main_replica - group_has_main_replica`
    cross_parallelization_group_loads = shards_in_this_group - group_has_main_replica

    # Filter out shards that don't belong to this group
    shard_to_ranks = {k: v for k, v in shard_to_ranks.items() if k in shards_in_this_group}

    shard_to_saving_rank = distribute_shards_to_ranks(
        shard_to_ranks, shard_to_size, len(all_shards), cross_parallelization_group_loads
    )

    return ShardDistribution(
        shard_to_saving_rank, shards_in_this_group, shard_to_metadata, shard_to_ranks
    )


def _pg_dist_cache_file_path(
    cache_path: str, parallelization_group: torch.distributed.ProcessGroup
) -> str:
    """Returns the cache file path holding the distributions for a given group.

    The file is keyed by a SHA-256 digest of the group's ordered global ranks.
    Decision rationale:
      * The distribution depends on the group's exact membership and rank order,
        so the key must identify both. ``min(global ranks)`` alone is not
        unique: distinct groups can share a minimum rank (for example a
        data-parallel group over ranks [0, 1, 2, 3] and an expert-data-parallel
        group over [0, 2]), and they would then read or overwrite each other's
        distributions.
      * It is computed from purely local metadata
        (``get_process_group_ranks``), so the filename is derivable without any
        collective — essential for the zero-communication read path.
      * Every member of a group maps to the same file (one file per group rather
        than one per rank): far fewer files at scale and a single read per rank,
        with duplicate reads absorbed by the FS page cache.

    Cache files written under the earlier ``pg_dist_<min rank>.pkl`` naming are
    not read; regenerate them with ``--ckpt-pg-tensors-cache-create``.

    Args:
        cache_path (str): directory holding the cache files.
        parallelization_group (ProcessGroup): the group to key on.

    Returns:
        str: absolute-or-relative path of the group's cache file.
    """
    ranks = torch.distributed.get_process_group_ranks(parallelization_group)
    group_key = hashlib.sha256(",".join(map(str, ranks)).encode("ascii")).hexdigest()
    return os.path.join(cache_path, f"{PG_DIST_CACHE_FILE_PREFIX}_{group_key}.pkl")


def _load_pg_dist_cache(cache_file: str) -> Dict[bool, ShardDistribution]:
    """Reads both pre-computed ShardDistributions for a group from disk.

    Returns the full ``{ignore_groups: ShardDistribution}`` map (not just one
    variant) so the caller can memoize both in the process-global cache and serve
    later save/load calls without re-opening the file.

    Performs no existence/validity checks by design (see the feature docs): the
    user opts into the cache only when they guarantee the config and world size
    match the run that created it, trading safety for the lowest possible
    latency.

    Args:
        cache_file (str): resolved path of the group's cache file.

    Returns:
        Dict[bool, ShardDistribution]: the {ignore_groups: distribution} map.
    """
    with open(cache_file, "rb") as f:
        return pickle.load(f)


def _create_pg_dist_cache(
    all_shards: List[List[ShardedTensor]],
    cache_path: str,
    parallelization_group: torch.distributed.ProcessGroup,
) -> Dict[bool, ShardDistribution]:
    """Builds both distribution variants and persists them for the group.

    Both the save (``ignore_groups=False``) and load (``ignore_groups=True``)
    distributions are derived from the *same* gathered metadata, so a single
    collective suffices to populate a cache usable by every later load and save
    — even if the creating job only ever loads (e.g. ``exit_after_loading_ckpt``).

    Only the group's writer rank (global rank == ``min`` of the group) writes,
    keeping create-time IO to one file per group. The write is atomic
    (temp file + ``os.replace``) so a concurrent/interrupted create can never
    leave a torn file that a reader would later trust blindly.

    Args:
        all_shards (List[List[ShardedTensor]]): gathered shard metadata.
        cache_path (str): directory to write the cache file into.
        parallelization_group (ProcessGroup): group being cached.

    Returns:
        Dict[bool, ShardDistribution]: the {ignore_groups: distribution} map,
            so the caller can return the variant it needs without recomputing.
    """
    both: Dict[bool, ShardDistribution] = {
        ignore_groups: _build_shard_distribution(all_shards, ignore_groups)
        for ignore_groups in (False, True)
    }
    ranks = torch.distributed.get_process_group_ranks(parallelization_group)
    if torch.distributed.get_rank() == min(ranks):
        os.makedirs(cache_path, exist_ok=True)
        path = _pg_dist_cache_file_path(cache_path, parallelization_group)
        tmp_path = f"{path}.tmp.{torch.distributed.get_rank()}"
        with open(tmp_path, "wb") as f:
            pickle.dump(both, f)
        os.replace(tmp_path, path)
    return both


def determine_main_replica_uniform_distribution(
    sharded_state_dict: ShardedStateDict,
    parallelization_group: torch.distributed.ProcessGroup,
    ignore_groups: bool = False,
    pg_cache_path: Optional[str] = None,
    pg_cache_create: bool = False,
) -> Optional[ShardDistribution]:
    """Computes (or loads from cache) the load/save shard distribution.

    Should be used in conjunction with `distribute_main_replicas_with_precomputed_distribution`
    which applies the computed save distribution.

    We rely on the fact that the assignment algorithm is deterministic on all ranks,
    so there is no extra communication needed after metadata exchange.

    PG-collective caching:
    The metadata exchange (`all_gather_object`) is by far the dominant cost of
    this function at scale. Its result is a pure deterministic function of the
    sharded state dict structure and the parallel layout, so for a fixed config
    and world size it is identical across jobs and can be cached on disk:

      * ``pg_cache_path`` set, ``pg_cache_create=False`` (READ): skip the
        collective entirely and load the pre-computed distribution for this
        group and mode from disk.
      * ``pg_cache_path`` set, ``pg_cache_create=True`` (CREATE): run the
        collective once, build *both* the save and load distributions from the
        single gather, persist them, and return the requested one.
      * both unset (default): the original behaviour, unchanged.

    Results are additionally memoized in a process-global cache (``_PG_DIST_CACHE``)
    keyed by the group's cache file, so within a single job each group is created
    (gather + write) or read (file open) at most once — later calls (subsequent
    saves, the second ``replicate_local_replicas`` pass, or the save wrapper
    reusing the load wrapper's entry) are served from memory.

    No existence/validity checks are performed on the cache by design — the user
    opts in only when guaranteeing a matching config and world size.

    Args:
        sharded_state_dict (ShardedStateDict): state dict to compute the distribution of
        parallelization_group (ProcessGroup): distribution will be computed
            within this process group
        ignore_groups (bool, optional): whether the distribution defines groups.
            This option is primarily used during loading, as it ensures that all replicas,
            including non-main ones, are loaded by this parallelization group
            Defaults to False.
        pg_cache_path (str, optional): directory of the PG-distribution cache.
            When set, enables the caching feature. Defaults to None (disabled).
        pg_cache_create (bool, optional): when True (and ``pg_cache_path`` set),
            compute the distribution normally and write the cache; when False
            (and ``pg_cache_path`` set), read the cache and skip the collective.
            Defaults to False.

    Returns (ShardDistribution, optional): distribution that can be used to apply the
        parallelization. Returns None if the process_group is trivial (1 rank)

    """
    from ..utils import get_pg_size

    if parallelization_group is None:
        parallelization_group = torch.distributed.group.WORLD
    group_size = get_pg_size(group=parallelization_group)
    if group_size <= 1:
        return

    if pg_cache_path is not None:
        # The resolved file path uniquely identifies this (cache dir, group) and
        # keys the process-global memo. Checking it *first* makes both READ and
        # CREATE idempotent within a job: a second call for the same group (a
        # later save, the second `replicate_local_replicas` call, or the save
        # wrapper reusing what the load wrapper already cached) returns from
        # memory with no collective and no file IO. The check is identical on all
        # ranks of the group, so it never desynchronizes the collective below.
        cache_file = _pg_dist_cache_file_path(pg_cache_path, parallelization_group)
        if cache_file in _PG_DIST_CACHE:
            return _PG_DIST_CACHE[cache_file][bool(ignore_groups)]

        # READ path: no collective; open the file once, then memoize both variants.
        if not pg_cache_create:
            both = _load_pg_dist_cache(cache_file)
            _PG_DIST_CACHE[cache_file] = both
            return both[bool(ignore_groups)]

        # CREATE path: gather once, build & persist both variants, then memoize
        # so no subsequent call for this group gathers or writes again.
        all_shards = _gather_shards_metadata(sharded_state_dict, parallelization_group)
        both = _create_pg_dist_cache(all_shards, pg_cache_path, parallelization_group)
        _PG_DIST_CACHE[cache_file] = both
        return both[bool(ignore_groups)]

    # Default path: unchanged behaviour.
    all_shards = _gather_shards_metadata(sharded_state_dict, parallelization_group)
    return _build_shard_distribution(all_shards, ignore_groups)


@torch.no_grad()
@debug_time(f"exchange_loaded_tensors_gather_rounds", logger)
def exchange_loaded_tensors_gather_rounds(
    loaded_tensors: Dict[_ShardId, torch.Tensor],
    unloaded_shards: Dict[_ShardId, ShardedTensor],
    shard_distribution: ShardDistribution = None,
    parallelization_group: Optional[torch.distributed.ProcessGroup] = None,
) -> Dict[_ShardId, torch.Tensor]:
    """Exchange the tensors loaded by different ranks with several all_gather calls.

    Groups tensors by dtype, divide tensors that will be exchanged into rounds
    and execute all_gather for tensors from each round.

    Note: the loading is distributed across ranks based on total loaded size
    in bytes, so there is no guarantee that number of rounds needed for each
    rank will be similar, which might result in a lot of almost empty
    all_gathers. The solution would be to group all tensors into a one
    bytes tensor and do a single all_gather (with similarly sized messages).

    Args:
        loaded_tensors (Dict[_ShardId, torch.Tensor]): mapping from ShardedTensor
            shard ids to tensors already loaded by this rank.
        unloaded_shards (Dict[_ShardId, torch.Tensor]): mapping from ShardedTensor
            shard ids to ShardedTensors that aren't loaded yet.
        shard_distribution (ShardDistribution): distribution of all shards
        parallelization_group (ProcessGroup, optional): process group used for load
            distribution. Tensors will be exchanged within this group

    Returns:
        Dict[_ShardId, torch.Tensor]: dictionary mapping shard ids to tensors
            needed by this rank to load a given state dict. Includes
            previously loaded tensors (from `loaded_tensors` input)
    """
    from ..utils import get_pg_rank, get_pg_size

    if parallelization_group is None:
        parallelization_group = torch.distributed.group.WORLD
    main_rank_for_shard, _, shard_to_metadata, all_ranks_for_shard = shard_distribution
    local_rank = get_pg_rank(group=parallelization_group)

    all_loaded_tensors = dict(loaded_tensors)

    # Group by dtype so that we all_gather tensors of the same dtype
    for dtype in sorted(set(map(lambda sh_ten: sh_ten.dtype, shard_to_metadata.values())), key=str):
        with debug_time(f"dtype_{dtype}"):
            # shards_by_rank maps rank to tensors loaded by this rank
            shards_by_rank: List[List[torch.Tensor]] = [
                [] for _ in range(get_pg_size(group=parallelization_group))
            ]
            for shard_id, rank in main_rank_for_shard.items():
                if len(all_ranks_for_shard[shard_id]) == 1:
                    assert all_ranks_for_shard[shard_id][0] == main_rank_for_shard[shard_id], (
                        f"When there is only 1 ranks that needs a given shard,"
                        f" it should be the loading rank."
                        f" Got: needs [{all_ranks_for_shard[shard_id][0]}]"
                        f" vs loads [{main_rank_for_shard[shard_id]}]"
                    )
                    # Skipping the exchange since only the loading rank needs this tensor
                    # TODO: we can employ some optimizations even for `len(shard_to_ranks) > 1`
                    #  case, e.g. P2P exchange. Currently handling this case saves most of the
                    #  work though.
                    continue
                if shard_to_metadata[shard_id].dtype == dtype:
                    shards_by_rank[rank].append(shard_id)

            # Transpose `shards_by_rank` to form exchange rounds
            shards_by_round = zip_longest(*shards_by_rank, fillvalue=None)
            for round_idx, round_shard_ids in enumerate(shards_by_round):
                round_tensors = []
                orig_devices = {}
                for rank, shard_id in enumerate(round_shard_ids):
                    if shard_id is None:
                        # if no more useful data, the given rank will exchange empty tensor
                        local_ten = torch.empty(0, dtype=dtype, device="cuda")
                        orig_device = None
                    else:
                        assert isinstance(shard_id, tuple), type(shard_id)
                        if rank == local_rank:
                            assert shard_id in all_loaded_tensors, (
                                shard_id,
                                all_loaded_tensors.keys(),
                            )
                            orig_device = all_loaded_tensors[shard_id]
                            all_loaded_tensors[shard_id] = all_loaded_tensors[shard_id].cuda()
                            local_ten = all_loaded_tensors[shard_id]
                        else:
                            local_ten, orig_device = _get_empty_tensor_for_exchange(
                                shard_id, unloaded_shards, shard_to_metadata, all_loaded_tensors
                            )
                        # Because of a TE bug, we have to exchange a nominal dtype instead of FP8
                        # It's ok to keep the nominal dtype after exchange, because TE will handle
                        # this during state dict load.
                        # TODO: remove it once the bug is fixed
                        from ..fp8_utils import is_float8tensor  # Avoid circular import

                        if is_float8tensor(local_ten):
                            try:
                                local_ten = local_ten.from_float8()
                            except Exception as e:
                                local_ten = local_ten.dequantize()
                            all_loaded_tensors[shard_id] = local_ten

                    round_tensors.append(local_ten)
                    if orig_device is not None:
                        orig_devices[shard_id] = orig_device

                torch.distributed.all_gather(
                    list(round_tensors),
                    round_tensors[local_rank],
                    group=parallelization_group,
                    async_op=False,
                )

                # Move tensors back to CPU if originally was on CPU
                for shard_id, orig_device in orig_devices.items():
                    all_loaded_tensors[shard_id] = all_loaded_tensors[shard_id].to(orig_device)

                del round_tensors  # remove tensor references

    return all_loaded_tensors


def exchange_loaded_tensors_gather_object(
    loaded_tensors: Dict[_ShardId, torch.Tensor],
    unloaded_shards: Dict[_ShardId, ShardedTensor],
    shard_distribution: ShardDistribution,
    parallelization_group: Optional[torch.distributed.ProcessGroup] = None,
) -> Dict[_ShardId, torch.Tensor]:
    """Exchange the tensors loaded by different ranks with a simple all_gather_object call.

    This version can be used for debugging purposes do to its simplistic
    implementation. Shouldn't be used if performance is important.

    Args:
        loaded_tensors (Dict[_ShardId, torch.Tensor]): mapping from ShardedTensor
            shard ids to tensors already loaded by this rank.
        unloaded_shards (Dict[_ShardId, torch.Tensor]): mapping from ShardedTensor
            shard ids to ShardedTensors that aren't loaded yet.
        shard_distribution (ShardDistribution): distribution of all shards
        parallelization_group (ProcessGroup, optional): process group used for load
            distribution. Tensors will be exchanged within this group

    Returns:
        Dict[_ShardId, torch.Tensor]: dictionary mapping shard ids to tensors
            needed by this rank to load a given state dict. Includes
            previously loaded tensors (from `loaded_tensors` input)

    """
    all_loaded_tensors_list = [None] * torch.distributed.get_world_size(group=parallelization_group)
    torch.distributed.all_gather_object(
        all_loaded_tensors_list, loaded_tensors, group=parallelization_group
    )
    all_loaded_tensors_list = cast(List[Dict[_ShardId, torch.Tensor]], all_loaded_tensors_list)
    all_loaded_tensors = reduce(lambda x, y: {**x, **y}, all_loaded_tensors_list)

    # Error checks
    if len(all_loaded_tensors) != sum(map(len, all_loaded_tensors_list)):
        err_msg = "Duplicate shard ids loaded by different ranks"
        if logger.isEnabledFor(logging.ERROR) and safe_get_rank() == 0:
            shard_ids_by_rank = [
                rank_loaded_tensors.keys() for rank_loaded_tensors in all_loaded_tensors_list
            ]
            logger.error("%s. Shards ids by rank: %s", err_msg, shard_ids_by_rank)
        raise CheckpointingException(err_msg)

    return all_loaded_tensors


def exchange_loaded_objects_gather_object(
    loaded_objects: Dict[_ShardId, Any],
) -> Dict[_ShardId, Any]:
    """Exchange the objects loaded by different ranks with a simple all_gather_object call.

    Args:
        loaded_objects (Dict[_ShardId, Any]): mapping from shard ids to objects
          already loaded by this rank.

    Returns:
        Dict[_ShardId, Any]: dictionary mapping shard ids to objects needed by this rank to
         load a given state dict.
    """
    all_loaded_objects_list = [None] * torch.distributed.get_world_size()
    torch.distributed.all_gather_object(all_loaded_objects_list, loaded_objects, group=None)
    all_loaded_objects_list = cast(List[Dict[_ShardId, Any]], all_loaded_objects_list)
    all_loaded_objects = reduce(lambda x, y: {**x, **y}, all_loaded_objects_list)

    # Error checks
    if len(all_loaded_objects) != sum(map(len, all_loaded_objects_list)):
        err_msg = "Duplicate shard ids loaded by different ranks"
        if logger.isEnabledFor(logging.ERROR) and safe_get_rank() == 0:
            shard_ids_by_rank = [
                rank_loaded_objects.keys() for rank_loaded_objects in all_loaded_objects_list
            ]
            logger.error("%s. Shards ids by rank: %s", err_msg, shard_ids_by_rank)
        raise CheckpointingException(err_msg)

    return all_loaded_objects


@torch.no_grad()
@debug_time("exchange_loaded_tensors_broadcast", logger)
def exchange_loaded_tensors_broadcast(
    loaded_tensors: Dict[_ShardId, torch.Tensor],
    unloaded_shards: Dict[_ShardId, ShardedTensor],
    shard_distribution: ShardDistribution,
    parallelization_group: Optional[torch.distributed.ProcessGroup] = None,
) -> Dict[_ShardId, torch.Tensor]:
    """Exchange the tensors loaded by different ranks by a series of broadcasts.

    For each rank for each loaded tensor do a broadcast to the whole group.
    A reasonable tradeoff in terms of performance and simplicity.

    Args:
        loaded_tensors (Dict[_ShardId, torch.Tensor]): mapping from ShardedTensor
            shard ids to tensors already loaded by this rank.
        unloaded_shards (Dict[_ShardId, ShardedTensor]): mapping from ShardedTensor
            shard ids to ShardedTensors that aren't loaded yet.
        shard_distribution (ShardDistribution): distribution of all shards
        parallelization_group (ProcessGroup, optional): process group used for load
            distribution. Tensors will be exchanged within this group

    Returns:
        Dict[_ShardId, torch.Tensor]: dictionary mapping shard ids to tensors
            needed by this rank to load a given state dict. Includes
            previously loaded tensors (from `loaded_tensors` input)
    """
    main_rank_for_shard, _, shard_to_metadata, all_ranks_for_shard = shard_distribution
    local_rank = torch.distributed.get_rank(group=parallelization_group)

    all_loaded_tensors = dict(loaded_tensors)

    for idx, (shard_id, rank) in enumerate(main_rank_for_shard.items()):
        if len(all_ranks_for_shard[shard_id]) == 1:
            assert all_ranks_for_shard[shard_id][0] == main_rank_for_shard[shard_id], (
                f"When there is only 1 ranks that needs a given shard,"
                f" it should be the loading rank."
                f"Got: needs [{all_ranks_for_shard[shard_id][0]}]"
                f" vs loads [{main_rank_for_shard[shard_id]}]"
            )
            # Skipping the exchange since only the loading rank needs this tensor
            # TODO: we can employ some optimizations even for `len(shard_to_ranks) > 1` case,
            #  e.g. P2P exchange. Currently handling this case saves most of the work though.
            continue
        if rank == local_rank:
            assert shard_id in all_loaded_tensors, (shard_id, all_loaded_tensors.keys())
            orig_device = all_loaded_tensors[shard_id].device
            local_ten = all_loaded_tensors[shard_id].cuda()
        else:
            local_ten, orig_device = _get_empty_tensor_for_exchange(
                shard_id, unloaded_shards, shard_to_metadata, all_loaded_tensors
            )

        # Because of a TE bug, we have to exchange a nominal dtype instead of FP8
        # It's ok to keep the nominal dtype after exchange, because TE will handle
        # this during state dict load.
        # TODO: remove it once the bug is fixed
        from ..fp8_utils import is_float8tensor  # Avoid circular import

        if is_float8tensor(local_ten):
            try:
                local_ten = local_ten.from_float8()
            except Exception as e:
                local_ten = local_ten.dequantize()
            all_loaded_tensors[shard_id] = local_ten

        global_src_rank = (
            rank
            if parallelization_group == None
            else torch.distributed.get_global_rank(parallelization_group, rank)
        )
        # We can do async_op=True only if there is no CPU-copy follow-up
        torch.distributed.broadcast(
            local_ten,
            src=global_src_rank,
            group=parallelization_group,
            async_op=orig_device is None,
        )
        # Move tensor back to CPU if originally was on CPU
        if orig_device is not None:
            all_loaded_tensors[shard_id] = local_ten.to(orig_device)
        del local_ten

    return all_loaded_tensors


_QUANTIZED_STORAGE_PART_ALIGNMENT = 16


def _aligned_nbytes(nbytes: int) -> int:
    return -(-nbytes // _QUANTIZED_STORAGE_PART_ALIGNMENT) * _QUANTIZED_STORAGE_PART_ALIGNMENT


def _quantized_storage_nbytes(tensor: torch.Tensor) -> int:
    """Size of the packed quantized storage of a TE quantized tensor (see `_pack_...`)."""
    return sum(
        _aligned_nbytes(part.numel() * part.element_size())
        for part in _quantized_storage_tensors(tensor)
    )


def _pack_quantized_storage(tensor: torch.Tensor) -> torch.Tensor:
    """Packs the raw storage of a TE quantized tensor (codes and scales) into one byte buffer.

    Exchanging the raw storage instead of the dequantized values keeps the loading rank's
    encoding bit for bit on the receivers (re-quantizing dequantized values can pick different
    block scales) and halves the exchanged bytes. Parts are 16-byte aligned so that every part
    can be viewed in place with its own dtype.
    """
    buf = torch.empty(_quantized_storage_nbytes(tensor), dtype=torch.uint8, device=tensor.device)
    offset = 0
    for part in _quantized_storage_tensors(tensor):
        nbytes = part.numel() * part.element_size()
        buf[offset : offset + nbytes].view(part.dtype).view(part.shape).copy_(part)
        offset += _aligned_nbytes(nbytes)
    return buf


def _unpack_quantized_storage(buf: torch.Tensor, tensor: torch.Tensor) -> None:
    """Inverse of `_pack_quantized_storage`, writing into the storage of `tensor`."""
    offset = 0
    for part in _quantized_storage_tensors(tensor):
        nbytes = part.numel() * part.element_size()
        part.copy_(buf[offset : offset + nbytes].view(part.dtype).view(part.shape))
        offset += _aligned_nbytes(nbytes)
    if offset != buf.numel():
        raise CheckpointingException(
            f'Packed quantized storage ({buf.numel()} bytes) does not match the destination'
            f' ({offset} bytes)'
        )


def exchange_loaded_tensors_broadcast_quantized(
    loaded_tensors: Dict[_ShardId, torch.Tensor],
    unloaded_shards: Dict[_ShardId, ShardedTensor],
    shard_distribution: ShardDistribution,
    parallelization_group: Optional[torch.distributed.ProcessGroup] = None,
) -> Dict[_ShardId, torch.Tensor]:
    """`exchange_loaded_tensors_broadcast` for state dicts with quantized destinations.

    Used by the streaming dequantize load, which loads quantized destinations in place on the
    loading rank. Such tensors are broadcast as their packed raw storage (see
    `_pack_quantized_storage`) and unpacked straight into the receivers' destinations, so that
    every rank ends up with the loading rank's encoding and no high-precision copy is created.
    Other tensors are exchanged as by `exchange_loaded_tensors_broadcast`.

    Args: see `exchange_loaded_tensors_broadcast`.
    """
    from ..fp8_utils import is_float8tensor  # Avoid circular import

    main_rank_for_shard, _, shard_to_metadata, all_ranks_for_shard = shard_distribution
    local_rank = torch.distributed.get_rank(group=parallelization_group)

    # Ranks that do not need a shard still take part in its broadcast and must know the size of
    # its packed storage, which only the loading rank knows: gather the sizes once up front.
    local_nbytes = {
        shard_id: _quantized_storage_nbytes(tensor)
        for shard_id, tensor in loaded_tensors.items()
        if is_float8tensor(tensor)
    }
    all_nbytes = [None] * torch.distributed.get_world_size(group=parallelization_group)
    torch.distributed.all_gather_object(all_nbytes, local_nbytes, group=parallelization_group)
    quantized_nbytes = {k: v for rank_nbytes in all_nbytes for k, v in rank_nbytes.items()}

    if not quantized_nbytes:
        return exchange_loaded_tensors_broadcast(
            loaded_tensors, unloaded_shards, shard_distribution, parallelization_group
        )

    plain_loaded_tensors = {k: v for k, v in loaded_tensors.items() if k not in quantized_nbytes}
    plain_distribution = ShardDistribution(
        {k: v for k, v in main_rank_for_shard.items() if k not in quantized_nbytes},
        shard_distribution.shards_in_this_group,
        shard_to_metadata,
        all_ranks_for_shard,
    )
    all_loaded_tensors = exchange_loaded_tensors_broadcast(
        plain_loaded_tensors, unloaded_shards, plain_distribution, parallelization_group
    )

    for shard_id, rank in main_rank_for_shard.items():
        if shard_id not in quantized_nbytes:
            continue
        nbytes = quantized_nbytes[shard_id]
        if rank == local_rank:
            all_loaded_tensors[shard_id] = loaded_tensors[shard_id]
        if len(all_ranks_for_shard[shard_id]) == 1:
            # Only the loading rank needs this tensor, no exchange needed.
            continue
        if rank == local_rank:
            quantized = loaded_tensors[shard_id]
            buf = _pack_quantized_storage(quantized)
        else:
            quantized = unloaded_shards[shard_id].data if shard_id in unloaded_shards else None
            if quantized is not None and (
                not is_float8tensor(quantized) or _quantized_storage_nbytes(quantized) != nbytes
            ):
                raise CheckpointingException(
                    f'Shard {shard_id} was loaded as a quantized tensor on rank {rank} but its'
                    f' destination on rank {local_rank} does not have the same quantized storage'
                )
            buf = torch.empty(nbytes, dtype=torch.uint8, device='cuda')
        global_src_rank = (
            rank
            if parallelization_group is None
            else torch.distributed.get_global_rank(parallelization_group, rank)
        )
        torch.distributed.broadcast(buf, src=global_src_rank, group=parallelization_group)
        if rank != local_rank and quantized is not None:
            with torch.no_grad():
                _unpack_quantized_storage(buf, quantized)
            # Hand back a view rather than the destination object itself: `load_state_dict`
            # copies the loaded tensor into the param, and TE's generic quantized `copy_`
            # cannot copy a tensor onto itself (it detaches the source storage first).
            all_loaded_tensors[shard_id] = quantized.view(quantized.shape)
        del buf

    return all_loaded_tensors


def exchange_by_distribution(
    loaded_tensors: Dict[_ShardId, torch.Tensor],
    unloaded_shards: Dict[_ShardId, ShardedTensor],
    shard_distribution: ShardDistribution,
    parallelization_group: Optional[torch.distributed.ProcessGroup] = None,
    exchange_algo="broadcast",
    exchange_quantized_storage: bool = False,
) -> Dict[_ShardId, torch.Tensor]:
    """Exchange tensors loaded by different ranks using the specified exchange_algo.

    Args:
        loaded_tensors (Dict[_ShardId, torch.Tensor]): mapping from ShardedTensor
            shard ids to tensors already loaded by this rank.
        unloaded_shards (Dict[_ShardId, ShardedTensor]): mapping from ShardedTensor
            shard ids to ShardedTensors that aren't loaded yet.
        shard_distribution (ShardDistribution): distribution of all shards
        parallelization_group (ProcessGroup, optional): process group used for load
            distribution. Tensors will be exchanged within this group
        exchange_algo (str): The algorithm used for performing exchanges.
            Defaults to 'broadcast'.
        exchange_quantized_storage (bool): with the 'broadcast' algorithm, exchange quantized
            tensors as their raw storage and unpack them into the receivers' quantized
            destinations (streaming dequantize load), see
            `exchange_loaded_tensors_broadcast_quantized`.

    Returns:
        Dict[_ShardId, torch.Tensor]: dictionary mapping shard ids to tensors
            needed by this rank to load a given state dict. Includes
            previously loaded tensors (from `loaded_tensors` input)
    """

    assert shard_distribution is not None, "Expecting distribution to perform exchange"
    if exchange_algo == "gather_object":
        exchange_fn = exchange_loaded_tensors_gather_object
    elif exchange_algo == "gather_rounds":
        exchange_fn = exchange_loaded_tensors_gather_rounds
    elif exchange_algo == "broadcast":
        exchange_fn = (
            exchange_loaded_tensors_broadcast_quantized
            if exchange_quantized_storage
            else exchange_loaded_tensors_broadcast
        )
    else:
        raise NotImplementedError(f"Unrecognized gather algorithm: {exchange_algo}")
    return exchange_fn(loaded_tensors, unloaded_shards, shard_distribution, parallelization_group)
