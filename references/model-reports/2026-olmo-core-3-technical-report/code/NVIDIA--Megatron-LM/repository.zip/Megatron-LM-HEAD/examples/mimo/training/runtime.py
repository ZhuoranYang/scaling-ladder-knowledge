# Copyright (c) 2026, NVIDIA CORPORATION. All rights reserved.

"""Per-rank runtime setup (RNG seeding, freezing, DDP wrapping) for hetero MIMO training."""

from __future__ import annotations

import argparse
from dataclasses import replace

import torch

from examples.mimo.training.topology import HeteroTopology
from megatron.core.distributed import DistributedDataParallelConfig
from megatron.core.models.mimo.config.role import MIMO_LANGUAGE_MODULE_KEY
from megatron.core.models.mimo.model.base import MimoEncoderFloat16Module, MimoModel
from megatron.core.process_groups_config import ProcessGroupCollection
from megatron.core.transformer.module import Float16Module
from megatron.training.initialize import _set_random_seed
from megatron.training.models.dist_utils import (
    prepare_existing_model_chunks_for_distributed_training,
)
from megatron.training.utils import print_rank_0
from megatron.training.global_vars import get_run_config

# Preserve the previous example-local import path.
_EncoderFloat16Module = MimoEncoderFloat16Module


def configure_module_rng(
    args: argparse.Namespace,
    pg_collection: ProcessGroupCollection,
    role_seed_offset: int,
    data_parallel_random_init: bool = False,
) -> None:
    """Seed one active module role through the stock explicit-process-group path.

    The seed is shared across a module's DP/CP replicas but distinct across PP stages and roles,
    so disjoint modules (and stages) get independent RNG state. Caller invokes once per active
    module on this rank.
    """
    cfg = get_run_config()
    for _required in ("pp", "dp", "tp", "ep", "expt_tp", "gtp_remat", "expt_gtp_remat"):
        assert (
            getattr(pg_collection, _required, None) is not None
        ), f"pg_collection passed to configure_module_rng must define {_required}"
    _set_random_seed(
        cfg.rng.seed + role_seed_offset,
        data_parallel_random_init,
        te_rng_tracker=cfg.rng.te_rng_tracker,
        inference_rng_tracker=cfg.rng.inference_rng_tracker,
        use_cudagraphable_rng=getattr(args, "cuda_graph_impl", "none") != "none",
        pp_group=pg_collection.pp,
        dp_group=pg_collection.dp,
        tp_group=pg_collection.tp,
        ep_group=pg_collection.ep,
        etp_group=pg_collection.expt_tp,
        gtp_remat_group=pg_collection.gtp_remat,
        egtp_remat_group=pg_collection.expt_gtp_remat,
    )


def _freeze_modality_submodule(submodule: torch.nn.Module, args: argparse.Namespace) -> None:
    """Freeze the encoder backbone (--freeze-vit) and/or projector (--freeze-projection)."""
    if getattr(args, "freeze_vit", False):
        submodule.encoders.requires_grad_(False)
    if getattr(args, "freeze_projection", False):
        submodule.input_projections.requires_grad_(False)
        submodule.output_projections.requires_grad_(False)


def _module_config(module: torch.nn.Module):
    """Return the module's own config, else the first descendant config (e.g. an encoder)."""
    config = getattr(module, "config", None)
    if config is not None:
        return config
    for child in module.modules():
        config = getattr(child, "config", None)
        if config is not None:
            return config
    raise ValueError("Cannot resolve a config for DDP wrapping from module")


def _ddp_config_for_role(
    ddp_config: DistributedDataParallelConfig, enable_overlap: bool
) -> DistributedDataParallelConfig:
    """Derive a role-specific DDP config without mutating the caller's config."""
    return replace(
        ddp_config,
        overlap_grad_reduce=ddp_config.overlap_grad_reduce and enable_overlap,
        overlap_param_gather=ddp_config.overlap_param_gather and enable_overlap,
    )


def wrap_active_modules_with_ddp(
    args: argparse.Namespace,
    mimo_model: MimoModel,
    topology: HeteroTopology,
    ddp_config: DistributedDataParallelConfig,
    data_parallel_random_init: bool = False,
    use_layer_wise_distributed_optimizer: bool = False,
    use_layer_wise_param_layout: bool = True,
) -> None:
    """Freeze (per --freeze-* flags), Float16Module-wrap, and DDP-wrap each active module."""
    if mimo_model.language_model is not None:
        freeze_projection = bool(getattr(args, "freeze_projection", False))
        input_projections = mimo_model.language_model_input_projections
        assert input_projections is not None
        if getattr(args, "freeze_lm", False):
            mimo_model.language_model.requires_grad_(False)
            if not freeze_projection:
                input_projections.requires_grad_(True)
        elif freeze_projection:
            input_projections.requires_grad_(False)
        lm_config = _module_config(mimo_model.language_model)
        print_rank_0("wrapping language model in DDP")
        mimo_model.language_model = prepare_existing_model_chunks_for_distributed_training(
            [mimo_model.language_model],
            lm_config,
            topology.module_pgs[MIMO_LANGUAGE_MODULE_KEY],
            ddp_config=_ddp_config_for_role(ddp_config, enable_overlap=True),
            data_parallel_random_init=data_parallel_random_init,
            mixed_precision_wrapper=Float16Module,
            use_layer_wise_distributed_optimizer=use_layer_wise_distributed_optimizer,
            use_layer_wise_param_layout=use_layer_wise_param_layout,
        )[0]

    for name, submodule in mimo_model.modality_submodules.items():
        if submodule is None or name not in topology.module_pgs:
            continue
        _freeze_modality_submodule(submodule, args)
        enc_config = _module_config(submodule)
        print_rank_0(f"wrapping modality submodule {name!r} in DDP")
        mimo_model.modality_submodules[name] = (
            prepare_existing_model_chunks_for_distributed_training(
                [submodule],
                enc_config,
                topology.module_pgs[name],
                ddp_config=_ddp_config_for_role(
                    ddp_config, enable_overlap=getattr(args, "mimo_encoder_ddp_overlap", False)
                ),
                data_parallel_random_init=data_parallel_random_init,
                mixed_precision_wrapper=MimoEncoderFloat16Module,
                use_layer_wise_distributed_optimizer=use_layer_wise_distributed_optimizer,
                use_layer_wise_param_layout=use_layer_wise_param_layout,
            )[0]
        )
