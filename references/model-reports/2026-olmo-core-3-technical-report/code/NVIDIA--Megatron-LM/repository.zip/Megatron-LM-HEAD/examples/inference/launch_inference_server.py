# Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.

"""OpenAI-compatible inference server using the Megatron high-level API.

Mirrors tools/run_dynamic_text_generation_server.py but drives the
`DynamicInferenceEngine` through `MegatronAsyncLLM.serve(...)` instead
of building the coordinator/engine pipeline manually. Coordinator mode is
required (HTTP serving uses the coordinator path); `use_coordinator=True`
is hardcoded in the script.
"""

import asyncio
import os
import sys
from argparse import ArgumentParser

import torch
import torch.distributed as dist

sys.path.append(
    os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir))
)

from megatron.core.inference.apis import MegatronAsyncLLM, ServeConfig
from megatron.core.inference.shards import build_inference_pg_collections_for_shards
from megatron.core.inference.shards_spec import spec_declares_disaggregation
from megatron.core.utils import configure_nvtx_profiling
from megatron.inference.utils import (
    add_inference_args,
    get_inference_config_from_model_and_args,
    get_model_for_inference,
)
from megatron.training import get_args, initialize_megatron
from megatron.training.arguments import parse_and_validate_args
from megatron.training.argument_utils import inference_cfg_container_from_args
from megatron.training.global_vars import get_run_config, get_tokenizer, set_run_config


def add_serve_args(parser: ArgumentParser) -> ArgumentParser:
    parser = add_inference_args(parser)
    group = parser.add_argument_group(title='High-level inference server')
    group.add_argument("--coordinator-host", type=str, default=None)
    group.add_argument("--coordinator-port", type=int, default=None)
    group.add_argument("--host", type=str, default="0.0.0.0", help="HTTP bind host")
    group.add_argument("--port", type=int, default=5000, help="HTTP bind port")
    group.add_argument("--parsers", type=str, nargs="+", default=[], help="Response parser names")
    group.add_argument(
        "--verbose", action="store_true", default=False, help="Per-request HTTP logging"
    )
    group.add_argument(
        "--frontend-replicas",
        type=int,
        default=4,
        help="Number of HTTP frontend processes spawned on the primary rank.",
    )
    group.add_argument(
        "--default-temperature",
        type=float,
        default=None,
        help="Server-level temperature default when a request omits temperature. "
        "Takes precedence over the model's generation_config.json; unset leaves "
        "that free to apply, falling back to 1.0 if neither is set.",
    )
    group.add_argument(
        "--default-top-p",
        type=float,
        default=None,
        help="Server-level top-p default when a request omits top_p. "
        "Takes precedence over the model's generation_config.json; unset leaves "
        "that free to apply, falling back to 1.0 if neither is set.",
    )
    group.add_argument(
        "--default-top-k",
        type=int,
        default=None,
        help="Server-level top-k default when a request omits top_k. "
        "Takes precedence over the model's generation_config.json; unset leaves "
        "that free to apply, falling back to 0 if neither is set.",
    )
    group.add_argument(
        "--eval-mode",
        action="store_true",
        help="Avoid returning prompt token IDs by default for pure serving.",
    )
    return parser


def _build_model_and_inference_config(args):
    """Build the model on either global or role-tagged inference process groups."""

    if spec_declares_disaggregation(args.inference_shards):
        world_size = dist.get_world_size()
        shards = build_inference_pg_collections_for_shards(world_size, args.inference_shards)
        local_shard = next(shard for shard in shards if shard.pg_collection is not None)
        model = get_model_for_inference(
            pg_collection=local_shard.pg_collection,
            checkpoint_group=local_shard.process_group,
        )
        inference_config = get_inference_config_from_model_and_args(model, args)
        inference_config.pg_collection = local_shard.pg_collection
        return model, inference_config

    model = get_model_for_inference()
    inference_config = get_inference_config_from_model_and_args(model, args)
    return model, inference_config


async def _serve(args, model, tokenizer, inference_config):
    async with MegatronAsyncLLM(
        model=model,
        tokenizer=tokenizer,
        inference_config=inference_config,
        use_coordinator=True,
        coordinator_host=args.coordinator_host,
        coordinator_port=args.coordinator_port,
    ) as llm:
        serve_config = ServeConfig(
            host=args.host,
            port=args.port,
            parsers=args.parsers,
            verbose=args.verbose,
            frontend_replicas=args.frontend_replicas,
            default_temperature=args.default_temperature,
            default_top_p=args.default_top_p,
            default_top_k=args.default_top_k,
            eval_mode=args.eval_mode,
        )
        await llm.serve(serve_config, blocking=True)


def main():
    args = parse_and_validate_args(
        extra_args_provider=add_serve_args,
        args_defaults={'no_load_rng': True, 'no_load_optim': True},
    )
    # Temporary args/config duplication during the training-loop refactor:
    # migrated settings use config; remaining settings still use legacy args.
    set_run_config(inference_cfg_container_from_args(args, build_model_config=False))
    initialize_megatron()

    args = get_args()

    # Match the legacy tool's NVTX gating.
    # Temporary args/config duplication during the training-loop refactor:
    # migrated settings use config; remaining settings still use legacy args.
    cfg = get_run_config()
    if (cfg.profiling.use_nsys_profiler or cfg.profiling.use_pytorch_profiler) and cfg.profiling.nvtx_ranges:
        configure_nvtx_profiling(True)

    tokenizer = get_tokenizer()
    model, inference_config = _build_model_and_inference_config(args)

    try:
        asyncio.run(_serve(args, model, tokenizer, inference_config))
    except KeyboardInterrupt:
        print("Server process interrupted by user.")
    finally:
        if torch.distributed.is_initialized():
            torch.distributed.destroy_process_group()


if __name__ == "__main__":
    main()
