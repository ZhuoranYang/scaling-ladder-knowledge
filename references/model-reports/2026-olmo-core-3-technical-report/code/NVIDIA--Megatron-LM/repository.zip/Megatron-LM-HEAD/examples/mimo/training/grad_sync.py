# Copyright (c) 2026, NVIDIA CORPORATION. All rights reserved.

"""Dual gradient finalization for MIMO training on the stock Megatron loop."""

from __future__ import annotations

import torch
import torch.distributed as dist

from examples.mimo.training.topology import HeteroTopology
from megatron.core.distributed.finalize_model_grads import finalize_model_grads
from megatron.core.models.mimo.config.role import MIMO_LANGUAGE_MODULE_KEY
from megatron.core.models.mimo.model.base import MimoModel
from megatron.core.pipeline_parallel.utils import is_pp_last_stage
from megatron.training.global_vars import get_run_config

# Sentinel set per modality submodule when this rank had that modality's input this step.
_PARTICIPATED_ATTR = "_mimo_rank_processed_input"


def _has_modality_input(value) -> bool:
    """Whether this rank received this modality's input this step.

    The batch omits a modality's key when absent, so ``value`` is None (not present) or a
    non-empty nested dict (present); an empty tensor also counts as absent.
    """
    if isinstance(value, torch.Tensor):
        return value.numel() > 0
    return bool(value)


def mark_modality_participation(mimo_model: MimoModel, batch) -> None:
    """Tag each modality submodule with whether this rank had that modality's input this step.

    Reads ``batch["modality_inputs"]`` (keyed by modality name) so the flag is per modality
    rather than vision-specific.
    """
    modality_inputs = batch.get("modality_inputs", {}) if isinstance(batch, dict) else {}
    for name, submodule in mimo_model.modality_submodules.items():
        if submodule is not None:
            setattr(submodule, _PARTICIPATED_ATTR, _has_modality_input(modality_inputs.get(name)))


def reset_modality_participation(mimo_model: MimoModel) -> None:
    """Clear per-step participation flags at the top of each train step."""
    for submodule in mimo_model.modality_submodules.values():
        if submodule is not None:
            setattr(submodule, _PARTICIPATED_ATTR, False)


def _vision_participation_count(submodule, vision_dp_group) -> torch.Tensor:
    """Scalar count of vision-DP ranks that processed image input this step."""
    val = 1.0 if getattr(submodule, _PARTICIPATED_ATTR, False) else 0.0
    indicator = torch.tensor(val, dtype=torch.float32, device="cuda")
    dist.all_reduce(indicator, op=dist.ReduceOp.SUM, group=vision_dp_group)
    return indicator


def _token_normalization_scale(num_tokens: torch.Tensor) -> torch.Tensor:
    """Return a device-side reciprocal, leaving zero-token gradients unscaled."""
    return num_tokens.clamp_min(1).reciprocal()


def _is_pg_member(pg) -> bool:
    """Whether the current rank belongs to ``pg`` (defensive; -1 for non-members)."""
    return pg is not None and dist.get_rank(group=pg) >= 0


def _is_token_source_rank(language_pg) -> bool:
    """Whether this rank is on the LLM (last PP stage, TP rank 0) coordinate that sums
    the global token count over all data lanes.

    Sourcing from this single coordinate avoids double-counting across TP/PP replicas.
    The _is_pg_member guards short-circuit encoder-grid ranks (non-member pp/tp groups)
    so they never participate.
    """
    if language_pg is None:
        return False
    pp = getattr(language_pg, "pp", None)
    tp = getattr(language_pg, "tp", None)
    return (
        _is_pg_member(pp)
        and _is_pg_member(tp)
        and is_pp_last_stage(pp)
        and dist.get_rank(group=tp) == 0
    )


def _token_source_global_rank(language_grid) -> int:
    """Global rank of the single LLM token-source coordinate (tp=0, cp=0, dp=0, pp=last).

    Derived statically from ``get_rank_enum("pp")`` (the grid's authoritative rank
    enumeration, identical on every rank), so encoder-grid ranks in no LLM group can name
    it. The global minimum rank is (tp=0, cp=0, dp=0), so its PP line is the source line
    and that line's last entry is the (pp=last) source rank.
    """
    pp_lines = language_grid.get_rank_enum("pp")
    min_rank = min(rank for line in pp_lines for rank in line)
    for line in pp_lines:
        if min_rank in line:
            return int(line[-1])
    raise RuntimeError(
        f"Could not derive token-source global rank from language grid pp_lines={pp_lines}"
    )


def _global_token_count(num_tokens, language_pg, src_global_rank) -> torch.Tensor:
    """Total non-padded tokens in the global batch, visible on every rank.

    Only the LLM token-source ranks compute the count by summing over all LLM data lanes;
    the source then broadcasts N_global from its global rank to every rank in the
    world (including the non-colocated encoder grid, where ``language_pg`` is None) so
    both modules divide by the same per-token mean.
    """
    global_num_tokens = torch.zeros((), dtype=torch.float32, device="cuda")
    if _is_token_source_rank(language_pg):
        data_group = language_pg.dp_cp_gtp_remat or language_pg.dp_cp
        token_count = num_tokens.to(dtype=torch.float32).sum()
        dist.all_reduce(token_count, group=data_group, op=dist.ReduceOp.SUM)
        if dist.get_rank(group=data_group) == 0:
            global_num_tokens.copy_(token_count)
    dist.broadcast(global_num_tokens, src=src_global_rank)
    return global_num_tokens


def configure_grad_sync(args, mimo_model: MimoModel, topology: HeteroTopology) -> None:
    """Configure per-module gradient finalization: each module finalizes over its own groups.

    The encoder and LLM have decoupled parallelism (separate grids), so each reduces its
    gradients over its own process-group collection; both then divide by one shared
    per-token mean (N_global).

    MimoModel structure (each a separately DDP-wrapped module on its own grid)::

        MimoModel
        ├─ language_model          (LLM)      -> own process groups
        └─ modality_submodules[*]  (encoders) -> own process groups
    """
    module_pgs = topology.module_pgs
    language_pg = module_pgs.get(MIMO_LANGUAGE_MODULE_KEY)
    # Broadcast root for N_global; derived statically so encoder-grid ranks (in no LLM
    # group) can still name it.
    src_global_rank = _token_source_global_rank(topology.grids[MIMO_LANGUAGE_MODULE_KEY])
    correct_vision_grad = bool(
        getattr(args, "correct_encoder_grad_for_partial_participation", False)
    )

    def finalize_grads_func(_model_list, num_tokens, force_all_reduce=False, **_kwargs):
        # calculate_per_token_loss=True => DDP gradient_scaling_factor 1.0 (pure SUM),
        # so the per-token mean is applied here by dividing every shard by N_global.
        assert num_tokens is not None, (
            "MIMO grad sync expects calculate_per_token_loss=True so the schedule "
            "forwards total_num_tokens; got None."
        )

        # N_global is the global token count, published to every rank (including the
        # non-colocated encoder grid) so both modules divide by the same per-token mean.
        n_global = _global_token_count(num_tokens, language_pg, src_global_rank)
        inv = _token_normalization_scale(n_global)

        if mimo_model.language_model is not None:
            finalize_model_grads(
                [mimo_model.language_model],
                num_tokens=None,
                pg_collection=language_pg,
                force_all_reduce=force_all_reduce,
            )
            mimo_model.language_model.scale_gradients(inv)

        for name, submodule in mimo_model.modality_submodules.items():
            if submodule is None or not any(
                parameter.requires_grad for parameter in submodule.parameters()
            ):
                continue
            vision_pg = module_pgs.get(name)
            finalize_model_grads(
                [submodule],
                num_tokens=None,
                pg_collection=vision_pg,
                force_all_reduce=force_all_reduce,
            )

            vision_scale = inv
            if correct_vision_grad and vision_pg is not None and vision_pg.dp is not None:
                vision_dp_group = vision_pg.dp
                if _is_pg_member(vision_dp_group):
                    vision_dp_size = dist.get_world_size(vision_dp_group)
                    if vision_dp_size > 1:
                        participation = _vision_participation_count(submodule, vision_dp_group)
                        participation_scale = torch.where(
                            (participation > 0) & (participation < vision_dp_size),
                            vision_dp_size * participation.reciprocal(),
                            torch.ones_like(participation),
                        )
                        vision_scale = vision_scale * participation_scale

            submodule.scale_gradients(vision_scale)

    mimo_model.config.finalize_model_grads_func = finalize_grads_func
    # The schedule always calls grad_scale_func with a Tensor loss; the per-token
    # mean is applied in finalize_grads_func, so no extra scaling is needed here.
    mimo_model.config.grad_scale_func = lambda loss: loss

    if getattr(args, "overlap_grad_reduce", False):
        cfg = get_run_config()
        assert mimo_model.config.no_sync_func is None, (
            "MIMO overlap owns config.no_sync_func; a second synchronization context "
            "cannot be composed safely"
        )
        mimo_model.config.no_sync_func = mimo_model.no_sync
        if cfg.dist.align_grad_reduce:
            mimo_model.config.grad_sync_func = mimo_model.start_grad_sync
