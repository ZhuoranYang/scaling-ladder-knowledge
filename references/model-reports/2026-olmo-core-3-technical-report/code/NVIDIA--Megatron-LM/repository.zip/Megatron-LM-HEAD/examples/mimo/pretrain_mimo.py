# Copyright (c) 2026, NVIDIA CORPORATION. All rights reserved.

"""Heterogeneous Nemotron6-MoE VLM training through the stock pretrain loop."""

from __future__ import annotations

from megatron.rank_log_setup import suppress_duplicate_logs_off_rank0

# Quiet the duplicate warnings before the heavy imports below: torch raises its
# own deprecations while it is being imported, so a filter installed any later
# cannot reach them.
suppress_duplicate_logs_off_rank0()

import argparse
from functools import partial

from examples.mimo.model_providers import resolve_provider
from examples.mimo.model_providers.nemotron_moe_vlm import add_model_provider_args
from examples.mimo.training.args import (
    add_hetero_grid_args,
    build_module_grid_specs,
    validate_hetero_grid_args,
)
from examples.mimo.training.builder import MimoBuildConfig
from examples.mimo.training.data import add_mock_data_args, build_train_valid_test_data_loaders
from examples.mimo.training.distributed import initialize_distributed, shutdown_distributed
from examples.mimo.training.encoder_prefetch import (
    EncoderPrefetchLoader,
    add_encoder_prefetch_args,
    prefetch_frozen_features,
    validate_encoder_prefetch_args,
)
from examples.mimo.training.step import mimo_forward_step
from examples.mimo.training.topology import create_topology
from megatron.core.enums import ModelType
from megatron.core.utils import unwrap_model
from megatron.training.argument_utils import pretrain_cfg_container_from_args
from megatron.training.arguments import parse_args, validate_args
from megatron.training.global_vars import set_args, set_run_config
from megatron.training.training import pretrain
from megatron.training.vocab_utils import calculate_padded_vocab_size


def extra_args_provider(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """Register model-provider, heterogeneous-grid, and mock-data arguments."""
    parser = add_model_provider_args(parser)
    parser = add_hetero_grid_args(parser)
    parser = add_mock_data_args(parser)
    parser = add_encoder_prefetch_args(parser)
    return parser


def _set_stock_parallel_args(args: argparse.Namespace) -> None:
    # validate_args and the stock training loop consume these fields.
    args.tensor_model_parallel_size = args.mimo_llm_tp
    args.pipeline_model_parallel_size = args.mimo_llm_pp
    args.context_parallel_size = args.mimo_llm_cp
    args.expert_model_parallel_size = args.mimo_llm_ep
    args.expert_tensor_parallel_size = args.mimo_llm_expt_tp or 1


def _parse_and_validate() -> argparse.Namespace:
    """Parse stock plus MIMO arguments and validate the disjoint module grids."""
    args = parse_args(extra_args_provider)
    _, llm_size = validate_hetero_grid_args(args, args.world_size)
    _set_stock_parallel_args(args)
    physical_world_size = args.world_size
    args.world_size = llm_size
    try:
        validate_args(args, {"dataloader_type": "external"})
    finally:
        args.world_size = physical_world_size
    if not (
        args.use_distributed_optimizer
        or getattr(args, "use_layer_wise_distributed_optimizer", False)
        or args.optimizer == "dist_muon"
    ):
        raise ValueError("Other optimizer paths have not been tested with heterogeneous MIMO")
    validate_encoder_prefetch_args(args)

    if getattr(args, "padded_vocab_size", None) is None:
        args.padded_vocab_size = calculate_padded_vocab_size(
            args.vocab_size,
            args.make_vocab_size_divisible_by,
            args.mimo_llm_tp,
            logging_enabled=False,
        )
    return args


def main() -> None:
    """Build the heterogeneous topology and run stock pretraining."""
    args = _parse_and_validate()
    set_args(args)
    model_cfg = MimoBuildConfig()
    cfg = pretrain_cfg_container_from_args(args, model_cfg)
    set_run_config(cfg)
    provider = resolve_provider(args)

    prefetch_loader = None
    initialize_distributed()
    # The grid/rank-layout args model a single encoder region; the builder itself is
    # generic over any number of encoder grids in the topology.
    encoder_name = provider.encoder_module_names[0] if provider.encoder_module_names else None
    specs = build_module_grid_specs(args, args.world_size, encoder_name)
    topology = create_topology(specs, cfg.dist.high_priority_stream_groups)

    communicator = provider.build_communicator(args, topology)

    if args.mimo_encoder_prefetch and len(provider.encoder_module_names) != 1:
        raise ValueError("encoder prefetch requires exactly one encoder")

    # Encoder prefetch runs encoder forward while producing batches, so it needs the built
    # rank-local encoder instance. Capture the wrapped model here so the data provider can
    # later extract that encoder and bind it to the prefetch worker.
    captured_model = {}
    hooks = []
    if args.mimo_encoder_prefetch:

        def capture_model(models):
            captured_model["model"] = models[0]
            return models

        hooks.append(capture_model)
    model_cfg._topology = topology
    model_cfg.post_wrap_hooks = hooks

    def train_valid_test_data_provider(_train_val_test_num_samples):
        nonlocal prefetch_loader
        loaders = build_train_valid_test_data_loaders(args, topology)
        iterators = tuple(iter(loader) if loader is not None else None for loader in loaders)
        if not args.mimo_encoder_prefetch or loaders[0] is None:
            return iterators

        mimo_model = unwrap_model(captured_model["model"])
        if not mimo_model.role.has_modality_modules:
            return iterators
        if prefetch_loader is not None:
            raise RuntimeError("encoder prefetch loader was already built")

        encoder_module = unwrap_model(mimo_model.modality_submodules[encoder_name])
        prefetch_loader = EncoderPrefetchLoader(
            source=iter(loaders[0]),
            encoder_name=encoder_name,
            feature_producer=partial(prefetch_frozen_features, encoder_module),
            depth=args.mimo_encoder_prefetch_depth,
            debug=args.mimo_encoder_prefetch_debug,
        )
        prefetch_loader.start()
        return (prefetch_loader, *iterators[1:])

    train_valid_test_data_provider.is_distributed = True
    pretrain(
        cfg,
        train_valid_test_data_provider,
        ModelType.encoder_or_decoder,
        mimo_forward_step,
        model_provider=None,
        skip_model_parallel_init=True,
        p2p_communicator=communicator,
        pg_collection=topology.schedule_pg_collection,
        build_tokenizer=False,
    )

    if prefetch_loader is not None:
        prefetch_loader.close()
    topology.destroy()
    shutdown_distributed()


if __name__ == "__main__":
    main()
