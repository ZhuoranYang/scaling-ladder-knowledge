<div align="center">

# Model Optimizer Integrated Examples


[Model Optimizer](https://github.com/NVIDIA/Model-Optimizer) |
[Local Examples](#getting-started-in-a-local-environment) |
[Configuration](./ADVANCED.md#advanced-configuration) |
[Slurm Examples](./ADVANCED.md#slurm-examples) |
[Speculative Decoding](./speculative.md) |
[Knowledge Distillation](./distillation.md) |
[Advanced Topics](./ADVANCED.md)

</div>

[Model Optimizer](https://github.com/NVIDIA/Model-Optimizer) (**ModelOpt**, `nvidia-modelopt`)
provides end-to-end model optimization for NVIDIA hardware including quantization (real or simulated),
knowledge distillation, pruning, speculative decoding, and more.


## Major Features

- Optimize Megatron-Core distributed checkpoints.
- Support all kinds of model parallelism (TP, EP, ETP, PP).
- Export to TensorRT-LLM, vLLM, and SGLang ready unified checkpoint.

## Support Matrix {Model}x{Features}

| Model (`conf/`) | Quantization | EAGLE3 | Pruning (PP only) | Distillation |
| :---: | :---: | :---: | :---: | :---: |
| `deepseek-ai/DeepSeek-R1` | ✅ | ✅ | - | - |
| `meta-llama/Llama-{3.1-8B, 3.1-405B, 3.2-1B}-Instruct` | ✅ | ✅ | ✅ | ✅ |
| `meta-llama/Llama-4-{Scout,Maverick}-17B-{16,128}E-Instruct` | ✅ | ✅ | - | - |
| `moonshotai/Kimi-K2-Instruct` | ✅ | ✅ | - | - |
| `nvidia/NVIDIA-Nemotron-Nano-9B-v2` | ✅ | - | ✅ | ✅ |
| `nvidia/NVIDIA-Nemotron-3.5-Lightning-30B-A3B` | ✅ | - | ✅ | ✅ |
| `nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B-BF16` | ✅ | - | ✅ | ✅ |
| `nvidia/NVIDIA-Nemotron-3-Super-120B-A12B-BF16` | ✅ | - | ✅ | ✅ |
| `nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B-BF16` | ✅ | - | ✅ | ✅ |
| `openai/gpt-oss-{20b, 120b}` | ✅ | **Online** | ✅ | ✅ |
| `Qwen/Qwen3-{0.6B, 8B}` | ✅ | ✅ | ✅ | ✅ |
| `Qwen/Qwen3-{30B-A3B, 235B-A22B}` | **WAR** | ✅ | ✅ | ✅ |


## Setup

Run these examples in an NVIDIA GPU container. The [NVIDIA NGC NeMo container
catalog](https://catalog.ngc.nvidia.com/orgs/nvidia/-/containers/nemo/-/tags)
lists the current release; the commands below use `nvcr.io/nvidia/nemo:26.08`.
The container includes Megatron-Bridge and a compatible Model Optimizer
installation.

To run the examples from a Megatron-LM checkout, mount that checkout and a
workspace for Hugging Face models, checkpoints, datasets, and outputs. The
workspace remains on the host after the container exits. Set `HF_TOKEN` before
starting the container when accessing gated Hugging Face models.

```sh
MEGATRON_LM_PATH=/path/to/Megatron-LM
WORKSPACE_PATH=/path/to/modelopt-workspace

docker run --rm -it --gpus all --shm-size=24g \
    -e HF_TOKEN \
    -v "${MEGATRON_LM_PATH}:/workspace/Megatron-LM" \
    -v "${WORKSPACE_PATH}:/workspace/modelopt-workspace" \
    -w /workspace/Megatron-LM/examples/post_training/modelopt \
    nvcr.io/nvidia/nemo:26.08 \
    bash
```

Inside the container, run an example normally and set `MLM_SKIP_INSTALL=1` to
use the Model Optimizer installation provided by the container. To try the
latest Model Optimizer features from [source](https://github.com/NVIDIA/Model-Optimizer),
add the following mount to the `docker run` command above:

```sh
MODEL_OPTIMIZER_PATH=/path/to/Model-Optimizer
# Add: -v "${MODEL_OPTIMIZER_PATH}:/workspace/Model-Optimizer"
```

Then install the mounted checkout inside the container. Keep
`MLM_SKIP_INSTALL=1` when running the examples so their requirements file does
not replace the editable installation:

```sh
pip install -e /workspace/Model-Optimizer
```

### Megatron-Core Checkpoint Prerequisite

All examples require a Megatron-Core distributed checkpoint. To import a
Hugging Face model, run the [Megatron-Bridge stable checkpoint conversion
CLI](https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/main/examples/conversion#2-stable-checkpoint-conversion-cli)
inside the NeMo container started above.

Use `--device cpu` when the conversion fits in host memory; otherwise use
`--device gpu` with the intended `--tp`, `--pp`, and `--ep` layout. See the
Megatron-Bridge conversion documentation for distributed imports and supported
architectures. To quantize directly from Hugging Face, use the
[Megatron-Bridge quantization examples](https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/main/examples/quantization).

### Megatron Model Configs

**❗ IMPORTANT:** The first positional argument (e.g. `meta-llama/Llama-3.2-1B-Instruct`) of each script is the config name used to match the supported model config in `conf/`. Make sure the model you are running is supported by a config in `conf/`.

## ⭐ Post-Training Quantization

Post-training quantization (PTQ) converts a Megatron-Core checkpoint to a
simulated or real low-precision checkpoint without training. Provide the
imported checkpoint through `${MLM_MODEL_CKPT}` and set `${MLM_MODEL_SAVE}` to
the resumable Megatron-LM distributed checkpoint to create.

> **📙 NOTE:** ModelOpt supports different quantization formats which are listed in the [ModelOpt quant configs](https://github.com/NVIDIA/Model-Optimizer/blob/7971fff05882da7eae16eae6bc927d1481dcd63f/modelopt/torch/quantization/config.py#L626).
> The quant config is specified by the full config name in all-caps, e.g. NVFP4_DEFAULT_CFG.
> By default, we simulate the low-precision numerical behavior (fake-quant) which can be run on GPUs with compute > 80.
> Real low-precision paramters (e.g. `E4M3` or `E2M1`)
> and low-precision compute (e.g. `FP8Linear`) are also supported depending on GPU compute capability.
> **See [Advanced Topics](./ADVANCED.md) for details**.

```sh
\
    TP=1 \
    MLM_MODEL_CKPT=<megatron_core_checkpoint> \
    MLM_MODEL_SAVE=/tmp/Llama-3.2-1B-Instruct_quant \
    ./quantize.sh meta-llama/Llama-3.2-1B-Instruct NVFP4_DEFAULT_CFG 
```

For KV cache quantization, add a flag like `MLM_EXTRA_ARGS="--export-kv-cache-quant fp8"` while specifying your desired KV cache precision (see `KV_QUANT_CFG_CHOICES` in `quantize.py`).

For QAT exports, set `MLM_EXTRA_ARGS=--no-clamp-kv-scales` to disable KV-cache scale clamping and preserve the learned scales.

### ⭐ Auto Quantize (Mixed-Precision Search)

Auto Quantize uses `mtq.auto_quantize` to perform a per-layer mixed-precision search, assigning each
layer the best quantization format (e.g. NVFP4 or FP8) subject to a target effective-bits constraint.
This produces a model that is more accurate than uniform quantization at the same average bit-width.

Pass `auto` as the second positional argument to `quantize.sh` and provide `--auto-quantize-bits`
through `MLM_EXTRA_ARGS`. The script will skip `--export-quant-cfg` entirely and drive the search
via the auto-quantize arguments.

> **Note:** Auto Quantize requires `--pipeline-model-parallel-size 1` (PP=1) and
> [Model-Optimizer](https://github.com/NVIDIA/Model-Optimizer) **0.46 or greater**
> (`pip install nvidia-modelopt>=0.46`). Alternatively, install from the
> [main branch](https://github.com/NVIDIA/Model-Optimizer) for the latest features.

```sh
\
    TP=1 \
    MLM_MODEL_CKPT=<megatron_core_checkpoint> \
    MLM_MODEL_SAVE=/tmp/Llama-3.2-1B-Instruct_auto_quant \
    MLM_EXTRA_ARGS="--auto-quantize-bits 4.0" \
    ./quantize.sh meta-llama/Llama-3.2-1B-Instruct auto
```

Key arguments (passed via `MLM_EXTRA_ARGS`):

| Argument | Default | Description |
| --- | --- | --- |
| `--auto-quantize-bits` | *(required)* | Target effective bits per weight (e.g. `4.0`, `4.8`). |
| `--auto-quantize-formats` | `NVFP4_DEFAULT_CFG FP8_DEFAULT_CFG` | Space-separated list of quant configs to search over. |
| `--auto-quantize-method` | `gradient` | Sensitivity scoring method (`gradient` or `kl_div`). |
| `--auto-quantize-score-size` | `128` | Number of samples used for sensitivity scoring. |
| `--auto-quantize-checkpoint` | `None` | Optional path to save/restore search state across runs. |

Export the PTQ checkpoint with [`export.sh`](#-megatron-checkpoint-export)
before running inference with it.

## ⭐ Quantization Aware Training & Distillation

Quantization-aware training (QAT) fine-tunes the PTQ checkpoint with the
supervised cross-entropy loss to adapt it to a target task.

```sh
\
    TP=1 \
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Instruct_quant \
    MLM_MODEL_SAVE=/tmp/Llama-3.2-1B-Instruct-qat \
    ./finetune.sh meta-llama/Llama-3.2-1B-Instruct
```

Quantization-aware distillation (QAD) instead distills the quantized student from a frozen BF16
teacher to recover quantization accuracy. Both workflows use `finetune.sh`
with the PTQ checkpoint in `${MLM_MODEL_CKPT}`.  For QAD, add the BF16 teacher checkpoint through `--export-kd-teacher-load`. The teacher checkpoint must include `model_config.yaml`, or provide its path
with `--export-kd-teacher-model-config`:

```sh
\
    TP=1 \
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Instruct_quant \
    MLM_MODEL_SAVE=/tmp/Llama-3.2-1B-Instruct-qad \
    MLM_EXTRA_ARGS="--export-kd-teacher-load /path/to/Llama-3.2-1B-Instruct-bf16 \
        --export-kd-teacher-model-config /path/to/Llama-3.2-1B-Instruct-bf16/model_config.yaml" \
    ./finetune.sh meta-llama/Llama-3.2-1B-Instruct
```

See the [distillation documentation](./distillation.md) for teacher checkpoint
requirements and optional distillation-loss configuration.

For both QAT and QAD, configure the training data, hyper parameters, and the PTQ student and/or BF16 teacher according to your desired training recipe.

For scale-learning QAD (LSQ), where the PTQ checkpoint was quantized with learnable scales, add `--lsq-scale-lr` to `MLM_EXTRA_ARGS` to train the scale (`_amax_pre`/`_amax_post`) parameters with their own learning rate; otherwise they use `--lr`. Setting `--lr 0` with a nonzero `--lsq-scale-lr` trains only the scales.

Export the QAT or QAD checkpoint with [`export.sh`](#-megatron-checkpoint-export)
before running inference with it.

## ⭐ Megatron Checkpoint Export

Export converts a Megatron-LM distributed checkpoint to the unified Hugging
Face format used for inference with vLLM, TensorRT-LLM, and SGLang. Provide the
checkpoint through `${MLM_MODEL_CKPT}` and set `${EXPORT_DIR}` to the export
destination.

```sh
\
    PP=1 \
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Instruct_quant \
    EXPORT_DIR=/tmp/Llama-3.2-1B-Instruct_export \
    ./export.sh meta-llama/Llama-3.2-1B-Instruct
```

To export for the vLLM fake-quant example in
`modelopt/examples/vllm_serve/vllm_serve_fakequant.py`, add
`--export-vllm-fq`:

```sh
\
    PP=1 \
    MLM_EXTRA_ARGS=--export-vllm-fq \
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Instruct_quant \
    EXPORT_DIR=/tmp/Llama-3.2-1B-Instruct_export \
    ./export.sh meta-llama/Llama-3.2-1B-Instruct
```

For KV cache quantization, add
`MLM_EXTRA_ARGS="--export-kv-cache-quant fp8"` and specify the desired KV
cache precision (see `KV_QUANT_CFG_CHOICES` in `quantize.py`).

## ⭐ Online BF16 EAGLE3 Training

Online EAGLE3 training has both the target (frozen) and draft models in the memory where the `hidden_states`
required for training is generated on the fly. Periodically, acceptance length (AL, the higher the better) is
evaluated on MT-Bench prompts. Use the same `export.sh` script to export the EAGLE3 checkpoint for
deployment.

```sh
\
    TP=1 \
    HF_MODEL_CKPT=<pretrained_model_name_or_path> \
    MLM_MODEL_SAVE=/tmp/Llama-3.2-1B-Eagle3 \
    ./eagle3.sh meta-llama/Llama-3.2-1B-Instruct

\
    PP=1 \
    HF_MODEL_CKPT=<pretrained_model_name_or_path> \
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Eagle3 \
    EXPORT_DIR=/tmp/Llama-3.2-1B-Eagle3-Export \
    ./export.sh meta-llama/Llama-3.2-1B-Instruct
```

See [Advanced Topics](./ADVANCED.md) for a `moonshotai/Kimi-K2-Instruct` EAGLE3 training example using `slurm`.

## ⭐ Offline BF16 EAGLE3 Training
Unlike online EAGLE3 training, offline workflow precomputes target model `hidden_states` and dumps to disk.
Then only the draft model is called during training. AL is no longer reported during training. After training,
`export.sh` is used to export EAGLE3 checkpoint.

```sh
\
    # Convert to online eagle3 model for base model feature extraction
    HF_MODEL_CKPT=<pretrained_model_name_or_path> \
    MLM_MODEL_SAVE=/tmp/Llama-3.2-1B-Eagle3 \
    MLM_EXTRA_ARGS="--algorithm eagle3" \
    ./convert.sh meta-llama/Llama-3.2-1B-Instruct

\
    # Dump base model feature to disk
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Eagle3 \
    MLM_EXTRA_ARGS="--output-dir /tmp/offline_data" \
    ./offline_feature_extrach.sh meta-llama/Llama-3.2-1B-Instruct

\
    # Convert to offline eagle3 model
    HF_MODEL_CKPT=<pretrained_model_name_or_path> \
    MLM_MODEL_SAVE=/tmp/Llama-3.2-1B-Eagle3-offline \
    MLM_EXTRA_ARGS="--algorithm eagle3 --export-offline-model" \
    ./convert.sh meta-llama/Llama-3.2-1B-Instruct

\
    # Train the offline eagle3 model using extracted features
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Eagle3-offline \
    MLM_MODEL_SAVE=/tmp/Llama-3.2-1B-Eagle3-offline \
    MLM_EXTRA_ARGS="--export-offline-model --offline-distillation-data /tmp/offline_data" \
    ./finetune.sh meta-llama/Llama-3.2-1B-Instruct

\
    # Export the trained eagle3 checkpoint
    PP=1 \
    HF_MODEL_CKPT=<pretrained_model_name_or_path> \
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Eagle3-offline \
    EXPORT_DIR=/tmp/Llama-3.2-1B-Eagle3-Export \
    MLM_EXTRA_ARGS="--export-offline-model" \
    ./export.sh meta-llama/Llama-3.2-1B-Instruct
```

## ⭐ Pruning

Pruning is supported for GPT and Mamba models in Pipeline Parallel mode. The `prune.sh` script
prunes a model by passing `--prune-export-config '<json_without_spaces>'` to `prune.py` via `MLM_EXTRA_ARGS`.
The JSON describes the target pruned architecture; calibration data is used to compute importance
scores that drive the dimension reduction.

Supported hyperparameters (any subset can appear as keys in `--prune-export-config`):
`hidden_size`, `ffn_hidden_size`, `num_attention_heads`, `num_query_groups`, `mamba_num_heads`,
`mamba_head_dim`, `num_moe_experts`, `moe_ffn_hidden_size`, `moe_shared_expert_intermediate_size`,
`num_layers`.

Example for depth pruning Qwen3-8B from 36 to 24 layers:

```sh
PP=1 \
MLM_EXTRA_ARGS='--prune-export-config {"num_layers":24}' \
HF_MODEL_CKPT=<pretrained_model_name_or_path> \
MLM_MODEL_SAVE=Qwen3-8B-Pruned \
./prune.sh Qwen/Qwen3-8B
```

The default calibration dataset is `nemotron-post-training-dataset-v2` (gated, requires
`hf auth login`). Override it by adding `--calib-dataset <hf_dataset_name_or_local_jsonl>`
to `MLM_EXTRA_ARGS` (e.g. `cnn_dailymail` for an ungated alternative).

> [!TIP]
> If number of layers in the model is not divisible by pipeline parallel size (PP), you can configure uneven
> PP by adding `--decoder-first-pipeline-num-layers <X> --decoder-last-pipeline-num-layers <Y>` to `MLM_EXTRA_ARGS`.

> [!TIP]
> You can reuse intermediate pruning scores when pruning the same model again to a different config
> by adding `--prune-intermediate-ckpt <path_to_cache_dir>` to `MLM_EXTRA_ARGS`.

> [!NOTE]
> When loading pruned M-LM checkpoint for subsequent steps, make sure overwrite the pruned parameters in the
> default `conf/` by setting `MLM_EXTRA_ARGS`. E.g.: for loading above pruned Qwen3-8B checkpoint for mmlu, set:
> `MLM_EXTRA_ARGS="--num-layers 24"`

For NAS-based automatic pruning (search across many candidate architectures and pick the best via
MMLU scoring), see the [Megatron-Bridge pruning example](https://github.com/NVIDIA/Model-Optimizer/tree/main/examples/megatron_bridge#pruning).
Checkout pruning getting started and general guidelines in the [ModelOpt pruning README](https://github.com/NVIDIA/Model-Optimizer/tree/main/examples/pruning).

## ⭐ Inference and Training

The saved Megatron-LM distributed checkpoint (output of above scripts) can be resumed for inference
(generate or evaluate) or training (SFT or PEFT). To read more about these features, see
[Advanced Topics](./ADVANCED.md).

```sh
\
    TP=1 \
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Instruct_quant \
    ./generate.sh meta-llama/Llama-3.2-1B-Instruct

\
    TP=1 \
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Instruct_quant \
    ./mmlu.sh meta-llama/Llama-3.2-1B-Instruct

\
    TP=1 \
    MLM_MODEL_CKPT=/tmp/Llama-3.2-1B-Instruct_quant \
    ./finetune.sh meta-llama/Llama-3.2-1B-Instruct
```

## Advanced Usage
To contribute, please ping [@NVIDIA/post-training](https://github.com/orgs/NVIDIA/teams/post-training) team members. We format the examples with
```
uvx black@24.10.0 .
uvx isort .
```
