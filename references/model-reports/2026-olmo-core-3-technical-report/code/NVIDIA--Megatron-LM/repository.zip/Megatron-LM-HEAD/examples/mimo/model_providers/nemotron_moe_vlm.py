# Copyright (c) 2026, NVIDIA CORPORATION. All rights reserved.

"""Nemotron6-MoE VLM model provider for hetero MIMO examples."""

from __future__ import annotations

import argparse
from copy import deepcopy
from functools import partial
from typing import TYPE_CHECKING, Optional

import torch

from examples.mimo.model_providers import MimoProvider
from examples.mimo.model_providers.radio_encoder import (
    RADIO_ENCODER_MODULE_NAME,
    _base_config,
    _disable_gtp,
    _make_dense_non_hybrid,
    add_radio_encoder_args,
    radio_vision_config,
    radio_vision_encoder_spec,
)
from examples.mimo.utils.hetero import get_grid_dim_size
from megatron.core.activations import squared_relu
from megatron.core.hyper_comm_grid import HyperCommGrid
from megatron.core.model_parallel_config import resolve_tensor_parallel_weight_shards
from megatron.core.models.hybrid.hybrid_layer_specs import (
    mamba_stack_spec,
    wide_residual_hybrid_stack_spec,
)
from megatron.core.models.mamba.mamba_model import MambaModel
from megatron.core.models.mimo.config.role import MIMO_LANGUAGE_MODULE_KEY
from megatron.core.models.mimo.submodules.vision import VisionModalitySubmodules
from megatron.core.models.vision.multimodal_projector import MultimodalProjector
from megatron.core.pipeline_parallel.multimodule_communicator import MultiModulePipelineCommunicator
from megatron.core.process_groups_config import ProcessGroupCollection
from megatron.core.tensor_parallel import ColumnParallelLinear
from megatron.core.transformer.enums import AttnBackend
from megatron.core.transformer.mlp import MLP, MLPSubmodules
from megatron.core.transformer.spec_utils import ModuleSpec
from megatron.core.transformer.transformer_config import TransformerConfig
from megatron.core.utils import get_pg_rank, get_pg_size

try:
    from megatron.core.extensions.transformer_engine import TERowParallelLinear
except ImportError:  # pragma: no cover - TE always present in the CI container
    TERowParallelLinear = None

if TYPE_CHECKING:
    from examples.mimo.training.topology import HeteroTopology

NEMOTRON_MODEL_PROVIDER = "nemotron-moe-vlm"


def add_model_provider_args(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """Register the model-provider args for hetero MIMO examples.

    Only the provider/vision knobs this PR consumes are declared here; stock
    ``arguments.py`` owns the ``TransformerConfig`` field flags and
    ``radio_encoder`` owns the RADIO-encoder knobs.
    """
    add_radio_encoder_args(parser)
    provider = parser.add_argument_group("mimo model provider")
    provider.add_argument(
        "--model-provider",
        choices=[NEMOTRON_MODEL_PROVIDER],
        default=NEMOTRON_MODEL_PROVIDER,
        help="Which MIMO model provider/preset to build.",
    )
    provider.add_argument("--freeze-lm", action="store_true")
    provider.add_argument("--freeze-vit", action="store_true")
    provider.add_argument("--freeze-projection", action="store_true")
    provider.add_argument(
        "--mimo-vision-encoder-attention-backend",
        type=lambda value: AttnBackend[value],
        choices=list(AttnBackend),
        default=None,
        help=(
            "Vision encoder attention backend. Defaults to --attention-backend. Transformer "
            "Engine backend selection is process-wide, so colocated encoder and language "
            "modules must use compatible settings."
        ),
    )
    provider.add_argument(
        "--mimo-vision-encoder-flash-attention-version",
        type=int,
        choices=(2, 3, 4),
        default=None,
        help=(
            "FlashAttention version requested by the vision encoder. Defaults to "
            "--flash-attention-version. Transformer Engine version selection is process-wide, "
            "so colocated encoder and language modules must use compatible settings."
        ),
    )
    provider.add_argument(
        "--vision-projection-type",
        type=str,
        choices=["mlp", "affine"],
        default="affine",
        help="Projection module from frozen vision features to language hidden size.",
    )
    return parser


def _vocab_size(args: argparse.Namespace) -> int:
    """Resolve the vocabulary size from stock args (``padded_vocab_size`` / ``vocab_size``)."""
    for attr in ("padded_vocab_size", "vocab_size"):
        value = getattr(args, attr, None)
        if value:
            return int(value)
    raise ValueError("vocab size unresolved: set --vocab-size / a tokenizer, or padded_vocab_size")


def nemotron_projection_layer_spec() -> ModuleSpec:
    """Return the Nemotron VLM RADIO-to-language projector layer spec."""
    if TERowParallelLinear is None:
        raise RuntimeError("TERowParallelLinear is required")
    # MultimodalProjector's affine path builds fc1 with gather_output=True, which
    # TE column-parallel linears reject; use core ColumnParallelLinear for fc1.
    return ModuleSpec(
        module=MLP,
        submodules=MLPSubmodules(linear_fc1=ColumnParallelLinear, linear_fc2=TERowParallelLinear),
    )


def nemotron_language_config(
    args: argparse.Namespace,
    tp_size: int,
    pp_size: int,
    ep_size: int,
    expt_tp_size: int,
    cp_size: int = 1,
) -> TransformerConfig:
    """Nemotron6-MoE language config: stock from-args base + model-specific overrides."""
    config = deepcopy(_base_config(args))
    gtp_remat_num_sequence_shards = config.gtp_remat_num_sequence_shards
    # Code-only fields + hetero parallelism pins.
    config.variable_seq_lengths = True
    config.expert_model_parallel_size = ep_size
    config.expert_tensor_parallel_size = expt_tp_size
    config.tensor_model_parallel_size = tp_size
    config.pipeline_model_parallel_size = pp_size
    config.context_parallel_size = cp_size
    config.tensor_parallel_num_weight_shards, config.gtp_weight_remat_size = (
        resolve_tensor_parallel_weight_shards(
            tp_size,
            getattr(args, "tensor_parallel_num_weight_shards", None),
            getattr(args, "gtp_weight_remat_size", 1),
        )
    )
    config.expert_tensor_parallel_num_weight_shards, config.expert_gtp_weight_remat_size = (
        resolve_tensor_parallel_weight_shards(
            expt_tp_size,
            getattr(args, "expert_tensor_parallel_num_weight_shards", None),
            getattr(args, "expert_gtp_weight_remat_size", 1),
            shards_field="expert_tensor_parallel_num_weight_shards",
            tp_field="expert_tensor_parallel_size",
        )
    )
    config.sequence_parallel = tp_size > 1
    config.tensor_parallel_num_sequence_shards = tp_size * gtp_remat_num_sequence_shards
    config.position_embedding_type = args.position_embedding_type
    return config


def require_per_token_loss(config: TransformerConfig) -> None:
    """The hetero MIMO loop scales both language and vision grads by real LM tokens."""
    if not config.calculate_per_token_loss:
        raise ValueError("hetero MIMO training requires calculate_per_token_loss=True")


def _vision_projection_input_size(
    args: argparse.Namespace, vision_config: TransformerConfig
) -> int:
    """Return the encoder output width consumed by the projector."""
    input_size = int(vision_config.hidden_size)
    if getattr(args, "pixel_shuffle", False):
        input_size *= 4
    return input_size


def nemotron_projection_config(
    args: argparse.Namespace,
    tp_size: int,
    projection_input_size: int,
    base_config: TransformerConfig | None = None,
) -> TransformerConfig:
    """Vision-to-Nemotron projection config: stock from-args base + overrides."""
    config = deepcopy(base_config if base_config is not None else _base_config(args))
    config.num_layers = 1
    config.hidden_size = int(args.hidden_size)
    config.num_attention_heads = 1
    config.ffn_hidden_size = 4 * projection_input_size
    config.gated_linear_unit = False
    config.bias_activation_fusion = False
    config.bias_dropout_fusion = False
    config.add_bias_linear = False
    config.activation_func = squared_relu
    config.normalization = "RMSNorm"
    _make_dense_non_hybrid(config)  # Projection inherits no MoE/Mamba/hybrid settings.
    config.tensor_model_parallel_size = tp_size
    config.context_parallel_size = 1
    if base_config is None:
        _disable_gtp(config)
    config.sequence_parallel = False
    config.tensor_parallel_num_sequence_shards = None
    return config


def _nemotron_projection_spec(
    args: argparse.Namespace,
    input_size: int,
    tp_size: int,
    pg_collection: ProcessGroupCollection | None,
    base_config: TransformerConfig | None = None,
) -> ModuleSpec:
    """Build the RADIO-to-language projection for its owning grid."""
    return ModuleSpec(
        module=MultimodalProjector,
        params={
            "config": nemotron_projection_config(args, tp_size, input_size, base_config),
            "submodules": nemotron_projection_layer_spec().submodules,
            "projector_type": args.vision_projection_type,
            "input_size": input_size,
            "pg_collection": pg_collection,
        },
    )


def language_model_spec(
    args: argparse.Namespace,
    pg_collection: Optional[ProcessGroupCollection],
    llm_grid: HyperCommGrid,
) -> ModuleSpec:
    """Create the language ``ModuleSpec`` for the local language grid.

    ``pg_collection`` is the per-module ProcessGroupCollection built by
    ``examples/mimo/training/topology.py`` (``None`` on ranks not in the language
    grid). ``llm_grid`` is the language ``HyperCommGrid`` used only for fallback
    dim sizes when a group is missing.
    """
    # None on ranks outside the language grid -> sizes come from the grid; when a
    # collection is provided its pp/tp/cp/ep/expt_tp groups must all be present.
    if pg_collection is None:
        pp_rank = 0
        pp_size = get_grid_dim_size(llm_grid, "pp")
        tp_size = get_grid_dim_size(llm_grid, "tp")
        cp_size = get_grid_dim_size(llm_grid, "cp") * get_grid_dim_size(
            llm_grid, "gtp_remat_sequence_shards"
        )
        ep_size = getattr(args, "mimo_llm_ep", 1)
        expt_tp_size = getattr(args, "mimo_llm_expt_tp", None) or 1
    else:
        assert all(
            getattr(pg_collection, name, None) is not None
            for name in ("pp", "tp", "cp", "ep", "expt_tp")
        ), "language pg_collection is missing a required pp/tp/cp/ep/expt_tp group"
        pp_rank = get_pg_rank(pg_collection.pp)
        pp_size = get_pg_size(pg_collection.pp)
        tp_size = get_pg_size(pg_collection.tp)
        cp_size = get_pg_size(pg_collection.cp)
        ep_size = get_pg_size(pg_collection.ep)
        expt_tp_size = get_pg_size(pg_collection.expt_tp)

    config = nemotron_language_config(
        args, tp_size, pp_size, ep_size, expt_tp_size, cp_size=cp_size
    )
    require_per_token_loss(config)
    stack_spec = (
        wide_residual_hybrid_stack_spec
        if getattr(config, "wide_residual", None) is not None
        else mamba_stack_spec
    )
    return ModuleSpec(
        module=MambaModel,
        params={
            "config": config,
            "mamba_stack_spec": stack_spec,
            "vocab_size": _vocab_size(args),
            "max_sequence_length": args.seq_length,
            "pre_process": pp_rank == 0,
            "post_process": pp_rank == pp_size - 1,
            "hybrid_layer_pattern": args.hybrid_layer_pattern,
            "position_embedding_type": args.position_embedding_type,
            "rotary_base": args.rotary_base,
            "rotary_percent": args.rotary_percent,
            "seq_len_interpolation_factor": args.rotary_seq_len_interpolation_factor,
            "share_embeddings_and_output_weights": False,
            "scatter_embedding_sequence_parallel": False,
            "logit_dtype": args.logit_dtype,
            "pg_collection": pg_collection,
        },
    )


def vision_submodules_spec(
    args: argparse.Namespace,
    pg_collection: Optional[ProcessGroupCollection],
    encoder_grid: HyperCommGrid,
) -> ModuleSpec:
    """Create the vision ``ModuleSpec`` for the local encoder grid."""
    pp_pg = getattr(pg_collection, "pp", None) if pg_collection is not None else None
    tp_pg = getattr(pg_collection, "tp", None) if pg_collection is not None else None
    # None on ranks outside the encoder grid -> sizes from the grid; a provided
    # collection must carry pp/tp.
    if pg_collection is None:
        tp_size = get_grid_dim_size(encoder_grid, "tp")
        pp_size = get_grid_dim_size(encoder_grid, "pp")
    else:
        assert (
            pp_pg is not None and tp_pg is not None
        ), "encoder pg_collection is missing the required pp/tp group"
        tp_size = get_pg_size(tp_pg)
        pp_size = get_pg_size(pp_pg)

    vision_config = radio_vision_config(args, tp_size, pp_size)
    if args.mimo_vision_encoder_attention_backend is not None:
        vision_config.attention_backend = args.mimo_vision_encoder_attention_backend
    if args.mimo_vision_encoder_flash_attention_version is not None:
        vision_config.flash_attention_version = args.mimo_vision_encoder_flash_attention_version
    vision_encoder_spec = radio_vision_encoder_spec(args, vision_config, pg_collection)
    projection_input_size = _vision_projection_input_size(args, vision_config)
    input_projections = []
    if not args.mimo_run_input_projections_on_llm_ranks:
        input_projections.append(
            _nemotron_projection_spec(args, projection_input_size, tp_size, pg_collection)
        )
    return ModuleSpec(
        module=VisionModalitySubmodules,
        params={"pg_collection": pg_collection},
        submodules={
            "encoders": {RADIO_ENCODER_MODULE_NAME: vision_encoder_spec},
            "input_projections": input_projections,
        },
    )


def language_input_projection_spec(
    args: argparse.Namespace,
    pg_collection: ProcessGroupCollection | None,
    language_grid: HyperCommGrid,
    language_spec: ModuleSpec,
) -> ModuleSpec | None:
    """Build the RADIO input projection on the first language stage when requested."""
    if not args.mimo_run_input_projections_on_llm_ranks:
        return None

    del language_grid
    vision_config = radio_vision_config(args, args.mimo_encoder_tp, 1)
    language_config = language_spec.params["config"]
    return _nemotron_projection_spec(
        args,
        _vision_projection_input_size(args, vision_config),
        language_config.tensor_model_parallel_size,
        pg_collection,
        language_config,
    )


def nemotron_special_token_ids(args: argparse.Namespace) -> dict[str, int]:
    """Map each encoder module to the special token id marking its inputs."""
    return {RADIO_ENCODER_MODULE_NAME: args.image_token_id}


def _nemotron_bridge_recv_shape(
    batch: dict, image_token_id: int, hidden_size: int
) -> tuple[int, int]:
    """Derive the local projected-vision receive shape from language input IDs."""
    input_ids = batch.get("input_ids")
    if not isinstance(input_ids, torch.Tensor):
        raise TypeError("bridge receive shape requires tensor batch['input_ids']")
    if input_ids.ndim != 2:
        raise ValueError(f"expected 2D batch['input_ids'], got shape {tuple(input_ids.shape)}")
    return int((input_ids == image_token_id).sum().item()), hidden_size


def build_nemotron_communicator(
    args: argparse.Namespace, topology: "HeteroTopology"
) -> MultiModulePipelineCommunicator:
    """Wire the RADIO-encoder -> language cross-grid pipeline communicator."""
    language_grid = topology.grids[MIMO_LANGUAGE_MODULE_KEY]
    language_config = language_model_spec(args, None, language_grid).params["config"]
    if RADIO_ENCODER_MODULE_NAME not in topology.grids:
        # LLM-only topology has no encoder or cross-module bridge metadata.
        return MultiModulePipelineCommunicator(
            topology.grids,
            {MIMO_LANGUAGE_MODULE_KEY: []},
            language_config,
            dim_mapping={"s": 0, "h": 2, "b": 1},
        )
    bridge_recv_shape_fns = None
    if getattr(args, "mimo_bridge_skip_shape_exchange", False):
        bridge_hidden_size = int(args.hidden_size)
        if getattr(args, "mimo_run_input_projections_on_llm_ranks", False):
            vision_config = radio_vision_config(args, args.mimo_encoder_tp, 1)
            bridge_hidden_size = _vision_projection_input_size(args, vision_config)
        bridge_recv_shape_fns = {
            RADIO_ENCODER_MODULE_NAME: partial(
                _nemotron_bridge_recv_shape,
                image_token_id=int(args.image_token_id),
                hidden_size=bridge_hidden_size,
            )
        }
    return MultiModulePipelineCommunicator(
        topology.grids,
        {RADIO_ENCODER_MODULE_NAME: [MIMO_LANGUAGE_MODULE_KEY], MIMO_LANGUAGE_MODULE_KEY: []},
        language_config,
        dim_mapping={"s": 0, "h": 2, "b": 1},
        module_output_ndim={RADIO_ENCODER_MODULE_NAME: 2},
        bridge_recv_shape_fns=bridge_recv_shape_fns,
        bridge_comm_dtypes={RADIO_ENCODER_MODULE_NAME: language_config.params_dtype},
    )


def nemotron_provider() -> MimoProvider:
    """Provider descriptor for the Nemotron6-MoE + RADIO VLM."""
    return MimoProvider(
        encoder_module_names=(RADIO_ENCODER_MODULE_NAME,),
        language_spec=language_model_spec,
        encoder_specs={RADIO_ENCODER_MODULE_NAME: vision_submodules_spec},
        special_token_ids=nemotron_special_token_ids,
        build_communicator=build_nemotron_communicator,
        language_input_projection_specs={RADIO_ENCODER_MODULE_NAME: language_input_projection_spec},
    )
