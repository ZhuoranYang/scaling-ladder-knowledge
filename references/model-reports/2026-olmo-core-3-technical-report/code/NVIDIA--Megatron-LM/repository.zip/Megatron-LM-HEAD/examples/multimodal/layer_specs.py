# Copyright (c) 2024-2026, NVIDIA CORPORATION. All rights reserved.
from functools import partial

import torch

from megatron.core.extensions.transformer_engine import HAVE_TE
from megatron.core.fusions.fused_bias_dropout import get_bias_dropout_add
from megatron.core.models.gpt.moe_module_specs import get_moe_module_spec
from megatron.core.models.hybrid.hybrid_block import HybridStack, HybridStackSubmodules
from megatron.core.ssm.mamba_layer import MambaLayer, MambaLayerSubmodules
from megatron.core.ssm.mamba_mixer import MambaMixer, MambaMixerSubmodules
from megatron.core.ssm.mlp_layer import MLPLayer
from megatron.core.tensor_parallel.layers import ColumnParallelLinear, RowParallelLinear
from megatron.core.transformer.attention import SelfAttention, SelfAttentionSubmodules
from megatron.core.transformer.dot_product_attention import DotProductAttention
from megatron.core.transformer.enums import AttnMaskType
from megatron.core.transformer.identity_op import IdentityOp
from megatron.core.transformer.mlp import MLP, MLPSubmodules
from megatron.core.transformer.spec_utils import ModuleSpec
from megatron.core.transformer.transformer_layer import (
    MoETransformerLayer,
    TransformerLayer,
    TransformerLayerSubmodules,
)
from megatron.core.typed_torch import not_none

if HAVE_TE:
    from megatron.core.extensions.transformer_engine import (
        TEColumnParallelLinear,
        TEDotProductAttention,
        TELayerNormColumnParallelLinear,
        TENorm,
        TERowParallelLinear,
    )
else:
    (
        TEColumnParallelLinear,
        TEDotProductAttention,
        TELayerNormColumnParallelLinear,
        TENorm,
        TERowParallelLinear,
    ) = (None, None, None, None, None)

try:
    import apex

    from megatron.core.fusions.fused_layer_norm import FusedLayerNorm
    from megatron.core.transformer.torch_norm import WrappedTorchNorm

    HAVE_APEX = True
    LNImpl = FusedLayerNorm
except ImportError:
    import warnings

    from megatron.core.transformer.torch_norm import WrappedTorchNorm

    warnings.warn(f'Apex is not installed. Falling back to Torch Norm')
    LNImpl = WrappedTorchNorm


def get_layer_spec(is_vit, normalization) -> ModuleSpec:
    attn_mask_type = AttnMaskType.no_mask if is_vit else AttnMaskType.causal
    if normalization == "LayerNorm":
        norm = LNImpl
    elif normalization == "RMSNorm":
        if HAVE_TE:
            norm = TENorm
        else:
            version = torch.__version__.split('.')
            version_geq_2_4 = int(TORCH_VERSION[0]) > 2 or (
                int(TORCH_VERSION[0]) == 2 and int(TORCH_VERSION[1]) >= 4
            )
            assert version_geq_2_4, "Torch version >= 2.4.0 is required for RMSNorm"
            if HAVE_APEX:
                warnings.warn(f'Apex does not support RMSNorm. Falling back to Torch Norm')
            norm = WrappedTorchNorm
    else:
        raise RuntimeError("unknown normalization", normalization)

    mlp = get_mlp_module_spec(use_te=False)  # doesn't include norm.

    return ModuleSpec(
        module=TransformerLayer,
        submodules=TransformerLayerSubmodules(
            input_layernorm=not_none(norm),
            self_attention=ModuleSpec(
                module=SelfAttention,
                params={"attn_mask_type": attn_mask_type},
                submodules=SelfAttentionSubmodules(
                    linear_qkv=ColumnParallelLinear,
                    core_attention=DotProductAttention,
                    linear_proj=RowParallelLinear,
                    q_layernorm=IdentityOp,
                    k_layernorm=IdentityOp,
                ),
            ),
            self_attn_bda=get_bias_dropout_add,
            pre_mlp_layernorm=not_none(norm),
            mlp=mlp,
            mlp_bda=get_bias_dropout_add,
        ),
    )


def get_layer_spec_te(is_vit=False, padding=False) -> ModuleSpec:
    attn_mask_type = AttnMaskType.no_mask if is_vit else AttnMaskType.causal
    # Padding mask is needed for e.g. Context Parallel.
    if padding:
        assert not is_vit, "padding_causal mask not used with ViT"
        attn_mask_type = AttnMaskType.padding_causal

    mlp = get_norm_mlp_module_spec_te()
    return ModuleSpec(
        module=TransformerLayer,
        submodules=TransformerLayerSubmodules(
            self_attention=ModuleSpec(
                module=SelfAttention,
                params={"attn_mask_type": attn_mask_type},
                submodules=SelfAttentionSubmodules(
                    linear_qkv=not_none(TELayerNormColumnParallelLinear),
                    core_attention=not_none(TEDotProductAttention),
                    linear_proj=not_none(TERowParallelLinear),
                    q_layernorm=IdentityOp,
                    k_layernorm=IdentityOp,
                ),
            ),
            self_attn_bda=get_bias_dropout_add,
            pre_mlp_layernorm=IdentityOp,
            mlp=mlp,
            mlp_bda=get_bias_dropout_add,
        ),
    )


def get_hybrid_layer_spec_te(config=None, padding=False) -> ModuleSpec:
    """Hybrid (Mamba + attention + MLP [+ MoE]) layer spec.

    Args:
        config: language-model ``TransformerConfig``. Required for MoE hybrids
            (e.g. nemotron3-moe, formerly nemotron6-moe): the moe_layer branch reads
            ``num_moe_experts`` / ``moe_grouped_gemm`` off it to match the
            checkpoint's architecture. Non-MoE hybrids may pass ``None``;
            they never traverse the moe_layer branch.
        padding: use padding-causal attention mask (needed for context
            parallel + sequence parallel).
    """
    attn_mask_type = AttnMaskType.causal
    # Padding mask is needed for e.g. Context Parallel.
    if padding:
        attn_mask_type = AttnMaskType.padding_causal

    if config is not None:
        assert config.num_moe_experts is not None, (
            "get_hybrid_layer_spec_te: config.num_moe_experts must be set to "
            "build the MoE branch of the hybrid stack."
        )
        num_experts = config.num_moe_experts
        moe_grouped_gemm = config.moe_grouped_gemm
    else:
        num_experts = None
        moe_grouped_gemm = None

    return ModuleSpec(
        module=HybridStack,
        submodules=HybridStackSubmodules(
            mamba_layer=ModuleSpec(
                module=MambaLayer,
                submodules=MambaLayerSubmodules(
                    mixer=ModuleSpec(
                        module=MambaMixer,
                        submodules=MambaMixerSubmodules(
                            in_proj=TELayerNormColumnParallelLinear, out_proj=TERowParallelLinear
                        ),
                    ),
                    mamba_bda=get_bias_dropout_add,
                ),
            ),
            # Started with spec from gpt_layer_specs.py (with MLP removed)
            # Using the TE spec because we had problems getting the non-TE spec
            # working
            attention_layer=ModuleSpec(
                module=TransformerLayer,
                submodules=TransformerLayerSubmodules(
                    self_attention=ModuleSpec(
                        module=SelfAttention,
                        params={"attn_mask_type": attn_mask_type},
                        submodules=SelfAttentionSubmodules(
                            linear_qkv=not_none(TELayerNormColumnParallelLinear),
                            core_attention=not_none(TEDotProductAttention),
                            linear_proj=not_none(TERowParallelLinear),
                        ),
                    ),
                    self_attn_bda=get_bias_dropout_add,
                ),
            ),
            # Started with spec from gpt_layer_specs.py
            # Using the TE spec because we had problems getting the non-TE spec
            # working
            mlp_layer=ModuleSpec(
                module=MLPLayer,
                submodules=TransformerLayerSubmodules(
                    mlp=partial(
                        MLP.as_mlp_submodule,
                        submodules=MLPSubmodules(
                            linear_fc1=not_none(TELayerNormColumnParallelLinear),
                            linear_fc2=not_none(TERowParallelLinear),
                        ),
                    ),
                    mlp_bda=get_bias_dropout_add,
                ),
            ),
            moe_layer=ModuleSpec(
                module=MoETransformerLayer,
                submodules=TransformerLayerSubmodules(
                    pre_mlp_layernorm=TENorm,
                    mlp=get_moe_module_spec(
                        use_te=True,
                        num_experts=num_experts,
                        moe_grouped_gemm=moe_grouped_gemm,
                        moe_use_legacy_grouped_gemm=False,
                    ),
                    mlp_bda=get_bias_dropout_add,
                ),
            ),
        ),
    )


def get_mlp_module_spec(use_te: bool = True):
    # Dense MLP w/ or w/o TE modules.
    return ModuleSpec(
        module=MLP,
        submodules=MLPSubmodules(
            linear_fc1=not_none(TEColumnParallelLinear) if use_te else ColumnParallelLinear,
            linear_fc2=not_none(TERowParallelLinear) if use_te else RowParallelLinear,
        ),
    )


def get_norm_mlp_module_spec_te():
    return ModuleSpec(
        module=MLP,
        submodules=MLPSubmodules(
            linear_fc1=not_none(TELayerNormColumnParallelLinear),
            linear_fc2=not_none(TERowParallelLinear),
        ),
    )
