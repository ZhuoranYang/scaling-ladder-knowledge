# Copyright (c) 2025, NVIDIA CORPORATION. All rights reserved.

"""Export a GPTModel."""
import functools
import inspect
import os
import sys
import warnings
from pathlib import Path

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../")))

import modelopt.torch.export as mtex
import torch

from megatron.core.utils import unwrap_model
from megatron.post_training.arguments import add_modelopt_args
from megatron.post_training.model_builder import modelopt_gpt_hybrid_builder
from megatron.training import get_args, get_model
from megatron.training.arguments import parse_and_validate_args
from megatron.training.checkpointing import load_checkpoint
from megatron.training.argument_utils import inference_cfg_container_from_args
from megatron.training.global_vars import set_run_config
from megatron.training.initialize import initialize_megatron
from model_provider import model_provider

warnings.filterwarnings('ignore')


def add_modelopt_export_args(parser):
    """Add additional arguments for ModelOpt hf-like export."""
    group = parser.add_argument_group(title='ModelOpt hf-like export')
    group.add_argument(
        "--export-extra-modules",
        action="store_true",
        help="Export extra modules such as Medusa, EAGLE, or MTP.",
    )
    group.add_argument(
        "--pretrained-model-name",
        type=str,
        help="A pretrained model hosted inside a model repo on huggingface.co.",
    )
    group.add_argument(
        "--export-vllm-fq",
        action="store_true",
        default=False,
        help="Export the model for vLLM fakequant reload.",
    )
    group.add_argument(
        "--no-clamp-kv-scales",
        action="store_false",
        dest="clamp_kv_scales",
        default=True,
        help="Preserve FP8 KV-cache scales learned during QAT instead of clamping them to 1.0.",
    )
    group.add_argument("--export-dir", type=str, help="The target export path.")
    add_modelopt_args(parser)
    return parser


if __name__ == "__main__":
    args = parse_and_validate_args(
        extra_args_provider=add_modelopt_export_args,
        args_defaults={
            'tokenizer_type': 'HuggingFaceTokenizer',
            'no_load_rng': True,
            'no_load_optim': True,
        },
    )
    # Temporary args/config duplication during the training-loop refactor:
    # migrated settings use config; remaining settings still use legacy args.
    set_run_config(inference_cfg_container_from_args(args, build_model_config=False))
    initialize_megatron(training=False)

    args = get_args()

    # Meta device initialization for ParallelLinear only works if using cpu initialization.
    # Meta device initialization is used such that models can be materialized in low-precision
    # directly when ModelOpt real quant is used. Otherwise, the model is first initialized
    # as BF16 in memory which may result in OOM and defeat the purpose of real quant.
    args.use_cpu_initialization = True
    if not args.init_model_with_meta_device:
        warnings.warn(
            "--init-model-with-meta-device is not set. If you would like to resume the "
            "model in low-bit directly (low-memory initialization and skipping 16-bit), "
            "--init-model-with-meta-device must be set.",
            UserWarning,
        )

    model = get_model(
        functools.partial(model_provider, modelopt_gpt_hybrid_builder), wrap_with_ddp=False
    )

    # Materialize the model from meta device to cpu before loading the checkpoint.
    unwrapped_model = unwrap_model(model)[0]
    unwrapped_model.to_empty(device="cpu")

    if args.load is not None and Path(args.load).is_dir():
        load_checkpoint(model, None, None)
    else:
        raise ValueError(f"Invalid load checkpoint directory: {args.load}")


    # Decide whether we are exporting only the extra_modules (e.g. EAGLE3).
    # Only the last pp stage may have extra_modules, hence broadcast from the last rank.
    export_extra_modules = hasattr(unwrapped_model, "eagle_module") or hasattr(
        unwrapped_model, "medusa_heads"
    )
    torch.distributed.broadcast_object_list(
        [export_extra_modules], src=torch.distributed.get_world_size() - 1
    )

    export_kwargs = {
        "export_extra_modules": export_extra_modules,
        "dtype": torch.bfloat16,
        "export_dir": args.export_dir,
        "moe_router_dtype": unwrapped_model.config.moe_router_dtype,
    }
    export_fn = mtex.export_mcore_gpt_to_hf_vllm_fq if args.export_vllm_fq else mtex.export_mcore_gpt_to_hf

    if "trust_remote_code" in inspect.signature(export_fn).parameters:
        export_kwargs.update({"trust_remote_code": args.trust_remote_code})

    if "clamp_kv_cache_scales" in inspect.signature(export_fn).parameters:
        export_kwargs["clamp_kv_cache_scales"] = args.clamp_kv_scales
    elif not args.clamp_kv_scales:
        raise RuntimeError(
            "--no-clamp-kv-scales requires a ModelOpt version that supports "
            "export_mcore_gpt_to_hf(..., clamp_kv_cache_scales=False)."
        )

    export_fn(unwrapped_model, args.pretrained_model_name, **export_kwargs)
