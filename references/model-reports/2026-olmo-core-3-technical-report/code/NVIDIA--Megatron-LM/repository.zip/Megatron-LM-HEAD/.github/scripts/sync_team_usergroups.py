# Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Syncs GitHub team membership to Slack user groups.

This script reads members from GitHub teams and updates the corresponding
Slack user groups to match.
"""

import argparse
import os
import sys

import requests
from github_slack_utils import SlackApiError, get_slack_client, get_slack_user_id, get_user_email

# Constants
GITHUB_API_URL = "https://api.github.com"

# Teams whose *children* are each synced to their own Slack usergroup
PARENT_TEAM_SLUGS = ["mcore-reviewers"]

# Teams synced directly (the team itself, not its children)
DIRECT_TEAM_SLUGS = ["mcore-engineers"]

_usergroups_cache = None


def get_headers():
    """Get GitHub API headers with authentication."""
    token = os.environ.get("GH_TOKEN")
    if not token:
        token = os.environ.get("GITHUB_TOKEN")

    if not token:
        print("Error: GH_TOKEN or GITHUB_TOKEN not set")
        sys.exit(1)

    return {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}


def get_org():
    """Returns the organization from GITHUB_REPOSITORY env var or default."""
    repo_env = os.environ.get("GITHUB_REPOSITORY", "NVIDIA/Megatron-LM")
    return repo_env.split("/")[0]


def github_team_to_slack_usergroup(team_slug):
    """Convert a GitHub team slug to a Slack usergroup handle.

    Rules:
    - Training team: "training" -> "megatron-training"
    - Base pattern: "test" -> "mcore-test"
    - Remove "core-" prefix: "core-test" -> "mcore-test"
    - Remove "megatron-" prefix: "megatron-test" -> "mcore-test"
    - Remove "-and-": "test1-and-test2" -> "mcore-test1-test2"
    - Shorten "mixture-of-experts" to "moe"
    - Shorten "pipeline-parallelism" to "pp"
    - Shorten "reinforcement-learning" to "rl"
    """
    if team_slug == "training":
        return "megatron-training"

    name = team_slug

    # Apply shortenings first (before removing prefixes)
    name = name.replace("mixture-of-experts", "moe")
    name = name.replace("pipeline-parallelism", "pp")
    name = name.replace("reinforcement-learning", "rl")

    # Remove prefixes
    if name.startswith("core-"):
        name = name[5:]  # Remove "core-"
    elif name.startswith("megatron-"):
        name = name[9:]  # Remove "megatron-"
    elif name.startswith("mcore-"):
        name = name[6:]  # Remove "mcore-"

    # Remove "-and-"
    name = name.replace("-and-", "-")

    return f"mcore-{name}"


def get_child_teams(org, parent_team_slug):
    """Fetches child teams of a parent GitHub team."""
    # First get the team ID
    url = f"{GITHUB_API_URL}/orgs/{org}/teams/{parent_team_slug}"
    headers = get_headers()

    resp = requests.get(url, headers=headers)
    if resp.status_code != 200:
        print(f"Error fetching parent team '{parent_team_slug}': {resp.status_code} {resp.text}")
        return []

    parent_team_id = resp.json().get("id")
    if not parent_team_id:
        print(f"Error: Could not get ID for team '{parent_team_slug}'")
        return []

    # Now fetch child teams
    url = f"{GITHUB_API_URL}/orgs/{org}/teams/{parent_team_slug}/teams"
    child_teams = []
    page = 1

    while True:
        resp = requests.get(f"{url}?per_page=100&page={page}", headers=headers)
        if resp.status_code != 200:
            print(f"Error fetching child teams: {resp.status_code} {resp.text}")
            return child_teams

        data = resp.json()
        if not data:
            break

        child_teams.extend([team["slug"] for team in data])
        if len(data) < 100:
            break
        page += 1

    return child_teams


def get_team_members(org, team_slug):
    """Fetches members of the GitHub team."""
    url = f"{GITHUB_API_URL}/orgs/{org}/teams/{team_slug}/members"
    headers = get_headers()

    members = set()
    page = 1
    while True:
        resp = requests.get(f"{url}?per_page=100&page={page}", headers=headers)
        if resp.status_code == 404:
            print(f"Warning: Team '{team_slug}' not found in org '{org}'")
            return set()
        if resp.status_code != 200:
            print(f"Error fetching team members: {resp.status_code} {resp.text}")
            return set()

        data = resp.json()
        if not data:
            break

        members.update([m["login"] for m in data])
        if len(data) < 100:
            break
        page += 1

    return members


def fetch_all_usergroups(slack_client):
    """Fetch all Slack usergroups once and cache them."""
    global _usergroups_cache

    if _usergroups_cache is not None:
        return _usergroups_cache

    if not slack_client:
        _usergroups_cache = {}
        return _usergroups_cache

    try:
        print("Fetching Slack usergroups...")
        response = slack_client.usergroups_list(include_users=True)
        _usergroups_cache = {}
        for usergroup in response.get("usergroups", []):
            handle = usergroup.get("handle")
            if handle:
                _usergroups_cache[handle] = {
                    "id": usergroup.get("id"),
                    "users": usergroup.get("users", []),
                }
        print(f"Fetched {len(_usergroups_cache)} usergroups")
        return _usergroups_cache
    except SlackApiError as e:
        print(f"Warning: Could not list Slack usergroups: {e.response['error']}")
        _usergroups_cache = {}
        return _usergroups_cache


def get_slack_usergroup_id(slack_client, handle):
    """Get Slack usergroup ID from handle."""
    usergroups = fetch_all_usergroups(slack_client)

    if handle in usergroups:
        return usergroups[handle]["id"], usergroups[handle]["users"]

    return None, []


def github_team_to_usergroup_name(team_slug):
    """Convert a GitHub team slug to a Slack usergroup display name.

    Example: "test3" -> "Megatron Core Experts: Test3"
    """
    # Title case each word separated by hyphens, then join with spaces
    words = team_slug.split("-")
    title_cased = " ".join(word.capitalize() for word in words)
    return f"Megatron Core Experts: {title_cased}"


def create_slack_usergroup(slack_client, handle, team_slug):
    """Create a new Slack usergroup.

    Args:
        slack_client: Slack WebClient instance
        handle: The usergroup handle (e.g., "mcore-test")
        team_slug: The GitHub team slug (used for name and description)

    Returns:
        The usergroup ID if created successfully, None otherwise
    """
    global _usergroups_cache

    name = github_team_to_usergroup_name(team_slug)
    description = f'Expert review group "{team_slug}"'

    try:
        print(f"Creating Slack usergroup '@{handle}' with name '{name}'...")
        response = slack_client.usergroups_create(name=name, handle=handle, description=description)
        usergroup = response.get("usergroup", {})
        usergroup_id = usergroup.get("id")

        if usergroup_id:
            # Update cache with new usergroup
            if _usergroups_cache is not None:
                _usergroups_cache[handle] = {"id": usergroup_id, "users": []}
            print(f"Successfully created Slack usergroup '@{handle}'")
            return usergroup_id
        else:
            print(f"Error: Usergroup created but no ID returned")
            return None

    except SlackApiError as e:
        print(f"Error creating Slack usergroup '@{handle}': {e.response['error']}")
        return None


def sync_team_to_usergroup(team_slug, usergroup_handle, dry_run=False):
    """Sync a GitHub team to a Slack usergroup."""
    print(f"\n{'='*60}")
    print(f"Syncing GitHub team '{team_slug}' -> Slack usergroup '@{usergroup_handle}'")
    print(f"{'='*60}")

    org = get_org()
    slack_client = get_slack_client()

    if not slack_client:
        print("Error: Slack token not configured")
        return False

    # 1. Get GitHub team members
    members = get_team_members(org, team_slug)
    if not members:
        print(f"No members found in GitHub team '{team_slug}'")
        return False

    # Filter out service accounts
    members = {m for m in members if not m.startswith("svc")}
    print(f"GitHub team members ({len(members)}): {sorted(members)}")

    # 2. Get Slack user IDs for each member
    slack_user_ids = []
    missing_users = []

    for username in sorted(members):
        email = get_user_email(username)
        slack_id = get_slack_user_id(slack_client, email)
        if slack_id:
            slack_user_ids.append(slack_id)
        else:
            missing_users.append((username, email, "not found in Slack"))

    if missing_users:
        print(f"\nWarning: Could not resolve {len(missing_users)} users:")
        for username, email, reason in missing_users:
            print(f"  - {username}: {reason}" + (f" (tried {email})" if email else ""))

    if not slack_user_ids:
        print(f"Error: No Slack users found for team '{team_slug}'")
        return False

    # 3. Get current Slack usergroup membership (or create if it doesn't exist)
    usergroup_id, current_members = get_slack_usergroup_id(slack_client, usergroup_handle)

    if not usergroup_id:
        print(f"Slack usergroup '@{usergroup_handle}' not found, creating it...")
        if dry_run:
            print(f"Dry run: Would create usergroup '@{usergroup_handle}'")
            current_members = []
        else:
            usergroup_id = create_slack_usergroup(slack_client, usergroup_handle, team_slug)
            if not usergroup_id:
                print(f"Error: Failed to create Slack usergroup '@{usergroup_handle}'")
                return False
            current_members = []

    # 4. Compare and update
    current_set = set(current_members)
    new_set = set(slack_user_ids)

    to_add = new_set - current_set
    to_remove = current_set - new_set

    print(f"\nCurrent usergroup members: {len(current_members)}")
    print(f"New members to set: {len(slack_user_ids)}")
    print(f"  Adding: {len(to_add)} users")
    print(f"  Removing: {len(to_remove)} users")

    if current_set == new_set:
        print("No changes needed - usergroup is already in sync")
        return True

    if dry_run:
        print(f"\nDry run: Would update '@{usergroup_handle}' with {len(slack_user_ids)} members")
        return True

    # 5. Update the usergroup
    try:
        slack_client.usergroups_users_update(usergroup=usergroup_id, users=slack_user_ids)
        print(f"\nSuccessfully updated '@{usergroup_handle}' with {len(slack_user_ids)} members")
        return True
    except SlackApiError as e:
        print(f"Error updating usergroup: {e.response['error']}")
        return False


def get_team_to_usergroup_mapping(parent_team_slug):
    """Fetch child teams of a parent team and generate the mapping."""
    org = get_org()
    child_teams = get_child_teams(org, parent_team_slug)

    if not child_teams:
        print(f"Error: No child teams found under '{parent_team_slug}'")
        return {}

    mapping = {}
    for team_slug in child_teams:
        usergroup_handle = github_team_to_slack_usergroup(team_slug)
        mapping[team_slug] = usergroup_handle

    return mapping


def sync_all_teams(dry_run=False, parent_teams=None, direct_teams=None):
    """Sync GitHub teams to their Slack usergroups.

    Args:
        parent_teams: List of team slugs whose *children* are each synced.
                      Defaults to PARENT_TEAM_SLUGS.
        direct_teams: List of team slugs synced directly (not their children).
                      Defaults to DIRECT_TEAM_SLUGS.
    """
    if parent_teams is None:
        parent_teams = PARENT_TEAM_SLUGS
    if direct_teams is None:
        direct_teams = DIRECT_TEAM_SLUGS

    team_to_usergroup = {}

    for parent_slug in parent_teams:
        print(f"Fetching child teams of '{parent_slug}'...")
        mapping = get_team_to_usergroup_mapping(parent_slug)
        team_to_usergroup.update(mapping)

    for team_slug in direct_teams:
        usergroup_handle = github_team_to_slack_usergroup(team_slug)
        team_to_usergroup[team_slug] = usergroup_handle

    if not team_to_usergroup:
        return False

    print(f"Found {len(team_to_usergroup)} teams to sync")
    print("\nTeam to usergroup mapping:")
    for team, usergroup in sorted(team_to_usergroup.items()):
        print(f"  {team} -> @{usergroup}")

    results = {"success": [], "failed": []}

    for team_slug, usergroup_handle in team_to_usergroup.items():
        success = sync_team_to_usergroup(team_slug, usergroup_handle, dry_run=dry_run)
        if success:
            results["success"].append(team_slug)
        else:
            results["failed"].append(team_slug)

    # Summary
    print(f"\n{'='*60}")
    print("SYNC SUMMARY")
    print(f"{'='*60}")
    print(f"Successful: {len(results['success'])}")
    print(f"Failed: {len(results['failed'])}")

    if results["failed"]:
        print(f"\nFailed teams: {', '.join(results['failed'])}")
        return False

    return True


def main():
    parser = argparse.ArgumentParser(description="Sync GitHub team membership to Slack user groups")
    parser.add_argument(
        "--dry-run", action="store_true", help="Show what would be done without making changes"
    )
    parser.add_argument(
        "--list", action="store_true", help="List all configured team-to-usergroup mappings"
    )
    parser.add_argument(
        "--parent-team",
        action="append",
        dest="parent_teams",
        metavar="SLUG",
        help=(
            "Sync all children of this GitHub team (can be repeated). "
            f"Defaults to: {PARENT_TEAM_SLUGS}"
        ),
    )
    parser.add_argument(
        "--team",
        action="append",
        dest="direct_teams",
        metavar="SLUG",
        help=(
            "Sync this GitHub team directly (can be repeated). " f"Defaults to: {DIRECT_TEAM_SLUGS}"
        ),
    )

    args = parser.parse_args()

    # Use CLI values when provided, otherwise fall back to module-level defaults
    parent_teams = args.parent_teams if args.parent_teams is not None else PARENT_TEAM_SLUGS
    direct_teams = args.direct_teams if args.direct_teams is not None else DIRECT_TEAM_SLUGS

    if args.list:
        team_to_usergroup = {}
        for parent_slug in parent_teams:
            print(f"Fetching child teams of '{parent_slug}'...")
            team_to_usergroup.update(get_team_to_usergroup_mapping(parent_slug))
        for team_slug in direct_teams:
            team_to_usergroup[team_slug] = github_team_to_slack_usergroup(team_slug)
        if not team_to_usergroup:
            sys.exit(1)
        print("\nTeam-to-usergroup mappings:")
        print(f"{'GitHub Team':<35} {'Slack Usergroup':<30}")
        print("-" * 65)
        for team, usergroup in sorted(team_to_usergroup.items()):
            print(f"{team:<35} @{usergroup:<29}")
        return

    success = sync_all_teams(
        dry_run=args.dry_run, parent_teams=parent_teams, direct_teams=direct_teams
    )
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
