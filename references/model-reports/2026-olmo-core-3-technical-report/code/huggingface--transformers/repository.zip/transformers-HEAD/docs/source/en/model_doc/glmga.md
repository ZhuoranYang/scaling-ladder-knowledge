<!--Copyright 2026 the HuggingFace Team. All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.


⚠️ Note that this file is in Markdown but contains specific syntax for our doc-builder (similar to MDX) that may not be rendered properly in your Markdown viewer.

-->
*This model was contributed to Hugging Face Transformers on 2026-05-26.*


# Glmga

## Overview

Paper and author details for the Glmga model are not available yet.

The abstract from the paper is the following:

<INSERT PAPER ABSTRACT HERE>

Tips:

<INSERT TIPS ABOUT MODEL HERE>

The model contribution details and original code repository are not available yet.

## Usage examples

<INSERT SOME NICE EXAMPLES HERE>

Glmga reuses the [GLM-4.6V](./glm46v) modeling and processor; only its configuration and image/video
processors are model-specific. Load it with the `Auto*` classes (e.g. `AutoModelForImageTextToText`,
`AutoProcessor`), which resolve to the GLM-4.6V implementation.

## GlmgaConfig

[[autodoc]] GlmgaConfig

## GlmgaImageProcessor

[[autodoc]] GlmgaImageProcessor

## GlmgaVideoProcessor

[[autodoc]] GlmgaVideoProcessor

## GlmgaImageProcessorPil

[[autodoc]] GlmgaImageProcessorPil
