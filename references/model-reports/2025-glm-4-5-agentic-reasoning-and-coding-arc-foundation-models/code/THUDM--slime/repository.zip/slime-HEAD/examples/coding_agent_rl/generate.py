"""Coding-Agent RL: per-sample generate() function for slime.

    --custom-generate-function-path examples.coding_agent_rl.generate.generate

generate() is a four-stage orchestrator: swe.prepare_workspace + harness.run
-> swe.git_diff -> swe.run_evaluation -> adapter.finish_session. The (harness,
adapter) pair is chosen by sample.metadata.agent, falling back to SWE_AGENT
(claude_code | codex); see _AGENTS below.
Sandbox-side work is split across three layers: the provider-agnostic sandbox
contract (slime.agent.sandbox), the swappable harness lifecycle
(slime.agent.harness), and the SWE task layer (examples.coding_agent_rl.swe --
dataset parsing, workspace prep, diff, eval). LLM plumbing (Anthropic / OpenAI
<-> SGLang /generate, token capture, segment split) is the matching
slime.agent.adapters adapter. swe.get_metadata documents the dataset row schema
and produces the md dict consumed below.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import random
import secrets
import sys
import time
import traceback
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager, nullcontext
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from slime.agent.adapters import AnthropicAdapter, ResponsesAdapter
from slime.agent.aiohttp_threaded import FilteredAccessLogger, run_app_in_thread
from slime.agent.harness import ClaudeCodeHarness, CodexHarness
from slime.agent.sandbox import EXIT_TIME_BUDGET_EXCEEDED, Sandbox, SandboxTerminatedError
from slime.observability.trace_utils import bind_trace, export_trace, import_trace, trace_span
from slime.utils.misc import SingletonMeta, get_current_node_ip
from slime.utils.processing_utils import load_tokenizer
from slime.utils.types import Sample

from . import swe
from .sandbox import create_sandbox

logger = logging.getLogger(__name__)
logging.getLogger("e2b").setLevel(logging.WARNING)

_AGENTS = {
    "claude_code": (ClaudeCodeHarness, AnthropicAdapter),
    "codex": (CodexHarness, ResponsesAdapter),
}
AGENT_NAME = os.environ.get("SWE_AGENT", "claude_code")
if AGENT_NAME not in _AGENTS:
    raise ValueError(f"SWE_AGENT={AGENT_NAME!r} not in {sorted(_AGENTS)}")
HARNESS_CLS, ADAPTER_CLS = _AGENTS[AGENT_NAME]


def agent_name_for(sample: Sample) -> str:
    name = (sample.metadata or {}).get("agent", AGENT_NAME)
    if name not in _AGENTS:
        raise ValueError(f"Unknown coding agent {name!r}; expected one of {sorted(_AGENTS)}")
    return name


@dataclass(frozen=True)
class SweConfig:
    eval_protocol: str  # eval-path schema/grader (SWE_EVAL_PROTOCOL)
    train_protocol: str  # train-path schema/grader (SWE_TRAIN_PROTOCOL)
    adapter_public_host: str | None
    adapter_bind_host: str
    adapter_port: int
    fork_merge_threshold: int | None
    agent_time_budget_sec: int
    eval_timeout_sec: int
    rollout_guard_sec: int
    boot_concurrency: int
    boot_retries: int

    @classmethod
    def from_env(cls) -> SweConfig:
        agent_time_budget = int(os.environ.get("SWE_AGENT_TIME_BUDGET_SEC", "1800"))
        eval_timeout = int(os.environ.get("SWE_EVAL_TIMEOUT_SEC", "600"))
        guard = int(os.environ.get("SWE_ROLLOUT_GUARD_SEC", "0") or 0) or (agent_time_budget + eval_timeout + 180)
        fork = int(os.environ.get("SLIME_FORK_MERGE_MAX_RESPONSE_TOKENS") or "0")
        return cls(
            eval_protocol=os.environ.get("SWE_EVAL_PROTOCOL", swe.PROTOCOL_SCALESWE),
            train_protocol=os.environ.get("SWE_TRAIN_PROTOCOL", swe.PROTOCOL_SCALESWE),
            adapter_public_host=os.environ.get("ADAPTER_PUBLIC_HOST"),
            adapter_bind_host=os.environ.get("ADAPTER_BIND_HOST", "0.0.0.0"),
            adapter_port=int(os.environ.get("ADAPTER_PORT", "18001")),
            fork_merge_threshold=fork,
            agent_time_budget_sec=agent_time_budget,
            eval_timeout_sec=eval_timeout,
            rollout_guard_sec=guard,
            boot_concurrency=int(os.environ.get("SWE_BOOT_CONCURRENCY", "0")),
            boot_retries=int(os.environ.get("SWE_BOOT_RETRIES", "2")),
        )


CONFIG = SweConfig.from_env()

if CONFIG.boot_concurrency < 0:
    raise ValueError("SWE_BOOT_CONCURRENCY must be nonnegative; 0 disables the boot limit")
_BOOT_SEM = asyncio.Semaphore(CONFIG.boot_concurrency) if CONFIG.boot_concurrency else None
_TRACE_FILE_ID = secrets.token_hex(8)


@asynccontextmanager
async def boot_agent_sandbox(image: str, instance_id: str, *, harness=None, trace=None) -> AsyncIterator[Sandbox]:
    """Boot a fresh sandbox and install the selected harness toolchain.

    Create the sandbox from the dataset image, install Node 22 + the harness CLI
    from host tarballs, retry transient boot/install failures, and close the
    sandbox when the caller leaves the context.
    """
    sb = None
    last_err: Exception | None = None
    for attempt in range(CONFIG.boot_retries):
        cand = create_sandbox(image)
        try:
            with trace_span(trace, "sandbox_boot_wait", record_error=False) if trace else nullcontext():
                if _BOOT_SEM is not None:
                    await _BOOT_SEM.acquire()
            try:
                with (
                    trace_span(trace, "sandbox_create", attrs={"attempt": attempt}, record_error=False)
                    if trace
                    else nullcontext()
                ):
                    await cand.__aenter__()
                try:
                    with trace_span(trace, "harness_install", record_error=False) if trace else nullcontext():
                        await (harness or HARNESS_CLS()).install_cli(cand)
                except BaseException:
                    with trace_span(trace, "sandbox_cleanup", record_error=False) if trace else nullcontext():
                        await cand.__aexit__(None, None, None)
                    raise
            finally:
                if _BOOT_SEM is not None:
                    _BOOT_SEM.release()
            sb = cand
            break
        except Exception as e:
            last_err = e
            logger.warning(
                "[coding_agent_rl] %s: provision attempt %d/%d failed: %s: %s",
                instance_id,
                attempt + 1,
                CONFIG.boot_retries,
                type(e).__name__,
                str(e)[:200],
            )
            with trace_span(trace, "sandbox_boot_backoff", record_error=False) if trace else nullcontext():
                await asyncio.sleep(1 + attempt + random.random())
    if sb is None:
        assert last_err is not None
        raise last_err
    try:
        yield sb
    finally:
        with trace_span(trace, "sandbox_cleanup", record_error=False) if trace else nullcontext():
            await sb.__aexit__(*sys.exc_info())


class _AdapterService(metaclass=SingletonMeta):
    def __init__(self, args) -> None:
        self.args = args
        self.tokenizer = load_tokenizer(args.hf_checkpoint, trust_remote_code=True)
        self.max_context_len = int(getattr(args, "rollout_max_context_len", 0) or 0)
        self.tool_parser = getattr(args, "sglang_tool_call_parser", None) or None
        self.reasoning_parser = getattr(args, "sglang_reasoning_parser", None) or None
        self.sglang_url = f"http://{args.sglang_router_ip}:{args.sglang_router_port}"
        if not CONFIG.adapter_public_host:
            raise RuntimeError(
                "ADAPTER_PUBLIC_HOST is not set. Export it to the host IP that "
                "sandboxes can reach for reverse-connection to the adapter; "
                "without it the sandbox cannot dial back and the rollout aborts."
            )
        self._endpoints = {}
        self.adapter, self.adapter_url, self.app_handle = self.endpoint(AGENT_NAME)

    def endpoint(self, agent_name):
        if agent_name in self._endpoints:
            return self._endpoints[agent_name]
        _, adapter_cls = _AGENTS[agent_name]
        adapter = adapter_cls(
            tokenizer=self.tokenizer,
            sglang_url=self.sglang_url,
            tool_parser=self.tool_parser,
            reasoning_parser=self.reasoning_parser,
            fork_threshold_tokens=CONFIG.fork_merge_threshold,
            rollout_args=self.args,
        )
        # handler_cancellation=True so a client disconnect cancels the handler
        # coroutine, arming the fire-and-forget /abort_request in the adapter.
        # Otherwise a cancelled client leaves an inflight sglang /generate that
        # races the next release_memory_occupation and trips its idle assertion.
        app_handle = run_app_in_thread(
            adapter.app,
            host=CONFIG.adapter_bind_host,
            port=CONFIG.adapter_port if not self._endpoints else 0,
            thread_name=f"{agent_name}-adapter",
            runner_kwargs={
                "handler_cancellation": True,
                "access_log_class": FilteredAccessLogger,
            },
        )
        public_host = get_current_node_ip() if CONFIG.adapter_public_host == "auto" else CONFIG.adapter_public_host
        adapter_url = f"http://{public_host}:{app_handle.port}"
        logger.info(
            "[coding_agent_rl] agent=%s tokenizer=%s adapter=%s max_context_len=%s tool_parser=%s reasoning_parser=%s",
            agent_name,
            self.args.hf_checkpoint,
            adapter_url,
            self.max_context_len,
            self.tool_parser,
            self.reasoning_parser,
        )
        self._endpoints[agent_name] = (adapter, adapter_url, app_handle)
        return self._endpoints[agent_name]


async def generate(args, base_sample: Sample, sampling_params: dict[str, Any], evaluation: bool = False):
    """Trace every trajectory, including those later rejected by group filtering."""
    samples = []
    try:
        with trace_span(base_sample, "coding_rollout", record_error=False):
            samples = await _generate(args, base_sample, sampling_params, evaluation)
        return samples
    finally:
        # One append-only shard per worker, without prompts, commands, images,
        # endpoints, or environment variables. Keep failed attempts as well.
        if trace_dir := os.environ.get("SWE_TRACE_DIR"):
            try:
                path = Path(trace_dir)
                path.mkdir(parents=True, exist_ok=True)
                record = {
                    "index": base_sample.index,
                    "group_index": base_sample.group_index,
                    "trace": base_sample.trace,
                    "status": samples[0].status.value if samples else "interrupted",
                    "reward": float(samples[0].reward or 0) if samples else 0.0,
                    "response_length": sum(sum(s.loss_mask or []) for s in samples),
                    "metadata": {"agent": agent_name_for(base_sample), "segments": len(samples)},
                }
                with (path / f"rollouts-{_TRACE_FILE_ID}.jsonl").open("a") as stream:
                    stream.write(json.dumps(record) + "\n")
            except Exception:
                logger.exception("Could not write coding rollout trace")


async def _generate(args, base_sample: Sample, sampling_params: dict[str, Any], evaluation: bool = False):
    """Per-sample agent function with wall-clock guard (see rollout_guard_sec)."""
    state = _AdapterService(args)
    agent_name = agent_name_for(base_sample)
    harness = _AGENTS[agent_name][0]()
    adapter, adapter_url, _ = state.endpoint(agent_name)
    protocol = CONFIG.eval_protocol if evaluation else CONFIG.train_protocol
    md = swe.get_metadata(base_sample, protocol)
    instance_id = md["instance_id"]
    if not md["image"] or not md["workdir"]:
        return _abort_result(base_sample, "missing_image_or_workdir", instance_id)
    reason = swe.evaluability_check(md)
    if reason:
        return _abort_result(base_sample, f"unevaluatable:{reason}", instance_id)

    session_id = base_sample.session_id = _session_id(base_sample, instance_id)
    adapter.open_session(
        session_id,
        trace=import_trace(export_trace(bind_trace(base_sample)), base_sample.trace),
        sampling_defaults=sampling_params,
        max_context_tokens=state.max_context_len,
        apply_chat_template_kwargs={
            **(getattr(args, "apply_chat_template_kwargs", None) or {}),
            **(base_sample.apply_chat_template_kwargs or {}),
        },
    )
    t0 = time.time()
    try:
        async with asyncio.timeout(CONFIG.rollout_guard_sec):
            async with boot_agent_sandbox(md["image"], instance_id, harness=harness, trace=base_sample) as sb:
                with trace_span(base_sample, "workspace_prepare", record_error=False):
                    baseline = await swe.prepare_workspace(sb, md["workdir"], md)
                with trace_span(base_sample, "agent_run", record_error=False) as span:
                    agent_exit_code = await harness.run(
                        sb,
                        workdir=md["workdir"],
                        session_id=session_id,
                        adapter_url=adapter_url,
                        time_budget_sec=CONFIG.agent_time_budget_sec,
                        prompt=swe.SWE_PROMPT,
                    )
                    span.set("exit_code", agent_exit_code)
                agent_metrics = await harness.collect_metrics(sb, workdir=md["workdir"])
                with trace_span(base_sample, "patch_extract", record_error=False):
                    diff_text = await swe.git_diff(sb, md["workdir"], baseline)

            with trace_span(base_sample, "evaluation", record_error=False) as span:
                reward, applied_cleanly = await swe.run_evaluation(
                    md,
                    diff_text=diff_text,
                    timeout_sec=CONFIG.eval_timeout_sec,
                    trace=base_sample,
                )
                span.update({"reward": float(reward), "applied_cleanly": bool(applied_cleanly)})
            if evaluation:
                logger.info(
                    "[coding_agent_rl] %s: reward=%.2f applied=%s agent_exit_code=%d elapsed=%.1fs (eval-only)",
                    instance_id,
                    float(reward),
                    bool(applied_cleanly),
                    agent_exit_code,
                    time.time() - t0,
                )
                return _eval_result(
                    base_sample,
                    reward=float(reward),
                    applied_cleanly=bool(applied_cleanly),
                    agent_exit_code=agent_exit_code,
                    instance_id=instance_id,
                )

            with trace_span(base_sample, "trajectory_finalize", record_error=False):
                samples = await adapter.finish_session(
                    session_id,
                    base_sample=base_sample,
                    reward=float(reward),
                    extra_metadata={
                        "grading_solved": float(reward) == 1.0,
                        "instance_id": instance_id,
                        "agent": agent_name,
                        "agent_metrics": agent_metrics,
                    },
                )
            if not samples:
                return _abort_result(base_sample, "adapter_session_empty", instance_id)

            for s in samples:
                s.metadata = {**(s.metadata or {}), "agent_exit_code": agent_exit_code}
                if agent_metrics.get("compact_limit_reached") or agent_exit_code == EXIT_TIME_BUDGET_EXCEEDED:
                    s.status = Sample.Status.TRUNCATED
                    s.metadata.update(
                        truncated=True,
                        truncation_reason=(
                            "compact_limit" if agent_metrics.get("compact_limit_reached") else "time_budget"
                        ),
                    )
            if agent_exit_code != 0 and not agent_metrics.get("compact_limit_reached"):
                reason = "time budget exceeded" if agent_exit_code < 0 else f"CLI error (exit {agent_exit_code})"
                logger.warning(
                    "[coding_agent_rl] %s: agent_exit_code=%d (%s)",
                    instance_id,
                    agent_exit_code,
                    reason,
                )
            logger.info(
                "[coding_agent_rl] %s: reward=%.2f applied=%s agent_exit_code=%d elapsed=%.1fs segments=%d",
                instance_id,
                float(reward),
                bool(applied_cleanly),
                agent_exit_code,
                time.time() - t0,
                len(samples),
            )
            return samples

    except SandboxTerminatedError as error:
        # A terminal sandbox failure is an observed trajectory outcome. Keep
        # its sampled actions and train them with zero reward instead of
        # discarding the trajectory and retrying until execution succeeds.
        metadata = {
            "grading_solved": False,
            "instance_id": instance_id,
            "agent": agent_name,
            "agent_error": str(error),
            "agent_error_type": "sandbox_terminated",
        }
        if evaluation:
            samples = _eval_result(
                base_sample, reward=0.0, applied_cleanly=False, agent_exit_code=None, instance_id=instance_id
            )
            samples[0].metadata.update(metadata)
        else:
            with trace_span(base_sample, "trajectory_finalize", record_error=False):
                samples = await adapter.finish_session(
                    session_id, base_sample=base_sample, reward=0.0, extra_metadata=metadata
                )
            if not samples:
                return _abort_result(base_sample, "sandbox_terminated_before_generation", instance_id)
        logger.info(
            "[coding_agent_rl] %s: reward=0.00 agent_error=%s elapsed=%.1fs segments=%d",
            instance_id,
            error,
            time.time() - t0,
            len(samples),
        )
        return samples
    except asyncio.TimeoutError:
        _log_timeout_diagnostic(t0, instance_id)
        return _abort_result(base_sample, "wall_clock_timeout", instance_id)
    except Exception as e:
        logger.warning(
            "[coding_agent_rl] %s: rollout failed: %s\n%s",
            instance_id,
            e,
            traceback.format_exc(),
        )
        return _abort_result(base_sample, f"exception:{type(e).__name__}", instance_id)
    finally:
        with trace_span(base_sample, "adapter_cleanup", record_error=False):
            await adapter.drop_session(session_id, wait_timeout=30)  # cleanup only, idempotent


def _log_timeout_diagnostic(t0: float, instance_id: str) -> None:
    # Dump pending-task names when the wall-clock guard fires. Must not crash.
    try:
        elapsed = time.time() - t0
        pending = [t for t in asyncio.all_tasks() if not t.done()]
        stuck = []
        for t in pending[:5]:  # cap to avoid log spam
            coro = getattr(t, "_coro", None)
            stuck.append(getattr(coro, "__qualname__", repr(coro)))
        logger.warning(
            "[coding_agent_rl] %s: wall_clock_timeout after %.1fs "
            "(guard=%ds); %d tasks pending; sample of stuck: %s",
            instance_id,
            elapsed,
            CONFIG.rollout_guard_sec,
            len(pending),
            stuck,
        )
    except Exception:  # pragma: no cover - diag must never crash
        pass


def _session_id(sample: Sample, instance_id: str) -> str:
    if sample.session_id:
        return sample.session_id
    if sample.index is not None and sample.group_index is not None:
        return f"cagent-{instance_id}-{sample.index}-{sample.group_index}"
    return f"cagent-{instance_id}-{secrets.token_hex(8)}"


def _abort_result(sample: Sample, reason: str, instance_id: str) -> list[Sample]:
    """Mark ``sample`` aborted in place and return it in the list shape this
    fan-out generate function always yields."""
    sample.tokens = [0, 0]
    sample.response = ""
    sample.response_length = 1
    sample.loss_mask = [0]
    sample.rollout_log_probs = [0.0]
    sample.reward = 0.0
    sample.remove_sample = True
    sample.status = Sample.Status.ABORTED
    sample.metadata = {
        **(sample.metadata or {}),
        "abort_reason": reason,
        "instance_id": instance_id,
    }
    logger.warning("[coding_agent_rl] %s aborted: %s", instance_id, reason)
    return [sample]


def _eval_result(
    sample: Sample,
    *,
    reward: float,
    applied_cleanly: bool,
    agent_exit_code: int | None,
    instance_id: str,
) -> list[Sample]:
    """Eval-path placeholder: only ``reward`` matters for ``eval/sweb``."""

    sample.tokens = [0, 0]
    sample.response = ""
    sample.response_length = 1
    sample.loss_mask = [0]
    sample.rollout_log_probs = [0.0]
    sample.reward = float(reward)
    sample.remove_sample = True
    sample.status = Sample.Status.COMPLETED
    sample.metadata = {
        **(sample.metadata or {}),
        "instance_id": instance_id,
        "grading_solved": float(reward) == 1.0,
        "applied_cleanly": applied_cleanly,
        "agent_exit_code": agent_exit_code,
    }
    return [sample]
