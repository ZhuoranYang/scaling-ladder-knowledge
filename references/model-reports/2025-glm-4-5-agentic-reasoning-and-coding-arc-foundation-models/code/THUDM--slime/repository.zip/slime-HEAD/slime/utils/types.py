import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import numpy as np
import torch

from slime.data.tensor import TensorRef
from slime.utils.misc import decode_int32_meta_array

_TOP_P_TOKEN_ID_META_KEYS = ("top_p_token_ids", "top_p_kept_token_ids")
_TOP_P_TOKEN_OFFSET_META_KEYS = ("top_p_token_offsets", "top_p_kept_token_offsets")


def _extract_rollout_top_p_token_data(
    meta_info: dict[str, Any],
    *,
    expected_num_tokens: int | None = None,
) -> tuple[torch.Tensor, torch.Tensor] | None:
    token_ids = decode_int32_meta_array(meta_info, _TOP_P_TOKEN_ID_META_KEYS)
    offsets = decode_int32_meta_array(meta_info, _TOP_P_TOKEN_OFFSET_META_KEYS)
    if token_ids is None and offsets is None:
        return None
    if token_ids is None or offsets is None:
        raise ValueError("SGLang top-p token replay must include both token ids and offsets.")
    if offsets.numel() == 0 or int(offsets[0]) != 0:
        raise ValueError(f"SGLang top-p token offsets must start with 0, got {offsets[:1].tolist()}.")
    if int(offsets[-1]) != token_ids.numel():
        raise ValueError(
            "SGLang top-p token ids/offsets mismatch: "
            f"offsets[-1]={int(offsets[-1])}, len(token_ids)={token_ids.numel()}."
        )
    if expected_num_tokens is not None and offsets.numel() != expected_num_tokens + 1:
        raise ValueError(
            "SGLang top-p token offsets length must equal generated token count + 1: "
            f"len(offsets)={offsets.numel()}, generated={expected_num_tokens}."
        )
    return token_ids, offsets


def _merge_rollout_top_p_token_data(
    base_token_ids: list[int] | torch.Tensor | TensorRef | None,
    base_offsets: list[int] | torch.Tensor | TensorRef | None,
    token_ids: torch.Tensor,
    offsets: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    if isinstance(base_token_ids, TensorRef):
        base_token_ids = base_token_ids.load()
    if isinstance(base_offsets, TensorRef):
        base_offsets = base_offsets.load()
    base_token_ids = torch.as_tensor([] if base_token_ids is None else base_token_ids, dtype=torch.int32).reshape(-1)
    base_offsets = torch.as_tensor([0] if base_offsets is None else base_offsets, dtype=torch.int32).reshape(-1)
    base_offset = int(base_offsets[-1])
    return (
        torch.cat([base_token_ids, token_ids]),
        torch.cat([base_offsets, offsets[1:] + base_offset]),
    )


def _pad_rollout_top_p_offsets(
    token_ids: list[int] | torch.Tensor | TensorRef | None,
    offsets: list[int] | torch.Tensor | TensorRef | None,
    num_tokens: int,
) -> tuple[torch.Tensor | TensorRef, torch.Tensor]:
    if offsets is None or token_ids is None:
        raise ValueError("Cannot append empty top-p spans without existing token ids and offsets.")
    if num_tokens < 0:
        raise ValueError(f"num_tokens must be non-negative, got {num_tokens}.")
    # Masked tool tokens only extend offsets; keep the immutable ids shared.
    if not isinstance(token_ids, TensorRef):
        token_ids = torch.as_tensor(token_ids, dtype=torch.int32).reshape(-1)
    if isinstance(offsets, TensorRef):
        offsets = offsets.load()
    offsets = torch.as_tensor(offsets, dtype=torch.int32).reshape(-1)
    if offsets.numel() == 0:
        raise ValueError("Cannot append empty top-p spans to empty offsets.")
    if num_tokens == 0:
        return token_ids, offsets
    empty_offsets = offsets.new_full((num_tokens,), int(offsets[-1]))
    return token_ids, torch.cat([offsets, empty_offsets])


def _to_int_list(tokens) -> list[int]:
    if tokens is None:
        return []
    if torch.is_tensor(tokens):
        return [int(token) for token in tokens.detach().cpu().reshape(-1).tolist()]
    return [int(token) for token in tokens]


def _to_float_list(values) -> list[float] | None:
    if values is None:
        return None
    if torch.is_tensor(values):
        return [float(value) for value in values.detach().cpu().reshape(-1).tolist()]
    return [float(value) for value in values]


def _numel(value) -> int:
    if isinstance(value, TensorRef):
        return math.prod(value.shape)
    return int(torch.as_tensor(value).reshape(-1).numel())


@dataclass
class Sample:
    """The sample generated"""

    group_index: int | None = None
    index: int | None = None
    # Id of the rollout this sample came from. Defaults to ``None`` and the
    # downstream pipeline falls back to ``index`` (so the default rollout
    # path, where one execution = one training sample, sees rollout_id ==
    # index). Compact / subagent paths that split one rollout execution into
    # multiple training samples should set the same ``rollout_id`` on every
    # sibling, so loss aggregation averages within the rollout instead of
    # over-counting it.
    rollout_id: int | None = None
    # prompt
    prompt: str | list[dict[str, str]] = ""
    tokens: list[int] = field(default_factory=list)
    multimodal_inputs: dict[str, Any] | None = None  # raw multimodal data, e.g. images, videos, etc.
    multimodal_train_inputs: dict[str, Any] | None = None  # processed multimodal data, e.g. pixel_values, etc.
    multimodal_train_input_id: str | None = None
    apply_chat_template_kwargs: dict = field(default_factory=dict)
    # response
    response: str = ""
    response_length: int = 0
    label: str | None = None
    reward: float | dict[str, Any] | None = None
    loss_mask: list[int] | None = None
    weight_versions: list[str] = field(default_factory=list)
    rollout_log_probs: list[float] | None = None  # Log probabilities from rollout engine
    rollout_topk_token_ids: np.ndarray | torch.Tensor | list[list[int]] | TensorRef | None = None
    rollout_topk_log_probs: np.ndarray | torch.Tensor | list[list[float]] | TensorRef | None = None
    # Ragged top-p nucleus token ids replayed from rollout sampling. For response
    # token i, kept ids are rollout_top_p_token_ids[offsets[i]:offsets[i + 1]].
    rollout_top_p_token_ids: list[int] | torch.Tensor | TensorRef | None = None
    rollout_top_p_token_offsets: list[int] | torch.Tensor | TensorRef | None = None
    rollout_top_p_log_probs: np.ndarray | torch.Tensor | list[float] | TensorRef | None = None
    rollout_routed_experts: list[list[int]] | list[torch.Tensor] | torch.Tensor | TensorRef | None = (
        None  # Routed experts from rollout engine
    )
    remove_sample: bool = False
    teacher_log_probs: list[float] | None = None  # Log probabilities from teacher model for OPD

    class Status(Enum):
        PENDING = "pending"
        COMPLETED = "completed"
        TRUNCATED = "truncated"
        ABORTED = "aborted"
        # Indicates a recoverable or non-critical failure during generation (e.g., tool call failure,
        # external API error, parsing error). Unlike ABORTED, FAILED samples may still contain partial
        # valid output and can be retried or handled gracefully.
        FAILED = "failed"

    status: Status = Status.PENDING

    metadata: dict = field(default_factory=dict)
    generate_function_path: str | None = None
    custom_rm_path: str | None = None
    # metadata used during training, e.g., what loss to use for this sample.
    train_metadata: dict | None = None

    # Session ID for consistent hashing routing (used when router policy is consistent_hashing)
    session_id: str | None = None

    non_generation_time: float = 0.0  # time spent in non-generation steps

    @dataclass
    class SpecInfo:
        spec_accept_token_num: int = 0
        spec_draft_token_num: int = 0
        spec_verify_ct: int = 0
        completion_token_num: int = 0

        @property
        def spec_accept_rate(self) -> float:
            return self.spec_accept_token_num / self.spec_draft_token_num if self.spec_draft_token_num > 0 else 0.0

        @property
        def spec_accept_length(self) -> float:
            return self.completion_token_num / self.spec_verify_ct if self.spec_verify_ct > 0 else 0.0

        def add(self, meta_info: dict):
            # SGLang renamed these counters; retain the older response format
            # while preferring the strict draft counts (excluding bonus tokens).
            self.spec_accept_token_num += meta_info.get(
                "spec_num_correct_drafts", meta_info.get("spec_accept_token_num", 0)
            )
            self.spec_draft_token_num += meta_info.get(
                "spec_num_proposed_drafts", meta_info.get("spec_draft_token_num", 0)
            )
            self.spec_verify_ct += meta_info.get("spec_verify_ct", 0)
            self.completion_token_num += meta_info.get("completion_tokens", 0)

        def to_dict(self):
            return {
                "spec_accept_token_num": self.spec_accept_token_num,
                "spec_draft_token_num": self.spec_draft_token_num,
                "spec_verify_ct": self.spec_verify_ct,
                "completion_token_num": self.completion_token_num,
            }

        @staticmethod
        def from_dict(data: dict):
            info = Sample.SpecInfo()
            info.spec_accept_token_num = data.get("spec_accept_token_num", 0)
            info.spec_draft_token_num = data.get("spec_draft_token_num", 0)
            info.spec_verify_ct = data.get("spec_verify_ct", 0)
            info.completion_token_num = data.get("completion_token_num", 0)
            return info

    spec_info: SpecInfo = field(default_factory=SpecInfo)

    @dataclass
    class PrefixCacheInfo:
        cached_tokens: int = 0
        total_prompt_tokens: int = 0

        @property
        def prefix_cache_hit_rate(self) -> float:
            return self.cached_tokens / self.total_prompt_tokens if self.total_prompt_tokens > 0 else 0.0

        def add(self, meta_info: dict):
            self.cached_tokens += meta_info.get("cached_tokens", 0)
            # new_tokens = input_tokens - cached_tokens
            self.total_prompt_tokens += meta_info.get("prompt_tokens", 0)

        def to_dict(self):
            return {
                "cached_tokens": self.cached_tokens,
                "total_prompt_tokens": self.total_prompt_tokens,
            }

        @staticmethod
        def from_dict(data: dict):
            info = Sample.PrefixCacheInfo()
            info.cached_tokens = data.get("cached_tokens", 0)
            info.total_prompt_tokens = data.get("total_prompt_tokens", 0)
            return info

    prefix_cache_info: PrefixCacheInfo = field(default_factory=PrefixCacheInfo)

    def to_dict(self):
        value = self.__dict__.copy()
        value["status"] = self.status.value
        value["spec_info"] = self.spec_info.to_dict()
        value["prefix_cache_info"] = self.prefix_cache_info.to_dict()
        return value

    @staticmethod
    def from_dict(data: dict):
        data = dict(data)
        data["status"] = Sample.Status(data["status"])
        data["spec_info"] = Sample.SpecInfo.from_dict(data.get("spec_info", {}))
        data["prefix_cache_info"] = Sample.PrefixCacheInfo.from_dict(data.get("prefix_cache_info", {}))

        field_names = set(Sample.__dataclass_fields__.keys())
        init_data = {k: v for k, v in data.items() if k in field_names}
        sample = Sample(**init_data)

        for key, value in data.items():
            if key not in field_names:
                setattr(sample, key, value)

        return sample

    def get_reward_value(self, args) -> float:
        return self.reward if not args.reward_key else self.reward[args.reward_key]

    @property
    def effective_response_length(self):
        return sum(self.loss_mask) if self.loss_mask is not None else self.response_length

    def append_response_tokens(
        self,
        args=None,
        *,
        tokens=None,
        log_probs=None,
        trainable: bool = True,
        meta_info: dict | None = None,
        text: str | None = None,
        update_terminal_info: bool = True,
    ):
        """
        Append response-side tokens and keep training metadata aligned.

        Model-generated tokens should pass ``trainable=True`` plus SGLang
        ``meta_info`` and log probabilities. Tool/environment tokens should pass
        ``trainable=False``; they receive loss-mask zeros and empty top-p spans
        when top-p replay is active.
        """
        tokens = _to_int_list(tokens)
        log_probs = _to_float_list(log_probs)
        if log_probs is not None and len(log_probs) != len(tokens):
            raise ValueError(f"log_probs length {len(log_probs)} != tokens length {len(tokens)}")
        if tokens and trainable and log_probs is None:
            raise ValueError("trainable response tokens require rollout log probabilities.")
        if tokens and not trainable:
            if log_probs is not None:
                raise ValueError("non-trainable response tokens should not pass rollout log probabilities.")
            log_probs = [0.0] * len(tokens)

        previous_response_length = self.response_length
        if tokens and getattr(args, "use_score_centering", False) and getattr(args, "rollout_top_p", 1.0) == 1.0:
            from .score_centering import extract_sampler_topk

            k = args.score_centering_top_k
            for key in ("rollout_topk_token_ids", "rollout_topk_log_probs"):
                value = getattr(self, key)
                if isinstance(value, TensorRef):
                    setattr(self, key, value.load().numpy())
            if trainable:
                ids, logps = extract_sampler_topk(meta_info or {}, len(tokens), k)
            else:
                # Dummy distributions for masked tool/environment tokens. Distinct
                # ids and finite logprobs keep the loss finite before masking.
                ids = np.broadcast_to(np.arange(k, dtype=np.int32), (len(tokens), k)).copy()
                logps = np.full((len(tokens), k), -math.log(k), dtype=np.float32)
            if self.rollout_topk_token_ids is None:
                if previous_response_length and any(self.loss_mask or [1] * previous_response_length):
                    raise ValueError("Existing trainable response tokens have no sampler top-k data.")
                self.rollout_topk_token_ids = np.broadcast_to(
                    np.arange(k, dtype=np.int32), (previous_response_length, k)
                ).copy()
                self.rollout_topk_log_probs = np.full((previous_response_length, k), -math.log(k), dtype=np.float32)
            self.rollout_topk_token_ids = (
                np.concatenate((np.asarray(self.rollout_topk_token_ids, dtype=np.int32), ids))
                if previous_response_length
                else ids
            )
            self.rollout_topk_log_probs = (
                np.concatenate((np.asarray(self.rollout_topk_log_probs, dtype=np.float32), logps))
                if previous_response_length
                else logps
            )
        if tokens and getattr(args, "use_score_centering", False) and getattr(args, "rollout_top_p", 1.0) < 1:
            from .score_centering import extract_sampler_top_p, validate_sampler_top_p

            if self.rollout_top_p_token_ids is None:
                if previous_response_length and any(self.loss_mask or [1] * previous_response_length):
                    raise ValueError("Existing trainable response tokens have no sampler top-p data.")
                self.rollout_top_p_token_ids = torch.empty(0, dtype=torch.int32)
                self.rollout_top_p_token_offsets = torch.zeros(previous_response_length + 1, dtype=torch.int32)
                self.rollout_top_p_log_probs = np.empty(0, dtype=np.float32)
            if trainable:
                ids, offsets, logps = extract_sampler_top_p(meta_info or {}, len(tokens))
                validate_sampler_top_p(ids, offsets, logps, len(tokens), tokens=tokens, sampled_logps=log_probs)
                self.rollout_top_p_token_ids, self.rollout_top_p_token_offsets = _merge_rollout_top_p_token_data(
                    self.rollout_top_p_token_ids,
                    self.rollout_top_p_token_offsets,
                    torch.as_tensor(ids),
                    torch.as_tensor(offsets),
                )
                previous_logps = self.rollout_top_p_log_probs
                if isinstance(previous_logps, TensorRef):
                    previous_logps = previous_logps.load()
                self.rollout_top_p_log_probs = np.concatenate((np.asarray(previous_logps), logps))
                # Already appended the validated replay data above.
                meta_info = {
                    key: value
                    for key, value in (meta_info or {}).items()
                    if key not in (*_TOP_P_TOKEN_ID_META_KEYS, *_TOP_P_TOKEN_OFFSET_META_KEYS)
                }
        if text is not None:
            self.response += text
        if tokens:
            self.tokens += tokens
            self.response_length += len(tokens)
            if self.loss_mask is None:
                self.loss_mask = [1] * previous_response_length
            self.loss_mask += [1 if trainable else 0] * len(tokens)

        if log_probs is not None:
            if self.rollout_log_probs is None:
                if trainable and previous_response_length:
                    raise ValueError(
                        "Cannot append trainable rollout log probabilities to a sample with existing response "
                        "tokens but no existing rollout_log_probs."
                    )
                self.rollout_log_probs = [0.0] * previous_response_length
            self.rollout_log_probs += log_probs

        should_pad_top_p = bool(tokens and not trainable)
        if meta_info is not None or should_pad_top_p:
            self._apply_meta_info(
                args,
                meta_info or {},
                new_token_count=len(tokens),
                pad_missing_top_p=should_pad_top_p,
                update_terminal_info=update_terminal_info,
            )

        self._validate_response_metadata_lengths()

    def _apply_meta_info(
        self,
        args,
        meta_info: dict,
        *,
        new_token_count: int = 0,
        pad_missing_top_p: bool = False,
        update_terminal_info: bool = True,
    ) -> None:
        applied_top_p_data = False
        if new_token_count:
            top_p_data = _extract_rollout_top_p_token_data(meta_info, expected_num_tokens=new_token_count)
            if top_p_data is not None:
                applied_top_p_data = True
                base_token_ids, base_offsets = self.rollout_top_p_token_ids, self.rollout_top_p_token_offsets
                if base_token_ids is None and base_offsets is None:
                    self.rollout_top_p_token_ids, self.rollout_top_p_token_offsets = top_p_data
                else:
                    self.rollout_top_p_token_ids, self.rollout_top_p_token_offsets = _merge_rollout_top_p_token_data(
                        base_token_ids,
                        base_offsets,
                        *top_p_data,
                    )

        if (
            pad_missing_top_p
            and new_token_count
            and self.rollout_top_p_token_offsets is not None
            and not applied_top_p_data
        ):
            self.rollout_top_p_token_ids, self.rollout_top_p_token_offsets = _pad_rollout_top_p_offsets(
                self.rollout_top_p_token_ids,
                self.rollout_top_p_token_offsets,
                new_token_count,
            )

        # Community SGLang returns routed expert ids as base64-encoded int32.
        routed_experts = decode_int32_meta_array(meta_info, "routed_experts")
        if routed_experts is not None:
            if args is None:
                raise ValueError("args is required to decode routed experts metadata.")
            routed_experts_start_len = int(meta_info.get("routed_experts_start_len", 0) or 0)
            if routed_experts_start_len < 0:
                raise ValueError(
                    f"SGLang routed_experts_start_len must be non-negative, got {routed_experts_start_len}."
                )
            expected_rows = max(0, len(self.tokens) - 1 - routed_experts_start_len)
            expected_numel = expected_rows * args.num_layers * args.moe_router_topk
            if routed_experts.numel() != expected_numel:
                raise ValueError(
                    "SGLang routed_experts element count does not match sample tokens: "
                    f"got={routed_experts.numel()}, expected={expected_numel} "
                    f"(tokens={len(self.tokens)}, routed_experts_start_len={routed_experts_start_len}, "
                    f"num_layers={args.num_layers}, "
                    f"moe_router_topk={args.moe_router_topk})."
                )
            routed_experts = routed_experts.reshape(
                expected_rows,
                args.num_layers,
                args.moe_router_topk,
            )
            if routed_experts_start_len == 0:
                self.rollout_routed_experts = routed_experts
            else:
                existing_len = self.get_rollout_routed_experts_length()
                if existing_len == 0:
                    raise ValueError(
                        "Cannot append partial routed experts without existing routed experts "
                        f"(routed_experts_start_len={routed_experts_start_len})."
                    )
                if existing_len < routed_experts_start_len:
                    raise ValueError(
                        "Existing routed experts shorter than routed_experts_start_len: "
                        f"existing_rows={existing_len}, routed_experts_start_len={routed_experts_start_len}."
                    )
                if existing_len == routed_experts_start_len:
                    self._append_rollout_routed_experts_chunk(routed_experts)
                else:
                    existing = self.materialize_rollout_routed_experts(replace=False)
                    self.rollout_routed_experts = torch.cat(
                        [existing[:routed_experts_start_len], routed_experts],
                        dim=0,
                    )

        if not update_terminal_info or "finish_reason" not in meta_info:
            return

        if getattr(args, "sglang_speculative_algorithm", False):
            # cannot directly use spec info from sglang because of partial rollout.
            self.spec_info.add(meta_info=meta_info)

        # Collect prefix cache statistics
        self.prefix_cache_info.add(meta_info=meta_info)

        if new_token_count > 0 and "weight_version" in meta_info:
            self.weight_versions.append(meta_info["weight_version"])

        match meta_info["finish_reason"]["type"]:
            case "length":
                self.status = Sample.Status.TRUNCATED
            case "abort":
                self.status = Sample.Status.ABORTED
            case "stop":
                self.status = Sample.Status.COMPLETED

    def _append_rollout_routed_experts_chunk(self, routed_experts: torch.Tensor) -> None:
        existing = self.rollout_routed_experts
        if existing is None:
            self.rollout_routed_experts = routed_experts
        elif isinstance(existing, TensorRef):
            self.rollout_routed_experts = [existing.load(), routed_experts]
        elif isinstance(existing, list) and all(torch.is_tensor(item) for item in existing):
            existing.append(routed_experts)
        else:
            self.rollout_routed_experts = [torch.as_tensor(existing, dtype=routed_experts.dtype), routed_experts]

    def get_rollout_routed_experts_length(self) -> int:
        routed_experts = self.rollout_routed_experts
        if routed_experts is None:
            return 0
        if isinstance(routed_experts, TensorRef):
            return int(routed_experts.shape[0])
        if torch.is_tensor(routed_experts):
            return int(routed_experts.shape[0])
        if isinstance(routed_experts, list):
            if not routed_experts:
                return 0
            if all(torch.is_tensor(item) for item in routed_experts):
                return sum(int(item.shape[0]) for item in routed_experts)
            return int(torch.as_tensor(routed_experts).shape[0])
        return int(torch.as_tensor(routed_experts).shape[0])

    def materialize_rollout_routed_experts(self, *, replace: bool = True) -> torch.Tensor | None:
        routed_experts = self.rollout_routed_experts
        if routed_experts is None:
            return None
        if isinstance(routed_experts, TensorRef):
            tensor = routed_experts.load()
        elif torch.is_tensor(routed_experts):
            tensor = routed_experts.reshape(*routed_experts.shape)
        elif isinstance(routed_experts, list) and all(torch.is_tensor(item) for item in routed_experts):
            tensor = torch.cat(routed_experts, dim=0) if len(routed_experts) > 1 else routed_experts[0]
        else:
            tensor = torch.as_tensor(routed_experts, dtype=torch.int32)
        tensor = tensor.detach().cpu().contiguous()
        if replace:
            self.rollout_routed_experts = tensor
        return tensor

    def _validate_response_metadata_lengths(self):
        for key in ("rollout_topk_token_ids", "rollout_topk_log_probs"):
            value = getattr(self, key)
            if value is not None and len(value) != self.response_length:
                raise ValueError(f"{key} length {len(value)} != response_length {self.response_length}")
        if self.loss_mask is not None and len(self.loss_mask) != self.response_length:
            raise ValueError(f"loss_mask length {len(self.loss_mask)} != response_length {self.response_length}")

        if self.rollout_log_probs is not None and len(self.rollout_log_probs) != self.response_length:
            raise ValueError(
                f"rollout_log_probs length {len(self.rollout_log_probs)} != response_length {self.response_length}"
            )

        if self.rollout_top_p_token_ids is None and self.rollout_top_p_token_offsets is None:
            return
        if self.rollout_top_p_token_ids is None or self.rollout_top_p_token_offsets is None:
            raise ValueError("rollout top-p replay must include both token ids and offsets.")

        offsets = self.rollout_top_p_token_offsets
        if isinstance(offsets, TensorRef):
            offsets = offsets.load()
        offsets = torch.as_tensor(offsets, dtype=torch.int32).reshape(-1)
        if offsets.numel() != self.response_length + 1:
            raise ValueError(
                "rollout_top_p_token_offsets length must equal response_length + 1: "
                f"len(offsets)={offsets.numel()}, response_length={self.response_length}."
            )
        token_id_count = _numel(self.rollout_top_p_token_ids)
        if self.rollout_top_p_log_probs is not None and len(self.rollout_top_p_log_probs) != token_id_count:
            raise ValueError("Top-p logprobs must align with the replay token ids.")
        if int(offsets[-1]) != token_id_count:
            raise ValueError(
                "rollout top-p token ids/offsets mismatch: "
                f"offsets[-1]={int(offsets[-1])}, len(token_ids)={token_id_count}."
            )


@dataclass(frozen=True)
class ParamInfo:
    name: str
    dtype: torch.dtype
    shape: torch.Size
    attrs: dict
    size: int
    src_rank: int


# A dict-based batch produced along the rollout -> training path
# In Megatron backend, several fields are converted to torch.Tensor lists on GPU
# before being consumed by data iterators (see megatron_utils.actor._get_rollout_data).
RolloutBatch = dict[str, list[torch.Tensor] | list[int] | list[float] | list[str]]


@dataclass
class MultimodalType:
    name: str  # Type identifier used in message content (e.g., "image")
    placeholder: str  # Placeholder token in conversation messages (e.g., "<image>")


class MultimodalTypes:
    IMAGE = MultimodalType(name="image", placeholder="<image>")
    VIDEO = MultimodalType(name="video", placeholder="<video>")
    AUDIO = MultimodalType(name="audio", placeholder="<audio>")

    @classmethod
    def all(cls) -> list[MultimodalType]:
        return [cls.IMAGE, cls.VIDEO, cls.AUDIO]

    @classmethod
    def get(cls, name: str) -> MultimodalType | None:
        return next((m for m in cls.all() if m.name == name), None)
