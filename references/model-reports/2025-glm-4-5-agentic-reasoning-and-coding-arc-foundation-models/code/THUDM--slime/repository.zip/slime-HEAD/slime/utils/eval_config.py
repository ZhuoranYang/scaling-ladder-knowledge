from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field, fields
from typing import Any

_MISSING = object()

# TODO: This is ugly, temporarily leave this. We should unify all the config name for dataset, default, and args. (advice from Tom.)
DATASET_RUNTIME_SPECS: dict[str, dict[str, tuple[str, ...]]] = {
    "n_samples_per_eval_prompt": {
        "dataset_keys": ("n_samples_per_eval_prompt",),
        "default_keys": ("n_samples_per_eval_prompt",),
        "arg_attrs": ("n_samples_per_eval_prompt", "n_samples_per_prompt"),
    },
    "temperature": {
        "dataset_keys": ("temperature",),
        "default_keys": ("temperature",),
        "arg_attrs": ("eval_temperature", "rollout_temperature"),
    },
    "top_p": {
        "dataset_keys": ("top_p",),
        "default_keys": ("top_p",),
        "arg_attrs": ("eval_top_p", "rollout_top_p"),
    },
    "top_k": {
        "dataset_keys": ("top_k",),
        "default_keys": ("top_k",),
        "arg_attrs": ("eval_top_k", "rollout_top_k"),
    },
    "max_response_len": {
        "dataset_keys": ("max_response_len",),
        "default_keys": ("max_response_len",),
        "arg_attrs": ("eval_max_response_len", "rollout_max_response_len"),
    },
    "min_eval_samples": {
        "dataset_keys": ("min_eval_samples",),
        "default_keys": ("min_eval_samples",),
        "arg_attrs": (),
    },
    "stop": {
        "dataset_keys": ("stop",),
        "default_keys": ("stop",),
        "arg_attrs": ("rollout_stop",),
    },
    "stop_token_ids": {
        "dataset_keys": ("stop_token_ids",),
        "default_keys": ("stop_token_ids",),
        "arg_attrs": ("rollout_stop_token_ids",),
    },
    "min_new_tokens": {
        "dataset_keys": ("min_new_tokens",),
        "default_keys": ("min_new_tokens",),
        "arg_attrs": ("eval_min_new_tokens",),
    },
}

DATASET_SAMPLE_SPECS: dict[str, dict[str, tuple[str, ...]]] = {
    "input_key": {
        "dataset_keys": ("input_key",),
        "default_keys": ("input_key",),
        "arg_attrs": ("eval_input_key", "input_key"),
    },
    "label_key": {
        "dataset_keys": ("label_key",),
        "default_keys": ("label_key",),
        "arg_attrs": ("eval_label_key", "label_key"),
    },
    "tool_key": {
        "dataset_keys": ("tool_key",),
        "default_keys": ("tool_key",),
        "arg_attrs": ("eval_tool_key", "tool_key"),
    },
    "metadata_key": {
        "dataset_keys": ("metadata_key",),
        "default_keys": ("metadata_key",),
        "arg_attrs": ("metadata_key",),
    },
    "multimodal_keys": {
        "dataset_keys": ("multimodal_keys",),
        "default_keys": ("multimodal_keys",),
        "arg_attrs": ("multimodal_keys",),
    },
    "apply_chat_template": {
        "dataset_keys": ("apply_chat_template",),
        "default_keys": ("apply_chat_template",),
        "arg_attrs": ("apply_chat_template",),
    },
    "apply_chat_template_kwargs": {
        "dataset_keys": ("apply_chat_template_kwargs",),
        "default_keys": ("apply_chat_template_kwargs",),
        "arg_attrs": ("apply_chat_template_kwargs",),
    },
    "custom_rm_path": {
        "dataset_keys": ("custom_rm_path",),
        "default_keys": ("custom_rm_path",),
        "arg_attrs": ("eval_custom_rm_path", "custom_rm_path"),
    },
}


def _first_not_missing(*values: Any) -> Any:
    for value in values:
        if value is not _MISSING:
            return value
    return _MISSING


def _pick_from_mapping(data: dict[str, Any], key_names: tuple[str, ...] | None) -> Any:
    if key_names is None:
        return _MISSING
    for key_name in key_names:
        if key_name in data:
            return data[key_name]
    return _MISSING


def pick_from_args(args: Any, attrs: tuple[str, ...]) -> Any:
    for attr in attrs:
        value = getattr(args, attr, None)
        if value is not None:
            return value
    return None


def _ensure_metadata_overrides(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise TypeError("metadata_overrides must be a mapping.")
    return value


@dataclass
class EvalDatasetConfig:
    """Configuration for a single evaluation dataset."""

    name: str
    path: str
    rm_type: str | None = None
    custom_rm_path: str | None = None

    # Dataset-specific overrides
    input_key: str | None = None
    label_key: str | None = None
    tool_key: str | None = None
    metadata_key: str | None = None
    multimodal_keys: dict[str, str] | None = None
    apply_chat_template: bool | None = None
    apply_chat_template_kwargs: dict[str, Any] | None = None

    n_samples_per_eval_prompt: int | None = None

    temperature: float | None = None
    top_p: float | None = None
    top_k: int | None = None
    max_response_len: int | None = None
    stop: list[str] | None = None
    stop_token_ids: list[int] | None = None
    min_new_tokens: int | None = None
    repetition_penalty: float | None = None
    skip_special_tokens: bool | None = None
    no_stop_trim: bool | None = None

    # per-dataset custom generate function (e.g., for tool calling)
    custom_generate_function_path: str | None = None

    # app_service URL for server mode generation (e.g., "http://localhost:18080")
    # If set, eval will use ServerGenerationProxy to generate through AppServer
    app_service: str | None = None

    eval_task_timeout: int | None = None
    min_eval_samples: int | None = None

    # Early stop: terminate eval when remaining samples < eval_early_stop_remaining
    # AND no new result has been received for eval_early_stop_idle_timeout seconds.
    # Both must be set (non-None) for early stop to take effect.
    eval_early_stop_remaining: int | None = None
    eval_early_stop_idle_timeout: float | None = None

    # Inline source config (mirrors the per-source fields in the train data JSON).
    # When any of these is set, eval will treat this dataset as its own "source"
    # and build a Dataset-level source_config keyed by `name`. No need to set
    # --source-key or have a `source` field in the eval jsonl.
    message_processor: dict[str, Any] | None = None
    reward_model: dict[str, Any] | None = None
    remote_environment: dict[str, Any] | None = None

    metadata_overrides: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.metadata_overrides = _ensure_metadata_overrides(self.metadata_overrides)
        if self.min_eval_samples is not None and self.min_eval_samples <= 0:
            raise ValueError("min_eval_samples must be positive when set.")

    @property
    def cache_key(self) -> tuple[Any, ...]:
        """Return a tuple uniquely identifying dataset config for caching."""
        return (
            self.name,
            self.path,
            self.input_key,
            self.label_key,
            self.tool_key,
            self.metadata_key,
        )

    def inject_metadata(self, sample_metadata: Any) -> dict[str, Any]:
        """Return updated metadata merging overrides."""
        if not isinstance(sample_metadata, dict):
            metadata = {}
        else:
            metadata = dict(sample_metadata)

        if self.rm_type is not None:
            metadata["rm_type"] = self.rm_type

        for key, value in self.metadata_overrides.items():
            metadata[key] = value

        return metadata


def ensure_dataset_list(config: Any) -> list[dict[str, Any]]:
    """
    Normalize OmegaConf containers into a list of dicts.
    Accepts either a list or dictionary keyed by dataset name.
    """
    if config is None:
        return []

    if isinstance(config, dict):
        datasets = []
        for name, cfg in config.items():
            dataset = dict(cfg or {})
            dataset.setdefault("name", name)
            datasets.append(dataset)
        return datasets

    if isinstance(config, (list, tuple)):
        datasets = []
        for item in config:
            dataset = dict(item or {})
            if "name" not in dataset:
                raise ValueError("Each evaluation dataset entry must include a `name` field.")
            datasets.append(dataset)
        return datasets

    raise TypeError("eval.datasets must be either a list or a mapping.")


def _apply_dataset_field_overrides(
    args: Any, dataset_cfg: dict[str, Any], defaults: dict[str, Any], spec_names: dict[str, Any]
) -> None:
    for field_name, spec in spec_names.items():
        dataset_value = _pick_from_mapping(dataset_cfg, spec["dataset_keys"])
        default_value = _pick_from_mapping(defaults, spec["default_keys"])
        resolved_value = _first_not_missing(dataset_value, default_value)
        if resolved_value is not _MISSING:
            dataset_cfg[field_name] = resolved_value
            continue
        dataset_cfg[field_name] = pick_from_args(args, spec["arg_attrs"])


def build_eval_dataset_configs(
    args: Any,
    raw_config: Iterable[dict[str, Any]],
    defaults: dict[str, Any],
) -> list[EvalDatasetConfig]:
    defaults = defaults or {}
    combined_specs = {**DATASET_RUNTIME_SPECS, **DATASET_SAMPLE_SPECS}

    # A key that is neither a spec name nor an EvalDatasetConfig field would be
    # silently ignored below — the same typo inside a dataset entry raises from
    # the dataclass constructor, so hold `defaults` to the same standard.
    valid_default_keys = {f.name for f in fields(EvalDatasetConfig)} | {
        key for spec in combined_specs.values() for key in spec["default_keys"]
    }
    unknown_keys = set(defaults) - valid_default_keys
    if unknown_keys:
        raise ValueError(
            f"Unknown key(s) in eval.defaults: {sorted(unknown_keys)}. " f"Valid keys: {sorted(valid_default_keys)}."
        )

    datasets: list[EvalDatasetConfig] = []
    for cfg in raw_config:
        cfg_dict = dict(cfg or {})
        _apply_dataset_field_overrides(args, cfg_dict, defaults, combined_specs)
        # Fields without a spec entry (rm_type, repetition_penalty, app_service,
        # ...) still honor eval.defaults: dataset entry wins, default fills in.
        for key, value in defaults.items():
            if key not in combined_specs:
                cfg_dict.setdefault(key, value)
        dataset = EvalDatasetConfig(**cfg_dict)
        datasets.append(dataset)
    return datasets
