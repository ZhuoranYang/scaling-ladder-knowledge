import abc
import copy
import logging
from pathlib import Path

import torch

from slime.rollout.base_types import iter_samples
from slime.utils.data import Dataset
from slime.utils.misc import load_function
from slime.utils.processing_utils import load_processor, load_tokenizer
from slime.utils.types import Sample

logger = logging.getLogger(__name__)


class DataSource(abc.ABC):
    def register_consumer(self, name, consumer):
        if name in self.consumers:
            raise ValueError(f"Consumer {name!r} already registered")
        restored = getattr(self, "_restored_consumers", {})
        if name in restored:
            consumer.load_state_dict(restored.pop(name))
        self.consumers[name] = consumer

    def close(self):
        for consumer in getattr(self, "consumers", {}).values():
            consumer.close()

    @abc.abstractmethod
    def get_samples(self, num_samples: int) -> list[list[Sample]]:
        """
        Return num_samples samples
        """

    @abc.abstractmethod
    def add_samples(self, samples: list[list[Sample]]):
        """
        Add samples to the data source
        """

    @abc.abstractmethod
    def save(self, rollout_id):
        """
        Save the state of the data source
        """

    @abc.abstractmethod
    def load(self, rollout_id=None):
        """
        Load the state of the data source
        """

    @abc.abstractmethod
    def __len__(self) -> int:
        """
        Length of the data source. May change when samples are added/fetched.
        """


# TODO may further refactor data-loading part later
class RolloutDataSource(DataSource):
    def __init__(self, args):
        self.args = args
        self.consumers = {}
        self._restored_consumers = {}

        self.epoch_id = 0
        self.sample_group_index = 0
        self.sample_index = 0
        self.sample_offset = 0
        # TODO remove this
        self.metadata = {}

        if args.prompt_data is not None:
            tokenizer = load_tokenizer(args.hf_checkpoint, trust_remote_code=True)
            processor = load_processor(args.hf_checkpoint, trust_remote_code=True)

            # TODO move (during the refactor)
            if (d := args.dump_details) is not None:
                tokenizer.save_pretrained(Path(d) / "tokenizer")
                if processor:
                    processor.save_pretrained(Path(d) / "processor")

            self.dataset = Dataset(
                args.prompt_data,
                tokenizer=tokenizer,
                processor=processor,
                max_length=args.rollout_max_prompt_len,
                prompt_key=args.input_key,
                multimodal_keys=args.multimodal_keys,
                label_key=args.label_key,
                metadata_key=args.metadata_key,
                tool_key=args.tool_key,
                apply_chat_template=args.apply_chat_template,
                apply_chat_template_kwargs=args.apply_chat_template_kwargs,
                seed=args.rollout_seed,
            )
            if self.args.rollout_shuffle:
                self.dataset.shuffle(self.epoch_id)
        else:
            self.dataset = None

    def get_samples(self, num_samples):
        # TODO further improve code
        if self.dataset is not None:
            if self.sample_offset + num_samples <= len(self.dataset):
                prompt_samples = self.dataset.samples[self.sample_offset : self.sample_offset + num_samples]
                self.sample_offset += num_samples
            else:
                prompt_samples = self.dataset.samples[self.sample_offset :]
                num_samples -= len(prompt_samples)
                self.epoch_id += 1
                if self.args.rollout_shuffle:
                    self.dataset.shuffle(self.epoch_id)
                prompt_samples += self.dataset.samples[:num_samples]
                self.sample_offset = num_samples
        else:
            prompt_samples = [Sample() for _ in range(num_samples)]

        samples = []
        for prompt_sample in prompt_samples:
            group = []
            for _ in range(self.args.n_samples_per_prompt):
                sample = copy.deepcopy(prompt_sample)
                sample.group_index = self.sample_group_index
                sample.index = self.sample_index
                self.sample_index += 1
                group.append(sample)
            self.sample_group_index += 1
            samples.append(group)
        return samples

    def add_samples(self, samples: list[list[Sample]]):
        raise RuntimeError(f"Cannot add samples to {self.__class__.__name__}. This is a read-only data source.")

    def state_dict(self):
        # The cursor includes prompts already borrowed by background workers.
        # Drain admission and snapshot their ready queues with that cursor so a
        # checkpoint cannot skip prefetched samples when the source is restored.
        paused = []
        try:
            for consumer in self.consumers.values():
                paused.append((consumer, consumer.pause()))
            state = {
                name: copy.deepcopy(getattr(self, name))
                for name in ("sample_offset", "epoch_id", "sample_group_index", "sample_index", "metadata")
            }
            if hasattr(self, "buffer"):
                state["buffer"] = copy.deepcopy(self.buffer)
            state["consumers"] = {
                **self._restored_consumers,
                **{name: consumer.state_dict() for name, consumer in self.consumers.items()},
            }
            return state
        finally:
            for consumer, was_paused in paused:
                if not was_paused:
                    consumer.resume()

    def load_state_dict(self, state):
        for name, value in state.items():
            if name == "consumers":
                self._restored_consumers = value
            else:
                setattr(self, name, value)
        if self.args.rollout_shuffle and self.dataset is not None:
            # Rebuild the saved epoch's ordering before reading from its cursor.
            self.dataset.shuffle(self.epoch_id)

    def save(self, rollout_id):
        path = Path(self.args.save) / "rollout" / f"global_dataset_state_dict_{rollout_id}.pt"
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(self.state_dict(), path)

    def load(self, rollout_id=None):
        if self.args.load is None:
            return
        path = Path(self.args.load) / "rollout" / f"global_dataset_state_dict_{rollout_id}.pt"
        if not path.exists():
            logger.info("Checkpoint %s does not exist.", path)
            return
        self.load_state_dict(torch.load(path, weights_only=False))

    def __len__(self) -> int:
        if self.dataset is None:
            return 0
        return len(self.dataset)


class RolloutDataSourceWithBuffer(RolloutDataSource):
    def __init__(self, args):
        super().__init__(args)
        self.buffer = []
        if self.args.buffer_filter_path is None:
            self.buffer_filter = pop_oldest if getattr(args, "buffer_sort_by_staleness", False) else pop_first
        else:
            self.buffer_filter = load_function(self.args.buffer_filter_path)

    def get_samples(self, num_samples: int) -> list[list[Sample]]:
        """
        Return num_samples samples
        """

        samples = self._get_samples_from_buffer(num_samples)
        num_samples -= len(samples)

        if num_samples == 0:
            return samples

        samples += super().get_samples(num_samples=num_samples)
        return samples

    def _get_samples_from_buffer(self, num_samples: int) -> list[list[Sample]]:
        if len(self.buffer) == 0 or num_samples == 0:
            return []

        samples = self.buffer_filter(self.args, None, self.buffer, num_samples)
        return samples

    def add_samples(self, samples: list[list[Sample]]):
        """
        Add a sample group to buffer.
        """
        if not samples:
            return
        assert isinstance(samples, list), f"samples must be a list, got {type(samples)}"
        assert isinstance(samples[0], list), f"the elements of samples must be list, got {type(samples[0])}"
        for i in range(0, len(samples)):
            assert (
                len(samples[i]) == self.args.n_samples_per_prompt
            ), f"the length of the elements of samples must be equal to n_samples_per_prompt, got {len(samples[i])} != {self.args.n_samples_per_prompt}"
            group = samples[i]  # type: ignore
            self.buffer.append(group)

    # TODO remove
    def update_metadata(self, metadata: dict):
        self.metadata.update(metadata)

    # TODO remove
    def get_metadata(self):
        return self.metadata

    def get_buffer_length(self):
        return len(self.buffer)


def pop_oldest(args, rollout_id, buffer: list[list[Sample]], num_samples: int) -> list[list[Sample]]:
    """Resume groups with the oldest generated tokens first; preserve ties."""

    def oldest_version(group):
        versions = (str(v) for sample in iter_samples(group) for v in (sample.weight_versions or []))
        return min(
            (int(v) for v in versions if v.isascii() and v.removeprefix("-").isdigit()),
            default=float("inf"),
        )

    buffer.sort(key=oldest_version)
    return pop_first(args, rollout_id, buffer, num_samples)


def pop_first(args, rollout_id, buffer: list[list[Sample]], num_samples: int) -> list[list[Sample]]:
    num_to_pop = min(len(buffer), num_samples)
    samples = buffer[:num_to_pop]
    del buffer[:num_to_pop]
    return samples
