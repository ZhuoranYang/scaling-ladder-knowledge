import copy
import logging
import socket
from dataclasses import dataclass

import ray
from ray.util.placement_group import placement_group
from ray.util.scheduling_strategies import PlacementGroupSchedulingStrategy

from slime.utils.cleanup import Cleanup

from .actor_group import RayTrainGroup
from .utils import add_default_ray_env_vars

logger = logging.getLogger(__name__)


@ray.remote(num_gpus=1)
class InfoActor:
    def get_ip_and_gpu_id(self):
        return ray.util.get_node_ip_address(), ray.get_gpu_ids()[0]


def sort_key(x):
    index, node_identifier, gpu_id = x
    # Sort by node IP number and then by GPU ID
    try:
        # try to parse it as an IP address.
        ip_address = node_identifier
        node_ip_parts = list(map(int, ip_address.split(".")))
    except ValueError:
        # Try to resolve the hostname to an IP address.
        try:
            ip_address = socket.gethostbyname(node_identifier)
            node_ip_parts = list(map(int, ip_address.split(".")))
        except (socket.gaierror, TypeError):
            # Instead, we convert each character of the original identifier string
            # to its ASCII value. This provides a stable and consistent numerical
            # representation that allows for sorting.
            node_ip_parts = [ord(c) for c in node_identifier]

    return (node_ip_parts, int(gpu_id))


def _create_placement_group(num_gpus):
    """Create a placement group with the specified number of GPUs."""
    if num_gpus == 0:
        return None, [], []

    bundles = [{"GPU": 1, "CPU": 1} for _ in range(num_gpus)]
    pg = placement_group(bundles, strategy="PACK")
    num_bundles = len(bundles)

    # Wait for the placement group to be scheduled. Poll rather than a bare
    # ray.get(pg.ready()) so the wait is observable: when it can't be placed yet
    # (a node's GPUs haven't registered with the GCS, or an autoscaler is still
    # bringing nodes up) log the GPU counts periodically instead of hanging with no
    # output. The wait stays unbounded, so autoscaling clusters — where a pending
    # placement group is what drives scale-up — are unaffected.
    ready_ref = pg.ready()
    elapsed = 0
    log_interval = 30
    while not ray.wait([ready_ref], timeout=log_interval)[0]:
        elapsed += log_interval
        total = ray.cluster_resources().get("GPU", 0)
        available = ray.available_resources().get("GPU", 0)
        logger.info(
            f"Waiting for placement group of {num_gpus} GPUs (elapsed {elapsed}s): "
            f"{total:g} GPUs registered with Ray, {available:g} available."
        )

    # use info actor to get the GPU id
    info_actors = []
    for i in range(num_bundles):
        info_actors.append(
            InfoActor.options(
                scheduling_strategy=PlacementGroupSchedulingStrategy(
                    placement_group=pg,
                    placement_group_bundle_index=i,
                ),
            ).remote()
        )
    gpu_ids = ray.get([actor.get_ip_and_gpu_id.remote() for actor in info_actors])
    for actor in info_actors:
        ray.kill(actor)

    bundle_infos = [(i, gpu_ids[i][0], gpu_ids[i][1]) for i in range(num_bundles)]
    sorted_bundle_infos = sorted(bundle_infos, key=sort_key)
    pg_reordered_bundle_indices = [info[0] for info in sorted_bundle_infos]
    # Map from logical index -> physical GPU ID
    pg_reordered_gpu_ids = [gpu_ids[info[0]][1] for info in sorted_bundle_infos]

    for i in range(num_bundles):
        actual_bundle_index = pg_reordered_bundle_indices[i]
        logger.info(
            f"  bundle {i:4}, actual_bundle_index: {actual_bundle_index:4}, "
            f"node: {gpu_ids[actual_bundle_index][0]}, gpu: {gpu_ids[actual_bundle_index][1]}"
        )

    return pg, pg_reordered_bundle_indices, pg_reordered_gpu_ids


def _get_placement_group_layout(args) -> tuple[int, int]:
    actor_num_gpus = args.actor_num_nodes * args.actor_num_gpus_per_node

    if args.debug_train_only:
        return actor_num_gpus, 0

    if args.rollout_external:
        if args.debug_rollout_only:
            return actor_num_gpus, 0
        return actor_num_gpus, actor_num_gpus

    if args.debug_rollout_only:
        return args.rollout_num_gpus, 0

    if args.colocate:
        return max(actor_num_gpus, args.rollout_num_gpus), 0

    return actor_num_gpus + args.rollout_num_gpus, actor_num_gpus


def create_placement_groups(args):
    """Create placement groups for actor, critic, and rollout engines."""

    if not args.colocate and not args.rollout_external and not args.debug_train_only and not args.debug_rollout_only:
        # Separate allocations let a restarted trainer resize without moving
        # the serving engines that still hold rollout state.
        actor_pg = _create_placement_group(args.actor_num_nodes * args.actor_num_gpus_per_node)
        try:
            rollout_pg = _create_placement_group(args.rollout_num_gpus)
        except BaseException:
            from ray.util.placement_group import remove_placement_group

            if actor_pg[0] is not None:
                Cleanup().run("remove partial training placement", remove_placement_group, actor_pg[0])
            raise
        return {"actor": actor_pg, "critic": actor_pg if args.use_critic else None, "rollout": rollout_pg}

    num_gpus, rollout_offset = _get_placement_group_layout(args)

    logger.info(f"Creating placement group with {num_gpus} GPUs...")
    pg, actor_pg_reordered_bundle_indices, actor_pg_reordered_gpu_ids = _create_placement_group(num_gpus)
    rollout_pg_reordered_bundle_indices = actor_pg_reordered_bundle_indices[rollout_offset:]
    rollout_pg_reordered_gpu_ids = actor_pg_reordered_gpu_ids[rollout_offset:]

    result = {
        "actor": (pg, actor_pg_reordered_bundle_indices, actor_pg_reordered_gpu_ids),
        "rollout": (pg, rollout_pg_reordered_bundle_indices, rollout_pg_reordered_gpu_ids),
    }

    result["critic"] = result["actor"] if args.use_critic else None

    return result


def allocate_train_group(
    args,
    num_nodes,
    num_gpus_per_node,
    pg,
    role="actor",
    with_ref=False,
    with_opd_teacher=False,
    actor_cls=None,
):
    return RayTrainGroup(
        args=args,
        num_nodes=num_nodes,
        num_gpus_per_node=num_gpus_per_node,
        pg=pg,
        num_gpus_per_actor=0.4,
        role=role,
        with_ref=with_ref,
        with_opd_teacher=with_opd_teacher,
        actor_cls=actor_cls,
    )


def create_actor_model(args, pgs, rollout_manager, actor_cls=None):
    actor_args = args
    if args.megatron_config_path is not None:
        from slime.utils.arguments import parse_megatron_role_args

        actor_args = parse_megatron_role_args(args, args.megatron_config_path, role="actor")

    actor_model_kwargs = {}
    if actor_cls is not None:
        actor_model_kwargs["actor_cls"] = actor_cls
    actor_model = allocate_train_group(
        args=actor_args,
        num_nodes=args.actor_num_nodes,
        num_gpus_per_node=args.actor_num_gpus_per_node,
        pg=pgs["actor"],
        with_ref=actor_args.kl_coef != 0 or actor_args.use_kl_loss,
        with_opd_teacher=actor_args.use_opd and actor_args.opd_type == "megatron",
        **actor_model_kwargs,
    )
    actor_start_rollout_ids = actor_model.create(rollout_manager=rollout_manager)
    return actor_model, actor_start_rollout_ids


def create_training_models(args, pgs, rollout_manager, actor_cls=None):
    actor_model, actor_start_rollout_ids = create_actor_model(args, pgs, rollout_manager, actor_cls=actor_cls)

    critic_model = None
    if args.use_critic and args.num_rollout != 0:
        from slime.utils.arguments import parse_megatron_role_args

        critic_args = (
            parse_megatron_role_args(args, args.megatron_config_path, role="critic")
            if args.megatron_config_path is not None
            else copy.deepcopy(args)
        )
        if args.megatron_config_path is None:
            critic_args.disable_param_buffers_cpu_backup = False

        critic_model = allocate_train_group(
            args=critic_args,
            num_nodes=args.critic_num_nodes,
            num_gpus_per_node=args.critic_num_gpus_per_node,
            pg=pgs["critic"],
            role="critic",
        )
        critic_start_rollout_ids = critic_model.create(rollout_manager=rollout_manager)

    # TODO how to decide rollout start id when critic is involved? For now we just require user to specify it via args.
    if critic_model is not None:
        start_rollout_ids = critic_start_rollout_ids
    else:
        start_rollout_ids = actor_start_rollout_ids

    assert len(set(start_rollout_ids)) == 1

    if args.start_rollout_id is None:
        args.start_rollout_id = start_rollout_ids[0]

    ray.get(rollout_manager.load.remote(args.start_rollout_id - 1))

    return actor_model, critic_model


@dataclass
class RolloutStartup:
    """One driver's attempt, including resources acquired before startup ends."""

    args: object
    restore_plan: object = None
    manager: object = None
    serving: object = None
    placements: dict | None = None
    num_rollout_per_epoch: int | None = None

    def close(self, *, failed):
        timeout = getattr(self.args, "rollout_cleanup_timeout", 60)
        with Cleanup(timeout) as cleanup:
            if failed and self.serving is not None:
                # A live but wedged manager must not prevent the independent
                # serving owner from releasing this driver's training actors.
                if self.manager is not None:
                    try:
                        ray.get(self.manager.detach_training.remote(), timeout=cleanup.remaining / 2)
                    except Exception:
                        logger.exception("Manager could not pause for restart; replacing it on the next attempt")
                        cleanup.run("terminate unresponsive manager", ray.kill, self.manager, no_restart=True)
                cleanup.run(
                    "detach training from serving",
                    lambda: ray.get(
                        self.serving.detach_training.remote(ray.get_runtime_context().get_job_id(), cleanup.remaining),
                        timeout=cleanup.remaining,
                    ),
                )
                return

            # Successful completion disposes both owners independently. A
            # broken custom source/manager cannot skip engine or PG cleanup.
            for name, actor, fraction in (("manager", self.manager, 0.5), ("serving", self.serving, 1)):
                if actor is not None:
                    timeout = cleanup.remaining * fraction
                    cleanup.run(
                        f"dispose {name}",
                        lambda actor=actor, timeout=timeout: ray.get(actor.dispose.remote(timeout), timeout=timeout),
                    )
                    cleanup.run(f"terminate {name}", ray.kill, actor, no_restart=True)
            if self.serving is None and self.placements:
                from ray.util.placement_group import remove_placement_group

                # External engines are not ours, but driver-created placements are.
                for group in {value[0] for value in self.placements.values() if value and value[0]}:
                    cleanup.run("remove training placement", remove_placement_group, group)


def create_rollout_manager(args, *, restore_plan=None):
    # Keep the caller's requested configuration intact. Runtime discovery and
    # checkpoint selection produce an attempt-local Namespace for old hooks.
    startup = RolloutStartup(copy.deepcopy(args), restore_plan)
    try:
        _attach_rollout_manager(startup)
    except BaseException:
        # Startup can fail after serving attaches but before the caller receives
        # this object. Roll back that partial attempt at the acquisition boundary.
        try:
            startup.close(failed=True)
        except Exception:
            logger.exception("Failed to detach partially started training")
        raise
    return startup


def _attach_rollout_manager(startup):
    from .rollout import RolloutManager
    from .serving import ServingCluster
    from .training_recovery import RECOVERY_NAMESPACE, training_session_name

    options = {
        "num_cpus": 1,
        "num_gpus": 0,
        "runtime_env": {"env_vars": add_default_ray_env_vars()},
    }
    args, restore_plan = startup.args, startup.restore_plan
    serving = None
    deployment = None
    if args.rollout_external:
        # External serving retains its existing startup and ownership contract.
        placements = startup.placements = create_placement_groups(args)
    else:
        # Ray resolves these stable names in one namespace. Reuse the detached
        # owner first, then recreate/attach the manager against its deployment;
        # manager death never requires discovering individual router processes.
        name = training_session_name(args)
        serving = startup.serving = ServingCluster.options(
            **options,
            name=name + ":serving",
            namespace=RECOVERY_NAMESPACE,
            lifetime="detached",
            get_if_exists=True,
        ).remote(args, restore_plan)
        # get_if_exists may return an old actor without running its constructor.
        # Attachment checks ownership and applies the new training configuration.
        deployment = ray.get(serving.attach_training.remote(args, ray.get_runtime_context().get_job_id()))
        placements, restore_plan = deployment.placements, deployment.restore_plan
        startup.placements = placements
        for key, value in deployment.routers.items():
            setattr(args, key, value)
        options.update(name=name, namespace=RECOVERY_NAMESPACE, lifetime="detached", get_if_exists=True)
    if args.rollout_data_transport == "nixl":
        options["enable_tensor_transport"] = True
    manager = startup.manager = RolloutManager.options(**options).remote(
        args,
        placements["rollout"],
        restore_plan=restore_plan,
        serving=serving,
        deployment=deployment,
    )
    reused = False
    if serving is not None:
        # Serving attachment fences the previous driver and resets its NCCL
        # connections. Manager attachment restores the data/checkpoint boundary.
        resume = ray.get(manager.attach_training.remote(args, deployment))
        restore_plan, reused = resume.restore_plan, resume.reused
        args = startup.args = resume.apply(args)
        logger.info("%s serving session %s", "Reusing" if reused else "Created", name)
    num_rollout_per_epoch = None
    if args.num_rollout is None:
        num_rollout_per_epoch = ray.get(manager.get_num_rollout_per_epoch.remote())
        args.num_rollout = num_rollout_per_epoch * args.num_epoch
        assert args.num_rollout > 0
    if args.check_weight_update_equal and not reused:
        # This diagnostic resets initial weights. Reused engines must retain
        # their current weights until the restarted trainer replaces them.
        ray.get(manager.check_weights.remote(action="snapshot"))
        ray.get(manager.check_weights.remote(action="reset_tensors"))
    if args.offload_rollout:
        ray.get(manager.offload.remote())
    startup.num_rollout_per_epoch = num_rollout_per_epoch
    startup.restore_plan = restore_plan
