import logging
import os
from argparse import Namespace
from contextlib import nullcontext
from datetime import timedelta
from pathlib import Path

import ray
import torch
import torch.distributed as dist
from megatron.core import mpu
from torch_memory_saver import torch_memory_saver
from transformers import AutoTokenizer

from slime.data.tensor import TensorRef
from slime.observability import train_data_utils, train_metric_utils
from slime.observability.logging_utils import init_tracking
from slime.observability.profile_utils import TrainProfiler
from slime.observability.timer import Timer, inverse_timer, timer, with_defer
from slime.ray.train_actor import TrainRayActor
from slime.utils import accelerator
from slime.utils.data import process_rollout_data
from slime.utils.distributed_utils import get_gloo_group
from slime.utils.memory_utils import clear_memory, print_memory, reset_cuda_stack_size
from slime.utils.misc import Box
from slime.utils.model_config import load_hf_config
from slime.utils.reloadable_process_group import (
    destroy_process_groups,
    monkey_patch_torch_dist,
    register_default_process_group,
    reload_process_groups,
)
from slime.utils.routed_experts import (
    RoutedExpertsLayerRef,
    RoutedExpertsMicrobatch,
    RoutedExpertsMicrobatchPrefetcher,
)
from slime.utils.routing_replay import RoutingReplay
from slime.utils.types import RolloutBatch

from ...utils.tensor_backper import TensorBackuper
from .checkpoint import load_checkpoint
from .cp_utils import prepare_routed_experts_for_routing_replay, slice_log_prob_with_cp
from .data import DataIterator, get_data_iterator
from .hf_checkpoint_saver import save_hf_model_to_path
from .initialize import init, is_megatron_main_rank
from .loss import (
    compute_advantages_and_returns,
    drain_captured_log_probs,
    enable_log_prob_capture,
    get_log_probs_and_entropy,
    get_values,
)
from .model import forward_only, initialize_model_and_optimizer, save, train
from .update_weight import create_weight_updater
from .update_weight.common import named_params_and_buffers

logging.getLogger("megatron").setLevel(logging.WARNING)

logger = logging.getLogger(__name__)


class MegatronTrainRayActor(TrainRayActor):
    @with_defer(lambda: Timer().start("train_wait"))
    def init(
        self,
        args: Namespace,
        role: str,
        with_ref: bool = False,
        with_opd_teacher: bool = False,
    ) -> int | None:
        if args.debug_rollout_only:
            self.args = args
            return 0

        if args.offload_train:
            monkey_patch_torch_dist()
        super().init(args, role, with_ref, with_opd_teacher)
        if args.offload_train:
            # Destroying and recreating WORLD invalidates raw dist.group.WORLD references cached by external code.
            # Set SLIME_DESTROY_WORLD_PROCESS_GROUP=0 when such references may outlive a train sleep/wake cycle.
            if os.getenv("SLIME_DESTROY_WORLD_PROCESS_GROUP", "1").lower() not in {"0", "false", "no"}:
                register_default_process_group(timeout=timedelta(minutes=args.distributed_timeout_minutes))
            else:
                logger.info("Default WORLD process-group destruction is disabled")

        init(args)

        if is_megatron_main_rank():
            init_tracking(args, primary=False, role=role)

        self.prof = TrainProfiler(args)

        # read config and tokenizer serialized to prevent concurrent writing bug.
        for i in range(args.num_gpus_per_node):
            if i == dist.get_rank() % args.num_gpus_per_node:
                self.hf_config = load_hf_config(args.hf_checkpoint, trust_remote_code=True)
                self.tokenizer = AutoTokenizer.from_pretrained(self.args.hf_checkpoint, trust_remote_code=True)
            dist.barrier(group=get_gloo_group())

        dist.barrier(group=get_gloo_group())

        self.model, self.optimizer, self.opt_param_scheduler, loaded_rollout_id = initialize_model_and_optimizer(
            args, role
        )

        vpp_size = mpu.get_virtual_pipeline_model_parallel_world_size() or 1
        if vpp_size > 1:
            from megatron.core.utils import get_model_config

            microbatch_group_size_per_vp_stage = get_model_config(self.model[0]).microbatch_group_size_per_vp_stage
        else:
            microbatch_group_size_per_vp_stage = 1
        self.train_parallel_config = {
            "dp_size": mpu.get_data_parallel_world_size(with_context_parallel=False),
            "cp_size": mpu.get_context_parallel_world_size(),
            "vpp_size": vpp_size,
            "microbatch_group_size_per_vp_stage": microbatch_group_size_per_vp_stage,
        }

        start_rollout_id = loaded_rollout_id + 1

        if role == "critic":
            if self.args.offload_train:
                self.sleep()
            return start_rollout_id

        self.weights_backuper = TensorBackuper(
            source_getter=lambda: named_params_and_buffers(self.args, self.model),
        )
        self._active_model_tag: str | None = "actor"
        self.weights_backuper.backup("actor")

        if with_ref:
            self.load_other_checkpoint("ref", args.ref_load)

        # Load teacher model for Megatron-based on-policy distillation
        if with_opd_teacher:
            self.load_other_checkpoint("teacher", args.opd_teacher_load)

        if self.args.vocab_size is None:
            # Prefer HF config vocab_size (which may include model-native padding)
            # over tokenizer vocab_size, which may be smaller.
            hf_vocab = getattr(self.hf_config, "vocab_size", None)
            self.args.vocab_size = hf_vocab if hf_vocab is not None else self.tokenizer.vocab_size

        # Model-only resumes keep the serving version aligned with the next
        # rollout. Actor recreation can supply the latest version explicitly.
        if not hasattr(args, "update_weight_start_version"):
            args.update_weight_start_version = (
                args.start_rollout_id if args.start_rollout_id is not None else start_rollout_id
            )
        self.weight_updater = create_weight_updater(
            self.args,
            self.model,
            weights_getter=lambda: self.weights_backuper.get("actor"),
            model_name=type(self.hf_config).__name__.lower() if self.args.model_name is None else self.args.model_name,
            quantization_config=getattr(self.hf_config, "quantization_config", None),
        )

        # empty cache after initialization
        clear_memory()

        if self.args.offload_train:
            # recover to actor in the end.
            self._switch_model("actor")
            self.sleep()

        self.rollout_engines = None

        self.rollout_data_postprocess = None
        if self.args.rollout_data_postprocess_path is not None:
            from slime.utils.misc import load_function

            self.rollout_data_postprocess = load_function(self.args.rollout_data_postprocess_path)

        self.prof.on_init_end()

        return start_rollout_id

    @timer
    def sleep(self) -> None:
        assert self.args.offload_train

        clear_memory(clear_host_memory=True)
        print_memory("before offload model")
        if (
            self.role == "actor"
            and self.args.use_critic
            and not self.args.colocate
            and hasattr(self.weight_updater, "disconnect_rollout_engines")
        ):
            self.weight_updater.disconnect_rollout_engines()
        destroy_process_groups()

        torch_memory_saver.pause()
        reset_cuda_stack_size()

        print_memory("after offload model")

    @timer
    def wake_up(self) -> None:
        assert self.args.offload_train
        print_memory("before wake_up model")

        torch_memory_saver.resume()

        clear_memory()
        reload_process_groups()

        if mpu.get_pipeline_model_parallel_world_size() > 2:
            # Megatron's patched batched pipeline P2P uses the default WORLD
            # group.  After reload, PP=4 starts with only the first two stages
            # entering batch_isend_irecv(), but PyTorch requires every rank when
            # that is the first NCCL operation on a group.  Prime WORLD here,
            # after the memory saver is resumed, so later stages cannot miss its
            # lazy initialization.  Sleep still destroys it completely.
            dist.barrier(device_ids=[accelerator.current_device()])
        if self.role == "actor":
            self._switch_model("actor")
        print_memory("after wake_up model")

    def _get_rollout_data(self, rollout_data_ref: Box) -> RolloutBatch:
        # Fetch data through ray on CPU, not sure if this will be performance bottleneck.
        # Both first pp stage and the last pp stage will receive the data.
        rollout_data = process_rollout_data(
            rollout_data_ref,
            mpu.get_data_parallel_rank(with_context_parallel=False),
            mpu.get_data_parallel_world_size(with_context_parallel=False),
        )
        # TODO: this is ugly, move to somewhere else?
        # move tokens to GPU in advance
        device = accelerator.current_device()
        rollout_data["tokens"] = [
            t.to(device=device, dtype=torch.long, non_blocking=True) for t in rollout_data["tokens"]
        ]
        rollout_data["loss_masks"] = [
            t.to(device=device, dtype=torch.int, non_blocking=True) for t in rollout_data["loss_masks"]
        ]
        if "rollout_mask_sums" in rollout_data:
            # Promote precomputed per-rollout mask totals to GPU tensors here
            # (matching loss_masks) so the loss reducer can just divide.
            rollout_data["rollout_mask_sums"] = rollout_data["rollout_mask_sums"].to(
                device=device, dtype=torch.float32, non_blocking=True
            )
        if "multimodal_train_inputs" in rollout_data:
            # Move multimodal training tensors to GPU in advance
            rollout_data["multimodal_train_inputs"] = [
                (
                    {
                        key: value.to(device=device, non_blocking=True) if isinstance(value, torch.Tensor) else value
                        for key, value in mm_dict.items()
                    }
                    if mm_dict is not None
                    else None
                )
                for mm_dict in rollout_data["multimodal_train_inputs"]
            ]

        for key in ["rollout_log_probs", "teacher_log_probs"]:
            if key not in rollout_data:
                continue
            rollout_data[key] = [
                slice_log_prob_with_cp(log_prob, total_length, response_length).to(
                    device=device,
                    dtype=torch.float32,
                    non_blocking=True,
                )
                for log_prob, total_length, response_length in zip(
                    rollout_data[key],
                    rollout_data["total_lengths"],
                    rollout_data["response_lengths"],
                    strict=False,
                )
            ]
        for key, dtype in (("rollout_topk_token_ids", torch.int32), ("rollout_topk_log_probs", torch.float32)):
            if key not in rollout_data:
                continue
            rollout_data[key] = [
                (
                    value
                    if isinstance(value, TensorRef)
                    else (value if self.args.allgather_cp else slice_log_prob_with_cp(value, total, response)).to(
                        device="cpu", dtype=dtype
                    )
                )
                for value, total, response in zip(
                    rollout_data[key], rollout_data["total_lengths"], rollout_data["response_lengths"], strict=True
                )
            ]
        return rollout_data

    def _switch_model(self, target_tag: str) -> None:
        if target_tag not in self.weights_backuper.backup_tags:
            raise ValueError(f"Cannot switch to unknown model tag: {target_tag}")
        self.weights_backuper.restore(target_tag)
        self._active_model_tag = target_tag

    def fill_routing_replay(self, data_iterator, num_microbatches, rollout_data):
        if "rollout_routed_experts" not in rollout_data:
            raise ValueError(
                "rollout_routed_experts is required in rollout_data when use_rollout_routing_replay is set."
            )

        from megatron.core.transformer.transformer_block import get_num_layers_to_build
        from megatron.core.transformer.transformer_layer import get_transformer_layer_offset

        from slime.utils.routing_replay import RoutingReplay

        layer_ids = []
        for vp_stage, model in enumerate(self.model):
            config = model.module.config
            num_layers_to_build = get_num_layers_to_build(config, vp_stage=vp_stage)
            offset = get_transformer_layer_offset(config, vp_stage=vp_stage)
            for layer_id in range(offset, offset + num_layers_to_build):
                if isinstance(config.moe_layer_freq, int):
                    if layer_id % config.moe_layer_freq != 0:
                        continue
                elif isinstance(config.moe_layer_freq, list):
                    assert len(config.moe_layer_freq) == config.num_layers
                    if config.moe_layer_freq[layer_id] == 0:
                        continue
                layer_ids.append(layer_id)
        assert len(layer_ids) == len(RoutingReplay.all_routing_replays)

        for iterator in data_iterator:
            iterator.reset()

        replay_source = rollout_data["rollout_routed_experts"]
        disk_prefetcher = None
        prepare_kwargs = {
            "num_experts": self.args.num_experts,
            "data_pad_size_multiplier": self.args.data_pad_size_multiplier,
            "sequence_parallel": self.args.sequence_parallel,
            "allgather_cp": self.args.allgather_cp,
        }
        for _ in range(sum(num_microbatches)):
            iterator = data_iterator[0]
            batch_indices = iterator.micro_batch_indices[iterator.offset]
            batch = iterator.get_next(["rollout_routed_experts", "tokens"])
            values = batch["rollout_routed_experts"]

            disk_backed = [isinstance(value, TensorRef) for value in values]
            if any(disk_backed) and not all(disk_backed):
                raise ValueError("A routing replay microbatch cannot mix disk-backed and resident route tensors.")

            if layer_ids and all(disk_backed):
                if disk_prefetcher is None:
                    disk_prefetcher = RoutedExpertsMicrobatchPrefetcher(self.args.routing_replay_prefetch_microbatches)
                source = RoutedExpertsMicrobatch(
                    values,
                    batch["tokens"],
                    consumer_count=len(layer_ids),
                    prepare_kwargs=prepare_kwargs,
                )
                disk_prefetcher.add(source)
                for replay, layer_id in zip(RoutingReplay.all_routing_replays, layer_ids, strict=True):
                    replay.record(RoutedExpertsLayerRef(source, layer_id))
            elif layer_ids:
                rollout_routed_experts = prepare_routed_experts_for_routing_replay(
                    values,
                    batch["tokens"],
                    **prepare_kwargs,
                )
                for replay, layer_id in zip(RoutingReplay.all_routing_replays, layer_ids, strict=True):
                    replay.record(rollout_routed_experts[:, layer_id])

            # Drop manager-owned references as soon as this microbatch has
            # been registered, bounding actor RSS during setup.
            for sample_idx in batch_indices:
                replay_source[sample_idx] = None

        if disk_prefetcher is not None:
            disk_prefetcher.start()
            RoutingReplay.register_lazy_resource(disk_prefetcher)

        del rollout_data["rollout_routed_experts"]

        for iterator in data_iterator:
            iterator.reset()

    def compute_log_prob(
        self,
        data_iterator: list[DataIterator],
        num_microbatches: list[int],
        store_prefix: str = "",
        use_rollout_top_p_replay: bool = True,
    ) -> dict[str, list[torch.Tensor]]:
        with timer(f"{store_prefix}log_probs"):
            return forward_only(
                get_log_probs_and_entropy,
                self.args,
                self.model,
                data_iterator,
                num_microbatches,
                store_prefix=store_prefix,
                use_rollout_top_p_replay=use_rollout_top_p_replay,
            )

    def train(self, rollout_id: int, rollout_data_ref: Box, external_data=None):
        if self.args.debug_rollout_only:
            return None

        if self.args.offload_train:
            self.wake_up()

        with timer("data_preprocess"):
            rollout_data = self._get_rollout_data(rollout_data_ref)

        if self.role == "critic":
            result = self.train_critic(rollout_id, rollout_data)
        else:
            self.train_actor(rollout_id, rollout_data, external_data=external_data)
            result = None

        if self.args.offload_train:
            del rollout_data
            self.sleep()

        return result

    def train_critic(self, rollout_id: int, rollout_data: RolloutBatch):
        """Train critic and return CPU values (used as old-values for the next actor train)."""
        data_iterator = get_data_iterator(rollout_data)
        num_microbatches = rollout_data["num_microbatches"]
        global_batch_sizes = rollout_data["global_batch_sizes"]

        # Compute current critic values (used as old_values for value loss and for actor advantages).
        rollout_data.update(forward_only(get_values, self.args, self.model, data_iterator, num_microbatches))

        compute_advantages_and_returns(self.args, rollout_data)

        self.args.loss_type = "value_loss"
        train(
            rollout_id,
            self.model,
            self.optimizer,
            self.opt_param_scheduler,
            data_iterator,
            num_microbatches,
            global_batch_sizes,
        )

        if mpu.is_pipeline_last_stage() and "values" in rollout_data:
            from slime.backends.megatron_utils.data import tensors_to_cpu

            return {"values": tensors_to_cpu(rollout_data["values"])}
        return {}

    def train_actor(self, rollout_id: int, rollout_data: RolloutBatch, external_data=None) -> None:
        # Create data iterator for log_probs and train.
        data_iterator = get_data_iterator(rollout_data)
        num_microbatches = rollout_data["num_microbatches"]
        global_batch_sizes = rollout_data["global_batch_sizes"]

        if self.args.use_rollout_routing_replay:
            self.fill_routing_replay(data_iterator, num_microbatches, rollout_data)

        with inverse_timer("train_wait"), timer("train"):
            if self.args.compute_advantages_and_returns:
                if "ref" in self.weights_backuper.backup_tags:
                    if self.args.use_routing_replay:
                        os.environ["ROUTING_REPLAY_STAGE"] = "fallthrough"
                    self._switch_model("ref")
                    rollout_data.update(
                        self.compute_log_prob(
                            data_iterator,
                            num_microbatches,
                            store_prefix="ref_",
                            use_rollout_top_p_replay=False,
                        )
                    )

                # Forward teacher model to get teacher_log_probs for Megatron-based OPD
                if "teacher" in self.weights_backuper.backup_tags:
                    if self.args.use_routing_replay:
                        os.environ["ROUTING_REPLAY_STAGE"] = "fallthrough"
                    self._switch_model("teacher")
                    rollout_data.update(
                        self.compute_log_prob(
                            data_iterator,
                            num_microbatches,
                            store_prefix="teacher_",
                        )
                    )

                self._switch_model("actor")
                can_reuse_log_probs_in_loss = (
                    len(num_microbatches) == 1
                    and self.args.loss_type == "policy_loss"
                    and self.args.kl_coef == 0
                    and not self.args.use_rollout_logprobs
                    and not self.args.get_mismatch_metrics
                    and not self.args.use_critic
                    and not self.args.use_opd
                    and (not self.args.use_routing_replay or self.args.use_rollout_routing_replay)
                    and self.args.advantage_estimator != "gspo"
                )
                if (
                    not self.args.use_rollout_logprobs or self.args.get_mismatch_metrics
                ) and not can_reuse_log_probs_in_loss:
                    if self.args.use_routing_replay:
                        if self.args.use_rollout_routing_replay:
                            os.environ["ROUTING_REPLAY_STAGE"] = "replay_forward"
                            RoutingReplay.begin_lazy_pass("forward")
                        else:
                            os.environ["ROUTING_REPLAY_STAGE"] = "record"
                    rollout_data.update(
                        self.compute_log_prob(
                            data_iterator,
                            num_microbatches,
                            store_prefix="",
                        )
                    )
                    if self.args.use_rollout_routing_replay:
                        RoutingReplay.clear_all_forward()

                if self.args.use_critic:
                    if external_data is not None and mpu.is_pipeline_last_stage():
                        values = external_data.get("values")
                        if values is not None:
                            from slime.backends.megatron_utils.data import tensors_to_gpu

                            rollout_data["values"] = tensors_to_gpu(values)
                if self._active_model_tag != "actor":
                    self._switch_model("actor")

                # Calculate adv and returns. Need to performed before training (instead of on the fly),
                # because we may need normalize the whole rollout.
                compute_advantages_and_returns(self.args, rollout_data)

            if self.rollout_data_postprocess is not None:
                self.rollout_data_postprocess(self.args, rollout_id, rollout_data)

            train_metric_utils.log_rollout_data(
                rollout_id,
                self.args,
                rollout_data,
            )

            # Train
            if self.args.use_routing_replay:
                os.environ["ROUTING_REPLAY_STAGE"] = "replay_backward"
                if self.args.use_rollout_routing_replay:
                    # Hold each microbatch across forward and recompute; release
                    # it after the backward replay has consumed every layer.
                    RoutingReplay.begin_lazy_pass("backward")
            # When dumping train debug data but the actor log_probs were not
            # recomputed separately (can_reuse_log_probs_in_loss / use_rollout_logprobs),
            # snapshot them from the training forward so the dump still carries
            # per-sample log_probs — at no extra forward pass.
            capture_log_probs = self.args.save_debug_train_data is not None and "log_probs" not in rollout_data
            if capture_log_probs:
                enable_log_prob_capture()
            with timer("actor_train"):
                train(
                    rollout_id,
                    self.model,
                    self.optimizer,
                    self.opt_param_scheduler,
                    data_iterator,
                    num_microbatches,
                    global_batch_sizes,
                )
            if capture_log_probs:
                captured = drain_captured_log_probs()
                # `captured` is non-empty only on the last PP stage running a loss
                # that snapshots log_probs (policy_loss), and then covers every
                # local sample. Key it by this rank's `partition` to land in local
                # sample order; skip otherwise (nothing to place).
                if captured:
                    rollout_data["log_probs"] = [captured[pos] for pos in rollout_data["partition"]]

            self.prof.step(rollout_id=rollout_id)

        train_data_utils.save_debug_train_data(self.args, rollout_id=rollout_id, rollout_data=rollout_data)

        if self.args.use_routing_replay:
            RoutingReplay.clear_all()

        # update the cpu actor weight to the latest model
        self.weights_backuper.backup("actor")

        # Update ref model if needed
        if (
            self.args.ref_update_interval is not None
            and (rollout_id + 1) % self.args.ref_update_interval == 0
            and "ref" in self.weights_backuper.backup_tags
        ):
            with timer("ref_model_update"):
                if is_megatron_main_rank():
                    logger.info(f"Updating ref model at rollout_id {rollout_id}")
                self.weights_backuper.backup("ref")

        train_metric_utils.log_perf_data(
            rollout_id,
            self.args,
            extra_metrics=self.weight_updater.pop_metrics(),
        )

    @timer
    def save_model(self, rollout_id: int, force_sync: bool = False) -> None:
        if self.args.debug_rollout_only:
            return

        # torch dist may trigger nccl communication during saving.
        if self.args.offload_train:
            self.wake_up()

        if self.args.async_save:
            from megatron.training.async_utils import maybe_finalize_async_save

            maybe_finalize_async_save(blocking=True)

        save(rollout_id, self.model, self.optimizer, self.opt_param_scheduler)

        if force_sync and self.args.async_save:
            # Replay data can be released once this call returns, so the current
            # save must be durable rather than merely queued in the background.
            maybe_finalize_async_save(blocking=True)

        if self.args.save_hf is not None and self.role == "actor":
            save_hf_model_to_path(self.args, Path(self.args.save_hf.format(rollout_id=rollout_id)), self.model)

        if self.args.offload_train:
            self.sleep()

    @timer
    def update_weights(self) -> None:
        if self.args.debug_train_only or self.args.debug_rollout_only:
            return

        if not self.args.rollout_external or self.args.use_fault_tolerance:
            # Recover just before weights can be installed. One rank changes
            # serving topology; the barrier lets all ranks see the same engines.
            if dist.get_rank() == 0:
                ray.get(self.rollout_manager.recover_updatable_engines.remote())
            dist.barrier(group=get_gloo_group())

        (
            rollout_engines,
            rollout_engine_lock,
            num_new_engines,
            engine_gpu_counts,
            engine_gpu_offsets,
            engine_parallel_configs,
        ) = ray.get(self.rollout_manager.get_updatable_engines_and_lock.remote())

        reconnect_rollout_engines = self.args.offload_train and self.args.use_critic and not self.args.colocate

        if not rollout_engines and not reconnect_rollout_engines:
            if dist.get_rank() == 0:
                logger.info("No updatable SGLang engines are running; skip weight update.")
            return

        if reconnect_rollout_engines:
            self.wake_up()
        elif self.args.offload_train:
            reload_process_groups()

        if num_new_engines > 0 or reconnect_rollout_engines:
            # A replacement trainer must reconnect even to surviving engines;
            # their previous update groups belonged to the old trainer ranks.
            self.weight_updater.connect_rollout_engines(
                rollout_engines,
                rollout_engine_lock,
                engine_gpu_counts=engine_gpu_counts,
                engine_gpu_offsets=engine_gpu_offsets,
                engine_parallel_configs=engine_parallel_configs,
            )
            dist.barrier(group=get_gloo_group())
            if dist.get_rank() == 0:
                # Clear connection markers only after every rank is connected.
                ray.get(self.rollout_manager.clear_updatable_num_new_engines.remote())

        with torch_memory_saver.disable() if self.args.offload_train else nullcontext():
            print_memory("before update_weights")
            self.weight_updater.update_weights()
            print_memory("after update_weights")

        if reconnect_rollout_engines:
            self.sleep()
        elif self.args.offload_train:
            destroy_process_groups()

    def load_other_checkpoint(self, model_tag: str, path: str) -> None:
        old_args = (
            self.args.load,
            self.args.no_load_optim,
            self.args.no_load_rng,
            self.args.finetune,
            self.args.ckpt_step,
        )
        self.args.load = path
        self.args.no_load_optim = True
        self.args.no_load_rng = True
        self.args.finetune = True

        # The actor's resume step belongs to a different checkpoint. A None
        # reference/teacher step must let its own tracker select the release.
        if model_tag == "ref":
            self.args.ckpt_step = self.args.ref_ckpt_step
        elif model_tag == "teacher":
            self.args.ckpt_step = self.args.opd_teacher_ckpt_step
        try:
            _, _ = load_checkpoint(
                self.model,
                None,
                None,
                checkpointing_context={},
            )
        finally:
            (
                self.args.load,
                self.args.no_load_optim,
                self.args.no_load_rng,
                self.args.finetune,
                self.args.ckpt_step,
            ) = old_args

        self.weights_backuper.backup(model_tag)
        self._active_model_tag = model_tag
