"""Agent rollout building blocks."""
