"""Exercise the built bilingual lab in Chromium; no GPU or server required."""

import functools
import json
import os
import subprocess
import sys
import tempfile
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

from playwright.sync_api import expect, sync_playwright


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def copyfile(self, source, outputfile):
        try:
            super().copyfile(source, outputfile)
        except (BrokenPipeError, ConnectionResetError):
            pass  # Navigation can cancel an in-flight asset request.


def expect_rendered_math(page):
    # Raw TeX is also visible: require MathJax output for every formula, including
    # nodes nested inside MyST's tex2jax_ignore / mathjax_ignore article wrapper.
    expect(page.locator(".reader-article .math").first).to_be_visible()
    expect(page.locator(".reader-article .math:not(:has(mjx-container))")).to_have_count(0, timeout=30000)
    expect(page.locator(".reader-article mjx-merror")).to_have_count(0)


def expect_share_metadata(page, lang, check_image=False):
    canonical = "https://thudm.github.io/slime/" + ("zh/" if lang == "zh" else "")
    expect(page.locator('link[rel="canonical"]')).to_have_attribute("href", canonical)
    expect(page.locator('meta[property="og:url"]')).to_have_attribute("content", canonical)
    expect(page.locator('meta[name="twitter:card"]')).to_have_attribute("content", "summary_large_image")
    description = page.locator('meta[name="description"]').get_attribute("content")
    assert "LLM" in description
    expect(page.locator('meta[property="og:description"]')).to_have_attribute("content", description)
    image = f"https://thudm.github.io/slime/_static/image/rl-world-{lang}.png"
    expect(page.locator('meta[property="og:image"]')).to_have_attribute("content", image)
    expect(page.locator('meta[name="twitter:image"]')).to_have_attribute("content", image)
    if check_image:
        assert (
            page.evaluate(
                """url => new Promise((resolve, reject) => {
            const image = new Image();
            image.onload = () => resolve([image.naturalWidth, image.naturalHeight]);
            image.onerror = reject;
            image.src = url;
        })""",
                image,
            )
            == [1200, 630]
        )


def exercise_laptop_layout(page, base, lang):
    for width, height in ((1280, 800), (1440, 900)):
        page.set_viewport_size({"width": width, "height": height})
        hero = page.locator(".hero").bounding_box()
        assert hero["y"] + hero["height"] <= height
        page.locator('.hero-actions a[href="#learn"]').click()
        page.locator('[data-walkthrough-stage="3"]').click()
        # The explanation, graph and tour controls fit together on a laptop.
        assert page.locator("#learn").bounding_box()["height"] <= height
        for step in range(6):
            page.locator(f'[data-step="{step}"]').click()
            assert page.locator(".preview").evaluate("el => el.scrollHeight <= el.clientHeight + 1")
            assert page.locator("#world").evaluate("el => el.scrollWidth <= el.clientWidth + 1")
            assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
        page.locator(".artifact-preview > summary").click()
        expect(page.locator("#artifact-panel")).to_be_visible()
        # Long shell / JSON lines wrap; inspecting a file uses the page scroll.
        assert page.locator("#artifact-panel").evaluate(
            "el => el.scrollWidth <= el.clientWidth + 1 && el.scrollHeight <= el.clientHeight + 1"
        )
        page.locator(".artifact-preview > summary").click()
        page.locator("#reset").click()
    page.locator('[data-step="1"]').click()
    page.locator(".resource-options > summary").click()
    page.locator(".parallel-explorer > summary").click()
    page.locator('[name="cpuAdam"]').uncheck()
    expect(page.locator(".resource-options")).to_have_attribute("open", "")
    expect(page.locator(".parallel-explorer")).to_have_attribute("open", "")
    page.locator("#undo").click()
    expect(page.locator('[name="cpuAdam"]')).to_be_checked()
    expect(page.locator(".parallel-explorer")).to_have_attribute("open", "")
    page.locator("#reset").click()
    page.goto(f"{base}/{lang}/", wait_until="networkidle")
    page.set_viewport_size({"width": 1440, "height": 1000})


def exercise_homepage_review(page, context, base, lang):
    page.locator('[name="task"][value="custom"]').check()
    saved = page.evaluate("localStorage.getItem('slime-experiment-v1')")
    page.locator('.hero-actions a[href="#learn"]').click()
    expect(page.locator("#learn")).to_be_visible()
    expect(page.locator(".walkthrough-sample")).to_have_count(8)
    page.clock.install()
    page.locator("#walkthrough-play").click()
    page.clock.fast_forward(15000)
    expect(page.locator('[data-walkthrough-stage="1"]')).to_have_attribute("aria-current", "step")
    page.locator("#walkthrough-play").click()
    page.clock.fast_forward(15000)
    expect(page.locator('[data-walkthrough-stage="1"]')).to_have_attribute("aria-current", "step")
    page.locator("#walkthrough-play").click()
    page.clock.fast_forward(15000)
    expect(page.locator(".walkthrough-sample.correct")).to_have_count(4)
    page.locator("#walkthrough-next").click()
    expect(page.locator(".walkthrough-sample").first).to_contain_text("+0.94")
    page.locator("#walkthrough-next").click()
    expect(page.locator('[data-tour-phase="4"]')).to_be_visible()
    assert page.evaluate("localStorage.getItem('slime-experiment-v1')") == saved
    for width in (390, 320):
        page.set_viewport_size({"width": width, "height": 1000})
        assert page.locator("#learn").evaluate("el => el.scrollWidth <= el.clientWidth")
        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
    page.set_viewport_size({"width": 1440, "height": 1000})
    page.locator("#adopt-walkthrough").click()
    expect(page.locator('[name="task"][value="math"]')).to_be_checked()
    page.locator("#undo").click()
    expect(page.locator('[name="task"][value="custom"]')).to_be_checked()
    page.locator("#reset").click()
    page.locator('[data-step="5"]').click()
    page.locator('[name="hf"]').fill("/private/baseline-A")
    page.locator('[name="hf"]').press("Tab")
    page.locator("#comparison > summary").click()
    page.locator("#save-baseline").click()
    baseline = page.evaluate("localStorage.getItem('slime-baseline-v1')")
    page.locator('[data-step="1"]').click()
    page.locator('[name="schedule"][value="async"]').check()
    expect(page.locator("#comparison-content")).to_contain_text("colocate → separate")
    expect(page.locator("#comparison-content")).to_contain_text("sync → async")
    page.locator('[data-step="2"]').click()
    page.locator('[name="precision"][value="fp8"]').check()
    page.locator('[data-step="3"]').click()
    page.locator('[name="correction"][value="icepop"]').check()
    expect(page.locator(".comparison-insights")).to_contain_text("0.4/0.1 = 4")
    page.locator('[data-step="5"]').click()
    page.locator('[name="hf"]').fill("/private/current-B")
    page.locator('[name="hf"]').press("Tab")
    assert page.evaluate("localStorage.getItem('slime-baseline-v1')") == baseline
    page.locator('[data-artifact="experiment.json"]').click()
    plan = json.loads(page.locator("#artifact-code").text_content())
    assert plan["choices"]["schedule"] == "async"
    assert plan["provenance"]["runtimeEvidence"] == []
    assert len(plan["provenance"]["page"]["commit"]) == 40
    page.locator("#recipe-source > summary").click()
    expect(page.locator("#recipe-source-content")).to_contain_text(plan["provenance"]["recipe"]["path"])
    for width in (390, 320):
        page.set_viewport_size({"width": width, "height": 1000})
        assert page.locator("#recipe-source").evaluate("el => el.scrollWidth <= el.clientWidth")
        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
    page.set_viewport_size({"width": 1440, "height": 1000})
    page.reload(wait_until="networkidle")
    page.locator("#comparison > summary").click()
    assert page.evaluate("localStorage.getItem('slime-baseline-v1')") == baseline
    for width in (390, 320):
        page.set_viewport_size({"width": width, "height": 1000})
        for side in ("a", "b"):
            page.locator(f'[data-compare-side="{side}"]').click()
            expect(page.locator(f'[data-compare-config="{side}"]')).to_be_visible()
            expect(page.locator(f'[data-compare-config="{"b" if side == "a" else "a"}"]')).to_be_hidden()
            assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
    page.set_viewport_size({"width": 1440, "height": 1000})
    page.locator("#share-comparison").click()
    link = page.evaluate("navigator.clipboard.readText()")
    assert "private" not in link
    shared = context.new_page()
    shared.goto(link)
    shared.locator("#comparison > summary").click()
    expect(shared.locator("#comparison-content")).to_contain_text("sync → async")
    shared.close()
    page.locator("#restore-baseline").click()
    assert json.loads(page.evaluate("localStorage.getItem('slime-experiment-v1')"))["schedule"] == "sync"
    page.locator("#undo").click()
    assert json.loads(page.evaluate("localStorage.getItem('slime-experiment-v1')"))["schedule"] == "async"
    page.locator("#redo").click()
    assert json.loads(page.evaluate("localStorage.getItem('slime-experiment-v1')"))["schedule"] == "sync"
    page.locator("#undo").click()
    current_b = page.evaluate("localStorage.getItem('slime-experiment-v1')")
    page.locator("#save-baseline").click()
    assert page.evaluate("localStorage.getItem('slime-experiment-v1')") == current_b
    assert json.loads(page.evaluate("localStorage.getItem('slime-baseline-v1')"))["schedule"] == "async"
    page.locator("#redo").click()
    assert json.loads(page.evaluate("localStorage.getItem('slime-experiment-v1')"))["schedule"] == "sync"
    assert json.loads(page.evaluate("localStorage.getItem('slime-baseline-v1')"))["schedule"] == "async"
    page.locator("#clear-baseline").click()
    assert page.evaluate("localStorage.getItem('slime-baseline-v1')") is None
    page.locator("#reset").click()
    page.locator('[data-step="1"]').click()
    page.locator('[name="layout"][value="separate"]').check()
    page.locator('[data-step="4"]').click()
    page.locator('[name="pd"]').check()
    before = page.evaluate("localStorage.getItem('slime-experiment-v1')")
    apply = page.locator('[data-repair-action="pd-resources"]')
    apply.locator("xpath=..").locator("summary").click()
    expect(apply.locator("xpath=..")).to_contain_text("8 → 16")
    assert page.evaluate("localStorage.getItem('slime-experiment-v1')") == before
    apply.click()
    expect(page.locator("#download")).to_be_disabled()
    assert json.loads(page.evaluate("localStorage.getItem('slime-experiment-v1')"))["rollout"] == 16
    page.locator("#undo").click()
    assert page.evaluate("localStorage.getItem('slime-experiment-v1')") == before
    page.locator("#redo").click()
    page.locator('[data-repair-target="ib"]').click()
    expect(page.locator('[name="ib"]')).to_be_focused()
    page.locator('[name="ib"]').fill("mlx5_0")
    page.locator('[name="ib"]').press("Tab")
    expect(page.locator("#download")).to_be_enabled()
    page.locator("#import-experiment").set_input_files(
        {
            "name": "old.json",
            "mimeType": "application/json",
            "buffer": json.dumps({"schema": 1, "choices": {"model": "qwen38"}}).encode(),
        }
    )
    expect(page.locator('[name="model"][value="qwen38"]')).to_be_checked()
    page.locator("#undo").click()
    expect(page.locator('[name="pd"]')).to_be_checked()
    before = page.evaluate("localStorage.getItem('slime-experiment-v1')")
    page.locator("#import-experiment").set_input_files(
        {
            "name": "future.json",
            "mimeType": "application/json",
            "buffer": b'{"schema":99,"choices":{"model":"qwen38"}}',
        }
    )
    expect(page.locator("#toast")).to_contain_text("schema 1")
    assert page.evaluate("localStorage.getItem('slime-experiment-v1')") == before
    page.locator("#reset").click()
    page.goto(f"{base}/{lang}/", wait_until="networkidle")


def run():
    build = Path(__file__).resolve().parents[1] / "build"
    server = ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(QuietHandler, directory=str(build)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{server.server_port}"
    try:
        with sync_playwright() as playwright, tempfile.TemporaryDirectory() as downloads:
            browser = playwright.chromium.launch()
            for lang in ("en", "zh"):
                context = browser.new_context(viewport={"width": 1440, "height": 1000}, reduced_motion="reduce")
                context.grant_permissions(["clipboard-read", "clipboard-write"])
                page = context.new_page()
                errors = []
                page.on("pageerror", lambda error, target=errors: target.append(str(error)))
                page.goto(f"{base}/{lang}/", wait_until="networkidle")
                expect_share_metadata(page, lang)
                expect(page.locator(".hero-copy .primary")).to_have_attribute("href", "#learn")
                exercise_laptop_layout(page, base, lang)
                exercise_homepage_review(page, context, base, lang)
                expect(page.locator("#install-docker")).to_be_visible()
                expect(page.locator("#install-conda")).to_be_hidden()
                recipe_before_install = page.locator("#artifact-code").text_content()
                expect(page.locator("#install")).not_to_contain_text("CUDA 12")
                page.locator('[data-install-copy="install-docker-host"]').click()
                commands = page.evaluate("navigator.clipboard.readText()")
                assert commands.startswith("SLIME_IMAGE=slimerl/slime:latest-cu130\n")
                assert 'docker pull "$SLIME_IMAGE"' in commands
                assert '-v "$PWD:/root/slime" -v "$PWD/../slime-data:/data"' in commands
                subprocess.run(["bash", "-n"], input=commands, text=True, check=True)
                for width in (1440, 390, 320):
                    page.set_viewport_size({"width": width, "height": 1000})
                    for method in ("conda", "docker"):
                        page.locator(f'[name="install-method"][value="{method}"]').check()
                        panel = page.locator(f"#install-{method}")
                        expect(panel).to_be_visible()
                        for button in panel.locator("[data-install-copy]").all():
                            button.click()
                            commands = page.evaluate("navigator.clipboard.readText()")
                            target = button.get_attribute("data-install-copy")
                            assert commands == page.locator(f"#{target}").text_content()
                            subprocess.run(["bash", "-n"], input=commands, text=True, check=True)
                        assert page.locator("#install").evaluate("el => el.scrollWidth <= el.clientWidth")
                        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
                page.set_viewport_size({"width": 1440, "height": 1000})
                page.locator('[name="install-method"][value="docker"]').focus()
                page.keyboard.press("ArrowRight")
                expect(page.locator("#install-conda")).to_be_visible()
                page.keyboard.press("ArrowLeft")
                expect(page.locator("#install-docker")).to_be_visible()
                expect(page.locator("#artifact-code")).to_have_text(recipe_before_install)
                page.locator(".install-next a").click()
                expect(page).to_have_url(f"{base}/{lang}/#lab")
                page.goto(f"{base}/{lang}/", wait_until="networkidle")
                no_js = browser.new_page(java_script_enabled=False)
                no_js.goto(f"{base}/{lang}/")
                expect(no_js.locator("#install-docker")).to_be_visible()
                expect(no_js.locator("#install-conda")).to_be_visible()
                expect(no_js.locator("#install-methods")).to_be_hidden()
                no_js.close()
                expect(page.locator('[name="model"]')).to_have_count(4)
                expect(page.locator(".hero-description")).to_contain_text("slime")
                expect(page.locator(".core-capabilities article")).to_have_count(2)
                expect(page.locator(".glm-lineage")).to_contain_text("GLM-5.3-Flash")
                expect(page.locator('[name="model"][value="glm5"] + span')).to_contain_text("GLM-5.3")
                assert (
                    page.locator(".option-description").first.evaluate(
                        "el => parseFloat(getComputedStyle(el).fontSize)"
                    )
                    >= 16
                )
                expect(page.locator('[data-signal="math"]')).to_be_visible()
                page.locator('[name="task"][value="custom"]').check()
                expect(page.locator('[data-signal="custom"]')).to_be_visible()
                page.locator("#undo").click()
                expect(page.locator('[data-signal="math"]')).to_be_visible()
                page.locator('.library-teaser a[href="get_started/experiment-guide.html"]').click()
                expect(page.locator(".reader-article .mermaid")).to_be_visible()
                assert page.url == f"{base}/{lang}/"
                page.keyboard.press("Escape")
                for guide in ("policy-mismatch", "rl-systems"):
                    page.locator(f'.library-teaser a[href="advanced/{guide}.html"]').click()
                    expect_rendered_math(page)
                    page.keyboard.press("Escape")
                page.locator('[name="model"][value="qwen38"]').check()
                page.locator('[data-step="2"]').click()
                expect(page.locator('[name="mambaDtype"][value="auto"]')).to_be_checked()
                page.locator('[name="kv"][value="fp8"]').check()
                expect(page.locator('[data-cache="attention"] b')).to_have_text("FP8")
                expect(page.locator('[data-cache="ssm"] b')).to_have_text("FP32")
                page.locator('[name="mambaDtype"][value="bfloat16"]').check()
                expect(page.locator('[data-cache="ssm"] b')).to_have_text("BF16")
                expect(page.locator("#artifact-code")).to_contain_text("--sglang-mamba-ssm-dtype bfloat16")
                page.locator("#undo").click()
                expect(page.locator('[data-cache="ssm"] b')).to_have_text("FP32")
                expect(page.locator('[name="kv"][value="fp8"]')).to_be_checked()
                page.locator('[name="mambaRatio"]').fill("1.5")
                page.locator('[name="mambaRatio"]').press("Tab")
                page.reload(wait_until="networkidle")
                expect(page.locator('[name="mambaRatio"]')).to_have_value("1.5")
                expect(page.locator("#artifact-code")).to_contain_text("--sglang-mamba-full-memory-ratio '1.5'")
                page.locator('#choices a[href$="#hybrid-cache"]').click()
                expect_rendered_math(page)
                expect(page.locator(".reader-article")).to_contain_text("GLM-5.3-Flash")
                page.keyboard.press("Escape")
                for width in (390, 320):
                    page.set_viewport_size({"width": width, "height": 900})
                    expect(page.locator(".workbench .hybrid-cache-map")).to_be_visible()
                    assert page.locator("#world").evaluate("el => el.scrollWidth <= el.clientWidth"), width
                    assert page.evaluate("document.documentElement.scrollWidth <= innerWidth"), width
                page.set_viewport_size({"width": 1440, "height": 1000})
                page.locator('[data-step="0"]').click()
                page.locator('[name="model"][value="flash"]').check()
                page.locator('[data-step="2"]').click()
                expect(page.locator('[name="mambaDtype"]')).to_have_count(0)
                assert "--sglang-mamba-" not in page.locator("#artifact-code").text_content()
                page.locator("#reset").click()
                page.locator('[data-step="4"]').click()
                for width in (1440, 390, 320):
                    page.set_viewport_size({"width": width, "height": 1000})
                    for pd in (False, True):
                        for hicache in (False, True):
                            for speculative in (False, True):
                                page.locator('[name="pd"]').set_checked(pd)
                                page.locator('[name="hicache"]').set_checked(hicache)
                                page.locator('[name="speculative"]').set_checked(speculative)
                                expect(page.locator(".serving-scene")).to_be_visible()
                                expect(page.locator(".combined-pool")).to_have_count(int(not pd))
                                expect(page.locator(".prefill-pool")).to_have_count(int(pd))
                                expect(page.locator(".decode-pool")).to_have_count(int(pd))
                                expect(page.locator('[data-serving-phase="transfer"]')).to_have_count(int(pd))
                                expect(page.locator('[data-cache-tier="cpu"]')).to_have_count(int(hicache))
                                expect(page.locator('[data-serving-phase="draft"]')).to_have_count(int(speculative))
                                expect(page.locator('[data-serving-phase="decode"]')).to_have_count(
                                    int(not speculative)
                                )
                                assert page.locator("#world").evaluate("el => el.scrollWidth <= el.clientWidth")
                                assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
                                if pd:
                                    expect(page.locator('.decode-pool [data-cache-tier="cpu"]')).to_have_count(0)
                page.set_viewport_size({"width": 1440, "height": 1000})
                page.locator('[name="pd"]').uncheck()
                page.locator('[name="draftSource"][value="external"]').check()
                expect(page.locator("#download")).to_be_disabled()
                page.locator('[name="draft"]').fill("/models/private eagle head")
                page.locator('[name="draft"]').press("Tab")
                page.locator('[name="specSteps"]').fill("5")
                page.locator('[name="specSteps"]').press("Tab")
                expect(page.locator("#artifact-code")).to_contain_text("--sglang-speculative-num-draft-tokens 6")
                expect(page.locator("#artifact-code")).to_contain_text(
                    "--sglang-speculative-draft-model-path '/models/private eagle head'"
                )
                expect(page.locator("#download")).to_be_enabled()
                page.reload(wait_until="networkidle")
                expect(page.locator('[name="draft"]')).to_have_value("/models/private eagle head")
                page.locator("#share").click()
                shared = page.evaluate("navigator.clipboard.readText()")
                assert "private" not in shared
                shared_page = context.new_page()
                shared_page.goto(shared)
                expect(shared_page.locator('[name="speculative"]')).to_be_checked()
                expect(shared_page.locator('[name="draft"]')).to_have_value("")
                expect(shared_page.locator("#download")).to_be_disabled()
                shared_page.close()
                page.locator('[name="speculative"]').uncheck()
                expect(page.locator('[data-serving-phase="draft"]')).to_have_count(0)
                page.locator("#undo").click()
                expect(page.locator('[data-serving-phase="draft"]')).to_be_visible()
                page.locator("#play").click()
                expect(page.locator('[data-serving-phase="draft"]')).to_have_class("draft-stage active", timeout=5000)
                page.locator("#play").click()
                page.locator('[data-learn="eagle"]').click()
                expect_rendered_math(page)
                page.keyboard.press("Escape")
                page.locator("#reset").click()
                expect(page.locator("#download")).to_be_enabled()
                page.locator('[data-step="1"]').click()
                page.locator('[name="layout"][value="external"]').check()
                expect(page.locator(".external-map .sampler")).to_have_count(3)
                page.locator("#undo").click()
                expect(page.locator(".external-map")).to_have_count(0)
                page.locator(".resource-options > summary").click()
                page.locator(".parallel-explorer > summary").click()
                page.locator('[data-parallel="cp"]').click()
                page.locator('[data-cp="allgather"]').click()
                expect(page.locator("#parallel-diagram")).to_contain_text("DSA")
                # The illustration must not change the selected model's CP recipe.
                assert "--allgather-cp" not in page.locator("#artifact-code").text_content()
                page.locator('[data-parallel="memory"]').click()
                page.locator('[name="cpuAdam"]').uncheck()
                assert "--optimizer-cpu-offload" not in page.locator("#artifact-code").text_content()
                page.locator("#undo").click()
                expect(page.locator('[name="cpuAdam"]')).to_be_checked()
                page.locator("#redo").click()
                expect(page.locator('[name="cpuAdam"]')).not_to_be_checked()
                page.locator('[name="partial"]').check()
                page.locator('[name="maskPartial"]').check()
                assert "--over-sampling-batch-size 16" in page.locator("#artifact-code").text_content()
                page.locator('[name="schedule"][value="async"]').check()
                expect(page.locator('[name="layout"][value="separate"]')).to_be_checked()
                page.locator('[name="straw"]').check()
                expect(page.locator("#download")).to_be_disabled()
                for name, value in {
                    "queueDir": "/shared/juicefs/my-run",
                    "queueRun": "browser-run",
                    "declaration": "/shared/deployment.json",
                }.items():
                    page.locator(f'[name="{name}"]').fill(value)
                    page.locator(f'[name="{name}"]').press("Tab")
                expect(page.locator("#download")).to_be_enabled()
                expect(page.locator(".schedule-explorer")).to_contain_text("Distributed fully async")
                expect(page.locator(".queue-pool")).to_contain_text("straw")
                script = page.locator("#artifact-code").text_content()
                assert "--rollout-data-transport straw" in script and "--partial-rollout" in script
                assert "--over-sampling-batch-size" not in script
                page.locator('[data-learn="partial"]').click()
                expect(page.locator("#learn-dialog")).to_be_visible()
                expect(page.locator(".reader-article")).to_be_visible()
                expect(page.locator(".reader-sources a")).to_have_count(2)
                assert len(page.locator(".reader-article").inner_text()) > 500
                assert page.url == f"{base}/{lang}/"
                expect_rendered_math(page)
                page.keyboard.press("Escape")
                expect(page.locator('[data-learn="partial"]')).to_be_focused()
                page.reload(wait_until="networkidle")
                expect(page.locator('[name="queueRun"]')).to_have_value("browser-run")
                page.locator("#share").click()
                shared = page.evaluate("navigator.clipboard.readText()")
                assert "browser-run" not in shared and "deployment.json" not in shared
                shared_page = context.new_page()
                shared_page.goto(shared)
                expect(shared_page.locator('[name="straw"]')).to_be_checked()
                expect(shared_page.locator('[name="queueDir"]')).to_have_value("")
                shared_page.close()
                with page.expect_download() as event:
                    page.locator("#download").click()
                target = Path(downloads) / f"{lang}-experiment.sh"
                event.value.save_as(target)
                subprocess.run(["bash", "-n", target], check=True)
                assert target.read_text() == script
                # PD validates both engine pools; YAML disables cache on decode.
                page.locator("#reset").click()
                page.locator('[data-step="1"]').click()
                page.locator('[name="layout"][value="separate"]').check()
                page.locator('[name="rollout"]').fill("16")
                page.locator('[name="rollout"]').press("Tab")
                page.locator('[data-step="4"]').click()
                page.locator('[name="pd"]').check()
                page.locator('[name="hicache"]').check()
                page.locator('[name="ib"]').fill("mlx5_0")
                page.locator('[name="ib"]').press("Tab")
                page.locator('[data-artifact="sglang.yaml"]').click()
                expect(page.locator("#artifact-code")).to_contain_text("enable_hierarchical_cache: false")
                page.keyboard.press("End")
                expect(page.locator('[data-artifact="experiment.json"]')).to_be_focused()
                plan = json.loads(page.locator("#artifact-code").text_content())
                assert not plan["validation"]["errors"]
                page.locator("#play").click()
                expect(page.locator("#play")).to_have_attribute("aria-pressed", "true")
                page.locator("#play").click()
                # Language navigation retains the same page and fragment.
                page.evaluate("location.hash='lab'")
                page.locator(".lang-toggle-btn").click()
                other = "zh" if lang == "en" else "en"
                page.wait_for_url(f"{base}/{other}/#lab")
                page.locator("#reset").click()
                for width in (1440, 390, 320):
                    page.set_viewport_size({"width": width, "height": 900})
                    for step in range(6):
                        page.locator(f'[data-step="{step}"]').click()
                        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth"), (lang, width, step)
                        if width <= 720:
                            # The main illustration must be visible in the page, without
                            # discovering or opening the floating preview button first.
                            expect(page.locator(".workbench > .preview #world")).to_be_visible()
                            expect(page.locator("#world .world-lesson")).to_have_attribute("data-lesson", str(step))
                            preview_box = page.locator(".workbench > .preview").bounding_box()
                            builder_box = page.locator(".builder-panel").bounding_box()
                            assert preview_box["y"] + preview_box["height"] <= builder_box["y"]
                            page.locator("#mobile-preview").click()
                            expect(page.locator("#mobile-preview-dialog")).to_be_visible()
                            expect(page.locator("#world")).to_be_visible()
                            assert page.locator("#mobile-preview-dialog").evaluate(
                                "el => el.scrollWidth <= el.clientWidth"
                            ), (width, step)
                            page.locator("#close-preview").click()
                            expect(page.locator("#mobile-preview-dialog")).not_to_be_visible()
                            expect(page.locator(".workbench > .preview #world")).to_be_visible()
                page.locator('[data-step="0"]').click()
                page.locator('[name="task"][value="custom"]').check()
                expect(page.locator('.workbench [data-signal="custom"]')).to_be_visible()
                page.locator("#undo").click()
                expect(page.locator('.workbench [data-signal="math"]')).to_be_visible()
                # External fleets with PD/cache must also fit narrow preview panels.
                page.locator('[data-step="1"]').click()
                page.locator('[name="layout"][value="external"]').check()
                page.locator('[data-step="4"]').click()
                page.locator('[name="pd"]').check()
                page.locator('[name="hicache"]').check()
                page.locator("#mobile-preview").click()
                expect(page.locator(".external-map .sampler")).to_have_count(3)
                assert page.locator("#mobile-preview-dialog").evaluate("el => el.scrollWidth <= el.clientWidth")
                clusters = page.locator(".external-cluster").evaluate_all(
                    "nodes => nodes.map(n => {const r=n.getBoundingClientRect();return {top:r.top,bottom:r.bottom};})"
                )
                assert clusters[0]["bottom"] < clusters[1]["top"] < clusters[1]["bottom"] < clusters[2]["top"]
                page.locator("#close-preview").click()
                expect(page.locator(".workbench .external-map .sampler")).to_have_count(3)
                for guide in ("policy-mismatch", "rl-systems"):
                    page.locator(f'.library-teaser a[href="advanced/{guide}.html"]').click()
                    expect_rendered_math(page)
                    assert page.locator("#learn-dialog").evaluate("el => el.scrollWidth <= el.clientWidth")
                    page.keyboard.press("Escape")
                # Check local page/anchor targets from the new landing page and guides.
                for doc in (
                    "index",
                    "get_started/quick_start",
                    "get_started/experiment-guide",
                    "advanced/policy-mismatch",
                    "advanced/rl-systems",
                    "advanced/parallelism-memory",
                    "advanced/rollout-scheduling",
                ):
                    page.goto(f"{base}/{lang}/{doc}.html", wait_until="domcontentloaded")
                    links = page.locator("a[href]").evaluate_all("(nodes) => nodes.map(a => a.href)")
                    for link in links:
                        url = urlsplit(link)
                        if not link.startswith(base) or url.query:
                            continue
                        file = build / unquote(url.path.lstrip("/"))
                        if file.is_dir():
                            file /= "index.html"
                        assert file.is_file(), link
                        if url.fragment and file.suffix == ".html" and not url.fragment.startswith("experiment="):
                            # MyST anchors may be percent encoded for Chinese headings.
                            anchor = unquote(url.fragment)
                            html = file.read_text()
                            assert f'id="{anchor}"' in html or f'name="{anchor}"' in html, link
                page.goto(f"{base}/{lang}/library.html")
                expect(page.locator(".library-categories .toctree-l1")).to_have_count(8)
                expect(page.locator(".library-categories .toctree-l2")).to_have_count(0)
                page.locator('.library-categories a[href="operations/index.html"]').click()
                expect(page.locator('article a[href="../developer_guide/profiling.html"]')).to_be_visible()
                query = "parallelism" if lang == "en" else "并行"
                page.goto(f"{base}/{lang}/search.html?q={query}")
                expect(
                    page.locator('#search-results a[href*="advanced/parallelism-memory.html"]').first
                ).to_be_visible()
                assert not errors, errors
                context.close()
                print(f"{lang}: configuration, history, sharing, downloads, mobile and local links passed")
            # Build exactly what release-docs publishes: English at root, Chinese in zh/.
            with tempfile.TemporaryDirectory() as publish:
                docs = build.parent
                for language, destination in (("en", Path(publish)), ("zh", Path(publish) / "zh")):
                    result = subprocess.run(
                        [
                            sys.executable,
                            "-m",
                            "sphinx",
                            "-b",
                            "html",
                            "-D",
                            f"language={language}",
                            "--conf-dir",
                            str(docs),
                            "-W",
                            "--keep-going",
                            str(docs / language),
                            str(destination),
                        ],
                        env={**os.environ, "SLIME_DOC_LAYOUT": "root", "SLIME_DOC_LANG": language},
                        cwd=docs,
                        text=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                    )
                    assert result.returncode == 0, result.stdout
                for prefix in ("/", "/slime/"):
                    context = browser.new_context()
                    missing = []

                    def production_route(route, _request, *, prefix=prefix, missing=missing):
                        relative = unquote(urlsplit(route.request.url).path.removeprefix(prefix))
                        file = Path(publish) / relative
                        if file.is_dir():
                            file /= "index.html"
                        if not file.is_file():
                            missing.append(route.request.url)
                            route.fulfill(status=404, body="not found")
                        else:
                            route.fulfill(path=file)

                    context.route("https://thudm.github.io/**", production_route)
                    page = context.new_page()
                    page.goto(f"https://thudm.github.io{prefix}#lab", wait_until="networkidle")
                    expect_share_metadata(page, "en", check_image=prefix == "/slime/")
                    expect(page.locator('[name="model"]')).to_have_count(4)
                    page.locator('[data-learn="grpo"]').click()
                    expect_rendered_math(page)
                    page.keyboard.press("Escape")
                    page.locator(".lang-toggle-btn").click()
                    page.wait_for_url(f"https://thudm.github.io{prefix}zh/#lab")
                    expect_share_metadata(page, "zh", check_image=prefix == "/slime/")
                    page.locator('[data-learn="grpo"]').click()
                    expect_rendered_math(page)
                    page.keyboard.press("Escape")
                    page.locator(".lang-toggle-btn").click()
                    page.wait_for_url(f"https://thudm.github.io{prefix}#lab")
                    page.goto(f"https://thudm.github.io{prefix}developer_guide/profiling.html")
                    page.locator(".lang-toggle-btn").click()
                    page.wait_for_url(f"https://thudm.github.io{prefix}zh/developer_guide/profiling.html")
                    assert not missing, missing
                    context.close()
            print(
                "actual production builds: root and https://thudm.github.io/slime/ assets, reader and language links passed"
            )
            browser.close()
    finally:
        server.shutdown()
        server.server_close()


if __name__ == "__main__":
    run()
