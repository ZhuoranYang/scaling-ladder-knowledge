"""Plugin contract tests."""
