#!/usr/bin/env python
"""MLS-MPM (Moving Least Squares Material Point
Method, Hu et al. 2018) on MiniTriton tensors, 2D. Model and trade-offs:

- Transfers: quadratic B-spline weights (3 nodes/axis, 9 nodes per
  particle). P2G consumes ``sparse.scatter_add`` directly (the
  message-passing primitive): a source kernel packs (m w, momentum) per
  particle-node pair, the grid accumulation is the primitive itself.
  G2P is a custom kernel because the MLS affine velocity needs the full
  per-node weighted sums, one pass -> (v_new, C_new).
- Constitutive model: **compressible StVK, eigenvalue-free**:
  Psi = mu/2 ||F||^2 + lam/2 (J-1)^2,  P = dPsi/dF = mu F + lam (J-1) cof(F)
  (2D cofactor is two swizzles -> no polar decomposition anywhere).
  The Sony-style svd3/polar3 is not available as a builder primitive;
  this eigenvalue-free model stands in for it (sgn/det edge
  cases of FCR are irrelevant for the squash-ball scene).
- Grid: 128x128 over [0,1]^2 (dx = 1/128); dt configurable; walls = zero
  normal velocity on the 3 outer node rings; semi-implicit via the
  momentum update inside P2G (gravity enters as nodal momentum).
- Mass conservation: particles' mass is scattered with f32 atomics; the
  only drift is atomic-order rounding (~1e-6 relative).

    CUDA_VISIBLE_DEVICES=1 python examples/mpm_demo.py --steps 200 \
        --frames /tmp/mpm
    CUDA_VISIBLE_DEVICES=1 python examples/mpm_demo.py --bench

Viz: viridis heatmap of grid mass + white particle scatter.
"""

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl
from minitriton import sparse, viz

GRAV = -9.8


# ---------------------------------------------------------------------------
# kernels
# ---------------------------------------------------------------------------

@tl.kernel
def _p2g_src_kernel(x_ptr, v_ptr, c_ptr, f_ptr, src_ptr, idx_ptr, N, G,
                    DX, INV_DX, DT, MU, LAM, V0, BLOCK: tl.constexpr):
    """Per particle: pack the 9 grid-node contributions (columns
    [weight*mass, momentum_x, momentum_y] incl. gravity and the internal
    stress force) plus the flat node index, for sparse.scatter_add."""
    p = tl.program_id(0)
    xp = tl.load(x_ptr + 2 * p)
    yp = tl.load(x_ptr + 2 * p + 1)
    vx = tl.load(v_ptr + 2 * p)
    vy = tl.load(v_ptr + 2 * p + 1)
    c00 = tl.load(c_ptr + 4 * p)
    c01 = tl.load(c_ptr + 4 * p + 1)
    c10 = tl.load(c_ptr + 4 * p + 2)
    c11 = tl.load(c_ptr + 4 * p + 3)
    f00 = tl.load(f_ptr + 4 * p)
    f01 = tl.load(f_ptr + 4 * p + 1)
    f10 = tl.load(f_ptr + 4 * p + 2)
    f11 = tl.load(f_ptr + 4 * p + 3)
    # stress = (1/J) P F^T, P = mu F + lam (J-1) cof(F)  (StVK)
    J = f00 * f11 - f01 * f10
    p00 = MU * f00 + LAM * (J - 1.0) * f11
    p01 = MU * f01 - LAM * (J - 1.0) * f10
    p10 = MU * f10 - LAM * (J - 1.0) * f01
    p11 = MU * f11 + LAM * (J - 1.0) * f00
    invJ = 1.0 / (J + 1e-9)
    s00 = (p00 * f00 + p01 * f01) * invJ
    s01 = (p00 * f10 + p01 * f11) * invJ
    s10 = (p10 * f00 + p11 * f01) * invJ
    s11 = (p10 * f10 + p11 * f11) * invJ
    # quadratic B-spline weights on each axis
    bx = tl.cast(xp * INV_DX - 0.5, tl.int32)
    by = tl.cast(yp * INV_DX - 0.5, tl.int32)
    fxx = xp * INV_DX - tl.cast(bx, tl.float32)
    fyy = yp * INV_DX - tl.cast(by, tl.float32)
    wx0 = 0.5 * (1.5 - fxx) * (1.5 - fxx)
    wx1 = 0.75 - (fxx - 1.0) * (fxx - 1.0)
    wx2 = 0.5 * (fxx - 0.5) * (fxx - 0.5)
    wy0 = 0.5 * (1.5 - fyy) * (1.5 - fyy)
    wy1 = 0.75 - (fyy - 1.0) * (fyy - 1.0)
    wy2 = 0.5 * (fyy - 0.5) * (fyy - 0.5)
    dwx0 = fxx - 1.5
    dwx1 = -2.0 * (fxx - 1.0)
    dwx2 = fxx - 0.5
    dwy0 = fyy - 1.5
    dwy1 = -2.0 * (fyy - 1.0)
    dwy2 = fyy - 0.5
    for ox in range(0, 3):
        for oy in range(0, 3):
            k = ox * 3 + oy
            wx = tl.where(ox == 0, wx0, tl.where(ox == 1, wx1, wx2))
            dwx = tl.where(ox == 0, dwx0, tl.where(ox == 1, dwx1, dwx2))
            wy = tl.where(oy == 0, wy0, tl.where(oy == 1, wy1, wy2))
            dwy = tl.where(oy == 0, dwy0, tl.where(oy == 1, dwy1, dwy2))
            w = wx * wy
            gwx = dwx * wy      # d w / d x_g (times inv_dx below)
            gwy = wx * dwy
            gx = tl.cast(bx + ox, tl.float32) * DX
            gy = tl.cast(by + oy, tl.float32) * DX
            dX = gx - xp
            dY = gy - yp
            affx = vx + c00 * dX + c01 * dY
            affy = vy + c10 * dX + c11 * dY
            # internal force: -V0 * sigma . grad w  (grad w = gw * inv_dx)
            fx_stress = (s00 * gwx + s01 * gwy) * INV_DX * V0
            fy_stress = (s10 * gwx + s11 * gwy) * INV_DX * V0
            m = 1.0
            tomv_x = w * (m * affx + DT * (m * 0.0 - fx_stress))
            tomv_y = w * (m * affy + DT * (m * GRAV - fy_stress))
            node = (bx + ox) * G + (by + oy)
            q = p * 9 + k
            tl.store(src_ptr + 3 * q, w * m)
            tl.store(src_ptr + 3 * q + 1, tomv_x)
            tl.store(src_ptr + 3 * q + 2, tomv_y)
            tl.store(idx_ptr + q, node)


@tl.kernel
def _grid_kernel(g_ptr, G, BLOCK: tl.constexpr):
    """v = p/m where m > 0; the 3 outer node rings are hard walls.
    Grid layout: flat (G*G, 3) rows [mass, momentum_x, momentum_y]."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < G * G
    mass = tl.load(g_ptr + offs * 3, mask=m, other=0.0)
    px = tl.load(g_ptr + offs * 3 + 1, mask=m, other=0.0)
    py = tl.load(g_ptr + offs * 3 + 2, mask=m, other=0.0)
    invm = tl.where(mass > 1e-8, 1.0 / mass, 0.0)
    vx = px * invm
    vy = py * invm
    idx = tl.cast(offs, tl.int32)
    nx = idx // G
    ny = idx - nx * G
    wall = (nx < 3) | (nx > G - 4) | (ny < 3) | (ny > G - 4)
    vx = tl.where(wall, 0.0, vx)
    vy = tl.where(wall, 0.0, vy)
    tl.store(g_ptr + offs * 3 + 1, vx, mask=m)
    tl.store(g_ptr + offs * 3 + 2, vy, mask=m)


@tl.kernel
def _g2p_kernel(x_ptr, v_ptr, c_ptr, f_ptr, g_ptr, N, G,
                DX, INV_DX, DT, BLOCK: tl.constexpr):
    """Per particle: one pass -> v_new, C_new (MLS), x advance, F update
    F = (I + dt C) F."""
    p = tl.program_id(0)
    xp = tl.load(x_ptr + 2 * p)
    yp = tl.load(x_ptr + 2 * p + 1)
    bx = tl.cast(xp * INV_DX - 0.5, tl.int32)
    by = tl.cast(yp * INV_DX - 0.5, tl.int32)
    fxx = xp * INV_DX - tl.cast(bx, tl.float32)
    fyy = yp * INV_DX - tl.cast(by, tl.float32)
    wx0 = 0.5 * (1.5 - fxx) * (1.5 - fxx)
    wx1 = 0.75 - (fxx - 1.0) * (fxx - 1.0)
    wx2 = 0.5 * (fxx - 0.5) * (fxx - 0.5)
    wy0 = 0.5 * (1.5 - fyy) * (1.5 - fyy)
    wy1 = 0.75 - (fyy - 1.0) * (fyy - 1.0)
    wy2 = 0.5 * (fyy - 0.5) * (fyy - 0.5)
    nvx = 0.0
    nvy = 0.0
    a00 = 0.0
    a01 = 0.0
    a10 = 0.0
    a11 = 0.0
    for ox in range(0, 3):
        for oy in range(0, 3):
            wx = tl.where(ox == 0, wx0, tl.where(ox == 1, wx1, wx2))
            wy = tl.where(oy == 0, wy0, tl.where(oy == 1, wy1, wy2))
            w = wx * wy
            node = (bx + ox) * G + (by + oy)
            vgx = tl.load(g_ptr + node * 3 + 1)
            vgy = tl.load(g_ptr + node * 3 + 2)
            gx = tl.cast(bx + ox, tl.float32) * DX
            gy = tl.cast(by + oy, tl.float32) * DX
            dX = gx - xp
            dY = gy - yp
            nvx += w * vgx
            nvy += w * vgy
            # MLS affine matrix: C = B . D^{-1}, D = dx^2/4 I  ->
            # C = 4 * inv_dx^2 * sum w v_g (x_g - x_p)^T
            a00 += w * vgx * dX
            a01 += w * vgx * dY
            a10 += w * vgy * dX
            a11 += w * vgy * dY
    k = 4.0 * INV_DX * INV_DX
    c00 = a00 * k
    c01 = a01 * k
    c10 = a10 * k
    c11 = a11 * k
    xp_new = xp + DT * nvx
    yp_new = yp + DT * nvy
    tl.store(v_ptr + 2 * p, nvx)
    tl.store(v_ptr + 2 * p + 1, nvy)
    tl.store(x_ptr + 2 * p, xp_new)
    tl.store(x_ptr + 2 * p + 1, yp_new)
    tl.store(c_ptr + 4 * p, c00)
    tl.store(c_ptr + 4 * p + 1, c01)
    tl.store(c_ptr + 4 * p + 2, c10)
    tl.store(c_ptr + 4 * p + 3, c11)
    f00 = tl.load(f_ptr + 4 * p)
    f01 = tl.load(f_ptr + 4 * p + 1)
    f10 = tl.load(f_ptr + 4 * p + 2)
    f11 = tl.load(f_ptr + 4 * p + 3)
    # F_new = (I + dt C) F
    e00 = 1.0 + DT * c00
    e01 = DT * c01
    e10 = DT * c10
    e11 = 1.0 + DT * c11
    tl.store(f_ptr + 4 * p, e00 * f00 + e01 * f10)
    tl.store(f_ptr + 4 * p + 1, e00 * f01 + e01 * f11)
    tl.store(f_ptr + 4 * p + 2, e10 * f00 + e11 * f10)
    tl.store(f_ptr + 4 * p + 3, e10 * f01 + e11 * f11)



# ---------------------------------------------------------------------------
# driver
# ---------------------------------------------------------------------------

class MPMWorld:
    """MLS-MPM world: particles on a G x G grid over [0, 1]^2."""

    def __init__(self, n: int = 16384, G: int = 128, dt: float = 5e-4,
                 mu: float = 5e2, lam: float = 5e3, v0_scale: float = 1.0,
                 seed: int = 0, device: str = "cuda"):
        self.G = int(G)
        self.dx = 1.0 / self.G
        self.inv_dx = float(self.G)
        self.dt = float(dt)
        self.mu, self.lam = float(mu), float(lam)
        self.device = device
        rng = np.random.default_rng(seed)
        # blob: disc, center (0.5, 0.6), radius scaled to n at dx lattice
        r_blob = 0.20
        ang = rng.uniform(0, 2 * np.pi, n)
        rad = r_blob * np.sqrt(rng.uniform(0.0, 1.0, n))
        xp = (0.5 + rad * np.cos(ang)).astype(np.float32)
        yp = (0.6 + rad * np.sin(ang)).astype(np.float32)
        self.n = int(n)
        area = np.pi * r_blob * r_blob
        self.v0 = v0_scale * area / self.n    # per-particle volume
        d = lambda a: tl.tensor(np.ascontiguousarray(a), device=device)
        x = np.stack([xp, yp], axis=1).astype(np.float32)
        v = np.tile(np.array([0.0, -1.5], np.float32), (self.n, 1))
        self.x, self.v = d(x), d(v)
        self.c = d(np.zeros((self.n, 4), np.float32))
        f0 = np.tile(np.array([1.0, 0.0, 0.0, 1.0], np.float32), (self.n, 1))
        self.f = d(f0)
        gg = self.G * self.G
        self.src = tl.zeros((9 * self.n, 3), tl.float32, device)
        self.nidx = tl.zeros(9 * self.n, tl.int32, device)
        self.g = None
        self.step_count = 0

    def _p2g(self):
        n = self.n
        _p2g_src_kernel[(n,)](
            self.x._buffer_arg(), self.v._buffer_arg(), self.c._buffer_arg(),
            self.f._buffer_arg(), self.src._buffer_arg(),
            self.nidx._buffer_arg(), n, self.G, self.dx, self.inv_dx,
            self.dt, self.mu, self.lam, self.v0, BLOCK=1, num_warps=1)
        # P2G grid accumulation straight through the scatter_add primitive
        self.g = sparse.scatter_add(self.src, self.nidx, (self.G * self.G, 3))

    def step(self):
        n = self.n
        self._p2g()
        _grid_kernel[((self.G * self.G + 255) // 256,)](
            self.g._buffer_arg(), self.G, BLOCK=256, num_warps=4)
        _g2p_kernel[(n,)](
            self.x._buffer_arg(), self.v._buffer_arg(), self.c._buffer_arg(),
            self.f._buffer_arg(), self.g._buffer_arg(), n, self.G,
            self.dx, self.inv_dx, self.dt, BLOCK=1, num_warps=1)
        self.step_count += 1

    # -- stats ---------------------------------------------------------------

    def grid_mass(self) -> float:
        if self.g is None:
            return 0.0
        return float(self.g[:, 0].sum().numpy())

    def mean_j(self) -> float:
        det = self.f[:, 0] * self.f[:, 3] - self.f[:, 1] * self.f[:, 2]
        return float(det.mean().numpy())

    def finite(self) -> bool:
        return bool(np.isfinite(self.x.numpy()).all()
                    and np.isfinite(self.f.numpy()).all())

    def frame(self, buf: viz.PixelBuffer):
        if self.g is None:
            self._p2g()
        mass = self.g[:, 0].contiguous().reshape((self.G, self.G))
        viz.heatmap(buf, mass, cmap="viridis", vmin=0.0, vmax=8.0)
        viz.particles(buf, self.x[:, 0], self.x[:, 1],
                      color=(0.95, 0.95, 0.95), radius=0, y_up=True)
        return buf


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--n", type=int, default=16384)
    p.add_argument("--steps", type=int, default=200)
    p.add_argument("--dt", type=float, default=5e-4)
    p.add_argument("--mu", type=float, default=5e2)
    p.add_argument("--lam", type=float, default=5e3)
    p.add_argument("--frames", type=str, default=None)
    p.add_argument("--display", action="store_true")
    p.add_argument("--bench", action="store_true")
    p.add_argument("--stats", type=int, default=25)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    world = MPMWorld(n=args.n, dt=args.dt, mu=args.mu, lam=args.lam,
                     seed=args.seed)
    mass0 = None  # measured after the first P2G
    print(f"MLS-MPM: n={world.n} grid={world.G}x{world.G} dx={world.dx:.4f} "
          f"dt={world.dt:.1e} mu={world.mu:g} lam={world.lam:g} "
          f"v0={world.v0:.3e}")

    win = buf = None
    if not args.bench:
        buf = viz.PixelBuffer(480, 480)
        win = viz.Window(480, 480, title="mpm_demo (MLS-MPM)",
                         frames_dir=args.frames, display=args.display,
                         fps=60, max_frames=args.steps)
        if win.mode == "frames":
            print(f"frames -> {win.frames_dir}")

    t0 = time.perf_counter()
    done = 0
    for s in range(args.steps):
        if win is not None:
            act = win.show(world.frame(buf))
            if act == "quit":
                break
            if act == "paused":
                continue
        world.step()
        done += 1
        if mass0 is None:
            mass0 = world.grid_mass()
        if args.stats and (s + 1) % args.stats == 0:
            el = time.perf_counter() - t0
            gm = world.grid_mass()
            print(f"step {s + 1:5d}  {done / el:7.1f} steps/s  "
                  f"grid_mass={gm:.3f} ({(gm - mass0) / max(mass0, 1e-12):+.2e})  "
                  f"meanJ={world.mean_j():.4f}")
    tl.synchronize()
    el = time.perf_counter() - t0
    gm = world.grid_mass()
    drift = abs(gm - (mass0 if mass0 is not None else gm)) / max(
        mass0 or 1.0, 1e-12)
    ok_fin = world.finite()
    print(f"DONE n={world.n} steps={done} wall={el:.2f}s "
          f"-> {done / el:.1f} sim-steps/s  (finite={ok_fin})")
    print(f"sanity: mass {mass0:.4f} -> {gm:.4f} (drift {drift:.2e}, "
          f"want < 1%), meanJ={world.mean_j():.4f}")
    if win is not None:
        win.close()
    return 0 if ok_fin and drift < 0.01 else 1


if __name__ == "__main__":
    sys.exit(main())
