#!/usr/bin/env python
"""Train a nanochat-scale char-level GPT on the
MiniTriton repo's own source code (minitriton/**/*.py, self-contained,
no network), fp32. ``--ddp``: NCCL data-parallel over
``--ddp-nproc`` GPUs (grad allreduce once per step, averaged ranks).

Model: GPT-2-small-class decoder (12 layers / 12 heads / 768 embd,
~85M params with a char vocab; block 512 default, 256 configurable).
Forward uses the fused flash-attention kernel; backward is the unfused
composite. Optimizer: fused AdamW + clip_grad_norm. ``--tf32`` routes
matmul + attention through the tf32 tensor-core kernels; ``--mixed``
(alias ``--bf16``) runs bf16 mixed
precision: BF16AdamW over fp32 master weights + GradScaler dynamic loss
scaling + Linear matmul fwd+bwd on the bf16 mma kernels + attention at
precision="bf16" (fused bf16 forward, native bf16 mma backward;
MT_ATTN_BWD_F32=1 opts into the fused f32-on-upcasts backward);
LN/CE/residual stream stay fp32 (the torch AMP boundary).

    CUDA_VISIBLE_DEVICES=1 python examples/train_gpt.py --steps 2000
    CUDA_VISIBLE_DEVICES=3 python examples/train_gpt.py --mixed --steps 500
    CUDA_VISIBLE_DEVICES=1,2 python examples/train_gpt.py --ddp --steps 500 \
        --batch-size 64

Prints per-step loss + tokens/s, writes examples/train_gpt_loss.png.
A torch-eager throughput baseline for the same config lives in
benchmarks/training/train_gpt_bench.py.
"""

import argparse
import math
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl
from minitriton import nn


# ---------------------------------------------------------------------------
# data: the repo's own source as a char-level corpus
# ---------------------------------------------------------------------------

def load_corpus(root: Path):
    text = ""
    for p in sorted(root.rglob("*.py")):
        text += p.read_text() + "\n"
    chars = sorted(set(text))
    stoi = {c: i for i, c in enumerate(chars)}
    data = np.array([stoi[c] for c in text], dtype=np.int32)
    return data, len(chars), stoi


def get_batch(data: np.ndarray, batch: int, block: int, rng):
    ix = rng.integers(0, len(data) - block - 1, size=batch)
    x = np.stack([data[i:i + block] for i in ix])
    y = np.stack([data[i + 1:i + block + 1] for i in ix])
    return x, y


# ---------------------------------------------------------------------------
# model
# ---------------------------------------------------------------------------

class Block(nn.Module):
    def __init__(self, cfg, seed):
        super().__init__()
        self.cfg = cfg
        self.ln1 = nn.LayerNorm(cfg.n_embd, device=cfg.device)
        self.attn = nn.CausalSelfAttention(
            cfg.n_embd, cfg.n_head, device=cfg.device, seed=seed,
            precision="bf16" if cfg.bf16 else None)
        self.ln2 = nn.LayerNorm(cfg.n_embd, device=cfg.device)
        self.fc = nn.Linear(cfg.n_embd, 4 * cfg.n_embd, device=cfg.device,
                            seed=seed + 1)
        self.proj = nn.Linear(4 * cfg.n_embd, cfg.n_embd, device=cfg.device,
                              seed=seed + 2)
        self.proj.reinit_(0.02 / (2 * cfg.n_layer) ** 0.5, seed=seed + 3)

    def forward(self, x):
        x = x + self.attn(_mm_in(self.ln1, x, self.cfg))
        return x + self.proj(tl.gelu(self.fc(_mm_in(self.ln2, x, self.cfg))))


def _mm_in(ln_module, x, cfg):
    """LayerNorm (fp32) feeding the bf16 matmul interior: the residual
    stream stays fp32 (torch AMP's boundary); LN weights are fp32; the
    bf16 seam is the LN kernel's own pack-on-store (identical rounding
    to LN-fp32 -> astype-bf16, without the materialized cast). Identity
    in fp32 mode."""
    if not cfg.bf16:
        return ln_module(x)
    return ln_module(x, out_dtype=tl.bfloat16)


class GPT(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.wte = nn.Embedding(cfg.vocab_size, cfg.n_embd,
                                device=cfg.device, seed=0)
        self.wpe = nn.Embedding(cfg.block_size, cfg.n_embd,
                                device=cfg.device, seed=1)
        self.blocks = [Block(cfg, seed=10 + 4 * i)
                       for i in range(cfg.n_layer)]
        for i, b in enumerate(self.blocks):
            setattr(self, f"block{i}", b)
        self.ln_f = nn.LayerNorm(cfg.n_embd, device=cfg.device)
        self.lm_head = nn.Linear(cfg.n_embd, cfg.vocab_size, bias=False,
                                 device=cfg.device, seed=2)
        self.lm_head.weight = self.wte.weight  # tied embeddings (nanoGPT)
        self.criterion = nn.CrossEntropyLoss()
        self._pos_cache = {}

    def _pos(self, t, device):
        """Position indices, cached per block size: the arange is constant,
        and re-uploading it every step is both a host sync and a CUDA
        graph capture violation."""
        p = self._pos_cache.get(t)
        if p is None:
            p = tl.arange(t, dtype=tl.int64, device=device)
            self._pos_cache[t] = p
        return p

    def forward(self, idx, targets=None):
        b, t = idx.shape
        pos = self._pos(t, idx.device)
        x = self.wte(idx) + self.wpe(pos)
        for blk in self.blocks:
            x = blk(x)
        if self.cfg.bf16:
            # lm_head is tied to wte, which stays fp32 in bf16 mode:
            # fp32 LN -> fp32 classifier matmul (fused with the CE seam)
            logits = self.lm_head(self.ln_f(x))
        else:
            logits = self.lm_head(_mm_in(self.ln_f, x, self.cfg))
        if targets is None:
            return logits
        if self.cfg.bf16 and logits.dtype != tl.float32:
            # CE at the fp32 boundary
            logits = logits.astype(tl.float32)
        return self.criterion(logits, targets)

    def num_params(self):
        return sum(p.numel() for p in self.parameters())


class Cfg:
    device = "cuda"
    vocab_size = 0
    block_size = 512
    n_layer = 12
    n_head = 12
    n_embd = 768
    bf16 = False


def _convert_bf16_(module: nn.Module, fp32_orig: dict | None = None):
    """Cast parameters to bf16 in place, EXCEPT LayerNorm's (fp32 compute
    boundary) and Embedding's: the tied embedding table drives both the
    token features and the lm_head classifier; keeping it fp32 costs a
    vocab-sized fp32 matmul only (negligible at this corpus vocab) and removes
    a forward-side divergence source (torch AMP keeps embeddings fp32
    too). Tied weights are cast once.

    Returns ``fp32_orig``: {id(param): pre-conversion fp32 copy}, to be
    handed to BF16AdamW(masters=...). Initializing the fp32 masters from
    the unrounded weights matters: if the master is quantized at init,
    coherent updates smaller than half a bf16 ulp round away on the param
    instead of accumulating under the quantization floor — measurable as
    a ~0.3-nat step-1 loss shift (mimicking stalled training) followed
    by a persistent trajectory offset."""
    if fp32_orig is None:
        fp32_orig = {}
    if not isinstance(module, (nn.LayerNorm, nn.Embedding)):
        for p in list(module._parameters.values()):
            if p.dtype == tl.bfloat16:
                continue
            with tl.no_grad():
                fp32_orig[id(p)] = p.detach() * 1.0  # exact fp32 copy
                p._steal(p.astype(tl.bfloat16))
            p.requires_grad = True
            p.grad = None
    for m in module._modules.values():
        _convert_bf16_(m, fp32_orig)
    return fp32_orig


# ---------------------------------------------------------------------------
# training
# ---------------------------------------------------------------------------

def lr_at(step, total, base, warmup=100, floor_ratio=0.1):
    if step < warmup:
        return base * (step + 1) / warmup
    t = (step - warmup) / max(1, total - warmup)
    return base * (floor_ratio + (1 - floor_ratio)
                   * 0.5 * (1 + np.cos(np.pi * t)))


def train(args, rank: int = 0, world: int = 1):
    """One training run. In DDP mode (world > 1) ``--batch-size`` is the
    GLOBAL batch: every rank draws the same batch from the same-seeded rng
    and trains on its contiguous shard; grads are averaged by
    ``ddp.sync_grads()`` and the logged loss is the global-batch mean — so
    the trajectory matches a single-GPU run at the same global batch."""
    from minitriton import distributed as dist

    cfg = Cfg()
    cfg.block_size = args.block_size
    cfg.n_layer = args.n_layer
    cfg.n_head = args.n_head
    cfg.n_embd = args.n_embd

    repo = Path(__file__).resolve().parents[1]
    data, vocab_size, _ = load_corpus(repo / "minitriton")
    cfg.vocab_size = vocab_size
    if rank == 0:
        print(f"corpus: {len(data)} chars, vocab {vocab_size}; "
              f"expected initial loss ~ln(vocab) = {np.log(vocab_size):.2f}")

    if args.batch_size % world != 0:
        raise ValueError(
            f"--batch-size {args.batch_size} must be divisible by the "
            f"world size {world}")
    local_batch = args.batch_size // world

    _apply_precision_mode(args)
    rng = np.random.default_rng(args.seed)
    cfg.bf16 = args.bf16
    model = GPT(cfg)
    fp32_orig = _convert_bf16_(model) if args.bf16 else None
    n_params = model.num_params()
    ddp = None
    if world > 1:
        ddp = dist.DistributedDataParallel(model)
    fwd = ddp if ddp is not None else model
    if rank == 0:
        print(f"model: {n_params / 1e6:.1f}M params, block {cfg.block_size}, "
              f"batch {args.batch_size} "
              f"({args.batch_size * cfg.block_size} tokens/step)"
              + (f", DDP world={world}, local batch {local_batch}"
                 if world > 1 else ""))

    if args.bf16:
        opt = nn.BF16AdamW(model.parameters(), lr=args.lr,
                           betas=(0.9, 0.95), weight_decay=0.1,
                           masters=fp32_orig)
        scaler = nn.GradScaler()
    else:
        opt = nn.AdamW(model.parameters(), lr=args.lr, betas=(0.9, 0.95),
                       weight_decay=0.1)
        scaler = None
    tl.reset_peak_stats()

    losses = []
    scaler_rows = []
    t_start = time.perf_counter()
    t_mark = t_start
    tokens_mark = 0
    for step in range(args.steps):
        lr = lr_at(step, args.steps, args.lr)
        opt.lr = lr
        x, y = get_batch(data, args.batch_size, cfg.block_size, rng)
        if world > 1:
            h = local_batch
            x = x[rank * h:(rank + 1) * h]
            y = y[rank * h:(rank + 1) * h]
        xb = tl.tensor(x, device=cfg.device)
        yb = tl.tensor(y, device=cfg.device)
        loss = fwd(xb, yb)
        model.zero_grad()
        (scaler.scale_loss(loss) if scaler is not None else loss).backward()
        if ddp is not None:
            ddp.sync_grads()
        skipped = False
        if scaler is not None:
            scaler.unscale_(model.parameters())
            if args.inject_nan == step:
                for p in model.parameters():
                    if p.grad is not None:
                        p.grad = p.grad * 1e30  # -> non-finite total norm
                        break
            total = nn.clip_grad_norm(model.parameters(), 1.0)
            finite = math.isfinite(total)
            if finite:
                opt.step()
            else:
                # NaN/Inf grads: skip the step and purge them (staleness
                # guard — nothing from this backward may leak into the
                # next), the scaler backoffs below
                model.zero_grad()
                skipped = True
            scaler.update(not finite)
        else:
            nn.clip_grad_norm(model.parameters(), 1.0)
            opt.step()
        lv = loss.item()
        if world > 1:
            # global-batch mean loss (equal shards): one tiny allreduce
            lt = tl.tensor([lv], device=cfg.device)
            dist.get_process_group().allreduce(lt)
            lv = lt.item() / world
        losses.append(lv)
        if scaler is not None:
            scaler_rows.append(
                (step, lv, scaler.scale, 1 if skipped else 0))
        tokens_mark += args.batch_size * cfg.block_size
        if step % args.log_every == 0 or step == args.steps - 1:
            now = time.perf_counter()
            tps = tokens_mark / (now - t_mark) if now > t_mark else 0.0
            if rank == 0:
                extra = ""
                if scaler is not None:
                    extra = (f" | scale {scaler.scale:g}"
                             + (" | SKIPPED (non-finite grads)"
                                if skipped else ""))
                print(f"step {step:5d} | loss {lv:8.4f} | lr {lr:.2e} | "
                      f"{tps / 1e3:7.1f}K tok/s | {now - t_start:7.1f}s"
                      + extra)
            t_mark = now
            tokens_mark = 0

    total_t = time.perf_counter() - t_start
    total_tokens = args.steps * args.batch_size * cfg.block_size
    if rank == 0:
        print(f"\n{args.steps} steps in {total_t:.1f}s -> "
              f"{total_tokens / total_t / 1e3:.1f}K tok/s avg, "
              f"loss {losses[0]:.4f} -> {losses[-1]:.4f}")
        stats = tl.memory_stats()
        print(f"allocator peak: allocated "
              f"{stats['peak_allocated_bytes'] / 2**30:.2f} GiB, reserved "
              f"{stats['peak_reserved_bytes'] / 2**30:.2f} GiB")

    if rank == 0 and args.loss_csv:
        csv_path = repo / args.loss_csv
        with open(csv_path, "w") as f:
            f.write("step,loss\n")
            for i, lv in enumerate(losses):
                f.write(f"{i},{lv}\n")
        print(f"loss csv -> {csv_path}")

    if rank == 0 and args.scaler_csv:
        csv_path = repo / args.scaler_csv
        with open(csv_path, "w") as f:
            f.write("step,loss,scale,skipped\n")
            for s, lv, sc, sk in scaler_rows:
                f.write(f"{s},{lv:.6f},{sc:.6g},{sk}\n")
        n_skipped = sum(r[3] for r in scaler_rows)
        print(f"scaler csv -> {csv_path} "
              f"({n_skipped} skipped steps, final scale "
              f"{scaler_rows[-1][2]:g})")

    if rank == 0:
        # loss curve
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(losses, lw=1.2)
        ax.axhline(np.log(vocab_size), ls="--", c="gray", lw=1,
                   label=f"ln(vocab)={np.log(vocab_size):.2f}")
        ax.set_xlabel("step")
        ax.set_ylabel("cross entropy")
        ax.set_title(f"train_gpt: {n_params / 1e6:.0f}M params, block "
                     f"{cfg.block_size}, "
                     f"{'bf16' if cfg.bf16 else 'fp32'}, minitriton"
                     + (f", DDP x{world}" if world > 1 else ""))
        ax.legend()
        ax.grid(alpha=0.3)
        fig.tight_layout()
        out = repo / args.out
        fig.savefig(out, dpi=120)
        print(f"loss curve -> {out}")
    if world > 1:
        dist.destroy_process_group()
    return losses


def _ddp_worker(rank, world, args):
    """distributed.launch entry: rendezvous env is injected by launch."""
    from minitriton import distributed as dist
    dist.init_process_group()
    train(args, rank=rank, world=world)


def _apply_precision_mode(args):
    if getattr(args, "bf16", False):
        # params bf16, activations bf16 inside the matmul interior (mma
        # by dtype routing); fp32 residual stream / LN / CE; attention
        # forward bf16 mma, backward native bf16 mma (MT_ATTN_BWD_F32=1
        # opts into the fused f32 kernels on upcasts).
        # Matmuls that stay fp32 (tied lm_head) stay exact-fp32.
        print("[precision] mixed (bf16 AMP): bf16 params + fp32 masters "
              "+ dynamic loss scaling; bf16 mma matmul fwd+bwd + bf16 "
              "flash attention fwd")
    elif getattr(args, "tf32", False):
        import minitriton.device.cuda.ops as _be
        _be.set_allow_tf32(True)
        print("[precision] tf32 matmul (allow_tf32) + tf32 flash attention")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=2000)
    ap.add_argument("--batch-size", type=int, default=32,
                    help="global batch (--ddp: split evenly over ranks)")
    ap.add_argument("--block-size", type=int, default=512)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--n-layer", type=int, default=12)
    ap.add_argument("--n-head", type=int, default=12)
    ap.add_argument("--n-embd", type=int, default=768)
    ap.add_argument("--seed", type=int, default=1337)
    ap.add_argument("--log-every", type=int, default=50)
    ap.add_argument("--out", type=str, default="examples/train_gpt_loss.png")
    ap.add_argument("--tf32", action="store_true",
                    help="tf32 matmul + tf32 flash attention (tensor core)")
    ap.add_argument("--mixed", action="store_true",
                    help="mixed-precision tier: BF16AdamW over fp32 master weights "
                         "+ GradScaler dynamic loss scaling + Linear matmul "
                         "fwd+bwd on bf16 mma + attention precision=bf16; "
                         "LN/CE/residual stream stay fp32 (torch AMP "
                         "boundary)")
    ap.add_argument("--bf16", action="store_true",
                    help="alias of --mixed")
    ap.add_argument("--loss-csv", type=str, default="",
                    metavar="PATH",
                    help="also dump every step's (global-mean) loss as a "
                         "step,loss CSV (path relative to the repo root)")
    ap.add_argument("--scaler-csv", type=str, default="",
                    metavar="PATH",
                    help="mixed mode only: dump per-step GradScaler dynamics "
                         "as step,loss,scale,skipped rows (path relative "
                         "to the repo root)")
    ap.add_argument("--inject-nan", type=int, default=-1, metavar="STEP",
                    help="test hook: at STEP, multiply one grad by 1e30 "
                         "after unscale_ (forces a non-finite grad norm, "
                         "exercising the GradScaler skip + backoff path)")
    ap.add_argument("--ddp", action="store_true",
                    help="data-parallel over --ddp-nproc GPUs via NCCL "
                         "(CUDA_VISIBLE_DEVICES selects them)")
    ap.add_argument("--ddp-nproc", type=int, default=2)
    args = ap.parse_args()
    args.bf16 = args.bf16 or args.mixed
    if args.tf32 and args.bf16:
        ap.error("--tf32 and --mixed/--bf16 are mutually exclusive")
    if args.scaler_csv and not args.bf16:
        ap.error("--scaler-csv requires --mixed/--bf16")

    if args.ddp:
        from minitriton import distributed as dist
        dist.launch(_ddp_worker, args.ddp_nproc, args=(args,))
        return
    train(args)


if __name__ == "__main__":
    main()
