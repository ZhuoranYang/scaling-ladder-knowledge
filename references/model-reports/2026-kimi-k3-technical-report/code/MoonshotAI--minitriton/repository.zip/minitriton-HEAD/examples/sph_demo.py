#!/usr/bin/env python
"""2D PBD fluid (Position-Based Dynamics, Macklin et
al. 2013) on MiniTriton tensors. Physical model choices:

- Predict v += g*dt, x* = x + v*dt; density constraint lambda solved on
  x*; position correction dx; velocity from (x_new - x_old)/dt; XSPH
  artificial viscosity. One constraint iteration per step (demo-grade
  incompressibility, very stable).
- 2D poly6 density kernel W = (4/(pi h^8)) (h^2 - r^2)^3 and 2D spiky
  gradient |grad W| = (30/(pi h^5)) (h - r)^2 along -r_hat.
- Uniform-grid cell list EVERY step: cell id kernel -> sparse.coo_sort_by_key
  (bitonic) -> sparse.searchsorted segment bounds; neighbor loops read
  the segments directly (never a pair list).
- Rest density rho0 is calibrated on the initial block (mean of the
  density pass with rho0 := 1) — assert-checkable density sanity.

    CUDA_VISIBLE_DEVICES=1 python examples/sph_demo.py --steps 400 \
        --frames /tmp/sph
    CUDA_VISIBLE_DEVICES=1 python examples/sph_demo.py --bench  (no viz)

Prints steps/s; with --frames writes frame_%05d.png per step.
"""

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl
from minitriton import sparse, viz

GRAV = -9.8
SCORR_K = 0.0  # tensile-stability term OFF by default: any nonzero value
               # sustained a saturated pumped state in the pond config
               # (rho/KE inflate without bound at SK>0, perfect pond at
               # SK=0). Re-enable only for clumping scenarios and re-measure.
SCORR_N = 4
XSPH_C = 0.3


# ---------------------------------------------------------------------------
# kernels
# ---------------------------------------------------------------------------

@tl.kernel
def _predict_kernel(x_ptr, y_ptr, vx_ptr, vy_ptr, xp_ptr, yp_ptr, N, DT, GX,
                    GY, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    vx = tl.load(vx_ptr + offs, mask=m, other=0.0)
    vy = tl.load(vy_ptr + offs, mask=m, other=0.0)
    x = tl.load(x_ptr + offs, mask=m, other=0.0)
    y = tl.load(y_ptr + offs, mask=m, other=0.0)
    vx = vx + GX * DT
    vy = vy + GY * DT
    tl.store(xp_ptr + offs, x + vx * DT, mask=m)
    tl.store(yp_ptr + offs, y + vy * DT, mask=m)
    tl.store(vx_ptr + offs, vx, mask=m)
    tl.store(vy_ptr + offs, vy, mask=m)


@tl.kernel
def _cell_id_kernel(x_ptr, y_ptr, cid_ptr, N, INV_CELL, GW, GH, DOMW, DOMH,
                    BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m, other=0.0)
    y = tl.load(y_ptr + offs, mask=m, other=0.0)
    cx = tl.cast(x * INV_CELL, tl.int32)
    cy = tl.cast(y * INV_CELL, tl.int32)
    cx = tl.where(cx < 0, 0, cx)
    cx = tl.where(cx > GW - 1, GW - 1, cx)
    cy = tl.where(cy < 0, 0, cy)
    cy = tl.where(cy > GH - 1, GH - 1, cy)
    tl.store(cid_ptr + offs, cy * GW + cx, mask=m)


@tl.kernel
def _lambda_kernel(xp_ptr, yp_ptr, rp_ptr, perm_ptr, lam_ptr, rho_ptr,
                   N, GW, GH, INV_CELL, H, H2, POLY6, SPIKY, RHO0, EPSR,
                   BLOCK: tl.constexpr):
    """Per particle: rho_i = sum W_poly6; lambda_i = -C/(grad^2 sum + eps),
    C = rho_i/rho0 - 1 (PBD density). One program per particle, lanes walk
    the neighbor cell segments in blocks of BLOCK."""
    i = tl.program_id(0)
    xi = tl.load(xp_ptr + i)
    yi = tl.load(yp_ptr + i)
    cx = tl.cast(xi * INV_CELL, tl.int32)
    cy = tl.cast(yi * INV_CELL, tl.int32)
    cx = tl.where(cx < 0, 0, cx)
    cx = tl.where(cx > GW - 1, GW - 1, cx)
    cy = tl.where(cy < 0, 0, cy)
    cy = tl.where(cy > GH - 1, GH - 1, cy)
    acc = tl.zeros((BLOCK,), tl.float32)
    gax = tl.zeros((BLOCK,), tl.float32)
    gay = tl.zeros((BLOCK,), tl.float32)
    ga2 = tl.zeros((BLOCK,), tl.float32)
    offs = tl.arange(0, BLOCK)
    for ddy in range(-1, 2):
        for ddx in range(-1, 2):
            cx2 = cx + ddx
            cy2 = cy + ddy
            ok = (cx2 >= 0) & (cx2 < GW) & (cy2 >= 0) & (cy2 < GH)
            ccx = tl.where(ok, cx2, 0)
            ccy = tl.where(ok, cy2, 0)
            nb = ccy * GW + ccx
            s = tl.load(rp_ptr + nb)
            e = tl.load(rp_ptr + nb + 1)
            seg = tl.where(ok, e - s, 0)
            for k0 in range(0, seg, BLOCK):
                jm = (k0 + offs) < seg
                j = tl.load(perm_ptr + s + k0 + offs, mask=jm, other=N)
                xj = tl.load(xp_ptr + j, mask=jm, other=1e9)
                yj = tl.load(yp_ptr + j, mask=jm, other=1e9)
                rx = xi - xj
                ry = yi - yj
                q2 = rx * rx + ry * ry
                within = q2 < H2
                tt = H2 - q2
                w = tl.where(within, POLY6 * tt * tt * tt, 0.0)
                acc = acc + w
                r = tl.sqrt(q2)
                hr = H - r
                gn = -SPIKY * hr * hr / (r + 1e-9)
                gx = tl.where(within, gn * rx, 0.0)
                gy = tl.where(within, gn * ry, 0.0)
                gax = gax + gx
                gay = gay + gy
                ga2 = ga2 + gx * gx + gy * gy
    rho = tl.sum(acc)
    sgx = tl.sum(gax)
    sgy = tl.sum(gay)
    sg2 = tl.sum(ga2)
    c = rho / RHO0 - 1.0
    denom = (sgx * sgx + sgy * sgy + sg2) / (RHO0 * RHO0)
    lam = -c / (denom + EPSR)
    tl.store(lam_ptr + i, lam)
    tl.store(rho_ptr + i, rho)


@tl.kernel
def _dx_kernel(xp_ptr, yp_ptr, lam_ptr, rp_ptr, perm_ptr, dx_ptr, dy_ptr,
               N, GW, GH, INV_CELL, H, H2, POLY6, SPIKY, RHO0, INV_WDQ,
               SK, DXC, BLOCK: tl.constexpr):
    """dx_i = (1/rho0) * sum_j (lam_i + lam_j + s_corr) * grad W_ij."""
    i = tl.program_id(0)
    xi = tl.load(xp_ptr + i)
    yi = tl.load(yp_ptr + i)
    li = tl.load(lam_ptr + i)
    cx = tl.cast(xi * INV_CELL, tl.int32)
    cy = tl.cast(yi * INV_CELL, tl.int32)
    cx = tl.where(cx < 0, 0, cx)
    cx = tl.where(cx > GW - 1, GW - 1, cx)
    cy = tl.where(cy < 0, 0, cy)
    cy = tl.where(cy > GH - 1, GH - 1, cy)
    ax = tl.zeros((BLOCK,), tl.float32)
    ay = tl.zeros((BLOCK,), tl.float32)
    offs = tl.arange(0, BLOCK)
    for ddy in range(-1, 2):
        for ddx in range(-1, 2):
            cx2 = cx + ddx
            cy2 = cy + ddy
            ok = (cx2 >= 0) & (cx2 < GW) & (cy2 >= 0) & (cy2 < GH)
            ccx = tl.where(ok, cx2, 0)
            ccy = tl.where(ok, cy2, 0)
            nb = ccy * GW + ccx
            s = tl.load(rp_ptr + nb)
            e = tl.load(rp_ptr + nb + 1)
            seg = tl.where(ok, e - s, 0)
            for k0 in range(0, seg, BLOCK):
                jm = (k0 + offs) < seg
                j = tl.load(perm_ptr + s + k0 + offs, mask=jm, other=N)
                xj = tl.load(xp_ptr + j, mask=jm, other=1e9)
                yj = tl.load(yp_ptr + j, mask=jm, other=1e9)
                lj = tl.load(lam_ptr + j, mask=jm, other=0.0)
                rx = xi - xj
                ry = yi - yj
                q2 = rx * rx + ry * ry
                within = q2 < H2
                r = tl.sqrt(q2)
                hr = H - r
                gn = -SPIKY * hr * hr / (r + 1e-9)
                gx = tl.where(within, gn * rx, 0.0)
                gy = tl.where(within, gn * ry, 0.0)
                tt = H2 - q2
                wsc = tl.where(within, POLY6 * tt * tt * tt * INV_WDQ, 0.0)
                s2 = wsc * wsc
                scorr = -SK * s2 * s2
                coef = tl.where(within, (li + lj + scorr) / RHO0, 0.0)
                ax = ax + coef * gx
                ay = ay + coef * gy
    dxx = tl.sum(ax)
    dyy = tl.sum(ay)
    dxx = tl.where(dxx > DXC, DXC, tl.where(dxx < -DXC, -DXC, dxx))
    dyy = tl.where(dyy > DXC, DXC, tl.where(dyy < -DXC, -DXC, dyy))
    tl.store(dx_ptr + i, dxx)
    tl.store(dy_ptr + i, dyy)


@tl.kernel
def _xsph_kernel(x_ptr, y_ptr, vx_ptr, vy_ptr, ox_ptr, oy_ptr, rp_ptr,
                 perm_ptr, N, GW, GH, INV_CELL, H2, POLY6, C,
                 BLOCK: tl.constexpr):
    """XSPH viscosity: dv_i = C * sum_j (v_j - v_i) W_poly6(r_ij)."""
    i = tl.program_id(0)
    xi = tl.load(x_ptr + i)
    yi = tl.load(y_ptr + i)
    vxi = tl.load(vx_ptr + i)
    vyi = tl.load(vy_ptr + i)
    cx = tl.cast(xi * INV_CELL, tl.int32)
    cy = tl.cast(yi * INV_CELL, tl.int32)
    cx = tl.where(cx < 0, 0, cx)
    cx = tl.where(cx > GW - 1, GW - 1, cx)
    cy = tl.where(cy < 0, 0, cy)
    cy = tl.where(cy > GH - 1, GH - 1, cy)
    ax = tl.zeros((BLOCK,), tl.float32)
    ay = tl.zeros((BLOCK,), tl.float32)
    offs = tl.arange(0, BLOCK)
    for ddy in range(-1, 2):
        for ddx in range(-1, 2):
            cx2 = cx + ddx
            cy2 = cy + ddy
            ok = (cx2 >= 0) & (cx2 < GW) & (cy2 >= 0) & (cy2 < GH)
            ccx = tl.where(ok, cx2, 0)
            ccy = tl.where(ok, cy2, 0)
            nb = ccy * GW + ccx
            s = tl.load(rp_ptr + nb)
            e = tl.load(rp_ptr + nb + 1)
            seg = tl.where(ok, e - s, 0)
            for k0 in range(0, seg, BLOCK):
                jm = (k0 + offs) < seg
                j = tl.load(perm_ptr + s + k0 + offs, mask=jm, other=N)
                xj = tl.load(x_ptr + j, mask=jm, other=1e9)
                yj = tl.load(y_ptr + j, mask=jm, other=1e9)
                vxj = tl.load(vx_ptr + j, mask=jm, other=0.0)
                vyj = tl.load(vy_ptr + j, mask=jm, other=0.0)
                rx = xi - xj
                ry = yi - yj
                q2 = rx * rx + ry * ry
                within = q2 < H2
                tt = H2 - q2
                w = tl.where(within, POLY6 * tt * tt * tt, 0.0)
                ax = ax + (vxj - vxi) * w
                ay = ay + (vyj - vyi) * w
    tl.store(ox_ptr + i, vxi + C * tl.sum(ax))
    tl.store(oy_ptr + i, vyi + C * tl.sum(ay))


@tl.kernel
def _apply_dx_kernel(xp_ptr, yp_ptr, dx_ptr, dy_ptr, N, PAD, BWX, BHY,
                     BLOCK: tl.constexpr):
    """x* += dx inside the constraint-iteration loop (with wall clamp)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    xp = tl.load(xp_ptr + offs, mask=m, other=0.0)
    yp = tl.load(yp_ptr + offs, mask=m, other=0.0)
    dx = tl.load(dx_ptr + offs, mask=m, other=0.0)
    dy = tl.load(dy_ptr + offs, mask=m, other=0.0)
    xn = xp + dx
    yn = yp + dy
    xn = tl.where(xn < PAD, PAD, xn)
    xn = tl.where(xn > BWX - PAD, BWX - PAD, xn)
    yn = tl.where(yn < PAD, PAD, yn)
    yn = tl.where(yn > BHY - PAD, BHY - PAD, yn)
    tl.store(xp_ptr + offs, xn, mask=m)
    tl.store(yp_ptr + offs, yn, mask=m)


@tl.kernel
def _finalize_kernel(x_ptr, y_ptr, xp_ptr, yp_ptr, vx_ptr,
                     vy_ptr, N, DT, PAD, BWX, BHY, VMAX, BLOCK: tl.constexpr):
    """x_new = clamp(x*); v = (x_new - x)/dt (semi-implicit), with a wall
    contact freeze and a global |v| cap (spray control)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    xo = tl.load(x_ptr + offs, mask=m, other=0.0)
    yo = tl.load(y_ptr + offs, mask=m, other=0.0)
    xp = tl.load(xp_ptr + offs, mask=m, other=0.0)
    yp = tl.load(yp_ptr + offs, mask=m, other=0.0)
    xn = xp  # constraint iterations already applied dx to x*
    yn = yp
    xr = xn
    yr = yn
    xn = tl.where(xn < PAD, PAD, xn)
    xn = tl.where(xn > BWX - PAD, BWX - PAD, xn)
    yn = tl.where(yn < PAD, PAD, yn)
    yn = tl.where(yn > BHY - PAD, BHY - PAD, yn)
    # hard walls: a clamped axis loses its velocity (inelastic contact)
    vxo = tl.where(xn != xr, 0.0, (xn - xo) / DT)
    vyo = tl.where(yn != yr, 0.0, (yn - yo) / DT)
    sp2 = vxo * vxo + vyo * vyo
    over = sp2 > VMAX * VMAX
    scl = VMAX / tl.sqrt(sp2 + 1e-12)
    vxo = tl.where(over, vxo * scl, vxo)
    vyo = tl.where(over, vyo * scl, vyo)
    tl.store(x_ptr + offs, xn, mask=m)
    tl.store(y_ptr + offs, yn, mask=m)
    tl.store(vx_ptr + offs, vxo, mask=m)
    tl.store(vy_ptr + offs, vyo, mask=m)



@tl.kernel
def _field_density_kernel(x_ptr, y_ptr, rp_ptr, perm_ptr, f_ptr, N, GW, GH,
                          INV_CELL, H, H2, POLY6, DOMW, DOMH, RGW, RGH,
                          BLOCK: tl.constexpr):
    """SPH density field sampled at one render-grid point per program:
    f[gy,gx] = sum_j poly6(|p - x_j|) over the 3x3 sim-cell neighborhood
    (same cell list and kernel as the solver's density pass)."""
    gx_id = tl.program_id(0)
    gy_id = tl.program_id(1)
    rgwf = tl.cast(RGW, tl.float32)
    rghf = tl.cast(RGH, tl.float32)
    px = (tl.cast(gx_id, tl.float32) + 0.5) * DOMW / rgwf
    py = (tl.cast(gy_id, tl.float32) + 0.5) * DOMH / rghf
    cx = tl.cast(px * INV_CELL, tl.int32)
    cy = tl.cast(py * INV_CELL, tl.int32)
    cx = tl.where(cx < 0, 0, cx)
    cx = tl.where(cx > GW - 1, GW - 1, cx)
    cy = tl.where(cy < 0, 0, cy)
    cy = tl.where(cy > GH - 1, GH - 1, cy)
    acc = tl.zeros((BLOCK,), tl.float32)
    offs = tl.arange(0, BLOCK)
    for ddy in range(-1, 2):
        for ddx in range(-1, 2):
            cx2 = cx + ddx
            cy2 = cy + ddy
            ok = (cx2 >= 0) & (cx2 < GW) & (cy2 >= 0) & (cy2 < GH)
            ccx = tl.where(ok, cx2, 0)
            ccy = tl.where(ok, cy2, 0)
            nb = ccy * GW + ccx
            s = tl.load(rp_ptr + nb)
            e = tl.load(rp_ptr + nb + 1)
            seg = tl.where(ok, e - s, 0)
            for k0 in range(0, seg, BLOCK):
                jm = (k0 + offs) < seg
                j = tl.load(perm_ptr + s + k0 + offs, mask=jm, other=N)
                xj = tl.load(x_ptr + j, mask=jm, other=1e9)
                yj = tl.load(y_ptr + j, mask=jm, other=1e9)
                rx = px - xj
                ry = py - yj
                q2 = rx * rx + ry * ry
                within = q2 < H2
                tt = H2 - q2
                acc = acc + tl.where(within, POLY6 * tt * tt * tt, 0.0)
    tl.store(f_ptr + (RGH - 1 - gy_id) * RGW + gx_id, tl.sum(acc))


@tl.kernel
def _field_blur_kernel(f_ptr, o_ptr, RGW, RGH, BLOCK: tl.constexpr):
    """One 5x5 box-blur pass over the density field (edge clamped) —
    the SPH field's finite-particle speckle, smoothed for display."""
    gx_id = tl.program_id(0)
    gy_id = tl.program_id(1)
    acc = 0.0
    base = gy_id * RGW + gx_id
    for ddy in range(-2, 3):
        for ddx in range(-2, 3):
            yy = gy_id + ddy
            xx = gx_id + ddx
            yy = tl.where(yy < 0, 0, tl.where(yy > RGH - 1, RGH - 1, yy))
            xx = tl.where(xx < 0, 0, tl.where(xx > RGW - 1, RGW - 1, xx))
            acc = acc + tl.load(f_ptr + yy * RGW + xx)
    tl.store(o_ptr + base, acc / 25.0)


# ---------------------------------------------------------------------------
# PBD fluid driver
# ---------------------------------------------------------------------------

class PBDFluid:
    """2D PBD fluid in a [0, dom_w]x[0, dom_h] box; particle mass = 1.

    Buffers are split-component f32/i32 tensors; the neighbor pipeline is
    rebuilt from scratch every step (bitonic sort + boundary search).
    """

    def __init__(self, n: int = 50000, dom_w: float = 1.0, dom_h: float = 1.0,
                 dt: float = 1.0 / 480.0, h_factor: float = 1.85, seed: int = 0,
                 iterations: int = 4, vmax: float = 1.0,
                 device: str = "cuda"):
        self.device = device
        self.dt = float(dt)
        self.iterations = int(iterations)
        self.vmax = float(vmax)
        self.dom_w = float(dom_w)
        self.dom_h = float(dom_h)
        # initial pool: full-width block resting at the bottom, at the
        # equilibrated spacing (settle test, not a dam break, so the demo
        # converges to a calm pond and the density sanity check is strict)
        s0 = (self.dom_w * self.dom_h * 0.5 / n) ** 0.5
        nx = max(1, int((n * self.dom_w / self.dom_h * 0.9) ** 0.5))
        ny = max(1, (n + nx - 1) // nx)
        ny_max = max(1, int(0.6 * self.dom_h / s0))
        if ny > ny_max:
            ny = ny_max
            nx = (n + ny - 1) // ny
        s0 = min(0.94 * self.dom_w / nx, 0.94 * self.dom_h / max(ny, 1))
        gx, gy = np.meshgrid(
            0.05 + s0 * (0.5 + np.arange(nx)),
            0.05 + s0 * (0.5 + np.arange(ny)))
        rng = np.random.default_rng(seed)
        px = (gx.reshape(-1)[:n] + 1e-4 * rng.standard_normal(n)).astype(np.float32)
        py = (gy.reshape(-1)[:n] + 1e-4 * rng.standard_normal(n)).astype(np.float32)
        self.n = len(px)
        self.s0 = s0
        self.h = h_factor * s0
        self.inv_cell = 1.0 / self.h
        self.gw = int(np.ceil(self.dom_w * self.inv_cell))
        self.gh = int(np.ceil(self.dom_h * self.inv_cell))
        self.ncells = self.gw * self.gh
        if self.ncells > 2**31 - 2:
            raise RuntimeError("cell grid too fine for i32 cell ids")
        d = lambda a: tl.tensor(a, device=device)
        self.x, self.y = d(px), d(py)
        z = np.zeros(self.n, np.float32)
        self.vx, self.vy = d(z), d(z)
        self.xp, self.yp = d(z), d(z)
        self.dx, self.dy = d(z), d(z)
        self.lam, self.rho = d(z), d(z)
        self.vx2, self.vy2 = d(z), d(z)
        self.cid = d(np.zeros(self.n, np.int32))
        self.poly6 = 4.0 / (np.pi * self.h**8)
        self.spiky = 30.0 / (np.pi * self.h**5)
        self.pad = 0.5 * s0
        # scorr reference weight: W_poly6 at 0.2 h...0.3 h band (use 0.25)
        dq = 0.25 * self.h
        t0 = self.h**2 - dq**2
        self.inv_wdq = 1.0 / (self.poly6 * t0**3)
        self.rho0 = self._calibrate()  # host sync, once
        # PBD eps regularizer: 2% of the single-neighbor denominator scale
        # 2*|gradW|^2/rho0^2 (Macklin uses absolute units; with 2D kernels
        # the raw |gradC|^2 is ~1e6, so a bare 1e-6 makes isolated-particle
        # lambdas explode)
        gmax = self.spiky * self.h * self.h
        self.epsr = 0.02 * 2.0 * gmax * gmax / (self.rho0 * self.rho0)
        self.dx_clamp = 0.5 * self.h  # |dx| cap per step (robustness)
        self.step_count = 0

    def _cell_list(self, cx=None, cy=None):
        _cell_id_kernel[((self.n + 255) // 256,)](
            (cx or self.xp)._buffer_arg(), (cy or self.yp)._buffer_arg(),
            self.cid._buffer_arg(), self.n, self.inv_cell, self.gw, self.gh,
            self.dom_w, self.dom_h, BLOCK=256, num_warps=4)
        return sparse.cell_list(self.cid, self.ncells)

    def _calibrate(self):
        """rho0 = mean density of the initial block (kernel units)."""
        self.xp, self.yp = self.x, self.y  # alias for the calibration pass
        rp, perm = self._cell_list()
        _lambda_kernel[(self.n,)](
            self.xp._buffer_arg(), self.yp._buffer_arg(), rp._buffer_arg(),
            perm._buffer_arg(), self.lam._buffer_arg(), self.rho._buffer_arg(),
            self.n, self.gw, self.gh, self.inv_cell, self.h, self.h * self.h,
            self.poly6, self.spiky, 1.0, 1e-6, BLOCK=32, num_warps=1)
        rho0 = float(self.rho.mean().numpy())
        self.xp = tl.zeros(self.n, tl.float32, self.device)
        self.yp = tl.zeros(self.n, tl.float32, self.device)
        return rho0

    def step(self):
        n = self.n
        _predict_kernel[((n + 255) // 256,)](
            self.x._buffer_arg(), self.y._buffer_arg(), self.vx._buffer_arg(),
            self.vy._buffer_arg(), self.xp._buffer_arg(), self.yp._buffer_arg(),
            n, self.dt, 0.0, GRAV, BLOCK=256, num_warps=4)
        rp, perm = self._cell_list()
        h2 = self.h * self.h
        for _ in range(self.iterations):
            _lambda_kernel[(n,)](
                self.xp._buffer_arg(), self.yp._buffer_arg(),
                rp._buffer_arg(), perm._buffer_arg(), self.lam._buffer_arg(),
                self.rho._buffer_arg(), n, self.gw, self.gh, self.inv_cell,
                self.h, h2, self.poly6, self.spiky, self.rho0, self.epsr,
                BLOCK=32, num_warps=1)
            _dx_kernel[(n,)](
                self.xp._buffer_arg(), self.yp._buffer_arg(),
                self.lam._buffer_arg(), rp._buffer_arg(),
                perm._buffer_arg(), self.dx._buffer_arg(),
                self.dy._buffer_arg(), n, self.gw, self.gh, self.inv_cell,
                self.h, h2, self.poly6, self.spiky, self.rho0, self.inv_wdq,
                SCORR_K, self.dx_clamp, BLOCK=32, num_warps=1)
            _apply_dx_kernel[((n + 255) // 256,)](
                self.xp._buffer_arg(), self.yp._buffer_arg(),
                self.dx._buffer_arg(), self.dy._buffer_arg(), n, self.pad,
                self.dom_w, self.dom_h, BLOCK=256, num_warps=4)
        _finalize_kernel[((n + 255) // 256,)](
            self.x._buffer_arg(), self.y._buffer_arg(), self.xp._buffer_arg(),
            self.yp._buffer_arg(), self.vx._buffer_arg(), self.vy._buffer_arg(),
            n, self.dt, self.pad, self.dom_w, self.dom_h, self.vmax,
            BLOCK=256, num_warps=4)
        _xsph_kernel[(n,)](
            self.x._buffer_arg(), self.y._buffer_arg(), self.vx._buffer_arg(),
            self.vy._buffer_arg(), self.vx2._buffer_arg(),
            self.vy2._buffer_arg(), rp._buffer_arg(), perm._buffer_arg(),
            n, self.gw, self.gh, self.inv_cell, h2, self.poly6,
            XSPH_C / self.rho0, BLOCK=32, num_warps=1)
        self.vx, self.vx2 = self.vx2, self.vx
        self.vy, self.vy2 = self.vy2, self.vy
        self.step_count += 1

    # -- stats ---------------------------------------------------------------

    def kinetic_energy(self) -> float:
        s = (self.vx * self.vx + self.vy * self.vy).sum()
        return 0.5 * float(s.numpy())

    def rho_mean(self) -> float:
        return float(self.rho.mean().numpy())

    def finite(self) -> bool:
        return bool(np.isfinite(self.x.numpy()).all()
                    and np.isfinite(self.vx.numpy()).all())

    def frame(self, buf: viz.PixelBuffer):
        viz.clear(buf, (0.02, 0.03, 0.05))
        viz.particles(buf, self.x / self.dom_w, self.y / self.dom_h,
                      color=(0.35, 0.65, 1.0), radius=1, y_up=True)
        return buf

    def frame_water(self, buf: viz.PixelBuffer, gw: int = 0, gh: int = 0):
        """Field-sampled SPH render: evaluate the poly6 density field on a
        gw x gh grid (same cell list + kernel as the solver) and colormap
        it ("water": deep navy body -> cyan surface -> white foam).
        gw/gh default to the buffer's own resolution (no upscale speckle).
        """
        gw = gw or buf.W
        gh = gh or buf.H
        rp, perm = self._cell_list()
        field = tl.zeros((gh, gw), tl.float32, self.device)
        _field_density_kernel[(gw, gh)](  # grid dim0 = x (width)
            self.x._buffer_arg(), self.y._buffer_arg(), rp._buffer_arg(),
            perm._buffer_arg(), field._buffer_arg(), self.n, self.gw,
            self.gh, self.inv_cell, self.h, self.h * self.h, self.poly6,
            self.dom_w, self.dom_h, gw, gh, BLOCK=32, num_warps=1)
        smooth = tl.zeros((gh, gw), tl.float32, self.device)
        _field_blur_kernel[(gw, gh)](field._buffer_arg(),
                                     smooth._buffer_arg(), gw, gh,
                                     BLOCK=32, num_warps=1)
        viz.clear(buf, (0.004, 0.012, 0.039))
        viz.heatmap(buf, smooth, cmap="water", vmin=0.06 * self.rho0,
                    vmax=1.5 * self.rho0)
        return buf



def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--n", type=int, default=50000)
    p.add_argument("--steps", type=int, default=400)
    p.add_argument("--dt", type=float, default=1.0 / 480.0)
    p.add_argument("--frames", type=str, default=None,
                   help="directory for PNG frame output (headless mode)")
    p.add_argument("--display", action="store_true",
                   help="try a pygame window (auto-falls back to frames)")
    p.add_argument("--bench", action="store_true", help="no viz, timed run")
    p.add_argument("--stats", type=int, default=25, help="stats every K steps")
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    fluid = PBDFluid(n=args.n, dt=args.dt, seed=args.seed)
    print(f"PBD fluid: n={fluid.n} h={fluid.h:.4f} grid={fluid.gw}x{fluid.gh} "
          f"({fluid.ncells} cells) rho0={fluid.rho0:.3f} dt={fluid.dt:.5f}")

    win = None
    buf = None
    if not args.bench:
        buf = viz.PixelBuffer(512, 512)
        win = viz.Window(512, 512, title="sph_demo (PBD fluid)",
                         frames_dir=args.frames, display=args.display,
                         fps=60, max_frames=args.steps)
        if win.mode == "frames":
            print(f"frames -> {win.frames_dir}")

    t0 = time.perf_counter()
    done = 0
    ke0 = None
    for s in range(args.steps):
        if win is not None:
            act = win.show(fluid.frame(buf))
            if act == "quit":
                break
            if act == "paused":
                continue
        fluid.step()
        done += 1
        if args.stats and (s + 1) % args.stats == 0:
            ke = fluid.kinetic_energy()
            ke0 = ke if ke0 is None else ke0
            rm = fluid.rho_mean()
            el = time.perf_counter() - t0
            print(f"step {s + 1:5d}  {done / el:7.1f} steps/s  "
                  f"rho_mean/rho0={rm / fluid.rho0:6.3f}  KE={ke:8.4f}")
    tl.synchronize()
    el = time.perf_counter() - t0
    ok_fin = fluid.finite()
    print(f"DONE n={fluid.n} steps={done} wall={el:.2f}s "
          f"-> {done / el:.1f} sim-steps/s  (finite={ok_fin})")
    if done and args.stats:
        print(f"sanity: rho_mean/rho0={fluid.rho_mean() / fluid.rho0:.3f} "
              f"(hydrostatic settle level; expect stable, no drift, "
              f"KE decaying), KE_final={fluid.kinetic_energy():.4f}")
    if win is not None:
        win.close()
    return 0 if ok_fin else 1


if __name__ == "__main__":
    sys.exit(main())
