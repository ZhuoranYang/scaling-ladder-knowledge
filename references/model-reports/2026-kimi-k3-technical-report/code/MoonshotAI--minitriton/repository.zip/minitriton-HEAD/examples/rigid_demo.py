#!/usr/bin/env python
"""Batch 2D rigid bodies (uniform discs) with
contact impulses, on MiniTriton tensors. Model choices:

- Full 2D rigid state: (x, y, vx, vy, theta, omega), m = pi r^2,
  I = 1/2 m r^2; semi-implicit Euler, gravity.
- Broadphase EVERY step with the GPU cell list (cell size
  h = 2 * r_max so any contact pair lives in adjacent cells;
  broadphase = sort + segment). No pair list is
  materialized: each body's program loops its 3x3 cells directly.
- Narrowphase: sequential-impulse, Jacobi style — every body's program
  accumulates (dvx, dvy, domega) from its contacts against the SAME
  velocity snapshot (normal restitution + Coulomb friction; friction is
  the only torque source for discs, wall contacts included), then one
  kernel applies the deltas — K_ITERS=10 iterations of {accumulate,
  apply} per step.
- Penetration cleanup: 2 NGS position-correction passes (beta = 0.4,
  slop = 1e-4). Restitution cutoff v_min to stop floor jitter.

    CUDA_VISIBLE_DEVICES=1 python examples/rigid_demo.py --steps 400 \
        --frames /tmp/rigid
    CUDA_VISIBLE_DEVICES=1 python examples/rigid_demo.py --bench

Prints steps/s; uses minitriton.viz for rendering (center dot + rim dot
showing rotation).
"""

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl
from minitriton import sparse, viz

GRAV = -9.8
RESTITUTION = 0.3
FRICTION = 0.5
V_THRESH = 0.05      # restitution cutoff
K_ITERS = 10         # impulse iterations
NGS_ITERS = 2
NGS_BETA = 0.4
NGS_SLOP = 1e-4


# ---------------------------------------------------------------------------
# kernels
# ---------------------------------------------------------------------------

@tl.kernel
def _predict_kernel(x_ptr, y_ptr, th_ptr, vx_ptr, vy_ptr, om_ptr, N, DT,
                    BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    vx = tl.load(vx_ptr + offs, mask=m, other=0.0)
    vy = tl.load(vy_ptr + offs, mask=m, other=0.0)
    x = tl.load(x_ptr + offs, mask=m, other=0.0)
    y = tl.load(y_ptr + offs, mask=m, other=0.0)
    th = tl.load(th_ptr + offs, mask=m, other=0.0)
    om = tl.load(om_ptr + offs, mask=m, other=0.0)
    vy = vy + GRAV * DT
    tl.store(vy_ptr + offs, vy, mask=m)
    tl.store(x_ptr + offs, x + vx * DT, mask=m)
    tl.store(y_ptr + offs, y + vy * DT, mask=m)
    tl.store(th_ptr + offs, th + om * DT, mask=m)


@tl.kernel
def _cell_id_kernel(x_ptr, y_ptr, cid_ptr, N, INV_CELL, GW, GH,
                    BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m, other=0.0)
    y = tl.load(y_ptr + offs, mask=m, other=0.0)
    cx = tl.cast(x * INV_CELL, tl.int32)
    cy = tl.cast(y * INV_CELL, tl.int32)
    cx = tl.where(cx < 0, 0, cx)
    cx = tl.where(cx > GW - 1, GW - 1, cx)
    cy = tl.where(cy < 0, 0, cy)
    cy = tl.where(cy > GH - 1, GH - 1, cy)
    tl.store(cid_ptr + offs, cy * GW + cx, mask=m)


@tl.kernel
def _wall_clamp_kernel(x_ptr, y_ptr, vx_ptr, vy_ptr, om_ptr, r_ptr, N,
                       DOMW, DOMH, BLOCK: tl.constexpr):
    """Hard static walls: project positions onto the boundary and kill the
    inward velocity (with friction on the tangential one)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m, other=0.0)
    y = tl.load(y_ptr + offs, mask=m, other=0.0)
    vx = tl.load(vx_ptr + offs, mask=m, other=0.0)
    vy = tl.load(vy_ptr + offs, mask=m, other=0.0)
    om = tl.load(om_ptr + offs, mask=m, other=0.0)
    r = tl.load(r_ptr + offs, mask=m, other=0.0)
    floor = y < r
    vy = tl.where(floor & (vy < 0.0), 0.0, vy)
    vx = tl.where(floor, vx * 0.7, vx)
    om = tl.where(floor, om * 0.7, om)
    y = tl.where(floor, r, y)
    left = x < r
    vx = tl.where(left & (vx < 0.0), 0.0, vx)
    vy = tl.where(left, vy * 0.7, vy)
    x = tl.where(left, r, x)
    right = x > DOMW - r
    vx = tl.where(right & (vx > 0.0), 0.0, vx)
    vy = tl.where(right, vy * 0.7, vy)
    x = tl.where(right, DOMW - r, x)
    top = y > DOMH - r
    vy = tl.where(top & (vy > 0.0), 0.0, vy)
    y = tl.where(top, DOMH - r, y)
    tl.store(x_ptr + offs, x, mask=m)
    tl.store(y_ptr + offs, y, mask=m)
    tl.store(vx_ptr + offs, vx, mask=m)
    tl.store(vy_ptr + offs, vy, mask=m)
    tl.store(om_ptr + offs, om, mask=m)


@tl.kernel
def _impulse_kernel(x_ptr, y_ptr, r_ptr, invm_ptr, invi_ptr, vx_ptr, vy_ptr,
                    om_ptr, dvx_ptr, dvy_ptr, dom_ptr, rp_ptr, perm_ptr,
                    N, GW, GH, INV_CELL, DOMW, DOMH, REST, MU, VT,
                    BLOCK: tl.constexpr):
    """Per body: accumulate (dvx, dvy, domega) from all contacts (pairs +
    walls) against the current velocity snapshot (Jacobi)."""
    i = tl.program_id(0)
    xi = tl.load(x_ptr + i)
    yi = tl.load(y_ptr + i)
    ri = tl.load(r_ptr + i)
    invmi = tl.load(invm_ptr + i)
    invii = tl.load(invi_ptr + i)
    vxi = tl.load(vx_ptr + i)
    vyi = tl.load(vy_ptr + i)
    omi = tl.load(om_ptr + i)
    cx = tl.cast(xi * INV_CELL, tl.int32)
    cy = tl.cast(yi * INV_CELL, tl.int32)
    cx = tl.where(cx < 0, 0, cx)
    cx = tl.where(cx > GW - 1, GW - 1, cx)
    cy = tl.where(cy < 0, 0, cy)
    cy = tl.where(cy > GH - 1, GH - 1, cy)
    ax = tl.zeros((BLOCK,), tl.float32)
    ay = tl.zeros((BLOCK,), tl.float32)
    ao = tl.zeros((BLOCK,), tl.float32)
    offs = tl.arange(0, BLOCK)
    for ddy in range(-1, 2):
        for ddx in range(-1, 2):
            cx2 = cx + ddx
            cy2 = cy + ddy
            ok = (cx2 >= 0) & (cx2 < GW) & (cy2 >= 0) & (cy2 < GH)
            ccx = tl.where(ok, cx2, 0)
            ccy = tl.where(ok, cy2, 0)
            nb = ccy * GW + ccx
            s = tl.load(rp_ptr + nb)
            e = tl.load(rp_ptr + nb + 1)
            seg = tl.where(ok, e - s, 0)
            for k0 in range(0, seg, BLOCK):
                jm = (k0 + offs) < seg
                j = tl.load(perm_ptr + s + k0 + offs, mask=jm, other=i)
                xj = tl.load(x_ptr + j, mask=jm, other=1e9)
                yj = tl.load(y_ptr + j, mask=jm, other=1e9)
                rj = tl.load(r_ptr + j, mask=jm, other=0.0)
                invmj = tl.load(invm_ptr + j, mask=jm, other=0.0)
                invij = tl.load(invi_ptr + j, mask=jm, other=0.0)
                vxj = tl.load(vx_ptr + j, mask=jm, other=0.0)
                vyj = tl.load(vy_ptr + j, mask=jm, other=0.0)
                omj = tl.load(om_ptr + j, mask=jm, other=0.0)
                rx = xi - xj
                ry = yi - yj
                d2 = rx * rx + ry * ry
                rr = ri + rj
                contact = (d2 < rr * rr) & (j != i)
                d = tl.sqrt(d2)
                nx = rx / (d + 1e-9)
                ny = ry / (d + 1e-9)
                # relative contact-point velocity (vj_contact - vi_contact);
                # normal impulse on i acts along -n; friction along t=perp(n)
                vrn = (vxi - vxj) * nx + (vyi - vyj) * ny
                vrt = (vxi - vxj) * (-ny) + (vyi - vyj) * nx \
                    - omi * ri - omj * rj
                kn = invmi + invmj
                jn = tl.where(contact & (vrn < -VT),
                              -(1.0 + REST) * vrn / (kn + 1e-12), 0.0)
                jn = tl.where(contact & (vrn >= -VT) & (vrn < 0.0),
                              -vrn / (kn + 1e-12), jn)  # resting contact
                kt = kn + ri * ri * invii + rj * rj * invij
                jt = tl.where(contact, -vrt / (kt + 1e-12), 0.0)
                jtlim = MU * jn
                jt = tl.where(jt > jtlim, jtlim, jt)
                jt = tl.where(jt < -jtlim, -jtlim, jt)
                # apply +jn along n to body i? Handedness: n points from j
                # to i; separating normal impulse pushes i along +n.
                ax = ax + jn * nx * invmi + jt * (-ny) * invmi
                ay = ay + jn * ny * invmi + jt * nx * invmi
                ao = ao - jt * ri * invii
    # walls (static), expressed as impulses exactly like the pair contacts:
    # Jn = -(1+e) vn / invm, Jt clamped to +-mu Jn; dv = J invm,
    # domega = Jt r invi.
    wvx = 0.0
    wvy = 0.0
    # walls are NOT part of the Jacobi system (a static friction bound
    # lashed to a sign flip never converges and pumps omega on small
    # discs); they are enforced by the hard projection pass at the end of
    # the step (position clamp + velocity/rotation damping).
    tl.store(dvx_ptr + i, tl.sum(ax))
    tl.store(dvy_ptr + i, tl.sum(ay))
    tl.store(dom_ptr + i, tl.sum(ao))


@tl.kernel
def _apply_kernel(vx_ptr, vy_ptr, om_ptr, dvx_ptr, dvy_ptr, dom_ptr,
                  invm_ptr, N, FAC, VMAX, OMMAX, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    vx = tl.load(vx_ptr + offs, mask=m, other=0.0)
    vy = tl.load(vy_ptr + offs, mask=m, other=0.0)
    om = tl.load(om_ptr + offs, mask=m, other=0.0)
    dvx = tl.load(dvx_ptr + offs, mask=m, other=0.0)
    dvy = tl.load(dvy_ptr + offs, mask=m, other=0.0)
    dom = tl.load(dom_ptr + offs, mask=m, other=0.0)
    invm = tl.load(invm_ptr + offs, mask=m, other=1.0)
    # dvx/dvy are accumulated as invm-weighted impulses -> multiply by m:
    # stored (jn*invmi) so direct add is correct; dom likewise (jt*r*invi).
    nvx = vx + FAC * dvx
    nvy = vy + FAC * dvy
    nom = om + FAC * dom
    # state clamps: small discs have tiny inertia and Jacobi clocking can
    # otherwise ratchet omega without bound (position pile stays correct,
    # only the spin channel is saturated). Documented demo bound.
    sp2 = nvx * nvx + nvy * nvy
    over = sp2 > VMAX * VMAX
    scl = VMAX / tl.sqrt(sp2 + 1e-12)
    nvx = tl.where(over, nvx * scl, nvx)
    nvy = tl.where(over, nvy * scl, nvy)
    nom = tl.where(nom > OMMAX, OMMAX, nom)
    nom = tl.where(nom < -OMMAX, -OMMAX, nom)
    tl.store(vx_ptr + offs, nvx, mask=m)
    tl.store(vy_ptr + offs, nvy, mask=m)
    tl.store(om_ptr + offs, nom, mask=m)


@tl.kernel
def _add_inplace_kernel(x_ptr, c_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m, other=0.0)
    c = tl.load(c_ptr + offs, mask=m, other=0.0)
    tl.store(x_ptr + offs, x + c, mask=m)


@tl.kernel
def _ngs_kernel(x_ptr, y_ptr, r_ptr, invm_ptr, ncx_ptr, ncy_ptr, rp_ptr,
                perm_ptr, N, GW, GH, INV_CELL, DOMW, DOMH, BETA, SLOP,
                BLOCK: tl.constexpr):
    """NGS position correction: accumulate overlap splits + wall push-out."""
    i = tl.program_id(0)
    xi = tl.load(x_ptr + i)
    yi = tl.load(y_ptr + i)
    ri = tl.load(r_ptr + i)
    invmi = tl.load(invm_ptr + i)
    cx = tl.cast(xi * INV_CELL, tl.int32)
    cy = tl.cast(yi * INV_CELL, tl.int32)
    cx = tl.where(cx < 0, 0, cx)
    cx = tl.where(cx > GW - 1, GW - 1, cx)
    cy = tl.where(cy < 0, 0, cy)
    cy = tl.where(cy > GH - 1, GH - 1, cy)
    ax = tl.zeros((BLOCK,), tl.float32)
    ay = tl.zeros((BLOCK,), tl.float32)
    offs = tl.arange(0, BLOCK)
    for ddy in range(-1, 2):
        for ddx in range(-1, 2):
            cx2 = cx + ddx
            cy2 = cy + ddy
            ok = (cx2 >= 0) & (cx2 < GW) & (cy2 >= 0) & (cy2 < GH)
            ccx = tl.where(ok, cx2, 0)
            ccy = tl.where(ok, cy2, 0)
            nb = ccy * GW + ccx
            s = tl.load(rp_ptr + nb)
            e = tl.load(rp_ptr + nb + 1)
            seg = tl.where(ok, e - s, 0)
            for k0 in range(0, seg, BLOCK):
                jm = (k0 + offs) < seg
                j = tl.load(perm_ptr + s + k0 + offs, mask=jm, other=i)
                xj = tl.load(x_ptr + j, mask=jm, other=1e9)
                yj = tl.load(y_ptr + j, mask=jm, other=1e9)
                rj = tl.load(r_ptr + j, mask=jm, other=0.0)
                invmj = tl.load(invm_ptr + j, mask=jm, other=0.0)
                rx = xi - xj
                ry = yi - yj
                d2 = rx * rx + ry * ry
                rr = ri + rj
                contact = (d2 < rr * rr) & (j != i)
                d = tl.sqrt(d2)
                pen = rr - d - SLOP
                nx = rx / (d + 1e-9)
                ny = ry / (d + 1e-9)
                c = tl.where(contact & (pen > 0.0),
                             BETA * pen * invmi / (invmi + invmj + 1e-12),
                             0.0)
                ax = ax + c * nx
                ay = ay + c * ny
    wvx = 0.0
    wvy = 0.0
    wvy += tl.where(ri - yi > 0.0, BETA * (ri - yi), 0.0)
    wvx += tl.where(ri - xi > 0.0, BETA * (ri - xi), 0.0)
    wvx -= tl.where(xi + ri - DOMW > 0.0, BETA * (xi + ri - DOMW), 0.0)
    wvy -= tl.where(yi + ri - DOMH > 0.0, BETA * (yi + ri - DOMH), 0.0)
    tl.store(ncx_ptr + i, tl.sum(ax) + wvx)
    tl.store(ncy_ptr + i, tl.sum(ay) + wvy)



# ---------------------------------------------------------------------------
# driver
# ---------------------------------------------------------------------------

class RigidWorld:
    """Batch-rigid-disc world: broadphase cell list + Jacobi impulse loop."""

    def __init__(self, n: int = 1500, dom_w: float = 1.6, dom_h: float = 1.2,
                 dt: float = 1.0 / 240.0, r_lo: float = 0.010,
                 r_hi: float = 0.020, k_iters: int = K_ITERS, seed: int = 0,
                 device: str = "cuda"):
        rng = np.random.default_rng(seed)
        self.n, self.dt = int(n), float(dt)
        self.dom_w, self.dom_h = float(dom_w), float(dom_h)
        self.k_iters = int(k_iters)
        r = rng.uniform(r_lo, r_hi, self.n).astype(np.float32)
        # drop-in init: jittered lattice in the sky, mild overlap ok
        cols = int(self.dom_w / (2.3 * r_hi))
        rows = (self.n + cols - 1) // cols
        gx, gy = np.meshgrid(np.arange(cols), np.arange(rows))
        px = (r_hi * 1.15 + gx.reshape(-1)[:self.n] * 2.3 * r_hi
              + 0.004 * rng.standard_normal(self.n))
        py = (0.55 * self.dom_h + gy.reshape(-1)[:self.n] * 2.3 * r_hi
              + 0.004 * rng.standard_normal(self.n))
        py = np.clip(py, 0.0, self.dom_h - r_hi - 0.01)
        self.r_max = float(r.max())
        self.cell = 2.0 * self.r_max
        self.inv_cell = 1.0 / self.cell
        self.gw = int(np.ceil(self.dom_w * self.inv_cell)) + 1
        self.gh = int(np.ceil(self.dom_h * self.inv_cell)) + 1
        self.ncells = self.gw * self.gh
        d = lambda a: tl.tensor(np.ascontiguousarray(a), device=device)
        z = np.zeros(self.n, np.float32)
        self.x, self.y = d(px.astype(np.float32)), d(py.astype(np.float32))
        self.vx, self.vy = d(z), d(z)
        self.th, self.om = d(z), d(z)
        self.r = d(r)
        mass = np.pi * r * r
        self.invm = d((1.0 / mass).astype(np.float32))
        self.invi = d((1.0 / (0.5 * mass * r * r)).astype(np.float32))
        self.dvx, self.dvy, self.dom = d(z), d(z), d(z)
        self.ncx, self.ncy = d(z), d(z)
        self.cid = d(np.zeros(self.n, np.int32))
        self.step_count = 0

    def step(self):
        n = self.n
        _predict_kernel[((n + 255) // 256,)](
            self.x._buffer_arg(), self.y._buffer_arg(), self.th._buffer_arg(),
            self.vx._buffer_arg(), self.vy._buffer_arg(), self.om._buffer_arg(),
            n, self.dt, BLOCK=256, num_warps=4)
        _cell_id_kernel[((n + 255) // 256,)](
            self.x._buffer_arg(), self.y._buffer_arg(),
            self.cid._buffer_arg(), n, self.inv_cell, self.gw, self.gh,
            BLOCK=256, num_warps=4)
        rp, perm = sparse.cell_list(self.cid, self.ncells)
        for _ in range(self.k_iters):
            _impulse_kernel[(n,)](
                self.x._buffer_arg(), self.y._buffer_arg(),
                self.r._buffer_arg(), self.invm._buffer_arg(),
                self.invi._buffer_arg(), self.vx._buffer_arg(),
                self.vy._buffer_arg(), self.om._buffer_arg(),
                self.dvx._buffer_arg(), self.dvy._buffer_arg(),
                self.dom._buffer_arg(), rp._buffer_arg(), perm._buffer_arg(),
                n, self.gw, self.gh, self.inv_cell, self.dom_w, self.dom_h,
                RESTITUTION, FRICTION, V_THRESH, BLOCK=32, num_warps=1)
            _apply_kernel[((n + 255) // 256,)](
                self.vx._buffer_arg(), self.vy._buffer_arg(),
                self.om._buffer_arg(), self.dvx._buffer_arg(),
                self.dvy._buffer_arg(), self.dom._buffer_arg(),
                self.invm._buffer_arg(), n, 0.5, 8.0, 30.0,
                BLOCK=256, num_warps=4)
        for _ in range(NGS_ITERS):
            _ngs_kernel[(n,)](
                self.x._buffer_arg(), self.y._buffer_arg(),
                self.r._buffer_arg(), self.invm._buffer_arg(),
                self.ncx._buffer_arg(), self.ncy._buffer_arg(),
                rp._buffer_arg(), perm._buffer_arg(), n, self.gw, self.gh,
                self.inv_cell, self.dom_w, self.dom_h, NGS_BETA, NGS_SLOP,
                BLOCK=32, num_warps=1)
            _ngs_apply((self.x, self.y), (self.ncx, self.ncy), n)
        _wall_clamp_kernel[((n + 255) // 256,)](
            self.x._buffer_arg(), self.y._buffer_arg(), self.vx._buffer_arg(),
            self.vy._buffer_arg(), self.om._buffer_arg(), self.r._buffer_arg(),
            n, self.dom_w, self.dom_h, BLOCK=256, num_warps=4)
        self.step_count += 1

    # -- stats ---------------------------------------------------------------

    _zero_pair = None

    def kinetic_energy(self) -> float:
        m = 1.0 / self.invm
        lin = 0.5 * (m * (self.vx * self.vx + self.vy * self.vy)).sum()
        return float(lin.numpy())

    def rot_kinetic_energy(self) -> float:
        inertia = 1.0 / self.invi
        return float((0.5 * inertia * self.om * self.om).sum().numpy())

    def finite(self) -> bool:
        return bool(np.isfinite(self.x.numpy()).all()
                    and np.isfinite(self.vx.numpy()).all())

    def sink_violation(self) -> float:
        """max(r_i - y_i) across bodies: floor penetration."""
        d = (self.r - self.y).max()
        return float(d.numpy())

    def frame(self, buf: viz.PixelBuffer):
        import math
        viz.clear(buf, (0.02, 0.03, 0.05))
        viz.particles(buf, self.x / self.dom_w, self.y / self.dom_h,
                      color=(0.95, 0.75, 0.25), radius=1, y_up=True)
        rimx = (self.x + self.r * _cos_t(self.th)) / self.dom_w
        rimy = (self.y + self.r * _sin_t(self.th)) / self.dom_h
        viz.particles(buf, rimx, rimy, color=(1.0, 0.98, 0.9), radius=0,
                      y_up=True)
        return buf


def _cos_t(t):
    return _unary_math(t, "cos")


def _sin_t(t):
    return _unary_math(t, "sin")


def _unary_math(t, fn):
    # eager sin/cos: not all unary fns are guaranteed; do it on GPU via a
    # small DSL kernel instead of hoping.
    out = tl.empty(t.shape, tl.float32, t.device)
    _rim_math_kernel[((t.numel() + 255) // 256,)](
        t._buffer_arg(), out._buffer_arg(), t.numel(), FN=fn,
        BLOCK=256, num_warps=4)
    return out


@tl.kernel
def _rim_math_kernel(t_ptr, out_ptr, N, FN: tl.constexpr,
                     BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    v = tl.load(t_ptr + offs, mask=m, other=0.0)
    if FN == "cos":
        o = tl.cos(v)
    else:
        o = tl.sin(v)
    tl.store(out_ptr + offs, o, mask=m)


def _ngs_apply(xt, ct, n):
    for a, c in zip(xt, ct):
        _add_inplace_kernel[((n + 255) // 256,)](a._buffer_arg(),
                                                 c._buffer_arg(), n,
                                                 BLOCK=256, num_warps=4)


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--n", type=int, default=1500)
    p.add_argument("--steps", type=int, default=400)
    p.add_argument("--dt", type=float, default=1.0 / 240.0)
    p.add_argument("--frames", type=str, default=None)
    p.add_argument("--display", action="store_true")
    p.add_argument("--bench", action="store_true")
    p.add_argument("--stats", type=int, default=25)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    world = RigidWorld(n=args.n, dt=args.dt, seed=args.seed)
    print(f"rigid world: n={world.n} cells={world.gw}x{world.gh} "
          f"({world.ncells}) cell={world.cell:.3f} r_max={world.r_max:.3f} "
          f"dt={world.dt:.5f} K={world.k_iters}")

    win = buf = None
    if not args.bench:
        buf = viz.PixelBuffer(480, 360)
        win = viz.Window(480, 360, title="rigid_demo (2D rigid discs)",
                         frames_dir=args.frames, display=args.display,
                         fps=60, max_frames=args.steps)
        if win.mode == "frames":
            print(f"frames -> {win.frames_dir}")

    t0 = time.perf_counter()
    done = 0
    for s in range(args.steps):
        if win is not None:
            act = win.show(world.frame(buf))
            if act == "quit":
                break
            if act == "paused":
                continue
        world.step()
        done += 1
        if args.stats and (s + 1) % args.stats == 0:
            el = time.perf_counter() - t0
            print(f"step {s + 1:5d}  {done / el:7.1f} steps/s  "
                  f"KE={world.kinetic_energy():9.4f}  "
                  f"rotKE={world.rot_kinetic_energy():8.4f}  "
                  f"sink={world.sink_violation():.5f}")
    tl.synchronize()
    el = time.perf_counter() - t0
    ok_fin = world.finite()
    print(f"DONE n={world.n} steps={done} wall={el:.2f}s "
          f"-> {done / el:.1f} sim-steps/s  (finite={ok_fin})")
    print(f"sanity: KE={world.kinetic_energy():.4f} "
          f"sink={world.sink_violation():.5f} "
          f"(want bounded KE, sink << r_min)")
    if win is not None:
        win.close()
    return 0 if ok_fin else 1


if __name__ == "__main__":
    sys.exit(main())
