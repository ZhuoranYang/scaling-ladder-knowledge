"""Gallery figure producer for the README (regenerable, figure-data lockstep).

Renders the SPH dam-break demo (field-sampled "water" colormap) headless
and emits `assets/gallery_water.mp4` (video) + `gallery_water.png`
(contact-sheet fallback) + `gallery_water.pdf` (print variant). The DDP
overlay figure is produced by `benchmarks/training/plot_ddp_overlay.py`
(see its docstring).

    CUDA_VISIBLE_DEVICES=1 python examples/render_gallery.py
"""

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT_PNG = ROOT / "assets" / "gallery_water.png"
OUT_MP4 = ROOT / "assets" / "gallery_water.mp4"

STEPS = 480
FPS = 48
PICKS = 6  # evenly spaced frames for the contact sheet


def main() -> int:
    sys.path.insert(0, str(ROOT))  # repo package first (not site-packages)
    sys.path.insert(0, str(ROOT / "examples"))
    import numpy as np
    from PIL import Image
    from minitriton import viz
    import sph_demo as sd

    fluid = sd.PBDFluid(n=50000, device="cuda")
    buf = viz.PixelBuffer(540, 720, "cuda")
    frames = []
    for s in range(STEPS):
        fluid.step()
        frames.append(Image.fromarray(fluid.frame_water(buf).resolve()))
    idx = [round(i * (len(frames) - 1) / (PICKS - 1)) for i in range(PICKS)]
    imgs = [frames[i] for i in idx]
    w, h = imgs[0].size
    sheet = Image.new("RGB", (w * 3, h * 2), (18, 18, 22))
    for i, im in enumerate(imgs):
        sheet.paste(im, ((i % 3) * w, (i // 3) * h))
    sheet.save(OUT_PNG)
    # print variant (README link) via matplotlib — Pillow's PDF plugin
    # needs a JPEG build that this env lacks
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig = plt.figure(figsize=(sheet.width / 200, sheet.height / 200),
                     dpi=200, frameon=False)
    fig.figimage(sheet, 0, 0)
    fig.savefig(OUT_PNG.with_suffix(".pdf"))
    plt.close(fig)
    tmp = ROOT / "build" / "gallery_frames"
    tmp.mkdir(parents=True, exist_ok=True)
    for i, im in enumerate(frames):
        im.save(tmp / f"frame_{i:05d}.png")
    subprocess.run(
        ["ffmpeg", "-y", "-framerate", str(FPS),
         "-i", str(tmp / "frame_%05d.png"),
         "-c:v", "libx264", "-crf", "28", "-pix_fmt", "yuv420p",
         "-movflags", "+faststart", str(OUT_MP4)],
        check=True, capture_output=True)
    print(f"gallery -> {OUT_PNG} ({len(frames)} frames)")
    print(f"video   -> {OUT_MP4} ({OUT_MP4.stat().st_size / 1e6:.2f} MB, "
          f"{STEPS} steps @ {FPS} fps)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
