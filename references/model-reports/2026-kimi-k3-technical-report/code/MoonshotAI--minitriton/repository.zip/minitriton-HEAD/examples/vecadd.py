#!/usr/bin/env python
"""1M-element fp32 vecadd written in the MiniTriton DSL.

grid/layout strategy: one program per BLOCK-sized tile; grid =
ceil(N / BLOCK) 1D programs; each program's block is distributed over
num_warps*32 threads (contiguous per-thread fragments, vectorized 16-byte
accesses on the aligned fast path, masked boundary handling via scalar
fallback).

Compiled via minitriton's own pipeline: Python AST -> MLIR -> PTX -> cubin
-> CUDA driver launch. Checked against numpy.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl


@tl.kernel
def vecadd(x_ptr, y_ptr, out_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < N
    x = tl.load(x_ptr + offs, mask=mask)
    y = tl.load(y_ptr + offs, mask=mask)
    tl.store(out_ptr + offs, x + y, mask=mask)


N = 1 << 20  # 1M elements
BLOCK = 512


def main() -> None:
    rng = np.random.default_rng(0)
    x = rng.random(N, dtype=np.float32)
    y = rng.random(N, dtype=np.float32)

    dx = tl.Buffer.from_numpy(x)
    dy = tl.Buffer.from_numpy(y)
    dout = tl.Buffer(N, tl.float32)

    vecadd[((N + BLOCK - 1) // BLOCK,)](dx, dy, dout, N, BLOCK=BLOCK)
    tl.synchronize()

    out = dout.to_numpy()
    max_err = float(np.max(np.abs(out - (x + y))))
    print(f"max err: {max_err:.3e}")
    assert max_err < 1e-6, f"FAILED: max err {max_err}"
    print("PASS")


if __name__ == "__main__":
    main()
