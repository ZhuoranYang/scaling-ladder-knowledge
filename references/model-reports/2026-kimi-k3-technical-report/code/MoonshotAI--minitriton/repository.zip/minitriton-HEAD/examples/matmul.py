#!/usr/bin/env python
"""fp32 matmul (C = A @ B) in the MiniTriton DSL.

grid/layout strategy: grid = (M/BM, N/BN) 2D programs; each program
computes a (BM, BN) output tile held as per-thread accumulator fragments
(BN distributed over num_threads, VEC_N = BN/num_threads columns each).
The K loop walks in BK chunks; tl.dot stages the A/B tiles through static
.shared buffers (memref.global in workgroup space + gpu.barrier) and runs
an FMA loop: per k, one vectorized b-fragment load (LDS.128) plus BM
broadcast a-loads, accumulating in registers (vector<BM x VEC_N>).

Checked against numpy.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl


@tl.kernel
def matmul_kernel(a_ptr, b_ptr, c_ptr, M, N, K,
                  BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    acc = tl.zeros((BM, BN), tl.float32)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * N + offs_n[None, :]
    for k in range(0, K, BK):
        a = tl.load(a_ptrs)
        b = tl.load(b_ptrs)
        acc = tl.dot(a, b, acc)
        a_ptrs += BK
        b_ptrs += BK * N
    tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)


def main() -> None:
    M = N = K = 1024
    BM, BN, BK, warps = 32, 128, 32, 4
    rng = np.random.default_rng(0)
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)

    da = tl.Buffer.from_numpy(a)
    db = tl.Buffer.from_numpy(b)
    dc = tl.Buffer(M * N, tl.float32)
    matmul_kernel[(M // BM, N // BN)](da, db, dc, M, N, K,
                                      BM=BM, BN=BN, BK=BK, num_warps=warps)
    tl.synchronize()

    out = dc.to_numpy().reshape(M, N)
    ref = a @ b
    rel = float(np.max(np.abs(out - ref)) / np.sqrt(K))
    print(f"rel err (scaled): {rel:.3e}")
    assert rel < 1e-4, f"FAILED: rel err {rel}"
    print("PASS")


if __name__ == "__main__":
    main()
