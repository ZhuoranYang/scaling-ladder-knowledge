"""Eager Tensor object model: a ``Tensor`` is (storage, shape, dtype, device)
plus view metadata; cuda views are pure metadata, cpu storage is the numpy
ndarray itself. bf16 host roundtrips go through f32 (no numpy equivalent).
"""

from __future__ import annotations

import math

import numpy as np

from .frontend import types as tl_types
from .frontend.types import DType
from .runtime.buffer import Buffer

_NP_TO_DTYPE = {
    np.dtype(np.float32): tl_types.float32,
    np.dtype(np.float16): tl_types.float16,
    np.dtype(np.int32): tl_types.int32,
    np.dtype(np.int64): tl_types.int64,
}

_FLOAT_RANK = {tl_types.float16: 1, tl_types.bfloat16: 2, tl_types.float32: 3}
_INT_RANK = {tl_types.int32: 1, tl_types.int64: 2}


def np_dtype_of(dt: DType):
    if dt == tl_types.bfloat16:
        raise TypeError("bfloat16 has no numpy dtype; cast to float32 first")
    return dt.numpy()


def dtype_of_numpy(arr: np.ndarray) -> DType:
    dt = _NP_TO_DTYPE.get(arr.dtype)
    if dt is None:
        raise TypeError(f"unsupported numpy dtype: {arr.dtype} "
                        "(v1: float32/float16/int32/int64)")
    return dt


def canonical_dim(d: int, ndim: int) -> int:
    """torch-style dim normalization: negative wraps once; out-of-range
    raises instead of silently modulo-wrapping."""
    dd = d + ndim if d < 0 else d
    if dd < 0 or dd >= ndim:
        raise IndexError(
            f"Dimension out of range (expected to be in range of "
            f"[{-ndim}, {ndim - 1}], but got {d})")
    return dd


def canonical_dims(dims, ndim: int) -> tuple:
    """Tuple form: canonicalizes each dim, rejects duplicates (torch:
    'dim 0 appears multiple times in the list of dims')."""
    out = tuple(canonical_dim(d, ndim) for d in dims)
    if len(set(out)) != len(out):
        raise IndexError("dim appears multiple times in the list of dims")
    return out


def promote_dtype(a: DType, b: DType) -> DType:
    """Simplified torch promotion: floats promote
    toward the larger of fp16/bf16/fp32 (fp16+bf16 -> fp32), ints stay in
    i32/i64, int+float -> the float dtype."""
    if a == b:
        return a
    if a.is_float and b.is_float:
        ra, rb = _FLOAT_RANK[a], _FLOAT_RANK[b]
        if ra == rb:
            return a
        if {a, b} == {tl_types.float16, tl_types.bfloat16}:
            return tl_types.float32
        return a if ra > rb else b
    if a.is_int and b.is_int:
        return a if _INT_RANK[a] >= _INT_RANK[b] else b
    return a if a.is_float else b


def _contig_strides(shape) -> tuple[int, ...]:
    st = []
    acc = 1
    for s in reversed(shape):
        st.append(acc)
        acc *= s
    return tuple(reversed(st))


def _is_contiguous(shape, strides) -> bool:
    acc = 1
    for s, st in zip(reversed(shape), reversed(strides)):
        if s == 1:
            continue
        if st != acc:
            return False
        acc *= s
    return True


class _ViewBuffer(Buffer):
    """A non-owning Buffer pointing ``offset`` elements into a base Buffer,
    so strided cuda views can be passed to kernel launches (which take
    ``.ptr/.nelem/.dtype``). Keeps the base alive; never frees."""

    def __init__(self, base: Buffer, offset_elems: int):
        assert 0 <= offset_elems <= base.nelem
        self.device = base.device
        self.dtype = base.dtype
        self.nelem = base.nelem - offset_elems
        self.nbytes = self.nelem * base.dtype.itemsize
        self.ptr = base.ptr + offset_elems * base.dtype.itemsize
        self._freed = True  # ownership stays with base
        self._base = base


# Device allocations go through the pooled caching allocator
# (runtime/allocator.py).
from .runtime.allocator import _alloc  # noqa: E402


def _record_view(src: "Tensor", out: "Tensor", op: str, meta) -> "Tensor":
    """Autograd hook for view/metadata ops: records a tape node when grad
    mode is on and the source requires grad, else returns ``out`` unchanged
    (see autograd/engine.py)."""
    from .autograd import engine
    return engine.record_view(src, out, op, meta)


class Tensor:
    __slots__ = ("_storage", "shape", "dtype", "device", "_st", "_offset",
                 "requires_grad", "grad", "grad_fn")
    # numpy defers binary ops on us to our dunders (without it, numpy
    # iterates us as a sequence and returns an object ndarray of 0-d
    # tensors — one kernel launch per element)
    __array_priority__ = 1000

    # -- construction ---------------------------------------------------------

    def __init__(self, data, dtype: DType | None = None,
                 device: str = "cuda", requires_grad: bool = False):
        """User-facing constructor: ``Tensor(data, dtype=..., device=...)``
        where data is a numpy array, a (nested) list or a scalar.
        Supported dtypes: float32/float16/int32/int64; numpy float64
        (numpy's default float) is treated as float32."""
        if isinstance(data, Tensor):
            src = data
            out = src.to(device=device) if device != src.device else src
            if dtype is not None and dtype != out.dtype:
                out = out.astype(dtype)
            self._share(out)
            # Tensor(Tensor) starts a NEW leaf (torch.tensor(t) semantics:
            # detach): never inherit the source's grad_fn or .grad buffer.
            self.grad_fn = None
            self.grad = None
            self.requires_grad = requires_grad
            if requires_grad and self.dtype.is_int:
                raise RuntimeError(
                    "only float tensors can require gradients")
            return
        if isinstance(data, np.ndarray):
            arr = data
        else:
            arr = np.asarray(data)
            if arr.dtype not in _NP_TO_DTYPE and arr.dtype.kind in "iu":
                arr = arr.astype(np.int64)
        # f64 is numpy's default float (np.random.randn, python floats):
        # treat it as f32 like torch does; f64 is not a supported dtype
        if arr.dtype == np.float64:
            arr = arr.astype(np.float32)
        if dtype is not None and dtype_of_numpy(arr) != dtype:
            arr = arr.astype(np_dtype_of(dtype))
        out = from_numpy(arr, device=device)
        self._steal(out)
        self.requires_grad = requires_grad
        if requires_grad and self.dtype.is_int:
            raise RuntimeError("only float tensors can require gradients")

    def _steal(self, other: "Tensor"):
        """Take over another tensor's storage + autograd state, consuming
        the source (its reference moves to self)."""
        buf = other._storage
        self._release_storage()
        self._share(other)
        # ownership transfer, not a second owner: undo _share's +1 on the
        # consumed source or every _steal leaks one pool block
        if buf is not None and getattr(buf, "_pool", None) is not None:
            buf._owners -= 1
        other._storage = None  # source consumed: reference moved, not shared

    def _share(self, other: "Tensor"):
        """Copy metadata/autograd state and share the storage reference
        (owner count incremented by _make on the creation side)."""
        self._release_storage()
        self._storage = other._storage
        if getattr(other._storage, "_pool", None) is not None:
            other._storage._owners += 1
        self.shape = other.shape
        self.dtype = other.dtype
        self.device = other.device
        self._st = other._st
        self._offset = other._offset
        self.requires_grad = other.requires_grad
        self.grad = other.grad
        self.grad_fn = other.grad_fn

    def _release_storage(self):
        """Decrement the pooled-buffer owner count, freeing on last use."""
        buf = getattr(self, "_storage", None)
        if buf is not None and getattr(buf, "_pool", None) is not None:
            buf._owners -= 1
            if buf._owners == 0:
                buf.free()
        self._storage = None

    def __del__(self):
        try:
            self._release_storage()
        except Exception:
            pass

    def __copy__(self):
        """copy.copy: a new tensor object sharing storage, with proper
        pool-owner accounting (the default slots copy would bypass
        _owners and free a live buffer on the first death)."""
        t = type(self)._make(self._storage, self.shape, self.dtype,
                             self.device, self._st, self._offset)
        t.requires_grad = self.requires_grad
        t.grad_fn = self.grad_fn
        return t

    def __deepcopy__(self, memo):
        """copy.deepcopy: clone semantics (own storage, data copied;
        requires_grad preserved, grad/grad_fn not inherited)."""
        from . import ops
        out = empty(self.shape, self.dtype, self.device)
        if self.numel():
            ops._copy_into_view(out, self.contiguous())
        out.requires_grad = self.requires_grad
        return out

    @classmethod
    def _make(cls, storage, shape, dtype, device, strides=None, offset=0):
        t = cls.__new__(cls)
        t._storage = storage
        t.shape = tuple(int(s) for s in shape)
        t.dtype = dtype
        t.device = device
        t._st = tuple(strides) if strides is not None else \
            _contig_strides(t.shape)
        t._offset = int(offset)
        t.requires_grad = False
        t.grad = None
        t.grad_fn = None
        if device == "cuda" and getattr(storage, "_pool", None) is not None:
            # pooled device buffer: track live tensor owners explicitly so
            # the pool return happens on the last tensor death, not on
            # Buffer.__del__ timing (see runtime/allocator.py notes)
            storage._owners += 1
        return t

    # -- basic metadata ---------------------------------------------------------

    @property
    def ndim(self) -> int:
        return len(self.shape)

    @property
    def strides(self) -> tuple[int, ...]:
        if self.device == "cpu":
            return tuple(s // self.dtype.itemsize
                         for s in self._storage.strides)
        return self._st

    def stride(self, dim: int | None = None):
        if dim is None:
            return self.strides
        return self.strides[canonical_dim(dim, self.ndim)]

    def numel(self) -> int:
        return math.prod(self.shape) if self.shape else 1

    def is_contiguous(self) -> bool:
        return _is_contiguous(self.shape, self.strides)

    # -- host roundtrip ---------------------------------------------------------

    def numpy(self) -> np.ndarray:
        if self.device == "cpu":
            return self._storage
        t = self if self.is_contiguous() else self.contiguous()
        if self.dtype == tl_types.bfloat16:
            t = t.astype(tl_types.float32)
        buf = t._buffer_arg()  # view at the tensor's offset
        return buf.to_numpy()[:t.numel()].reshape(t.shape)

    def item(self):
        if self.numel() != 1:
            raise RuntimeError(
                f"item() requires a single-element tensor, got {self.shape}")
        return self.numpy().reshape(()).item()

    def cpu(self) -> "Tensor":
        return self.to(device="cpu")

    def cuda(self) -> "Tensor":
        return self.to(device="cuda")

    def to(self, device: str | DType | None = None,
           dtype: DType | None = None) -> "Tensor":
        if isinstance(device, DType):
            device, dtype = None, device
        device = device or self.device
        out = self
        if device != self.device:
            if device == "cpu":
                arr = np.array(self.numpy())
                out = Tensor._make(arr, arr.shape, dtype_of_numpy(arr), "cpu")
            elif device == "cuda":
                out = from_numpy(np.ascontiguousarray(self.numpy()),
                                 device="cuda")
            else:
                raise ValueError(f"unknown device {device!r} (want cpu/cuda)")
            out = _record_view(self, out, "to", device)
        if dtype is not None and dtype != out.dtype:
            out = out.astype(dtype)
        return out

    def astype(self, dtype: DType) -> "Tensor":
        if dtype == self.dtype:
            return self
        from . import ops
        return ops.astype(self, dtype)

    # -- autograd (see autograd/engine.py) --------------------------------------

    @property
    def is_leaf(self) -> bool:
        return self.grad_fn is None

    def requires_grad_(self, requires_grad: bool = True) -> "Tensor":
        if self.grad_fn is not None:
            raise RuntimeError(
                "you can only change requires_grad flags of leaf variables")
        if requires_grad and self.dtype.is_int:
            raise RuntimeError("only float tensors can require gradients")
        self.requires_grad = requires_grad
        return self

    def detach(self) -> "Tensor":
        """A new tensor sharing storage, cut off from the tape."""
        if self.device == "cpu":
            out = Tensor._make(self._storage, self.shape, self.dtype, "cpu")
        else:
            out = Tensor._make(self._storage, self.shape, self.dtype, "cuda",
                               self._st, self._offset)
        return out

    def backward(self, grad: "Tensor | None" = None):
        """Reverse-mode autodiff from this tensor (scalar if grad is None)."""
        from .autograd import engine
        engine.backward(self, grad)

    def zero_grad(self):
        self.grad = None


    # -- views (pure metadata on cuda, native numpy views on cpu) ----------------

    def _view(self, shape, strides, offset) -> "Tensor":
        """cuda strided-view constructor (metadata only)."""
        return Tensor._make(self._storage, shape, self.dtype, "cuda",
                            strides, self._offset + offset)

    def _view_flat(self, shape) -> "Tensor":
        """view with contiguous strides; requires self contiguous."""
        assert self.is_contiguous()
        if self.device == "cpu":
            return Tensor._make(self._storage.reshape(shape), shape,
                                self.dtype, "cpu")
        return self._view(shape, _contig_strides(shape), 0)

    def _cpu_view(self, arr: np.ndarray) -> "Tensor":
        return Tensor._make(arr, arr.shape, self.dtype, "cpu")

    def reshape(self, *shape) -> "Tensor":
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        shape = list(shape)
        neg = [i for i, s in enumerate(shape) if s == -1]
        if len(neg) > 1:
            raise RuntimeError("only one dimension can be -1")
        if neg:
            known = math.prod(s for s in shape if s != -1)
            if known == 0 or self.numel() % known != 0:
                raise RuntimeError(
                    f"cannot reshape {self.shape} to {tuple(shape)}")
            shape[neg[0]] = self.numel() // known
        shape = tuple(int(s) for s in shape)
        if math.prod(shape) != self.numel():
            raise RuntimeError(f"cannot reshape {self.shape} to {shape}")
        if self.device == "cpu":
            return _record_view(self, self._cpu_view(self._storage.reshape(shape)),
                                "reshape", shape)
        st = _reshape_strides(self.shape, self.strides, shape)
        if st is not None:
            return _record_view(self, self._view(shape, st, 0), "reshape", shape)
        out = self.contiguous()._view_flat(shape)
        return _record_view(self, out, "reshape", shape)

    def view(self, *shape) -> "Tensor":
        """torch view semantics: like reshape but errors when a copy would
        be needed."""
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        shape = tuple(int(s) for s in shape)
        st = _reshape_strides(self.shape, self.strides, shape)
        if st is None:
            raise RuntimeError(
                f"view of shape {shape} is incompatible with tensor shape "
                f"{self.shape} and strides {self.strides}; use reshape")
        if self.device == "cpu":
            return _record_view(self, self._cpu_view(self._storage.reshape(shape)),
                                "reshape", shape)
        return _record_view(self, self._view(shape, st, 0), "reshape", shape)

    def permute(self, *dims) -> "Tensor":
        if len(dims) == 1 and isinstance(dims[0], (tuple, list)):
            dims = tuple(dims[0])
        dims = tuple(canonical_dim(d, self.ndim) for d in dims)
        if sorted(dims) != list(range(self.ndim)):
            raise RuntimeError(f"invalid permutation {dims} for {self.shape}")
        if self.device == "cpu":
            return _record_view(self, self._cpu_view(np.transpose(self._storage, dims)),
                                "permute", dims)
        out = self._view(tuple(self.shape[d] for d in dims),
                         tuple(self.strides[d] for d in dims), 0)
        return _record_view(self, out, "permute", dims)

    def transpose(self, dim0: int, dim1: int) -> "Tensor":
        dims = list(range(self.ndim))
        d0, d1 = canonical_dim(dim0, self.ndim), canonical_dim(dim1, self.ndim)
        dims[d0], dims[d1] = dims[d1], dims[d0]
        return self.permute(dims)

    def t(self) -> "Tensor":
        if self.ndim != 2:
            raise RuntimeError("t() expects a 2D tensor")
        return self.transpose(0, 1)

    def unsqueeze(self, dim: int) -> "Tensor":
        dim = dim if dim >= 0 else dim + self.ndim + 1
        if not (0 <= dim <= self.ndim):
            raise RuntimeError(f"unsqueeze dim {dim} out of range")
        if self.device == "cpu":
            return _record_view(self, self._cpu_view(np.expand_dims(self._storage, dim)),
                                "unsqueeze", dim)
        shape = self.shape[:dim] + (1,) + self.shape[dim:]
        st = self.strides
        new_st = st[:dim] + ((st[dim] * self.shape[dim]) if dim < self.ndim
                             else 1,) + st[dim:]
        return _record_view(self, self._view(shape, new_st, 0), "unsqueeze", dim)

    def squeeze(self, dim: int | None = None) -> "Tensor":
        if dim is not None:
            dim = canonical_dim(dim, self.ndim)
            if self.shape[dim] != 1:
                return self  # torch: squeezing a non-1 dim is a no-op
        if self.device == "cpu":
            return _record_view(self, self._cpu_view(np.squeeze(self._storage, axis=dim)),
                                "reshape", self.shape)
        if dim is not None:
            shape = self.shape[:dim] + self.shape[dim + 1:]
            st = self.strides[:dim] + self.strides[dim + 1:]
            return _record_view(self, self._view(shape, st, 0), "reshape",
                                self.shape)
        shape, st = [], []
        for s, t in zip(self.shape, self.strides):
            if s != 1:
                shape.append(s)
                st.append(t)
        return _record_view(self, self._view(tuple(shape), tuple(st), 0),
                            "reshape", self.shape)

    def broadcast_to(self, shape) -> "Tensor":
        shape = tuple(int(s) for s in shape)
        st = _broadcast_strides(self.shape, self.strides, shape)
        if st is None:
            raise RuntimeError(f"cannot broadcast {self.shape} to {shape}")
        if self.device == "cpu":
            return _record_view(self, self._cpu_view(np.broadcast_to(self._storage, shape)),
                                "broadcast_to", self.shape)
        return _record_view(self, self._view(shape, st, 0), "broadcast_to",
                            self.shape)

    def expand(self, *shape) -> "Tensor":
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        if len(shape) != self.ndim:
            raise RuntimeError(f"expand to {shape} from {self.shape}")
        shape = tuple(self.shape[i] if s == -1 else int(s)
                      for i, s in enumerate(shape))
        return self.broadcast_to(shape)

    def contiguous(self) -> "Tensor":
        if self.is_contiguous():
            return self
        from . import ops
        return ops.contiguous(self)

    # -- indexing ------------------------------------------------------------

    def __getitem__(self, idx) -> "Tensor":
        if not isinstance(idx, tuple):
            idx = (idx,)
        if any(i is Ellipsis for i in idx):
            e = idx.index(Ellipsis)
            # boolean scalars insert a new axis WITHOUT consuming a dim
            # (same accounting as n_consume below): t[True, ..., 0] on a
            # (2,3) tensor fills exactly one slice for "..."
            n_fill = self.ndim - sum(
                0 if isinstance(i, (bool, np.bool_)) else 1
                for i in idx if i is not Ellipsis)
            idx = idx[:e] + (slice(None),) * max(0, n_fill) + idx[e + 1:]
        # boolean scalars insert a new axis WITHOUT consuming a dim
        # (numpy semantics); pad the remaining dims after them
        n_consume = sum(0 if isinstance(i, (bool, np.bool_)) else 1
                        for i in idx)
        idx = idx + (slice(None),) * (self.ndim - n_consume)
        if n_consume > self.ndim:
            raise IndexError(f"too many indices for {self.shape}")
        if any(isinstance(i, (list, np.ndarray, Tensor)) for i in idx):
            raise IndexError(
                "fancy indexing is not supported (v1: ints and slices only)")
        if self.device == "cpu":
            out = self._storage[idx]
            if not isinstance(out, np.ndarray):
                # an all-int index makes numpy return a scalar copy; rebuild
                # it as a 0-d slice view so writes through it (the grad
                # scatter in autograd) reach the base storage
                keep = []
                for d, i in enumerate(idx):
                    j = int(i)
                    if j < 0:
                        j += self._storage.shape[d]
                    keep.append(slice(j, j + 1))
                out = self._storage[tuple(keep)].reshape(())
            return _record_view(self, self._cpu_view(out), "getitem", idx)
        shape, st, offset = [], [], 0
        src_st = self.strides
        d = 0
        for i in idx:
            if isinstance(i, (bool, np.bool_)):
                # a boolean scalar index adds a new axis (size 1 or 0) and
                # indexes nothing: t[True] on (2,4) -> (1,2,4)
                shape.append(1 if i else 0)
                st.append(0)
                continue
            if isinstance(i, (int, np.integer)):
                n = self.shape[d]
                j = int(i)
                if j < 0:
                    j += n
                if not (0 <= j < n):
                    raise IndexError(f"index {i} out of bounds for dim {d} "
                                     f"of size {n}")
                offset += j * src_st[d]
                d += 1
            elif isinstance(i, slice):
                start, stop, step = i.indices(self.shape[d])
                length = max(0, (stop - start + (step - 1 if step > 0 else
                                                 step + 1)) // step)
                offset += start * src_st[d]
                shape.append(length)
                st.append(src_st[d] * step)
                d += 1
            else:
                raise IndexError(f"unsupported index type {type(i).__name__}")
        return _record_view(self, self._view(tuple(shape), tuple(st), offset),
                            "getitem", idx)

    def __setitem__(self, idx, value):
        raise NotImplementedError(
            "in-place indexed assignment is not supported (v1)")

    # -- operator overloads (delegate to ops) -----------------------------------

    def __add__(self, other):
        from . import ops
        return ops.add(self, other)

    def __radd__(self, other):
        from . import ops
        return ops.add(other, self)

    def __sub__(self, other):
        from . import ops
        return ops.sub(self, other)

    def __rsub__(self, other):
        from . import ops
        return ops.sub(other, self)

    def __mul__(self, other):
        from . import ops
        return ops.mul(self, other)

    def __rmul__(self, other):
        from . import ops
        return ops.mul(other, self)

    def __truediv__(self, other):
        from . import ops
        return ops.div(self, other)

    def __rtruediv__(self, other):
        from . import ops
        return ops.div(other, self)

    def __pow__(self, other):
        from . import ops
        return ops.pow(self, other)

    def __rpow__(self, other):
        from . import ops
        return ops.pow(other, self)

    def __neg__(self):
        from . import ops
        return ops.neg(self)

    def __abs__(self):
        from . import ops
        return ops.abs(self)

    def __matmul__(self, other):
        from . import ops
        return ops.matmul(self, other)

    # -- comparisons: elementwise f32 1.0/0.0 mask (no bool dtype) ---------
    # __hash__ pinned: defining __eq__ would reset it to None, but autograd
    # and the optimizer key dicts/sets on tensor identity.

    __hash__ = object.__hash__

    def __eq__(self, other):
        from . import ops
        return ops.eq(self, other)

    def __ne__(self, other):
        from . import ops
        return ops.ne(self, other)

    def __lt__(self, other):
        from . import ops
        return ops.lt(self, other)

    def __le__(self, other):
        from . import ops
        return ops.le(self, other)

    def __gt__(self, other):
        from . import ops
        return ops.gt(self, other)

    def __ge__(self, other):
        from . import ops
        return ops.ge(self, other)

    # -- in-place arithmetic: write the out-of-place result back through
    # (possibly a strided view) like torch's `v += rhs`. Not autograd-tracked
    # — rejected on requires-grad tensors.

    def _inplace_write(self, out):
        from . import ops
        if self.requires_grad:
            raise RuntimeError(
                "in-place operations on a tensor that requires grad are "
                "not supported (autograd is not tracked through in-place "
                "writes); use the out-of-place form x = x + y")
        ops._copy_into_view(self, out)
        return self

    def __iadd__(self, other):
        from . import ops
        return self._inplace_write(ops.add(self, other))

    def __isub__(self, other):
        from . import ops
        return self._inplace_write(ops.sub(self, other))

    def __imul__(self, other):
        from . import ops
        return self._inplace_write(ops.mul(self, other))

    def __itruediv__(self, other):
        from . import ops
        return self._inplace_write(ops.div(self, other))

    # -- reduction / nn method shortcuts --------------------------------------

    def sum(self, dim=None, keepdim=False, dtype=None):
        from . import ops
        return ops.sum(self, dim=dim, keepdim=keepdim, dtype=dtype)

    def mean(self, dim=None, keepdim=False, dtype=None):
        from . import ops
        return ops.mean(self, dim=dim, keepdim=keepdim, dtype=dtype)

    def max(self, dim=None, keepdim=False):
        from . import ops
        return ops.max(self, dim=dim, keepdim=keepdim)

    def min(self, dim=None, keepdim=False):
        from . import ops
        return ops.min(self, dim=dim, keepdim=keepdim)

    def argmax(self, dim=None, keepdim=False):
        from . import ops
        return ops.argmax(self, dim=dim, keepdim=keepdim)

    def softmax(self, dim=-1):
        from . import ops
        return ops.softmax(self, dim=dim)

    def log_softmax(self, dim=-1):
        from . import ops
        return ops.log_softmax(self, dim=dim)

    # -- misc ------------------------------------------------------------------

    @property
    def data(self):
        """The raw storage: a Buffer (cuda) or numpy ndarray (cpu)."""
        return self._storage

    def _buffer_arg(self) -> Buffer:
        """Device pointer view (with offset applied) for kernel launches."""
        assert self.device == "cuda"
        if self._offset == 0:
            return self._storage
        return _ViewBuffer(self._storage, self._offset)

    def __len__(self):
        if self.ndim == 0:
            raise TypeError("len() of a 0-d tensor")
        return self.shape[0]

    def __bool__(self):
        # torch semantics: multi-element truth value is ambiguous
        if self.numel() != 1:
            raise RuntimeError(
                "Boolean value of Tensor with more than one element is "
                "ambiguous")
        return bool(self.item())

    def __float__(self):
        return float(self.item())

    def __int__(self):
        return int(self.item())

    def __repr__(self):
        return (f"tl.Tensor({self.numpy()}, shape={self.shape}, "
                f"dtype={self.dtype}, device={self.device!r})"
                if self.numel() <= 64 else
                f"tl.Tensor(shape={self.shape}, dtype={self.dtype}, "
                f"device={self.device!r})")


# ---------------------------------------------------------------------------
# stride algorithms (torch-compatible view rules)
# ---------------------------------------------------------------------------

def _reshape_strides(old_shape, old_st, new_shape):
    """Strides for a view of new_shape, or None if a copy is required
    (torch's view compatibility algorithm: merge adjacent dims whose
    strides chain, then assign greedily)."""
    if _is_contiguous(old_shape, old_st):
        return _contig_strides(new_shape)
    # merge collapsible dims of the old tensor
    dims, sts = [], []
    for s, st in zip(old_shape, old_st):
        if s == 1:
            continue
        if dims and sts[-1] == st * s:
            dims[-1] *= s
            sts[-1] = st
        else:
            dims.append(s)
            sts.append(st)
    new = [s for s in new_shape if s != 1]
    out_st = {}
    i, j = len(dims) - 1, len(new) - 1
    while i >= 0 and j >= 0:
        if dims[i] == new[j]:
            out_st[j] = sts[i]
            i -= 1
            j -= 1
        elif new[j] < dims[i] and dims[i] % new[j] == 0:
            # split old dim (dims[i], sts[i]): the inner part keeps the old
            # stride; the remaining outer part continues at stride*new[j]
            out_st[j] = sts[i]
            sts[i] *= new[j]
            dims[i] //= new[j]
            j -= 1
        else:
            return None
    if i >= 0:
        return None
    # rebuild with size-1 dims (stride value irrelevant; keep it sane)
    res, k = [], 0
    for s in new_shape:
        if s == 1:
            res.append(out_st.get(k, 1))
        else:
            res.append(out_st[k])
            k += 1
    return tuple(res)


def _broadcast_strides(old_shape, old_st, new_shape):
    nd = len(new_shape) - len(old_shape)
    if nd < 0:
        return None
    st = [0] * nd
    for i, (s, t) in enumerate(zip(old_shape, old_st)):
        ns = new_shape[nd + i]
        if s == ns:
            st.append(t)
        elif s == 1:
            st.append(0)
        else:
            return None
    return tuple(st)


# ---------------------------------------------------------------------------
# creation functions (public API)
# ---------------------------------------------------------------------------

def from_numpy(arr: np.ndarray, device: str = "cuda") -> Tensor:
    arr = np.asarray(arr)
    dtype = dtype_of_numpy(arr)
    if device == "cpu":
        return Tensor._make(arr, arr.shape, dtype, "cpu")
    if device != "cuda":
        raise ValueError(f"unknown device {device!r}")
    if arr.size == 0:
        # zero-element tensors are legal (torch allows them); Buffer
        # requires >=1 element, so allocate the same 1-element pad as
        # empty() and keep the true (zero) shape
        buf = _alloc(1, dtype)
        return Tensor._make(buf, arr.shape, dtype, "cuda")
    buf = Buffer.from_numpy(np.ascontiguousarray(arr))
    return Tensor._make(buf, arr.shape, dtype, "cuda")


def tensor(data, dtype: DType | None = None, device: str = "cuda",
           requires_grad: bool = False) -> Tensor:
    return Tensor(data, dtype=dtype, device=device, requires_grad=requires_grad)


def empty(shape, dtype: DType = tl_types.float32, device: str = "cuda") -> Tensor:
    if isinstance(shape, int):
        shape = (shape,)
    shape = tuple(shape)
    numel = math.prod(shape) if shape else 1
    if device == "cpu":
        return Tensor._make(np.empty(shape, dtype=np_dtype_of(dtype)),
                            shape, dtype, "cpu")
    buf = _alloc(max(numel, 1), dtype)
    return Tensor._make(buf, shape, dtype, "cuda")


def zeros(shape, dtype: DType = tl_types.float32, device: str = "cuda") -> Tensor:
    t = empty(shape, dtype, device)
    if device == "cpu":
        t._storage[...] = 0
        return t
    nbytes = t.numel() * dtype.itemsize
    t._storage.device.memset32(t._storage.ptr, 0, (nbytes + 3) // 4)
    return t


def ones(shape, dtype: DType = tl_types.float32, device: str = "cuda") -> Tensor:
    t = empty(shape, dtype, device)
    if device == "cpu":
        t._storage[...] = 1
        return t
    pattern = {
        "f32": 0x3F800000, "f16": 0x3C003C00, "bf16": 0x3F803F80,
        "i32": 1,
    }.get(dtype.name)
    if pattern is None:  # i64: memset pattern would be wrong; go via host
        return from_numpy(np.ones(shape, dtype=np.int64), device="cuda")
    nbytes = t.numel() * dtype.itemsize
    t._storage.device.memset32(t._storage.ptr, pattern, (nbytes + 3) // 4)
    return t


def arange(start, end=None, step=1, dtype: DType | None = None,
           device: str = "cuda") -> Tensor:
    if end is None:
        start, end = 0, start
    if dtype is None:
        dtype = tl_types.float32 if any(
            isinstance(v, float) for v in (start, end, step)) \
            else tl_types.int64
    arr = np.arange(start, end, step, dtype=np_dtype_of(dtype))
    return from_numpy(arr, device=device)


def eye(n: int, m: int | None = None, dtype: DType = tl_types.float32,
        device: str = "cuda") -> Tensor:
    """(n, m) with 1s on the main diagonal (m defaults to n). Host-built
    then uploaded, like arange."""
    arr = np.eye(n, m, dtype=np_dtype_of(dtype))
    return from_numpy(arr, device=device)


def randn(*shape, dtype: DType = tl_types.float32, device: str = "cuda",
          seed: int | None = None) -> Tensor:
    if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
        shape = tuple(shape[0])
    rng = np.random.default_rng(seed)
    arr = rng.standard_normal(shape).astype(np_dtype_of(dtype))
    return from_numpy(arr, device=device)
