"""Canonical pipeline choreography skeletons (minitriton/sched).

Each helper is a `@tl.inline` DSL function: pure `tl.*` vocabulary,
inlined into the caller's kernel at trace time. The skeleton here is
the canonical 2-stage whole-K GEMM pipeline (single-buffer rotation
via tl.pipelined): A tiles re-read per iteration (L1-resident), the B
stream double-times through one staging pipe.
"""

from __future__ import annotations

import minitriton as tl


@tl.inline
def gemm_2stage_bf16(a_ptr, b_ptr, K, sam, sbk, offs_m, offs_n, acc,
                     BM: tl.constexpr, BK: tl.constexpr, BN: tl.constexpr):
    """Canonical 2-stage bf16 whole-K GEMM pipeline (scheduling skeleton,
    not an application kernel): computes acc(BM, BN) += A(BM, K) @
    B(K, BN) over K in BK steps — A row-major tiles (row stride `sam`)
    re-loaded per iteration, B tiles (row stride `sbk`) streamed through
    one tl.pipelined single-buffer rotation. `acc` is the caller's
    Fragment("C") accumulator (mma_layout("C", (BM, BN), "bf16")) and the
    result is returned for the caller's epilogue/store.

    Contract: K % BK == 0 (checked when K is compile-time; the caller
    guarantees it otherwise), offs_m/offs_n are the caller's (BM,)/(BN,)
    block offsets, a/b are bf16 with unit stride along K/N.
    """
    offs_k = tl.arange(0, BK)
    lay_a = tl.mma_layout("A", (BM, BK), "bf16")
    b_pipe = tl.stage_pipe((BK, BN), tl.bfloat16, EVEN=True)
    for k0 in tl.pipelined(range(0, K, BK), stages=2):
        a_fr = tl.load(a_ptr + offs_m[:, None] * sam + (k0 + offs_k)[None, :],
                       LAYOUT=lay_a)
        acc = tl.mma(a_fr, p_b, acc)
        p_b = tl.stage(b_pipe,
                       b_ptr + (k0 + offs_k)[:, None] * sbk + offs_n[None, :])
    return acc
