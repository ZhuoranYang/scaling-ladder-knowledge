"""MiniTriton: Python tile DSL -> MLIR -> PTX -> GPU, plus an eager
tensor library with numpy CPU and DSL-kernel CUDA backends."""

from . import _mlir  # noqa: F401  (actionable error when MLIR is missing)

from .frontend.types import (  # noqa: F401
    bfloat16,
    constexpr,
    float16,
    float32,
    int32,
    int64,
    pointer,
)
from .frontend.code_generator import kernel, Kernel, DSLCompileError, inline  # noqa: F401
from .runtime.buffer import Buffer, get_device  # noqa: F401
from .runtime.autotune import Config, autotune, do_bench  # noqa: F401

# eager tensor library
from .tensor import (  # noqa: F401
    Tensor,
    arange,
    empty,
    eye,
    from_numpy,
    ones,
    randn,
    tensor,
    zeros,
)
from . import ops  # noqa: F401
from .ops import (  # noqa: F401
    abs,
    add,
    add_layernorm,
    argmax,
    astype,
    bmm,
    broadcast_to,
    cat,
    contiguous,
    cross_entropy,
    div,
    embedding,
    exp,
    gelu,
    layer_norm,
    log,
    log_softmax,
    matmul,
    max,
    mean,
    min,
    mul,
    neg,
    pow,
    relu,
    rms_norm,
    sigmoid,
    silu,
    softmax,
    split,
    sqrt,
    sub,
    sum,
    swiglu,
    tanh,
)

from .compile import compile  # noqa: F401

# autograd
from .autograd import Function, no_grad  # noqa: F401
from .runtime.allocator import memory_stats, reset_peak_stats  # noqa: F401
from . import nn  # noqa: F401
from . import sparse  # noqa: F401
from . import distributed  # noqa: F401
from . import viz  # noqa: F401

try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("minitriton")
except Exception:  # source tree without an installed distribution
    __version__ = "0.1.0"


def synchronize() -> None:
    """Block until the whole default device is idle (all streams,
    including MT_STREAM_OVERLAP side streams)."""
    get_device().synchronize()
