"""Normalization row kernels of the device/cuda kernels package:
softmax/log_softmax fwd+bwd, layer_norm/rms_norm fwd, add_LN, and
the fused LN-bwd family (single-pass dx, per-row stats, col-stats
partials + folds).

All kernels assume the *last* dim of every operand is unit-stride (the
eager layer calls .contiguous() when that is not the case); other strides
are runtime i32 arguments.

``import minitriton as tl`` here resolves against the partially initialized
package (frontend/runtime names are exported before the eager layer is
imported), which is what makes the decorators work at import time.

NOTE: no ``from __future__ import annotations`` here — kernel parameter
annotations (``tl.constexpr``) must stay real objects for the DSL binder.
"""

import minitriton as tl
from ._common import _row_block, _col_vec_bc, col_sum_geometry

_I32_ELEM_BUDGET = 2**31 - 1


def _i32_row_budget(C: int, itemsize: int) -> int:
    """Rows per launch: keep element offsets below 2**31 (i32 addressing)
    and the row-chunk view bases 16B-aligned (the vectorized load/store
    path assumes an aligned base; a row slice at an unaligned element
    offset would fault). Same discipline as ce.py's _ce_i32_row_budget."""
    align = 16 // itemsize
    budget = _I32_ELEM_BUDGET // C // align
    if budget == 0:
        raise NotImplementedError(
            f"row length {C} is too wide to chunk under i32 addressing")
    return budget * align


# ---------------------------------------------------------------------------
# softmax / log_softmax
# ---------------------------------------------------------------------------

@tl.kernel
def softmax_row_kernel(x_ptr, out_ptr, C,
                       LOG: tl.constexpr, CALC_F32: tl.constexpr,
                       OUT_DT: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=float("-inf"))
    if CALC_F32:
        # sub-f32 floats compute in f32 (the reduce family's CALC_F32
        # discipline); OUT_DT packs the f32 result back on store
        x = tl.cast(x, tl.float32)
    x_max = tl.max(x)
    e = tl.exp(x - x_max)
    s = tl.sum(e)
    if LOG:
        y = (x - x_max) - tl.log(s)
    else:
        y = e / s
    tl.store(out_ptr + row * C + offs, tl.cast(y, OUT_DT), mask=m)


def launch_softmax(x, out, C: int, log: bool):
    R = x.numel() // C if C else 0
    if R == 0:
        return
    budget = _i32_row_budget(C, x.dtype.itemsize)
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_softmax(x[r0:r1], out[r0:r1], C, log)
        return
    block = _row_block(C)
    calc_f32 = x.dtype.is_float and x.dtype.itemsize < 4
    softmax_row_kernel[(R,)](x._buffer_arg(), out._buffer_arg(), C,
                             LOG=log, CALC_F32=calc_f32, OUT_DT=out.dtype,
                             BLOCK=block, num_warps=4)



# ---------------------------------------------------------------------------
# layer_norm / rms_norm (over the last dim; weight/bias optional)
# ---------------------------------------------------------------------------

@tl.kernel
def layernorm_kernel(x_ptr, w_ptr, b_ptr, out_ptr, C, eps,
                     HAS_W: tl.constexpr, HAS_B: tl.constexpr,
                     CALC_F32: tl.constexpr, OUT_DT: tl.constexpr,
                     BLOCK: tl.constexpr):
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    if CALC_F32:
        # sub-f32 floats compute in f32 (CALC_F32 discipline)
        x = tl.cast(x, tl.float32)
    inv_c = 1.0 / C
    mean = tl.sum(x) * inv_c
    d = tl.where(m, x - mean, 0.0)  # masked lanes must not pollute var
    var = tl.sum(d * d) * inv_c
    rstd = 1.0 / tl.sqrt(var + eps)
    y = d * rstd
    if HAS_W:
        w = tl.load(w_ptr + offs, mask=m, other=0.0)
        y = y * w
    if HAS_B:
        bb = tl.load(b_ptr + offs, mask=m, other=0.0)
        y = y + bb
    # pack-on-store: f32 compute, out elem dtype store (the cast-fusion
    # producer seam — same rounding as a separate astype pass, without
    # materializing it; a no-op when OUT_DT is f32)
    y = tl.cast(y, OUT_DT)
    tl.store(out_ptr + row * C + offs, y, mask=m)


@tl.kernel
def rmsnorm_kernel(x_ptr, w_ptr, out_ptr, C, eps,
                   HAS_W: tl.constexpr, CALC_F32: tl.constexpr,
                   OUT_DT: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    if CALC_F32:
        x = tl.cast(x, tl.float32)
    ms = tl.sum(x * x) * (1.0 / C)
    rstd = 1.0 / tl.sqrt(ms + eps)
    y = x * rstd
    if HAS_W:
        w = tl.load(w_ptr + offs, mask=m, other=0.0)
        y = y * w
    tl.store(out_ptr + row * C + offs, tl.cast(y, OUT_DT), mask=m)


def launch_layernorm(x, w, b, out, C: int, eps: float):
    R = x.numel() // C if C else 0
    if R == 0:
        return
    budget = _i32_row_budget(C, min(x.dtype.itemsize, out.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        # Not plan-cacheable (a host launch loop): the None handle makes
        # the eager layer skip its plan cache for this call.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_layernorm(x[r0:r1], w, b, out[r0:r1], C, eps)
        return None
    block = _row_block(C)
    dummy = x  # unused pointer when HAS_W/HAS_B is False
    return layernorm_kernel[(R,)](
        x._buffer_arg(),
        (w if w is not None else dummy)._buffer_arg(),
        (b if b is not None else dummy)._buffer_arg(),
        out._buffer_arg(), C, eps,
        HAS_W=w is not None, HAS_B=b is not None,
        CALC_F32=x.dtype.is_float and x.dtype.itemsize < 4,
        OUT_DT=out.dtype,
        BLOCK=block, num_warps=4)


def launch_rmsnorm(x, w, out, C: int, eps: float):
    R = x.numel() // C if C else 0
    if R == 0:
        return
    budget = _i32_row_budget(C, x.dtype.itemsize)
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_rmsnorm(x[r0:r1], w, out[r0:r1], C, eps)
        return
    block = _row_block(C)
    rmsnorm_kernel[(R,)](x._buffer_arg(),
                         (w if w is not None else x)._buffer_arg(),
                         out._buffer_arg(), C, eps,
                         HAS_W=w is not None,
                         CALC_F32=x.dtype.is_float and x.dtype.itemsize < 4,
                         OUT_DT=out.dtype, BLOCK=block, num_warps=4)


@tl.kernel
def add_layernorm_kernel(x_ptr, res_ptr, w_ptr, b_ptr, out_ptr, s_ptr, C, eps,
                         HAS_W: tl.constexpr, HAS_B: tl.constexpr,
                         HAS_S: tl.constexpr, CALC_F32: tl.constexpr,
                         OUT_DT: tl.constexpr, BLOCK: tl.constexpr):
    """Fused residual-add + layer_norm (case-fusions): s = x + res inline,
    out = layer_norm(s); s is optionally stored (the next block's residual
    input / the fused backward's saved input)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    r = tl.load(res_ptr + row * C + offs, mask=m, other=0.0)
    if CALC_F32:
        x = tl.cast(x, tl.float32)
        r = tl.cast(r, tl.float32)
    s = x + r
    if HAS_S:
        tl.store(s_ptr + row * C + offs, tl.cast(s, OUT_DT), mask=m)
    inv_c = 1.0 / C
    mean = tl.sum(s) * inv_c
    d = tl.where(m, s - mean, 0.0)  # masked lanes must not pollute var
    var = tl.sum(d * d) * inv_c
    rstd = 1.0 / tl.sqrt(var + eps)
    y = d * rstd
    if HAS_W:
        w = tl.load(w_ptr + offs, mask=m, other=0.0)
        y = y * w
    if HAS_B:
        bb = tl.load(b_ptr + offs, mask=m, other=0.0)
        y = y + bb
    tl.store(out_ptr + row * C + offs, tl.cast(y, OUT_DT), mask=m)


def launch_add_layernorm(x, res, w, b, out, s, C: int, eps: float):
    """x/res (R, C) contiguous rows -> out = layer_norm(x + res); s (same
    shape or None) receives the residual sum when requested."""
    R = x.numel() // C if C else 0
    if R == 0:
        return
    budget = _i32_row_budget(C, x.dtype.itemsize)
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_add_layernorm(x[r0:r1], res[r0:r1], w, b, out[r0:r1],
                                 s[r0:r1] if s is not None else None, C, eps)
        return
    block = _row_block(C)
    dummy = x  # unused pointer when HAS_W/HAS_B/HAS_S is False
    add_layernorm_kernel[(R,)](
        x._buffer_arg(), res._buffer_arg(),
        (w if w is not None else dummy)._buffer_arg(),
        (b if b is not None else dummy)._buffer_arg(),
        out._buffer_arg(),
        (s if s is not None else dummy)._buffer_arg(), C, eps,
        HAS_W=w is not None, HAS_B=b is not None,
        HAS_S=s is not None,
        CALC_F32=x.dtype.is_float and x.dtype.itemsize < 4,
        OUT_DT=out.dtype,
        BLOCK=block, num_warps=4)



# ---------------------------------------------------------------------------
# backward row kernels: fused single-pass
# counterparts of the forward row kernels, all on 2D contiguous rows.
# ---------------------------------------------------------------------------

@tl.kernel
def softmax_backward_row_kernel(g_ptr, y_ptr, dx_ptr, C,
                                LOG: tl.constexpr, CALC_F32: tl.constexpr,
                                OUT_DT: tl.constexpr, BLOCK: tl.constexpr):
    """LOG=False: dx = y * (g - sum(g*y))   (y = softmax(x))
    LOG=True:  dx = g - exp(y) * sum(g)     (y = log_softmax(x))"""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    g = tl.load(g_ptr + row * C + offs, mask=m, other=0.0)
    y = tl.load(y_ptr + row * C + offs, mask=m, other=0.0)
    if CALC_F32:
        g = tl.cast(g, tl.float32)
        y = tl.cast(y, tl.float32)
    if LOG:
        s = tl.sum(g)
        tl.store(dx_ptr + row * C + offs,
                 tl.cast(g - tl.exp(y) * s, OUT_DT), mask=m)
    else:
        s = tl.sum(g * y)
        tl.store(dx_ptr + row * C + offs,
                 tl.cast(y * (g - s), OUT_DT), mask=m)


def launch_softmax_backward(g, y, out, C: int, log: bool):
    R = g.numel() // C if C else 0
    if R == 0:
        return
    budget = _i32_row_budget(C, min(g.dtype.itemsize, y.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_softmax_backward(g[r0:r1], y[r0:r1], out[r0:r1], C, log)
        return
    block = _row_block(C)
    calc_f32 = (g.dtype.is_float and g.dtype.itemsize < 4) or \
        (y.dtype.is_float and y.dtype.itemsize < 4)
    softmax_backward_row_kernel[(R,)](g._buffer_arg(), y._buffer_arg(),
                                      out._buffer_arg(), C, LOG=log,
                                      CALC_F32=calc_f32, OUT_DT=out.dtype,
                                      BLOCK=block, num_warps=4)


@tl.kernel
def layernorm_backward_kernel(g_ptr, x_ptr, w_ptr, dx_ptr, xh_ptr, C, eps,
                              HAS_W: tl.constexpr, CALC_F32: tl.constexpr,
                              OUT_DT: tl.constexpr, BLOCK: tl.constexpr):
    """Per row: dx = rstd*(u - mean(u) - xhat*mean(u*xhat)), xhat stored as
    an auxiliary output (dw = sum_rows(g*xhat) computed by the caller).
    u = g*w (or g without weight)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    g = tl.load(g_ptr + row * C + offs, mask=m, other=0.0)
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    if CALC_F32:
        g = tl.cast(g, tl.float32)
        x = tl.cast(x, tl.float32)
    inv_c = 1.0 / C
    mean = tl.sum(x) * inv_c
    d = tl.where(m, x - mean, 0.0)  # masked lanes must not pollute var
    var = tl.sum(d * d) * inv_c
    rstd = 1.0 / tl.sqrt(var + eps)
    xh = d * rstd
    u = g
    if HAS_W:
        w = tl.load(w_ptr + offs, mask=m, other=0.0)
        u = g * w
    u_mean = tl.sum(u) * inv_c
    uxh_mean = tl.sum(u * xh) * inv_c
    dx = rstd * (u - u_mean - xh * uxh_mean)
    tl.store(dx_ptr + row * C + offs, tl.cast(dx, OUT_DT), mask=m)
    tl.store(xh_ptr + row * C + offs, tl.cast(xh, OUT_DT), mask=m)


@tl.kernel
def rmsnorm_backward_kernel(g_ptr, x_ptr, w_ptr, dx_ptr, xr_ptr, C, eps,
                            HAS_W: tl.constexpr, CALC_F32: tl.constexpr,
                            OUT_DT: tl.constexpr, BLOCK: tl.constexpr):
    """Per row: dx = rstd*(u - xr*mean(u*xr)) with xr = x*rstd (stored;
    dw = sum_rows(g*xr) computed by the caller). u = g*w (or g)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    g = tl.load(g_ptr + row * C + offs, mask=m, other=0.0)
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    if CALC_F32:
        g = tl.cast(g, tl.float32)
        x = tl.cast(x, tl.float32)
    inv_c = 1.0 / C
    ms = tl.sum(x * x) * inv_c
    rstd = 1.0 / tl.sqrt(ms + eps)
    xr = x * rstd
    u = g
    if HAS_W:
        w = tl.load(w_ptr + offs, mask=m, other=0.0)
        u = g * w
    uxr_mean = tl.sum(u * xr) * inv_c
    dx = rstd * (u - xr * uxr_mean)
    tl.store(dx_ptr + row * C + offs, tl.cast(dx, OUT_DT), mask=m)
    tl.store(xr_ptr + row * C + offs, tl.cast(xr, OUT_DT), mask=m)


def launch_layernorm_backward(g, x, w, dx, xh, C: int, eps: float):
    R = g.numel() // C if C else 0
    if R == 0:
        return
    budget = _i32_row_budget(C, min(g.dtype.itemsize, x.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        # Not plan-cacheable (see launch_layernorm).
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_layernorm_backward(g[r0:r1], x[r0:r1], w, dx[r0:r1],
                                      xh[r0:r1], C, eps)
        return None
    block = _row_block(C)
    calc_f32 = (g.dtype.is_float and g.dtype.itemsize < 4) or \
        (x.dtype.is_float and x.dtype.itemsize < 4)
    return layernorm_backward_kernel[(R,)](
        g._buffer_arg(), x._buffer_arg(),
        (w if w is not None else g)._buffer_arg(), dx._buffer_arg(),
        xh._buffer_arg(), C, eps,
        HAS_W=w is not None, CALC_F32=calc_f32, OUT_DT=dx.dtype,
        BLOCK=block, num_warps=4)


@tl.kernel
def layernorm_backward_stats_kernel(g_ptr, x_ptr, w_ptr, dx_ptr, st_ptr,
                                    C, eps, HAS_W: tl.constexpr,
                                    CALC_F32: tl.constexpr,
                                    OUT_DT: tl.constexpr,
                                    BLOCK: tl.constexpr):
    """layernorm_backward_kernel minus the xhat store: the per-row
    (mean, rstd) f32 pair goes to st[row] instead, and the fused weight
    grad column reduce (reduce_col2_stats_kernel) recomputes
    xhat = (x-mean)*rstd on the fly — the same f32 ops on the same
    values, so dx/dgamma/dbeta stay bit-identical while the (R, C) xhat
    tensor and the g*xhat product tensor are never materialized."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    g = tl.load(g_ptr + row * C + offs, mask=m, other=0.0)
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    if CALC_F32:
        g = tl.cast(g, tl.float32)
        x = tl.cast(x, tl.float32)
    inv_c = 1.0 / C
    mean = tl.sum(x) * inv_c
    d = tl.where(m, x - mean, 0.0)  # masked lanes must not pollute var
    var = tl.sum(d * d) * inv_c
    rstd = 1.0 / tl.sqrt(var + eps)
    xh = d * rstd
    u = g
    if HAS_W:
        w = tl.load(w_ptr + offs, mask=m, other=0.0)
        u = g * w
    u_mean = tl.sum(u) * inv_c
    uxh_mean = tl.sum(u * xh) * inv_c
    dx = rstd * (u - u_mean - xh * uxh_mean)
    tl.store(dx_ptr + row * C + offs, tl.cast(dx, OUT_DT), mask=m)
    tl.store(st_ptr + row * 2, mean)
    tl.store(st_ptr + row * 2 + 1, rstd)


def launch_layernorm_backward_stats(g, x, w, dx, st, C: int, eps: float):
    R = g.numel() // C if C else 0
    if R == 0:
        return
    # st is (R, 2): the max(C, 2) row width covers its offsets too.
    budget = _i32_row_budget(max(C, 2),
                             min(g.dtype.itemsize, x.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        # Not plan-cacheable (see launch_layernorm).
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_layernorm_backward_stats(g[r0:r1], x[r0:r1], w,
                                            dx[r0:r1], st[r0:r1], C, eps)
        return None
    block = _row_block(C)
    calc_f32 = (g.dtype.is_float and g.dtype.itemsize < 4) or \
        (x.dtype.is_float and x.dtype.itemsize < 4)
    return layernorm_backward_stats_kernel[(R,)](
        g._buffer_arg(), x._buffer_arg(),
        (w if w is not None else g)._buffer_arg(), dx._buffer_arg(),
        st._buffer_arg(), C, eps,
        HAS_W=w is not None, CALC_F32=calc_f32, OUT_DT=dx.dtype,
        BLOCK=block, num_warps=4)


@tl.kernel
def reduce_col2_stats_kernel(g_ptr, x_ptr, st_ptr, pa_ptr, pb_ptr, R, C,
                             SLICE, BC: tl.constexpr, EVEN_C: tl.constexpr):
    """Fused LN weight/bias grad column sums over a row slice:
    pa[rid, c] = sum g[r, c], pb[rid, c] = sum g[r, c] * xhat[r, c] with
    xhat = (x - mean_r) * rstd_r recomputed from the per-row stats (f32
    accumulate, same 4-way pointer-bump walk as reduce_col_kernel).
    g/x loads are cast to f32 at load (a no-op for f32 inputs): sub-f32
    float inputs accumulate in f32 — the CALC_F32 discipline.
    EVEN_C (C % BC == 0) drops the column mask so the dist fragments
    take the 16B vector loads."""
    rid = tl.program_id(0)
    cid = tl.program_id(1)
    offs = cid * BC + tl.arange(0, BC)
    r0 = rid * SLICE
    r1 = tl.where(r0 + SLICE < R, r0 + SLICE, R)
    r4 = r1 - (r1 - (r0 + 1)) % 4
    if EVEN_C:
        mean = tl.load(st_ptr + r0 * 2)
        rstd = tl.load(st_ptr + r0 * 2 + 1)
        g0 = tl.cast(tl.load(g_ptr + r0 * C + offs), tl.float32)
        x0 = tl.cast(tl.load(x_ptr + r0 * C + offs), tl.float32)
        a0 = g0
        b0 = g0 * ((x0 - mean) * rstd)
        a1 = a0 * 0.0
        a2 = a0 * 0.0
        a3 = a0 * 0.0
        b1 = a0 * 0.0
        b2 = a0 * 0.0
        b3 = a0 * 0.0
        bg = g_ptr + (r0 + 1) * C + offs
        bx = x_ptr + (r0 + 1) * C + offs
        bs = st_ptr + (r0 + 1) * 2
        for r in range(r0 + 1, r4, 4):
            g0 = tl.cast(tl.load(bg), tl.float32)
            g1 = tl.cast(tl.load(bg + C), tl.float32)
            g2 = tl.cast(tl.load(bg + 2 * C), tl.float32)
            g3 = tl.cast(tl.load(bg + 3 * C), tl.float32)
            x0 = tl.cast(tl.load(bx), tl.float32)
            x1 = tl.cast(tl.load(bx + C), tl.float32)
            x2 = tl.cast(tl.load(bx + 2 * C), tl.float32)
            x3 = tl.cast(tl.load(bx + 3 * C), tl.float32)
            a0 = a0 + g0
            a1 = a1 + g1
            a2 = a2 + g2
            a3 = a3 + g3
            b0 = b0 + g0 * ((x0 - tl.load(bs)) * tl.load(bs + 1))
            b1 = b1 + g1 * ((x1 - tl.load(bs + 2)) * tl.load(bs + 3))
            b2 = b2 + g2 * ((x2 - tl.load(bs + 4)) * tl.load(bs + 5))
            b3 = b3 + g3 * ((x3 - tl.load(bs + 6)) * tl.load(bs + 7))
            bg = bg + 4 * C
            bx = bx + 4 * C
            bs = bs + 8
        bg = g_ptr + r4 * C + offs
        bx = x_ptr + r4 * C + offs
        bs = st_ptr + r4 * 2
        for r in range(r4, r1):
            g0 = tl.cast(tl.load(bg), tl.float32)
            x0 = tl.cast(tl.load(bx), tl.float32)
            a0 = a0 + g0
            b0 = b0 + g0 * ((x0 - tl.load(bs)) * tl.load(bs + 1))
            bg = bg + C
            bx = bx + C
            bs = bs + 2
        a0 = (a0 + a1) + (a2 + a3)
        b0 = (b0 + b1) + (b2 + b3)
        tl.store(pa_ptr + rid * C + offs, a0)
        tl.store(pb_ptr + rid * C + offs, b0)
    else:
        m = offs < C
        mean = tl.load(st_ptr + r0 * 2)
        rstd = tl.load(st_ptr + r0 * 2 + 1)
        g0 = tl.cast(tl.load(g_ptr + r0 * C + offs, mask=m, other=0.0),
                     tl.float32)
        x0 = tl.cast(tl.load(x_ptr + r0 * C + offs, mask=m, other=0.0),
                     tl.float32)
        a0 = g0
        b0 = g0 * ((x0 - mean) * rstd)
        a1 = a0 * 0.0
        a2 = a0 * 0.0
        a3 = a0 * 0.0
        b1 = a0 * 0.0
        b2 = a0 * 0.0
        b3 = a0 * 0.0
        bg = g_ptr + (r0 + 1) * C + offs
        bx = x_ptr + (r0 + 1) * C + offs
        bs = st_ptr + (r0 + 1) * 2
        for r in range(r0 + 1, r4, 4):
            g0 = tl.cast(tl.load(bg, mask=m, other=0.0), tl.float32)
            g1 = tl.cast(tl.load(bg + C, mask=m, other=0.0), tl.float32)
            g2 = tl.cast(tl.load(bg + 2 * C, mask=m, other=0.0), tl.float32)
            g3 = tl.cast(tl.load(bg + 3 * C, mask=m, other=0.0), tl.float32)
            x0 = tl.cast(tl.load(bx, mask=m, other=0.0), tl.float32)
            x1 = tl.cast(tl.load(bx + C, mask=m, other=0.0), tl.float32)
            x2 = tl.cast(tl.load(bx + 2 * C, mask=m, other=0.0), tl.float32)
            x3 = tl.cast(tl.load(bx + 3 * C, mask=m, other=0.0), tl.float32)
            a0 = a0 + g0
            a1 = a1 + g1
            a2 = a2 + g2
            a3 = a3 + g3
            b0 = b0 + g0 * ((x0 - tl.load(bs)) * tl.load(bs + 1))
            b1 = b1 + g1 * ((x1 - tl.load(bs + 2)) * tl.load(bs + 3))
            b2 = b2 + g2 * ((x2 - tl.load(bs + 4)) * tl.load(bs + 5))
            b3 = b3 + g3 * ((x3 - tl.load(bs + 6)) * tl.load(bs + 7))
            bg = bg + 4 * C
            bx = bx + 4 * C
            bs = bs + 8
        bg = g_ptr + r4 * C + offs
        bx = x_ptr + r4 * C + offs
        bs = st_ptr + r4 * 2
        for r in range(r4, r1):
            g0 = tl.cast(tl.load(bg, mask=m, other=0.0), tl.float32)
            x0 = tl.cast(tl.load(bx, mask=m, other=0.0), tl.float32)
            a0 = a0 + g0
            b0 = b0 + g0 * ((x0 - tl.load(bs)) * tl.load(bs + 1))
            bg = bg + C
            bx = bx + C
            bs = bs + 2
        a0 = (a0 + a1) + (a2 + a3)
        b0 = (b0 + b1) + (b2 + b3)
        tl.store(pa_ptr + rid * C + offs, a0, mask=m)
        tl.store(pb_ptr + rid * C + offs, b0, mask=m)


@tl.kernel
def splitk_reduce2_kernel(pa_ptr, pb_ptr, oa_ptr, ob_ptr, C,
                          S: tl.constexpr, BLOCK: tl.constexpr):
    """Dual of splitk_reduce_kernel: fold the (S, C) partial planes of a
    fused two-output column reduce in one pass."""
    offs = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    m = offs < C
    a = tl.load(pa_ptr + offs, mask=m, other=0.0)
    b = tl.load(pb_ptr + offs, mask=m, other=0.0)
    for s in range(1, S):
        a = a + tl.load(pa_ptr + s * C + offs, mask=m, other=0.0)
        b = b + tl.load(pb_ptr + s * C + offs, mask=m, other=0.0)
    tl.store(oa_ptr + offs, a, mask=m)
    tl.store(ob_ptr + offs, b, mask=m)


def launch_reduce_col2_stats(g, x, st, pa, pb, R: int, C: int,
                             target_rows: int = 96):
    """Two deterministic passes (partials + dual fold) for the fused LN
    weight/bias grads; f32 (R, C) inputs."""
    BC, nw, even, ncol, rch, slice_rows = col_sum_geometry(
        R, C, 4, target_rows)
    fl1 = reduce_col2_stats_kernel[(rch, ncol)](
        g._buffer_arg(), x._buffer_arg(), st._buffer_arg(),
        pa._buffer_arg(), pb._buffer_arg(), R, C, slice_rows,
        BC=BC, EVEN_C=even, num_warps=nw)
    return fl1, slice_rows, rch, BC, nw, even


def launch_splitk_reduce2(pa, pb, oa, ob, C: int, split_k: int):
    BLOCK = 128
    return splitk_reduce2_kernel[((C + BLOCK - 1) // BLOCK,)](
        pa._buffer_arg(), pb._buffer_arg(), oa._buffer_arg(),
        ob._buffer_arg(), C, S=split_k, BLOCK=BLOCK, num_warps=4)


def launch_rmsnorm_backward(g, x, w, dx, xr, C: int, eps: float):
    R = g.numel() // C if C else 0
    if R == 0:
        return
    budget = _i32_row_budget(C, min(g.dtype.itemsize, x.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_rmsnorm_backward(g[r0:r1], x[r0:r1], w, dx[r0:r1],
                                    xr[r0:r1], C, eps)
        return
    block = _row_block(C)
    calc_f32 = (g.dtype.is_float and g.dtype.itemsize < 4) or \
        (x.dtype.is_float and x.dtype.itemsize < 4)
    rmsnorm_backward_kernel[(R,)](
        g._buffer_arg(), x._buffer_arg(),
        (w if w is not None else g)._buffer_arg(), dx._buffer_arg(),
        xr._buffer_arg(), C, eps,
        HAS_W=w is not None, CALC_F32=calc_f32,
        OUT_DT=dx.dtype, BLOCK=block,
        num_warps=4)




__all__ = [
    "softmax_row_kernel",
    "launch_softmax",
    "layernorm_kernel",
    "rmsnorm_kernel",
    "launch_layernorm",
    "launch_rmsnorm",
    "add_layernorm_kernel",
    "launch_add_layernorm",
    "softmax_backward_row_kernel",
    "launch_softmax_backward",
    "layernorm_backward_kernel",
    "rmsnorm_backward_kernel",
    "launch_layernorm_backward",
    "layernorm_backward_stats_kernel",
    "launch_layernorm_backward_stats",
    "reduce_col2_stats_kernel",
    "splitk_reduce2_kernel",
    "_col_vec_bc",
    "col_sum_geometry",
    "launch_reduce_col2_stats",
    "launch_splitk_reduce2",
    "launch_rmsnorm_backward",
    "launch_layernorm_backward_fused",
    "launch_layernorm_backward_dx",
]


def launch_layernorm_backward_fused(g2d, x2d, w, dx, dbeta, dgamma,
                                    R: int, C: int, eps: float):
    """Composed fused LN backward (three stages): the per-row stats dx
    kernel + the (g, g*xhat) column partials + the 2-out fold. Allocates
    the (st, pa, pb) workspaces on the cold path and returns
    (fl1, fl2, fl3, st, pa, pb, tail) for the caller's plan cache —
    fl2/fl3 may be None on the slow path (the stages always run once
    fl1 resolved; plan caching is the caller's conditional). pa holds
    the g sums (dbeta), pb the g*xhat sums (dgamma)."""
    from ....frontend import types as tl_types
    from ....tensor import empty
    budget = _i32_row_budget(max(C, 2),
                             min(g2d.dtype.itemsize, x2d.dtype.itemsize))
    if R > budget:
        # i32 addressing: run the stats/dx row kernel and the column
        # partials per row chunk (each chunk's element offsets stay below
        # 2**31), stack the per-chunk partial planes, and fold once over
        # the stack. Not plan-cacheable (a host launch loop): the None
        # handles make the eager layer skip its plan cache for this call.
        st = empty((R, 2), tl_types.float32, "cuda")
        chunks = [(r0, min(r0 + budget, R)) for r0 in range(0, R, budget)]
        rchs = [col_sum_geometry(r1 - r0, C, 4)[4] for r0, r1 in chunks]
        pa = empty((sum(rchs), C), tl_types.float32, "cuda")
        pb = empty((sum(rchs), C), tl_types.float32, "cuda")
        off = 0
        for (r0, r1), rch in zip(chunks, rchs):
            launch_layernorm_backward_stats(g2d[r0:r1], x2d[r0:r1], w,
                                            dx[r0:r1], st[r0:r1], C, eps)
            launch_reduce_col2_stats(g2d[r0:r1], x2d[r0:r1], st[r0:r1],
                                     pa[off:off + rch], pb[off:off + rch],
                                     r1 - r0, C)
            off += rch
        launch_splitk_reduce2(pa, pb, dbeta, dgamma, C, off)
        return None, None, None, st, pa, pb, None
    st = empty((R, 2), tl_types.float32, "cuda")
    fl1 = launch_layernorm_backward_stats(g2d, x2d, w, dx, st, C, eps)
    if fl1 is None:
        return fl1, None, None, st, None, None, None
    _, _, _, _, rch, _ = col_sum_geometry(R, C, 4)
    pa = empty((rch, C), tl_types.float32, "cuda")
    pb = empty((rch, C), tl_types.float32, "cuda")
    ret2 = launch_reduce_col2_stats(g2d, x2d, st, pa, pb, R, C)
    fl2, slice_rows = (ret2[0], ret2[1]) if ret2 is not None \
        else (None, None)
    fl3 = launch_splitk_reduce2(pa, pb, dbeta, dgamma, C, rch)
    return fl1, fl2, fl3, st, pa, pb, (R, C, slice_rows)


def launch_layernorm_backward_dx(g2d, x2d, w, dx, R: int, C: int,
                                 eps: float):
    """dx-only fused LN backward: the stats row kernel alone + its
    (R, 2) stats workspace; returns (fl, st) for the caller's plan
    cache."""
    from ....frontend import types as tl_types
    from ....tensor import empty
    st = empty((R, 2), tl_types.float32, "cuda")
    fl = launch_layernorm_backward_stats(g2d, x2d, w, dx, st, C, eps)
    return fl, st
