"""Compile cache: in-memory dict + disk cubin store (~/.minitriton/cache/).

Key = (kernel source hash, argument signature, constexpr values, num_warps,
target arch, cache-format version). Disk layout mirrors triton:

    ~/.minitriton/cache/<key>/kernel.cubin
    ~/.minitriton/cache/<key>/meta.json
"""

from __future__ import annotations

import hashlib
import json
import os
from functools import lru_cache
from pathlib import Path

from ..precision import fingerprint as _prec_fingerprint

# Bump when the codegen/lowering changes in a way that invalidates cubins.
CACHE_VERSION = "phase1.v1"

# Frozen at import: precision levers are documented "read once at import
# time", and builder.py snapshots the same import-time values for codegen.
# Freezing the fingerprint component here too keeps every disk/mem key
# aligned with what codegen can actually emit — a runtime poke of a
# precision.* global can no longer put a flipped-codegen cubin under an
# unflipped key (stale reuse / disk-cache pollution).
_PREC_FINGERPRINT = _prec_fingerprint()


@lru_cache(maxsize=1)
def codegen_fingerprint() -> str:
    """Hash of the compiler's own sources, so stale cubins never survive an
    edit to the builder/frontend/lowering (belt and braces for dev)."""
    h = hashlib.sha256()
    base = Path(__file__).resolve().parents[1]
    for rel in ("compiler/builder.py", "compiler/layout.py",
                "compiler/lowering.py",
                "compiler/wir.py", "compiler/passes.py",
                "frontend/code_generator.py", "frontend/semantics.py",
                "frontend/types.py"):
        h.update((base / rel).read_bytes())
    # pass configuration also changes codegen output
    h.update(os.environ.get("MINITRITON_WIR_PASSES", "1").encode())
    h.update(os.environ.get("MINITRITON_OPT_PASSES", "").encode())
    # W-IR smem annotation rewrites smem accesses AND switches path
    # selection (builder issue_vec_fast bypass) — same source, different
    # cubin, so the env must salt the key
    h.update(os.environ.get("MINITRITON_WIR_ANNOTATE", "0").encode())
    # opt-in precision modes change codegen (builder reduce/exp/sqrt) —
    # the import-time frozen string (module level), not a live re-read
    h.update(_PREC_FINGERPRINT.encode())
    return h.hexdigest()[:16]


def cache_root() -> Path:
    root = os.environ.get("MINITRITON_CACHE_DIR", "~/.minitriton/cache")
    return Path(root).expanduser()


def make_key(src: str, signature: tuple, constexprs: tuple, num_warps: int,
             chip: str, extra: tuple = ()) -> str:
    h = hashlib.sha256()
    h.update(CACHE_VERSION.encode())
    h.update(codegen_fingerprint().encode())
    h.update(src.encode())
    h.update(repr(signature).encode())
    h.update(repr(constexprs).encode())
    if extra:
        # captured-global values / @tl.inline helper sources (they bake
        # into the MLIR but not into `src`); conditional so dep-free
        # kernels keep their existing disk entries
        h.update(repr(extra).encode())
    h.update(f"|warps={num_warps}|arch={chip}".encode())
    return h.hexdigest()


class CompileCache:
    """Two-level cache: process memory, then disk."""

    def __init__(self, root: Path | None = None):
        self.root = root or cache_root()
        self._mem: dict[str, bytes] = {}

    def get(self, key: str) -> bytes | None:
        if key in self._mem:
            return self._mem[key]
        path = self.root / key / "kernel.cubin"
        if path.is_file():
            cubin = path.read_bytes()
            self._mem[key] = cubin
            return cubin
        return None

    def get_meta(self, key: str) -> dict | None:
        """The meta.json sidecar of a disk-cached cubin (None if absent)."""
        path = self.root / key / "meta.json"
        if path.is_file():
            try:
                return json.loads(path.read_text())
            except Exception:
                return None
        return None

    def put(self, key: str, cubin: bytes, meta: dict) -> None:
        self._mem[key] = cubin
        d = self.root / key
        d.mkdir(parents=True, exist_ok=True)
        # atomic writes (temp file + rename): concurrent processes compiling
        # the same kernel (distributed.launch children) never observe a
        # torn cubin
        for name, data in (("kernel.cubin", cubin),
                           ("meta.json", json.dumps(meta, indent=2,
                                                    default=repr).encode())):
            tmp = d / f".{name}.tmp.{os.getpid()}"
            tmp.write_bytes(data)
            os.replace(tmp, d / name)


_default_cache: CompileCache | None = None


def get_cache() -> CompileCache:
    global _default_cache
    if _default_cache is None:
        _default_cache = CompileCache()
    return _default_cache
