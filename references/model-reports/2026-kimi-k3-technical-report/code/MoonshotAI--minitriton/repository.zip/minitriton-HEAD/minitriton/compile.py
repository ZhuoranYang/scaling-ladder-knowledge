"""``@tl.compile``: trace an eager function on proxy tensors, fuse what the
fusion rule engine (``fusion.py``) claims, replay the rest through the
normal eager path. Graphs are keyed by (function, arg shapes/strides/
dtypes/devices, non-tensor values, allow_tf32) and cached; CPU tensors
always run eager; ``MT_COMPILE=0`` disables.
"""

from __future__ import annotations

import ast
import dis
import inspect
import os
import textwrap

import numpy as np

from .frontend import types as tl_types
from .frontend.code_generator import Kernel
from .tensor import Tensor, empty

f32 = tl_types.float32

# ---------------------------------------------------------------------------
# tracing proxy + graph
# ---------------------------------------------------------------------------


class _Node:
    __slots__ = ("kind", "fn", "args", "meta", "shape", "dtype")

    def __init__(self, kind, fn, args, meta=None, shape=None, dtype=None):
        self.kind = kind      # 'input' | 'be' | 'method'
        self.fn = fn          # backend fn name or method name
        self.args = args      # tuple with _Proxy/_Node leaves, scalars, dtypes
        self.meta = meta or {}
        self.shape = shape
        self.dtype = dtype

    def __repr__(self):
        return f"<_Node {self.kind}:{self.fn} {self.shape} {self.dtype}>"


class _Proxy(Tensor):
    """A Tensor with no storage; every backend call records a node."""

    __slots__ = ("node", "_graph")

    def __init__(self, graph, node):
        self._storage = None
        self.shape = node.shape
        self.dtype = node.dtype
        self.device = "trace"
        self._st = ()
        self._offset = 0
        self.requires_grad = False
        self.grad = None
        self.grad_fn = None
        self.node = node
        self._graph = graph

    # -- metadata methods return new proxies recording a replay node ---------

    def _rec(self, method, out_shape, *args):
        node = _Node("method", method, (self.node,) + args,
                     shape=out_shape, dtype=self.dtype)
        self._graph.nodes.append(node)
        return _Proxy(self._graph, node)

    def reshape(self, *shape):
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        shape = list(shape)
        if -1 in shape:
            known = 1
            for s in shape:
                if s != -1:
                    known *= s
            shape[shape.index(-1)] = _numel(self.shape) // known
        return self._rec("reshape", tuple(int(s) for s in shape), tuple(shape))

    def view(self, *shape):
        return self.reshape(*shape)

    def permute(self, *dims):
        if len(dims) == 1 and isinstance(dims[0], (tuple, list)):
            dims = tuple(dims[0])
        dims = tuple(d % len(self.shape) for d in dims)
        return self._rec("permute", tuple(self.shape[d] for d in dims), dims)

    def transpose(self, d0, d1):
        dims = list(range(len(self.shape)))
        dims[d0 % len(dims)], dims[d1 % len(dims)] = \
            dims[d1 % len(dims)], dims[d0 % len(dims)]
        return self.permute(tuple(dims))

    def t(self):
        return self.transpose(0, 1)

    def unsqueeze(self, dim):
        dim = dim if dim >= 0 else dim + len(self.shape) + 1
        shape = self.shape[:dim] + (1,) + self.shape[dim:]
        return self._rec("unsqueeze", shape, dim)

    def squeeze(self, dim=None):
        if dim is None:
            shape = tuple(s for s in self.shape if s != 1)
        else:
            d = dim % len(self.shape)
            shape = self.shape if self.shape[d] != 1 else \
                self.shape[:d] + self.shape[d + 1:]
        return self._rec("squeeze", shape, dim)

    def broadcast_to(self, shape):
        return self._rec("broadcast_to", tuple(shape), tuple(shape))

    def expand(self, *shape):
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        shape = tuple(self.shape[i] if s == -1 else int(s)
                      for i, s in enumerate(shape))
        return self.broadcast_to(shape)

    def contiguous(self):
        return self._rec("contiguous", self.shape)

    def astype(self, dtype):
        node = _Node("method", "astype", (self.node, dtype),
                     shape=self.shape, dtype=dtype)
        self._graph.nodes.append(node)
        return _Proxy(self._graph, node)

    def __getitem__(self, idx):
        raise RuntimeError(
            "@tl.compile: __getitem__ inside a compiled function is not "
            "traced; do slicing outside or use whole-tensor ops")

    # data-dependent escapes are meaningless on proxies
    def numpy(self):
        raise RuntimeError(".numpy() inside @tl.compile is not allowed")

    def item(self):
        raise RuntimeError(".item() inside @tl.compile is not allowed")

    def to(self, device=None, dtype=None):
        if dtype is not None and dtype != self.dtype:
            return self.astype(dtype)
        return self


def _numel(shape):
    n = 1
    for s in shape:
        n *= s
    return n


class _Graph:
    def __init__(self):
        self.nodes = []
        self.inputs = []


# ---------------------------------------------------------------------------
# tracing backend (same interface as device.cuda; records instead of runs)
# ---------------------------------------------------------------------------

def _node(graph, fn, args, shape, dtype):
    n = _Node("be", fn, args, shape=shape, dtype=dtype)
    graph.nodes.append(n)
    return _Proxy(graph, n)


class _TraceBackend:
    """Records the backend-interface calls made by ops.py."""

    def __init__(self, graph):
        self.g = graph

    # elementwise
    def unary(self, op, a, out_dtype):
        return _node(self.g, "unary", (op, a.node, out_dtype),
                     a.shape, out_dtype)

    def binary(self, op, a, b, out_dtype):
        shape = tuple(np.broadcast_shapes(a.shape, b.shape))
        return _node(self.g, "binary", (op, a.node, b.node, out_dtype),
                     shape, out_dtype)

    def binary_scalar(self, op, a, s, side, out_dtype):
        return _node(self.g, "binary_scalar", (op, a.node, s, side, out_dtype),
                     a.shape, out_dtype)

    # fused elementwise forward ops (case-fusions)
    def swiglu(self, a, b, out_dtype):
        shape = tuple(np.broadcast_shapes(a.shape, b.shape))
        return _node(self.g, "swiglu", (a.node, b.node, out_dtype),
                     shape, out_dtype)

    # movement
    def contiguous(self, a):
        return _node(self.g, "contiguous", (a.node,), a.shape, a.dtype)

    def astype(self, a, dtype):
        return _node(self.g, "astype", (a.node, dtype), a.shape, dtype)

    def cat(self, tensors, dim, out_dtype):
        shape = list(tensors[0].shape)
        shape[dim] = sum(t.shape[dim] for t in tensors)
        return _node(self.g, "cat", (tuple(t.node for t in tensors), dim,
                                     out_dtype), tuple(shape), out_dtype)

    # matmul
    def matmul(self, a, b):
        shape = (a.shape[0], b.shape[1])
        return _node(self.g, "matmul", (a.node, b.node), shape, f32)

    def matmul_bf16(self, a, b, out_dtype=None, bias=None):
        """bf16 tensor-core mma route, traced as its own node kind (the
        R2' fusion rule's match target). Mirrors the backend's ndim
        handling so batched/1D calls trace the same reshapes."""
        dt = out_dtype or tl_types.bfloat16
        if a.ndim == 1 and b.ndim == 1:
            out = self.matmul_bf16(a.reshape((1, a.shape[0])),
                                   b.reshape((b.shape[0], 1)),
                                   out_dtype=out_dtype, bias=bias)
            return out.reshape(())
        if a.ndim == 1:
            out = self.matmul_bf16(a.reshape((1, a.shape[0])), b,
                                   out_dtype=out_dtype, bias=bias)
            return out.reshape(out.shape[1:])
        if b.ndim == 1:
            out = self.matmul_bf16(a, b.reshape((b.shape[0], 1)),
                                   out_dtype=out_dtype, bias=bias)
            return out.reshape(out.shape[:-1])
        if a.ndim == 2 and b.ndim == 2:
            # mirror _mm_bf16_2d's bias contract at trace time: a
            # wrong-shaped bias must fail loudly here, not silently
            # degrade to a reshape error at exec time
            if bias is not None and (bias.ndim != 1
                                     or bias.shape[0] != b.shape[1]):
                raise RuntimeError(
                    f"matmul_bf16 bias must be ({b.shape[1]},), got "
                    f"{bias.shape}")
            shape = (a.shape[0], b.shape[1])
            return _node(self.g, "matmul_bf16",
                         (a.node, b.node, out_dtype,
                          bias.node if bias is not None else None),
                         shape, dt)
        if b.ndim == 2:
            k = a.shape[-1]
            a2 = a.reshape((a.numel() // k, k))
            out = self.matmul_bf16(a2, b, out_dtype=out_dtype, bias=bias)
            return out.reshape(a.shape[:-1] + (b.shape[1],))
        batch = tuple(np.broadcast_shapes(a.shape[:-2], b.shape[:-2]))
        if bias is not None:
            raise NotImplementedError(
                "batched matmul_bf16 with bias is not supported "
                "(bmm_bf16 has no bias epilogue)")
        av = a.broadcast_to(batch + a.shape[-2:]) \
            if a.shape[:-2] != batch else a
        bv = b.broadcast_to(batch + b.shape[-2:]) \
            if b.shape[:-2] != batch else b
        if len(batch) > 1:
            B = 1
            for s in batch:
                B *= s
            av = av.contiguous().reshape((B,) + av.shape[-2:])
            bv = bv.contiguous().reshape((B,) + bv.shape[-2:])
        out = self.bmm_bf16(av, bv, out_dtype=out_dtype)
        return out.reshape(batch + out.shape[-2:])

    def bmm_bf16(self, a, b, out_dtype=None):
        dt = out_dtype or tl_types.bfloat16
        shape = (a.shape[0], a.shape[1], b.shape[2])
        return _node(self.g, "bmm_bf16", (a.node, b.node, out_dtype),
                     shape, dt)

    def bmm(self, a, b):
        shape = (a.shape[0], a.shape[1], b.shape[2])
        return _node(self.g, "bmm", (a.node, b.node), shape, f32)

    # reductions / nn row primitives
    def reduce_row(self, op, x2d, out_dtype):
        return _node(self.g, "reduce_row", (op, x2d.node, out_dtype),
                     (x2d.shape[0],), out_dtype)

    def reduce_full(self, op, x, out_dtype):
        return _node(self.g, "reduce_full", (op, x.node, out_dtype),
                     (), out_dtype)

    def argmax_rows(self, x2d):
        return _node(self.g, "argmax_rows", (x2d.node,),
                     (x2d.shape[0],), tl_types.int64)

    def softmax_rows(self, x2d, log):
        return _node(self.g, "softmax_rows", (x2d.node, log),
                     x2d.shape, x2d.dtype)

    def layer_norm_rows(self, x2d, w, b, eps):
        return _node(self.g, "layer_norm_rows",
                     (x2d.node, w.node if w is not None else None,
                      b.node if b is not None else None, eps),
                     x2d.shape, x2d.dtype)

    def rms_norm_rows(self, x2d, w, eps):
        return _node(self.g, "rms_norm_rows",
                     (x2d.node, w.node if w is not None else None, eps),
                     x2d.shape, x2d.dtype)

    def add_layernorm_rows(self, x2d, res2d, w, b, eps, need_sum=False):
        """The backend returns (out, s|None); downstream ops consume
        plain single-tensor nodes, so trace the raw call plus one
        ``_tuple_item`` pick per returned tensor."""
        n = _Node("be", "add_layernorm_rows",
                  (x2d.node, res2d.node,
                   w.node if w is not None else None,
                   b.node if b is not None else None, eps, need_sum),
                  shape=x2d.shape, dtype=x2d.dtype)
        self.g.nodes.append(n)
        y = _node(self.g, "_tuple_item", (n, 0), x2d.shape, x2d.dtype)
        if not need_sum:
            return y, None
        return y, _node(self.g, "_tuple_item", (n, 1), x2d.shape,
                        x2d.dtype)

    def embedding_rows(self, w2d, idx1d):
        return _node(self.g, "embedding_rows", (w2d.node, idx1d.node),
                     (idx1d.shape[0], w2d.shape[1]), w2d.dtype)

    def cross_entropy_rows(self, x2d, t1d):
        return _node(self.g, "cross_entropy_rows", (x2d.node, t1d.node),
                     (x2d.shape[0],), x2d.dtype)


# ---------------------------------------------------------------------------
# fusion planning — delegated to the rule engine (fusion.py)
# ---------------------------------------------------------------------------

def _resolve(v, env):
    return env[v] if isinstance(v, _Node) else v


def _plan(g: _Graph, out: _Node):
    """-> (fused_groups: dict root _Node -> group spec)."""
    from . import fusion as _fusion
    return _fusion.plan(g, out)


# ---------------------------------------------------------------------------
# fused kernel codegen (reuses the DSL pipeline via source generation)
# ---------------------------------------------------------------------------

from .device.cuda.elementwise import _source_kernel  # noqa: E402
from .device.cuda import kernels as _kk  # noqa: E402

_FUSED_CACHE: dict = {}


def _fused_name(prefix: str, key) -> str:
    """Deterministic fused-kernel name: ``hash()`` is process-randomized
    (PYTHONHASHSEED), which made disk-cached cubins / autotune picks miss
    across processes."""
    import hashlib
    digest = int.from_bytes(
        hashlib.sha256(repr(key).encode()).digest()[:4], "big") % 10**8
    return f"{prefix}_{digest}"


def _ew_kernel(expr: str, n_inputs: int, scalars: list,
               leaf_casts: list) -> Kernel:
    key = ("fused_ew", expr, n_inputs, tuple(scalars), tuple(leaf_casts))
    k = _FUSED_CACHE.get(key)
    if k is not None:
        return k
    name = _fused_name("fused_ew", key)
    ptrs = [f"x{i}_ptr" for i in range(n_inputs)]
    sargs = [f"s{i}" for i in range(len(scalars))]
    loads = []
    for i in range(n_inputs):
        loads.append(f"x{i} = tl.load(x{i}_ptr + offs, mask=m)")
        if leaf_casts[i]:
            # R3 absorbed cast: house load-cast idiom (raw dtype -> f32)
            loads.append(f"x{i} = tl.cast(x{i}, tl.float32)")
    params = ptrs + ["out_ptr"] + sargs + ["N", "BLOCK"]
    body = "\n".join(f"    {l}" for l in loads)
    k = _source_kernel(name, f"""
@tl.kernel
def {name}({", ".join(params[:-1])}, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
{body}
    tl.store(out_ptr + offs, {expr}, mask=m)
""", params, frozenset({"BLOCK"}))
    _FUSED_CACHE[key] = k
    return k


def _mm_epi_kernel(expr: str) -> Kernel:
    key = ("fused_mm", expr)
    k = _FUSED_CACHE.get(key)
    if k is not None:
        return k
    name = _fused_name("fused_mm", key)
    k = _source_kernel(name, f"""
@tl.kernel
def {name}(a_ptr, b_ptr, bias_ptr, c_ptr, M, N, K, sam, sbk,
           BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
           EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
           EVEN_MN: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    acc = tl.zeros((BM, BN), tl.float32)
    a_ptrs = a_ptr + offs_m[:, None] * sam + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * sbk + offs_n[None, :]
    for k in range(0, K, BK):
        if EVEN_MK:
            a = tl.load(a_ptrs)
        else:
            a = tl.load(a_ptrs, mask=(offs_m[:, None] < M)
                        & ((offs_k + k)[None, :] < K), other=0.0)
        if EVEN_KN:
            b = tl.load(b_ptrs)
        else:
            b = tl.load(b_ptrs, mask=((offs_k + k)[:, None] < K)
                        & (offs_n[None, :] < N), other=0.0)
        acc = tl.dot(a, b, acc)
        a_ptrs += BK
        b_ptrs += BK * sbk
    bias = tl.load(bias_ptr + offs_n, mask=offs_n < N, other=0.0)
    v = acc + bias[None, :]
    v = {expr}
    if EVEN_MN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], v)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], v, mask=cm)
""", ["a_ptr", "b_ptr", "bias_ptr", "c_ptr", "M", "N", "K", "sam", "sbk",
      "BM", "BN", "BK", "EVEN_MK", "EVEN_KN", "EVEN_MN"],
    frozenset({"BM", "BN", "BK", "EVEN_MK", "EVEN_KN", "EVEN_MN"}))
    _FUSED_CACHE[key] = k
    return k


def _mma_epi_kernel(expr: str) -> Kernel:
    """R2' fused mma matmul-epilogue kernel: matmul_mma_kernel's staging
    and autotune surface, the epilogue applied on the f32 C fragment,
    then store_m4 (bf16 packed / f32)."""
    key = ("fused_mma_epi", expr)
    k = _FUSED_CACHE.get(key)
    if k is not None:
        return k
    name = _fused_name("fused_mma_epi", key)
    params = ["a_ptr", "b_ptr", "c_ptr", "M", "N", "K", "sam", "sbk",
              "bias_ptr",
              "BM", "BN", "BK", "ATOM", "STAGES", "GROUP_M",
              "EVEN_MK", "EVEN_KN", "EVEN_MN", "EVEN_K",
              "TRANS_A", "TRANS_B", "TVEC_A", "TVEC_B", "ONE_BAR",
              "BIAS", "F2F", "DYN_SMEM", "ONE_SHOT", "EPI"]
    k = _source_kernel(name, f"""
@tl.kernel
def {name}(a_ptr, b_ptr, c_ptr, M, N, K, sam, sbk, bias_ptr,
           BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
           ATOM: tl.constexpr, STAGES: tl.constexpr,
           GROUP_M: tl.constexpr,
           EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
           EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr,
           TRANS_A: tl.constexpr, TRANS_B: tl.constexpr,
           TVEC_A: tl.constexpr, TVEC_B: tl.constexpr,
           ONE_BAR: tl.constexpr,
           BIAS: tl.constexpr = False,
           F2F: tl.constexpr = False,
           DYN_SMEM: tl.constexpr = False,
           ONE_SHOT: tl.constexpr = False,
           EPI: tl.constexpr = ""):
    pid = tl.program_id(0)
    num_pid_m = (M + BM - 1) // BM
    num_pid_n = (N + BN - 1) // BN
    num_in_group = GROUP_M * num_pid_n
    group_id = pid // num_in_group
    first_pid_m = group_id * GROUP_M
    group_size = tl.where(num_pid_m - first_pid_m < GROUP_M,
                          num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size)
    pid_n = (pid % num_in_group) // group_size
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    if TRANS_A:
        a_ptrs = a_ptr + offs_m[:, None] + offs_k[None, :] * sam
    else:
        a_ptrs = a_ptr + offs_m[:, None] * sam + offs_k[None, :]
    if TRANS_B:
        b_ptrs = b_ptr + offs_k[:, None] + offs_n[None, :] * sbk
    else:
        b_ptrs = b_ptr + offs_k[:, None] * sbk + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM=ATOM, STAGES=STAGES,
                          TRANS_A=TRANS_A, TRANS_B=TRANS_B,
                          TVEC_A=TVEC_A, TVEC_B=TVEC_B, ONE_BAR=ONE_BAR,
                          F2F=F2F, DYN_SMEM=DYN_SMEM, ONE_SHOT=ONE_SHOT)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM=ATOM, STAGES=STAGES,
                          EVEN_K=EVEN_K, VEC=False,
                          a_mask=am, b_mask=bn,
                          TRANS_A=TRANS_A, TRANS_B=TRANS_B, ONE_BAR=ONE_BAR,
                          DYN_SMEM=DYN_SMEM, ONE_SHOT=ONE_SHOT)
    if BIAS:
        bias = tl.load(bias_ptr + offs_n, mask=offs_n < N, other=0.0)
        v = acc + bias[None, :]
    else:
        v = acc
    v = {expr}
    if EVEN_MN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], v, EPI=EPI)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], v, mask=cm,
                 EPI=EPI)
""", params, frozenset(params[9:]))
    _FUSED_CACHE[key] = k
    return k


def _mm_v2_epi_kernel(expr: str) -> Kernel:
    """Accumulator epilogue for the fp32 store_t2 path: a matmul_v2_kernel
    clone with an arbitrary elementwise ``expr`` (from the r2v fusion
    rule) applied to the f32 accumulator before the store."""
    key = ("fused_mm_v2_epi", expr)
    k = _FUSED_CACHE.get(key)
    if k is not None:
        return k
    name = _fused_name("fused_mm_v2_epi", key)
    params = ["a_ptr", "b_ptr", "c_ptr", "M", "N", "K", "sam", "sbk",
              "bias_ptr",
              "BM", "BN", "BK", "TM", "TN", "STAGES", "GROUP_M",
              "EVEN_MK", "EVEN_KN", "EVEN_MN", "EVEN_K",
              "TRANS_A", "TRANS_B", "BIAS", "ONE_BAR"]
    k = _source_kernel(name, f"""
@tl.kernel
def {name}(a_ptr, b_ptr, c_ptr, M, N, K, sam, sbk, bias_ptr,
           BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
           TM: tl.constexpr, TN: tl.constexpr,
           STAGES: tl.constexpr, GROUP_M: tl.constexpr,
           EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
           EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr,
           TRANS_A: tl.constexpr, TRANS_B: tl.constexpr,
           BIAS: tl.constexpr = False,
           ONE_BAR: tl.constexpr = False):
    pid = tl.program_id(0)
    num_pid_m = (M + BM - 1) // BM
    num_pid_n = (N + BN - 1) // BN
    num_in_group = GROUP_M * num_pid_n
    group_id = pid // num_in_group
    first_pid_m = group_id * GROUP_M
    group_size = tl.where(num_pid_m - first_pid_m < GROUP_M,
                          num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size)
    pid_n = (pid % num_in_group) // group_size
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    if TRANS_A:
        a_ptrs = a_ptr + offs_m[:, None] + offs_k[None, :] * sam
    else:
        a_ptrs = a_ptr + offs_m[:, None] * sam + offs_k[None, :]
    if TRANS_B:
        b_ptrs = b_ptr + offs_k[:, None] + offs_n[None, :] * sbk
    else:
        b_ptrs = b_ptr + offs_k[:, None] * sbk + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                             TRANS_A=TRANS_A, TRANS_B=TRANS_B,
                             ONE_BAR=ONE_BAR)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                             EVEN_K=EVEN_K, VEC=False,
                             a_mask=am, b_mask=bn,
                             TRANS_A=TRANS_A, TRANS_B=TRANS_B,
                             ONE_BAR=ONE_BAR)
    # the epilogue expr applies to the bare accumulator (same-layout
    # elementwise on the t2 value); the bias, when present, rides the
    # store_t2 bias_pt per-fragment add (the production matmul_v2 BIAS
    # form) — a bias value cannot broadcast onto the t2 accumulator in
    # the v1 DSL, so expr never sees it (r2v fuses a bias+unary chain
    # only up to the add; the unary replays eagerly)
    v = acc
    v = {expr}
    if BIAS:
        bpt = bias_ptr + pid_n * BN + tl.arange(0, BN)
        if EVEN_MN:
            tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], v,
                     bias=bpt)
        else:
            cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
            tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], v,
                     mask=cm, bias=bpt)
    elif EVEN_MN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], v)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], v, mask=cm)
""", params, frozenset(params[9:]))
    _FUSED_CACHE[key] = k
    return k


# ---------------------------------------------------------------------------
# executor
# ---------------------------------------------------------------------------

_EW_EXPR = {
    "add": "({a} + {b})", "sub": "({a} - {b})", "mul": "({a} * {b})",
    "div": "({a} / {b})",
}


class _Exec:
    def __init__(self, g: _Graph, out: _Node, fused: dict):
        self.g = g
        self.out = out
        self.fused = fused
        self.covered = set()
        for spec in fused.values():
            self.covered |= spec["members"]

    def _run_ew_group(self, root, spec, env):
        """Inline the whole group into one expr over leaf loads/scalars."""
        from .device.cuda.elementwise import _UNARY, _BINARY_BW, \
            _FUSED_BINARY, _pow_scalar_expr
        cast_members = spec.get("cast_members", ())
        leaves, scalars = [], []

        def build(n):
            if n.fn == "astype" and n in cast_members:
                # R3 absorbed cast: the leaf load applies it (load-cast)
                leaf = n.args[0]
                if leaf not in leaves:
                    leaves.append(leaf)
                return f"x{leaves.index(leaf)}"
            if n not in spec["members"]:
                if n not in leaves:
                    leaves.append(n)
                return f"x{leaves.index(n)}"
            if n.fn == "unary":
                op = n.args[0]
                template, kind = _UNARY[op]
                inner = build(n.args[1])
                return template.replace("{zero}", "0.0").format(x=f"({inner})")
            if n.fn == "binary":
                op = n.args[0]
                if op == "pow":
                    return f"tl.exp(({build(n.args[2])}) * tl.log({build(n.args[1])}))"
                if op in _EW_EXPR:
                    return _EW_EXPR[op].format(a=f"({build(n.args[1])})",
                                               b=f"({build(n.args[2])})")
                # R4: backward/fused binary exprs (gelu_bw & co)
                template, kind = (_BINARY_BW.get(op)
                                  or _FUSED_BINARY[op])
                return template.format(a=f"({build(n.args[1])})",
                                       b=f"({build(n.args[2])})")
            if n.fn == "binary_scalar":
                op, x_n, s, side = n.args[0], n.args[1], n.args[2], n.args[3]
                inner = build(x_n)
                if isinstance(s, (float, np.floating)):
                    si = len(scalars)
                    scalars.append(float(s))
                    sv = f"s{si}"
                    a, b = (inner, sv) if side == "r" else (sv, inner)
                    if op != "pow":
                        return _EW_EXPR[op].format(a=f"({a})", b=f"({b})")
                    if side == "r":
                        # integer-exponent specialization as on the eager
                        # path: exp(s*log(x)) is NaN on negative bases
                        template, _kind = _pow_scalar_expr(float(s), f32)
                        return template.format(a=f"({a})", b=f"({b})")
                    return f"tl.exp(({b}) * tl.log({a}))"
                # int scalar: bake as a literal
                lit = repr(int(s))
                if op == "pow":
                    if side == "r":
                        template, _kind = _pow_scalar_expr(int(s), f32)
                        return template.format(a=f"({inner})", b=lit)
                    return f"tl.exp(({inner}) * tl.log({lit}))"
                a, b = (inner, lit) if side == "r" else (lit, inner)
                return _EW_EXPR[op].format(a=f"({a})", b=f"({b})")
            raise RuntimeError(f"cannot fuse {n.fn}")

        expr = build(root)
        # the fused kernel loads every leaf flat: a non-contiguous leaf
        # view would read wrong elements — degrade to the eager replay
        # (correct, just unfused).
        if not all(env[l].is_contiguous() for l in leaves):
            return self._replay_group(root, spec, env)
        leaf_casts = [l.dtype != f32 for l in leaves]
        k = _ew_kernel(expr, len(leaves), scalars, leaf_casts)
        out = empty(root.shape, f32, "cuda")
        n = out.numel()
        if n == 0:
            return out  # grid would be (0,): cuLaunchKernel rejects it
        bufs = [env[l]._buffer_arg() for l in leaves] + [out._buffer_arg()]
        grid = ((n + 1023) // 1024,)
        k[grid](*bufs, *scalars, n, BLOCK=1024, num_warps=4)
        return out

    def _replay_group(self, root, spec, env):
        """Exec-time guard fallback: replay the group's nodes one by one
        through the normal eager path (correct, just unfused)."""
        from .device import cuda as real_be
        local = dict(env)
        for n in self.g.nodes:
            if n not in spec["members"]:
                continue
            if n.kind == "method":
                local[n] = getattr(local[n.args[0]], n.fn)(*n.args[1:])
            else:
                local[n] = getattr(real_be, n.fn)(
                    *[_resolve(a, local) for a in n.args])
        return local[root]

    def _run_mm_group(self, root, spec, env):
        mm = spec["mm"]
        a = env[mm.args[0]]
        b = env[mm.args[1]]
        a = a if a.dtype == f32 else a.astype(f32)
        b = b if b.dtype == f32 else b.astype(f32)
        if a.strides[-1] != 1:
            a = a.contiguous()
        if b.strides[-1] != 1:
            b = b.contiguous()
        M, K = a.shape
        N = b.shape[1]
        if M == 0 or N == 0:
            # empty result: the tile grid would have a 0 dimension and
            # cuLaunchKernel rejects it (eager matmul early-outs the same)
            return empty((M, N), f32, "cuda")
        if spec["bias"] is not None:
            bias = env[spec["bias"]]
            bias = bias.contiguous().reshape((N,))
        else:
            from .tensor import zeros
            bias = zeros((N,), f32, "cuda")
        out = empty((M, N), f32, "cuda")
        k = _mm_epi_kernel(spec["expr"])
        tuner = _kk._mm_tuner(k, M, N, K)
        grid = lambda args: ((args["M"] + args["BM"] - 1) // args["BM"],
                             (args["N"] + args["BN"] - 1) // args["BN"])
        args = (a._buffer_arg(), b._buffer_arg(), bias._buffer_arg(),
                out._buffer_arg(), M, N, K, a.strides[0], b.strides[0])
        tuner.launch(k, grid, args, None,
                     {"BM": 0, "BN": 0, "BK": 0, "EVEN_MK": False,
                      "EVEN_KN": False, "EVEN_MN": False})
        return out

    def _run_mma_group(self, root, spec, env):
        """R2' mma-route epilogue group; guards re-checked on the real
        tensors, ineligible graphs degrade to the eager replay (correct,
        just unfused)."""
        from .device import cuda as real_be
        from .device.cuda import ops as be_ops
        mm = spec["mm"]
        a, b = env[mm.args[0]], env[mm.args[1]]
        atom = spec["atom"]
        out_dtype = spec["out_dtype"]
        baked = mm.args[3] if atom == "bf16" else None
        M, Kd = a.shape
        N = b.shape[1]
        if M == 0 or N == 0:
            # empty result: the tile grid would have a 0 dimension and
            # cuLaunchKernel rejects it (eager matmul early-outs the same)
            return empty((M, N), out_dtype, "cuda")

        def degrade():
            local = dict(env)
            if atom == "bf16":
                local[mm] = be_ops.matmul_bf16(
                    a, b, out_dtype=out_dtype,
                    bias=env[baked] if baked is not None else None)
            else:
                local[mm] = real_be.matmul(a, b)
            for cn in spec["chain"]:
                local[cn] = getattr(real_be, cn.fn)(
                    *[_resolve(x, local) for x in cn.args])
            # bias baked into the mm node (bf16 tier) leaves an empty
            # epilogue chain: the group's root IS the matmul node
            return local[spec["chain"][-1] if spec["chain"] else mm]

        if atom == "tf32" and not be_ops.get_allow_tf32():
            return degrade()
        ta, tb = _kk._trans_kstride(a), _kk._trans_kstride(b)
        sam = ta if ta is not None else a.strides[0]
        sbk = tb if tb is not None else b.strides[0]
        if not _kk.mma_strides_ok(atom, sam, sbk, a.dtype, b.dtype):
            return degrade()
        # the fused kernel stages plain or pure-transpose operands only
        if a.strides[-1] != 1 and ta is None:
            return degrade()
        if b.strides[-1] != 1 and tb is None:
            return degrade()
        if atom == "bf16" and out_dtype == f32 \
                and Kd >= 4096 and Kd >= 4 * M:
            return degrade()  # belt & braces (match already rejects)
        bias = None
        if spec["bias"] is not None:
            bias = env[spec["bias"]].contiguous().reshape((N,))
        out = empty((M, N), out_dtype, "cuda")
        k = _mma_epi_kernel(spec["expr"])
        tuner = _kk._mm_mma_tuner(k, atom, M, N, Kd, sam, sbk,
                                  ta is not None, tb is not None,
                                  a.dtype, b.dtype)
        grid = lambda args: (((args["M"] + args["BM"] - 1) // args["BM"])
                             * ((args["N"] + args["BN"] - 1) // args["BN"]),)
        args = (a._buffer_arg(), b._buffer_arg(), out._buffer_arg(),
                M, N, Kd, sam, sbk,
                (bias if bias is not None else out)._buffer_arg())
        kw = dict(_kk._MMA_KW, BIAS=bias is not None, F2F=False)
        tuner.launch(k, grid, args, None, kw)
        return out

    def _run_mm_v2_group(self, root, spec, env):
        """r2v fp32 store_t2 epilogue group; guards re-checked on the real
        tensors, ineligible graphs degrade to the eager replay (correct,
        just unfused)."""
        from .device import cuda as real_be
        mm = spec["mm"]
        a, b = env[mm.args[0]], env[mm.args[1]]
        M, Kd = a.shape
        N = b.shape[1]
        if M == 0 or N == 0:
            # empty result: the tile grid would have a 0 dimension and
            # cuLaunchKernel rejects it (eager matmul early-outs the same)
            return empty((M, N), f32, "cuda")

        def degrade():
            local = dict(env)
            local[mm] = real_be.matmul(a, b)
            for cn in spec["chain"]:
                local[cn] = getattr(real_be, cn.fn)(
                    *[_resolve(x, local) for x in cn.args])
            return local[spec["chain"][-1]]

        ta, tb = _kk._trans_kstride(a), _kk._trans_kstride(b)
        sam = ta if ta is not None else a.strides[0]
        sbk = tb if tb is not None else b.strides[0]
        # the fused kernel stages plain or pure-transpose operands only
        if a.strides[-1] != 1 and ta is None:
            return degrade()
        if b.strides[-1] != 1 and tb is None:
            return degrade()
        if a.dtype != f32 or b.dtype != f32:
            return degrade()
        if Kd >= 4096 and Kd >= 4 * M:
            return degrade()  # split-K candidate: partials take no epi
        bias = None
        if spec["bias"] is not None:
            bias = env[spec["bias"]].contiguous().reshape((N,))
        out = empty((M, N), f32, "cuda")
        k = _mm_v2_epi_kernel(spec["expr"])
        tuner = _kk._mm_v2_tuner(k, M, N, Kd, sam, sbk,
                                 ta is not None, tb is not None)
        grid = lambda args: (((args["M"] + args["BM"] - 1) // args["BM"])
                             * ((args["N"] + args["BN"] - 1) // args["BN"]),)
        args = (a._buffer_arg(), b._buffer_arg(), out._buffer_arg(),
                M, N, Kd, sam, sbk,
                (bias if bias is not None else out)._buffer_arg())
        kw = dict(_kk._V2_KW, BIAS=bias is not None)
        tuner.launch(k, grid, args, None, kw)
        return out

    def run(self, real_inputs):
        from .device import cuda as real_be
        env = {}
        for n, t in zip(self.g.inputs, real_inputs):
            env[n] = t
        for n in self.g.nodes:
            if n.kind == "input":
                continue
            if n in self.covered:
                if n in self.fused:
                    spec = self.fused[n]
                    if spec["type"] == "ew_chain":
                        env[n] = self._run_ew_group(n, spec, env)
                    elif spec["type"] == "mm_epilogue":
                        env[n] = self._run_mm_group(n, spec, env)
                    elif spec["type"] == "mma_epilogue":
                        env[n] = self._run_mma_group(n, spec, env)
                    elif spec["type"] == "mm_v2_epilogue":
                        env[n] = self._run_mm_v2_group(n, spec, env)
                    else:  # "alias" (R8): bind to the source view, no copy
                        env[n] = env[spec["src"]]
                continue  # non-root members covered by their group's root
            if n.kind == "method":
                tgt = env[n.args[0]]
                env[n] = getattr(tgt, n.fn)(*n.args[1:])
            elif n.fn == "_tuple_item":
                # multi-output backend call's pick node (add_layernorm_rows)
                env[n] = env[n.args[0]][n.args[1]]
            else:
                env[n] = getattr(real_be, n.fn)(
                    *[_resolve(a, env) for a in n.args])
        return env[self.out]


# ---------------------------------------------------------------------------
# decorator
# ---------------------------------------------------------------------------

class _CompiledFn:
    def __init__(self, fn):
        self.fn = fn
        self._cache = {}
        self.__name__ = fn.__name__
        self.__doc__ = fn.__doc__
        self._closure_warned = False

    def _key(self, args, kwargs):
        parts = []
        for a in list(args) + [kwargs[k] for k in sorted(kwargs)]:
            if isinstance(a, Tensor):
                # strides: fused ew groups load leaves flat, so a
                # non-contiguous view must not share a contiguous graph
                parts.append(("T", a.shape, a.strides, a.dtype.name,
                              a.device))
            else:
                parts.append(("S", repr(a)))
        # global flags change routing (r2p tf32 vs r2 v1-dot): the flag
        # state at trace time must hold at exec time
        from .device.cuda.ops import get_allow_tf32
        parts.append(("allow_tf32", get_allow_tf32()))
        return tuple(parts)

    # opcodes that reference a module global by name — raw co_names would
    # also list attribute (LOAD_ATTR) and import names
    _GLOBAL_OPS = frozenset({
        "LOAD_GLOBAL", "LOAD_NAME", "STORE_GLOBAL", "STORE_NAME",
        "DELETE_GLOBAL", "DELETE_NAME",
    })

    def _captured_tensors(self):
        """Names of Tensor values the fn body can read through captures
        (closure cells + referenced module globals).

        Globals are collected from the actual global-touching
        instructions, not raw ``co_names`` — ``co_names`` also lists
        attribute names (``x.sum()``), which made a module-level Tensor
        sharing a method's name a false positive. May still
        over-report: a global referenced only on a never-executed
        branch is flagged. Both directions fail loud, not silent."""
        fn = self.fn
        code = getattr(fn, "__code__", None)
        if code is None:
            return []
        bad = []
        cells = getattr(fn, "__closure__", None) or ()
        for name, cell in zip(code.co_freevars, cells):
            try:
                v = cell.cell_contents
            except ValueError:  # emptied cell
                continue
            if isinstance(v, Tensor):
                bad.append(name)
        glb = getattr(fn, "__globals__", {})
        seen = set(bad)
        for ins in dis.get_instructions(fn):
            if ins.opname in self._GLOBAL_OPS and ins.argval not in seen:
                seen.add(ins.argval)
                if isinstance(glb.get(ins.argval), Tensor):
                    bad.append(ins.argval)
        return bad

    def _trace(self, args, kwargs):
        from . import ops as ops_mod
        bad = self._captured_tensors()
        if bad:
            # a captured tensor is not an input node: it has no storage
            # under tracing and is invisible to the graph cache key —
            # fail loudly instead of dying on _Proxy/storage internals
            raise RuntimeError(
                f"@tl.compile: {self.fn.__name__} reads captured "
                f"tensor(s) {', '.join(repr(n) for n in bad)} (closure "
                "cells / module globals) — a compiled function must not "
                "read captured tensor state; pass the tensor in as an "
                "argument instead")
        if getattr(self.fn, "__closure__", None) \
                and not self._closure_warned:
            # closure cells are invisible to _key: mutating captured
            # state between calls replays a stale graph — warn once here.
            self._closure_warned = True
            import warnings
            warnings.warn(
                f"@tl.compile: {self.fn.__name__} closes over "
                f"{len(self.fn.__closure__)} cell(s); captured state is "
                "not part of the graph cache key — a compiled function "
                "must not read mutable captured state (closure cells, "
                "module globals, instance attributes) or it silently "
                "replays a stale graph",
                stacklevel=3)
        g = _Graph()
        be = _TraceBackend(g)
        ops_mod._BACKENDS["trace"] = be

        def wrap(a):
            if isinstance(a, Tensor):
                n = _Node("input", "input", (), shape=a.shape, dtype=a.dtype)
                g.inputs.append(n)
                g.nodes.append(n)
                return _Proxy(g, n)
            return a

        t_args = [wrap(a) for a in args]
        # wrap kwargs in the SAME alphabetical order __call__ uses:
        # g.inputs is positional, so record order must match exec order
        t_kwargs = {k: wrap(kwargs[k]) for k in sorted(kwargs)}
        out = self.fn(*t_args, **t_kwargs)
        if not isinstance(out, _Proxy):
            raise RuntimeError(
                "@tl.compile: the function must return a single Tensor")
        fused = _plan(g, out.node)
        return _Exec(g, out.node, fused)

    def __call__(self, *args, **kwargs):
        if os.environ.get("MT_COMPILE", "1") == "0":
            return self.fn(*args, **kwargs)
        if any(isinstance(a, Tensor) and a.device == "cpu"
               for a in list(args) + list(kwargs.values())):
            return self.fn(*args, **kwargs)  # cpu: eager only
        key = self._key(args, kwargs)
        exe = self._cache.get(key)
        if exe is None:
            exe = self._trace(args, kwargs)
            self._cache[key] = exe
        real_inputs = [a for a in list(args) + [kwargs[k] for k in sorted(kwargs)]
                       if isinstance(a, Tensor)]
        return exe.run(real_inputs)


def compile(fn=None):
    """``@tl.compile`` decorator. Set MT_COMPILE=0 to disable.

    Graph cache keys cover only call arguments and the allow_tf32 flag —
    never captured state: mutating module globals / closure cells /
    instance attributes between calls silently replays a stale graph
    (a non-empty ``__closure__`` warns at trace time). Reading a
    captured *tensor* raises at trace time instead — pass tensors in as
    arguments.

    Gradients do NOT flow through a compiled graph: the traced output is
    a fresh eager tensor with no grad_fn, so backward() on it raises
    (unlike torch.compile). Compute loss/backward outside the compiled
    function, or use it for forward-only paths."""
    if fn is None:
        return _CompiledFn
    return _CompiledFn(fn)
