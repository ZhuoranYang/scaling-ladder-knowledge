"""Python-registered W-IR passes — small pass
framework.

Runs between W-IR emission and the upstream conversion pipeline
(compiler/lowering.py). Passes are generic: they know nothing about the
payload — only the ``wir.*`` annotations (affine offset forms, par-loop
hints, warp filters, thread count) that any W-IR program carries.

Framework (kept deliberately small):

- ``Pass``        base class: ``name`` / ``priority`` / ``run(func_op,
                  nt, st)``; ``is_verifier = True`` marks invariant
                  checkers, which the manager runs AFTER all transforms.
- ``PASSES``      the registry; ``@register`` appends.
- ``PassManager`` priority ordering + per-pass env kill-switch
                  (``MINITRITON_WIR_PASSES=0`` disables everything,
                  ``MINITRITON_WIR_<NAME>=0`` one pass — the
                  P1/P2 spellings also work) + per-func stats dicts
                  (hit/bail counters, one per pass per gpu.func).

Passes shipped:

P1  loop warp-distribution: ``par_for t in [0, n)`` (n <= num_warps, no
    carried values, no side exits, no inner control flow) whose smem
    access offsets are all affine is rewritten to ``if warp < n:
    body(warp)`` when every iteration pair proves independent under
    exact per-thread offset enumeration. Loops that fail the proof stay
    sequential and still get P2's sync placement, so correctness never
    depends on the hint.

P2  sync placement/minimization: per-thread exact offset sets (affine
    forms with constant div/mod — closed under evaluation, no polyhedral
    machinery needed) drive a may-dependence analysis over smem
    accesses: a needed cross-warp ordering becomes ``gpu.barrier``, a
    needed same-warp cross-lane ordering becomes ``bar.warp.sync``;
    same-thread program order is free. Pre-existing ``gpu.barrier`` ops
    act as full separators. A structured segment (contains control flow)
    that would need a sync INSIDE it is a hard error — wrong code is
    never emitted.

verify_sync  soundness verifier: replays the dependence analysis after
    the transforms and hard-errors on any unsynchronized may-dependence
    (the P2 guarantee restated as a check). Runs last; catches pass bugs
    rather than payload bugs.

Env: MINITRITON_WIR_PASSES=0 disables all; MINITRITON_WIR_P1/P2/
VERIFY_SYNC=0 disables one.
"""

from __future__ import annotations

import json
import os

from mlir import ir
from mlir.dialects import arith, gpu, nvvm, scf

from .wir import dump_form, eval_form, parse_form, subst_iv

_STATS = []  # per-func dicts, for tests/debug


def stats():
    return list(_STATS)


def _opname(op) -> str:
    """MLIR operation name. Generated ODS OpView classes (gpu.module,
    gpu.func) override ``.name`` to mean the SYMBOL name — always go to
    the underlying Operation for the opcode name."""
    try:
        return op.operation.name
    except AttributeError:
        nm = op.name
        return nm if isinstance(nm, str) else str(nm)


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------

def _get_attr(op, name):
    try:
        return op.attributes[name]
    except KeyError:
        return None


def _attr_str(op, name, default=None):
    a = _get_attr(op, name)
    return ir.StringAttr(a).value if a is not None else default


def _attr_int(op, name, default=None):
    a = _get_attr(op, name)
    return ir.IntegerAttr(a).value if a is not None else default


def _set_str(op, name, s):
    op.attributes[name] = ir.StringAttr.get(s)


def _c32(v) -> ir.Value:
    return arith.constant(ir.IntegerType.get_signless(32), v)


def _const_val(v, depth=0):
    """python int for a compile-time-constant operand (looks through
    arith.constant and index_cast/ext/trunc chains), else None."""
    if depth > 6:
        return None
    owner = v.owner
    if owner is None:
        return None
    nm = _opname(owner)
    if nm == "arith.constant":
        a = _get_attr(owner, "value")
        if a is not None:
            try:
                return ir.IntegerAttr(a).value
            except Exception:
                return None
        return None
    if nm in ("arith.index_cast", "arith.index_castui", "arith.extsi",
              "arith.extui", "arith.trunci"):
        return _const_val(owner.operands[0], depth + 1)
    return None


def _ensure_block(region):
    if not region.blocks:
        region.blocks.append(ir.Block.create_at_start(region, []))
    return region.blocks[0]


class _Access:
    __slots__ = ("op", "role", "form", "vl", "is_store", "_cache")

    def __init__(self, op, is_store=None):
        self.op = op
        self.role = _attr_str(op, "wir.sh")
        self.form = parse_form(_attr_str(op, "wir.off", "null"))
        self.vl = _attr_int(op, "wir.vl", 1)
        if is_store is None:
            is_store = _opname(op) in ("memref.store", "vector.store",
                                       "nvgpu.device_async_copy")
        self.is_store = is_store
        self._cache = {}

    def offsets(self, tid, iv=0):
        """Element offset range for one thread; None when form is opaque.
        Memoized: dependence scans revisit the same (tid, iv) constantly."""
        key = (tid, iv)
        out = self._cache.get(key, 0)
        if out == 0:
            if self.form is None:
                out = None
            else:
                base = eval_form(self.form, tid, iv)
                out = range(base, base + self.vl)
            self._cache[key] = out
        return out


def _walk_ops(op):
    """Pre-order op iterator (this binding's .walk is callback-only)."""
    yield op
    for r in op.regions:
        for b in r.blocks:
            for s in b.operations:
                yield from _walk_ops(s)


def _walk_accesses(op):
    """Program-order annotated smem accesses under op (pre-order walk).
    Modeled op kinds: memref/vector load/store (obvious), annotated
    nvgpu.device_async_copy (a smem WRITE of vl elements), annotated
    nvvm.inline_ptx (a smem READ, e.g. ldmatrix's 16B row)."""
    out = []
    for sub in _walk_ops(op):
        nm = _opname(sub)
        if nm in ("memref.load", "memref.store", "vector.load",
                  "vector.store") and _get_attr(sub, "wir.off") is not None:
            out.append(_Access(sub))
        elif nm in ("nvgpu.device_async_copy", "nvvm.inline_ptx") \
                and _get_attr(sub, "wir.off") is not None:
            out.append(_Access(sub, is_store=(nm == "nvgpu.device_async_copy")))
    return out


def _has_control_flow(op):
    for sub in _walk_ops(op):
        if sub is op:
            continue
        if _opname(sub).split(".")[0] in ("scf", "gpu", "nvgpu", "nvvm"):
            return True
    return False


def _thread_id_op(entry_block):
    for op in entry_block.operations:
        if _opname(op) == "gpu.thread_id":
            return op
    return None


# ---------------------------------------------------------------------------
# dependence machinery (shared by P2 and the soundness verifier)
# ---------------------------------------------------------------------------

class _Seg:
    """A top-level op treated as one scheduling segment (with warp filter).

    ``by_anc`` pairs each access with the index of its top-level child at the
    nearest uniform control level (loop body / mapped-if then-block / plain
    top-level), so intra-segment placement compares integer positions only —
    no MLIR object-identity assumptions anywhere."""

    def __init__(self, op, warps, nt):
        self.op = op
        self.tids = list(range(nt)) if warps is None else \
            [t for w in warps for t in range(w * 32, w * 32 + 32)]
        self.accesses = _walk_accesses(op)
        self.flat = not _has_control_flow(op)
        nm = _opname(op)
        if nm in ("scf.if", "scf.for"):
            self.uchildren = list(op.regions[0].blocks[0].operations)
        else:
            self.uchildren = [op]
        self.by_anc = []
        for ci, ch in enumerate(self.uchildren):
            for a in _walk_accesses(ch):
                self.by_anc.append((ci, a))


def _dep(a1: _Access, s1: _Seg, a2: _Access, s2: _Seg, cache=None):
    """a1 (in s1, earlier) vs a2 (in s2): None / "lane" / "warp" — the
    ordering needed between them (None = independent). offset->tids
    inverted index per (access, segment) memoized in `cache`."""
    if a1.role != a2.role:
        return None
    key = (id(a1), id(s1)) if cache is not None else None
    if cache is not None and key in cache:
        m1, opaque1 = cache[key]
    else:
        m1, opaque1 = {}, []
        for t in s1.tids:
            offs = a1.offsets(t)
            if offs is None:
                opaque1.append(t)
            else:
                for o in offs:
                    m1.setdefault(o, []).append(t)
        if cache is not None:
            cache[key] = (m1, opaque1)
    need = None
    for t2 in s2.tids:
        offs2 = a2.offsets(t2)
        if offs2 is None:
            cand = [t for t in s1.tids if t != t2]  # opaque: aliases all
        else:
            cand = list(opaque1)
            for o in offs2:
                hit = m1.get(o)
                if hit:
                    cand += hit
            if not cand:
                continue
        for t1 in cand:
            if t1 == t2:
                continue
            if t1 // 32 != t2 // 32:
                return "warp"
            need = "lane"
    return need


def _insert_sync(op, kind):
    with ir.InsertionPoint(op):
        if kind == "warp":
            gpu.barrier()
        else:
            nvvm.InlinePtxOp([], [_c32(-1)], [], "bar.warp.sync $0;")


# ---------------------------------------------------------------------------
# pass framework
# ---------------------------------------------------------------------------

class Pass:
    """One W-IR pass. A general pass reads only ``wir.*`` annotations and
    proves legality per instance."""

    name = ""
    priority = 0
    is_verifier = False

    def run(self, func_op, nt, st):
        raise NotImplementedError


PASSES: list[Pass] = []


def register(cls):
    PASSES.append(cls())
    return cls


def _pass_enabled(name: str) -> bool:
    if os.environ.get("MINITRITON_WIR_PASSES", "1") == "0":
        return False
    return os.environ.get(f"MINITRITON_WIR_{name.upper()}", "1") != "0"


class PassManager:
    """Priority-ordered driver over the registry: transforms first
    (ascending priority), then verifiers. Per gpu.func, one flat stats
    dict with p1_/p2_-prefixed keys."""

    def __init__(self):
        self.transforms = sorted(
            (p for p in PASSES if not p.is_verifier
             and _pass_enabled(p.name)),
            key=lambda p: p.priority)
        self.verifiers = sorted(
            (p for p in PASSES if p.is_verifier
             and _pass_enabled(p.name)),
            key=lambda p: p.priority)

    def run(self, mod, nt_default: int = 128):
        if not (self.transforms or self.verifiers):
            return
        for gm in mod.body.operations:
            if _opname(gm) != "gpu.module":
                continue
            for func in gm.regions[0].blocks[0].operations:
                if _opname(func) != "gpu.func":
                    continue
                nt = _attr_int(func, "wir.nt", nt_default)
                st = {"func": _attr_str(func, "sym_name", "?"),
                      "p1_distributed": 0, "p1_bail_dep": 0,
                      "p1_bail_opaque": 0, "p1_bail_warp": 0,
                      "p2_top_warp": 0,
                      "p2_top_lane": 0, "p2_inner_warp": 0,
                      "p2_inner_lane": 0}
                for p in self.transforms:
                    p.run(func, nt, st)
                for p in self.verifiers:
                    p.run(func, nt, st)
                _STATS.append(st)
                if os.environ.get("MINITRITON_WIR_DEBUG") == "1":
                    print("[wir-passes]", st, flush=True)


def run_python_passes(mod, nt_default=128):
    """mod: ir.Module (parsed). Runs the registered passes on every
    gpu.func (transforms by priority, then verifiers)."""
    PassManager().run(mod, nt_default)


# ---------------------------------------------------------------------------
# P1: par-loop warp distribution
# ---------------------------------------------------------------------------

@register
class P1WarpDistribute(Pass):
    name = "p1"
    priority = 10

    def run(self, func_op, nt, st):
        # candidate par_loops may be nested (e.g. a staging loop around a
        # compute par_loop): legality is loop-local, so walk them all
        # (snapshot first — distribution erases loops)
        cands = [op for op in _walk_ops(func_op)
                 if _opname(op) == "scf.for"
                 and _attr_str(op, "wir.map") == "warp"]
        for op in cands:
            self._distribute(op, nt, st)

    def _distribute(self, for_op, nt, mod_stats):
        if _attr_str(for_op, "wir.map") != "warp":
            return False
        ops = for_op.operands
        if len(for_op.results) != 0 or len(ops) != 3:
            return False  # carried values: bail
        lb, ub, step = (_const_val(ops[0]), _const_val(ops[1]),
                        _const_val(ops[2]))
        nw = _attr_int(for_op, "wir.nw", 4)
        lid = _attr_int(for_op, "wir.lid")
        if lb != 0 or step != 1 or ub is None or ub < 1 or ub > nw:
            return False
        block = for_op.regions[0].blocks[0]

        def _body_clean(op):
            """No nested loops/syncs/GPU-region ops; result-free scf.if
            (lane predicates are part of the algorithm) is fine — P1's
            per-thread evaluation conservatively ignores predicates.
            Every smem load/store must carry a wir.off annotation:
            unannotated accesses escape both the independence and the
            warp-redundancy proofs below."""
            for sub in _walk_ops(op):
                if sub is op:
                    continue
                nm = _opname(sub)
                top = nm.split(".")[0]
                if top in ("gpu", "nvgpu", "nvvm"):
                    return False
                if nm == "scf.for":
                    return False
                if nm == "scf.if" and len(list(sub.results)) != 0:
                    return False
                if nm in ("memref.load", "memref.store",
                          "vector.load", "vector.store") \
                        and _get_attr(sub, "wir.off") is None:
                    memop = sub.operands[
                        0 if "load" in nm else 1]
                    try:
                        ms = ir.MemRefType(memop.type).memory_space
                    except ValueError:
                        continue
                    if ms is not None and \
                            str(ms) == "#gpu.address_space<workgroup>":
                        return False
            return True

        if not _body_clean(for_op):
            return False
        accs = _walk_accesses(for_op)
        if any(a.form is None for a in accs):
            mod_stats["p1_bail_opaque"] += 1
            return False
        # exact independence: for t1 != t2, W(t1) n (R(t2) | W(t2)) == {}
        sets = {}
        writes = [i for i, a in enumerate(accs) if a.is_store]
        for ai, a in enumerate(accs):
            for t in range(ub):
                s = set()
                for tid in range(nt):
                    s |= set(a.offsets(tid, t))
                sets[(ai, t)] = s
        for t1 in range(ub):
            w1 = set()
            for ai in writes:
                w1 |= sets[(ai, t1)]
            for t2 in range(ub):
                if t1 == t2:
                    continue
                for ai in range(len(accs)):
                    if w1 & sets[(ai, t2)]:
                        mod_stats["p1_bail_dep"] += 1
                        return False
        # intra-iteration warp redundancy: iteration t is re-executed by
        # warp t ALONE, so every access offset must be warp-invariant —
        # identical addresses from the same lane of every warp
        # (eval_form(form, tid, t) == eval_form(form, tid % 32, t)). The
        # independence proof above only covers CROSS-iteration overlap: a
        # loop whose offsets depend on the full tid but whose iterations
        # are mutually disjoint would pass it and then silently lose the
        # other nt-32 threads' writes of every iteration.
        for a in accs:
            for t in range(ub):
                for tid in range(nt):
                    if eval_form(a.form, tid, t) != \
                            eval_form(a.form, tid % 32, t):
                        mod_stats["p1_bail_warp"] += 1
                        return False
        # rewrite: scf.for t -> if (warp < n) { body with iv := warp }
        own = for_op.parent
        while own is not None and _opname(own) != "gpu.func":
            own = own.parent
        func_entry = own.regions[0].blocks[0] if own is not None else None
        with ir.InsertionPoint(for_op):
            t_op = _thread_id_op(func_entry) if func_entry is not None \
                else None
            if t_op is not None:
                tidv = t_op.results[0]
            else:
                with ir.InsertionPoint.at_block_begin(func_entry):
                    tidv = gpu.thread_id("x")
            tid32 = arith.index_cast(ir.IntegerType.get_signless(32), tidv)
            warp = arith.divsi(tid32, _c32(32))
            cond = arith.cmpi(arith.CmpIPredicate.slt, warp, _c32(ub))
            if_op = scf.IfOp(cond, [], has_else=False)
        then_block = _ensure_block(if_op.regions[0])
        with ir.InsertionPoint.at_block_begin(then_block):
            warp_idx = arith.index_cast(ir.IndexType.get(), warp)
        iv = block.arguments[0]
        sub_ops = [s for s in block.operations if _opname(s) != "scf.yield"]
        for sub in sub_ops:
            then_block.append(sub)
        iv.replace_all_uses_with(warp_idx)
        with ir.InsertionPoint(then_block.operations[-1]):
            y = scf.YieldOp([])
        then_block.append(y.operation)  # move the terminator to the block end
        _set_str(if_op, "wir.warps", json.dumps(list(range(ub))))
        # fix moved access annotations: iv := warp == tid // 32
        repl = ("div", ("tid",), 32)
        for a in _walk_accesses(if_op):
            _set_str(a.op, "wir.off", dump_form(subst_iv(a.form, lid, repl)))
        for_op.erase()
        mod_stats["p1_distributed"] += 1
        return True


# ---------------------------------------------------------------------------
# P2: sync placement / minimization
# ---------------------------------------------------------------------------

@register
class P2SyncPlacement(Pass):
    name = "p2"
    priority = 20

    def run(self, func_op, nt, st):
        body = func_op.regions[0].blocks[0]
        segs, hard_seps = [], set()  # hard_seps: segment indices fully ordered
        for op in body.operations:
            if _opname(op) == "gpu.barrier":
                hard_seps.add(len(segs))  # separator BEFORE this position
                continue
            warps = None
            if _opname(op) == "scf.if" \
                    and _get_attr(op, "wir.warps") is not None:
                warps = json.loads(_attr_str(op, "wir.warps"))
            seg = _Seg(op, warps, nt)
            if seg.accesses:
                segs.append(seg)
        if not segs:
            return
        # --- top-level placement (scan back until a full separator) -----
        inserted = {}  # gap index (before segs[i]) -> kind
        dcache = {}
        for i in range(1, len(segs)):
            need = None
            j = i - 1
            while j >= 0:
                if (j + 1) in hard_seps or inserted.get(j + 1) == "warp":
                    break
                for a1 in segs[j].accesses:
                    for a2 in segs[i].accesses:
                        if not a1.is_store and not a2.is_store:
                            continue
                        d = _dep(a1, segs[j], a2, segs[i], dcache)
                        if d == "warp":
                            need = "warp"
                            break
                        need = need or d
                    if need == "warp":
                        break
                if need == "warp":
                    break
                j -= 1
            if need:
                _insert_sync(segs[i].op, need)
                inserted[i] = need
                mod_stats = st
                mod_stats["p2_top_" + need] += 1
        # --- intra-segment -------------------------------------------------
        # Place syncs inside structured segments at the nearest UNIFORM
        # control level (loop body / mapped-if then-block / func top): never
        # inside a lane-predicated region (would be divergent). Cross-warp
        # edges inside a warp-filtered segment cannot be fixed locally ->
        # loud bail.
        for si, seg in enumerate(segs):
            entries = seg.by_anc
            if len(entries) < 2:
                continue
            scoped = seg.tids != list(range(nt))  # executes a subset of threads
            placed = []  # uniform-child indices that got a preceding sync
            for y in range(len(entries)):
                ayi, ya = entries[y]
                need = None
                for x in range(y):
                    axi, xa = entries[x]
                    if not xa.is_store and not ya.is_store:
                        continue
                    if axi == ayi:
                        d = _dep(xa, seg, ya, seg, dcache)
                        if d:
                            raise RuntimeError(
                                "WIR P2: dependence inside one predicated "
                                f"region (#{x} vs #{y}, segment {si}); "
                                "restructure the W-IR program (sync would be "
                                "divergent here)")
                        continue
                    if any(axi < p <= ayi for p in placed):
                        continue
                    d = _dep(xa, seg, ya, seg, dcache)
                    if d == "warp" and scoped:
                        raise RuntimeError(
                            "WIR P2: cross-warp dependence inside a scoped "
                            f"segment (#{x} vs #{y}, segment {si}); "
                            "restructure the W-IR program (split or map "
                            "differently)")
                    need = need or d
                if need:
                    if need == "warp" and _opname(seg.op) == "scf.for":
                        # redundant all-warp execution of a bailed par_loop
                        # races identical values across warps (W-IR legality
                        # contract); a warp-scope sync is sufficient
                        need = "lane"
                    _insert_sync(seg.uchildren[ayi], need)
                    placed.append(ayi)
                    st["p2_inner_" + need] += 1


# ---------------------------------------------------------------------------
# verify_sync: sync-placement soundness (post-transform invariant)
# ---------------------------------------------------------------------------

@register
class VerifySyncSoundness(Pass):
    """Restates the P2 guarantee as a check: after all transforms, every
    cross-segment may-dependence must be separated by a full barrier
    (pre-existing or P2-placed). A violation means a pass BUG — hard
    error, never silently miscompiled. Cheap: runs the same memoized
    dependence scan as P2, but read-only."""

    name = "verify_sync"
    priority = 90
    is_verifier = True

    def run(self, func_op, nt, st):
        # top-level segment scan identical in shape to P2's: full
        # separators are gpu.barrier ops (any origin); bar.warp.sync does
        # NOT separate cross-warp edges, so the scan ignores it. The check
        # is the strong invariant (every cross-warp may-dependence is
        # barrier-separated); lane-level checks stay with P2's model.
        body = func_op.regions[0].blocks[0]
        events = []  # ("bar" | "seg", seg|None) in program order
        for op in body.operations:
            nm = _opname(op)
            if nm == "gpu.barrier":
                events.append(("bar", None))
                continue
            warps = None
            if nm == "scf.if" and _get_attr(op, "wir.warps") is not None:
                warps = json.loads(_attr_str(op, "wir.warps"))
            seg = _Seg(op, warps, nt)
            if seg.accesses:
                events.append(("seg", seg))
        segs = [s for k, s in events if k == "seg"]
        st["verify_sync_segments"] = len(segs)
        dcache = {}
        checked = 0
        seg_idx = 0
        for ei, (kind, seg_i) in enumerate(events):
            if kind != "seg":
                continue
            need = None
            for kind_j, seg_j in reversed(events[:ei]):
                if kind_j == "bar":
                    break
                for a1 in seg_j.accesses:
                    for a2 in seg_i.accesses:
                        if not a1.is_store and not a2.is_store:
                            continue
                        d = _dep(a1, seg_j, a2, seg_i, dcache)
                        if d == "warp":
                            need = (a1, a2)
                            break
                    if need:
                        break
                if need:
                    break
            if need:
                raise RuntimeError(
                    "WIR verify_sync: cross-warp may-dependence between "
                    "segments is not separated by a gpu.barrier — a "
                    "transform pass broke sync soundness "
                    f"(func {st['func']}, segment #{seg_idx})")
            checked += 1
            seg_idx += 1
        st["verify_sync_checked"] = checked
