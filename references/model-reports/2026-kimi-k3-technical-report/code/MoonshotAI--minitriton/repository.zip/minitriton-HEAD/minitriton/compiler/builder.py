"""Tile operation emission layer: maps DSL tile ops onto upstream MLIR
dialects (arith / scf / vector / memref / gpu / nvvm). One program = one
thread block; tile values are distributed (per-thread vectors), flat-
distributed, or replicated per compiler/layout.py; addresses stay symbolic
(SepOff) or materialize as gather/scatter (MatOff). Pointers lower to a
dual scalar/16B-vector memref ABI with a runtime alignment guard.
"""

from __future__ import annotations

import contextlib
import itertools
import math

from mlir import ir
from mlir.dialects import arith, gpu, llvm, memref, nvgpu, nvvm, scf, vector

from .. import precision as _precision
from ..frontend import types as tl
from .layout import (
    Blocked,
    Fragment,
    Layout,
    Replicated,
    Sliced,
    convert_plan,
    default_layout,
    dist_layout,
    flat_layout,
    is_dist,
    is_flat,
    is_rep_like,
    is_t2,
    is_t3,
    store_compatible,
    t2_layout,
    vec_ept,
)

# Precision levers are compile-time constants: precision.py resolves the
# env once at import, and codegen here must see the SAME frozen values
# the compile-cache fingerprint uses (runtime/cache.py snapshots them at
# import too). Read them once, at module import — a runtime poke of a
# precision.* global is then uniformly inert for codegen AND cache keys
# instead of diverging (stale cubin / disk-cache pollution).
_PRECISE_MATH = _precision.precise_math()
_ROW_FP64 = _precision.row_fp64()


class TileConfigError(RuntimeError):
    """Layout/config problem the kernel author can act on."""


TID = ("tid",)  # the wir form of the thread id (annotation surface)


def FC(v):
    from .wir import form_const
    return form_const(v)


def FA(a, b):
    from .wir import form_add
    return form_add(a, b)


def FM(a, b):
    from .wir import form_mul
    return form_mul(a, b)


def FD(a, k):
    from .wir import form_div
    return form_div(a, k)


def FMo(a, k):
    from .wir import form_mod
    return form_mod(a, k)


def FAn(a, k):
    from .wir import form_and
    return form_and(a, k)


def FX(a, b):
    from .wir import form_xor
    return form_xor(a, b)


class MmaAtom:
    """Warp-wide tensor-core atom (geometry + instruction, as data): the
    layout-choice layer of the mma path — staging geometry, fragment maps
    and C writeback derive from these numbers. kind: "tf32" | "tf32x3"
    (3xTF32 hi/lo split) | "bf16"; m/n/k: atom tile; ep: elems per operand
    reg; v16: elems per 16B smem chunk; cvt: operands need cvt.rna.tf32
    rounding after the fragment load.
    """

    __slots__ = ("kind", "asm", "m", "n", "k", "ep", "v16", "elem", "cvt")


_MMA_ATOMS: dict = {}


def mma_atom(kind: str) -> MmaAtom:
    """The mma.sync atoms supported by tl.mma_tile (cached)."""
    a = _MMA_ATOMS.get(kind)
    if a is not None:
        return a
    a = MmaAtom()
    a.kind = kind
    if kind in ("tf32", "tf32x3"):
        a.asm = ("mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 "
                 "{$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, "
                 "{$10,$11,$12,$13};")
        a.m, a.n, a.k = 16, 8, 8
        a.ep, a.v16, a.elem = 1, 4, tl.float32
        a.cvt = True
    elif kind == "bf16":
        a.asm = ("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 "
                 "{$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, "
                 "{$10,$11,$12,$13};")
        a.m, a.n, a.k = 16, 8, 16
        a.ep, a.v16, a.elem = 2, 8, tl.bfloat16
        a.cvt = False
    else:
        raise TileConfigError(f"unknown mma atom {kind!r}")
    _MMA_ATOMS[kind] = a
    return a


def _workgroup_space():
    return ir.Attribute.parse("#gpu.address_space<workgroup>")


def _btrans_swizzle_factor(bk: int, bn: int) -> int:
    """Column-swizzle factor for transposed-B smem staging in matmul_tile.
    The XOR swizzle col ^ (kk * f) stays a bijection inside the (BK, BN)
    tile only when bn is a multiple of the smallest power of two greater
    than (bk-1)*f. 0 = unswizzled (correct, bank-conflicted)."""
    if bn >= 4 * bk:
        f = 4
    elif 8 <= bk <= 32 and bn >= 32:
        f = 32 // bk
    else:
        return 0
    need = 1
    while need <= (bk - 1) * f:
        need *= 2
    return f if bn % need == 0 else 0


# MLIR python objects must not be GC'd during interpreter finalization
# (their pybind deallocs need the GIL): root every Builder's context graph
# here so it dies with the process. CAPPED to bound autotune memory.
_MLIR_KEEP_ALIVE = []
_MLIR_KEEP_ALIVE_CAP = 64


def _ensure_block(region):
    """scf region blocks are auto-created by the op builders; reuse if so."""
    return region.blocks[0] if len(region.blocks) else region.blocks.append()


# ---------------------------------------------------------------------------
# Value model
# ---------------------------------------------------------------------------

class CExpr:
    """Compile-time value (python int/float/bool/str/DType)."""

    def __init__(self, value):
        if isinstance(value, tl.constexpr):
            value = value.value
        self.value = value

    def __repr__(self):
        return f"CExpr({self.value!r})"


class SmemBuf:
    """First-class smem staging buffer (the tl.smem value): a compile-time
    descriptor (backing .shared memref + shape/dtype) in RAW row-major
    layout. Written by tl.async_copy/tl.store_smem, read by tl.load_smem."""

    def __init__(self, smem, shape: tuple[int, int], dtype):
        self.smem = smem
        self.shape = shape
        self.dtype = dtype

    def __repr__(self):
        return f"SmemBuf({self.shape}, {self.dtype.name})"


class StagePipe:
    """Compile-time cp.async staging pipe (the tl.stage_pipe value): one
    named swizzled smem tile buffer plus its staging geometry. tl.async_stage
    copies a tile in, tl.mma consumes it through an AsyncTok promise."""

    def __init__(self, smem, rows: int, cols: int, trans: bool,
                 even: bool, elem):
        self.smem = smem
        self.rows = rows
        self.cols = cols
        self.trans = trans
        self.even = even
        self.elem = elem

    def __repr__(self):
        return (f"StagePipe({self.rows}x{self.cols}, trans={self.trans}, "
                f"even={self.even})")


class AsyncTok:
    """cp.async commit-group token (the async promise value) — the
    loop-carried pipeline state. `pipe`: staging destination (StagePipe or
    SmemBuf); `offset`: staged element offset (consumers read there too)."""

    def __init__(self, val, pipe: StagePipe, offset=None, shape=None):
        self.val = val
        self.pipe = pipe
        self.offset = offset  # i32 Scalar | None (== 0)
        self.shape = shape    # logical staged tile (rows, cols) | None
                              # (== the pipe's full buffer when None)

    def carry_items(self):
        items = [(self.val.type, self.val)]
        if self.offset is not None:
            items.append((self.offset.val.type, self.offset.val))
        return items

    def rebuild(self, vals):
        off = Scalar(self.offset.dtype, vals[1]) \
            if self.offset is not None else None
        return AsyncTok(vals[0], self.pipe, off, self.shape)

    def __repr__(self):
        return f"AsyncTok({self.pipe!r})"


class Scalar:
    """Runtime MLIR scalar value (i32/i64/f32/f16/bf16/i1)."""

    def __init__(self, dtype: tl.DType, val: ir.Value):
        self.dtype = dtype
        self.val = val

    def carry_items(self):
        return [(self.val.type, self.val)]

    def rebuild(self, vals):
        return Scalar(self.dtype, vals[0])

    def __repr__(self):
        return f"Scalar({self.dtype})"


class Tensor:
    """Materialized per-thread block value; layout is a
    compiler.layout.Layout. Per-thread register form by layout:
    dist (Blocked): vector<VEC> / vector<R x VEC>; flat (raveled run):
    vector<FPT>; rep-like (Replicated/Sliced): vector<shape>; t2: flat
    vector<tm*tn>; m4 (Fragment): the mma accumulator/operand registers.
    """

    def __init__(self, dtype: tl.DType, shape: tuple[int, ...],
                 layout: Layout, val: ir.Value, ept: int):
        self.dtype = dtype
        self.shape = tuple(shape)
        if not isinstance(layout, Layout):
            raise TileConfigError(
                f"Tensor layout must be a compiler.layout.Layout, got "
                f"{layout!r}")
        ok_shape = tuple(layout.shape) == self.shape
        if not ok_shape and isinstance(layout, Sliced):
            # reduce results keep the sliced dim as size-1: the
            # (R, 1) tensor is the keepdim materialization of
            # Sliced(parent, dim=1) (whose own shape is (R,)).
            d = layout.dim
            ok_shape = self.shape == (layout.shape[:d] + (1,)
                                      + layout.shape[d:])
        if not ok_shape:
            raise TileConfigError(
                f"layout shape {layout.shape} != tensor shape "
                f"{self.shape} ({layout.dump()})")
        if isinstance(layout, Fragment) \
                and ept != layout.regs_per_thread():
            raise TileConfigError(
                f"fragment value has {ept} regs/thread, layout "
                f"{layout.dump()} holds {layout.regs_per_thread()}")
        if isinstance(layout, Sliced) \
                and ept != layout.regs_per_thread():
            raise TileConfigError(
                f"sliced value has {ept} regs/thread, layout "
                f"{layout.dump()} holds {layout.regs_per_thread()}")
        self.layout = layout
        self.val = val
        self.ept = ept  # elements per thread (VEC / FPT / total for rep)

    def carry_items(self):
        return [(self.val.type, self.val)]

    def rebuild(self, vals):
        return Tensor(self.dtype, self.shape, self.layout, vals[0], self.ept)

    def __repr__(self):
        return f"Tensor({self.dtype}, {self.shape}, {self.layout})"


class Affine:
    """Affine 1D offset: value[i] = base + stride*i for i in [0, length);
    base/stride are python ints or i32 MLIR scalars."""

    def __init__(self, base, stride: int = 0, length: int = 1):
        self.base = base
        self.stride = stride
        self.length = length

    def __repr__(self):
        return f"Affine(base={self.base!r}, stride={self.stride}, len={self.length})"


class SepOff:
    """Separable symbolic offsets for address computation.

    shape (C,):  off[c]     = col.eval(c)
    shape (R,C): off[r, c]  = row.eval(r) + col.eval(c)
    shape ():    scalar offset col.base
    """

    def __init__(self, shape: tuple[int, ...], row: Affine | None = None,
                 col: Affine | None = None):
        self.shape = tuple(shape)
        self.row = row
        self.col = col

    @classmethod
    def scalar(cls, base=0):
        return cls((), None, Affine(base, 0, 1))

    @classmethod
    def arange(cls, start: int, length: int):
        return cls((length,), None, Affine(start, 1, length))

    def materialize_bases(self, b) -> "SepOff":
        """Force all affine bases to i32 SSA values (for loop carrying, so
        the carried structure is identical at every iteration)."""
        row = self.row
        col = self.col
        if row is not None and not isinstance(row.base, ir.Value):
            row = Affine(b.as_i32(row.base), row.stride, row.length)
        if col is not None and not isinstance(col.base, ir.Value):
            col = Affine(b.as_i32(col.base), col.stride, col.length)
        return SepOff(self.shape, row, col)

    def carry_items(self):
        items = []
        for aff in (self.row, self.col):
            if aff is None:
                continue
            if isinstance(aff.base, ir.Value):
                items.append((aff.base.type, aff.base))
            if isinstance(aff.stride, ir.Value):
                items.append((aff.stride.type, aff.stride))
        return items

    def rebuild(self, vals):
        it = iter(vals)

        def again(aff):
            if aff is None:
                return None
            base = next(it) if isinstance(aff.base, ir.Value) else aff.base
            stride = next(it) if isinstance(aff.stride, ir.Value) \
                else aff.stride
            return Affine(base, stride, aff.length)

        return SepOff(self.shape, again(self.row), again(self.col))

    def carried_structure(self):
        """The non-carried (compile-time) part of the offset: shape plus,
        per affine, the length and the stride when it is a python int.
        A loop/if-carried offset must keep this fixed — a runtime stride
        rides along as a carried SSA value, but a changed int stride
        would be silently dropped by rebuild, so it is an error."""

        def key(aff):
            if aff is None:
                return None
            s = aff.stride if isinstance(aff.stride, int) else None
            return (s, aff.length)

        return (self.shape, key(self.row), key(self.col))

    def __repr__(self):
        return f"SepOff({self.shape}, row={self.row}, col={self.col})"


class Pred:
    """One symbolic comparison: affine.eval(i) <op> bound (i32 scalar)."""

    def __init__(self, affine: Affine, op: str, bound):
        self.affine = affine
        self.op = op
        self.bound = bound  # int | ir.Value(i32)


class SepMask:
    """Symbolic mask: conjunction of row predicates and column predicates."""

    def __init__(self, shape, row_preds=None, col_preds=None):
        self.shape = tuple(shape)
        self.row_preds = list(row_preds or [])
        self.col_preds = list(col_preds or [])

    def combine(self, other: "SepMask") -> "SepMask":
        if self.shape != other.shape:
            # broadcast (R,1) with (1,C)
            if len(self.shape) == 2 and len(other.shape) == 2:
                r = max(self.shape[0], other.shape[0])
                c = max(self.shape[1], other.shape[1])
                ok0 = self.shape[0] in (1, r) and other.shape[0] in (1, r)
                ok1 = self.shape[1] in (1, c) and other.shape[1] in (1, c)
                if ok0 and ok1:
                    return SepMask((r, c),
                                   self.row_preds + other.row_preds,
                                   self.col_preds + other.col_preds)
            raise TileConfigError(
                f"cannot combine masks of shape {self.shape} and {other.shape}")
        return SepMask(self.shape,
                       self.row_preds + other.row_preds,
                       self.col_preds + other.col_preds)

    def newaxis(self, axis: int) -> "SepMask":
        """1D (C,) -> (C, 1) (axis=0) or (1, C) (axis=1)."""
        if len(self.shape) != 1:
            raise TileConfigError("newaxis on a 2D mask is not supported")
        c = self.shape[0]
        if axis == 0:
            return SepMask((c, 1), self.col_preds, [])
        return SepMask((1, c), [], self.col_preds)


class MatOff:
    """Materialized address offsets: addr = mat (an i32 block of runtime
    loaded indices) — the gather/scatter path: per-lane scalar
    loads/stores/atomics instead of the vectorized SepOff fast path."""

    def __init__(self, shape: tuple[int, ...], mat: "Tensor"):
        self.shape = tuple(shape)
        self.mat = mat  # Tensor, i32

    def materialize_bases(self, b) -> "MatOff":
        return self  # values are already i32 SSA

    def carry_items(self):
        return self.mat.carry_items()

    def rebuild(self, vals):
        return MatOff(self.shape, self.mat.rebuild(vals))

    def __repr__(self):
        return f"MatOff({self.shape}, mat={self.mat!r})"


class PtrTensor:
    """A pointer kernel argument plus a symbolic offset (an address tensor)."""

    def __init__(self, arg: "PtrArg", off: SepOff):
        self.arg = arg
        self.off = off

    def carry_items(self):
        return self.off.carry_items()

    def rebuild(self, vals):
        return PtrTensor(self.arg, self.off.rebuild(vals))

    def carried_structure(self):
        return self.off.carried_structure()


class PtrArg:
    """A pointer kernel parameter: scalar view + 16-byte vector view."""

    def __init__(self, elem: tl.DType, scalar_view: ir.Value, vec_view: ir.Value):
        self.elem = elem
        self.scalar_view = scalar_view
        self.vec_view = vec_view
        self.vl = tl.VECTOR_LANES[elem.name]


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------

class Builder:
    def __init__(self, name: str, num_threads: int):
        self.name = name
        self.num_threads = num_threads
        self.ctx = ir.Context()
        self.loc = ir.Location.unknown(self.ctx)
        self.module = None
        self.func = None
        self.entry = None
        self._ip = None
        self._tid32 = None
        self._smem: dict = {}
        self.i1 = self.i32 = self.f32 = self.idx = None

    # -- context management -------------------------------------------------

    def __enter__(self) -> "Builder":
        self.ctx.__enter__()
        self.loc.__enter__()
        self.i1 = ir.IntegerType.get_signless(1)
        self.i32 = ir.IntegerType.get_signless(32)
        self.f32 = ir.F32Type.get()
        self.idx = ir.IndexType.get()
        self.module = ir.Module.create(self.loc)
        return self

    def __exit__(self, *exc):
        # Root the module graph (finalization GC crashes on the GIL) and
        # pop the context stack (leftover entries also abort at exit).
        _MLIR_KEEP_ALIVE.append(
            (self.ctx, self.loc, self.module, self.func, self.entry,
             self._smem))
        if len(_MLIR_KEEP_ALIVE) > _MLIR_KEEP_ALIVE_CAP:
            del _MLIR_KEEP_ALIVE[:-_MLIR_KEEP_ALIVE_CAP]
        self.module = None
        self.func = None
        self.entry = None
        if self._ip is not None:  # finish() pops this on the happy path
            self._ip.__exit__(None, None, None)
            self._ip = None
        self.loc.__exit__(*exc)
        self.ctx.__exit__(*exc)

    # -- kernel scaffolding ---------------------------------------------------

    def begin(self, params: list):
        """Create module/gpu.module/gpu.func. params: list of (name, spec)
        with spec = ('ptr', DType) | DType. Returns {name: PtrTensor(bare
        pointer) | Scalar}."""
        arg_types = []
        for _, spec in params:
            if isinstance(spec, tuple) and spec[0] == "ptr":
                elem = spec[1]
                arg_types.append(ir.MemRefType.get(
                    [ir.ShapedType.get_dynamic_size()], elem.mlir()))
                arg_types.append(ir.MemRefType.get(
                    [ir.ShapedType.get_dynamic_size()],
                    ir.VectorType.get([tl.VECTOR_LANES[elem.name]], elem.mlir())))
            else:
                arg_types.append(spec.mlir())

        with ir.InsertionPoint(self.module.body):
            gmod = gpu.GPUModuleOp(f"{self.name}_mod")
            gmod.regions[0].blocks.append()
            with ir.InsertionPoint(gmod.regions[0].blocks[0]):
                fnty = ir.FunctionType.get(arg_types, [])
                self.func = gpu.GPUFuncOp(fnty, self.name, kernel=True)
                self.entry = self.func.add_entry_block()

        args = list(self.entry.arguments)
        out = {}
        ai = 0
        for pname, spec in params:
            if isinstance(spec, tuple) and spec[0] == "ptr":
                parg = PtrArg(spec[1], args[ai], args[ai + 1])
                ai += 2
                out[pname] = PtrTensor(parg, SepOff.scalar(0))
            else:
                out[pname] = Scalar(spec, args[ai])
                ai += 1

        self._ip = ir.InsertionPoint(self.entry)
        self._ip.__enter__()
        return out

    def finish(self) -> str:
        gpu.ReturnOp([])
        self._ip.__exit__(None, None, None)
        self._ip = None
        return str(self.module)

    def _if_op(self, cond: ir.Value, result_types: list):
        if_op = scf.IfOp(cond, result_types, has_else=True)
        _ensure_block(if_op.regions[0])
        _ensure_block(if_op.regions[1])
        return if_op

    def _for_op(self, lo, hi, step: int, iter_vals: list):
        """scf.for with index bounds (int or i32 scalar) and iter_args."""
        for_op = scf.ForOp(self.to_index(self.as_i32(lo)),
                           self.to_index(self.as_i32(hi)),
                           self.c_idx(step), iter_args=iter_vals)
        block = _ensure_block(for_op.regions[0])
        return for_op, block

    def _iv_i32(self, block) -> ir.Value:
        return arith.index_cast(self.i32, block.arguments[0])

    @contextlib.contextmanager
    def _block_ip(self, block):
        with ir.InsertionPoint(block):
            yield block

    def _region(self, region):
        return self._block_ip(_ensure_block(region))

    def _yield(self, vals: list):
        scf.YieldOp(vals)

    # -- constants / casts ----------------------------------------------------

    def const(self, dtype: tl.DType, value) -> ir.Value:
        return arith.constant(dtype.mlir(), value)

    def c_i32(self, v: int) -> ir.Value:
        return arith.constant(self.i32, v)

    def c_idx(self, v: int) -> ir.Value:
        return arith.constant(self.idx, v)

    def as_i32(self, v) -> ir.Value:
        """int | ir.Value(i32) -> ir.Value(i32)."""
        return self.c_i32(v) if isinstance(v, int) else v

    def to_index(self, v_i32) -> ir.Value:
        return arith.index_cast(self.idx, v_i32)

    def splat(self, vec_type: ir.Type, scalar: ir.Value) -> ir.Value:
        return vector.broadcast(vec_type, scalar)

    def vec_type(self, shape, elem: tl.DType) -> ir.Type:
        return ir.VectorType.get(list(shape), elem.mlir())

    def materialize_mask(self, mask: SepMask) -> Tensor:
        """Turn a symbolic mask into an i1 block value."""
        layout = self.choose_layout(mask.shape)
        ept = vec_ept(layout)
        rows, cols = mask.shape if len(mask.shape) == 2 else (1, mask.shape[0])
        if is_rep_like(layout):
            vty = ir.VectorType.get([rows, cols] if len(mask.shape) == 2 else [cols],
                                    self.i1)
            res = self.dense_const(vty, tl.int1, 1)
            for r, c in itertools.product(range(rows), range(cols)):
                m = self._rep_mask_at(mask, r, c)
                res = vector.insert(m, res, [], [c] if len(mask.shape) == 1
                                    else [r, c])
            return Tensor(tl.int1, mask.shape, layout, res, ept)
        if is_flat(layout):
            base = arith.muli(self.tid(), self.c_i32(ept))
            rho = arith.divsi(base, self.c_i32(cols))
            gamma = arith.remsi(base, self.c_i32(cols))
            frag, _ = self._flat_mask(mask, rho, gamma, ept)
            return Tensor(tl.int1, mask.shape, layout, frag, ept)
        col_base = arith.muli(self.tid(), self.c_i32(ept))
        frags = []
        for r in range(rows):
            frag, _ = self.mask_frag(mask, r, ept, col_base)
            frags.append(frag)
        if len(mask.shape) == 1:
            return Tensor(tl.int1, mask.shape, layout, frags[0], ept)
        vty = ir.VectorType.get([rows, ept], self.i1)
        res = self.dense_const(vty, tl.int1, 1)
        for r, v in enumerate(frags):
            res = vector.insert(v, res, [], [r])
        return Tensor(tl.int1, mask.shape, layout, res, ept)

    def dense_const(self, vec_type: ir.Type, dtype: tl.DType, value) -> ir.Value:
        if dtype.is_float:
            attr = ir.FloatAttr.get(dtype.mlir(), float(value))
        else:
            attr = ir.IntegerAttr.get(dtype.mlir(), int(value))
        return arith.constant(vec_type, ir.DenseElementsAttr.get_splat(vec_type, attr))

    def _iota_scaled(self, n: int, stride) -> ir.Value:
        """iota(n) * stride, stride int or i32 runtime scalar."""
        vty = ir.VectorType.get([n], self.i32)
        if isinstance(stride, int):
            return self.iota_const(n, stride)
        return arith.muli(self.iota_const(n, 1),
                          self.splat(vty, self.as_i32(stride)))

    def iota_const(self, n: int, stride: int = 1) -> ir.Value:
        import numpy as np
        ty = ir.VectorType.get([n], self.i32)
        return arith.constant(ty, ir.DenseElementsAttr.get(
            np.array([i * stride for i in range(n)], dtype=np.int32), type=ty))

    # -- ids --------------------------------------------------------------------

    def tid(self) -> ir.Value:
        """Thread id within the block, as i32 scalar (hoisted to the entry
        block so it is usable inside and outside control-flow regions)."""
        if self._tid32 is None:
            with ir.InsertionPoint.at_block_begin(self.entry):
                t = gpu.thread_id("x")
                self._tid32 = arith.index_cast(self.i32, t)
        return self._tid32

    def program_id(self, axis: int) -> Scalar:
        bid = gpu.block_id("xyz"[axis])
        return Scalar(tl.int32, arith.index_cast(self.i32, bid))

    # -- affine / sepoff algebra ------------------------------------------------

    def _base_add(self, a, b):
        """int | ir.Value(i32) addition with constant folding."""
        az = isinstance(a, int) and a == 0
        bz = isinstance(b, int) and b == 0
        if az:
            return b
        if bz:
            return a
        if isinstance(a, int) and isinstance(b, int):
            return a + b
        return arith.addi(self.as_i32(a), self.as_i32(b))

    def aff_shift(self, aff: Affine, delta) -> Affine:
        return Affine(self._base_add(aff.base, delta), aff.stride, aff.length)

    def aff_scale(self, aff: Affine, k) -> Affine:
        """Scale by a python int or an i32 runtime scalar."""
        if isinstance(k, int):
            base = aff.base * k if isinstance(aff.base, int) else \
                arith.muli(self.as_i32(aff.base), self.c_i32(k))
            stride = aff.stride * k if isinstance(aff.stride, int) else \
                arith.muli(self.as_i32(aff.stride), self.c_i32(k))
            return Affine(base, stride, aff.length)
        kv = self.as_i32(k)
        if isinstance(aff.base, int) and aff.base == 0:
            base = 0
        else:
            base = arith.muli(self.as_i32(aff.base), kv)
        if not isinstance(aff.stride, int):
            stride = arith.muli(self.as_i32(aff.stride), kv)
        elif aff.stride == 0:
            stride = 0
        elif aff.stride == 1:
            stride = kv
        else:
            stride = arith.muli(self.c_i32(aff.stride), kv)
        return Affine(base, stride, aff.length)

    @staticmethod
    def _is_zero(aff: Affine) -> bool:
        return isinstance(aff.base, int) and aff.base == 0 and aff.stride == 0

    def aff_combine(self, a: Affine, b: Affine, sign: int) -> Affine:
        # broadcast: a zero-valued affine (from a size-1 dim) yields the other
        if sign > 0 and self._is_zero(a):
            return b
        if self._is_zero(b):
            return a
        if a.length != b.length:
            if a.stride == 0:  # constant affine broadcasts along the other
                length = b.length
            elif b.stride == 0:
                length = a.length
            else:
                raise TileConfigError(
                    f"offset length mismatch: {a.length} vs {b.length}")
        else:
            length = a.length
        if sign > 0:
            stride = self._base_add(a.stride, b.stride)
        else:
            stride = self._base_add(a.stride, self._base_neg(b.stride))
        return Affine(self._base_add(a.base, b.base if sign > 0 else
                                     self._base_neg(b.base)),
                      stride, length)

    def _base_neg(self, a):
        return -a if isinstance(a, int) else arith.subi(self.c_i32(0), self.as_i32(a))

    def off_shift(self, off: SepOff, delta) -> SepOff:
        """Shift the whole address by a scalar delta. The offset value is
        row + col, so the delta must be applied exactly once (to col)."""
        col = self.aff_shift(off.col, delta) if off.col else None
        return SepOff(off.shape, off.row, col)

    def off_scale(self, off: SepOff, k: int) -> SepOff:
        row = self.aff_scale(off.row, k) if off.row else None
        col = self.aff_scale(off.col, k) if off.col else None
        return SepOff(off.shape, row, col)

    def off_combine(self, a: SepOff, b: SepOff, sign: int = 1) -> SepOff:
        """a +/- b for broadcast-compatible separable offsets."""
        shape = _broadcast_shapes(a.shape, b.shape)
        if shape is None:
            raise TileConfigError(
                f"cannot combine offset tensors of shape {a.shape} and {b.shape}: "
                "currently supports scalar broadcast and (R,1)+(1,C) tile offsets")

        def side(x: SepOff, which: str, length: int) -> Affine:
            aff = x.row if which == "row" else x.col
            if aff is None:
                return Affine(0, 0, length)
            return aff

        if len(shape) == 0:
            return SepOff((), None, self.aff_combine(a.col, b.col, sign))
        if len(shape) == 1:
            return SepOff(shape, None, self.aff_combine(a.col, b.col, sign))
        r, c = shape
        row_a, row_b = side(a, "row", r), side(b, "row", r)
        col_a, col_b = side(a, "col", c), side(b, "col", c)
        # a (C,) 1D offset broadcasts over the rows of a 2D one, etc.
        if len(a.shape) == 1:
            col_a = a.col
            row_a = Affine(0, 0, r)
        if len(b.shape) == 1:
            col_b = b.col
            row_b = Affine(0, 0, r)
        return SepOff(shape,
                      self.aff_combine(row_a, row_b, sign),
                      self.aff_combine(col_a, col_b, sign))

    def off_newaxis(self, off: SepOff, axis: int) -> SepOff:
        """1D (C,) -> (C, 1) for axis=0 (x[:, None]) or (1, C) for axis=1."""
        if len(off.shape) != 1:
            raise TileConfigError(
                f"newaxis on a {len(off.shape)}D offset tensor is not supported (1D only)")
        c = off.shape[0]
        if axis == 0:  # x[:, None]
            return SepOff((c, 1), off.col, Affine(0, 0, 1))
        return SepOff((1, c), Affine(0, 0, 1), off.col)

    # -- materialized offsets (gather/scatter addressing) ---------------------

    def off_mat(self, mat: "Tensor") -> "MatOff":
        """Wrap a runtime-loaded i32 block as a materialized offset tensor."""
        if not isinstance(mat, Tensor) or mat.dtype != tl.int32:
            raise TileConfigError(
                "materialized pointer offsets must be an i32 block "
                f"(tl.load of an i32 index buffer), got {mat!r}")
        return MatOff(mat.shape, mat)

    def off_mat_shift(self, off: "MatOff", delta) -> "MatOff":
        """MatOff + scalar delta: shift every materialized address once."""
        if isinstance(delta, int) and delta == 0:
            return off
        d = self.as_i32(delta)
        mat = off.mat
        return MatOff(off.shape,
                      Tensor(tl.int32, mat.shape, mat.layout,
                             arith.addi(mat.val, self.splat(mat.val.type, d)),
                             mat.ept))

    def off_mat_combine(self, off: "MatOff", rhs: SepOff) -> "MatOff":
        """MatOff + symbolic offset (broadcast-free, same shape):
        materialize the symbolic part and add it elementwise."""
        if rhs.shape == ():
            return self.off_mat_shift(off, self.eval_affine(rhs.col, 0))
        if rhs.shape != off.shape:
            raise TileConfigError(
                f"cannot combine materialized offsets of shape {off.shape} "
                f"with a symbolic offset of shape {rhs.shape} (scalar "
                "base or same shape only; fold broadcasts into the index "
                "block arithmetically)")
        m0 = self.materialize_offsets(rhs)
        mat = off.mat
        if m0.layout != mat.layout or m0.ept != mat.ept:
            # unreachable for same shape (layouts are shape-determined),
            # but fail loud instead of mis-addressing if that ever changes
            raise TileConfigError(
                f"layout mismatch combining offsets: {m0.layout} vs {mat.layout}")
        return MatOff(off.shape,
                      Tensor(tl.int32, off.shape, mat.layout,
                             arith.addi(mat.val, m0.val), mat.ept))

    def eval_affine(self, aff: Affine, i) -> ir.Value:
        """Evaluate base + stride*i at python-int or i32-scalar i."""
        base = self.as_i32(aff.base)
        if isinstance(aff.stride, int) and aff.stride == 0:
            return base
        i32 = self.as_i32(i)
        if isinstance(aff.stride, int) and aff.stride == 1:
            term = i32
        else:
            term = arith.muli(i32, self.as_i32(aff.stride))
        if isinstance(aff.base, int) and aff.base == 0:
            return term
        return arith.addi(base, term)

    def eval_affine_frag(self, aff: Affine, base_i32: ir.Value, n: int) -> ir.Value:
        """vector<n x i32>: eval(base + stride*(base_i32 + j)) for j in 0..n."""
        s = self.eval_affine(aff, base_i32)
        vty = ir.VectorType.get([n], self.i32)
        if isinstance(aff.stride, int):
            return arith.addi(self.splat(vty, s), self.iota_const(n, aff.stride))
        return arith.addi(self.splat(vty, s),
                          arith.muli(self.iota_const(n, 1),
                                     self.splat(vty, self.as_i32(aff.stride))))

    # -- layouts ------------------------------------------------------------------

    def choose_layout(self, shape: tuple[int, ...], *,
                      hint: str | None = None) -> Layout:
        """The load-time default layout (the pick when nothing requests
        otherwise): layout.default_layout; `hint` forces a family ("flat"
        = dot's staging preference)."""
        nt = self.num_threads
        if hint == "flat":
            return flat_layout(shape, nt)
        if hint is not None:
            raise TileConfigError(f"choose_layout: unknown hint {hint!r}")
        return default_layout(shape, nt)

    def convert_layout(self, v: Tensor, dst: Layout, *,
                       scratch=None) -> Tensor:
        """Convert value ``v`` to layout ``dst``; tier selection is
        layout.convert_plan: tier-0 identity, tier-1 register rules,
        tier-2 smem round-trip (``scratch`` supplies the buffer, else the
        static 48KB budget). tier-3 is graph-level only."""
        if not isinstance(dst, Layout):
            raise TileConfigError(
                f"convert_layout dst must be a Layout, got {dst!r}")
        src = v.layout
        if not isinstance(src, Layout):
            raise TileConfigError(
                f"convert_layout src layout must be a "
                f"compiler.layout.Layout, got {src!r}")
        plan = convert_plan(src, dst)
        if plan == "t0":
            return v
        if plan == "t1:frag_c_to_a":
            return self._convert_t1_frag_c_to_a(v, dst)
        if plan == "t1:bcast_to_frag_c":
            return self._convert_t1_bcast_to_frag_c(v, dst)
        return self._convert_t2_smem(v, dst, scratch)

    def _shfl_idx_f32(self, v, src):
        """shfl.sync.idx.b32 on an f32 lane value via inline PTX (gpu.shuffle
        IDX constrains the src lane to an immediate in this LLVM)."""
        return nvvm.InlinePtxOp(
            [self.f32], [v, src], [],
            "shfl.sync.idx.b32 $0, $1, $2, 0x1f, -1;").results[0]

    def _convert_t1_frag_c_to_a(self, v: Tensor, dst: Fragment) -> Tensor:
        """tier-1 rules #1/#2: mma C fragment -> A operand regs.
        The C fragment's n dim is the A fragment's k dim, so per A atom
        (im, h) the 4 i32 operand regs come straight out of the C
        accumulators: bf16 packs the two k-adjacent f32 accumulators of C
        atoms 2h/2h+1 into one bf16x2 register (zero shuffles); tf32 takes
        the (k = t, t+4) columns from the t//2 / t//2+2 lanes of the quad
        (two shfl.idx + one select per register), then cvt.rna.tf32.
        Returns a Tensor of the raw i32 operand registers (atoms_m *
        atoms_k * 4, (im, h, j) order), layout ``dst``.
        """
        src = v.layout
        atom = mma_atom(src.atom)
        am, an = src.atoms
        ak = dst.atoms[1]
        c = self.c_i32
        if atom.ep == 1:
            tid = self.tid()
            lane = arith.remsi(tid, c(32))
            g = arith.divsi(lane, c(4))
            t = arith.remsi(lane, c(4))
            is_odd = self.compare("!=", arith.andi(t, c(1)), c(0), tl.int32)
            src0 = arith.addi(arith.shli(g, c(2)), arith.shrui(t, c(1)))
            src2 = arith.addi(src0, c(2))
        nreg = am * ak * 4
        vty = ir.VectorType.get([nreg], self.i32)
        out = self.dense_const(vty, tl.int32, 0)
        for im in range(am):
            for h in range(ak):
                if atom.ep == 1:  # tf32: quad shfl.idx + select + cvt.rna
                    i0 = (im * an + h) * 4
                    cv = [vector.extract(v.val, [], [i0 + j])
                          for j in range(4)]
                    sel = [
                        self.select(is_odd,
                                    self._shfl_idx_f32(cv[1], src0),
                                    self._shfl_idx_f32(cv[0], src0)),
                        self.select(is_odd,
                                    self._shfl_idx_f32(cv[3], src0),
                                    self._shfl_idx_f32(cv[2], src0)),
                        self.select(is_odd,
                                    self._shfl_idx_f32(cv[1], src2),
                                    self._shfl_idx_f32(cv[0], src2)),
                        self.select(is_odd,
                                    self._shfl_idx_f32(cv[3], src2),
                                    self._shfl_idx_f32(cv[2], src2))]
                    regs = [self._mma_cvt_tf32(arith.bitcast(self.i32, a))
                            for a in sel]
                else:             # bf16: adjacent-accumulator pair pack
                    def px(ai, j):
                        return vector.extract(v.val, [],
                                              [(im * an + ai) * 4 + j])
                    regs = [
                        self._mma_pack_bf16x2(px(2 * h, 0), px(2 * h, 1)),
                        self._mma_pack_bf16x2(px(2 * h, 2), px(2 * h, 3)),
                        self._mma_pack_bf16x2(px(2 * h + 1, 0),
                                              px(2 * h + 1, 1)),
                        self._mma_pack_bf16x2(px(2 * h + 1, 2),
                                              px(2 * h + 1, 3))]
                for j in range(4):
                    out = vector.insert(regs[j], out, [],
                                        [(im * ak + h) * 4 + j])
        return Tensor(tl.int32, dst.shape, dst, out, nreg)

    def _convert_t1_bcast_to_frag_c(self, v: Tensor,
                                    dst: Fragment) -> Tensor:
        """tier-1 rule: a small (N,)/(1, N) f32 vector (rep, or warp-local
        dist) broadcast into the mma C fragment's columns — the bias add
        of the mma matmul epilogue. Fragment element (g, t) of atom
        (im, in_) takes the value at column wx*wa_n + in_*8 + t*2 + j%2.
        Register-only: a rep source selects among its registers; a dist
        source shfl.idx's the owner lane (col // VEC) and selects over
        col % VEC. src must be f32.
        """
        src = v.layout
        if v.dtype != tl.float32:
            raise TileConfigError(
                f"bcast_to_frag_c expects an f32 vector, got {v.dtype}")
        n = dst.shape[1]
        wn_m, wn_n = dst.warps
        am, an = dst.atoms
        wa_n = n // wn_n
        c = self.c_i32
        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        warp = arith.divsi(tid, c(32))
        t = arith.remsi(lane, c(4))
        wx = arith.remsi(warp, c(wn_n))
        rank1 = len(v.shape) == 1

        def src_reg(idx):
            return vector.extract(v.val, [], [idx] if rank1 else [0, idx])

        vals = []
        for in_ in range(an):
            for jj in range(2):
                if isinstance(src, Replicated):
                    # col = wx*wa_n + in_*8 + t*2 + jj: full case select
                    scal = None
                    for wxi in range(wn_n):
                        for ti in range(4):
                            cand = src_reg(wxi * wa_n + in_ * 8
                                           + ti * 2 + jj)
                            cond = self.and_i1(
                                self.compare("==", wx, c(wxi), tl.int32),
                                self.compare("==", t, c(ti), tl.int32))
                            scal = cand if scal is None else \
                                self.select(cond, cand, scal)
                else:
                    # dist: col's owner lane (col // VEC) + static reg
                    # select (col % VEC)
                    vec = src.size_per_thread[-1]
                    col = arith.addi(
                        arith.addi(arith.muli(wx, c(wa_n)),
                                   c(in_ * 8 + jj)),
                        arith.muli(t, c(2)))
                    owner = arith.divsi(col, c(vec))
                    rem = arith.remsi(col, c(vec))
                    scal = None
                    for r in range(vec):
                        cand = self._shfl_idx_f32(src_reg(r), owner)
                        cond = self.compare("==", rem, c(r), tl.int32)
                        scal = cand if scal is None else \
                            self.select(cond, cand, scal)
                vals.append(scal)
        return self._frag_c_from_col_vals(v, dst, vals)

    def _frag_c_from_col_vals(self, v: Tensor, dst: Fragment,
                              vals: list) -> Tensor:
        """Assemble the C-fragment register vector from the per-lane
        column values (2 per atom-n, (in_, j%2) order)."""
        am, an = dst.atoms
        nreg = am * an * 4
        vty = ir.VectorType.get([nreg], self.f32)
        out = self.dense_const(vty, tl.float32, 0.0)
        for im in range(am):
            for in_ in range(an):
                for half in range(2):
                    for jj in range(2):
                        out = vector.insert(
                            vals[in_ * 2 + jj], out, [],
                            [(im * an + in_) * 4 + 2 * half + jj])
        return Tensor(tl.float32, dst.shape, dst, out, nreg)

    def _convert_vec_to_frag_c_smem(self, v: Tensor,
                                    dst: Fragment) -> Tensor:
        """tier-2 form of the bias broadcast: a dist (N,) vector whose
        fragment slabs are NOT warp-local stages through a tiny smem
        buffer (one write, barrier, per-lane scalar reads, barrier)."""
        n = dst.shape[1]
        wn_n = dst.warps[1]
        an = dst.atoms[1]
        wa_n = n // wn_n
        c = self.c_i32
        smem = self._scratch_smem("cvt_bias", n, v.dtype)
        self._stage_tile_smem(v, smem)
        gpu.barrier()
        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        warp = arith.divsi(tid, c(32))
        t = arith.remsi(lane, c(4))
        wx = arith.remsi(warp, c(wn_n))
        vals = []
        for in_ in range(an):
            for jj in range(2):
                col = arith.addi(
                    arith.addi(arith.muli(wx, c(wa_n)), c(in_ * 8 + jj)),
                    arith.muli(t, c(2)))
                vals.append(memref.LoadOp(smem, [self.to_index(col)]).result)
        gpu.barrier()
        return self._frag_c_from_col_vals(v, dst, vals)

    # -- tier-2: smem round-trip ----------------------------------------

    def _stage_tile_smem(self, v: Tensor, smem, *, vl_view: int = 0):
        """The tier-2 round-trip's write side: v's elements into smem in
        logical row-major order. dist: one vector store per row at
        r*cols + tid*ept; flat: one vector store at tid*ept; rep-like:
        every thread scalar-stores every element. vl_view: stores are
        vl-sized chunks at vector-unit indices (dot's LDS.128 read side).
        """
        c = self.c_i32
        lay = v.layout
        cols = v.shape[1] if len(v.shape) == 2 else v.shape[0]
        rows = v.shape[0] if len(v.shape) == 2 else 1
        if is_dist(lay):
            if vl_view:
                per = v.ept // vl_view
                vty = ir.VectorType.get([vl_view], v.dtype.mlir())
                for r in range(rows):
                    row = vector.extract(v.val, [], [r]) \
                        if len(v.shape) == 2 else v.val
                    for j in range(per):
                        # the vector-unit smem view stores vl_view-wide
                        # chunks, so extract a sub-vector, not a scalar
                        chunk = vector.extract_strided_slice(
                            vty, row, [j * vl_view], [vl_view], [1])
                        idx = arith.addi(
                            c(r * (cols // vl_view)),
                            arith.addi(arith.muli(self.tid(), c(per)), c(j)))
                        memref.StoreOp(chunk, smem, [self.to_index(idx)])
            else:
                base = arith.muli(self.tid(), c(v.ept))
                for r in range(rows):
                    idx = arith.addi(c(r * cols), base)
                    row = vector.extract(v.val, [], [r]) \
                        if len(v.shape) == 2 else v.val
                    vector.StoreOp(row, smem, [self.to_index(idx)])
            return
        if is_flat(lay):
            if vl_view:
                vty = ir.VectorType.get([vl_view], v.dtype.mlir())
                for j in range(v.ept // vl_view):
                    # sub-vector chunk matching the vector-unit smem view
                    chunk = vector.extract_strided_slice(
                        vty, v.val, [j * vl_view], [vl_view], [1])
                    idx = arith.addi(
                        arith.muli(self.tid(), c(v.ept // vl_view)), c(j))
                    memref.StoreOp(chunk, smem, [self.to_index(idx)])
            else:
                idx = arith.muli(self.tid(), c(v.ept))
                vector.StoreOp(v.val, smem, [self.to_index(idx)])
            return
        if is_rep_like(lay):
            for r, cc in itertools.product(range(rows), range(cols)):
                val = vector.extract(v.val, [],
                                     [cc] if len(v.shape) == 1 else [r, cc])
                memref.StoreOp(val, smem, [self.c_idx(r * cols + cc)])
            return
        raise TileConfigError(
            f"stage_tile_smem: unsupported layout {lay!r}")

    def _unstage_tile_smem(self, dst: Layout, smem,
                           dtype: tl.DType) -> Tensor:
        """The tier-2 round-trip's read side: dst-layout fragments out of
        a row-major smem image. dist: one vector load per row; flat: one
        vector load; rep-like: per-element scalar loads."""
        ept = vec_ept(dst)
        c = self.c_i32
        cols = dst.shape[1] if len(dst.shape) == 2 else dst.shape[0]
        rows = dst.shape[0] if len(dst.shape) == 2 else 1
        zero = 0.0 if dtype.is_float else 0
        if is_rep_like(dst):
            vty = ir.VectorType.get(
                [rows, cols] if len(dst.shape) == 2 else [cols],
                dtype.mlir())
            res = self.dense_const(vty, dtype, zero)
            for r, cc in itertools.product(range(rows), range(cols)):
                val = memref.LoadOp(smem, [self.c_idx(r * cols + cc)]).result
                res = vector.insert(val, res, [],
                                    [cc] if len(dst.shape) == 1 else [r, cc])
            return Tensor(dtype, dst.shape, dst, res, ept)
        if is_flat(dst):
            vty = ir.VectorType.get([ept], dtype.mlir())
            v = vector.LoadOp(
                vty, smem, [self.to_index(arith.muli(self.tid(), c(ept)))])
            return Tensor(dtype, dst.shape, dst, v, ept)
        # dist
        base = arith.muli(self.tid(), c(ept))
        frags = []
        for r in range(rows):
            vty = ir.VectorType.get([ept], dtype.mlir())
            frags.append(vector.LoadOp(
                vty, smem, [self.to_index(arith.addi(c(r * cols), base))]))
        if len(dst.shape) == 1:
            return Tensor(dtype, dst.shape, dst, frags[0], ept)
        vty = ir.VectorType.get([rows, ept], dtype.mlir())
        res = self.dense_const(vty, dtype, zero)
        for r, v in enumerate(frags):
            res = vector.insert(v, res, [], [r])
        return Tensor(dtype, dst.shape, dst, res, ept)

    def _convert_t2_smem(self, v: Tensor, dst: Layout,
                         scratch=None) -> Tensor:
        """tier-2: smem round-trip for register-layout pairs with no
        tier-1 rule — write src in row-major order, barrier, read dst
        back, barrier (scratch-reuse guard). Fragment destinations only
        support the small bias-vector form (_convert_vec_to_frag_c_smem).
        """
        if isinstance(dst, Fragment):
            from .layout import _is_row_vector
            if dst.role == "C" and _is_row_vector(v.layout, dst.shape[1]):
                return self._convert_vec_to_frag_c_smem(v, dst)
            raise TileConfigError(
                f"convert_layout: no tier-1 rule for {v.layout!r} -> "
                f"{dst!r} and tier-2 cannot materialize fragments")
        nel = 1
        for s in v.shape:
            nel *= s
        smem = scratch if scratch is not None else \
            self._scratch_smem("cvt", nel, v.dtype)
        self._stage_tile_smem(v, smem)
        gpu.barrier()
        out = self._unstage_tile_smem(dst, smem, v.dtype)
        gpu.barrier()
        return out

    # -- small op helpers ---------------------------------------------------------

    def binary(self, op: str, x: ir.Value, y: ir.Value, dtype: tl.DType) -> ir.Value:
        """Elementwise arith on scalars or same-typed vectors."""
        if dtype.is_float:
            fn = {"add": arith.addf, "sub": arith.subf, "mul": arith.mulf,
                  "truediv": arith.divf, "mod": arith.remf,
                  "maximum": arith.maximumf, "minimum": arith.minimumf}[op]
        else:
            fn = {"add": arith.addi, "sub": arith.subi, "mul": arith.muli,
                  "floordiv": arith.divsi, "mod": arith.remsi,
                  "maximum": arith.maxsi, "minimum": arith.minsi}[op]
        return fn(x, y)

    _CMP_I = {"<": arith.CmpIPredicate.slt, "<=": arith.CmpIPredicate.sle,
              ">": arith.CmpIPredicate.sgt, ">=": arith.CmpIPredicate.sge,
              "==": arith.CmpIPredicate.eq, "!=": arith.CmpIPredicate.ne}
    _CMP_F = {"<": arith.CmpFPredicate.OLT, "<=": arith.CmpFPredicate.OLE,
              ">": arith.CmpFPredicate.OGT, ">=": arith.CmpFPredicate.OGE,
              "==": arith.CmpFPredicate.OEQ, "!=": arith.CmpFPredicate.ONE}

    def compare(self, op: str, x: ir.Value, y: ir.Value, dtype: tl.DType) -> ir.Value:
        if dtype.is_float:
            return arith.cmpf(self._CMP_F[op], x, y)
        return arith.cmpi(self._CMP_I[op], x, y)

    def select(self, cond, a, b):
        return arith.select(cond, a, b)

    def _is_constant_val(self, v) -> bool:
        """Is this SSA value produced by an arith.constant op? (Block
        arguments — e.g. loop-carried accumulators — are not, and nvvm
        inline-asm constraints care about the distinction.)"""
        try:
            return v.owner.name == "arith.constant"
        except Exception:
            return False

    def and_i1(self, a, b):        return arith.andi(a, b)

    # -- symbolic mask fragments ---------------------------------------------------

    def _pred_scalar(self, p: Pred, i) -> ir.Value:
        lhs = self.eval_affine(p.affine, i)
        return self.compare(p.op, lhs, self.as_i32(p.bound), tl.int32)

    def _pred_frag(self, p: Pred, base_i32: ir.Value, n: int) -> ir.Value:
        lhs = self.eval_affine_frag(p.affine, base_i32, n)
        vty = ir.VectorType.get([n], self.i32)
        return self.compare(p.op, lhs, self.splat(vty, self.as_i32(p.bound)), tl.int32)

    def mask_frag(self, mask, r, vec: int, col_base: ir.Value):
        """(frag vector<vec x i1>, all-true i1 scalar) for distributed row
        r (a python int — dist rows unroll statically)."""
        if mask is None:
            return None, None
        if isinstance(mask, Tensor):
            if mask.dtype != tl.int1:
                raise TileConfigError("mask block must be i1")
            if is_flat(mask.layout):
                # a flat mask's val IS the whole per-thread fragment
                # (vector<ept x i1> over the raveled run); the flat
                # load/store/atomic arms call with r == 0 / vec == ept.
                # Anything else is a layout mismatch — say so instead of
                # extracting a scalar and crashing the MLIR layer.
                if not (isinstance(r, int) and r == 0) or mask.ept != vec:
                    raise TileConfigError(
                        f"flat-laid-out mask block does not fit this "
                        f"access (mask {mask.layout!r}, ept {mask.ept}; "
                        f"access row {r!r}, vec {vec})")
                frag = mask.val
            elif len(mask.shape) == 1:
                frag = mask.val
            elif isinstance(r, int):
                frag = vector.extract(mask.val, [], [r])
            else:
                # t2/m4 arms use runtime row values — those require a
                # symbolic mask (guarded at their entry points)
                raise TileConfigError(
                    f"materialized mask blocks require statically "
                    f"unrolled rows (dist/flat layouts), got "
                    f"{mask.layout!r}")
            allv = vector.reduction(self.i1, vector.CombiningKind.AND, frag)
            return frag, allv
        assert isinstance(mask, SepMask)
        frag = None
        scalar = None
        for p in mask.row_preds:
            s = self._pred_scalar(p, r)
            scalar = s if scalar is None else self.and_i1(scalar, s)
        for p in mask.col_preds:
            f = self._pred_frag(p, col_base, vec)
            frag = f if frag is None else self.and_i1(frag, f)
        if frag is None:
            frag = self.dense_const(ir.VectorType.get([vec], self.i1), tl.int1, 1)
        if scalar is not None:
            frag = self.and_i1(frag, self.splat(frag.type, scalar))
        allv = vector.reduction(self.i1, vector.CombiningKind.AND, frag)
        return frag, allv

    def _flat_mask(self, mask: SepMask, rho, gamma, fpt: int):
        frag = None
        for p in mask.row_preds:
            s = self._pred_scalar(p, rho)
            vty = ir.VectorType.get([fpt], self.i1)
            frag = self.splat(vty, s) if frag is None else \
                self.and_i1(frag, self.splat(vty, s))
        for p in mask.col_preds:
            f = self._pred_frag(p, gamma, fpt)
            frag = f if frag is None else self.and_i1(frag, f)
        if frag is None:
            frag = self.dense_const(ir.VectorType.get([fpt], self.i1), tl.int1, 1)
        allv = vector.reduction(self.i1, vector.CombiningKind.AND, frag)
        return frag, allv

    # -- global memory access ---------------------------------------------------

    def _stride_addr(self, addr_i32: ir.Value, stride, j: int) -> ir.Value:
        """addr + j*stride where stride may be a python int or i32 value."""
        if j == 0 or (isinstance(stride, int) and stride == 0):
            return addr_i32
        if isinstance(stride, int):
            return arith.addi(addr_i32, self.c_i32(j * stride))
        return arith.addi(addr_i32, arith.muli(self.c_i32(j),
                                               self.as_i32(stride)))

    def _aligned_i1(self, addr_i32: ir.Value, vl: int) -> ir.Value:
        rem = arith.remsi(addr_i32, self.c_i32(vl))
        return arith.cmpi(arith.CmpIPredicate.eq, rem, self.c_i32(0))

    def _vec_chunk_load(self, parg: PtrArg, addr_i32: ir.Value) -> ir.Value:
        """16-byte vector load at element address addr (addr % VL == 0)."""
        idx = arith.divsi(addr_i32, self.c_i32(parg.vl))
        return memref.LoadOp(parg.vec_view, [self.to_index(idx)]).result

    def _vec_chunk_store(self, parg: PtrArg, addr_i32: ir.Value, v: ir.Value):
        idx = arith.divsi(addr_i32, self.c_i32(parg.vl))
        memref.StoreOp(v, parg.vec_view, [self.to_index(idx)])

    def _load_frag(self, parg: PtrArg, addr_i32: ir.Value, col_stride: int,
                   ept: int, mask_frag, mask_all, other: ir.Value) -> ir.Value:
        """Load one ept-element fragment starting at addr_i32."""
        elem = parg.elem
        vty = ir.VectorType.get([ept], elem.mlir())

        def slow_path():
            res = self.dense_const(vty, elem, 0)
            for j in range(ept):
                addr_j = self._stride_addr(addr_i32, col_stride, j)
                if mask_frag is not None:
                    m_j = vector.extract(mask_frag, [], [j])
                    safe = self.select(m_j, addr_j, self.c_i32(0))
                    v = memref.LoadOp(parg.scalar_view, [self.to_index(safe)]).result
                    v = self.select(m_j, v, other)
                else:
                    v = memref.LoadOp(parg.scalar_view, [self.to_index(addr_j)]).result
                res = vector.insert(v, res, [], [j])
            return res

        if ept % parg.vl != 0 or not (isinstance(col_stride, int)
                                      and col_stride == 1):
            # non-unit stride (e.g. a runtime stride from eager-view access)
            # must not take the contiguous vector fast path
            return slow_path()

        cond = self._aligned_i1(addr_i32, parg.vl)
        if mask_all is not None:
            cond = self.and_i1(cond, mask_all)
        if_op = scf.IfOp(cond, [vty], has_else=True)
        with ir.InsertionPoint(_ensure_block(if_op.regions[0])):
            res = self.dense_const(vty, elem, 0)
            for j in range(ept // parg.vl):
                addr_j = addr_i32 if j == 0 else \
                    arith.addi(addr_i32, self.c_i32(j * parg.vl))
                chunk = self._vec_chunk_load(parg, addr_j)
                res = chunk if ept == parg.vl else vector.insert_strided_slice(
                    chunk, res, [j * parg.vl], [1])
            scf.YieldOp([res])
        with ir.InsertionPoint(_ensure_block(if_op.regions[1])):
            scf.YieldOp([slow_path()])
        return if_op.results[0]

    def _store_frag(self, parg: PtrArg, addr_i32: ir.Value, col_stride: int,
                    val: ir.Value, ept: int, mask_frag, mask_all):

        def slow_path():
            for j in range(ept):
                addr_j = self._stride_addr(addr_i32, col_stride, j)
                v_j = vector.extract(val, [], [j])
                if mask_frag is not None:
                    m_j = vector.extract(mask_frag, [], [j])
                    sj = scf.IfOp(m_j, [], has_else=False)
                    with ir.InsertionPoint(_ensure_block(sj.regions[0])):
                        memref.StoreOp(v_j, parg.scalar_view, [self.to_index(addr_j)])
                        scf.YieldOp([])
                else:
                    memref.StoreOp(v_j, parg.scalar_view, [self.to_index(addr_j)])

        if ept % parg.vl != 0 or not (isinstance(col_stride, int)
                                      and col_stride == 1):
            slow_path()
            return
        cond = self._aligned_i1(addr_i32, parg.vl)
        if mask_all is not None:
            cond = self.and_i1(cond, mask_all)
        if_op = scf.IfOp(cond, [], has_else=True)
        with ir.InsertionPoint(_ensure_block(if_op.regions[0])):
            for j in range(ept // parg.vl):
                addr_j = addr_i32 if j == 0 else \
                    arith.addi(addr_i32, self.c_i32(j * parg.vl))
                chunk = val if ept == parg.vl else vector.extract_strided_slice(
                    ir.VectorType.get([parg.vl], parg.elem.mlir()),
                    val, [j * parg.vl], [parg.vl], [1])
                self._vec_chunk_store(parg, addr_j, chunk)
            scf.YieldOp([])
        with ir.InsertionPoint(_ensure_block(if_op.regions[1])):
            slow_path()
            scf.YieldOp([])

    def _other_value(self, elem: tl.DType, other) -> ir.Value:
        if other is None:
            return self.const(elem, 0.0 if elem.is_float else 0)
        if isinstance(other, CExpr):
            v = other.value
            return self.const(elem, float(v) if elem.is_float else int(v))
        if isinstance(other, Scalar):
            return other.val
        raise TileConfigError(
            f"tl.load 'other' must be a scalar constant, got {type(other).__name__}")

    # -- public tile ops ---------------------------------------------------------

    def load(self, pt: PtrTensor, mask=None, other=None, layout=None):
        off = pt.off
        parg = pt.arg
        other_v = self._other_value(parg.elem, other)

        if isinstance(off, MatOff):
            return self._gather_load(parg, off, mask, other_v)

        if layout is not None:
            if isinstance(layout, Blocked) and is_t3(layout):
                return self._load_t3(pt, layout, mask,
                                     other_v if other is not None else None)
            if not isinstance(layout, Fragment):
                raise TileConfigError(
                    f"tl.load LAYOUT supports Fragment destinations and "
                    f"t3 (Blocked) layouts, got {layout!r}")
            if layout.role == "C":
                shp = pt.off.shape
                if tuple(shp) == tuple(layout.shape):
                    if other is not None:
                        raise TileConfigError(
                            "fragment C load zfills masked lanes (other "
                            "must be omitted)")
                    return self._load_frag_c(pt, layout, mask)
                if len(shp) == 2 and shp[1] == 1 \
                        and shp[0] == layout.shape[0]:
                    return self._load_frag_stat(pt, layout, 1, mask,
                                                other_v)
                if len(shp) == 2 and shp[0] == 1 \
                        and shp[1] == layout.shape[1]:
                    return self._load_frag_stat(pt, layout, 0, mask,
                                                other_v)
                raise TileConfigError(
                    f"tl.load LAYOUT=Fragment('C') takes a "
                    f"({layout.shape[0]}, 1) / (1, {layout.shape[1]}) "
                    f"stat pointer tile, got {shp}")
            if other is not None:
                raise TileConfigError(
                    "fragment A load zfills masked rows (other must be "
                    "omitted)")
            return self._load_frag_a(pt, layout, mask)

        if off.shape == ():  # bare pointer / scalar offset
            addr = self.eval_affine(off.col, 0)
            return Scalar(parg.elem,
                          memref.LoadOp(parg.scalar_view, [self.to_index(addr)]).result)

        layout = self.choose_layout(off.shape)
        ept = vec_ept(layout)
        rows, cols = off.shape if len(off.shape) == 2 else (1, off.shape[0])
        stride = off.col.stride

        if is_rep_like(layout):
            vty = ir.VectorType.get([rows, cols] if len(off.shape) == 2 else [cols],
                                    parg.elem.mlir())
            res = self.dense_const(vty, parg.elem, 0)
            for r, c in itertools.product(range(rows), range(cols)):
                addr_j = self.eval_affine(off.col, c)
                if off.row is not None:
                    addr_j = arith.addi(self.eval_affine(off.row, r), addr_j)
                m_j = self._rep_mask_at(mask, r, c)
                if m_j is not None:
                    safe = self.select(m_j, addr_j, self.c_i32(0))
                    v = memref.LoadOp(parg.scalar_view, [self.to_index(safe)]).result
                    v = self.select(m_j, v, other_v)
                else:
                    v = memref.LoadOp(parg.scalar_view, [self.to_index(addr_j)]).result
                res = vector.insert(v, res, [], [c] if len(off.shape) == 1 else [r, c])
            return Tensor(parg.elem, off.shape, layout, res, ept)

        if is_flat(layout):
            base = arith.muli(self.tid(), self.c_i32(ept))
            rho = arith.divsi(base, self.c_i32(cols))
            gamma = arith.remsi(base, self.c_i32(cols))
            addr = arith.addi(self.eval_affine(off.row, rho),
                              self.eval_affine(off.col, gamma))
            if mask is None:
                frag_m, all_m = None, None
            elif isinstance(mask, SepMask):
                frag_m, all_m = self._flat_mask(mask, rho, gamma, ept)
            else:
                frag_m, all_m = self.mask_frag(mask, 0, ept, gamma)
            v = self._load_frag(parg, addr, stride, ept, frag_m, all_m, other_v)
            return Tensor(parg.elem, off.shape, layout, v, ept)

        # dist
        frags = []
        frag_idx = arith.muli(self.tid(), self.c_i32(ept))  # first column index
        col_base = self.eval_affine(off.col, frag_idx)      # its address value
        for r in range(rows):
            addr = col_base
            if off.row is not None:
                addr = arith.addi(self.eval_affine(off.row, r), col_base)
            frag_m, all_m = self.mask_frag(mask, r, ept, frag_idx)
            frags.append(self._load_frag(parg, addr, stride, ept,
                                         frag_m, all_m, other_v))
        if len(off.shape) == 1:
            return Tensor(parg.elem, off.shape, layout, frags[0], ept)
        vty = ir.VectorType.get([rows, ept], parg.elem.mlir())
        res = self.dense_const(vty, parg.elem, 0)
        for r, v in enumerate(frags):
            res = vector.insert(v, res, [], [r])
        return Tensor(parg.elem, off.shape, layout, res, ept)

    def _rep_mask_at(self, mask, r: int, c: int):
        """i1 scalar for element (r, c) of a replicated access, or None."""
        if mask is None:
            return None
        if isinstance(mask, Tensor):
            idx = [c] if len(mask.shape) == 1 else [r, c]
            return vector.extract(mask.val, [], idx)
        out = None
        for p in mask.row_preds:
            s = self._pred_scalar(p, r)
            out = s if out is None else self.and_i1(out, s)
        for p in mask.col_preds:
            s = self._pred_scalar(p, c)
            out = s if out is None else self.and_i1(out, s)
        return out

    def store(self, pt: PtrTensor, value, mask=None, bias_pt=None,
              epi: str | None = None):
        off = pt.off
        parg = pt.arg

        # Layout-dispatched emission: the value's layout picks the store
        # strategy.
        if bias_pt is not None and not (
                isinstance(value, Tensor)
                and (isinstance(value.layout, Fragment)
                     or is_t2(value.layout))):
            raise TileConfigError(
                "tl.store bias is an m4/t2 epilogue feature")
        if epi is not None and not (
                isinstance(value, Tensor)
                and isinstance(value.layout, Fragment)):
            raise TileConfigError(
                "tl.store EPI is an m4-fragment epilogue feature")

        if isinstance(off, MatOff):
            if not isinstance(value, Tensor):
                raise TileConfigError(
                    f"scatter tl.store value must be a block, got "
                    f"{type(value).__name__}")
            if value.shape != off.shape:
                raise TileConfigError(
                    f"tl.store value shape {value.shape} does not match the "
                    f"address tensor shape {off.shape}")
            self._scatter_store(parg, off, value, mask)
            return

        if off.shape == ():
            if isinstance(value, CExpr):
                v = value.value
                value = Scalar(parg.elem, self.const(
                    parg.elem, float(v) if parg.elem.is_float else int(v)))
            if not isinstance(value, Scalar):
                raise TileConfigError(
                    "storing to a scalar pointer requires a scalar value")
            v_s = value.val
            if value.dtype != parg.elem:
                from ..frontend import semantics as _sem
                v_s = _sem._cast(self, v_s, value.dtype, parg.elem)
            addr = self.eval_affine(off.col, 0)
            memref.StoreOp(v_s, parg.scalar_view, [self.to_index(addr)])
            return

        if isinstance(value, Tensor):
            if isinstance(value.layout, Fragment):
                self.store_m4(pt, value, mask=mask, bias_pt=bias_pt,
                              epi=epi)
                return
            if is_t2(value.layout):
                self.store_t2(pt, value, mask=mask, bias_pt=bias_pt)
                return
            if is_t3(value.layout):
                self._store_t3(pt, value, mask=mask)
                return
            if isinstance(value.layout, Sliced) \
                    and isinstance(value.layout.parent, Fragment):
                self._store_frag_stat(pt, value, mask=mask)
                return

        if not isinstance(value, Tensor):
            raise TileConfigError(
                f"tl.store value must be a block, got {type(value).__name__}")
        if value.shape != off.shape:
            raise TileConfigError(
                f"tl.store value shape {value.shape} does not match the "
                f"address tensor shape {off.shape}")
        if value.dtype != parg.elem:
            # same implicit cast as the scalar path above: e.g. an f16
            # block multiplied by a scalar promotes to f32, and storing
            # it back to the f16 pointer truncates lane-wise.
            from ..frontend import semantics as _sem
            value = Tensor(parg.elem, value.shape, value.layout,
                           _sem._cast(self, value.val, value.dtype,
                                      parg.elem), value.ept)
        layout = self.choose_layout(off.shape)
        ept = vec_ept(layout)
        if not store_compatible(value.layout, layout):
            raise TileConfigError(
                f"cannot store a {value.layout!r}-laid-out block through a "
                f"{layout.dump()}-distributed address of shape {off.shape}")
        rows, cols = off.shape if len(off.shape) == 2 else (1, off.shape[0])
        stride = off.col.stride

        if is_rep_like(layout):
            for r, c in itertools.product(range(rows), range(cols)):
                addr_j = self.eval_affine(off.col, c)
                if off.row is not None:
                    addr_j = arith.addi(self.eval_affine(off.row, r), addr_j)
                v_j = vector.extract(value.val, [], [c] if len(off.shape) == 1
                                     else [r, c])
                m_j = self._rep_mask_at(mask, r, c)
                if m_j is not None:
                    sj = scf.IfOp(m_j, [], has_else=False)
                    with ir.InsertionPoint(_ensure_block(sj.regions[0])):
                        memref.StoreOp(v_j, parg.scalar_view, [self.to_index(addr_j)])
                        scf.YieldOp([])
                else:
                    memref.StoreOp(v_j, parg.scalar_view, [self.to_index(addr_j)])
            return

        if is_flat(layout):
            base = arith.muli(self.tid(), self.c_i32(ept))
            rho = arith.divsi(base, self.c_i32(cols))
            gamma = arith.remsi(base, self.c_i32(cols))
            addr = arith.addi(self.eval_affine(off.row, rho),
                              self.eval_affine(off.col, gamma))
            if mask is None:
                frag_m, all_m = None, None
            elif isinstance(mask, SepMask):
                frag_m, all_m = self._flat_mask(mask, rho, gamma, ept)
            else:
                frag_m, all_m = self.mask_frag(mask, 0, ept, gamma)
            self._store_frag(parg, addr, stride, value.val, ept, frag_m, all_m)
            return

        frag_idx = arith.muli(self.tid(), self.c_i32(ept))
        col_base = self.eval_affine(off.col, frag_idx)
        for r in range(rows):
            addr = col_base
            if off.row is not None:
                addr = arith.addi(self.eval_affine(off.row, r), col_base)
            frag_m, all_m = self.mask_frag(mask, r, ept, frag_idx)
            row_v = value.val if len(value.shape) == 1 else \
                vector.extract(value.val, [], [r])
            self._store_frag(parg, addr, stride, row_v, ept, frag_m, all_m)

    # -- atomics (tl.atomic_add for scatter_add / embedding bwd) --------------

    def _tid0(self) -> ir.Value:
        """i1 predicate: this thread is thread 0 of the block."""
        return arith.cmpi(arith.CmpIPredicate.eq, self.tid(), self.c_i32(0))

    def _runtime_f32(self, v: ir.Value) -> ir.Value:
        """Hide a compile-time f32 constant behind runtime arithmetic
        (v + tid*0.0) so nvvm.inline_ptx does not try to bind it to an
        immediate ('n') constraint."""
        tidf = arith.sitofp(self.f32, self.tid())
        zero = arith.mulf(tidf, self.const(tl.float32, 0.0))
        return arith.addf(v, zero)

    def _atomic_base(self, parg: PtrArg) -> ir.Value:
        """Byte address of the buffer base as an `index` value (via the
        aligned pointer of the scalar memref view)."""
        return memref.ExtractAlignedPointerAsIndexOp(parg.scalar_view).result

    def _atomic_add_lane(self, parg: PtrArg, base, addr_i32, v, m_i1):
        """red.global.add.f32 at byte address base + addr_i32*itemsize."""

        def emit():
            off = arith.muli(self.to_index(addr_i32),
                             self.c_idx(parg.elem.itemsize))
            ba = arith.addi(base, off)
            ba64 = arith.index_cast(ir.IntegerType.get_signless(64), ba)
            nvvm.InlinePtxOp([], [ba64, v], [],
                             "red.global.add.f32 [$0], $1;")

        if m_i1 is None:
            emit()
        else:
            sj = scf.IfOp(m_i1, [], has_else=False)
            with ir.InsertionPoint(_ensure_block(sj.regions[0])):
                emit()
                scf.YieldOp([])

    def atomic_add(self, pt: PtrTensor, value, mask=None):
        """tl.atomic_add(ptr_tensor, value, mask=None): per-element
        atomic float add (atom.global/red.global.add.f32). f32 only."""
        off = pt.off
        parg = pt.arg
        if parg.elem != tl.float32:
            raise TileConfigError(
                f"tl.atomic_add currently supports f32 targets only, got {parg.elem}")
        if isinstance(value, Tensor) and value.dtype != tl.float32:
            # block values feed red.global.add.f32 verbatim (scalars are
            # cast instead), so a non-f32 block would only fail deep in
            # LLVM translation — reject it here
            raise TileConfigError(
                "tl.atomic_add currently supports f32 block values only, got "
                f"{value.dtype}")
        if isinstance(off, MatOff):
            if not isinstance(value, Tensor):
                raise TileConfigError(
                    "tl.atomic_add through materialized offsets requires a "
                    f"block value matching the index block's shape, got "
                    f"{type(value).__name__}")
            if value.shape != off.shape:
                raise TileConfigError(
                    f"tl.atomic_add value shape {value.shape} does not match "
                    f"the address tensor shape {off.shape}")
            self._scatter_atomic(parg, off, value, mask)
            return
        if isinstance(value, CExpr):
            v = value.value
            value = Scalar(parg.elem, self._runtime_f32(
                self.const(parg.elem, float(v))))
        if isinstance(value, Scalar):
            from ..frontend import semantics as _sem
            if value.dtype != parg.elem:
                value = Scalar(parg.elem,
                               _sem._cast(self, value.val, value.dtype, parg.elem))
            # a scalar value addresses a single element: a scalar () or
            # single-element block address (e.g. tl.arange(0, 1) * 0) is
            # exact; a multi-element block address would silently add at
            # the column base only — reject that loudly
            if off.shape != () and math.prod(off.shape) > 1:
                raise TileConfigError(
                    "tl.atomic_add with a scalar value requires a scalar "
                    "or single-element address, got address shape "
                    f"{off.shape} (use a block value for a block address)")
            base = self._atomic_base(parg)
            addr = self.eval_affine(off.col, 0)
            # the guard applies to the single accessed element
            m_i1 = self._rep_mask_at(mask, 0, 0)
            # scalar form executes in every thread; atomics must be issued
            # exactly once, so serialize to thread 0.
            one = scf.IfOp(self._tid0(), [], has_else=False)
            with ir.InsertionPoint(_ensure_block(one.regions[0])):
                self._atomic_add_lane(parg, base, addr, value.val, m_i1)
                scf.YieldOp([])
            return
        if not isinstance(value, Tensor):
            raise TileConfigError(
                f"tl.atomic_add value must be a block, got {type(value).__name__}")
        if value.shape != off.shape:
            raise TileConfigError(
                f"tl.atomic_add value shape {value.shape} does not match the "
                f"address tensor shape {off.shape}")
        layout = self.choose_layout(off.shape)
        ept = vec_ept(layout)
        rows, cols = off.shape if len(off.shape) == 2 else (1, off.shape[0])
        stride = off.col.stride
        base = self._atomic_base(parg)

        if is_rep_like(layout):
            # replicated layout: every thread holds all elements — issuing an
            # atomic per thread would add the value num_threads times, so
            # serialize the whole tile to thread 0.
            one = scf.IfOp(self._tid0(), [], has_else=False)
            with ir.InsertionPoint(_ensure_block(one.regions[0])):
                for r, c in itertools.product(range(rows), range(cols)):
                    addr_j = self.eval_affine(off.col, c)
                    if off.row is not None:
                        addr_j = arith.addi(self.eval_affine(off.row, r), addr_j)
                    v_j = vector.extract(value.val, [], [c] if len(off.shape) == 1
                                         else [r, c])
                    m_j = self._rep_mask_at(mask, r, c)
                    self._atomic_add_lane(parg, base, addr_j, v_j, m_j)
                scf.YieldOp([])
            return

        if is_flat(layout):
            tbase = arith.muli(self.tid(), self.c_i32(ept))
            rho = arith.divsi(tbase, self.c_i32(cols))
            gamma = arith.remsi(tbase, self.c_i32(cols))
            addr = arith.addi(self.eval_affine(off.row, rho),
                              self.eval_affine(off.col, gamma))
            if mask is None:
                frag_m = None
            elif isinstance(mask, SepMask):
                frag_m, _ = self._flat_mask(mask, rho, gamma, ept)
            else:
                frag_m, _ = self.mask_frag(mask, 0, ept, gamma)
            for j in range(ept):
                addr_j = self._stride_addr(addr, stride, j)
                v_j = vector.extract(value.val, [], [j])
                m_j = vector.extract(frag_m, [], [j]) if frag_m is not None else None
                self._atomic_add_lane(parg, base, addr_j, v_j, m_j)
            return

        # dist
        frag_idx = arith.muli(self.tid(), self.c_i32(ept))
        col_base = self.eval_affine(off.col, frag_idx)
        for r in range(rows):
            addr = col_base
            if off.row is not None:
                addr = arith.addi(self.eval_affine(off.row, r), col_base)
            frag_m, _ = self.mask_frag(mask, r, ept, frag_idx)
            row_v = value.val if len(value.shape) == 1 else \
                vector.extract(value.val, [], [r])
            for j in range(ept):
                addr_j = self._stride_addr(addr, stride, j)
                v_j = vector.extract(row_v, [], [j])
                m_j = vector.extract(frag_m, [], [j]) if frag_m is not None else None
                self._atomic_add_lane(parg, base, addr_j, v_j, m_j)

    # -- construction ---------------------------------------------------------

    def zeros(self, shape: tuple[int, ...], dtype: tl.DType,
              layout=None) -> Tensor:
        if layout is not None:
            # an explicitly-laid-out zero block (e.g. an accumulator born
            # in its Fragment("C") so the mma acc chain never converts)
            if not isinstance(layout, Layout):
                raise TileConfigError(
                    f"tl.zeros LAYOUT must be a Layout, got {layout!r}")
            shape_ok = tuple(shape) == tuple(layout.shape)
            if not shape_ok and isinstance(layout, Sliced):
                # the narrow (R, 1)/(1, C) statistic form of a sliced
                # parent
                d = layout.dim
                shape_ok = len(shape) == 2 and shape[d] == 1 and \
                    tuple(shape[:d] + shape[d + 1:]) == tuple(layout.shape)
            if not shape_ok:
                raise TileConfigError(
                    f"tl.zeros shape {shape} != layout shape "
                    f"{layout.shape}")
            nreg = layout.regs_per_thread()
            return Tensor(
                dtype, shape, layout,
                self.dense_const(
                    ir.VectorType.get([nreg], dtype.mlir()), dtype,
                    0.0 if dtype.is_float else 0), nreg)
        layout = self.choose_layout(shape)
        ept = vec_ept(layout)
        if is_flat(layout) or is_rep_like(layout) or len(shape) == 1:
            dims = [ept] if not is_rep_like(layout) else list(shape)
        else:
            dims = [shape[0], ept]
        vty = ir.VectorType.get(dims, dtype.mlir())
        return Tensor(dtype, shape, layout,
                      self.dense_const(vty, dtype, 0.0 if dtype.is_float else 0),
                      ept)

    def materialize_offsets(self, off: SepOff) -> Tensor:
        """Turn a symbolic offset tensor into an i32 block value."""
        layout = self.choose_layout(off.shape)
        ept = vec_ept(layout)
        rows, cols = off.shape if len(off.shape) == 2 else (1, off.shape[0])
        if is_rep_like(layout):
            vty = ir.VectorType.get([rows, cols] if len(off.shape) == 2 else [cols],
                                    self.i32)
            res = self.dense_const(vty, tl.int32, 0)
            for r, c in itertools.product(range(rows), range(cols)):
                v = self.eval_affine(off.col, c)
                if off.row is not None:
                    v = arith.addi(self.eval_affine(off.row, r), v)
                res = vector.insert(v, res, [], [c] if len(off.shape) == 1 else [r, c])
            return Tensor(tl.int32, off.shape, layout, res, ept)
        if is_flat(layout):
            base = arith.muli(self.tid(), self.c_i32(ept))
            rho = arith.divsi(base, self.c_i32(cols))
            gamma = arith.remsi(base, self.c_i32(cols))
            addr = arith.addi(self.eval_affine(off.row, rho),
                              self.eval_affine(off.col, gamma))
            vty = ir.VectorType.get([ept], self.i32)
            v = arith.addi(self.splat(vty, addr),
                           self._iota_scaled(ept, off.col.stride))
            return Tensor(tl.int32, off.shape, layout, v, ept)
        col_base = self.eval_affine(off.col, arith.muli(self.tid(), self.c_i32(ept)))
        frags = []
        for r in range(rows):
            addr = col_base
            if off.row is not None:
                addr = arith.addi(self.eval_affine(off.row, r), col_base)
            vty = ir.VectorType.get([ept], self.i32)
            frags.append(arith.addi(self.splat(vty, addr),
                                    self._iota_scaled(ept, off.col.stride)))
        if len(off.shape) == 1:
            return Tensor(tl.int32, off.shape, layout, frags[0], ept)
        vty = ir.VectorType.get([rows, ept], self.i32)
        res = self.dense_const(vty, tl.int32, 0)
        for r, v in enumerate(frags):
            res = vector.insert(v, res, [], [r])
        return Tensor(tl.int32, off.shape, layout, res, ept)

    # -- gather/scatter emission (MatOff materialized indexes) -----------------

    def _mat_layout(self, off: MatOff):
        """(rows, cols, ept, layout) for a materialized offset tensor."""
        mat = off.mat
        if mat.shape != off.shape:
            raise TileConfigError(
                f"materialized offset shape {mat.shape} != address shape "
                f"{off.shape}")
        if not (is_dist(mat.layout) or is_rep_like(mat.layout)):
            raise TileConfigError(
                f"gather/scatter offsets must be dist/rep-laid-out i32 "
                f"blocks, got {mat.layout!r}")
        rows, cols = off.shape if len(off.shape) == 2 else (1, off.shape[0])
        return rows, cols, mat.ept, mat.layout

    def _gather_load(self, parg: PtrArg, off: MatOff, mask, other_v) -> Tensor:
        """tl.load through materialized i32 offsets: per-lane scalar gather
        (no vector fast path — addresses are runtime data, not affine
        functions of the lanes)."""
        rows, cols, ept, layout = self._mat_layout(off)
        mat = off.mat
        elem = parg.elem
        if is_rep_like(layout):
            vty = ir.VectorType.get([rows, cols] if len(off.shape) == 2
                                    else [cols], elem.mlir())
            res = self.dense_const(vty, elem, 0)
            for r, c in itertools.product(range(rows), range(cols)):
                ix = [c] if len(off.shape) == 1 else [r, c]
                addr_j = vector.extract(mat.val, [], ix)
                m_j = self._rep_mask_at(mask, r, c)
                if m_j is not None:
                    safe = self.select(m_j, addr_j, self.c_i32(0))
                    v = memref.LoadOp(parg.scalar_view,
                                      [self.to_index(safe)]).result
                    v = self.select(m_j, v, other_v)
                else:
                    v = memref.LoadOp(parg.scalar_view,
                                      [self.to_index(addr_j)]).result
                res = vector.insert(v, res, [], ix)
            return Tensor(elem, off.shape, layout, res, ept)
        frag_idx = arith.muli(self.tid(), self.c_i32(ept))
        frags = []
        for r in range(rows):
            row_idx = mat.val if len(off.shape) == 1 else \
                vector.extract(mat.val, [], [r])
            frag_m, _ = self.mask_frag(mask, r, ept, frag_idx)
            res = self.dense_const(ir.VectorType.get([ept], elem.mlir()),
                                   elem, 0)
            for j in range(ept):
                addr_j = vector.extract(row_idx, [], [j])
                if frag_m is not None:
                    m_j = vector.extract(frag_m, [], [j])
                    safe = self.select(m_j, addr_j, self.c_i32(0))
                    v = memref.LoadOp(parg.scalar_view,
                                      [self.to_index(safe)]).result
                    v = self.select(m_j, v, other_v)
                else:
                    v = memref.LoadOp(parg.scalar_view,
                                      [self.to_index(addr_j)]).result
                res = vector.insert(v, res, [], [j])
            frags.append(res)
        if len(off.shape) == 1:
            return Tensor(elem, off.shape, layout, frags[0], ept)
        vty = ir.VectorType.get([rows, ept], elem.mlir())
        res = self.dense_const(vty, elem, 0)
        for r, v in enumerate(frags):
            res = vector.insert(v, res, [], [r])
        return Tensor(elem, off.shape, layout, res, ept)

    def _scatter_store(self, parg: PtrArg, off: MatOff, value: Tensor, mask):
        """tl.store through materialized i32 offsets: per-lane scatter."""
        if value.dtype != parg.elem:
            # same implicit cast as the default block-store path: e.g. an
            # f16 block multiplied by a scalar promotes to f32, and
            # storing it back to the f16 pointer truncates lane-wise
            from ..frontend import semantics as _sem
            value = Tensor(parg.elem, value.shape, value.layout,
                           _sem._cast(self, value.val, value.dtype,
                                      parg.elem), value.ept)
        rows, cols, ept, layout = self._mat_layout(off)
        if not store_compatible(value.layout, layout):
            raise TileConfigError(
                f"cannot scatter-store a {value.layout!r}-laid-out value "
                f"through {layout!r}-laid-out offsets")
        mat = off.mat
        if is_rep_like(layout):
            # replicated: every thread stores the same value to the same
            # address — redundant but consistent (no atomics needed)
            for r, c in itertools.product(range(rows), range(cols)):
                ix = [c] if len(off.shape) == 1 else [r, c]
                addr_j = vector.extract(mat.val, [], ix)
                v_j = vector.extract(value.val, [], ix)
                m_j = self._rep_mask_at(mask, r, c)
                if m_j is not None:
                    sj = scf.IfOp(m_j, [], has_else=False)
                    with ir.InsertionPoint(_ensure_block(sj.regions[0])):
                        memref.StoreOp(v_j, parg.scalar_view,
                                       [self.to_index(addr_j)])
                        scf.YieldOp([])
                else:
                    memref.StoreOp(v_j, parg.scalar_view,
                                   [self.to_index(addr_j)])
            return
        frag_idx = arith.muli(self.tid(), self.c_i32(ept))
        for r in range(rows):
            row_idx = mat.val if len(off.shape) == 1 else \
                vector.extract(mat.val, [], [r])
            row_v = value.val if len(value.shape) == 1 else \
                vector.extract(value.val, [], [r])
            frag_m, _ = self.mask_frag(mask, r, ept, frag_idx)
            for j in range(ept):
                addr_j = vector.extract(row_idx, [], [j])
                v_j = vector.extract(row_v, [], [j])
                m_j = vector.extract(frag_m, [], [j]) \
                    if frag_m is not None else None
                if m_j is not None:
                    sj = scf.IfOp(m_j, [], has_else=False)
                    with ir.InsertionPoint(_ensure_block(sj.regions[0])):
                        memref.StoreOp(v_j, parg.scalar_view,
                                       [self.to_index(addr_j)])
                        scf.YieldOp([])
                else:
                    memref.StoreOp(v_j, parg.scalar_view,
                                   [self.to_index(addr_j)])

    def _scatter_atomic(self, parg: PtrArg, off: MatOff, value: Tensor, mask):
        """tl.atomic_add through materialized i32 offsets: per-lane
        red.global.add.f32."""
        rows, cols, ept, layout = self._mat_layout(off)
        if not store_compatible(value.layout, layout):
            raise TileConfigError(
                f"cannot scatter-atomic a {value.layout!r}-laid-out value "
                f"through {layout!r}-laid-out offsets")
        base = self._atomic_base(parg)
        mat = off.mat
        if is_rep_like(layout):
            # replicated: an atomic per thread would add num_threads times
            # too much — serialize the whole tile to thread 0.
            one = scf.IfOp(self._tid0(), [], has_else=False)
            with ir.InsertionPoint(_ensure_block(one.regions[0])):
                for r, c in itertools.product(range(rows), range(cols)):
                    ix = [c] if len(off.shape) == 1 else [r, c]
                    addr_j = vector.extract(mat.val, [], ix)
                    v_j = vector.extract(value.val, [], ix)
                    m_j = self._rep_mask_at(mask, r, c)
                    self._atomic_add_lane(parg, base, addr_j, v_j, m_j)
                scf.YieldOp([])
            return
        frag_idx = arith.muli(self.tid(), self.c_i32(ept))
        for r in range(rows):
            row_idx = mat.val if len(off.shape) == 1 else \
                vector.extract(mat.val, [], [r])
            row_v = value.val if len(value.shape) == 1 else \
                vector.extract(value.val, [], [r])
            frag_m, _ = self.mask_frag(mask, r, ept, frag_idx)
            for j in range(ept):
                addr_j = vector.extract(row_idx, [], [j])
                v_j = vector.extract(row_v, [], [j])
                m_j = vector.extract(frag_m, [], [j]) \
                    if frag_m is not None else None
                self._atomic_add_lane(parg, base, addr_j, v_j, m_j)

    # -- math ------------------------------------------------------------------

    def _unary_ptx_f32(self, x, instr: str, scale: float | None = None):
        """Per-lane f32 PTX instruction on an f32 scalar/block.

        Sub-f32 float (f16/bf16) inputs are extended to f32, run through
        the f32 instruction (the approx PTX ops are f32-only) and the
        result truncated back — dtype-preserving, per-lane f32 accuracy
        (the same discipline as reduce_row_kernel's CALC_F32)."""
        if isinstance(x, (Scalar, Tensor)) and x.dtype.is_float \
                and x.dtype.itemsize < 4:
            from ..frontend import semantics as _sem
            r = self._unary_ptx_f32(_sem.cast(self, x, tl.float32),
                                    instr, scale)
            return _sem.cast(self, r, x.dtype)
        k = self.const(tl.float32, scale) if scale is not None else None

        def f(v):
            if k is not None:
                v = arith.mulf(v, k)
            return nvvm.InlinePtxOp([self.f32], [v], [], instr).results[0]

        if isinstance(x, Scalar):
            if x.dtype != tl.float32:
                raise TileConfigError(f"ptx math expects f32, got {x!r}")
            return Scalar(tl.float32, f(x.val))
        if not isinstance(x, Tensor) or x.dtype != tl.float32:
            raise TileConfigError(f"ptx math expects an f32 block, got {x!r}")
        shape = x.val.type.shape
        res = self.dense_const(x.val.type, tl.float32, 0.0)
        for idx in itertools.product(*[range(s) for s in shape]):
            lane = vector.extract(x.val, [], list(idx))
            res = vector.insert(f(lane), res, [], list(idx))
        return Tensor(tl.float32, x.shape, x.layout, res, x.ept)

    def sin(self, x):
        """sin(x) for f32 scalars/blocks via sin.approx (per-lane)."""
        return self._unary_ptx_f32(x, "sin.approx.f32 $0, $1;")

    def cos(self, x):
        """cos(x) for f32 scalars/blocks via cos.approx (per-lane)."""
        return self._unary_ptx_f32(x, "cos.approx.f32 $0, $1;")

    def exp(self, x):
        """exp(x) for f32 scalars/blocks via ex2.approx (per-lane).
        Sub-f32 floats extend to f32 and truncate back (see
        _unary_ptx_f32) — on both the approx and the precise path.
        MT_PRECISE_MATH (opt-in): Cody-Waite reduction + Cephes minimax
        polynomial + exact 2^k scaling (~1 ulp)."""
        if isinstance(x, (Scalar, Tensor)) and x.dtype.is_float \
                and x.dtype.itemsize < 4:
            from ..frontend import semantics as _sem
            return _sem.cast(self, self.exp(_sem.cast(self, x, tl.float32)),
                             x.dtype)
        if _PRECISE_MATH:
            return self._exp_precise(x)
        return self._unary_ptx_f32(x, "ex2.approx.f32 $0, $1;",
                                   scale=1.4426950408889634)

    def _exp_precise_lane(self, v):
        """One f32 lane of the precise exp (Cephes expf algorithm)."""
        # clamp: masked lanes may carry -inf; exp(-87.3) ~ 1e-38 ~ 0 and
        # exp(88.72) ~ 3.4e38 stay inside f32 range
        v = arith.maximumf(v, self.const(tl.float32, -87.3))
        v = arith.minimumf(v, self.const(tl.float32, 88.72))
        y = arith.mulf(v, self.const(tl.float32, 1.4426950408889634))
        kf = nvvm.InlinePtxOp([self.f32], [y], [],
                              "cvt.rni.f32.f32 $0, $1;").results[0]
        # r = v - k*ln2 (Cody-Waite: ln2 split into hi + lo, k*hi exact)
        r = arith.subf(arith.subf(v, arith.mulf(kf, self.const(
            tl.float32, 0.693359375))),
            arith.mulf(kf, self.const(tl.float32, -2.1219444005469058e-4)))
        # Cephes expf minimax on r in [-0.3466, 0.3466]
        p = self.const(tl.float32, 1.9875691500e-4)
        for c in (1.3981999507e-3, 8.3334519073e-3, 4.1665795894e-2,
                  1.6666665459e-1, 5.0000001201e-1):
            p = arith.addf(arith.mulf(p, r), self.const(tl.float32, c))
        z = arith.mulf(r, r)
        p = arith.addf(arith.addf(arith.mulf(p, z), r),
                       self.const(tl.float32, 1.0))
        # exact 2^k via exponent bits (k in [-126, 127] after clamping)
        ki = arith.fptosi(self.i32, kf)
        bits = arith.shli(arith.addi(ki, self.c_i32(127)), self.c_i32(23))
        return arith.mulf(p, arith.bitcast(self.f32, bits))

    def _exp_precise(self, x):
        if isinstance(x, Scalar):
            if x.dtype != tl.float32:
                raise TileConfigError(f"tl.exp expects f32, got {x!r}")
            return Scalar(tl.float32, self._exp_precise_lane(x.val))
        if not isinstance(x, Tensor) or x.dtype != tl.float32:
            raise TileConfigError(f"tl.exp expects an f32 block, got {x!r}")
        shape = x.val.type.shape
        res = self.dense_const(x.val.type, tl.float32, 0.0)
        for idx in itertools.product(*[range(s) for s in shape]):
            lane = vector.extract(x.val, [], list(idx))
            res = vector.insert(self._exp_precise_lane(lane), res, [],
                                list(idx))
        return Tensor(tl.float32, x.shape, x.layout, res, x.ept)

    def log(self, x):
        """natural log(x) for f32 scalars/blocks via lg2.approx (per-lane).
        Sub-f32 floats extend to f32 and truncate back (see
        _unary_ptx_f32)."""
        if isinstance(x, (Scalar, Tensor)) and x.dtype.is_float \
                and x.dtype.itemsize < 4:
            from ..frontend import semantics as _sem
            return _sem.cast(self, self.log(_sem.cast(self, x, tl.float32)),
                             x.dtype)
        ln2 = 0.6931471805599453

        def f(v):
            r = nvvm.InlinePtxOp([self.f32], [v], [],
                                 "lg2.approx.f32 $0, $1;").results[0]
            return arith.mulf(r, self.const(tl.float32, ln2))

        if isinstance(x, Scalar):
            if x.dtype != tl.float32:
                raise TileConfigError(f"tl.log expects f32, got {x!r}")
            return Scalar(tl.float32, f(x.val))
        if not isinstance(x, Tensor) or x.dtype != tl.float32:
            raise TileConfigError(f"tl.log expects an f32 block, got {x!r}")
        shape = x.val.type.shape
        res = self.dense_const(x.val.type, tl.float32, 0.0)
        for idx in itertools.product(*[range(s) for s in shape]):
            lane = vector.extract(x.val, [], list(idx))
            res = vector.insert(f(lane), res, [], list(idx))
        return Tensor(tl.float32, x.shape, x.layout, res, x.ept)

    def sqrt(self, x):
        """sqrt(x) for f32 scalars/blocks via sqrt.approx (per-lane).
        MT_PRECISE_MATH (opt-in): IEEE correctly-rounded sqrt.rn."""
        if _PRECISE_MATH:
            return self._unary_ptx_f32(x, "sqrt.rn.f32 $0, $1;")
        return self._unary_ptx_f32(x, "sqrt.approx.f32 $0, $1;")

    # -- reductions ---------------------------------------------------------------

    def _reduce_neutral(self, op: str, dtype: tl.DType):
        if op == "sum":
            return 0.0 if dtype.is_float else 0
        if op == "max":
            return float("-inf") if dtype.is_float else tl.SIGNED_INT_MIN[dtype.name]
        if op == "min":
            return float("inf") if dtype.is_float else tl.SIGNED_INT_MAX[dtype.name]
        raise TileConfigError(f"unsupported tl.reduce op: {op!r} (want sum/max/min)")

    def _reduce_kind(self, op: str, dtype: tl.DType):
        k = vector.CombiningKind
        if op == "sum":
            return k.ADD
        if op == "max":
            return k.MAXIMUMF if dtype.is_float else k.MAXSI
        if op == "min":
            return k.MINIMUMF if dtype.is_float else k.MINSI
        raise TileConfigError(f"unsupported tl.reduce op: {op!r} (want sum/max/min)")

    def _combine(self, op: str, dtype: tl.DType, a, b):
        if op == "sum":
            return arith.addf(a, b) if dtype.is_float else arith.addi(a, b)
        if op == "max":
            return arith.maximumf(a, b) if dtype.is_float else arith.maxsi(a, b)
        return arith.minimumf(a, b) if dtype.is_float else arith.minsi(a, b)

    def reduce(self, x: Tensor, op: str) -> Scalar:
        if not isinstance(x, Tensor) or len(x.shape) != 1 \
                or not is_dist(x.layout):
            raise TileConfigError(
                "tl.reduce currently supports 1D distributed blocks only "
                f"(got {x!r}); use axis=None/0 over a 1D block")
        if x.dtype.is_float and x.dtype.itemsize < 4:
            # sub-f32 float block: the warp butterfly's nvvm.shfl.sync
            # only takes 32-bit operands (and 16-bit accumulation would
            # be meaningless) — reduce in f32 and cast the scalar result
            # back (dtype-preserving; the compiler-level form of
            # reduce_row_kernel's CALC_F32 discipline)
            from ..frontend import semantics as _sem
            r = self.reduce(_sem.cast(self, x, tl.float32), op)
            return Scalar(x.dtype,
                          _sem._cast(self, r.val, tl.float32, x.dtype))
        if op == "sum" and x.dtype == tl.float32:
            if _ROW_FP64:
                return self._reduce_sum_compensated(x)
        kind = self._reduce_kind(op, x.dtype)
        init = self.const(x.dtype, self._reduce_neutral(op, x.dtype))
        v = vector.reduction(x.dtype.mlir(), kind, x.val, acc=init)
        # warp butterfly
        for off in (16, 8, 4, 2, 1):
            sh = gpu.shuffle(v, self.c_i32(off), self.c_i32(32),
                             gpu.ShuffleMode.XOR)
            shuffled = sh.results[0] if hasattr(sh, "results") else sh[0]
            v = self._combine(op, x.dtype, v, shuffled)
        num_warps = self.num_threads // 32
        if num_warps > 1:
            smem = self._scratch_smem("reduce", num_warps, x.dtype)
            lane = arith.remsi(self.tid(), self.c_i32(32))
            warp = arith.divsi(self.tid(), self.c_i32(32))
            is_lane0 = arith.cmpi(arith.CmpIPredicate.eq, lane, self.c_i32(0))
            if_op = scf.IfOp(is_lane0, [], has_else=False)
            with ir.InsertionPoint(_ensure_block(if_op.regions[0])):
                memref.StoreOp(v, smem, [self.to_index(warp)])
                scf.YieldOp([])
            gpu.barrier()
            v = memref.LoadOp(smem, [self.c_idx(0)]).result
            for w in range(1, num_warps):
                wv = memref.LoadOp(smem, [self.c_idx(w)]).result
                v = self._combine(op, x.dtype, v, wv)
            # the scratch buffer is shared by all reduces in this kernel;
            # make sure every warp has finished reading before the next
            # reduce overwrites it
            gpu.barrier()
        return Scalar(x.dtype, v)

    def _twosum_f32(self, a, b):
        """Error-free TwoSum on f32 SSA values: s + err == a + b exactly."""
        s = arith.addf(a, b)
        z = arith.subf(s, a)
        err = arith.addf(arith.subf(a, arith.subf(s, z)), arith.subf(b, z))
        return s, err

    def _reduce_sum_compensated(self, x: Tensor) -> Scalar:
        """TwoSum-compensated sum of a 1D distributed f32 block (opt-in,
        MT_ROW_FP64): Builder.reduce's butterfly/smem shape carrying a
        (hi, lo) compensation term (~2*eps, fp64-accumulator class)."""
        hi = self.const(tl.float32, 0.0)
        lo = self.const(tl.float32, 0.0)
        # intra-thread: sequential TwoSum over the per-thread lanes
        for i in range(x.ept):
            lane = vector.extract(x.val, [], [i])
            hi, err = self._twosum_f32(hi, lane)
            lo = arith.addf(lo, err)
        # warp butterfly on (hi, lo)
        for off in (16, 8, 4, 2, 1):
            sh_hi = gpu.shuffle(hi, self.c_i32(off), self.c_i32(32),
                                gpu.ShuffleMode.XOR)
            sh_hi = sh_hi.results[0] if hasattr(sh_hi, "results") else sh_hi[0]
            sh_lo = gpu.shuffle(lo, self.c_i32(off), self.c_i32(32),
                                gpu.ShuffleMode.XOR)
            sh_lo = sh_lo.results[0] if hasattr(sh_lo, "results") else sh_lo[0]
            hi, err = self._twosum_f32(hi, sh_hi)
            lo = arith.addf(lo, arith.addf(sh_lo, err))
        num_warps = self.num_threads // 32
        if num_warps > 1:
            smem_hi = self._scratch_smem("reduce_hp", num_warps, tl.float32)
            smem_lo = self._scratch_smem("reduce_hp_lo", num_warps,
                                         tl.float32)
            lane = arith.remsi(self.tid(), self.c_i32(32))
            warp = arith.divsi(self.tid(), self.c_i32(32))
            is_lane0 = arith.cmpi(arith.CmpIPredicate.eq, lane, self.c_i32(0))
            if_op = scf.IfOp(is_lane0, [], has_else=False)
            with ir.InsertionPoint(_ensure_block(if_op.regions[0])):
                memref.StoreOp(hi, smem_hi, [self.to_index(warp)])
                memref.StoreOp(lo, smem_lo, [self.to_index(warp)])
                scf.YieldOp([])
            gpu.barrier()
            hi = memref.LoadOp(smem_hi, [self.c_idx(0)]).result
            lo = memref.LoadOp(smem_lo, [self.c_idx(0)]).result
            for w in range(1, num_warps):
                hw = memref.LoadOp(smem_hi, [self.c_idx(w)]).result
                lw = memref.LoadOp(smem_lo, [self.c_idx(w)]).result
                hi, err = self._twosum_f32(hi, hw)
                lo = arith.addf(lo, arith.addf(lw, err))
            # shared scratch: all warps must be done reading before the
            # next compensated reduce overwrites it
            gpu.barrier()
        return Scalar(tl.float32, arith.addf(hi, lo))

    def _reduce_t3(self, x: Tensor, op: str) -> Tensor:
        """Row-wise reduce of a row-per-thread (t3) tile: register-local
        (one vector.reduction per thread, no shuffles/smem). Result: the
        t3 (R, 1) row statistic."""
        kind = self._reduce_kind(op, x.dtype)
        tm = x.layout.size_per_thread[0]
        if tm != 1:
            raise TileConfigError("t3 reduce currently supports tm == 1 rows")
        s = vector.reduction(x.dtype.mlir(), kind, x.val)
        out = self.dense_const(
            ir.VectorType.get([1], x.dtype.mlir()), x.dtype, 0)
        out = vector.insert(s, out, [], [0])
        out_lay = Blocked((x.shape[0], 1), (1, 1),
                          (self.num_threads, 1), (1, 0))
        return Tensor(x.dtype, (x.shape[0], 1), out_lay, out, 1)

    def _shfl_bfly4(self, v, off):
        """width-4 segmented shfl.sync.bfly (CUDA __shfl_xor_sync width=4):
        the t-quad reduction step of the warp-local online softmax;
        gpu.shuffle only covers lanes 0-3, hence inline PTX."""
        seg = ((32 - 4) << 8) | 0x1f
        return nvvm.InlinePtxOp(
            [self.f32], [v, self.c_i32(off)], [],
            f"shfl.sync.bfly.b32 $0, $1, $2, {seg}, -1;").results[0]

    def _reduce_frag(self, x: Tensor, op: str) -> Tensor:
        """Row-wise reduce of an mma C fragment (warp-local): intra-lane
        partial over the fragment's columns, then the width-4 t-quad
        butterfly. Result: the Sliced(Fragment, 1) per-row statistic
        (atoms_m*2 values per lane)."""
        if op not in ("sum", "max"):
            raise TileConfigError(f"fragment row reduce currently supports "
                                  f"sum/max, got {op!r}")
        frag = x.layout
        (wn_m, wn_n), (am, an) = frag.warps, frag.atoms
        if wn_n != 1:
            raise TileConfigError(
                "fragment row reduce wants the warp-slab (warps, 1) grid")
        combine = arith.maximumf if op == "max" else arith.addf
        vals = []
        for im in range(am):
            for half in range(2):
                acc = None
                for in_ in range(an):
                    for jj in range(2):
                        v_ = vector.extract(
                            x.val, [], [(im * an + in_) * 4 + half * 2 + jj])
                        acc = v_ if acc is None else combine(acc, v_)
                acc = combine(acc, self._shfl_bfly4(acc, 1))
                acc = combine(acc, self._shfl_bfly4(acc, 2))
                vals.append(acc)
        out = self.dense_const(
            ir.VectorType.get([am * 2], x.dtype.mlir()), x.dtype, 0)
        for r, v in enumerate(vals):
            out = vector.insert(v, out, [], [r])
        lay = Sliced(frag, 1)
        return Tensor(x.dtype, (frag.shape[0], 1), lay, out, am * 2)

    def reduce_axis1(self, x: Tensor, op: str) -> Tensor:
        """Row-wise reduce of a 2D distributed block: (R, C) dist -> (R, 1)
        column tensor laid out Sliced(dist, dim=1) (replicated across the
        column threads, broadcasts back against (R, C) dist blocks).
        Routing: t3 tiles reduce register-locally; mma C fragments
        warp-locally (intra-lane partial + width-4 butterfly)."""
        if isinstance(x, Tensor) and isinstance(x.layout, Blocked) \
                and is_t3(x.layout):
            return self._reduce_t3(x, op)
        if isinstance(x, Tensor) and isinstance(x.layout, Fragment) \
                and x.layout.role == "C":
            return self._reduce_frag(x, op)
        if not isinstance(x, Tensor) or len(x.shape) != 2 \
                or not is_dist(x.layout):
            raise TileConfigError(
                f"tl.{op}(axis=1) expects a 2D distributed block, got {x!r}")
        rows, _ = x.shape
        kind = self._reduce_kind(op, x.dtype)
        vty_r = ir.VectorType.get([rows], x.dtype.mlir())
        neutral = self.const(x.dtype, self._reduce_neutral(op, x.dtype))
        init = self.splat(vty_r, neutral)
        # per-row intra-thread reduce (vector.multi_reduction is not
        # lowered by this pipeline; per-row vector.reduction is)
        v = self.dense_const(vty_r, x.dtype, 0.0 if x.dtype.is_float else 0)
        for r in range(rows):
            row = vector.extract(x.val, [], [r])
            s = vector.reduction(x.dtype.mlir(), kind, row, acc=neutral)
            v = vector.insert(s, v, [], [r])
        # warp butterfly for all rows at once (per-row scalar shuffles)
        for off in (16, 8, 4, 2, 1):
            nxt = self.dense_const(vty_r, x.dtype,
                                   0.0 if x.dtype.is_float else 0)
            for r in range(rows):
                lane = vector.extract(v, [], [r])
                sh = gpu.shuffle(lane, self.c_i32(off), self.c_i32(32),
                                 gpu.ShuffleMode.XOR)
                shuffled = sh.results[0] if hasattr(sh, "results") else sh[0]
                nxt = vector.insert(
                    self._combine(op, x.dtype, lane, shuffled), nxt, [], [r])
            v = nxt
        num_warps = self.num_threads // 32
        if num_warps > 1:
            smem = self._scratch_smem("reduce_rows", num_warps * rows, x.dtype)
            lane = arith.remsi(self.tid(), self.c_i32(32))
            warp = arith.divsi(self.tid(), self.c_i32(32))
            is_lane0 = arith.cmpi(arith.CmpIPredicate.eq, lane, self.c_i32(0))
            if_op = scf.IfOp(is_lane0, [], has_else=False)
            with ir.InsertionPoint(_ensure_block(if_op.regions[0])):
                for r in range(rows):
                    lane_r = vector.extract(v, [], [r])
                    idx = arith.addi(arith.muli(warp, self.c_i32(rows)),
                                     self.c_i32(r))
                    memref.StoreOp(lane_r, smem, [self.to_index(idx)])
                scf.YieldOp([])
            gpu.barrier()
            res = self.dense_const(vty_r, x.dtype,
                                   0.0 if x.dtype.is_float else 0)
            for r in range(rows):
                wv = memref.LoadOp(smem, [self.c_idx(r)]).result
                for w in range(1, num_warps):
                    w2 = memref.LoadOp(smem,
                                       [self.c_idx(w * rows + r)]).result
                    wv = self._combine(op, x.dtype, wv, w2)
                res = vector.insert(wv, res, [], [r])
            # scratch reuse guard (same reason as Builder.reduce)
            gpu.barrier()
            v = res
        vty = ir.VectorType.get([rows, 1], x.dtype.mlir())
        return Tensor(x.dtype, (rows, 1), Sliced(x.layout, 1),
                      vector.shape_cast(vty, v), rows)

    def _smem_global(self, key, mty: ir.Type, nbytes: int):
        """A static .shared buffer: memref.global in the gpu.module +
        memref.get_global at the use point (memref.alloc in workgroup
        space falls back to a malloc under convert-gpu-to-nvvm)."""
        if key in self._smem:
            return self._smem[key]
        self._smem_bytes = getattr(self, "_smem_bytes", 0) + nbytes
        if self._smem_bytes > 48 * 1024:
            raise TileConfigError(
                f"shared memory budget exceeded: {self._smem_bytes} bytes "
                f"> 48KB static limit; shrink tile sizes")
        # the symbol name must be unique per key (same-role buffers with
        # different sizes/dtypes collide on the bare role name, e.g. two
        # tl.dots whose a operands are (64,64) and (1,64))
        names = getattr(self, "_smem_names", None)
        if names is None:
            names = self._smem_names = set()
        name = f"smem_{key[0]}"
        suffix = 0
        while name in names:
            suffix += 1
            name = f"smem_{key[0]}_{suffix}"
        names.add(name)
        gmod = self.module.body.operations[0]
        # pin every static smem global to 16B: ptxas packs globals in
        # declaration order and a later scratch buffer could push the
        # staging buffers off 16B (cp.async/ldmatrix fault).
        with ir.InsertionPoint.at_block_begin(gmod.regions[0].blocks[0]):
            memref.GlobalOp(name, mty, alignment=16)
        with ir.InsertionPoint.at_block_begin(self.entry):
            buf = memref.GetGlobalOp(mty, ir.FlatSymbolRefAttr.get(name)).result
        self._smem[key] = buf
        roles = getattr(self, "_smem_roles", None)
        if roles is None:
            roles = self._smem_roles = {}
        roles[buf] = name
        return buf

    # -- W-IR annotation surface (opt-in MINITRITON_WIR_ANNOTATE) --------
    # Emits exact per-thread offset forms (affine + const div/mod + const
    # bitwise swizzles) as wir.off/wir.sh/wir.vl attributes on smem
    # accesses. Zero cost when off; inexpressible paths stay unannotated.

    def _wir_annotate_on(self) -> bool:
        on = getattr(self, "_wir_anno", None)
        if on is None:
            import os
            on = os.environ.get("MINITRITON_WIR_ANNOTATE", "0") == "1"
            self._wir_anno = on
            if on:
                self._wf_lid = 0
                self.entry.owner.attributes["wir.nt"] = \
                    ir.IntegerAttr.get(
                        ir.IntegerType.get_signless(64), self.num_threads)
        return on

    def _wir_attr(self, op, role, form, vl):
        """Attach the W-IR smem-access annotation to one op (no-op unless
        MINITRITON_WIR_ANNOTATE=1). Accepts an OpView or an OpResult
        (async copies hand back their token)."""
        if not self._wir_annotate_on():
            return
        from .wir import dump_form
        own = op.operation if hasattr(op, "operation") else op.owner
        at = own.attributes
        at["wir.sh"] = ir.StringAttr.get(role)
        at["wir.off"] = ir.StringAttr.get(dump_form(form))
        at["wir.vl"] = ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), int(vl))

    def _wir_smem_role(self, smem) -> str:
        """The dependence-class name of a scratch smem buffer (its global
        symbol, recorded by _smem_global)."""
        return getattr(self, "_smem_roles", {}).get(smem, "smem")

    def _wir_mark_loop(self, for_op):
        """Assign a loop-iv form id (wir.lid) for annotations inside a
        loop body; returns the ("iv", lid) form (None when off)."""
        if not self._wir_annotate_on():
            return None
        lid = self._wf_lid
        self._wf_lid += 1
        at = for_op.operation.attributes
        at["wir.lid"] = ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), lid)
        at["wir.nw"] = ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), self.num_threads // 32)
        return ("iv", lid)


    def _scratch_smem(self, role: str, n: int, dtype: tl.DType):
        mty = ir.MemRefType.get([n], dtype.mlir(),
                                memory_space=_workgroup_space())
        return self._smem_global((role, n, dtype.name), mty,
                                 n * dtype.itemsize)

    def _scratch_smem_vec(self, role: str, nvec: int, dtype: tl.DType, vl: int):
        mty = ir.MemRefType.get(
            [nvec], ir.VectorType.get([vl], dtype.mlir()),
            memory_space=_workgroup_space())
        return self._smem_global((role, nvec, f"vector<{vl}x{dtype.name}>"),
                                 mty, nvec * vl * dtype.itemsize)

    # -- dynamic smem (>48KB): llvm extern global for the base, --------------
    #    inline PTX for all accesses — no memref view of the region -----------

    def _dyn_smem_i32(self):
        """Base byte address (i32, shared window) of the dynamic shared
        memory region — the CUDA ``extern __shared__`` equivalent. The
        region size is supplied at launch; the builder only accounts the
        byte count (dyn_smem_bytes)."""
        base = getattr(self, "_dyn_base", None)
        if base is None:
            gmod = self.module.body.operations[0]
            with ir.InsertionPoint.at_block_begin(gmod.regions[0].blocks[0]):
                llvm.mlir_global(
                    ir.Type.parse("!llvm.array<0 x i8>"), "__mt_dyn_smem",
                    linkage=ir.Attribute.parse("#llvm.linkage<external>"),
                    addr_space=3, alignment=16)
            with ir.InsertionPoint.at_block_begin(self.entry):
                p = llvm.mlir_addressof(ir.Type.parse("!llvm.ptr<3>"),
                                        "__mt_dyn_smem")
                base = self._dyn_base = llvm.ptrtoint(self.i32, p)
        return base

    def _dyn_smem_reserve(self, nbytes: int) -> None:
        self._dyn_smem_bytes = max(getattr(self, "_dyn_smem_bytes", 0),
                                   nbytes)

    @property
    def dyn_smem_bytes(self) -> int:
        """Dynamic smem bytes the launcher must supply (0 = static only)."""
        return getattr(self, "_dyn_smem_bytes", 0)

    @property
    def static_smem_bytes(self) -> int:
        """Static .shared bytes (the memref.global scratch buffers); the
        launcher needs it for the static+dynamic 48KB opt-in threshold."""
        return getattr(self, "_smem_bytes", 0)

    def _glob_base_i64(self, parg: PtrArg):
        """Raw global base byte address (i64) of a pointer argument — the
        cp.async source operand form ([l64]) when no memref view is used."""
        if getattr(self, "_i64_ty", None) is None:
            self._i64_ty = ir.IntegerType.get_signless(64)
        idx = memref.ExtractAlignedPointerAsIndexOp(parg.scalar_view).result
        return arith.index_cast(self._i64_ty, idx)

    def _cp_async16_dyn(self, dst_i32, src_i64):
        """One 16B cp.async into the dynamic smem region (raw i32 shared
        dst, generic i64 src). Groups are hardware state, so no token
        plumbing is needed."""
        nvvm.InlinePtxOp([], [dst_i32, src_i64], [],
                         "cp.async.cg.shared.global [$0], [$1], 16;")

    def _cp_async_commit_dyn(self):
        nvvm.InlinePtxOp([], [], [], "cp.async.commit_group;")

    def _cp_async_wait_dyn(self, num_groups: int):
        nvvm.InlinePtxOp([], [], [],
                         f"cp.async.wait_group {num_groups};")

    # -- dot ---------------------------------------------------------------------

    def _mma_f2f_ldg(self, parg: PtrArg, addr_i32: ir.Value) -> ir.Value:
        """One 16B global vector load for the f2f staging path (alignment
        proven by the vec-path config, no runtime guard)."""
        idx = arith.divsi(addr_i32, self.c_i32(parg.vl))
        return memref.LoadOp(parg.vec_view, [self.to_index(idx)]).result

    def _mma_f2f_sts(self, smem, addr_elems, esz: int, vec: ir.Value):
        """One 16B st.shared.v4 of a staged vector (raw shared-window
        byte address, same form as the ldmatrix addressing)."""
        addr_i32 = self._mma_smem_i32(smem, addr_elems, esz)
        v4i = ir.VectorType.get([4], self.i32)
        words = vector.bitcast(v4i, vec)
        r = [vector.extract(words, [], [j]) for j in range(4)]
        nvvm.InlinePtxOp([], [addr_i32] + r, [],
                         "st.shared.v4.b32 [$0], {$1,$2,$3,$4};")

    def _mma_f2f_slots(self, pre, parg, k_adv, smem, stage_elems,
                       esz: int, do_store: bool):
        """f2f staging for one operand: LDG.128 per precomputed slot into
        fresh SSA vectors (do_store=False -> the register tile) or one
        LDG+STS pair per slot (prologue fill)."""
        vecs = []
        for src, dst in pre:
            v = self._mma_f2f_ldg(parg, arith.addi(src, k_adv))
            if do_store:
                self._mma_f2f_sts(smem, arith.addi(stage_elems, dst),
                                  esz, v)
            vecs.append(v)
        return vecs

    def _mma_f2f_regs_sts(self, pre, regs, smem, stage_elems, esz: int):
        """Store the loop-carried register tile into its smem slot."""
        for (src, dst), v in zip(pre, regs):
            self._mma_f2f_sts(smem, arith.addi(stage_elems, dst), esz, v)

    def _mma_f2f_regs_ldg(self, pre, parg, k_adv):
        """Refill the register tile from the next K tile."""
        return [self._mma_f2f_ldg(parg, arith.addi(src, k_adv))
                for src, dst in pre]

    def dot(self, a: Tensor, b: Tensor, acc: Tensor | None = None) -> Tensor:
        if a.dtype != tl.float32 or b.dtype != tl.float32:
            raise TileConfigError("tl.dot currently supports f32 operands only")
        if len(a.shape) != 2 or len(b.shape) != 2:
            raise TileConfigError("tl.dot operands must be 2D blocks")
        bm, bk = a.shape
        bk2, bn = b.shape
        if bk != bk2:
            raise TileConfigError(
                f"tl.dot inner-dim mismatch: {a.shape} vs {b.shape}")
        nt = self.num_threads
        if bn % nt != 0:
            raise TileConfigError(
                f"tl.dot needs BN % num_threads == 0 (got BN={bn}, "
                f"num_threads={nt}) for the accumulator layout")
        vec_n = bn // nt
        if bm * vec_n > 128:
            raise TileConfigError(
                f"tl.dot accumulator too large: BM*VEC_N = {bm * vec_n} > 128 "
                f"registers per thread; shrink BM or BN")
        if acc is None:
            acc = self.zeros((bm, bn), tl.float32)
        if acc.shape != (bm, bn) or not is_dist(acc.layout):
            raise TileConfigError(
                f"tl.dot acc must be a distributed ({bm}, {bn}) block, got {acc!r}")

        vl = 4  # f32 16-byte lanes
        smem_a = self._scratch_smem("dot_a", bm * bk, tl.float32)
        use_bvec = (vec_n % vl == 0) and (not is_flat(b.layout)
                                          or b.ept % vl == 0)
        if use_bvec:
            smem_b = self._scratch_smem_vec("dot_b", (bk * bn) // vl, tl.float32, vl)
        else:
            smem_b = self._scratch_smem("dot_b", bk * bn, tl.float32)

        # stage a into smem (flat f32, row-major bm x bk) — the tier-2
        # smem round-trip's write side; the FMA loop below is the
        # consumer-side read (kept fused for register economy)
        if not (is_dist(a.layout) or is_flat(a.layout)):
            raise TileConfigError(
                f"tl.dot operand a has unsupported layout {a.layout!r} "
                "(must come from a distributed/flat tile load)")
        self._stage_tile_smem(a, smem_a)

        # stage b into smem
        if not (is_dist(b.layout) or is_flat(b.layout)):
            raise TileConfigError(
                f"tl.dot operand b has unsupported layout {b.layout!r}")
        self._stage_tile_smem(b, smem_b, vl_view=vl if use_bvec else 0)
        gpu.barrier()

        # FMA loop: acc[m] += a[m, k] * b[k, :] over k; a is smem-broadcast,
        # b fragments are vector loads (LDS.128) from the vector smem view.
        for_op = scf.ForOp(self.c_idx(0), self.c_idx(bk), self.c_idx(1),
                           iter_args=[acc.val])
        block = _ensure_block(for_op.regions[0])
        with ir.InsertionPoint(block):
            k_idx, acc_in = block.arguments
            k32 = arith.index_cast(self.i32, k_idx)
            if use_bvec:
                if vec_n == vl:
                    idx = arith.addi(arith.muli(k32, self.c_i32(bn // vl)),
                                     self.tid())
                    b_frag = memref.LoadOp(smem_b, [self.to_index(idx)]).result
                else:
                    vty = ir.VectorType.get([vec_n], self.f32)
                    b_frag = self.dense_const(vty, tl.float32, 0.0)
                    for j in range(vec_n // vl):
                        idx = arith.addi(
                            arith.muli(k32, self.c_i32(bn // vl)),
                            arith.addi(arith.muli(self.tid(),
                                                  self.c_i32(vec_n // vl)),
                                       self.c_i32(j)))
                        chunk = memref.LoadOp(smem_b, [self.to_index(idx)]).result
                        b_frag = vector.insert(chunk, b_frag, [], [j * vl])
            else:
                idx = arith.addi(arith.muli(k32, self.c_i32(bn)),
                                 arith.muli(self.tid(), self.c_i32(vec_n)))
                vty = ir.VectorType.get([vec_n], self.f32)
                b_frag = vector.LoadOp(vty, smem_b, [self.to_index(idx)]).result
            acc_cur = acc_in
            for m in range(bm):
                a_m = memref.LoadOp(
                    smem_a, [arith.addi(self.c_idx(m * bk), k_idx)]).result
                a_v = self.splat(ir.VectorType.get([vec_n], self.f32), a_m)
                row = vector.extract(acc_cur, [], [m])
                row = vector.fma(a_v, b_frag, row)
                acc_cur = vector.insert(row, acc_cur, [], [m])
            scf.YieldOp([acc_cur])
        acc_val = for_op.results[0]
        gpu.barrier()
        return Tensor(tl.float32, (bm, bn), dist_layout((bm, bn), nt),
                      acc_val, vec_n)

    # -- fused solve_tril (warp-level primitives) -----------------------------

    _TRIL_LD = 68  # padded row stride of the 64x64 smem tiles, in floats

    def _warp_sync(self):
        """Intra-warp shared-memory ordering (bar.warp.sync, full mask)."""
        nvvm.InlinePtxOp([], [self.c_i32(-1)], [], "bar.warp.sync $0;")

    def solve_tril(self, a_pt: PtrTensor, ai_pt: PtrTensor,
                   pid_t: Scalar, pid_bh: Scalar, T: Scalar, H: Scalar,
                   BT: int, cu_pt: PtrTensor | None = None,
                   ci_pt: PtrTensor | None = None):
        """Ai = (I + A)^-1 per BTxBT strictly-lower-triangular block, one
        CTA per (chunk, batch*head): phase 1 forward-substitutes the 16x16
        diagonal inverses in registers, phase 2 merges off-diagonal blocks
        with warp-level 16x16 matmuls. BT in {16, 32, 64}; A f32/bf16,
        Ai f32. cu_pt/ci_pt (varlen): A is [1, T_total, H, BT] and the
        sequence bounds come from cu_seqlens."""
        if BT not in (16, 32, 64) or BT % 16 != 0:
            raise TileConfigError(f"tl.solve_tril: BT must be 16/32/64, got {BT}")
        if ai_pt.arg.elem != tl.float32:
            raise TileConfigError("tl.solve_tril: Ai must be f32")
        if a_pt.arg.elem not in (tl.float32, tl.bfloat16):
            raise TileConfigError(f"tl.solve_tril: A must be f32/bf16, "
                                  f"got {a_pt.arg.elem}")
        if self.num_threads != 128:
            raise TileConfigError("tl.solve_tril needs num_warps=4 "
                                  f"(got {self.num_threads} threads)")
        is_bf16 = a_pt.arg.elem == tl.bfloat16
        is_varlen = cu_pt is not None
        NB = BT // 16
        LD = self._TRIL_LD
        c = self.c_i32
        sA = self._scratch_smem("tril_a", BT * LD, tl.float32)
        sX = self._scratch_smem("tril_x", BT * LD, tl.float32)
        zero = self.const(tl.float32, 0.0)
        one = self.const(tl.float32, 1.0)

        tid = self.tid()
        warp = arith.divsi(tid, c(32))
        lane = arith.remsi(tid, c(32))
        i0 = arith.divsi(lane, c(16))
        j0 = arith.remsi(lane, c(16))
        i0ld = arith.muli(i0, c(LD))

        # element offset of this CTA's BTxBT block
        row_stride = arith.muli(H.val, c(BT))
        h_idx = arith.remsi(pid_bh.val, H.val)
        if is_varlen:
            def _ld_i32(pt, off):
                v = memref.LoadOp(pt.arg.scalar_view,
                                  [self.to_index(off)]).result
                if pt.arg.elem == tl.int64:
                    v = arith.trunci(self.i32, v)
                return v
            i_n = _ld_i32(ci_pt, arith.muli(pid_t.val, c(2)))
            i_tl = _ld_i32(ci_pt, arith.addi(arith.muli(pid_t.val, c(2)), c(1)))
            bos = _ld_i32(cu_pt, i_n)
            t_loc = arith.subi(_ld_i32(cu_pt, arith.addi(i_n, c(1))), bos)
            base = arith.addi(
                arith.muli(arith.addi(bos, arith.muli(i_tl, c(BT))), row_stride),
                arith.muli(h_idx, c(BT)))
            t_rem = arith.subi(t_loc, arith.muli(i_tl, c(BT)))
        else:
            b_idx = arith.divsi(pid_bh.val, H.val)
            base = arith.addi(
                arith.addi(arith.muli(arith.muli(b_idx, T.val), row_stride),
                           arith.muli(arith.muli(pid_t.val, c(BT)), row_stride)),
                arith.muli(h_idx, c(BT)))
            t_rem = arith.subi(T.val, arith.muli(pid_t.val, c(BT)))

        # ---- load lower blocks; zero-fill upper / OOB ----
        VL = 8 if is_bf16 else 4  # elements per 16B chunk
        vty = ir.VectorType.get([VL], self.f32)
        zero_v = self.dense_const(vty, tl.float32, 0.0)
        base_v = arith.divsi(base, c(VL))
        row_stride_v = arith.muli(H.val, c(BT // VL))
        pairs = BT * BT // VL
        fpr = BT // VL  # 16B chunks per row

        def _load_one(idx):
            r = arith.divsi(idx, c(fpr))
            f = arith.remsi(idx, c(fpr))
            limit = arith.muli(arith.addi(arith.divsi(r, c(16)), c(1)),
                               c(16 // VL))
            cond = self.and_i1(
                arith.cmpi(arith.CmpIPredicate.slt, f, limit),
                arith.cmpi(arith.CmpIPredicate.slt, r, t_rem))
            g = arith.addi(arith.addi(base_v, arith.muli(r, row_stride_v)), f)
            dst = arith.addi(arith.muli(r, c(LD)), arith.muli(f, c(VL)))
            if_op = self._if_op(cond, [])
            with self._region(if_op.regions[0]):
                v = memref.LoadOp(a_pt.arg.vec_view, [self.to_index(g)]).result
                if is_bf16:
                    v = arith.extf(vty, v)
                vector.StoreOp(v, sA, [self.to_index(dst)])
                self._yield([])
            with self._region(if_op.regions[1]):
                vector.StoreOp(zero_v, sA, [self.to_index(dst)])
                self._yield([])

        for it in range((pairs + 127) // 128):
            idx = arith.addi(tid, c(128 * it))
            if pairs % 128 != 0:
                # ragged tail: threads past `pairs` must not touch smem at all
                inb = scf.IfOp(
                    arith.cmpi(arith.CmpIPredicate.slt, idx, c(pairs)), [],
                    has_else=False)
                with ir.InsertionPoint(_ensure_block(inb.regions[0])):
                    _load_one(idx)
                    scf.YieldOp([])
            else:
                _load_one(idx)
        gpu.barrier()

        # ---- phase 1: 16x16 diagonal inverses, lane-per-column ----
        cond16 = self.and_i1(arith.cmpi(arith.CmpIPredicate.slt, lane, c(16)),
                             arith.cmpi(arith.CmpIPredicate.slt, warp, c(NB)))
        if1 = scf.IfOp(cond16, [], has_else=False)
        with ir.InsertionPoint(_ensure_block(if1.regions[0])):
            off = arith.muli(warp, c(16))
            off69 = arith.muli(off, c(LD + 1))
            x = [zero] * 16
            x[0] = self.select(
                arith.cmpi(arith.CmpIPredicate.eq, lane, c(0)), one, zero)
            for i in range(1, 16):
                xi = zero
                for k in range(i):
                    aik = memref.LoadOp(sA, [self.to_index(
                        arith.addi(off69, c(i * LD + k)))]).result
                    take = arith.cmpi(arith.CmpIPredicate.sle, lane, c(k))
                    f = arith.addf(arith.mulf(arith.negf(aik), x[k]), xi)
                    xi = self.select(take, f, xi)
                vi = self.select(
                    arith.cmpi(arith.CmpIPredicate.slt, lane, c(i)), xi,
                    self.select(
                        arith.cmpi(arith.CmpIPredicate.eq, lane, c(i)),
                        one, zero))
                x[i] = vi
            for k in range(16):
                memref.StoreOp(x[k], sX, [self.to_index(
                    arith.addi(off69, arith.addi(c(k * LD), lane)))])
            scf.YieldOp([])
        gpu.barrier()

        # ---- phase 2: per-warp specialized 16x16 merges ----
        def mm16(sP, pr, pc, sQ, qr, qc):
            """acc[s] = sum_k P[pr+i0+2s, pc+k] * Q[qr+k, qc+j0], s=0..7."""
            acc = [zero] * 8
            for k in range(16):
                q = memref.LoadOp(sQ, [self.to_index(
                    arith.addi(c((qr + k) * LD + qc), j0))]).result
                for s in range(8):
                    p = memref.LoadOp(sP, [self.to_index(arith.addi(
                        c((pr + 2 * s) * LD + pc + k), i0ld))]).result
                    acc[s] = arith.addf(arith.mulf(p, q), acc[s])
            return acc

        def st16(sC, cr, cc, acc, negate=False):
            for s in range(8):
                v = arith.negf(acc[s]) if negate else acc[s]
                memref.StoreOp(v, sC, [self.to_index(arith.addi(
                    arith.addi(c((cr + 2 * s) * LD + cc), i0ld), j0))])

        def add16(sC, cr, cc, acc):
            for s in range(8):
                at = self.to_index(arith.addi(
                    arith.addi(c((cr + 2 * s) * LD + cc), i0ld), j0))
                cur = memref.LoadOp(sC, [at]).result
                memref.StoreOp(arith.addf(cur, acc[s]), sC, [at])

        for d in range(1, NB):
            for w in range(NB - d):
                condw = arith.cmpi(arith.CmpIPredicate.eq, warp, c(w))
                ifw = scf.IfOp(condw, [], has_else=False)
                with ir.InsertionPoint(_ensure_block(ifw.regions[0])):
                    bi, bj = w + d, w
                    tc = (w + 1) * 16  # scratch tile in sA's upper triangle
                    acc = mm16(sA, bi * 16, bj * 16, sX, bj * 16, bj * 16)
                    st16(sA, 0, tc, acc)
                    self._warp_sync()
                    for bk in range(bj + 1, bi):
                        acc = mm16(sA, bi * 16, bk * 16, sX, bk * 16, bj * 16)
                        add16(sA, 0, tc, acc)
                        self._warp_sync()
                    acc = mm16(sX, bi * 16, bi * 16, sA, 0, tc)
                    st16(sX, bi * 16, bj * 16, acc, negate=True)
                    scf.YieldOp([])
            gpu.barrier()

        # ---- store full BTxBT (zeros above the block diagonal) ----
        for it in range((pairs + 127) // 128):
            idx = arith.addi(tid, c(128 * it))
            r = arith.divsi(idx, c(fpr))
            f = arith.remsi(idx, c(fpr))
            limit = arith.muli(arith.addi(arith.divsi(r, c(16)), c(1)),
                               c(16 // VL))
            g = arith.addi(arith.addi(base_v, arith.muli(r, row_stride_v)), f)
            src = arith.addi(arith.muli(r, c(LD)), arith.muli(f, c(VL)))
            cond_r = arith.cmpi(arith.CmpIPredicate.slt, r, t_rem)
            if pairs % 128 != 0:
                cond_r = self.and_i1(cond_r,
                                     arith.cmpi(arith.CmpIPredicate.slt,
                                                idx, c(pairs)))
            ifr = scf.IfOp(cond_r, [], has_else=False)
            with ir.InsertionPoint(_ensure_block(ifr.regions[0])):
                cond_l = arith.cmpi(arith.CmpIPredicate.slt, f, limit)
                ifl = self._if_op(cond_l, [vty])
                with self._region(ifl.regions[0]):
                    vv = vector.LoadOp(vty, sX, [self.to_index(src)]).result
                    self._yield([vv])
                with self._region(ifl.regions[1]):
                    self._yield([zero_v])
                memref.StoreOp(ifl.results[0], ai_pt.arg.vec_view,
                               [self.to_index(g)])
                scf.YieldOp([])

    # -- naive W-IR solve_tril -------------------------------------------------

    def solve_tril_wir(self, a_pt: PtrTensor, ai_pt: PtrTensor,
                       pid_t: Scalar, pid_bh: Scalar, T: Scalar, H: Scalar,
                       BT: int, cu_pt: PtrTensor | None = None,
                       ci_pt: PtrTensor | None = None):
        """Same math as solve_tril, written naively on W-IR (no warp-role
        specialization, no syncs): compiler/passes.py recovers the schedule
        from the access annotations. Correctness oracle for the passes."""
        from .wir import WIR
        if BT not in (16, 32, 64) or BT % 16 != 0:
            raise TileConfigError(f"tl.solve_tril: BT must be 16/32/64, got {BT}")
        if ai_pt.arg.elem != tl.float32:
            raise TileConfigError("tl.solve_tril: Ai must be f32")
        if a_pt.arg.elem not in (tl.float32, tl.bfloat16):
            raise TileConfigError(f"tl.solve_tril: A must be f32/bf16, "
                                  f"got {a_pt.arg.elem}")
        if self.num_threads != 128:
            raise TileConfigError("tl.solve_tril needs num_warps=4 "
                                  f"(got {self.num_threads} threads)")
        is_bf16 = a_pt.arg.elem == tl.bfloat16
        is_varlen = cu_pt is not None
        NB = BT // 16
        LD = self._TRIL_LD
        c = self.c_i32
        w = WIR(self)
        self.entry.owner.attributes["wir.nt"] = ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), self.num_threads)
        sA = w.shmem("wir_a", BT * LD)
        sX = w.shmem("wir_x", BT * LD)
        zero = self.const(tl.float32, 0.0)
        one = self.const(tl.float32, 1.0)

        tid = w.tid()
        lane = w.mod(tid, 32)
        i0 = w.div(lane, 16)
        j0 = w.mod(lane, 16)
        i0ld = w.mul(i0, LD)
        tid_v = tid.val
        lane_v, i0_v, j0_v, i0ld_v = lane.val, i0.val, j0.val, i0ld.val

        # element offset of this CTA's BTxBT block (runtime scalars: opaque)
        row_stride = arith.muli(H.val, c(BT))
        h_idx = arith.remsi(pid_bh.val, H.val)
        if is_varlen:
            def _ld_i32(pt, off):
                v = memref.LoadOp(pt.arg.scalar_view,
                                  [self.to_index(off)]).result
                if pt.arg.elem == tl.int64:
                    v = arith.trunci(self.i32, v)
                return v
            i_n = _ld_i32(ci_pt, arith.muli(pid_t.val, c(2)))
            i_tl = _ld_i32(ci_pt, arith.addi(arith.muli(pid_t.val, c(2)), c(1)))
            bos = _ld_i32(cu_pt, i_n)
            t_loc = arith.subi(_ld_i32(cu_pt, arith.addi(i_n, c(1))), bos)
            base = arith.addi(
                arith.muli(arith.addi(bos, arith.muli(i_tl, c(BT))), row_stride),
                arith.muli(h_idx, c(BT)))
            t_rem = arith.subi(t_loc, arith.muli(i_tl, c(BT)))
        else:
            b_idx = arith.divsi(pid_bh.val, H.val)
            base = arith.addi(
                arith.addi(arith.muli(arith.muli(b_idx, T.val), row_stride),
                           arith.muli(arith.muli(pid_t.val, c(BT)), row_stride)),
                arith.muli(h_idx, c(BT)))
            t_rem = arith.subi(T.val, arith.muli(pid_t.val, c(BT)))

        # ---- cooperative global->smem stage (thread-parallel by construction,
        # already the optimal mapping; no pass involvement needed) ----
        VL = 8 if is_bf16 else 4
        vty = ir.VectorType.get([VL], self.f32)
        zero_v = self.dense_const(vty, tl.float32, 0.0)
        base_v = arith.divsi(base, c(VL))
        row_stride_v = arith.muli(H.val, c(BT // VL))
        pairs = BT * BT // VL
        fpr = BT // VL

        def _stage_one(idx: Idx):
            r = w.div(idx, fpr)
            f = w.mod(idx, fpr)
            limit = arith.muli(arith.addi(arith.divsi(r.val, c(16)), c(1)),
                               c(16 // VL))
            cond = self.and_i1(
                arith.cmpi(arith.CmpIPredicate.slt, f.val, limit),
                arith.cmpi(arith.CmpIPredicate.slt, r.val, t_rem))
            g = arith.addi(arith.addi(base_v, arith.muli(r.val, row_stride_v)),
                           f.val)
            dst = w.add(w.mul(r, LD), w.mul(f, VL))
            if_op = self._if_op(cond, [])
            with self._region(if_op.regions[0]):
                v = memref.LoadOp(a_pt.arg.vec_view, [self.to_index(g)]).result
                if is_bf16:
                    v = arith.extf(vty, v)
                w.shstore_vec(sA, dst, v)
                self._yield([])
            with self._region(if_op.regions[1]):
                w.shstore_vec(sA, dst, zero_v)
                self._yield([])

        for it in range((pairs + 127) // 128):
            idx = w.add(tid, 128 * it)
            if pairs % 128 != 0:
                inb = scf.IfOp(
                    arith.cmpi(arith.CmpIPredicate.slt, idx.val, c(pairs)), [],
                    has_else=False)
                with ir.InsertionPoint(_ensure_block(inb.regions[0])):
                    _stage_one(idx)
                    scf.YieldOp([])
            else:
                _stage_one(idx)

        # ---- phase 1: per-block 16x16 diagonal inverses (lane-per-column
        # forward substitution, register-resident; loop mapped by P1) ----
        with w.par_loop(NB, "warp") as ww:
            off = w.mul(ww, 16)
            off69 = w.mul(off, LD + 1)
            cond16 = arith.cmpi(arith.CmpIPredicate.slt, lane_v, c(16))
            if1 = scf.IfOp(cond16, [], has_else=False)
            with ir.InsertionPoint(_ensure_block(if1.regions[0])):
                x = [zero] * 16
                x[0] = self.select(
                    arith.cmpi(arith.CmpIPredicate.eq, lane_v, c(0)), one, zero)
                for i in range(1, 16):
                    xi = zero
                    for k in range(i):
                        aik = w.shload(sA, w.add(off69, i * LD + k))
                        take = arith.cmpi(arith.CmpIPredicate.sle, lane_v, c(k))
                        f = arith.addf(arith.mulf(arith.negf(aik), x[k]), xi)
                        xi = self.select(take, f, xi)
                    vi = self.select(
                        arith.cmpi(arith.CmpIPredicate.slt, lane_v, c(i)), xi,
                        self.select(
                            arith.cmpi(arith.CmpIPredicate.eq, lane_v, c(i)),
                            one, zero))
                    x[i] = vi
                for k in range(16):
                    w.shstore(sX, w.add(off69, w.add(w.mul(k, LD), lane)),
                              x[k])
                scf.YieldOp([])

        # ---- phase 2: off-diagonal merges, one parallel loop per distance ----
        # block coords here are Idx (dynamic, affine in the parallel-loop iv);
        # P1 maps each distance-d loop over warps, P2 places the syncs.
        def mm16(sP, pr, pc, sQ, qr, qc):
            """acc[s] = sum_k P[pr+i0+2s, pc+k] * Q[qr+k, qc+j0], s=0..7."""
            acc = [zero] * 8
            for k in range(16):
                q = w.shload(sQ, w.add(w.add(w.mul(w.add(qr, k), LD), qc), j0))
                for s in range(8):
                    p = w.shload(sP, w.add(
                        w.add(w.mul(w.add(pr, 2 * s), LD), pc),
                        w.add(w.idx(k), i0ld)))
                    acc[s] = arith.addf(arith.mulf(p, q), acc[s])
            return acc

        def st16(sC, cr, cc, acc, negate=False):
            for s in range(8):
                v = arith.negf(acc[s]) if negate else acc[s]
                w.shstore(sC, w.add(
                    w.add(w.mul(w.add(cr, 2 * s), LD), cc),
                    w.add(i0ld, j0)), v)

        def add16(sC, cr, cc, acc):
            for s in range(8):
                at = w.add(w.add(w.mul(w.add(cr, 2 * s), LD), cc),
                           w.add(i0ld, j0))
                cur = w.shload(sC, at)
                w.shstore(sC, at, arith.addf(cur, acc[s]))

        for d in range(1, NB):
            with w.par_loop(NB - d, "warp") as pw:
                bj = pw
                bi = w.add(pw, d)
                bi16, bj16 = w.mul(bi, 16), w.mul(bj, 16)
                tc = w.add(w.mul(pw, 16), 16)  # scratch in sA upper triangle
                acc = mm16(sA, bi16, bj16, sX, bj16, bj16)
                st16(sA, 0, tc, acc)
                for k in range(1, d):  # bk = bj+k covers bj+1 .. bi-1
                    bk16 = w.mul(w.add(pw, k), 16)
                    acc = mm16(sA, bi16, bk16, sX, bk16, bj16)
                    add16(sA, 0, tc, acc)
                acc = mm16(sX, bi16, bi16, sA, 0, tc)
                st16(sX, bi16, bj16, acc, negate=True)

        # ---- store full BTxBT (zeros above the block diagonal) ----
        for it in range((pairs + 127) // 128):
            idx = w.add(tid, 128 * it)
            r = w.div(idx, fpr)
            f = w.mod(idx, fpr)
            limit = arith.muli(arith.addi(arith.divsi(r.val, c(16)), c(1)),
                               c(16 // VL))
            g = arith.addi(arith.addi(base_v, arith.muli(r.val, row_stride_v)),
                           f.val)
            src = w.add(w.mul(r, LD), w.mul(f, VL))
            cond_r = arith.cmpi(arith.CmpIPredicate.slt, r.val, t_rem)
            if pairs % 128 != 0:
                cond_r = self.and_i1(
                    cond_r, arith.cmpi(arith.CmpIPredicate.slt, idx.val,
                                       c(pairs)))
            ifr = scf.IfOp(cond_r, [], has_else=False)
            with ir.InsertionPoint(_ensure_block(ifr.regions[0])):
                cond_l = arith.cmpi(arith.CmpIPredicate.slt, f.val, limit)
                ifl = self._if_op(cond_l, [vty])
                with self._region(ifl.regions[0]):
                    vv = w.shload_vec(sX, src, vty)
                    self._yield([vv])
                with self._region(ifl.regions[1]):
                    self._yield([zero_v])
                memref.StoreOp(ifl.results[0], ai_pt.arg.vec_view,
                               [self.to_index(g)])
                scf.YieldOp([])

    # -- tile-level mma DSL primitives: the building blocks application
    # kernels (flash, kda, ...) choreograph from @tl.kernel sources —
    # fragment-A loads, register-A x staged-B mma, materialize_to,
    # fragment-coordinate gathers, zeros born in a Fragment(C).

    def _load_frag_a(self, pt, layout: Fragment, mask):
        """tl.load with LAYOUT=tl.mma_layout("A", ...): a loop-invariant
        mma A operand tile loaded straight into packed operand registers
        ((im, h, j) order, the form _mma_sync consumes); out-of-bound rows
        zfill. bf16 planes load packed pairs directly; f32 planes pack
        in-register (cvt.rn.bf16x2 / cvt.rna.tf32 per atom) — the same
        rounding as the staged route."""
        atom = mma_atom(layout.atom)
        if layout.role != "A":
            raise TileConfigError(
                f"fragment load supports role 'A', got {layout.role!r}")
        if pt.arg.elem == tl.bfloat16:
            if layout.atom != "bf16":
                raise TileConfigError(
                    "fragment A load: a bf16 plane needs the bf16 atom")
            mode = "packed"
        elif pt.arg.elem == tl.float32:
            mode = "cast"  # f32 plane -> in-register operand pack/round
        else:
            raise TileConfigError(
                f"fragment A load: plane must be f32/bf16, got "
                f"{pt.arg.elem}")
        bm, kk = layout.shape
        wn_m, wn_n = layout.warps
        if wn_n != 1:
            raise TileConfigError("fragment A load wants the warp-slab "
                                  "(warps, 1) grid")
        am, ak = layout.atoms
        off = pt.off
        if tuple(off.shape) != (bm, kk):
            raise TileConfigError(
                f"fragment A load: tile {off.shape} != layout {layout.shape}")
        if not (isinstance(off.col.stride, int) and off.col.stride == 1):
            raise TileConfigError("fragment A load needs unit column stride")
        if mask is not None:
            if not isinstance(mask, SepMask) or mask.col_preds:
                raise TileConfigError(
                    "fragment A load masks must be row-predicate SepMasks")
        c = self.c_i32
        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        warp = arith.divsi(tid, c(32))
        g = arith.divsi(lane, c(4))
        t = arith.remsi(lane, c(4))
        row_w = arith.muli(warp, c(bm // wn_m))
        v2 = ir.VectorType.get([2], tl.bfloat16.mlir())
        v1i = ir.VectorType.get([1], self.i32)
        nreg = am * ak * 4
        out = self.dense_const(ir.VectorType.get([nreg], self.i32),
                               tl.int32, 0)
        for im in range(am):
            for h in range(ak):
                for j in range(4):
                    row_l = arith.addi(
                        row_w, arith.addi(c(im * atom.m + 8 * (j % 2)), g))
                    col = arith.addi(arith.muli(t, c(atom.ep)),
                                     c(h * atom.k + (j // 2) * (atom.k // 2)))
                    ok = None
                    for p in (mask.row_preds if mask is not None else []):
                        s = self._pred_scalar(p, row_l)
                        ok = s if ok is None else self.and_i1(ok, s)
                    addr = arith.addi(self.eval_affine(off.row, row_l),
                                      self.eval_affine(off.col, col))
                    if mode == "packed":
                        if ok is None:
                            vec = vector.LoadOp(v2, pt.arg.scalar_view,
                                                [self.to_index(addr)]).result
                            reg = vector.extract(
                                vector.bitcast(v1i, vec), [], [0])
                        else:
                            safe = self.select(ok, addr, c(0))
                            vec = vector.LoadOp(v2, pt.arg.scalar_view,
                                                [self.to_index(safe)]).result
                            reg = self.select(
                                ok, vector.extract(
                                    vector.bitcast(v1i, vec), [], [0]), c(0))
                    else:
                        # f32 plane -> operand cast in-register
                        if atom.ep == 1:  # tf32: per-element cvt.rna
                            if ok is None:
                                v0 = memref.LoadOp(
                                    pt.arg.scalar_view,
                                    [self.to_index(addr)]).result
                            else:
                                safe = self.select(ok, addr, c(0))
                                v0 = self.select(
                                    ok, memref.LoadOp(
                                        pt.arg.scalar_view,
                                        [self.to_index(safe)]).result,
                                    self.const(tl.float32, 0.0))
                            reg = self._mma_cvt_tf32(
                                arith.bitcast(self.i32, v0))
                        else:  # bf16: pair pack (lo=addr, hi=addr+1)
                            if ok is None:
                                v0 = memref.LoadOp(
                                    pt.arg.scalar_view,
                                    [self.to_index(addr)]).result
                                v1 = memref.LoadOp(
                                    pt.arg.scalar_view,
                                    [self.to_index(arith.addi(addr, c(1)))]
                                ).result
                            else:
                                safe = self.select(ok, addr, c(0))
                                v0 = self.select(
                                    ok, memref.LoadOp(
                                        pt.arg.scalar_view,
                                        [self.to_index(safe)]).result,
                                    self.const(tl.float32, 0.0))
                                v1 = self.select(
                                    ok, memref.LoadOp(
                                        pt.arg.scalar_view,
                                        [self.to_index(
                                            arith.addi(safe, c(1)))]
                                    ).result,
                                    self.const(tl.float32, 0.0))
                            reg = self._mma_pack_bf16x2(v0, v1)
                    out = vector.insert(reg, out, [], [(im * ak + h) * 4 + j])
        return Tensor(tl.int32, layout.shape, layout, out, nreg)

    def _mma_stage_tile(self, pt, smem, rows: int, cols: int, trans: bool,
                        mask, even: bool, tid, offset=None):
        """cp.async staging of one tile into swizzled smem for mma()'s B
        operand. trans=False: the (rows, cols) = (K, N) natural tile
        staged row-major, 16B chunks XOR-swizzled by row. trans=True:
        the transposed VIEW staged column-major, chunks swizzled by n.
        even -> 16B copies (mask must be None); else 4B zfill guarded by
        the mask's predicates on the staged row. cols // v16 must be a
        power of two or the swizzle escapes its row (TileConfigError)."""
        v16 = 16 // pt.arg.elem.itemsize
        gran = 4 // pt.arg.elem.itemsize
        cr = cols // v16  # 16B chunks per staged row
        if cr < 1 or cr & (cr - 1):
            # the XOR swizzle stays inside its row only for a power-of-two
            # chunk count (same constraint as _store_m4_smem)
            raise TileConfigError(
                f"mma stage: {rows}x{cols} tile gives {cr} 16B chunks per "
                "row — the smem XOR swizzle needs a power-of-two chunk "
                "count")
        # XOR-swizzle mask on 16B-chunk indices (chunk ^ (row & swz)):
        # cr-1 keeps the XOR inside the (power-of-two) chunk row; 15 caps
        # the pattern at the row's low 4 bits (16-row period, spanning
        # <= 16 chunks = 256B)
        swz = min(cr - 1, 15)
        nt = self.num_threads
        c = self.c_i32
        toks = []

        def src_at(row, c0):
            if trans:
                return arith.addi(
                    self.eval_affine(pt.off.row, c0),
                    self.eval_affine(pt.off.col, row))
            return arith.addi(
                self.eval_affine(pt.off.row, row),
                self.eval_affine(pt.off.col, c0))

        def row_ok(row):
            ok = None
            preds = () if mask is None else (
                mask.col_preds if trans else mask.row_preds)
            for p in preds:
                s = self._pred_scalar(p, row)
                ok = s if ok is None else self.and_i1(ok, s)
            return ok

        if even:
            if mask is not None:
                raise TileConfigError("mma stage: EVEN excludes a mask")
            if rows * (cols // v16) % nt:
                raise TileConfigError(
                    f"mma stage: {rows}x{cols} tile does not distribute "
                    f"over {nt} threads in 16B chunks")
            for j in range(rows * (cols // v16) // nt):
                cc = arith.addi(tid, c(j * nt))
                row = arith.divsi(cc, c(cols // v16))
                jc = arith.remsi(cc, c(cols // v16))
                src = src_at(row, arith.muli(jc, c(v16)))
                sw = arith.xori(jc, arith.andi(row, c(swz)))
                dst = arith.addi(arith.muli(row, c(cols)),
                                 arith.muli(sw, c(v16)))
                if offset is not None:
                    dst = arith.addi(dst, offset)
                op = nvgpu.device_async_copy(
                    smem, [self.to_index(dst)], pt.arg.scalar_view,
                    [self.to_index(src)], v16, bypass_l1=True)
                if self._wir_annotate_on():
                    fcc = FA(TID, FC(j * nt))
                    fsw = FX(FMo(fcc, cols // v16),
                             FAn(FD(fcc, cols // v16), swz))
                    self._wir_attr(
                        op, self._wir_smem_role(smem),
                        FA(FM(FD(fcc, cols // v16), FC(cols)),
                           FM(fsw, FC(v16))), v16)
                toks.append(op)
            return toks
        upr = cols // gran
        if rows * upr % nt:
            raise TileConfigError(
                f"mma stage: {rows}x{cols} tile does not distribute over "
                f"{nt} threads in {gran}-elem units")
        for j in range(rows * upr // nt):
            u = arith.addi(tid, c(j * nt))
            row = arith.divsi(u, c(upr))
            nn0 = arith.muli(arith.remsi(u, c(upr)), c(gran))
            src = src_at(row, nn0)
            ok = row_ok(row)
            if ok is not None:
                se = self.select(ok, self.c_idx(gran), self.c_idx(0))
                src = self.select(ok, src, c(0))
            else:
                se = self.c_idx(gran)
            sw = arith.xori(arith.divsi(nn0, c(v16)),
                            arith.andi(row, c(swz)))
            dst = arith.addi(arith.muli(row, c(cols)),
                             arith.addi(arith.muli(sw, c(v16)),
                                        arith.remsi(nn0, c(v16))))
            if offset is not None:
                dst = arith.addi(dst, offset)
            op = nvgpu.device_async_copy(
                smem, [self.to_index(dst)], pt.arg.scalar_view,
                [self.to_index(src)], gran, src_elements=se)
            if self._wir_annotate_on():
                fu = FA(TID, FC(j * nt))
                frow = FD(fu, upr)
                fnn0 = FM(FMo(fu, upr), FC(gran))
                fsw = FX(FD(fnn0, v16), FAn(frow, swz))
                self._wir_attr(
                    op, self._wir_smem_role(smem),
                    FA(FM(frow, FC(cols)),
                       FA(FM(fsw, FC(v16)), FMo(fnn0, v16))), gran)
            toks.append(op)
        return toks

    def stage_pipe(self, shape, elem, trans: bool = False,
                   even: bool = False) -> StagePipe:
        """tl.stage_pipe: allocate one cp.async staging pipe (a named
        swizzled smem tile buffer + geometry). `shape` is the STAGED
        tile's (rows, cols). Call at kernel top level only."""
        rows, cols = shape
        seq = getattr(self, "_pipe_seq", 0)
        self._pipe_seq = seq + 1
        smem = self._scratch_smem(f"mmapipe{seq}", rows * cols, elem)
        return StagePipe(smem, rows, cols, trans, even, elem)

    def async_stage(self, pipe: StagePipe, b_pt: PtrTensor,
                    mask=None, offset: Scalar | None = None) -> AsyncTok:
        """tl.async_stage(pipe, b_pt, mask=..., OFFSET=...): issue the
        cp.async group copying the b tile into the pipe's smem; the
        mask's predicates guard/zfill staged rows, OFFSET stages at an
        element offset (tl.mma reads the tile at the same offset).
        Compile-time OFFSETs are footprint-checked at the frontend; a
        runtime OFFSET can't be — OFFSET + the staged tile staying
        inside the pipe is then the caller's responsibility.
        Returns the promise token tl.mma / tl.async_wait consume."""
        rows, cols = (b_pt.off.shape[1], b_pt.off.shape[0]) \
            if pipe.trans else b_pt.off.shape
        if b_pt.arg.elem != pipe.elem:
            raise TileConfigError(
                f"tl.async_stage: cannot stage a {b_pt.arg.elem} tile "
                f"into a {pipe.elem} pipe — element types must match")
        if rows * cols > pipe.rows * pipe.cols:
            raise TileConfigError(
                f"tl.async_stage: {rows}x{cols} tile does not fit the "
                f"{pipe.rows}x{pipe.cols} pipe ({rows * cols} > "
                f"{pipe.rows * pipe.cols} elements) — the copy would "
                f"overrun the pipe's shared memory")
        toks = self._mma_stage_tile(b_pt, pipe.smem, rows, cols,
                                    pipe.trans, mask, pipe.even,
                                    self.tid(),
                                    offset=offset.val if offset else None)
        off_s = offset if offset is not None else \
            Scalar(tl.int32, self.c_i32(0))
        return AsyncTok(nvgpu.device_async_create_group(toks), pipe,
                        off_s, (rows, cols))

    def async_wait(self, tok: AsyncTok, pending: int):
        """tl.async_wait(tok, pending): wait until at most `pending`
        cp.async groups remain in flight (cp.async.wait_group semantics;
        groups complete in issue order)."""
        nvgpu.device_async_wait(tok.val, num_groups=pending)

    # -- row-per-thread (t3) tiles + the CUDA-core FMA dot ---------------------

    def _load_t3(self, pt, layout, mask, other_v=None):
        """tl.load with LAYOUT=tl.t3_layout(...): a row-per-thread tile —
        each thread holds tm full rows in registers (vector-chunk loads,
        row preds zfill OOB rows with `other`, default 0)."""
        rows, cols = layout.shape
        tm = layout.size_per_thread[0]
        if tm != 1:
            raise TileConfigError("t3 loads currently support tm == 1")
        off = pt.off
        if tuple(off.shape) != (rows, cols):
            raise TileConfigError(
                f"t3 load: tile {off.shape} != layout {layout.shape}")
        if not (cols == 1
                or (isinstance(off.col.stride, int) and off.col.stride == 1)):
            raise TileConfigError("t3 load needs unit column stride")
        if mask is not None:
            if not isinstance(mask, SepMask) or mask.col_preds:
                raise TileConfigError(
                    "t3 load masks must be row-predicate SepMasks")
        parg = pt.arg
        vl = parg.vl
        c = self.c_i32
        tid = self.tid()
        row_l = tid
        ok = None
        for p in (mask.row_preds if mask is not None else []):
            s = self._pred_scalar(p, row_l)
            ok = s if ok is None else self.and_i1(ok, s)
        row_addr = self.eval_affine(off.row, row_l)

        def slow_path() -> ir.Value:
            out = self.dense_const(
                ir.VectorType.get([cols], parg.elem.mlir()), parg.elem, 0)
            z = other_v if other_v is not None else \
                self.const(parg.elem, 0.0 if parg.elem.is_float else 0)
            for j in range(cols):
                addr = arith.addi(row_addr,
                                  self.eval_affine(off.col, c(j)))
                if ok is not None:
                    addr = self.select(ok, addr, c(0))
                v = memref.LoadOp(parg.scalar_view,
                                  [self.to_index(addr)]).result
                if ok is not None:
                    v = self.select(ok, v, z)
                out = vector.insert(v, out, [], [j])
            return out

        if cols % vl:
            # scalar path (narrow rows, e.g. the (BM, 1) row statistic)
            return Tensor(parg.elem, layout.shape, layout, slow_path(), cols)
        cols_vty = ir.VectorType.get([cols], parg.elem.mlir())
        # vector chunks index by addr // vl, so a vl-misaligned row base
        # (e.g. a runtime row stride) must take the scalar path; chunk j
        # only adds j*vl, so one runtime check covers the row
        addr0 = arith.addi(row_addr, self.eval_affine(off.col, c(0)))
        cond = self._aligned_i1(addr0, vl)
        if ok is not None:
            cond = self.and_i1(cond, ok)
        if_op = scf.IfOp(cond, [cols_vty], has_else=True)
        with ir.InsertionPoint(_ensure_block(if_op.regions[0])):
            res = self.dense_const(cols_vty, parg.elem, 0)
            for j in range(cols // vl):
                addr = arith.addi(row_addr,
                                  self.eval_affine(off.col, c(j * vl)))
                chunk = self._vec_chunk_load(parg, addr)
                res = chunk if cols == vl else vector.insert_strided_slice(
                    chunk, res, [j * vl], [1])
            scf.YieldOp([res])
        with ir.InsertionPoint(_ensure_block(if_op.regions[1])):
            scf.YieldOp([slow_path()])
        return Tensor(parg.elem, layout.shape, layout, if_op.results[0], cols)

    def _store_t3(self, pt, value: Tensor, mask=None):
        """Guarded store of a row-per-thread (t3) tile: each thread
        stores its row in vector chunks, row preds guarding."""
        layout = value.layout
        rows, cols = value.shape
        tm = layout.size_per_thread[0]
        if tm != 1:
            raise TileConfigError("t3 stores currently support tm == 1")
        off = pt.off
        if tuple(off.shape) != (rows, cols):
            raise TileConfigError(
                f"t3 store: tile {off.shape} != value {value.shape}")
        if not (cols == 1
                or (isinstance(off.col.stride, int)
                    and off.col.stride == 1)):
            raise TileConfigError("t3 store needs unit column stride")
        if pt.arg.elem != value.dtype:
            raise TileConfigError(
                f"t3 store: dtype mismatch {value.dtype} vs {pt.arg.elem}")
        if mask is not None:
            if not isinstance(mask, SepMask) or mask.col_preds:
                raise TileConfigError(
                    "t3 store masks must be row-predicate SepMasks")
        parg = pt.arg
        vl = parg.vl
        c = self.c_i32
        tid = self.tid()
        row_l = tid
        ok = None
        for p in (mask.row_preds if mask is not None else []):
            s = self._pred_scalar(p, row_l)
            ok = s if ok is None else self.and_i1(ok, s)
        row_addr = self.eval_affine(off.row, row_l)

        def emit_scalar():
            for j in range(cols):
                addr = arith.addi(row_addr,
                                  self.eval_affine(off.col, c(j)))
                memref.StoreOp(vector.extract(value.val, [], [j]),
                               parg.scalar_view,
                               [self.to_index(addr)])

        def emit_guarded_scalar():
            if ok is None:
                emit_scalar()
            else:
                if_op = scf.IfOp(ok, [], has_else=False)
                with ir.InsertionPoint(_ensure_block(if_op.regions[0])):
                    emit_scalar()
                    scf.YieldOp([])

        if cols % vl:
            # scalar path (narrow rows, e.g. the (BM, 1) lse statistic)
            emit_guarded_scalar()
            return
        v4 = ir.VectorType.get([vl], parg.elem.mlir())

        def emit_vec():
            for j in range(cols // vl):
                addr = arith.addi(row_addr,
                                  self.eval_affine(off.col, c(j * vl)))
                chunk = vector.extract_strided_slice(v4, value.val,
                                                     [j * vl], [vl], [1])
                self._vec_chunk_store(parg, addr, chunk)

        # same runtime guard as the load: a vl-misaligned row base falls
        # back to scalar stores instead of flooring the chunk address
        addr0 = arith.addi(row_addr, self.eval_affine(off.col, c(0)))
        cond = self._aligned_i1(addr0, vl)
        if ok is not None:
            cond = self.and_i1(cond, ok)
        if_op = scf.IfOp(cond, [], has_else=True)
        with ir.InsertionPoint(_ensure_block(if_op.regions[0])):
            emit_vec()
            scf.YieldOp([])
        with ir.InsertionPoint(_ensure_block(if_op.regions[1])):
            emit_guarded_scalar()
            scf.YieldOp([])

    def bcast_t3_col(self, y: Tensor, x_lay) -> Tensor:
        """Splat a t3 (BM, 1) row scalar across the columns of a t3
        (BM, C) layout (the row statistic form: one per-thread value
        replicated over its row)."""
        tm, cols = x_lay.size_per_thread[0], x_lay.shape[1]
        if not (is_t3(x_lay) and y.shape == (x_lay.shape[0], 1)
                and is_t3(y.layout)):
            raise TileConfigError(
                f"bcast_t3_col: cannot broadcast {y.shape} against "
                f"{x_lay!r}")
        out = self.dense_const(
            ir.VectorType.get([tm * cols], y.dtype.mlir()), y.dtype, 0)
        for r in range(tm):
            for j in range(cols):
                out = vector.insert(
                    vector.extract(y.val, [], [r]), out, [],
                    [r * cols + j])
        return Tensor(y.dtype, x_lay.shape, x_lay, out, tm * cols)

    def bcast_t3_scalar_to_rep(self, v: Tensor, rep_lay) -> Tensor:
        """Splat a t3 (BM, 1) row scalar into a (C,) rep vector (the
        per-thread scalar against a per-column vector: the rep result
        keeps every thread's whole-vector form)."""
        if not (len(rep_lay.shape) == 1 and is_rep_like(rep_lay)):
            raise TileConfigError(
                f"bcast_t3_scalar_to_rep: not a 1D rep layout {rep_lay!r}")
        n = rep_lay.shape[0]
        out = self.dense_const(
            ir.VectorType.get([n], v.dtype.mlir()), v.dtype, 0)
        for j in range(n):
            out = vector.insert(vector.extract(v.val, [], [0]), out, [],
                                [j])
        return Tensor(v.dtype, rep_lay.shape, rep_lay, out, n)

    def bcast_rep_rows(self, y: Tensor, x_lay) -> Tensor:
        """Broadcast a (C,) rep-like row vector across the rows of a t3
        layout: per owned element (i, j) -> y[j] (pure register
        selection)."""
        if not (len(y.shape) == 1 and is_rep_like(y.layout)):
            raise TileConfigError(
                f"bcast_rep_rows expects a (C,) rep value, got {y!r}")
        if not is_t3(x_lay) or x_lay.shape[1] != y.shape[0]:
            raise TileConfigError(
                f"bcast_rep_rows: cannot broadcast {y.shape} against "
                f"{x_lay!r}")
        tm, cols = x_lay.size_per_thread[0], x_lay.shape[1]
        out = self.dense_const(
            ir.VectorType.get([tm * cols], y.dtype.mlir()), y.dtype, 0)
        for r in range(tm):
            for j in range(cols):
                out = vector.insert(
                    vector.extract(y.val, [], [j]), out, [], [r * cols + j])
        return Tensor(y.dtype, x_lay.shape, x_lay, out, tm * cols)

    def dot_t3(self, a: Tensor, b, acc: Tensor | None = None, *,
               pending: int | None = None, trans_b: bool = False,
               offset: Scalar | None = None) -> Tensor:
        """Per-thread row x smem-tile FMA dot (tl.dot_t3, CUDA-core):
        out[i, j] = sum_k a[i, k] * buf[k, j]. `a`: t3 (BM, K) value in
        registers; `b`: a SmemBuf or async promise (the dot waits with
        PENDING newer groups allowed, then barriers); acc chains a t3
        (BM, N) accumulator. TRANS_B: buffer holds the (N, K) natural
        tile, read transposed (identical values)."""
        if not isinstance(a, Tensor) or not isinstance(a.layout, Blocked) \
                or not is_t3(a.layout):
            raise TileConfigError(
                f"tl.dot_t3: a must be a t3 row-per-thread value, got {a!r}")
        if a.layout.size_per_thread[0] != 1:
            raise TileConfigError("tl.dot_t3 currently supports tm == 1 operands")
        if a.dtype != tl.float32:
            raise TileConfigError("tl.dot_t3 currently supports f32 operands")
        bm, k_dim = a.shape
        if isinstance(b, AsyncTok):
            if pending is None:
                raise TileConfigError(
                    "tl.dot_t3 on a pipeline promise needs PENDING=<newer "
                    "groups allowed in flight>")
            if not isinstance(b.pipe, SmemBuf):
                raise TileConfigError(
                    "tl.dot_t3 consumes tl.async_copy (SmemBuf) promises")
            nvgpu.device_async_wait(b.val, num_groups=pending)
            gpu.barrier()
            buf = b.pipe
            if offset is None:
                offset = b.offset
            after = gpu.barrier
        else:
            if pending is not None:
                raise TileConfigError(
                    "tl.dot_t3: PENDING is a pipeline-promise kwarg")
            if not isinstance(b, SmemBuf):
                raise TileConfigError(
                    f"tl.dot_t3: b must be a SmemBuf or a promise, got {b!r}")
            buf = b
            after = lambda: None
        if buf.dtype != tl.float32:
            raise TileConfigError("tl.dot_t3 currently supports f32 buffers")
        k2, n = buf.shape
        if trans_b:
            n, k2 = k2, n
        if k2 != k_dim:
            # the buffer holds the tile at an offset (OFFSET= or just a
            # bigger buffer): K comes from the A operand, N from acc
            if acc is None:
                raise TileConfigError(
                    f"tl.dot_t3: K mismatch a {a.shape} vs buf "
                    f"{buf.shape} (and no acc to infer the logical "
                    "tile from)")
            n = acc.shape[1]
            k2 = k_dim
        if n % 4:
            raise TileConfigError(f"tl.dot_t3 needs N % 4 == 0, got {n}")
        out_lay = Blocked((bm, n), (1, n), (self.num_threads, 1), (1, 0))
        if acc is not None:
            if not isinstance(acc, Tensor) or acc.layout != out_lay:
                raise TileConfigError(
                    f"tl.dot_t3: acc must be the (BM, {n}) t3 accumulator")
            out = acc.val
        else:
            out = self.dense_const(ir.VectorType.get([n], self.f32),
                                   tl.float32, 0.0)
        v4 = ir.VectorType.get([4], self.f32)
        off_v = offset.val if offset is not None else self.c_i32(0)
        for kk in range(k_dim):
            if trans_b:
                bfr = []
                for j4 in range(n // 4):
                    chunk = self.dense_const(v4, tl.float32, 0.0)
                    for jj in range(4):
                        e = memref.LoadOp(buf.smem, [self.to_index(
                            arith.addi(off_v, self.c_i32(
                                (j4 * 4 + jj) * k_dim + kk)))]).result
                        chunk = vector.insert(e, chunk, [], [jj])
                    bfr.append(chunk)
            else:
                bfr = [vector.LoadOp(
                    v4, buf.smem,
                    [self.to_index(arith.addi(
                        off_v, self.c_i32(kk * n + j4 * 4)))]).result
                    for j4 in range(n // 4)]
            av = self.splat(v4, vector.extract(a.val, [], [kk]))
            for j4 in range(n // 4):
                sl = vector.extract_strided_slice(v4, out, [j4 * 4], [4],
                                                  [1])
                sl = vector.fma(av, bfr[j4], sl)
                out = vector.insert_strided_slice(sl, out, [j4 * 4], [1])
        after()
        return Tensor(tl.float32, (bm, n), out_lay, out, n)

    # -- first-class smem buffers + raw async copies -------------------

    def smem_alloc(self, shape, dtype) -> SmemBuf:
        """tl.smem(shape, dtype): allocate one user-held smem staging
        buffer (raw row-major, unswizzled). 2D tiles, f32/f16/bf16/i32;
        the 48KB static budget is enforced (TileConfigError)."""
        shape = tuple(shape)
        if len(shape) != 2 or any(not isinstance(s, int) or s <= 0
                                  for s in shape):
            raise TileConfigError(
                f"tl.smem needs a positive 2D shape, got {shape}")
        if dtype not in (tl.float32, tl.float16, tl.bfloat16, tl.int32):
            raise TileConfigError(
                f"tl.smem currently supports f32/f16/bf16/i32, got {dtype}")
        seq = getattr(self, "_userbuf_seq", 0)
        self._userbuf_seq = seq + 1
        smem = self._scratch_smem(f"userbuf{seq}", shape[0] * shape[1],
                                  dtype)
        return SmemBuf(smem, shape, dtype)

    def async_copy(self, buf: SmemBuf, pt: PtrTensor, mask=None,
                   even: bool = False, trans: bool = False,
                   offset: Scalar | None = None) -> AsyncTok:
        """tl.async_copy(buf, ptr_tile, MASK=, EVEN=, TRANS=): raw cp.async
        copy of one global tile into a user smem buffer, linear row-major
        (NO mma swizzle). MASK's row preds zfill; EVEN takes the 16B path
        (mask must be None, non-TRANS only); TRANS writes the (R, C) tile
        into a (C, R) buffer (4B scalar copies only). The caller orders
        consumption with tl.async_wait + tl.barrier."""
        want_shape = (buf.shape[1], buf.shape[0]) if trans else buf.shape
        if tuple(pt.off.shape) != tuple(want_shape):
            # subtile staging: a smaller tile is allowed whenever it
            # fits (OFFSET lands it inside; offset None = offset 0)
            if pt.off.shape[0] * pt.off.shape[1] > \
                    buf.shape[0] * buf.shape[1]:
                raise TileConfigError(
                    f"tl.async_copy: tile {pt.off.shape} != buffer "
                    f"{buf.shape}{' (TRANS)' if trans else ''} and does "
                    "not fit as a subtile either")
        if pt.arg.elem != buf.dtype:
            raise TileConfigError(
                f"tl.async_copy: dtype mismatch {pt.arg.elem} vs "
                f"{buf.dtype}")
        if not (isinstance(pt.off.col.stride, int)
                and pt.off.col.stride == 1):
            raise TileConfigError("tl.async_copy needs unit column stride")
        if mask is not None and not isinstance(mask, SepMask):
            raise TileConfigError(
                "tl.async_copy masks must be row-predicate SepMasks")
        if mask is not None and mask.col_preds:
            raise TileConfigError(
                "tl.async_copy currently supports row-predicate masks only")
        if trans and even:
            raise TileConfigError(
                "tl.async_copy TRANS excludes EVEN (transposed copies are "
                "4B scalar by construction)")
        rows, cols = pt.off.shape
        if trans:
            nt = self.num_threads
            c = self.c_i32
            tid = self.tid()
            if rows * cols % nt:
                raise TileConfigError(
                    f"tl.async_copy TRANS: {want_shape} does not "
                    f"distribute over {nt} threads")
            toks = []
            for j in range(rows * cols // nt):
                cc = arith.addi(tid, c(j * nt))
                kk = arith.remsi(cc, c(cols))
                nn = arith.divsi(cc, c(cols))
                src = arith.addi(
                    self.eval_affine(pt.off.row, nn),
                    self.eval_affine(pt.off.col, kk))
                dst = arith.addi(arith.muli(kk, c(rows)), nn)
                if offset is not None:
                    dst = arith.addi(dst, offset.val)
                ok = None
                for p in (mask.row_preds if mask is not None else []):
                    s = self._pred_scalar(p, nn)
                    ok = s if ok is None else self.and_i1(ok, s)
                if ok is not None:
                    se = self.select(ok, self.c_idx(1), self.c_idx(0))
                    src = self.select(ok, src, c(0))
                else:
                    se = self.c_idx(1)
                toks.append(nvgpu.device_async_copy(
                    buf.smem, [self.to_index(dst)], pt.arg.scalar_view,
                    [self.to_index(src)], 1, src_elements=se))
            return AsyncTok(nvgpu.device_async_create_group(toks), buf,
                            offset if offset is not None else
                            Scalar(tl.int32, self.c_i32(0)))
        rows, cols = pt.off.shape
        v16, gran = 16 // buf.dtype.itemsize, 2
        nt = self.num_threads
        c = self.c_i32
        tid = self.tid()
        toks = []
        if even:
            if mask is not None:
                raise TileConfigError("tl.async_copy: EVEN excludes a mask")
            if (cols * buf.dtype.itemsize) % 16:
                raise TileConfigError(
                    f"tl.async_copy EVEN needs 16B-aligned rows "
                    f"(cols*itemsize = {cols * buf.dtype.itemsize})")
            if rows * (cols // v16) % nt:
                raise TileConfigError(
                    f"tl.async_copy: {buf.shape} does not distribute over "
                    f"{nt} threads in 16B chunks")
            for j in range(rows * (cols // v16) // nt):
                cc = arith.addi(tid, c(j * nt))
                row = arith.divsi(cc, c(cols // v16))
                jc = arith.remsi(cc, c(cols // v16))
                src = arith.addi(
                    self.eval_affine(pt.off.row, row),
                    self.eval_affine(pt.off.col, arith.muli(jc, c(v16))))
                dst = arith.addi(arith.muli(row, c(cols)),
                                 arith.muli(jc, c(v16)))
                if offset is not None:
                    dst = arith.addi(dst, offset.val)
                op = nvgpu.device_async_copy(
                    buf.smem, [self.to_index(dst)], pt.arg.scalar_view,
                    [self.to_index(src)], v16, bypass_l1=True)
                if self._wir_annotate_on():
                    from .wir import form_add, form_const, form_div, \
                        form_mod, form_mul
                    fcc = form_add(TID, form_const(j * nt))
                    fdst = form_add(
                        form_mul(form_div(fcc, cols // v16),
                                 form_const(cols)),
                        form_mul(form_mod(fcc, cols // v16),
                                 form_const(v16)))
                    self._wir_attr(op, self._wir_smem_role(buf.smem),
                                   fdst, v16)
                toks.append(op)
        else:
            upr = cols // gran
            if cols % gran:
                raise TileConfigError(
                    f"tl.async_copy: odd column count {cols} does not fit "
                    f"the {gran}-elem copy unit (the tail column would be "
                    "silently dropped)")
            if rows * upr % nt:
                raise TileConfigError(
                    f"tl.async_copy: {buf.shape} does not distribute over "
                    f"{nt} threads in {gran}-elem units")
            for j in range(rows * upr // nt):
                u = arith.addi(tid, c(j * nt))
                row = arith.divsi(u, c(upr))
                nn0 = arith.muli(arith.remsi(u, c(upr)), c(gran))
                src = arith.addi(self.eval_affine(pt.off.row, row),
                                 self.eval_affine(pt.off.col, nn0))
                ok = None
                for p in (mask.row_preds if mask is not None else []):
                    s = self._pred_scalar(p, row)
                    ok = s if ok is None else self.and_i1(ok, s)
                if ok is not None:
                    se = self.select(ok, self.c_idx(gran), self.c_idx(0))
                    src = self.select(ok, src, c(0))
                else:
                    se = self.c_idx(gran)
                dst = arith.addi(arith.muli(row, c(cols)), nn0)
                if offset is not None:
                    dst = arith.addi(dst, offset.val)
                op = nvgpu.device_async_copy(
                    buf.smem, [self.to_index(dst)], pt.arg.scalar_view,
                    [self.to_index(src)], gran, src_elements=se)
                if self._wir_annotate_on():
                    from .wir import form_add, form_const, form_div, \
                        form_mod, form_mul
                    fu = form_add(TID, form_const(j * nt))
                    fdst = form_add(
                        form_mul(form_div(fu, upr), form_const(cols)),
                        form_mul(form_mod(fu, upr), form_const(gran)))
                    self._wir_attr(op, self._wir_smem_role(buf.smem),
                                   fdst, gran)
                toks.append(op)
        return AsyncTok(nvgpu.device_async_create_group(toks), buf,
                        offset if offset is not None else
                        Scalar(tl.int32, self.c_i32(0)))

    def barrier(self):
        """tl.barrier(): block-wide sync (bar.sync) — the raw smem
        handshake: async_wait orders the COPY, barrier publishes the
        smem contents to every thread (and orders buffer reuse)."""
        gpu.barrier()

    def load_smem(self, buf: SmemBuf) -> Tensor:
        """tl.load_smem(buf): read the whole tile back as a block value in
        the default layout for the shape; emission is scalar LDS."""
        layout = self.choose_layout(buf.shape)
        ept = vec_ept(layout)
        rows, cols = buf.shape
        elem = buf.dtype
        c = self.c_i32

        def ld(r, col, form):
            addr = arith.addi(arith.muli(c(r), c(cols)), col) \
                if isinstance(r, int) else arith.addi(
                    arith.muli(r, c(cols)), col)
            op = memref.LoadOp(buf.smem, [self.to_index(addr)])
            self._wir_attr(op, self._wir_smem_role(buf.smem), form, 1)
            return op.result

        if is_rep_like(layout):
            vty = ir.VectorType.get([rows, cols], elem.mlir())
            res = self.dense_const(vty, elem, 0)
            for r, cc in itertools.product(range(rows), range(cols)):
                res = vector.insert(
                    ld(r, c(cc), FC(r * cols + cc)), res, [], [r, cc])
            return Tensor(elem, buf.shape, layout, res, ept)
        if is_flat(layout):
            base = arith.muli(self.tid(), c(ept))
            rho = arith.divsi(base, c(cols))
            gamma = arith.remsi(base, c(cols))
            res = self.dense_const(ir.VectorType.get([ept], elem.mlir()),
                                   elem, 0)
            for j in range(ept):
                res = vector.insert(
                    ld(rho, arith.addi(gamma, c(j)),
                       FA(FM(TID, FC(ept)), FC(j))),
                    res, [], [j])
            return Tensor(elem, buf.shape, layout, res, ept)
        # dist: all rows, ept contiguous columns per thread
        col0 = arith.muli(self.tid(), c(ept))
        vty = ir.VectorType.get([rows, ept], elem.mlir())
        res = self.dense_const(vty, elem, 0)
        for r in range(rows):
            for j in range(ept):
                res = vector.insert(
                    ld(r, arith.addi(col0, c(j)),
                       FA(FC(r * cols), FA(FM(TID, FC(ept)), FC(j)))),
                    res, [], [r, j])
        return Tensor(elem, buf.shape, layout, res, ept)

    def store_smem(self, buf: SmemBuf, v: Tensor):
        """tl.store_smem(buf, v): write a block value into the buffer in
        the value's layout (dist/flat/rep; scalar STS). Pair with
        tl.barrier before other threads read."""
        if tuple(v.shape) != tuple(buf.shape):
            raise TileConfigError(
                f"tl.store_smem: value {v.shape} != buffer {buf.shape}")
        if v.dtype != buf.dtype:
            raise TileConfigError(
                f"tl.store_smem: dtype mismatch {v.dtype} vs {buf.dtype}")
        rows, cols = buf.shape
        ept = v.ept
        c = self.c_i32

        def st(r, col, val, form):
            addr = arith.addi(arith.muli(c(r), c(cols)), col) \
                if isinstance(r, int) else arith.addi(
                    arith.muli(r, c(cols)), col)
            op = memref.StoreOp(val, buf.smem, [self.to_index(addr)])
            self._wir_attr(op, self._wir_smem_role(buf.smem), form, 1)

        layout = v.layout
        if is_rep_like(layout):
            for r, cc in itertools.product(range(rows), range(cols)):
                st(r, c(cc), vector.extract(v.val, [], [r, cc]),
                   FC(r * cols + cc))
            return
        if is_flat(layout):
            base = arith.muli(self.tid(), c(ept))
            rho = arith.divsi(base, c(cols))
            gamma = arith.remsi(base, c(cols))
            for j in range(ept):
                st(rho, arith.addi(gamma, c(j)),
                   vector.extract(v.val, [], [j]),
                   FA(FM(TID, FC(ept)), FC(j)))
            return
        if not is_dist(layout):
            raise TileConfigError(
                f"tl.store_smem: unsupported value layout {layout!r}")
        col0 = arith.muli(self.tid(), c(ept))
        for r in range(rows):
            for j in range(ept):
                st(r, arith.addi(col0, c(j)),
                   vector.extract(v.val, [], [r, j]),
                   FA(FC(r * cols), FA(FM(TID, FC(ept)), FC(j))))

    def _mma_pipe_checks(self, a: Tensor, k_dim: int, bn: int):
        """Shared tl.mma operand checks -> (atom, am, ak, an, c_lay)."""
        if not isinstance(a, Tensor) or not isinstance(a.layout, Fragment) \
                or a.layout.role != "A":
            raise TileConfigError(
                f"tl.mma: a must be a Fragment('A') value, got {a!r}")
        if a.dtype != tl.int32:
            raise TileConfigError(
                "tl.mma: a must be packed operand registers (i32) — a "
                "LAYOUT=Fragment(A) load or a frag_c_to_a conversion")
        atom = mma_atom(a.layout.atom)
        if atom.kind not in ("bf16", "tf32"):
            raise TileConfigError(
                f"tl.mma currently supports bf16/tf32 atoms, got {atom.kind}")
        wn_m, wn_n = a.layout.warps
        if wn_n != 1 or wn_m != self.num_threads // 32:
            raise TileConfigError(
                "tl.mma: a layout must be the warp-slab (num_warps, 1) grid")
        bm = a.layout.shape[0]
        am, ak = a.layout.atoms
        if k_dim != a.layout.shape[1]:
            raise TileConfigError(
                f"tl.mma: K mismatch a {a.layout.shape} vs b K={k_dim}")
        if ak * atom.k != k_dim or bn % atom.n:
            raise TileConfigError(
                f"tl.mma: b tile {(k_dim, bn)} is not a whole number of "
                f"atoms for {a.layout!r}")
        an = bn // atom.n
        c_lay = Fragment((bm, bn), a.layout.atom, "C",
                         (self.num_threads // 32, 1), (am, an))
        return atom, am, ak, an, c_lay

    def _mma_on_smem(self, a: Tensor, smem, k_dim: int, bn: int,
                     trans: bool, acc: Tensor | None, atom, am, ak, an,
                     c_lay, offset=None) -> Tensor:
        """The tl.mma compute half: fragment reads of the staged B tile +
        the h-ascending mma loop (shared by the sync and pipelined
        forms)."""
        if acc is not None:
            if not isinstance(acc, Tensor) or acc.layout != c_lay:
                raise TileConfigError(
                    f"tl.mma: acc must be the {c_lay!r} accumulator, got "
                    f"{acc!r}")
        nc = am * an * 4
        c = self.c_i32
        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        g = arith.divsi(lane, c(4))
        t = arith.remsi(lane, c(4))
        vS = ir.VectorType.get([nc], self.f32)
        acc_const = acc is not None and self._is_constant_val(acc.val)
        if acc is None or acc_const:
            # 0.0 * runtime tid: keeps the first mma round's C operands
            # off the integer-only "n" constraint nvvm assigns to
            # constants (the value is +0.0 exactly).
            z = arith.mulf(self.dense_const(vS, tl.float32, 0.0),
                           self.splat(vS, arith.sitofp(self.f32, tid)))
            s = z if acc is None else arith.addf(acc.val, z)
        else:
            s = acc.val
        cols = k_dim if trans else bn
        # XOR-swizzle mask on 16B-chunk indices (chunk ^ (row & swz)):
        # chunks-1 keeps the XOR inside the (power-of-two) chunk row;
        # 15 caps the pattern at the row's low 4 bits (16-row period,
        # spanning <= 16 chunks = 256B)
        swz = min(cols // atom.v16 - 1, 15)
        base_off = offset.val if offset is not None else c(0)
        base = self._mma_smem_i32(smem, base_off, atom.elem.itemsize)
        for h in range(ak):
            bfs = []
            for in_ in range(an):
                if trans:
                    regs = self._mma_frag_b(atom, smem, base_off, k_dim, bn,
                                            0, swz, g, t, c(0), h, in_, True)
                elif atom.kind == "bf16":
                    regs = self._mma_frag_b_ldsm(atom, base, bn, swz, lane,
                                                 c(0), h, in_)
                else:
                    # tf32 B stays per-lane (a 4B operand spans two b16
                    # columns; ldmatrix can't make that fragment)
                    regs = self._mma_frag_b(atom, smem, base_off, k_dim, bn,
                                            swz, 0, g, t, c(0), h, in_, False)
                if atom.cvt:
                    regs = [self._mma_cvt_tf32(r) for r in regs]
                bfs.append(regs)
            for im in range(am):
                aregs = [vector.extract(a.val, [], [(im * ak + h) * 4 + j])
                         for j in range(4)]
                for in_ in range(an):
                    i0 = (im * an + in_) * 4
                    cregs = [vector.extract(s, [], [i0 + j0])
                             for j0 in range(4)]
                    d = self._mma_sync(atom, aregs, bfs[in_], cregs)
                    for j0 in range(4):
                        s = vector.insert(d[j0], s, [], [i0 + j0])
        gpu.barrier()
        return Tensor(tl.float32, (c_lay.shape[0], bn), c_lay, s, nc)

    def mma(self, a: Tensor, b, acc: Tensor | None = None, *,
            trans_b: bool = False, mask=None, even: bool = False,
            pending: int | None = None) -> Tensor:
        """One (BM, K) x (K, BN) mma tile (tl.mma). `a`: register-resident
        Fragment("A") (layout-requested load or frag_c_to_a convert); `b`:
        PtrTensor (staged synchronously via cp.async; trans_b/MASK/EVEN
        apply) or AsyncTok from tl.async_stage (waits with `pending`
        newer groups allowed). Returns the (BM, BN) f32 Fragment("C")
        accumulator; acc chains another mma's result in."""
        if isinstance(b, AsyncTok):
            if pending is None:
                raise TileConfigError(
                    "tl.mma on a pipeline promise needs PENDING=<newer "
                    "groups allowed in flight>")
            pipe = b.pipe
            if not isinstance(pipe, StagePipe):
                raise TileConfigError(
                    "tl.mma consumes tl.async_stage (StagePipe) promises; "
                    "raw tl.async_copy tokens only feed tl.async_wait")
            dims = b.shape or ((pipe.cols, pipe.rows) if pipe.trans else
                               (pipe.rows, pipe.cols))
            k_dim, bn = (dims[1], dims[0]) if pipe.trans else dims
            atom, am, ak, an, c_lay = self._mma_pipe_checks(a, k_dim, bn)
            nvgpu.device_async_wait(b.val, num_groups=pending)
            gpu.barrier()
            return self._mma_on_smem(a, pipe.smem, k_dim, bn, pipe.trans,
                                     acc, atom, am, ak, an, c_lay,
                                     offset=b.offset)
        b_pt = b
        if pending is not None:
            raise TileConfigError("tl.mma: PENDING is a pipeline-promise "
                                  "kwarg (b is a pointer tile)")
        if not isinstance(b_pt, PtrTensor):
            raise TileConfigError(
                f"tl.mma b must be a pointer tile or an AsyncTok, got "
                f"{b_pt!r}")
        k_dim, bn = b_pt.off.shape
        atom, am, ak, an, c_lay = self._mma_pipe_checks(a, k_dim, bn)
        if b_pt.arg.elem != atom.elem:
            raise TileConfigError(
                f"tl.mma: b must be {atom.elem}, got {b_pt.arg.elem}")
        unit = b_pt.off.row.stride if trans_b else b_pt.off.col.stride
        if not (isinstance(unit, int) and unit == 1):
            raise TileConfigError(
                "tl.mma: b needs unit stride along its contiguous dim")
        tid = self.tid()
        rows, cols = (bn, k_dim) if trans_b else (k_dim, bn)
        smem = self._scratch_smem("mma_b_stage", rows * cols, atom.elem)
        grp = nvgpu.device_async_create_group(
            self._mma_stage_tile(b_pt, smem, rows, cols, trans_b, mask,
                                 even, tid))
        nvgpu.device_async_wait(grp, num_groups=0)
        gpu.barrier()
        return self._mma_on_smem(a, smem, k_dim, bn, trans_b, acc, atom,
                                 am, ak, an, c_lay)

    def materialize_to(self, off: SepOff, layout: Layout) -> Tensor:
        """Symbolic offsets as an i32 block value in a requested layout
        (tl.materialize(offs, LAYOUT=...)): per owned element, the affine
        forms evaluated at its coordinates. Broadcast forms materialize
        NARROW: offs_m[:, None] -> Sliced(Fragment, 1), offs_n[None, :]
        -> Sliced(Fragment, 0) (triton slice-layout semantics)."""
        if not isinstance(off, SepOff):
            raise TileConfigError(
                f"tl.materialize expects a symbolic offset, got {off!r}")
        if len(off.shape) != 2:
            raise TileConfigError(
                "tl.materialize to a layout expects a 2D offset "
                "(use [:, None] / [None, :] broadcast forms)")
        if isinstance(layout, Blocked) and is_t3(layout):
            # the (BM, 1) row coordinate of a row-per-thread tile: one
            # scalar per thread (its own row)
            if not (off.shape[1] == 1
                    and off.shape[0] == layout.shape[0]
                    and layout.size_per_thread[0] == 1):
                raise TileConfigError(
                    f"tl.materialize to a t3 layout takes the "
                    f"({layout.shape[0]}, 1) row form, got {off.shape}")
            v = self.eval_affine(off.row, self.tid())
            v = arith.addi(v, self.eval_affine(off.col, 0))
            out = self.dense_const(ir.VectorType.get([1], self.i32),
                                   tl.int32, 0)
            out = vector.insert(v, out, [], [0])
            return Tensor(tl.int32, layout.shape, layout, out, 1)
        if not isinstance(layout, Fragment) or layout.role != "C":
            raise TileConfigError(
                f"tl.materialize currently supports Fragment('C') destinations, "
                f"got {layout!r}")
        (wn_m, wn_n), (am, an) = layout.warps, layout.atoms
        wa_m = layout.shape[0] // wn_m
        wa_n = layout.shape[1] // wn_n
        c = self.c_i32
        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        warp = arith.divsi(tid, c(32))
        g = arith.divsi(lane, c(4))
        t = arith.remsi(lane, c(4))
        wy = arith.divsi(warp, c(wn_n))
        wx = arith.remsi(warp, c(wn_n))

        def narrow(dim: int) -> Tensor:
            nreg = am * 2 if dim == 1 else an * 2
            out = self.dense_const(ir.VectorType.get([nreg], self.i32),
                                   tl.int32, 0)
            if dim == 1:
                if off.shape[0] != layout.shape[0] or off.shape[1] != 1:
                    raise TileConfigError(
                        f"tl.materialize: offset {off.shape} is not the "
                        f"({layout.shape[0]}, 1) row form")
                j = 0
                for im in range(am):
                    for half in range(2):
                        row_g = arith.addi(
                            arith.addi(arith.muli(wy, c(wa_m)),
                                       c(im * 16 + 8 * half)), g)
                        v = self.eval_affine(off.row, row_g)
                        v = arith.addi(v, self.eval_affine(off.col, 0))
                        out = vector.insert(v, out, [], [j])
                        j += 1
                shape = (layout.shape[0], 1)
            else:
                if off.shape != (1, layout.shape[1]):
                    raise TileConfigError(
                        f"tl.materialize: offset {off.shape} is not the "
                        f"(1, {layout.shape[1]}) column form")
                j = 0
                for in_ in range(an):
                    for jj in range(2):
                        col = arith.addi(
                            arith.addi(arith.muli(wx, c(wa_n)),
                                       c(in_ * 8 + jj)),
                            arith.muli(t, c(2)))
                        v = self.eval_affine(off.row, 0)
                        v = arith.addi(v, self.eval_affine(off.col, col))
                        out = vector.insert(v, out, [], [j])
                        j += 1
                shape = (1, layout.shape[1])
            return Tensor(tl.int32, shape, Sliced(layout, dim), out, nreg)

        if off.shape[1] == 1:
            return narrow(1)
        if off.shape[0] == 1:
            return narrow(0)
        # the full (BM, BN) form: every fragment element's coordinate
        if tuple(off.shape) != tuple(layout.shape):
            raise TileConfigError(
                f"tl.materialize: offset shape {off.shape} does not "
                f"match {layout.shape}")
        nc = am * an * 4
        out = self.dense_const(ir.VectorType.get([nc], self.i32),
                               tl.int32, 0)
        for im in range(am):
            for in_ in range(an):
                for half in range(2):
                    row_g = arith.addi(
                        arith.addi(arith.muli(wy, c(wa_m)),
                                   c(im * 16 + 8 * half)), g)
                    for jj in range(2):
                        col = arith.addi(
                            arith.addi(arith.muli(wx, c(wa_n)),
                                       c(in_ * 8 + jj)),
                            arith.muli(t, c(2)))
                        v = self.eval_affine(off.row, row_g)
                        v = arith.addi(v, self.eval_affine(off.col, col))
                        out = vector.insert(
                            v, out, [], [(im * an + in_) * 4 + half * 2 + jj])
        return Tensor(tl.int32, layout.shape, layout, out, nc)

    def _store_frag_stat(self, pt, value: Tensor, mask=None):
        """Store a narrow Sliced(Fragment, dim) statistic to its (BM,)/
        (BN,) global tile (the lse form): values are replicated across
        the quad, so one lane per quad (t == 0) writes each scalar
        (dim=1: per-row; dim=0: per-column), preds guarding."""
        lay = value.layout
        if not (isinstance(lay, Sliced)
                and isinstance(lay.parent, Fragment)):
            raise TileConfigError(
                f"fragment stat store expects a Sliced(Fragment) value, "
                f"got {value!r}")
        frag = lay.parent
        (wn_m, wn_n), (am, an) = frag.warps, frag.atoms
        wa_m = frag.shape[0] // wn_m
        wa_n = frag.shape[1] // wn_n
        c = self.c_i32
        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        warp = arith.divsi(tid, c(32))
        g = arith.divsi(lane, c(4))
        t = arith.remsi(lane, c(4))
        wy = arith.divsi(warp, c(wn_n))
        wx = arith.remsi(warp, c(wn_n))
        is_t0 = self.compare("==", t, c(0), tl.int32)
        off = pt.off

        def emit_scalar(addr, ok, j):
            if_op = scf.IfOp(ok, [], has_else=False)
            with ir.InsertionPoint(_ensure_block(if_op.regions[0])):
                memref.StoreOp(vector.extract(value.val, [], [j]),
                               pt.arg.scalar_view, [self.to_index(addr)])
                scf.YieldOp([])

        if lay.dim == 1:
            if tuple(off.shape) != (frag.shape[0], 1):
                raise TileConfigError(
                    f"fragment stat store: tile {off.shape} is not "
                    f"({frag.shape[0]}, 1)")
            for im in range(am):
                for half in range(2):
                    row = arith.addi(
                        arith.addi(arith.muli(wy, c(wa_m)),
                                   c(im * 16 + 8 * half)), g)
                    ok = is_t0
                    for p in (mask.row_preds if mask is not None else []):
                        ok = self.and_i1(ok, self._pred_scalar(p, row))
                    addr = arith.addi(self.eval_affine(off.row, row),
                                      self.eval_affine(off.col, 0))
                    emit_scalar(addr, ok, im * 2 + half)
        else:
            if tuple(off.shape) != (1, frag.shape[1]):
                raise TileConfigError(
                    f"fragment stat store: tile {off.shape} is not "
                    f"(1, {frag.shape[1]})")
            for in_ in range(an):
                for jj in range(2):
                    col = arith.addi(
                        arith.addi(arith.muli(wx, c(wa_n)),
                                   c(in_ * 8 + jj)),
                        arith.muli(t, c(2)))
                    ok = is_t0
                    for p in (mask.col_preds if mask is not None else []):
                        ok = self.and_i1(ok, self._pred_scalar(p, col))
                    addr = arith.addi(self.eval_affine(off.row, 0),
                                      self.eval_affine(off.col, col))
                    emit_scalar(addr, ok, in_ * 2 + jj)

    def _load_frag_stat(self, pt, layout: Fragment, dim: int, mask,
                        other_v):
        """Row/column statistics of an mma tile as the NARROW
        Sliced(Fragment, dim) value (tl.load of a (BM,1)/(1,BN) pointer
        tile with LAYOUT=Fragment("C")): per-lane scalar loads at the
        fragment's own row (dim=1) or column (dim=0) coordinates; the
        mask's preds guard each load (out-of-bound takes `other`)."""
        (wn_m, wn_n), (am, an) = layout.warps, layout.atoms
        wa_m = layout.shape[0] // wn_m
        wa_n = layout.shape[1] // wn_n
        elem = pt.arg.elem
        c = self.c_i32
        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        warp = arith.divsi(tid, c(32))
        g = arith.divsi(lane, c(4))
        t = arith.remsi(lane, c(4))
        wy = arith.divsi(warp, c(wn_n))
        wx = arith.remsi(warp, c(wn_n))
        off = pt.off

        def guard(preds, coord):
            ok = None
            for p in preds:
                s = self._pred_scalar(p, coord)
                ok = s if ok is None else self.and_i1(ok, s)
            return ok

        vals = []
        if dim == 1:
            if tuple(off.shape) != (layout.shape[0], 1):
                raise TileConfigError(
                    f"fragment stat load: tile {off.shape} is not "
                    f"({layout.shape[0]}, 1)")
            preds = () if mask is None else mask.row_preds
            for im in range(am):
                for half in range(2):
                    row = arith.addi(
                        arith.addi(arith.muli(wy, c(wa_m)),
                                   c(im * 16 + 8 * half)), g)
                    addr = arith.addi(self.eval_affine(off.row, row),
                                      self.eval_affine(off.col, 0))
                    ok = guard(preds, row)
                    if ok is not None:
                        addr = self.select(ok, addr, c(0))
                    v = memref.LoadOp(pt.arg.scalar_view,
                                      [self.to_index(addr)]).result
                    vals.append(self.select(ok, v, other_v)
                                if ok is not None else v)
        else:
            if tuple(off.shape) != (1, layout.shape[1]):
                raise TileConfigError(
                    f"fragment stat load: tile {off.shape} is not "
                    f"(1, {layout.shape[1]})")
            preds = () if mask is None else mask.col_preds
            for in_ in range(an):
                for jj in range(2):
                    col = arith.addi(
                        arith.addi(arith.muli(wx, c(wa_n)),
                                   c(in_ * 8 + jj)),
                        arith.muli(t, c(2)))
                    addr = arith.addi(self.eval_affine(off.row, 0),
                                      self.eval_affine(off.col, col))
                    ok = guard(preds, col)
                    if ok is not None:
                        addr = self.select(ok, addr, c(0))
                    v = memref.LoadOp(pt.arg.scalar_view,
                                      [self.to_index(addr)]).result
                    vals.append(self.select(ok, v, other_v)
                                if ok is not None else v)
        lay = Sliced(layout, dim)
        shape = (layout.shape[0], 1) if dim == 1 else (1, layout.shape[1])
        nreg = len(vals)
        out = self.dense_const(ir.VectorType.get([nreg], elem.mlir()),
                               elem, 0)
        for j, v in enumerate(vals):
            out = vector.insert(v, out, [], [j])
        return Tensor(elem, shape, lay, out, nreg)

    def _load_frag_c(self, pt, layout: Fragment, mask):
        """tl.load with LAYOUT=tl.mma_layout("C", ...) on a full (BM, BN)
        tile: lands directly in the mma C fragment (store_m4's load-twin).
        f32 planes load scalar pairs; bf16 planes unpack each 4B pair to
        two f32. Masked lanes zfill (`other` must be omitted)."""
        atom = mma_atom(layout.atom)
        if layout.role != "C":
            raise TileConfigError(
                f"fragment C load supports role 'C', got {layout.role!r}")
        elem = pt.arg.elem
        if elem not in (tl.float32, tl.bfloat16):
            raise TileConfigError(
                f"fragment C load: plane must be f32/bf16, got {elem}")
        (wn_m, wn_n), (am, an) = layout.warps, layout.atoms
        wa_m = layout.shape[0] // wn_m
        wa_n = layout.shape[1] // wn_n
        off = pt.off
        if tuple(off.shape) != tuple(layout.shape):
            raise TileConfigError(
                f"fragment C load: tile {off.shape} != layout "
                f"{layout.shape}")
        if not (isinstance(off.col.stride, int) and off.col.stride == 1):
            raise TileConfigError("fragment C load needs unit column stride")
        if mask is not None and not isinstance(mask, SepMask):
            raise TileConfigError(
                "fragment C load masks must be symbolic (SepMask)")
        c = self.c_i32
        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        warp = arith.divsi(tid, c(32))
        g = arith.divsi(lane, c(4))
        t = arith.remsi(lane, c(4))
        wy = arith.divsi(warp, c(wn_n))
        wx = arith.remsi(warp, c(wn_n))
        zero = self.const(tl.float32, 0.0)

        def guard(preds, coord):
            ok = None
            for p in preds:
                s = self._pred_scalar(p, coord)
                ok = s if ok is None else self.and_i1(ok, s)
            return ok

        rp = () if mask is None else mask.row_preds
        cp = () if mask is None else mask.col_preds
        nc = am * an * 4
        v2b = ir.VectorType.get([2], tl.bfloat16.mlir())
        out = self.dense_const(ir.VectorType.get([nc], self.f32),
                               tl.float32, 0.0)
        for im in range(am):
            for in_ in range(an):
                col0 = arith.addi(arith.muli(wx, c(wa_n)),
                                  arith.addi(c(in_ * atom.n),
                                             arith.muli(t, c(2))))
                for half in range(2):
                    row = arith.addi(
                        arith.addi(arith.muli(wy, c(wa_m)),
                                   c(im * 16 + 8 * half)), g)
                    addr = arith.addi(self.eval_affine(off.row, row),
                                      self.eval_affine(off.col, col0))
                    ok = guard(rp, row)
                    okc0 = guard(cp, col0)
                    okc1 = guard(cp, arith.addi(col0, c(1)))
                    ok0 = ok if okc0 is None else (
                        okc0 if ok is None else self.and_i1(ok, okc0))
                    ok1 = ok if okc1 is None else (
                        okc1 if ok is None else self.and_i1(ok, okc1))
                    i0 = (im * an + in_) * 4 + 2 * half
                    if elem == tl.float32:
                        if ok0 is None and ok1 is None:
                            x0 = memref.LoadOp(
                                pt.arg.scalar_view,
                                [self.to_index(addr)]).result
                            x1 = memref.LoadOp(
                                pt.arg.scalar_view,
                                [self.to_index(arith.addi(addr, c(1)))]
                            ).result
                        else:
                            safe0 = self.select(ok0, addr, c(0)) \
                                if ok0 is not None else addr
                            safe1 = self.select(ok1, addr, c(0)) \
                                if ok1 is not None else addr
                            x0 = memref.LoadOp(
                                pt.arg.scalar_view,
                                [self.to_index(safe0)]).result
                            x1 = memref.LoadOp(
                                pt.arg.scalar_view,
                                [self.to_index(arith.addi(safe1, c(1)))]
                            ).result
                            if ok0 is not None:
                                x0 = self.select(ok0, x0, zero)
                            if ok1 is not None:
                                x1 = self.select(ok1, x1, zero)
                    else:
                        # bf16 plane: one 4B pair -> two f32
                        okb = ok0 if ok1 is None else (
                            ok1 if ok0 is None else self.and_i1(ok0, ok1))
                        if okb is not None:
                            addr = self.select(okb, addr, c(0))
                        vec = vector.LoadOp(
                            v2b, pt.arg.scalar_view,
                            [self.to_index(addr)]).result
                        x0 = arith.extf(self.f32, vector.extract(vec, [],
                                                                 [0]))
                        x1 = arith.extf(self.f32, vector.extract(vec, [],
                                                                 [1]))
                        if ok0 is not None:
                            x0 = self.select(ok0, x0, zero)
                        if ok1 is not None:
                            x1 = self.select(ok1, x1, zero)
                    out = vector.insert(x0, out, [], [i0])
                    out = vector.insert(x1, out, [], [i0 + 1])
        return Tensor(tl.float32, layout.shape, layout, out, nc)

    def _frag_elem(self, v: Tensor, lay: Fragment, im: int, in_: int,
                   half: int, jj: int):
        """Extract this lane's element (im, in_, half, jj) of a value
        broadcast against the mma C fragment ``lay``: full fragment,
        Sliced(Fragment, 1), or Sliced(Fragment, 0)."""
        if v.layout == lay:
            return vector.extract(
                v.val, [], [(im * lay.atoms[1] + in_) * 4 + half * 2 + jj])
        if isinstance(v.layout, Sliced) and v.layout.parent == lay:
            return vector.extract(
                v.val, [], [im * 2 + half if v.layout.dim == 1
                            else in_ * 2 + jj])
        raise TileConfigError(
            f"value {v!r} does not broadcast against {lay!r}")

    def binop_frag(self, op: str, x: Tensor, y: Tensor,
                   compare: bool = False) -> Tensor:
        """Elementwise binop/compare over an mma C fragment and anything
        broadcastable against it (the other fragment or narrow
        Sliced(Fragment, dim) statistics)."""
        if isinstance(x.layout, Sliced) and x.layout == y.layout \
                and isinstance(x.layout.parent, Fragment):
            # two narrow statistics of the same parent/dim: the result
            # stays narrow (per-element op on the stat vectors)
            if op in ("and", "or"):
                dt = tl.int1
                if x.dtype != tl.int1 or y.dtype != tl.int1:
                    raise TileConfigError(f"fragment {op} needs i1 "
                                          "operands")
            else:
                dt = x.dtype if x.dtype == y.dtype else None
                if dt is None:
                    raise TileConfigError(
                        f"fragment elementwise dtype mismatch: {x.dtype} "
                        f"vs {y.dtype} (cast explicitly)")
            rdt = tl.int1 if compare else dt
            if compare:
                v = self.compare(op, x.val, y.val, dt)
            elif op == "and":
                v = self.and_i1(x.val, y.val)
            elif op == "or":
                v = arith.ori(x.val, y.val)
            else:
                v = self.binary(op, x.val, y.val, dt)
            return Tensor(rdt, x.shape, x.layout, v, x.ept)
        lay = x.layout if isinstance(x.layout, Fragment) else \
            (y.layout if isinstance(y.layout, Fragment) else
             x.layout.parent)
        if not isinstance(lay, Fragment) or lay.role != "C":
            raise TileConfigError(
                f"fragment elementwise needs a common Fragment('C'), got "
                f"{x.layout!r} vs {y.layout!r}")
        am, an = lay.atoms
        if op in ("and", "or"):
            dt = tl.int1
            if x.dtype != tl.int1 or y.dtype != tl.int1:
                raise TileConfigError(f"fragment {op} needs i1 operands")
        else:
            dt = x.dtype if x.dtype == y.dtype else None
            if dt is None:
                raise TileConfigError(
                    f"fragment elementwise dtype mismatch: {x.dtype} vs "
                    f"{y.dtype} (cast explicitly)")
        nc = am * an * 4
        rdt = tl.int1 if compare else dt
        out = self.dense_const(ir.VectorType.get([nc], rdt.mlir()),
                               rdt, 0)
        for im in range(am):
            for in_ in range(an):
                for half in range(2):
                    for jj in range(2):
                        xe = self._frag_elem(x, lay, im, in_, half, jj)
                        ye = self._frag_elem(y, lay, im, in_, half, jj)
                        if compare:
                            v = self.compare(op, xe, ye, dt)
                        elif op == "and":
                            v = self.and_i1(xe, ye)
                        elif op == "or":
                            v = arith.ori(xe, ye)
                        else:
                            v = self.binary(op, xe, ye, dt)
                        out = vector.insert(
                            v, out, [],
                            [(im * an + in_) * 4 + half * 2 + jj])
        return Tensor(rdt, lay.shape, lay, out, nc)

    # -- pipelined 2D-thread-tile matmul --------------------------------------

    def matmul_tile(self, a_pt: PtrTensor, b_pt: PtrTensor, K,
                    tm: int, tn: int, stages: int = 2, vec: bool = True,
                    even_k: bool = True, a_mask=None, b_mask=None,
                    a_trans: bool = False, b_trans: bool = False,
                    one_bar: bool = False) -> Tensor:
        """Whole-K-loop matmul (BM, BK) @ (BK, BN), cp.async multi-stage
        pipeline; returns the t2-layout accumulator (store via store_t2).
        a_pt/b_pt: unit-col-stride pointer tiles (a_trans/b_trans: pure
        transpose views); tm/tn: thread micro tile; stages: pipe depth.
        vec=True: unmasked 16B path (K%BK==0, aligned strides, BK/4 pow2);
        False: 4B zfill + a_mask/b_mask SepMasks, even_k drops K preds.
        one_bar: single-barrier schedule (autotune knob)."""
        a_off, b_off = a_pt.off, b_pt.off
        a_parg, b_parg = a_pt.arg, b_pt.arg
        if a_parg.elem != tl.float32 or b_parg.elem != tl.float32:
            raise TileConfigError("tl.matmul_tile supports f32 operands only")
        if len(a_off.shape) != 2 or len(b_off.shape) != 2:
            raise TileConfigError("tl.matmul_tile expects 2D pointer tiles")
        bm, bk = a_off.shape
        bk2, bn = b_off.shape
        if bk != bk2:
            raise TileConfigError(
                f"tl.matmul_tile inner-dim mismatch: {a_off.shape} vs {b_off.shape}")
        for name, off, tr in (("a", a_off, a_trans), ("b", b_off, b_trans)):
            if tr:
                if not (isinstance(off.row.stride, int)
                        and off.row.stride == 1):
                    raise TileConfigError(
                        f"tl.matmul_tile transposed {name} needs unit "
                        f"stride along its tile rows (the contiguous dim)")
            elif not (isinstance(off.col.stride, int)
                      and off.col.stride == 1):
                raise TileConfigError(
                    f"tl.matmul_tile needs unit column stride on {name}")
        if vec and (a_mask is not None or b_mask is not None):
            raise TileConfigError("tl.matmul_tile vec path takes no masks")
        # staging consumes a_mask's row preds (M) and b_mask's col preds
        # (N) only; a K-dim predicate would be silently dropped
        if a_mask is not None and a_mask.col_preds:
            raise TileConfigError(
                "tl.matmul_tile a_mask guards A's rows (M) only — K-dim "
                "masking is the K argument / even_k prefix convention's "
                "job, not a_mask's")
        if b_mask is not None and b_mask.row_preds:
            raise TileConfigError(
                "tl.matmul_tile b_mask guards B's columns (N) only — "
                "K-dim masking is the K argument / even_k prefix "
                "convention's job, not b_mask's")
        if vec and not even_k:
            raise TileConfigError(
                "tl.matmul_tile vec path needs even_k (K % BK == 0); use "
                "vec=False with masks for ragged K")

        nt = self.num_threads
        if tm not in (1, 2, 4, 8) or tn % 4 != 0 or tn < 4:
            raise TileConfigError(
                f"tl.matmul_tile needs tm in (1,2,4,8) and tn % 4 == 0, "
                f"got tm={tm}, tn={tn}")
        if tm * tn > 64:
            raise TileConfigError(
                f"tl.matmul_tile accumulator too large: tm*tn = {tm * tn} > 64")
        if bm % tm or bn % tn:
            raise TileConfigError(
                f"tl.matmul_tile tile ({bm}, {bn}) not divisible by "
                f"micro tile ({tm}, {tn})")
        nt_m, nt_n = bm // tm, bn // tn
        if nt_m * nt_n != nt:
            raise TileConfigError(
                f"tl.matmul_tile thread grid ({nt_m} x {nt_n}) != num_threads "
                f"({nt}); adjust BM/BN/tm/tn/num_warps")
        if bk % 4 != 0:
            raise TileConfigError(f"tl.matmul_tile needs BK % 4 == 0, got {bk}")
        cra, crb = bk // 4, bn // 4  # 16B chunks per a-row / b-row
        if vec and not a_trans and cra & (cra - 1):
            # the vec-path A staging XOR-swizzles 16B chunks by row: only a
            # power-of-two cra keeps the swizzled chunk inside its row
            raise TileConfigError(
                f"tl.matmul_tile BK={bk} gives {cra} 16B chunks per "
                "staged A row — the smem XOR swizzle needs a power-of-two "
                "chunk count (BK/4 must be a power of two)")
        # transposed operands stage with per-element (4B) copies
        chunks_a = bm * bk if a_trans else bm * cra
        chunks_b = bk * bn if b_trans else bk * crb
        if chunks_a % nt or chunks_b % nt:
            raise TileConfigError(
                f"tl.matmul_tile staging chunks not divisible by num_threads: "
                f"a {chunks_a}, b {chunks_b}, nt {nt}")
        if stages < 1:
            raise TileConfigError("tl.matmul_tile needs stages >= 1")
        if one_bar and stages < 2:
            raise TileConfigError(
                "tl.matmul_tile one_bar needs stages >= 2")
        log2_tm = tm.bit_length() - 1

        K_i32 = K.val if isinstance(K, Scalar) else self.as_i32(K.value)
        k_bound = K_i32

        # smem tiles are always flat f32 buffers (the device_async_copy
        # printer segfaults on vector element types in these bindings).
        smem_a = self._scratch_smem("mm_a", stages * bm * bk, tl.float32)
        smem_b = self._scratch_smem("mm_b", stages * bk * bn, tl.float32)

        tid = self.tid()
        tx = arith.remsi(tid, self.c_i32(nt_n))
        ty = arith.divsi(tid, self.c_i32(nt_n))

        def fold_ok(ok, cond):
            if cond is None:
                return ok
            return cond if ok is None else self.and_i1(ok, cond)

        def a_row_ok(row_i32):
            if a_mask is None:
                return None
            ok = None
            for p in a_mask.row_preds:
                ok = fold_ok(ok, self._pred_scalar(p, row_i32))
            return ok

        def k_ok(k0, c):
            """k0 + c < K as i1 (None when even_k)."""
            if even_k:
                return None
            lhs = self.eval_affine(Affine(k0, 1, bk), c)
            return self.compare("<", lhs, k_bound, tl.int32)

        def b_col_ok(c_i32):
            if b_mask is None:
                return None
            ok = None
            for p in b_mask.col_preds:
                ok = fold_ok(ok, self._pred_scalar(p, c_i32))
            return ok

        # vec-path staging prologue: (src, dst) slot lists built ONCE
        # outside the K loop; steady-state issue is one add per slot.
        def _stage_slots(off, parg, role: str, swz_b_f: int = 0):
            """role 'a16'/'a4' = A tile (16B chunks / 4B trans copies),
            'b16'/'b4' = B tile; returns (slots, k_adv(k0) -> i32)."""
            slots = []
            c4 = self.c_i32(4)
            if role == "a16":
                for j in range(chunks_a // nt):
                    c = arith.addi(tid, self.c_i32(j * nt))
                    row = arith.divsi(c, self.c_i32(cra))
                    jc = arith.remsi(c, self.c_i32(cra))
                    src = arith.addi(
                        self.eval_affine(off.row, row),
                        self.eval_affine(off.col, arith.muli(jc, c4)))
                    sw = jc if cra == 1 else arith.xori(
                        jc, arith.andi(arith.shrui(
                            row, self.c_i32(log2_tm)),
                            self.c_i32(cra - 1)))
                    dst = arith.addi(arith.muli(row, self.c_i32(bk)),
                                     arith.muli(sw, c4))
                    slots.append((src, dst, 4))
                return slots, (lambda k0: k0)  # col stride is 1
            if role == "a4":
                for j in range(chunks_a // nt):
                    c = arith.addi(tid, self.c_i32(j * nt))
                    mm = arith.remsi(c, self.c_i32(bm))
                    kk = arith.divsi(c, self.c_i32(bm))
                    src = arith.addi(
                        self.eval_affine(off.row, mm),
                        self.eval_affine(off.col, kk))
                    dst = arith.addi(arith.muli(kk, self.c_i32(bm)), mm)
                    slots.append((src, dst, 1))
                st = off.col.stride
                return slots, (lambda k0: k0 if isinstance(st, int)
                               and st == 1 else
                               arith.muli(k0, self.as_i32(st)))
            if role == "b16":
                ldb = off.row.stride
                for j in range(chunks_b // nt):
                    c = arith.addi(tid, self.c_i32(j * nt))
                    kk = arith.divsi(c, self.c_i32(crb))
                    jc = arith.remsi(c, self.c_i32(crb))
                    src = arith.addi(
                        self.eval_affine(off.row, kk),
                        self.eval_affine(off.col, arith.muli(jc, c4)))
                    dst = arith.addi(arith.muli(kk, self.c_i32(bn)),
                                     arith.muli(jc, c4))
                    slots.append((src, dst, 4))
                return slots, (lambda k0: k0 if isinstance(ldb, int)
                               and ldb == 1 else
                               arith.muli(k0, self.as_i32(ldb)))
            # b4 (trans-B scalar copies, XOR-swizzled dst by kk)
            for j in range(chunks_b // nt):
                c = arith.addi(tid, self.c_i32(j * nt))
                kk = arith.remsi(c, self.c_i32(bk))
                nn = arith.divsi(c, self.c_i32(bk))
                src = arith.addi(
                    self.eval_affine(off.row, kk),
                    self.eval_affine(off.col, nn))
                if swz_b_f:
                    nn = arith.xori(nn, arith.muli(kk,
                                                   self.c_i32(swz_b_f)))
                dst = arith.addi(arith.muli(kk, self.c_i32(bn)), nn)
                slots.append((src, dst, 1))
            return slots, (lambda k0: k0)  # trans row stride is 1

        pre_a = pre_b = k_adv_a = k_adv_b = None
        if vec:
            if a_trans:
                pre_a, k_adv_a = _stage_slots(a_off, a_parg, "a4")
            else:
                pre_a, k_adv_a = _stage_slots(a_off, a_parg, "a16")
            if b_trans:
                # same bijection-validated factor as the masked staging
                # (plain bn >= 4*bk lets non-bijective shapes through)
                pre_b, k_adv_b = _stage_slots(b_off, b_parg, "b4",
                                              _btrans_swizzle_factor(bk, bn))
            else:
                pre_b, k_adv_b = _stage_slots(b_off, b_parg, "b16")

        def issue_vec_fast(k0, stage):
            """Steady-state vec staging from the precomputed slots: one
            add per slot on each side (mirrors _mma_stage_vec_fast)."""
            toks = []
            for slots, smem, parg, k_adv, tile_elems in (
                    (pre_a, smem_a, a_parg, k_adv_a, bm * bk),
                    (pre_b, smem_b, b_parg, k_adv_b, bk * bn)):
                adv = k_adv(k0)
                dst_base = arith.muli(stage, self.c_i32(tile_elems))
                for src, dst, gran in slots:
                    op = nvgpu.device_async_copy(
                        smem, [self.to_index(arith.addi(dst_base, dst))],
                        parg.scalar_view,
                        [self.to_index(arith.addi(src, adv))], gran,
                        bypass_l1=gran == 4)
                    toks.append(op)
            return nvgpu.device_async_create_group(toks)

        def issue(k0, stage, sf=None):
            """Enqueue one (BM, BK) + (BK, BN) tile copy into buffer `stage`
            (k0, stage i32 scalars); returns the async-group token.
            sf: the stage's wir form (annotation surface, None when off).

            On the vec path the caller guarantees k0 < K (tile index clamped),
            so no predicates are emitted at all; the masked path zero-fills
            out-of-bounds elements."""
            toks = []
            tile_ok = None if vec else self.compare("<", k0, k_bound, tl.int32)
            role_a = self._wir_smem_role(smem_a)
            role_b = self._wir_smem_role(smem_b)
            if a_trans:
                # a tile, transposed view: coalesced 4B copies along m;
                # smem is (BK, BM) k-major (m-major would bank-conflict).
                for j in range(chunks_a // nt):
                    c = arith.addi(tid, self.c_i32(j * nt))
                    mm = arith.remsi(c, self.c_i32(bm))
                    kk = arith.divsi(c, self.c_i32(bm))
                    addr = arith.addi(
                        self.eval_affine(a_off.row, mm),
                        self.eval_affine(a_off.col, arith.addi(k0, kk)))
                    ok = fold_ok(fold_ok(tile_ok, a_row_ok(mm)),
                                 k_ok(k0, kk))
                    se = self.select(ok, self.c_idx(1), self.c_idx(0)) \
                        if ok is not None else None
                    if ok is not None:
                        addr = self.select(ok, addr, self.c_i32(0))
                    dst = arith.addi(arith.muli(stage, self.c_i32(bm * bk)),
                                     arith.addi(arith.muli(kk,
                                                           self.c_i32(bm)),
                                                mm))
                    op = nvgpu.device_async_copy(
                        smem_a, [self.to_index(dst)],
                        a_parg.scalar_view, [self.to_index(addr)], 1,
                        src_elements=se)
                    if sf is not None:
                        fcc = FA(TID, FC(j * nt))
                        self._wir_attr(
                            op, role_a,
                            FA(FM(sf, FC(bm * bk)),
                               FA(FM(FD(fcc, bm), FC(bm)), FMo(fcc, bm))), 1)
                    toks.append(op)
            else:
                # a tile: chunks_a 16B chunks (or bm*bk scalar copies)
                for j in range(chunks_a // nt):
                    c = arith.addi(tid, self.c_i32(j * nt))
                    row = arith.divsi(c, self.c_i32(cra))
                    jc = arith.remsi(c, self.c_i32(cra))
                    # NB: the column affine may carry a nonzero base; fold
                    # the K advance into the column index, not the arange.
                    addr = arith.addi(
                        self.eval_affine(a_off.row, row),
                        self.eval_affine(a_off.col,
                                         arith.addi(k0, arith.muli(
                                             jc, self.c_i32(4)))))
                    ok = fold_ok(fold_ok(tile_ok, a_row_ok(row)), k_ok(k0, jc))
                    dst_base = arith.muli(stage, self.c_i32(bm * bk))
                    if vec:
                        sw = jc
                        if cra > 1:
                            rsh = arith.shrui(row, self.c_i32(log2_tm))
                            sw = arith.xori(jc, arith.andi(rsh,
                                                           self.c_i32(cra - 1)))
                        dst = arith.addi(dst_base,
                                         arith.addi(arith.muli(row,
                                                               self.c_i32(bk)),
                                                    arith.muli(sw,
                                                               self.c_i32(4))))
                        op = nvgpu.device_async_copy(
                            smem_a, [self.to_index(dst)],
                            a_parg.scalar_view, [self.to_index(addr)], 4,
                            bypass_l1=True)
                        if sf is not None:
                            fcc = FA(TID, FC(j * nt))
                            frow = FD(fcc, cra)
                            fjc = FMo(fcc, cra)
                            fsw = fjc if cra == 1 else FX(
                                fjc, FAn(FD(frow, 1 << log2_tm), cra - 1))
                            self._wir_attr(
                                op, role_a,
                                FA(FM(sf, FC(bm * bk)),
                                   FA(FM(frow, FC(bk)), FM(fsw, FC(4)))), 4)
                        toks.append(op)
                    else:
                        dst0 = arith.muli(stage, self.c_i32(bm * bk))
                        for w in range(4):
                            addr_w = arith.addi(addr, self.c_i32(w))
                            ok_w = fold_ok(fold_ok(tile_ok, a_row_ok(row)),
                                           k_ok(k0, arith.addi(
                                               arith.muli(jc, self.c_i32(4)),
                                               self.c_i32(w))))
                            se = self.select(ok_w, self.c_idx(1),
                                             self.c_idx(0)) \
                                if ok_w is not None else None
                            if ok_w is not None:
                                addr_w = self.select(ok_w, addr_w,
                                                     self.c_i32(0))
                            dst = arith.addi(dst0, arith.addi(
                                arith.muli(row, self.c_i32(bk)),
                                arith.addi(arith.muli(jc, self.c_i32(4)),
                                           self.c_i32(w))))
                            op = nvgpu.device_async_copy(
                                smem_a, [self.to_index(dst)],
                                a_parg.scalar_view, [self.to_index(addr_w)], 1,
                                src_elements=se)
                            if sf is not None:
                                fcc = FA(TID, FC(j * nt))
                                self._wir_attr(
                                    op, role_a,
                                    FA(FM(sf, FC(bm * bk)),
                                       FA(FM(FD(fcc, cra), FC(bk)),
                                          FA(FM(FMo(fcc, cra), FC(4)),
                                             FC(w)))), 1)
                            toks.append(op)
            # b tile
            if b_trans:
                # transposed view: coalesced 4B copies along k; smem stays
                # (BK, BN) row-major with the column XOR-swizzled per kk
                # (nn ^ kk*swz_f, else kk-fast lanes hit one bank group).
                # _btrans_swizzle_factor degrades to 0 where it collides.
                swz_f = _btrans_swizzle_factor(bk, bn)
                for j in range(chunks_b // nt):
                    c = arith.addi(tid, self.c_i32(j * nt))
                    kk = arith.remsi(c, self.c_i32(bk))
                    nn = arith.divsi(c, self.c_i32(bk))
                    addr = arith.addi(
                        self.eval_affine(b_off.row, arith.addi(k0, kk)),
                        self.eval_affine(b_off.col, nn))
                    ok = fold_ok(fold_ok(tile_ok, k_ok(k0, kk)),
                                 b_col_ok(nn))
                    se = self.select(ok, self.c_idx(1), self.c_idx(0)) \
                        if ok is not None else None
                    if ok is not None:
                        addr = self.select(ok, addr, self.c_i32(0))
                    if swz_f:
                        nn = arith.xori(nn, arith.muli(kk,
                                                       self.c_i32(swz_f)))
                    dst = arith.addi(arith.muli(stage, self.c_i32(bk * bn)),
                                     arith.addi(arith.muli(kk,
                                                           self.c_i32(bn)),
                                                nn))
                    op = nvgpu.device_async_copy(
                        smem_b, [self.to_index(dst)],
                        b_parg.scalar_view, [self.to_index(addr)], 1,
                        src_elements=se)
                    if sf is not None:
                        fcc = FA(TID, FC(j * nt))
                        fkk = FMo(fcc, bk)
                        fnn = FD(fcc, bk)
                        if swz_f:
                            fnn = FX(fnn, FM(fkk, FC(swz_f)))
                        self._wir_attr(
                            op, role_b,
                            FA(FM(sf, FC(bk * bn)),
                               FA(FM(fkk, FC(bn)), fnn)), 1)
                    toks.append(op)
                return nvgpu.device_async_create_group(toks)
            ldb = b_off.row.stride
            k0n = arith.muli(k0, self.as_i32(ldb))
            for j in range(chunks_b // nt):
                c = arith.addi(tid, self.c_i32(j * nt))
                kk = arith.divsi(c, self.c_i32(crb))
                jc = arith.remsi(c, self.c_i32(crb))
                col_idx = arith.muli(jc, self.c_i32(4))
                col = self.eval_affine(b_off.col, col_idx)
                addr = arith.addi(arith.addi(k0n,
                                             self.eval_affine(b_off.row, kk)),
                                  col)
                ok = fold_ok(fold_ok(tile_ok, k_ok(k0, kk)), b_col_ok(col_idx))
                dst_base = arith.muli(stage, self.c_i32(bk * bn))
                if vec:
                    dst = arith.addi(dst_base,
                                     arith.addi(arith.muli(kk, self.c_i32(bn)),
                                                arith.muli(jc, self.c_i32(4))))
                    op = nvgpu.device_async_copy(
                        smem_b, [self.to_index(dst)],
                        b_parg.scalar_view, [self.to_index(addr)], 4,
                        bypass_l1=True)
                    if sf is not None:
                        fcc = FA(TID, FC(j * nt))
                        self._wir_attr(
                            op, role_b,
                            FA(FM(sf, FC(bk * bn)),
                               FA(FM(FD(fcc, crb), FC(bn)),
                                  FM(FMo(fcc, crb), FC(4)))), 4)
                    toks.append(op)
                else:
                    dst0 = arith.muli(stage, self.c_i32(bk * bn))
                    for w in range(4):
                        col_w = arith.addi(col_idx, self.c_i32(w))
                        ok_w = fold_ok(fold_ok(tile_ok, k_ok(k0, kk)),
                                       b_col_ok(col_w))
                        addr_w = arith.addi(addr, self.c_i32(w))
                        se = self.select(ok_w, self.c_idx(1), self.c_idx(0)) \
                            if ok_w is not None else None
                        if ok_w is not None:
                            addr_w = self.select(ok_w, addr_w, self.c_i32(0))
                        dst = arith.addi(dst0, arith.addi(
                            arith.muli(kk, self.c_i32(bn)),
                            arith.addi(arith.muli(jc, self.c_i32(4)),
                                       self.c_i32(w))))
                        op = nvgpu.device_async_copy(
                            smem_b, [self.to_index(dst)],
                            b_parg.scalar_view, [self.to_index(addr_w)], 1,
                            src_elements=se)
                        if sf is not None:
                            fcc = FA(TID, FC(j * nt))
                            self._wir_attr(
                                op, role_b,
                                FA(FM(sf, FC(bk * bn)),
                                   FA(FM(FD(fcc, crb), FC(bn)),
                                      FA(FM(FMo(fcc, crb), FC(4)),
                                         FC(w)))), 1)
                        toks.append(op)
            return nvgpu.device_async_create_group(toks)

        def compute(stage, acc, sf=None):
            """FMA over one staged tile: acc += a_tile @ b_tile.
            sf: the stage's wir form (annotation surface, None when off).
            The tn columns map as tn/4 16B chunks strided by nt_n*4 (chunk
            j4 at column (tx + j4*nt_n)*4): bank-conflict-free LDS.128."""
            base_a = arith.muli(stage, self.c_i32(bm * bk))
            base_b = arith.muli(stage, self.c_i32(bk * bn))
            role_a = self._wir_smem_role(smem_a)
            role_b = self._wir_smem_role(smem_b)
            v4 = ir.VectorType.get([4], self.f32)
            tym = arith.muli(ty, self.c_i32(tm))
            # transposed operands are staged with 4B copies and read back
            # scalar, except b_trans with swz_f == 4 (LDS.128 stays).
            a_vec = vec and not a_trans
            # read side uses the SAME validated factor as the staging side
            # (0 = unswizzled: b_vec falls to the scalar read fallback)
            b_swz_f = _btrans_swizzle_factor(bk, bn) if b_trans else 0
            b_vec = vec and (not b_trans or b_swz_f == 4)
            # hoisted per-micro-row smem bases (vec path)
            a_rows = [arith.addi(tym, self.c_i32(ii)) for ii in range(tm)]
            if a_vec:
                a_rowbase = [arith.addi(base_a,
                                        arith.muli(r, self.c_i32(bk)))
                             for r in a_rows]
                ty_sw = arith.andi(ty, self.c_i32(cra - 1)) if cra > 1 else None
            for g in range(bk // 4):
                if a_vec:
                    afr = []
                    for ii in range(tm):
                        chunk = self.c_i32(g * 4) if cra == 1 else \
                            arith.muli(arith.xori(self.c_i32(g), ty_sw),
                                       self.c_i32(4))
                        idx = arith.addi(a_rowbase[ii], chunk)
                        op = vector.LoadOp(v4, smem_a,
                                           [self.to_index(idx)])
                        if sf is not None:
                            frow = FA(FM(FD(TID, nt_n), FC(tm)), FC(ii))
                            fchunk = FC(g * 4) if cra == 1 else FM(
                                FX(FC(g), FAn(FD(TID, nt_n), cra - 1)),
                                FC(4))
                            self._wir_attr(
                                op, role_a,
                                FA(FM(sf, FC(bm * bk)),
                                   FA(FM(frow, FC(bk)), fchunk)), 4)
                        afr.append(op.result)
                for w in range(4):
                    kk = g * 4 + w
                    if b_vec:
                        bfr = []
                        for j4 in range(tn // 4):
                            col = arith.muli(
                                arith.addi(tx, self.c_i32(j4 * nt_n)),
                                self.c_i32(4))
                            if b_swz_f:
                                col = arith.xori(
                                    col, self.c_i32(kk * b_swz_f))
                            idx = arith.addi(
                                base_b,
                                arith.addi(
                                    arith.muli(self.c_i32(kk),
                                               self.c_i32(bn)),
                                    col))
                            op = vector.LoadOp(
                                v4, smem_b, [self.to_index(idx)])
                            if sf is not None:
                                fcol = FM(FA(FMo(TID, nt_n),
                                             FC(j4 * nt_n)), FC(4))
                                if b_swz_f:
                                    fcol = FX(fcol, FC(kk * b_swz_f))
                                self._wir_attr(
                                    op, role_b,
                                    FA(FM(sf, FC(bk * bn)),
                                       FA(FC(kk * bn), fcol)), 4)
                            bfr.append(op.result)
                    else:
                        bfr = []
                        for jj in range(tn):
                            j4, w4 = jj // 4, jj % 4
                            col = arith.addi(
                                arith.muli(
                                    arith.addi(tx, self.c_i32(j4 * nt_n)),
                                    self.c_i32(4)),
                                self.c_i32(w4))
                            if b_swz_f:
                                col = arith.xori(
                                    col, self.c_i32(kk * b_swz_f))
                            idx = arith.addi(
                                base_b,
                                arith.addi(
                                    arith.muli(self.c_i32(kk),
                                               self.c_i32(bn)),
                                    col))
                            op = memref.LoadOp(
                                smem_b, [self.to_index(idx)])
                            if sf is not None:
                                fcol = FA(FM(FA(FMo(TID, nt_n),
                                                FC(j4 * nt_n)), FC(4)),
                                          FC(w4))
                                if b_swz_f:
                                    fcol = FX(fcol, FC(kk * b_swz_f))
                                self._wir_attr(
                                    op, role_b,
                                    FA(FM(sf, FC(bk * bn)),
                                       FA(FC(kk * bn), fcol)), 1)
                            bfr.append(op.result)
                    for ii in range(tm):
                        if a_vec:
                            av_s = vector.extract(afr[ii], [], [w])
                        elif a_trans:
                            # k-major smem (BK, BM): element (m, k) at
                            # k*bm + m (matches the conflict-free staging)
                            idx = arith.addi(
                                base_a,
                                arith.addi(
                                    arith.muli(self.c_i32(kk),
                                               self.c_i32(bm)),
                                    a_rows[ii]))
                            op = memref.LoadOp(
                                smem_a, [self.to_index(idx)])
                            if sf is not None:
                                frow = FA(FM(FD(TID, nt_n), FC(tm)), FC(ii))
                                self._wir_attr(
                                    op, role_a,
                                    FA(FM(sf, FC(bm * bk)),
                                       FA(FC(kk * bm), frow)), 1)
                            av_s = op.result
                        else:
                            idx = arith.addi(
                                base_a,
                                arith.addi(
                                    arith.muli(a_rows[ii], self.c_i32(bk)),
                                    self.c_i32(kk)))
                            op = memref.LoadOp(
                                smem_a, [self.to_index(idx)])
                            if sf is not None:
                                frow = FA(FM(FD(TID, nt_n), FC(tm)), FC(ii))
                                self._wir_attr(
                                    op, role_a,
                                    FA(FM(sf, FC(bm * bk)),
                                       FA(FM(frow, FC(bk)), FC(kk))), 1)
                            av_s = op.result
                        if b_vec:
                            av = self.splat(v4, av_s)
                            for j4 in range(tn // 4):
                                sl = vector.extract_strided_slice(
                                    v4, acc, [ii * tn + j4 * 4], [4], [1])
                                sl = vector.fma(av, bfr[j4], sl)
                                acc = vector.insert_strided_slice(
                                    sl, acc, [ii * tn + j4 * 4], [1])
                        else:
                            for jj in range(tn):
                                cur = vector.extract(acc, [], [ii * tn + jj])
                                cur = arith.addf(arith.mulf(av_s, bfr[jj]),
                                                 cur)
                                acc = vector.insert(cur, acc, [], [ii * tn + jj])
            return acc

        n_tiles = arith.divsi(arith.addi(K_i32, self.c_i32(bk - 1)),
                              self.c_i32(bk))

        def issue_tile(t_i32, tf=None):
            """Issue tile index t (clamped to the last tile on the vec
            path, so issue() needs no predicates). tf: the tile index's
            wir form (None when off)."""
            if vec:
                last = arith.subi(n_tiles, self.c_i32(1))
                t_i32 = self.select(self.compare("<", t_i32, n_tiles, tl.int32),
                                    t_i32, last)
                if tf is None:  # precomputed-slot fast path (wir off)
                    return issue_vec_fast(arith.muli(t_i32, self.c_i32(bk)),
                                          arith.remsi(t_i32,
                                                      self.c_i32(stages)))
            sf = FMo(tf, stages) if tf is not None else None
            return issue(arith.muli(t_i32, self.c_i32(bk)),
                         arith.remsi(t_i32, self.c_i32(stages)), sf)

        # prologue: fill the first stages-1 buffers
        grp_pre = None
        for t in range(stages - 1):
            grp_pre = issue_tile(self.c_i32(t), FC(t) if self._wir_annotate_on()
                                 else None)

        vty = ir.VectorType.get([tm * tn], self.f32)
        acc0 = self.dense_const(vty, tl.float32, 0.0)
        if one_bar:
            # ONE barrier per K tile: wait_group(stages-2); bar; issue tile
            # i+stages-1; compute tile i. The group token threads through
            # the loop as an iter_arg (same handshake as ONE_BAR mma).
            for_op = scf.ForOp(self.c_idx(0), self.to_index(n_tiles),
                               self.c_idx(1), iter_args=[acc0, grp_pre])
            block = _ensure_block(for_op.regions[0])
            ivf = self._wir_mark_loop(for_op)
            with ir.InsertionPoint(block):
                i_idx, acc_in, tok_in = block.arguments
                i32v = arith.index_cast(self.i32, i_idx)
                stage = arith.remsi(i32v, self.c_i32(stages))
                nvgpu.device_async_wait(tok_in, num_groups=stages - 2)
                gpu.barrier()
                grp = issue_tile(arith.addi(i32v, self.c_i32(stages - 1)),
                                 FA(ivf, FC(stages - 1))
                                 if ivf is not None else None)
                acc_out = compute(stage, acc_in,
                                  FMo(ivf, stages) if ivf is not None
                                  else None)
                scf.YieldOp([acc_out, grp])
        else:
            for_op = scf.ForOp(self.c_idx(0), self.to_index(n_tiles),
                               self.c_idx(1), iter_args=[acc0])
            block = _ensure_block(for_op.regions[0])
            ivf = self._wir_mark_loop(for_op)
            with ir.InsertionPoint(block):
                i_idx, acc_in = block.arguments
                i32v = arith.index_cast(self.i32, i_idx)
                stage = arith.remsi(i32v, self.c_i32(stages))
                grp = issue_tile(arith.addi(i32v, self.c_i32(stages - 1)),
                                 FA(ivf, FC(stages - 1))
                                 if ivf is not None else None)
                nvgpu.device_async_wait(grp, num_groups=stages - 1)
                gpu.barrier()
                acc_out = compute(stage, acc_in,
                                  FMo(ivf, stages) if ivf is not None
                                  else None)
                gpu.barrier()
                scf.YieldOp([acc_out])
        out = Tensor(tl.float32, (bm, bn),
                     t2_layout((bm, bn), tm, tn, nt),
                     for_op.results[0], tm * tn)
        return out

    def store_t2(self, pt: PtrTensor, value: Tensor, mask=None,
                 bias_pt: PtrTensor | None = None):
        """Store a "t2"-laid-out (BM, BN) tile (from matmul_tile): thread
        (ty, tx) writes its tm x tn micro tile (tn/4 16B chunks strided
        by nt_n*4) through the vectorized store path. bias_pt (optional
        (BN,) f32 tile): fused bias epilogue, added to the f32
        accumulator before the store (bit-identical to matmul+bias)."""
        off = pt.off
        parg = pt.arg
        if not is_t2(value.layout):
            raise TileConfigError(
                f"store_t2 expects a t2-laid-out value, got {value!r}")
        if off.shape != value.shape or len(off.shape) != 2:
            raise TileConfigError(
                f"store_t2 shape mismatch: {off.shape} vs {value.shape}")
        if not (isinstance(off.col.stride, int) and off.col.stride == 1):
            raise TileConfigError("store_t2 needs unit column stride")
        if mask is not None and not isinstance(mask, SepMask):
            raise TileConfigError("store_t2 masks must be symbolic (SepMask)")
        if bias_pt is not None:
            if len(bias_pt.off.shape) != 1 \
                    or bias_pt.off.shape[0] != value.shape[1]:
                raise TileConfigError(
                    f"store_t2 bias tile must be ({value.shape[1]},), got "
                    f"{bias_pt.off.shape}")
            if bias_pt.arg.elem != tl.float32 or parg.elem != tl.float32:
                raise TileConfigError(
                    "store_t2 bias epilogue is an f32 feature")
        lay = value.layout
        nt_n, tm = lay.threads[1], lay.size_per_thread[0]
        tn = value.shape[1] // nt_n
        tid = self.tid()
        tx = arith.remsi(tid, self.c_i32(nt_n))
        ty = arith.divsi(tid, self.c_i32(nt_n))
        v4 = ir.VectorType.get([4], self.f32)
        for ii in range(tm):
            r = arith.addi(arith.muli(ty, self.c_i32(tm)), self.c_i32(ii))
            row_addr = self.eval_affine(off.row, r)
            for j4 in range(tn // 4):
                col0 = arith.muli(arith.addi(tx, self.c_i32(j4 * nt_n)),
                                  self.c_i32(4))
                addr = arith.addi(row_addr, self.eval_affine(off.col, col0))
                if mask is None:
                    frag_m, all_m = None, None
                else:
                    frag_m, all_m = self.mask_frag(mask, r, 4, col0)
                chunk = vector.extract_strided_slice(v4, value.val,
                                                     [ii * tn + j4 * 4],
                                                     [4], [1])
                if bias_pt is not None:
                    baddr = self.eval_affine(bias_pt.off.col, col0)
                    bv = self._load_frag(bias_pt.arg, baddr, 1, 4,
                                         frag_m, all_m,
                                         self.const(tl.float32, 0.0))
                    chunk = arith.addf(chunk, bv)
                self._store_frag(parg, addr, 1, chunk, 4, frag_m, all_m)

    # -- mma: the tensor-core path (mma_tile / store_m4), in pass-style
    # pieces: mma_atom (geometry as data), _mma_stage_a/_mma_stage_b
    # (cp.async staging), _mma_frag_a/_mma_frag_b (smem->fragment reads),
    # _mma_sync (inline PTX), store_m4 (C writeback).

    def _mma_i16_ty(self):
        if getattr(self, "_i16_ty", None) is None:
            self._i16_ty = ir.IntegerType.get_signless(16)
        return self._i16_ty

    def _mma_ld_i32(self, smem, addr, form=None):
        """One smem element as raw i32 bits (tf32 path): scalar LDS + a
        (free) bitcast so the mma operand goes in an "r"-constrained reg."""
        op = memref.LoadOp(smem, [self.to_index(addr)])
        self._wir_attr(op, self._wir_smem_role(smem), form, 1)
        return arith.bitcast(self.i32, op.result)

    def _mma_ld_f32(self, smem, addr, form=None):
        """One f32 value from smem (f32-staged mma operand)."""
        op = memref.LoadOp(smem, [self.to_index(addr)])
        self._wir_attr(op, self._wir_smem_role(smem), form, 1)
        return op.result

    def _mma_pack_bf16x2(self, lo, hi):
        """Round two f32 values (rn) and pack as {hi:lo} bf16x2 in one i32
        — the in-register cast for f32-staged operands of the bf16 mma
        (same rounding the elementwise astype kernels emit)."""
        return nvvm.InlinePtxOp([self.i32], [lo, hi], [],
                                "cvt.rn.bf16x2.f32 $0, $2, $1;").results[0]

    def _mma_ld_adj2_i32(self, smem, addr, form=None):
        """Two smem-adjacent bf16 elements (one 4B word) as i32 bits: a
        single 4B LDS via vector<2xbf16> + bitcast. ``addr`` is the smem
        element index of the first element of the pair (always even)."""
        v2 = ir.VectorType.get([2], tl.bfloat16.mlir())
        op = vector.LoadOp(v2, smem, [self.to_index(addr)])
        self._wir_attr(op, self._wir_smem_role(smem), form, 2)
        vec = op.result
        v1 = vector.bitcast(ir.VectorType.get([1], self.i32), vec)
        return vector.extract(v1, [], [0])

    def _mma_ld_strided2_i32(self, smem, addr0, addr1,
                             form0=None, form1=None):
        """One i32 mma operand packed from two bf16 elements at
        NON-adjacent smem addresses (2x LDS.U16 + shift/or). Low half =
        element at addr0, high half = addr1."""
        i16 = self._mma_i16_ty()
        op0 = memref.LoadOp(smem, [self.to_index(addr0)])
        self._wir_attr(op0, self._wir_smem_role(smem), form0, 1)
        op1 = memref.LoadOp(smem, [self.to_index(addr1)])
        self._wir_attr(op1, self._wir_smem_role(smem), form1, 1)
        lo = arith.extui(self.i32, arith.bitcast(i16, op0.result))
        hi = arith.extui(self.i32, arith.bitcast(i16, op1.result))
        return arith.ori(lo, arith.shli(hi, self.c_i32(16)))

    def _mma_sync(self, atom: "MmaAtom", aregs: list, bregs: list,
                  cregs: list) -> list:
        """One warp-wide mma.sync: d[0..3] = A @ B + c[0..3]; aregs 4 i32,
        bregs 2 i32, cregs 4 f32 (multi-result inline_ptx)."""
        if len(aregs) != 4 or len(bregs) != 2 or len(cregs) != 4:
            raise TileConfigError(
                f"_mma_sync expects 4 a regs / 2 b regs / 4 c regs, got "
                f"{len(aregs)}/{len(bregs)}/{len(cregs)}")
        res = nvvm.InlinePtxOp([self.f32] * 4, aregs + bregs + cregs, [],
                               atom.asm)
        return [res.results[i] for i in range(4)]

    def _mma_cvt_tf32(self, x_i32):
        """Round one f32 operand (raw i32 bits) to tf32 with
        round-to-nearest (cvt.rna.tf32.f32) — matching the input rounding
        cuBLAS applies in its tf32 path; returns raw i32 bits."""
        xf = arith.bitcast(self.f32, x_i32)
        return nvvm.InlinePtxOp([self.i32], [xf], [],
                                "cvt.rna.tf32.f32 $0, $1;").results[0]

    def _mma_split_tf32(self, x_i32):
        """hi/lo split for 3xTF32: hi = rn_tf32(x), lo = rn_tf32(x - hi)
        (the subtraction is exact — hi truncates the mantissa to 10 bits),
        so hi + lo carries ~21 bits of the f32 mantissa."""
        hi = self._mma_cvt_tf32(x_i32)
        lo = self._mma_cvt_tf32(arith.bitcast(
            self.i32, arith.subf(arith.bitcast(self.f32, x_i32),
                                 arith.bitcast(self.f32, hi))))
        return hi, lo

    # -- ldmatrix fragment path (plain layouts) ----------------------------

    def _mma_smem_i32(self, smem, base_elems, esz: int):
        """Raw shared-window byte address (i32) of smem[base_elems] — the
        addressing form ldmatrix/cp.async PTX wants ([r32])."""
        idx = memref.ExtractAlignedPointerAsIndexOp(smem).result
        b32 = arith.index_cast(self.i32, idx)
        return arith.addi(
            b32, arith.muli(self.as_i32(base_elems), self.c_i32(esz)))

    def _mma_ldsm_x4(self, addr_i32, form=None, role=None, vl=4):
        """One ldmatrix.x4: 4 b16 8x8 matrices into 4 i32 regs. Lane l
        supplies the row address of matrix l//8, row l%8."""
        op = nvvm.InlinePtxOp(
            [self.i32] * 4, [addr_i32], [],
            "ldmatrix.sync.aligned.m8n8.x4.shared.b16 "
            "{$0,$1,$2,$3}, [$4];")
        if role is not None:
            self._wir_attr(op, role, form, vl)
        return list(op.results)

    def _mma_ldsm_x2_trans(self, addr_i32, form=None, role=None, vl=4):
        """One ldmatrix.x2.trans: 2 b16 8x8 matrices, transposed fragment.
        Lanes 0-15 supply row addresses (matrix l//8, row l%8)."""
        op = nvvm.InlinePtxOp(
            [self.i32] * 2, [addr_i32], [],
            "ldmatrix.sync.aligned.m8n8.x2.trans.shared.b16 "
            "{$0,$1}, [$2];")
        if role is not None:
            self._wir_attr(op, role, form, vl)
        return list(op.results)

    def _mma_ldsm_x4_trans(self, addr_i32, form=None, role=None, vl=4):
        """One ldmatrix.x4.trans: 4 b16 8x8 matrices, transposed
        fragments. Lane l supplies the row address of matrix l//8, row
        l%8."""
        op = nvvm.InlinePtxOp(
            [self.i32] * 4, [addr_i32], [],
            "ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 "
            "{$0,$1,$2,$3}, [$4];")
        if role is not None:
            self._wir_attr(op, role, form, vl)
        return list(op.results)

    def _mma_ldsm_x2(self, addr_i32, form=None, role=None, vl=4):
        """One ldmatrix.x2: 2 b16 8x8 matrices into 2 i32 regs. Lanes
        0-15 supply row addresses (matrix l//8, row l%8)."""
        op = nvvm.InlinePtxOp(
            [self.i32] * 2, [addr_i32], [],
            "ldmatrix.sync.aligned.m8n8.x2.shared.b16 "
            "{$0,$1}, [$2];")
        if role is not None:
            self._wir_attr(op, role, form, vl)
        return list(op.results)

    def _mma_frag_b_ldsm_trans_addr(self, atom, base_i32, bk: int,
                                    swz_mask: int, lane, col_w, h: int,
                                    in_: int, fb=None):
        """Lane l's ldmatrix.x2 byte address for atom (h, in_) of
        TRANSPOSED (column-major (BN, BK)) B smem: matrix j = the 8x8
        block at n rows col_w + in_*8, k-chunk h*(k/v16) + j, chunk
        XOR-swizzled by n row. fb: base_i32's wir form."""
        c = self.c_i32
        v16 = atom.v16
        lanesel = arith.remsi(lane, c(16))
        j = arith.divsi(lanesel, c(8))
        r = arith.remsi(lane, c(8))
        nrow = arith.addi(col_w, arith.addi(c(in_ * atom.n), r))
        chunk = arith.addi(c(h * (atom.k // v16)), j)
        sw = chunk if swz_mask == 0 else arith.xori(
            chunk, arith.andi(nrow, c(swz_mask)))
        off = arith.addi(arith.muli(nrow, c(bk)),
                         arith.muli(sw, c(v16)))
        addr = arith.addi(base_i32,
                          arith.muli(off, c(atom.elem.itemsize)))
        if fb is not None:
            wfc = self._wf_ctx
            fl = wfc["lane"]
            fls = FMo(fl, 16)
            fnrow = FA(FA(wfc["col_w"], FC(in_ * atom.n)),
                       FMo(fl, 8))
            fchunk = FA(FC(h * (atom.k // v16)), FD(fls, 8))
            fsw = fchunk if swz_mask == 0 else FX(fchunk,
                                                  FAn(fnrow, swz_mask))
            return addr, FA(FM(fnrow, FC(bk)), FM(fsw, FC(v16)))
        return addr

    def _mma_frag_b_ldsm_trans(self, atom, base_i32, bk: int, swz_mask: int,
                               lane, col_w, h: int, in_: int):
        """The B-fragment of one bf16 (k16, n8) atom from TRANSPOSED
        (column-major (BN, BK)) smem as ONE ldmatrix.x2: from n-major
        rows the plain fragment IS the atom's (k = 2t, n = g) layout."""
        return self._mma_ldsm_x2(
            self._mma_frag_b_ldsm_trans_addr(atom, base_i32, bk, swz_mask,
                                             lane, col_w, h, in_))

    def _mma_frag_a_ldsm_trans_addr(self, atom, base_i32, bm: int,
                                    swz_mask: int, lane, row_w, h: int,
                                    im: int, fb=None):
        """Lane l's ldmatrix.x4.trans byte address for atom (h, im) of
        TRANSPOSED (k-major, (BK, BM)) A smem: matrix j = the 8x8 block
        at k rows h*atom.k + 8*(j//2), m cols row_w + im*atom.m + 8*(j%2);
        16B m-chunks XOR-swizzled by k row. fb: base_i32's wir form."""
        c = self.c_i32
        v16 = atom.v16
        j = arith.divsi(lane, c(8))
        r = arith.remsi(lane, c(8))
        kk = arith.addi(c(h * atom.k),
                        arith.addi(arith.muli(arith.divsi(j, c(2)), c(8)),
                                   r))
        m0 = arith.addi(row_w, c(im * atom.m))
        chunk = arith.addi(arith.divsi(m0, c(v16)),
                           arith.remsi(j, c(2)))
        sw = chunk if swz_mask == 0 else arith.xori(
            chunk, arith.andi(kk, c(swz_mask)))
        off = arith.addi(arith.muli(kk, c(bm)),
                         arith.muli(sw, c(v16)))
        addr = arith.addi(base_i32,
                          arith.muli(off, c(atom.elem.itemsize)))
        if fb is not None:
            wfc = self._wf_ctx
            fl = wfc["lane"]
            fj = FD(fl, 8)
            fkk = FA(FC(h * atom.k), FA(FM(FD(fj, 2), FC(8)), FMo(fl, 8)))
            fm0 = FA(wfc["row_w"], FC(im * atom.m))
            fchunk = FA(FD(fm0, v16), FMo(fj, 2))
            fsw = fchunk if swz_mask == 0 else FX(fchunk,
                                                  FAn(fkk, swz_mask))
            return addr, FA(FM(fkk, FC(bm)), FM(fsw, FC(v16)))
        return addr

    def _mma_frag_a_ldsm_trans(self, atom, base_i32, bm: int, swz_mask: int,
                               lane, row_w, h: int, im: int):
        """The A-fragment of one bf16 16x16 atom from TRANSPOSED (k-major)
        smem as ONE ldmatrix.x4.trans: the .trans fragment of a k-row 8x8
        block is exactly the (m = g, k = 2t) layout the mma A operand
        wants, in _mma_frag_a's reg order."""
        return self._mma_ldsm_x4_trans(
            self._mma_frag_a_ldsm_trans_addr(atom, base_i32, bm, swz_mask,
                                             lane, row_w, h, im))

    def _mma_frag_a_ldsm_addr(self, atom, base_i32, bk: int, swz_mask: int,
                              lane, row_w, h: int, im: int, fb=None):
        """Lane l's ldmatrix.x4 byte address for atom (h, im) of plain
        (BM, BK) A smem: matrix j = (rows m0 + 8*(j&1), col chunk
        h*(k/v16) + j//2), XOR-swizzled by row. fb: base_i32's wir form."""
        c = self.c_i32
        ck = atom.k // atom.v16
        j = arith.divsi(lane, c(8))
        m = arith.addi(arith.addi(row_w, c(im * atom.m)),
                       arith.addi(arith.muli(arith.andi(j, c(1)), c(8)),
                                  arith.remsi(lane, c(8))))
        chunk = arith.addi(c(h * ck), arith.divsi(lane, c(16)))
        sw = chunk if swz_mask == 0 else arith.xori(
            chunk, arith.andi(m, c(swz_mask)))
        off = arith.addi(arith.muli(m, c(bk)),
                         arith.muli(sw, c(atom.v16)))
        addr = arith.addi(base_i32,
                          arith.muli(off, c(atom.elem.itemsize)))
        if fb is not None:
            wfc = self._wf_ctx
            fl = wfc["lane"]
            fj = FD(fl, 8)
            fm = FA(FA(wfc["row_w"], FC(im * atom.m)),
                    FA(FM(FAn(fj, 1), FC(8)), FMo(fl, 8)))
            fchunk = FA(FC(h * ck), FD(fl, 16))
            fsw = fchunk if swz_mask == 0 else FX(fchunk,
                                                  FAn(fm, swz_mask))
            return addr, FA(FM(fm, FC(bk)), FM(fsw, FC(atom.v16)))
        return addr

    def _mma_frag_a_ldsm(self, atom, base_i32, bk: int, swz_mask: int,
                         lane, row_w, h: int, im: int):
        """The A-fragment of one 16x8 tf32 / 16x16 bf16 atom as ONE
        ldmatrix.x4: the x4 matrices are exactly fragment regs a0..a3."""
        return self._mma_ldsm_x4(
            self._mma_frag_a_ldsm_addr(atom, base_i32, bk, swz_mask, lane,
                                       row_w, h, im))

    def _mma_frag_b_ldsm_addr(self, atom, base_i32, bn: int, crb_mask: int,
                              lane, col_w, h: int, in_: int, fb=None):
        """Lane l's ldmatrix.x2.trans byte address for atom (h, in_) of
        plain (BK, BN) B smem: source matrices are (8 k-rows x one 16B
        n-chunk), chunk XOR-swizzled by k. fb: base_i32's wir form."""
        c = self.c_i32
        n0 = arith.addi(col_w, c(in_ * atom.n))
        lanesel = arith.remsi(lane, c(16))
        krow = arith.addi(c(h * atom.k + 0),
                          arith.addi(arith.muli(arith.divsi(lanesel, c(8)),
                                                c(8)),
                                     arith.remsi(lane, c(8))))
        chunk = arith.divsi(n0, c(atom.v16))
        sw = chunk if crb_mask == 0 else arith.xori(
            chunk, arith.andi(krow, c(crb_mask)))
        off = arith.addi(arith.muli(krow, c(bn)),
                         arith.muli(sw, c(atom.v16)))
        addr = arith.addi(base_i32,
                          arith.muli(off, c(atom.elem.itemsize)))
        if fb is not None:
            wfc = self._wf_ctx
            fl = wfc["lane"]
            fls = FMo(fl, 16)
            fkrow = FA(FC(h * atom.k),
                       FA(FM(FD(fls, 8), FC(8)), FMo(fl, 8)))
            fn0 = FA(wfc["col_w"], FC(in_ * atom.n))
            fchunk = FD(fn0, atom.v16)
            fsw = fchunk if crb_mask == 0 else FX(fchunk,
                                                  FAn(fkrow, crb_mask))
            return addr, FA(FM(fkrow, FC(bn)), FM(fsw, FC(atom.v16)))
        return addr

    def _mma_frag_b_ldsm(self, atom, base_i32, bn: int, crb_mask: int,
                         lane, col_w, h: int, in_: int):
        """The B-fragment of one bf16 (k16, n8) atom as ONE
        ldmatrix.x2.trans: the trans fragment distributes (k, n) as the
        (k=t pair, n=g) bf16 pairs the atom wants. tf32 B stays per-lane
        (a 4B operand spans two b16 columns)."""
        return self._mma_ldsm_x2_trans(
            self._mma_frag_b_ldsm_addr(atom, base_i32, bn, crb_mask, lane,
                                       col_w, h, in_))

    def _mma_frag_a(self, atom: "MmaAtom", smem_a, base_a, bk: int,
                    swz_mask: int, g, t, row_w, h: int, im: int,
                    a_trans: bool, sdt=None, fb=None) -> list:
        """Materialize this lane's 4 A-fragment i32 registers for atom
        (h, im): element (row g + 8*(j%2), col t*ep + (j//2)*(k/2)) of the
        warp tile at rows row_w + im*16 (per-lane LDS, no ldmatrix).
        Plain A smem is (BM, BK) row-major, 16B chunks XOR-swizzled by
        row; transposed A smem is (BK, BM) k-major, unswizzled.
        sdt: the STAGED element dtype (f32 for the cast-in-kernel bf16
        route: two f32 loads + cvt.rn.bf16x2 pack per register).
        fb: base_a's wir form."""
        sdt = sdt or atom.elem
        c = self.c_i32
        regs = []
        k4 = atom.k // 2  # k span between the two fragment column halves
        row0 = arith.addi(row_w, c(im * atom.m))
        f32pk = sdt == tl.float32 and atom.kind == "bf16"
        if fb is not None:
            wfc = self._wf_ctx
            fg, ft = wfc["g"], wfc["t"]
            frow0 = FA(wfc["row_w"], FC(im * atom.m))
        for j in range(4):
            j1, j2 = j % 2, j // 2
            row = arith.addi(row0, arith.addi(g, c(8 * j1)))
            if a_trans:
                # k-major smem (BK, BM): element (m, k) at k*bk + m
                kk = arith.addi(c(h * atom.k + j2 * k4),
                                t if atom.ep == 1 else arith.shli(t, c(1)))
                addr = arith.addi(base_a,
                                  arith.addi(arith.muli(kk, c(bk)), row))
                if fb is not None:
                    frow = FA(frow0, FA(fg, FC(8 * j1)))
                    fkk = FA(FC(h * atom.k + j2 * k4),
                             ft if atom.ep == 1 else FM(ft, FC(2)))
                    faddr = FA(fb, FA(FM(fkk, FC(bk)), frow))
                if atom.ep == 1:
                    regs.append(self._mma_ld_i32(smem_a, addr,
                                                 faddr if fb is not None
                                                 else None))
                elif f32pk:
                    regs.append(self._mma_pack_bf16x2(
                        self._mma_ld_f32(smem_a, addr,
                                         faddr if fb is not None else None),
                        self._mma_ld_f32(smem_a, arith.addi(addr, c(bk)),
                                         FA(faddr, FC(bk))
                                         if fb is not None else None)))
                else:
                    regs.append(self._mma_ld_strided2_i32(
                        smem_a, addr, arith.addi(addr, c(bk)),
                        faddr if fb is not None else None,
                        FA(faddr, FC(bk)) if fb is not None else None))
            elif f32pk:
                # f32-staged (BM, BK): 4-elem chunks; fold the t-dependent
                # chunk/offset into the swizzle math
                v16s = 4  # 16B / 4B
                tph = arith.shli(t, c(1))  # t * ep, ep == 2
                chunk = arith.addi(
                    c(h * (atom.k // v16s) + j2 * (k4 // v16s)),
                    arith.shrui(tph, c(2)))
                sw = arith.xori(chunk, arith.andi(row, c(swz_mask)))
                addr = arith.addi(
                    base_a,
                    arith.addi(arith.muli(row, c(bk)),
                               arith.addi(arith.muli(sw, c(v16s)),
                                          arith.andi(tph, c(v16s - 1)))))
                if fb is not None:
                    frow = FA(frow0, FA(fg, FC(8 * j1)))
                    ftph = FM(ft, FC(2))
                    fchunk = FA(FC(h * (atom.k // v16s)
                                   + j2 * (k4 // v16s)),
                                FD(ftph, 4))
                    fsw = FX(fchunk, FAn(frow, swz_mask))
                    faddr = FA(fb, FA(FM(frow, FC(bk)),
                                      FA(FM(fsw, FC(v16s)),
                                         FAn(ftph, v16s - 1))))
                regs.append(self._mma_pack_bf16x2(
                    self._mma_ld_f32(smem_a, addr,
                                     faddr if fb is not None else None),
                    self._mma_ld_f32(smem_a, arith.addi(addr, c(1)),
                                     FA(faddr, FC(1))
                                     if fb is not None else None)))
            else:
                # (BM, BK) row-major; chunk 2h + j2 of the swizzled row
                sw = arith.xori(c(h * (atom.k // atom.v16) + j2),
                                arith.andi(row, c(swz_mask)))
                addr = arith.addi(
                    base_a,
                    arith.addi(arith.muli(row, c(bk)),
                               arith.addi(arith.muli(sw, c(atom.v16)),
                                          arith.muli(t, c(atom.ep)))))
                if fb is not None:
                    frow = FA(frow0, FA(fg, FC(8 * j1)))
                    fsw = FX(FC(h * (atom.k // atom.v16) + j2),
                             FAn(frow, swz_mask))
                    faddr = FA(fb, FA(FM(frow, FC(bk)),
                                      FA(FM(fsw, FC(atom.v16)),
                                         FM(ft, FC(atom.ep)))))
                regs.append(
                    self._mma_ld_i32(smem_a, addr,
                                     faddr if fb is not None else None)
                    if atom.ep == 1
                    else self._mma_ld_adj2_i32(
                        smem_a, addr, faddr if fb is not None else None))
        return regs

    def _mma_frag_b(self, atom: "MmaAtom", smem_b, base_b, bk: int, bn: int,
                    crb_mask: int, crk_mask: int, g, t, col_w, h: int,
                    in_: int, b_trans: bool, sdt=None, fb=None) -> list:
        """Materialize this lane's 2 B-fragment i32 registers for atom
        (h, in_): element (row t*ep + j*(k/2), col g) of the warp tile at
        cols col_w + in_*8. Plain B smem is (BK, BN) row-major, 16B chunks
        XOR-swizzled by k; transposed B smem is (BN, BK) column-major,
        swizzled by n. sdt: the STAGED element dtype (f32 for the
        cast-in-kernel bf16 route). fb: base_b's wir form."""
        sdt = sdt or atom.elem
        c = self.c_i32
        regs = []
        k4 = atom.k // 2
        f32pk = sdt == tl.float32 and atom.kind == "bf16"
        if fb is not None:
            wfc = self._wf_ctx
            fg, ft = wfc["g"], wfc["t"]
        if b_trans:
            # column-major (BN, BK): element (k, n) at n*bk + k
            ncol = arith.addi(col_w, arith.addi(c(in_ * atom.n), g))
            for j in range(2):
                if f32pk:
                    # f32-staged, 4-elem (16B) chunks along k; fold the
                    # t*2 pair's chunk/offset into the swizzle math
                    v16s = 4
                    tph = arith.shli(t, c(1))
                    chunk = arith.addi(
                        c(h * (atom.k // v16s) + j * (k4 // v16s)),
                        arith.shrui(tph, c(2)))
                    sw = arith.xori(chunk, arith.andi(ncol, c(crk_mask)))
                    addr = arith.addi(
                        base_b,
                        arith.addi(arith.muli(ncol, c(bk)),
                                   arith.addi(arith.muli(sw, c(v16s)),
                                              arith.andi(tph, c(v16s - 1)))))
                    if fb is not None:
                        fncol = FA(FA(wfc["col_w"], FC(in_ * atom.n)), fg)
                        ftph = FM(ft, FC(2))
                        fchunk = FA(FC(h * (atom.k // v16s)
                                       + j * (k4 // v16s)),
                                    FD(ftph, 4))
                        fsw = FX(fchunk, FAn(fncol, crk_mask))
                        faddr = FA(fb, FA(FM(fncol, FC(bk)),
                                          FA(FM(fsw, FC(v16s)),
                                             FAn(ftph, v16s - 1))))
                    regs.append(self._mma_pack_bf16x2(
                        self._mma_ld_f32(smem_b, addr,
                                         faddr if fb is not None else None),
                        self._mma_ld_f32(smem_b, arith.addi(addr, c(1)),
                                         FA(faddr, FC(1))
                                         if fb is not None else None)))
                    continue
                sw = arith.xori(c(h * (atom.k // atom.v16) + j),
                                arith.andi(ncol, c(crk_mask)))
                addr = arith.addi(
                    base_b,
                    arith.addi(arith.muli(ncol, c(bk)),
                               arith.addi(arith.muli(sw, c(atom.v16)),
                                          arith.muli(t, c(atom.ep)))))
                if fb is not None:
                    fncol = FA(FA(wfc["col_w"], FC(in_ * atom.n)), fg)
                    fsw = FX(FC(h * (atom.k // atom.v16) + j),
                             FAn(fncol, crk_mask))
                    faddr = FA(fb, FA(FM(fncol, FC(bk)),
                                      FA(FM(fsw, FC(atom.v16)),
                                         FM(ft, FC(atom.ep)))))
                regs.append(
                    self._mma_ld_i32(smem_b, addr,
                                     faddr if fb is not None else None)
                    if atom.ep == 1
                    else self._mma_ld_adj2_i32(
                        smem_b, addr, faddr if fb is not None else None))
            return regs
        n_base = arith.addi(col_w, c(in_ * atom.n))
        ca = arith.divsi(n_base, c(atom.v16))  # first 16B chunk of the atom
        for j in range(2):
            kk = arith.addi(c(h * atom.k + j * k4), arith.shli(t, c(1))) \
                if atom.ep != 1 else arith.addi(c(h * atom.k + j * k4), t)
            if fb is not None:
                fkk = FA(FC(h * atom.k + j * k4),
                         FM(ft, FC(2)) if atom.ep != 1 else ft)
                fn_base = FA(wfc["col_w"], FC(in_ * atom.n))
            if atom.ep == 1:
                chunk = arith.addi(ca, arith.shrui(g, c(2)))
                sw = arith.xori(chunk, arith.andi(kk, c(crb_mask)))
                addr = arith.addi(
                    base_b,
                    arith.addi(arith.muli(kk, c(bn)),
                               arith.addi(arith.muli(sw, c(atom.v16)),
                                          arith.andi(g, c(3)))))
                if fb is not None:
                    fchunk = FA(FD(fn_base, atom.v16), FD(fg, 4))
                    fsw = FX(fchunk, FAn(fkk, crb_mask))
                    faddr = FA(fb, FA(FM(fkk, FC(bn)),
                                      FA(FM(fsw, FC(atom.v16)),
                                         FAn(fg, 3))))
                regs.append(self._mma_ld_i32(smem_b, addr,
                                             faddr if fb is not None
                                             else None))
            elif f32pk:
                # f32-staged (BK, BN): 4-elem chunks along n; the swizzle
                # is by k, evaluated per element of the (k, k+1) pair
                v16s = 4
                chunk = arith.addi(arith.divsi(n_base, c(v16s)),
                                   arith.shrui(g, c(2)))
                offn = arith.andi(g, c(v16s - 1))
                addrs = []
                for u in range(2):
                    ku = arith.addi(kk, c(u))
                    sw = arith.xori(chunk, arith.andi(ku, c(crb_mask)))
                    addrs.append(arith.addi(
                        base_b,
                        arith.addi(arith.muli(ku, c(bn)),
                                   arith.addi(arith.muli(sw, c(v16s)),
                                              offn))))
                if fb is not None:
                    fchunk = FA(FD(fn_base, v16s), FD(fg, 4))
                    foffn = FAn(fg, v16s - 1)
                    faddrs = [
                        FA(fb, FA(FM(FA(fkk, FC(u)), FC(bn)),
                                  FA(FM(FX(fchunk,
                                           FAn(FA(fkk, FC(u)), crb_mask)),
                                      FC(v16s)),
                                     foffn)))
                        for u in range(2)]
                regs.append(self._mma_pack_bf16x2(
                    self._mma_ld_f32(smem_b, addrs[0],
                                     faddrs[0] if fb is not None else None),
                    self._mma_ld_f32(smem_b, addrs[1],
                                     faddrs[1] if fb is not None else None)))
            else:
                addrs = []
                for u in range(2):
                    ku = arith.addi(kk, c(u))
                    sw = arith.xori(ca, arith.andi(ku, c(crb_mask)))
                    addrs.append(arith.addi(
                        base_b,
                        arith.addi(arith.muli(ku, c(bn)),
                                   arith.addi(arith.muli(sw, c(atom.v16)),
                                              g))))
                if fb is not None:
                    faddrs = [
                        FA(fb, FA(FM(FA(fkk, FC(u)), FC(bn)),
                                  FA(FM(FX(FD(fn_base, atom.v16),
                                           FAn(FA(fkk, FC(u)), crb_mask)),
                                        FC(atom.v16)),
                                     fg)))
                        for u in range(2)]
                regs.append(self._mma_ld_strided2_i32(
                    smem_b, addrs[0], addrs[1],
                    faddrs[0] if fb is not None else None,
                    faddrs[1] if fb is not None else None))
        return regs

    # -- mma operand staging (pass layer: global -> swizzled smem geometry) ---

    def _mma_stage_pre(self, atom, bm_or_bk, bk_or_bn, crv, swz_mask,
                       off, tid, kind: str, v16s: int = 0):
        """Vec-path staging prologue: per-thread (src_pre, dst_const) for
        every 16B chunk slot the thread copies (steady-loop issue is one
        add per cp.async). ``kind``: "a" stages (BM, BK) row-major
        swizzled by row; "b" (BK, BN) row-major swizzled by k; "bt"
        (BN, BK) column-major swizzled by n. v16s: staged elements per
        16B chunk (0 = the atom's)."""
        v16s = v16s or atom.v16
        c = self.c_i32
        out = []
        ann = self._wir_annotate_on()
        pre_dsts = getattr(self, "_wf_pre_dsts", None)
        if ann and pre_dsts is None:
            pre_dsts = self._wf_pre_dsts = {}
        if kind == "a":
            chunks = bm_or_bk * crv
            bodies = self._mma_chunk_indices(chunks, tid)
            exact = chunks % self.num_threads == 0
            for j, cc in enumerate(bodies):
                row = arith.divsi(cc, c(crv))
                jc = arith.remsi(cc, c(crv))
                src = arith.addi(
                    self.eval_affine(off.row, row),
                    self.eval_affine(off.col, arith.muli(jc, c(v16s))))
                sw = jc if swz_mask == 0 else arith.xori(
                    jc, arith.andi(row, c(swz_mask)))
                dst = arith.addi(arith.muli(row, c(bk_or_bn)),
                                 arith.muli(sw, c(v16s)))
                out.append((src, dst))
                if ann and exact:
                    fcc = FA(TID, FC(j * self.num_threads))
                    frow = FD(fcc, crv)
                    fjc = FMo(fcc, crv)
                    fsw = fjc if swz_mask == 0 else FX(
                        fjc, FAn(frow, swz_mask))
                    pre_dsts[id(dst)] = FA(FM(frow, FC(bk_or_bn)),
                                           FM(fsw, FC(v16s)))
        elif kind == "b":
            chunks = bm_or_bk * crv
            bodies = self._mma_chunk_indices(chunks, tid)
            exact = chunks % self.num_threads == 0
            for j, cc in enumerate(bodies):
                kk = arith.divsi(cc, c(crv))
                jc = arith.remsi(cc, c(crv))
                src = arith.addi(
                    self.eval_affine(off.row, kk),
                    self.eval_affine(off.col,
                                     arith.muli(jc, c(v16s))))
                sw = jc if swz_mask == 0 else arith.xori(
                    jc, arith.andi(kk, c(swz_mask)))
                dst = arith.addi(arith.muli(kk, c(bk_or_bn)),
                                 arith.muli(sw, c(v16s)))
                out.append((src, dst))
                if ann and exact:
                    fcc = FA(TID, FC(j * self.num_threads))
                    fkk = FD(fcc, crv)
                    fjc = FMo(fcc, crv)
                    fsw = fjc if swz_mask == 0 else FX(
                        fjc, FAn(fkk, swz_mask))
                    pre_dsts[id(dst)] = FA(FM(fkk, FC(bk_or_bn)),
                                           FM(fsw, FC(v16s)))
        else:  # bt: column-major (BN, BK), 16B chunks along k
            chunks = bk_or_bn * crv
            bodies = self._mma_chunk_indices(chunks, tid)
            exact = chunks % self.num_threads == 0
            for j, cc in enumerate(bodies):
                nn = arith.divsi(cc, c(crv))
                jc = arith.remsi(cc, c(crv))
                src = arith.addi(
                    self.eval_affine(off.row, arith.muli(jc, c(v16s))),
                    self.eval_affine(off.col, nn))
                sw = jc if swz_mask == 0 else arith.xori(
                    jc, arith.andi(nn, c(swz_mask)))
                dst = arith.addi(arith.muli(nn, c(bm_or_bk)),
                                 arith.muli(sw, c(v16s)))
                out.append((src, dst))
                if ann and exact:
                    fcc = FA(TID, FC(j * self.num_threads))
                    fnn = FD(fcc, crv)
                    fjc = FMo(fcc, crv)
                    fsw = fjc if swz_mask == 0 else FX(
                        fjc, FAn(fnn, swz_mask))
                    pre_dsts[id(dst)] = FA(FM(fnn, FC(bm_or_bk)),
                                           FM(fsw, FC(v16s)))
        return out

    def _mma_chunk_indices(self, chunks: int, tid):
        """The list of per-thread chunk indices [tid + j*nt], tail-clamped
        (same duplicate-copy trick as _mma_chunk_loop); used by the vec
        staging prologue."""
        nt = self.num_threads
        cc_list = []
        c = self.c_i32
        limit = c(chunks - 1)
        for j in range((chunks + nt - 1) // nt):
            cc = arith.addi(tid, c(j * nt))
            if chunks % nt:
                cc = self.select(self.compare("<", cc, c(chunks), tl.int32),
                                 cc, limit)
            cc_list.append(cc)
        return cc_list

    def _mma_stage_vec_fast(self, toks, smem, parg, stage, k_adv, S: int,
                            pre, num: int, sf=None):
        """Steady-state vec staging: one 16B cp.async per precomputed slot
        (src = pre.src + k_adv, dst = stage*S + pre.dst). sf: the stage
        index's wir form; the slot dsts' forms come from the prologue."""
        c = self.c_i32
        dst_base = arith.muli(stage, c(S))
        role = self._wir_smem_role(smem)
        for src, dst in pre:
            op = nvgpu.device_async_copy(
                smem, [self.to_index(arith.addi(dst_base, dst))],
                parg.scalar_view,
                [self.to_index(arith.addi(src, k_adv))], num,
                bypass_l1=True)
            if sf is not None:
                fdst = getattr(self, "_wf_pre_dsts", {}).get(id(dst))
                self._wir_attr(op, role, FA(FM(sf, FC(S)), fdst)
                               if fdst is not None else None, num)
            toks.append(op)

    def _mma_unit_copy(self, toks, smem, dst, src_view, addr, gran: int,
                       oks, form=None, prefix: bool = True):
        """One 4B cp.async of ``gran`` elements (gran = 4B / elemsize), with
        per-element predicates folded into a src-size zero-fill. ``oks``:
        one entry per element of the unit; None = always in bounds.
        ``prefix``: the oks pattern within a unit is prefix-shaped
        (``offs < hi`` form) — only then is the src-size zfill fold
        legal (it copies a leading run and zero-fills the tail). A
        non-prefix mask (e.g. ``offs >= lo``) would copy the wrong
        elements and zero the live ones, so those units stage
        synchronously: one predicated LDG + STS per element, no cp.async
        token (the pipeline's wait + bar.sync still order the STS ahead
        of the consuming mma; the token/group accounting only tracks
        cp.asyncs)."""
        if any(ok is not None for ok in oks) and not prefix:
            ety = ir.MemRefType(src_view.type).element_type
            zero = arith.constant(ety, 0.0)
            for w in range(gran):
                addr_w = addr if w == 0 else arith.addi(addr, self.c_i32(w))
                ok = oks[w]
                if ok is None:
                    v = memref.LoadOp(src_view,
                                      [self.to_index(addr_w)]).result
                else:
                    safe = self.select(ok, addr_w, self.c_i32(0))
                    v = memref.LoadOp(src_view,
                                      [self.to_index(safe)]).result
                    v = self.select(ok, v, zero)
                dst_w = dst if w == 0 else arith.addi(dst, self.c_i32(w))
                memref.StoreOp(v, smem, [self.to_index(dst_w)])
            return
        se = None
        if any(ok is not None for ok in oks):
            se = self.c_idx(0)
            for ok in oks:
                if ok is None:
                    se = arith.addi(se, self.c_idx(1))
                else:
                    se = arith.addi(se, self.select(ok, self.c_idx(1),
                                                    self.c_idx(0)))
            if oks[0] is not None:
                addr = self.select(oks[0], addr, self.c_i32(0))
        op = nvgpu.device_async_copy(
            smem, [self.to_index(dst)], src_view, [self.to_index(addr)],
            gran, src_elements=se)
        self._wir_attr(op, self._wir_smem_role(smem), form, gran)
        toks.append(op)

    def _mma_chunk_loop(self, chunks: int, tid, body):
        """body(c_i32, form) for c in {tid + j*nt}: out-of-range tail
        indices clamp to the last chunk (a benign duplicate copy keeps the
        async-group tokens uniform). Copies must never be guarded by
        control flow (a token defined inside scf.if cannot feed the
        create_group outside it)."""
        nt = self.num_threads
        rounds = (chunks + nt - 1) // nt
        ann = self._wir_annotate_on() and chunks % nt == 0
        if chunks % nt == 0:
            for j in range(rounds):
                body(arith.addi(tid, self.c_i32(j * nt)),
                     FA(TID, FC(j * nt)) if ann else None)
        else:
            limit = self.c_i32(chunks - 1)
            for j in range(rounds):
                cc = arith.addi(tid, self.c_i32(j * nt))
                body(self.select(
                    self.compare("<", cc, self.c_i32(chunks), tl.int32),
                    cc, limit), None)

    def _mma_stage_a(self, atom, smem, stage, tid, k0, bm, bk, cra,
                     swz_mask, a_off, a_parg, vec, trans, tile_ok, row_ok,
                     k_ok, fold_ok, toks, tvec: bool = False,
                     swz_tmask: int | None = None, sf=None,
                     prefix: bool = True):
        """Enqueue the (BM, BK) A tile of one pipeline stage (cp.async).
        Plain A: smem (BM, BK) row-major, 16B chunks XOR-swizzled by row
        (read side: _mma_frag_a); vec path = 16B copies, masked path = 4B
        zfill. Transposed A: k-major smem (BK, BM), unswizzled, 16B chunks
        when tvec else 4B units. The staged dtype is the operand's own
        (f32 for the cast-in-kernel bf16 route). sf: the stage's wir form.
        prefix: the unit-varying mask preds are prefix-shaped (see
        _mma_unit_copy); False forces the synchronous predicated path.
        """
        c = self.c_i32
        sdt = a_parg.elem
        v16s = 16 // sdt.itemsize
        gran = 4 // sdt.itemsize
        dst_base = arith.muli(stage, c(bm * bk))
        if not trans:
            if vec:
                def body(cc, fcc=None):
                    row = arith.divsi(cc, c(cra))
                    jc = arith.remsi(cc, c(cra))
                    addr = arith.addi(
                        self.eval_affine(a_off.row, row),
                        self.eval_affine(a_off.col, arith.addi(
                            k0, arith.muli(jc, c(v16s)))))
                    sw = jc if swz_mask == 0 else arith.xori(
                        jc, arith.andi(row, c(swz_mask)))
                    dst = arith.addi(dst_base, arith.addi(
                        arith.muli(row, c(bk)),
                        arith.muli(sw, c(v16s))))
                    op = nvgpu.device_async_copy(
                        smem, [self.to_index(dst)], a_parg.scalar_view,
                        [self.to_index(addr)], v16s, bypass_l1=True)
                    if fcc is not None:
                        frow = FD(fcc, cra)
                        fjc = FMo(fcc, cra)
                        fsw = fjc if swz_mask == 0 else FX(
                            fjc, FAn(frow, swz_mask))
                        self._wir_attr(
                            op, self._wir_smem_role(smem),
                            FA(FM(sf, FC(bm * bk)),
                               FA(FM(frow, FC(bk)), FM(fsw, FC(v16s)))),
                            v16s)
                    toks.append(op)
                self._mma_chunk_loop(bm * cra, tid, body)
            else:
                upr = bk // gran  # 4B units per row
                upc = v16s // gran  # units per 16B chunk

                def body(cc, fcc=None):
                    row = arith.divsi(cc, c(upr))
                    u = arith.remsi(cc, c(upr))
                    jc = arith.divsi(u, c(upc))
                    kk0 = arith.muli(u, c(gran))
                    rok = row_ok(row)
                    oks = [fold_ok(fold_ok(tile_ok, rok),
                                   k_ok(k0, arith.addi(kk0, c(w))))
                           for w in range(gran)]
                    addr = arith.addi(
                        self.eval_affine(a_off.row, row),
                        self.eval_affine(a_off.col, arith.addi(k0, kk0)))
                    sw = jc if swz_mask == 0 else arith.xori(
                        jc, arith.andi(row, c(swz_mask)))
                    dst = arith.addi(dst_base, arith.addi(
                        arith.muli(row, c(bk)),
                        arith.addi(arith.muli(sw, c(v16s)),
                                   arith.muli(arith.remsi(u, c(upc)),
                                              c(gran)))))
                    if fcc is not None:
                        frow = FD(fcc, upr)
                        fu = FMo(fcc, upr)
                        fjc = FD(fu, upc)
                        fsw = fjc if swz_mask == 0 else FX(
                            fjc, FAn(frow, swz_mask))
                        form = FA(FM(sf, FC(bm * bk)),
                                  FA(FM(frow, FC(bk)),
                                     FA(FM(fsw, FC(v16s)),
                                        FM(FMo(fu, upc), FC(gran)))))
                    else:
                        form = None
                    self._mma_unit_copy(toks, smem, dst, a_parg.scalar_view,
                                        addr, gran, oks, form, prefix=prefix)
                self._mma_chunk_loop(bm * upr, tid, body)
        else:
            # k-major smem (BK, BM): element (m, k) at k*bm + m; 16B chunks
            # (tvec) or 4B units along m. bf16 tiles XOR-swizzle the 16B
            # m-chunks by k row (the ldmatrix.x4.trans read would otherwise
            # land on one bank group); per-lane paths stay unswizzled.
            swz_on = swz_tmask is not None and atom.kind == "bf16" \
                and sdt == atom.elem
            if vec and tvec:
                cpr = bm // v16s   # 16B chunks per kk row

                def body16(cc, fcc=None):
                    kk = arith.divsi(cc, c(cpr))
                    jc = arith.remsi(cc, c(cpr))
                    m0 = arith.muli(jc, c(v16s))
                    addr = arith.addi(
                        self.eval_affine(a_off.row, m0),
                        self.eval_affine(a_off.col, arith.addi(k0, kk)))
                    sw = jc if not swz_on else arith.xori(
                        jc, arith.andi(kk, c(swz_tmask)))
                    dst = arith.addi(dst_base, arith.addi(
                        arith.muli(kk, c(bm)), arith.muli(sw, c(v16s))))
                    op = nvgpu.device_async_copy(
                        smem, [self.to_index(dst)], a_parg.scalar_view,
                        [self.to_index(addr)], v16s, bypass_l1=True)
                    if fcc is not None:
                        fkk = FD(fcc, cpr)
                        fjc = FMo(fcc, cpr)
                        fsw = fjc if not swz_on else FX(
                            fjc, FAn(fkk, swz_tmask))
                        self._wir_attr(
                            op, self._wir_smem_role(smem),
                            FA(FM(sf, FC(bm * bk)),
                               FA(FM(fkk, FC(bm)), FM(fsw, FC(v16s)))),
                            v16s)
                    toks.append(op)
                self._mma_chunk_loop(bk * cpr, tid, body16)
                return
            upr = bm // gran
            upc = v16s // gran

            def body(cc, fcc=None):
                kk = arith.divsi(cc, c(upr))
                u = arith.remsi(cc, c(upr))
                m0 = arith.muli(u, c(gran))
                oks = [fold_ok(fold_ok(tile_ok, row_ok(arith.addi(m0, c(w)))),
                               k_ok(k0, kk)) for w in range(gran)]
                addr = arith.addi(self.eval_affine(a_off.row, m0),
                                  self.eval_affine(a_off.col,
                                                   arith.addi(k0, kk)))
                jc = arith.divsi(u, c(upc))
                sw = jc if not swz_on else arith.xori(
                    jc, arith.andi(kk, c(swz_tmask)))
                dst = arith.addi(dst_base, arith.addi(
                    arith.muli(kk, c(bm)),
                    arith.addi(arith.muli(sw, c(v16s)),
                               arith.muli(arith.remsi(u, c(upc)),
                                          c(gran)))))
                if fcc is not None:
                    fkk = FD(fcc, upr)
                    fu = FMo(fcc, upr)
                    fjc = FD(fu, upc)
                    fsw = fjc if not swz_on else FX(
                        fjc, FAn(fkk, swz_tmask))
                    form = FA(FM(sf, FC(bm * bk)),
                              FA(FM(fkk, FC(bm)),
                                 FA(FM(fsw, FC(v16s)),
                                    FM(FMo(fu, upc), FC(gran)))))
                else:
                    form = None
                self._mma_unit_copy(toks, smem, dst, a_parg.scalar_view,
                                    addr, gran, oks, form, prefix=prefix)
            self._mma_chunk_loop(bk * upr, tid, body)

    def _mma_stage_b(self, atom, smem, stage, tid, k0, bk, bn, crb,
                     swz_mask, swz_tmask, b_off, b_parg, vec, trans, tile_ok,
                     k_ok, col_ok, fold_ok, toks, tvec: bool = False,
                     sf=None, prefix: bool = True):
        """Enqueue the (BK, BN) B tile of one pipeline stage (cp.async).
        Plain B: smem (BK, BN) row-major, 16B chunks XOR-swizzled by k.
        Transposed B: column-major smem (BN, BK), chunks XOR-swizzled by
        n; 16B chunks when tvec else 4B units. The staged dtype is the
        operand's own (f32 for the cast-in-kernel bf16 route).
        sf: the stage's wir form. prefix: the unit-varying mask preds
        are prefix-shaped (see _mma_unit_copy); False forces the
        synchronous predicated path."""
        c = self.c_i32
        sdt = b_parg.elem
        v16s = 16 // sdt.itemsize
        gran = 4 // sdt.itemsize
        dst_base = arith.muli(stage, c(bk * bn))
        if not trans:
            ldb = b_off.row.stride
            k0n = arith.muli(k0, self.as_i32(ldb))
            if vec:
                def body(cc, fcc=None):
                    kk = arith.divsi(cc, c(crb))
                    jc = arith.remsi(cc, c(crb))
                    addr = arith.addi(
                        arith.addi(k0n, self.eval_affine(b_off.row, kk)),
                        self.eval_affine(b_off.col,
                                         arith.muli(jc, c(v16s))))
                    sw = jc if swz_mask == 0 else arith.xori(
                        jc, arith.andi(kk, c(swz_mask)))
                    dst = arith.addi(dst_base, arith.addi(
                        arith.muli(kk, c(bn)),
                        arith.muli(sw, c(v16s))))
                    op = nvgpu.device_async_copy(
                        smem, [self.to_index(dst)], b_parg.scalar_view,
                        [self.to_index(addr)], v16s, bypass_l1=True)
                    if fcc is not None:
                        fkk = FD(fcc, crb)
                        fjc = FMo(fcc, crb)
                        fsw = fjc if swz_mask == 0 else FX(
                            fjc, FAn(fkk, swz_mask))
                        self._wir_attr(
                            op, self._wir_smem_role(smem),
                            FA(FM(sf, FC(bk * bn)),
                               FA(FM(fkk, FC(bn)), FM(fsw, FC(v16s)))),
                            v16s)
                    toks.append(op)
                self._mma_chunk_loop(bk * crb, tid, body)
            else:
                upr = bn // gran
                upc = v16s // gran

                def body(cc, fcc=None):
                    kk = arith.divsi(cc, c(upr))
                    u = arith.remsi(cc, c(upr))
                    jc = arith.divsi(u, c(upc))
                    n0 = arith.muli(u, c(gran))
                    kok = k_ok(k0, kk)
                    oks = [fold_ok(fold_ok(tile_ok, kok),
                                   col_ok(arith.addi(n0, c(w))))
                           for w in range(gran)]
                    addr = arith.addi(
                        arith.addi(k0n, self.eval_affine(b_off.row, kk)),
                        self.eval_affine(b_off.col, n0))
                    sw = jc if swz_mask == 0 else arith.xori(
                        jc, arith.andi(kk, c(swz_mask)))
                    dst = arith.addi(dst_base, arith.addi(
                        arith.muli(kk, c(bn)),
                        arith.addi(arith.muli(sw, c(v16s)),
                                   arith.muli(arith.remsi(u, c(upc)),
                                              c(gran)))))
                    if fcc is not None:
                        fkk = FD(fcc, upr)
                        fu = FMo(fcc, upr)
                        fjc = FD(fu, upc)
                        fsw = fjc if swz_mask == 0 else FX(
                            fjc, FAn(fkk, swz_mask))
                        form = FA(FM(sf, FC(bk * bn)),
                                  FA(FM(fkk, FC(bn)),
                                     FA(FM(fsw, FC(v16s)),
                                        FM(FMo(fu, upc), FC(gran)))))
                    else:
                        form = None
                    self._mma_unit_copy(toks, smem, dst, b_parg.scalar_view,
                                        addr, gran, oks, form, prefix=prefix)
                self._mma_chunk_loop(bk * upr, tid, body)
        else:
            # column-major smem (BN, BK): element (k, n) at n*bk + k; 16B
            # chunks (tvec) or 4B units along the (contiguous) k direction.
            if vec and tvec:
                cpc = bk // v16s   # 16B chunks per column

                def body16(cc, fcc=None):
                    nn = arith.divsi(cc, c(cpc))
                    jc = arith.remsi(cc, c(cpc))
                    addr = arith.addi(
                        self.eval_affine(
                            b_off.row,
                            arith.addi(k0, arith.muli(jc, c(v16s)))),
                        self.eval_affine(b_off.col, nn))
                    sw = jc if swz_tmask == 0 else arith.xori(
                        jc, arith.andi(nn, c(swz_tmask)))
                    dst = arith.addi(dst_base, arith.addi(
                        arith.muli(nn, c(bk)),
                        arith.muli(sw, c(v16s))))
                    op = nvgpu.device_async_copy(
                        smem, [self.to_index(dst)], b_parg.scalar_view,
                        [self.to_index(addr)], v16s, bypass_l1=True)
                    if fcc is not None:
                        fnn = FD(fcc, cpc)
                        fjc = FMo(fcc, cpc)
                        fsw = fjc if swz_tmask == 0 else FX(
                            fjc, FAn(fnn, swz_tmask))
                        self._wir_attr(
                            op, self._wir_smem_role(smem),
                            FA(FM(sf, FC(bk * bn)),
                               FA(FM(fnn, FC(bk)), FM(fsw, FC(v16s)))),
                            v16s)
                    toks.append(op)
                self._mma_chunk_loop(bn * cpc, tid, body16)
                return
            upr = bk // gran
            upc = v16s // gran

            def body(cc, fcc=None):
                nn = arith.divsi(cc, c(upr))
                u = arith.remsi(cc, c(upr))
                kk0 = arith.muli(u, c(gran))
                cok = col_ok(nn)
                oks = [fold_ok(fold_ok(tile_ok, cok),
                               k_ok(k0, arith.addi(kk0, c(w))))
                       for w in range(gran)]
                addr = arith.addi(
                    self.eval_affine(b_off.row, arith.addi(k0, kk0)),
                    self.eval_affine(b_off.col, nn))
                jc = arith.divsi(u, c(upc))
                sw = jc if swz_tmask == 0 else arith.xori(
                    jc, arith.andi(nn, c(swz_tmask)))
                dst = arith.addi(dst_base, arith.addi(
                    arith.muli(nn, c(bk)),
                    arith.addi(arith.muli(sw, c(v16s)),
                               arith.muli(arith.remsi(u, c(upc)),
                                          c(gran)))))
                if fcc is not None:
                    fnn = FD(fcc, upr)
                    fu = FMo(fcc, upr)
                    fjc = FD(fu, upc)
                    fsw = fjc if swz_tmask == 0 else FX(
                        fjc, FAn(fnn, swz_tmask))
                    form = FA(FM(sf, FC(bk * bn)),
                              FA(FM(fnn, FC(bk)),
                                 FA(FM(fsw, FC(v16s)),
                                    FM(FMo(fu, upc), FC(gran)))))
                else:
                    form = None
                self._mma_unit_copy(toks, smem, dst, b_parg.scalar_view,
                                    addr, gran, oks, form, prefix=prefix)
            self._mma_chunk_loop(bn * upr, tid, body)

    # -- mma pipeline driver (pass layer: tile -> fragment program) ----------

    def _mma_warp_grid(self, bm: int, bn: int, warps: int):
        """Pick the (wn_m, wn_n) warp grid: warp tiles must be multiples of
        the mma atom (wa_m % 16 == 0, wa_n % 8 == 0); prefer the most
        square atom count (minimizes operand reloads per mma)."""
        best = None
        for wm in range(1, warps + 1):
            if warps % wm:
                continue
            wn = warps // wm
            if bm % (16 * wm) or bn % (8 * wn):
                continue
            am, an = bm // (16 * wm), bn // (8 * wn)
            if am * an > 32:
                # > 128 C-fragment registers/thread: register pressure
                # beyond the 64-reg sweet spot, skip unless nothing fits
                continue
            key = (min(am, an), -abs(am - an), -wm)
            if best is None or key > best[0]:
                best = (key, wm, wn)
        if best is None:
            # fall back to the register-heavy grids
            for wm in range(1, warps + 1):
                if warps % wm:
                    continue
                wn = warps // wm
                if bm % (16 * wm) or bn % (8 * wn):
                    continue
                am, an = bm // (16 * wm), bn // (8 * wn)
                key = (min(am, an), -abs(am - an), -wm)
                if best is None or key > best[0]:
                    best = (key, wm, wn)
        if best is None:
            raise TileConfigError(
                f"mma_tile: no warp grid for ({bm}, {bn}) with {warps} "
                f"warps (wa_m % 16 / wa_n % 8 must hold)")
        return best[1], best[2]

    def mma_tile(self, a_pt: PtrTensor, b_pt: PtrTensor, K,
                 atom: str = "tf32", wn_m: int | None = None,
                 wn_n: int | None = None, stages: int = 2, vec: bool = True,
                 even_k: bool = True, a_mask=None, b_mask=None,
                 a_trans: bool = False, b_trans: bool = False,
                 a_tvec: bool = False, b_tvec: bool = False,
                 one_bar: bool = False, f2f: bool = False,
                 dyn_smem: bool = False, one_shot: bool = False) -> Tensor:
        """Tensor-core matmul: C tile (BM, BN) = A (BM, BK) @ B (BK, BN)
        over the whole K loop with mma.sync; returns the m4-fragment
        accumulator (store via store_m4). Same staging contract as
        matmul_tile (vec = unmasked 16B path, pow2 swizzle chunk counts;
        vec=False = 4B zfill + a_mask/b_mask; TRANS views folded into
        staging). atom: "tf32" | "tf32x3" | "bf16"; wn_m/wn_n: warp grid
        (default: picked); stages: pipeline depth. a_tvec/b_tvec: 16B
        transposed staging (bf16, aligned K stride). one_bar: single-
        barrier schedule. f2f / dyn_smem / one_shot: opt-in schedules
        (LDG->reg->STS staging / dynamic smem / short-K single-buffer).
        """
        atom = mma_atom(atom) if isinstance(atom, str) else atom
        if f2f and not (vec and not a_trans and not b_trans
                        and a_mask is None and b_mask is None
                        and stages >= 2 and even_k):
            raise TileConfigError(
                "tl.mma_tile f2f is a vec-path, plain-layout, even-K, "
                "stages>=2 schedule")
        if one_shot and (f2f or one_bar):
            raise TileConfigError(
                "tl.mma_tile one_shot is a standalone schedule "
                "(incompatible with f2f / one_bar)")
        a_off, b_off = a_pt.off, b_pt.off
        a_parg, b_parg = a_pt.arg, b_pt.arg
        for tv, tr, nm in ((a_tvec, a_trans, "a"), (b_tvec, b_trans, "b")):
            if tv and not tr:
                raise TileConfigError(
                    f"tl.mma_tile {nm}_tvec needs {nm.upper()}_TRANS")
            if tv and not vec:
                raise TileConfigError(
                    f"tl.mma_tile {nm}_tvec is a vec-path feature")
        ea_parg_elem = a_parg.elem
        eb_parg_elem = b_parg.elem
        if atom.kind == "bf16":
            # bf16 mma also takes f32 operands (cast-in-kernel route):
            # staged as f32, packed to bf16x2 at the fragment
            for nm, e, tv in (("a", ea_parg_elem, a_tvec),
                              ("b", eb_parg_elem, b_tvec)):
                if e not in (tl.bfloat16, tl.float32):
                    raise TileConfigError(
                        f"tl.mma_tile {atom.kind} expects bf16/f32 "
                        f"operands, got {ea_parg_elem}/{eb_parg_elem}")
                if tv and e != tl.bfloat16:
                    raise TileConfigError(
                        f"tl.mma_tile {nm}_tvec needs a bf16 {nm.upper()} "
                        "operand")
        elif a_parg.elem != atom.elem or b_parg.elem != atom.elem:
            raise TileConfigError(
                f"tl.mma_tile {atom.kind} expects {atom.elem} operands, got "
                f"{a_parg.elem}/{b_parg.elem}")
        if len(a_off.shape) != 2 or len(b_off.shape) != 2:
            raise TileConfigError("tl.mma_tile expects 2D pointer tiles")
        bm, bk = a_off.shape
        bk2, bn = b_off.shape
        if bk != bk2:
            raise TileConfigError(
                f"tl.mma_tile inner-dim mismatch: {a_off.shape} vs "
                f"{b_off.shape}")
        if one_shot and isinstance(K, CExpr) and isinstance(K.value, int) and stages * bk < K.value:
            raise TileConfigError(
                "tl.mma_tile one_shot needs STAGES * BK >= K "
                f"(stages={stages}, BK={bk}, K={K.value}) — the whole K "
                "extent is staged by the prologue, reading past the "
                "buffer otherwise")
        for name, off, tr in (("a", a_off, a_trans), ("b", b_off, b_trans)):
            if tr:
                if not (isinstance(off.row.stride, int)
                        and off.row.stride == 1):
                    raise TileConfigError(
                        f"tl.mma_tile transposed {name} needs unit stride "
                        f"along its tile rows (the contiguous dim)")
            elif not (isinstance(off.col.stride, int)
                      and off.col.stride == 1):
                raise TileConfigError(f"tl.mma_tile needs unit column stride "
                                      f"on {name}")
        if vec and (a_mask is not None or b_mask is not None):
            raise TileConfigError("tl.mma_tile vec path takes no masks")
        # staging consumes a_mask's row preds (M) and b_mask's col preds
        # (N) only; a K-dim predicate would be silently dropped
        if a_mask is not None and a_mask.col_preds:
            raise TileConfigError(
                "tl.mma_tile a_mask guards A's rows (M) only — K-dim "
                "masking is the K argument / EVEN_K prefix convention's "
                "job, not a_mask's")
        if b_mask is not None and b_mask.row_preds:
            raise TileConfigError(
                "tl.mma_tile b_mask guards B's columns (N) only — K-dim "
                "masking is the K argument / EVEN_K prefix convention's "
                "job, not b_mask's")
        if vec and not even_k:
            raise TileConfigError(
                "tl.mma_tile vec path needs even_k (K % BK == 0); use "
                "vec=False with masks for ragged K")
        if bk % atom.k or bk % atom.v16 or bn % atom.v16 or bm % atom.v16:
            raise TileConfigError(
                f"tl.mma_tile needs BK % {max(atom.k, atom.v16)} == 0 and "
                f"BM/BN % {atom.v16} == 0, got ({bm}, {bk}) x ({bk}, {bn})")
        nt = self.num_threads
        if nt % 32:
            raise TileConfigError("tl.mma_tile needs num_threads % 32 == 0")
        warps = nt // 32
        if wn_m is None and wn_n is None:
            wn_m, wn_n = self._mma_warp_grid(bm, bn, warps)
        if wn_m * wn_n != warps:
            raise TileConfigError(
                f"tl.mma_tile warp grid ({wn_m} x {wn_n}) != warps ({warps})")
        if bm % (atom.m * wn_m) or bn % (atom.n * wn_n):
            raise TileConfigError(
                f"tl.mma_tile warp tile not divisible by the atom: "
                f"({bm}/{wn_m}, {bn}/{wn_n}) vs ({atom.m}, {atom.n})")
        wa_m, wa_n = bm // wn_m, bn // wn_n
        atoms_m, atoms_n = wa_m // atom.m, wa_n // atom.n
        # staged-element geometry, per operand (bf16: 8/16B, f32: 4/16B)
        v16a = 16 // ea_parg_elem.itemsize
        v16b = 16 // eb_parg_elem.itemsize
        cra = bk // v16a
        crb = bn // v16b
        crbt = bk // v16b  # transposed-B chunks run along k
        # XOR-swizzle masks on 16B-chunk indices (chunk ^ (row & swz)):
        # chunks-1 keeps the XOR inside the (power-of-two) chunk row;
        # 15 caps the pattern at the row's low 4 bits (16-row period,
        # spanning <= 16 chunks = 256B)
        swz_a = min(cra - 1, 15)
        swz_b = min(crb - 1, 15)
        swz_bt = min(crbt - 1, 15)
        # transposed-A (k-major) chunks run along m; the ldmatrix.x4.trans
        # fragment path needs them XOR-swizzled by k row
        swz_at = min(bm // v16a - 1, 15)
        # the smem XOR swizzle stays inside its row only for a power-of-two
        # 16B-chunk count (same constraint as _store_m4_smem)
        swz_req = []  # (extent name, extent, 16B chunks per staged row)
        if not a_trans:
            swz_req.append(("BK", bk, cra))
        elif atom.kind == "bf16" and ea_parg_elem == atom.elem:
            # transposed A swizzles its 16B m-chunks by k row (bf16 only;
            # tf32/f32-staged trans-A smem is unswizzled)
            swz_req.append(("BM", bm, bm // v16a))
        if not b_trans:
            swz_req.append(("BN", bn, crb))
        else:
            # transposed B swizzles its 16B k-chunks by n (all atom kinds)
            swz_req.append(("BK", bk, crbt))
        for nm, ext, cr in swz_req:
            if cr & (cr - 1):
                raise TileConfigError(
                    f"tl.mma_tile {nm}={ext} gives {cr} 16B chunks per "
                    "staged row — the smem XOR swizzle needs a "
                    "power-of-two chunk count")
        if stages < 1:
            raise TileConfigError("tl.mma_tile needs stages >= 1")
        c = self.c_i32
        K_i32 = K.val if isinstance(K, Scalar) else self.as_i32(K.value)
        k_bound = K_i32

        # flat scratch buffers (same nvgpu-printer constraint as the fp32
        # path: scalar element types only); f32 operands stage as f32
        # (doubled smem for those tiles, cast later at the fragment)
        if dyn_smem:
            # dynamic-smem staging (the >48KB unlock): every access is a
            # raw i32 shared-window address, so no memref view is needed.
            # A tiles at byte 0, B right after.
            if not (vec and even_k and a_mask is None and b_mask is None
                    and not a_trans and not b_trans and not f2f
                    and atom.kind == "bf16"
                    and ea_parg_elem == atom.elem
                    and eb_parg_elem == atom.elem):
                raise TileConfigError(
                    "tl.mma_tile dyn_smem is a bf16 vec-path, "
                    "plain-layout, even-K, non-f2f feature")
            a_dyn_bytes = stages * bm * bk * atom.elem.itemsize
            b_dyn_bytes = stages * bk * bn * atom.elem.itemsize
            self._dyn_smem_reserve(a_dyn_bytes + b_dyn_bytes)
            dyn_base_a = self._dyn_smem_i32()
            dyn_base_b = arith.addi(dyn_base_a, c(a_dyn_bytes))
            smem_a = smem_b = None
        else:
            smem_a = self._scratch_smem("mma_a", stages * bm * bk,
                                        ea_parg_elem)
            smem_b = self._scratch_smem("mma_b", stages * bk * bn,
                                        eb_parg_elem)

        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        warp = arith.divsi(tid, c(32))
        g = arith.divsi(lane, c(4))
        t = arith.remsi(lane, c(4))
        wy = arith.divsi(warp, c(wn_n))
        wx = arith.remsi(warp, c(wn_n))
        row_w = arith.muli(wy, c(wa_m))
        col_w = arith.muli(wx, c(wa_n))
        if self._wir_annotate_on():
            # annotation context for the mma internals (frag reads and
            # ldmatrix addresses): the lane/warp decomposition forms
            flane = FMo(TID, 32)
            fwarp = FD(TID, 32)
            self._wf_ctx = {
                "lane": flane,
                "g": FD(flane, 4),
                "t": FMo(flane, 4),
                "row_w": FM(FD(fwarp, wn_n), FC(wa_m)),
                "col_w": FM(FMo(fwarp, wn_n), FC(wa_n)),
            }

        def fold_ok(ok, cond):
            if cond is None:
                return ok
            return cond if ok is None else self.and_i1(ok, cond)

        def a_row_ok(row_i32):
            if a_mask is None:
                return None
            ok = None
            for p in a_mask.row_preds:
                ok = fold_ok(ok, self._pred_scalar(p, row_i32))
            return ok

        def k_ok(k0, cc):
            if even_k:
                return None
            lhs = self.eval_affine(Affine(k0, 1, bk), cc)
            return self.compare("<", lhs, k_bound, tl.int32)

        def b_col_ok(c_i32):
            if b_mask is None:
                return None
            ok = None
            for p in b_mask.col_preds:
                ok = fold_ok(ok, self._pred_scalar(p, c_i32))
            return ok

        # cp.async's src-size zfill is prefix-only (copies a leading run,
        # zero-fills the tail — _mma_unit_copy). The mask preds that VARY
        # within one 4B unit decide whether the fold is legal: plain A and
        # transposed B units run along k (k_ok is '<': prefix); transposed
        # A units run along m (a_mask row preds) and plain B units along n
        # (b_mask col preds) — those must all be upper-bound comparisons
        # to fold; anything else (>=, >, ==, !=) takes the synchronous
        # predicated path instead.
        def _prefix_safe(preds):
            return all(p.op in ("<", "<=") for p in preds)

        a_prefix = True
        if a_trans and a_mask is not None:
            a_prefix = _prefix_safe(a_mask.row_preds)
        b_prefix = True
        if not b_trans and b_mask is not None:
            b_prefix = _prefix_safe(b_mask.col_preds)

        # vec-path staging prologue: (src, dst) slots built once outside
        # the K loop; steady-state issue is one add + one cp.async each.
        pre_a = self._mma_stage_pre(atom, bm, bk, cra, swz_a, a_off, tid,
                                    "a", v16a) if vec and not a_trans \
            else None
        pre_b = self._mma_stage_pre(atom, bk, bn, crb, swz_b, b_off, tid,
                                    "b", v16b) if vec and not b_trans \
            else None

        def issue(k0, stage, sf=None):
            toks = []
            tile_ok = None if vec else self.compare("<", k0, k_bound,
                                                    tl.int32)
            if pre_a is not None:
                self._mma_stage_vec_fast(toks, smem_a, a_parg, stage, k0,
                                         bm * bk, pre_a, v16a, sf)
            else:
                self._mma_stage_a(atom, smem_a, stage, tid, k0, bm, bk, cra,
                                  swz_a, a_off, a_parg, vec, a_trans,
                                  tile_ok, a_row_ok, k_ok, fold_ok, toks,
                                  tvec=a_tvec, swz_tmask=swz_at, sf=sf,
                                  prefix=a_prefix)
            if pre_b is not None:
                ldb = b_off.row.stride
                k_adv = arith.muli(k0, self.as_i32(ldb))
                self._mma_stage_vec_fast(toks, smem_b, b_parg, stage, k_adv,
                                         bk * bn, pre_b, v16b, sf)
            else:
                self._mma_stage_b(atom, smem_b, stage, tid, k0, bk, bn, crb,
                                  swz_b, swz_bt, b_off, b_parg, vec, b_trans,
                                  tile_ok, k_ok, b_col_ok, fold_ok, toks,
                                  tvec=b_tvec, sf=sf, prefix=b_prefix)
            return nvgpu.device_async_create_group(toks)

        # dynamic-smem staging: same slots, but dst is a raw byte address
        # and src a raw i64 global address (hardware group state).
        if dyn_smem:
            gbase_a64 = self._glob_base_i64(a_parg)
            gbase_b64 = self._glob_base_i64(b_parg)
            c64 = lambda v: arith.constant(self._i64_ty, v)
            esz_dyn = atom.elem.itemsize

            def issue_dyn(k0, stage):
                dst_a = arith.addi(dyn_base_a,
                                   arith.muli(stage, c(bm * bk * esz_dyn)))
                for src, dst in pre_a:
                    self._cp_async16_dyn(
                        arith.addi(dst_a, arith.muli(dst, c(esz_dyn))),
                        arith.addi(gbase_a64,
                                   arith.muli(arith.extsi(
                                       self._i64_ty, arith.addi(src, k0)),
                                       c64(esz_dyn))))
                ldb = b_off.row.stride
                k_adv = arith.muli(k0, self.as_i32(ldb))
                dst_b = arith.addi(dyn_base_b,
                                   arith.muli(stage, c(bk * bn * esz_dyn)))
                for src, dst in pre_b:
                    self._cp_async16_dyn(
                        arith.addi(dst_b, arith.muli(dst, c(esz_dyn))),
                        arith.addi(gbase_b64,
                                   arith.muli(arith.extsi(
                                       self._i64_ty, arith.addi(src, k_adv)),
                                       c64(esz_dyn))))
                self._cp_async_commit_dyn()

        def issue_or_dyn(k0, stage, sf=None):
            """One tile's staging copies + group commit; returns the nvgpu
            group token (static path) or None (dyn path)."""
            if dyn_smem:
                issue_dyn(k0, stage)
                return None
            return issue(k0, stage, sf)

        # ldmatrix fragment fast paths: A always; B only for bf16 (tf32's
        # 4B operand spans two b16 columns — keeps per-lane LDS).
        ldsm_a = not a_trans and ea_parg_elem == atom.elem
        ldsm_at = a_trans and atom.kind == "bf16" \
            and ea_parg_elem == atom.elem
        ldsm_b = atom.kind == "bf16" and not b_trans \
            and eb_parg_elem == atom.elem
        ldsm_bt = atom.kind == "bf16" and b_trans \
            and eb_parg_elem == atom.elem
        esz = atom.elem.itemsize
        # Hoisted ldmatrix lane addresses (loop-invariant; only the stage
        # base advances, one iadd per LDSM inside the K loop).
        pat_a = pat_b = pf_a = pf_b = None
        if ldsm_a or ldsm_at:
            ba0 = dyn_base_a if dyn_smem else \
                self._mma_smem_i32(smem_a, 0, esz)
            _afb = FC(0) if self._wir_annotate_on() and not dyn_smem \
                else None
            _pa = [self._mma_frag_a_ldsm_addr(atom, ba0, bk, swz_a,
                                              lane, row_w, h, im, _afb)
                   if ldsm_a else
                   self._mma_frag_a_ldsm_trans_addr(atom, ba0, bm,
                                                    swz_at, lane,
                                                    row_w, h, im, _afb)
                   for im in range(atoms_m)
                   for h in range(bk // atom.k)]
            if _afb is not None:
                pat_a = [[_pa[im * (bk // atom.k) + h][0]
                          for im in range(atoms_m)]
                         for h in range(bk // atom.k)]
                pf_a = [[_pa[im * (bk // atom.k) + h][1]
                         for im in range(atoms_m)]
                        for h in range(bk // atom.k)]
            else:
                pat_a = [[_pa[im * (bk // atom.k) + h]
                          for im in range(atoms_m)]
                         for h in range(bk // atom.k)]
        if ldsm_b or ldsm_bt:
            bb0 = dyn_base_b if dyn_smem else \
                self._mma_smem_i32(smem_b, 0, esz)
            _bfb = FC(0) if self._wir_annotate_on() and not dyn_smem \
                else None
            _pb = [self._mma_frag_b_ldsm_addr(atom, bb0, bn, swz_b,
                                              lane, col_w, h, in_, _bfb)
                   if ldsm_b else
                   self._mma_frag_b_ldsm_trans_addr(atom, bb0, bk,
                                                    swz_bt, lane,
                                                    col_w, h, in_, _bfb)
                   for in_ in range(atoms_n)
                   for h in range(bk // atom.k)]
            if _bfb is not None:
                pat_b = [[_pb[in_ * (bk // atom.k) + h][0]
                          for in_ in range(atoms_n)]
                         for h in range(bk // atom.k)]
                pf_b = [[_pb[in_ * (bk // atom.k) + h][1]
                         for in_ in range(atoms_n)]
                        for h in range(bk // atom.k)]
            else:
                pat_b = [[_pb[in_ * (bk // atom.k) + h]
                          for in_ in range(atoms_n)]
                         for h in range(bk // atom.k)]

        def compute(stage, acc, acc2=None, sf=None):
            """mma over one staged tile: acc += a_tile @ b_tile.
            sf: the stage's wir form (None when off). Per k atom h:
            materialize each warp-row A fragment and warp-col B fragment,
            then issue atoms_m x atoms_n mma.sync ops. tf32x3 keeps a
            hi/lo pair per fragment and issues 3 mmas (hi.hi into acc,
            cross terms into the separately accumulated acc2)."""
            base_a = arith.muli(stage, c(bm * bk))
            base_b = arith.muli(stage, c(bk * bn))
            stage_ab = arith.muli(stage, c(bm * bk * esz))
            stage_bb = arith.muli(stage, c(bk * bn * esz))
            x3 = atom.kind == "tf32x3"
            for h in range(bk // atom.k):
                afs = []
                for im in range(atoms_m):
                    if pat_a is not None:
                        addr = arith.addi(pat_a[h][im], stage_ab)
                        if sf is not None and pf_a is not None:
                            faddr = FA(pf_a[h][im], FM(sf, FC(bm * bk)))
                        else:
                            faddr = None
                        regs = self._mma_ldsm_x4(
                            addr, faddr, self._wir_smem_role(smem_a),
                            16 // esz) if ldsm_a else \
                            self._mma_ldsm_x4_trans(
                                addr, faddr, self._wir_smem_role(smem_a),
                                16 // esz)
                    else:
                        regs = self._mma_frag_a(
                            atom, smem_a, base_a, bm if a_trans else bk,
                            swz_a, g, t, row_w, h, im, a_trans,
                            ea_parg_elem,
                            FM(sf, FC(bm * bk)) if sf is not None else None)
                    if x3:
                        regs = [self._mma_split_tf32(r) for r in regs]
                    elif atom.cvt:
                        regs = [self._mma_cvt_tf32(r) for r in regs]
                    afs.append(regs)
                bfs = []
                for in_ in range(atoms_n):
                    if pat_b is not None:
                        addr = arith.addi(pat_b[h][in_], stage_bb)
                        if sf is not None and pf_b is not None:
                            faddr = FA(pf_b[h][in_], FM(sf, FC(bk * bn)))
                        else:
                            faddr = None
                        regs = self._mma_ldsm_x2_trans(
                            addr, faddr, self._wir_smem_role(smem_b),
                            16 // esz) if ldsm_b else \
                            self._mma_ldsm_x2(
                                addr, faddr, self._wir_smem_role(smem_b),
                                16 // esz)
                    else:
                        regs = self._mma_frag_b(
                            atom, smem_b, base_b, bk, bn, swz_b, swz_bt,
                            g, t, col_w, h, in_, b_trans, eb_parg_elem,
                            FM(sf, FC(bk * bn)) if sf is not None else None)
                    if x3:
                        regs = [self._mma_split_tf32(r) for r in regs]
                    elif atom.cvt:
                        regs = [self._mma_cvt_tf32(r) for r in regs]
                    bfs.append(regs)
                for im in range(atoms_m):
                    for in_ in range(atoms_n):
                        i0 = (im * atoms_n + in_) * 4
                        cregs = [vector.extract(acc, [], [i0 + j])
                                 for j in range(4)]
                        if x3:
                            ahi = [p[0] for p in afs[im]]
                            alo = [p[1] for p in afs[im]]
                            bhi = [p[0] for p in bfs[in_]]
                            blo = [p[1] for p in bfs[in_]]
                            c2 = [vector.extract(acc2, [], [i0 + j])
                                  for j in range(4)]
                            d = self._mma_sync(atom, ahi, bhi, cregs)
                            d2 = self._mma_sync(atom, ahi, blo, c2)
                            d2 = self._mma_sync(atom, alo, bhi, d2)
                            for j in range(4):
                                acc2 = vector.insert(d2[j], acc2, [], [i0 + j])
                        else:
                            d = self._mma_sync(atom, afs[im], bfs[in_],
                                               cregs)
                        for j in range(4):
                            acc = vector.insert(d[j], acc, [], [i0 + j])
            return acc, acc2

        n_tiles = arith.divsi(arith.addi(K_i32, c(bk - 1)), c(bk))

        def issue_tile(t_i32, tf=None):
            if vec:
                last = arith.subi(n_tiles, c(1))
                t_i32 = self.select(
                    self.compare("<", t_i32, n_tiles, tl.int32), t_i32, last)
            sf = FMo(tf, stages) if tf is not None else None
            return issue_or_dyn(arith.muli(t_i32, c(bk)),
                                arith.remsi(t_i32, c(stages)), sf)

        grp_pre = None
        if not f2f:
            for t_ in range(stages - (0 if one_shot else 1)):
                grp_pre = issue_tile(c(t_), FC(t_)
                                     if self._wir_annotate_on() else None)

        x3 = atom.kind == "tf32x3"
        nc = atoms_m * atoms_n * 4
        vty = ir.VectorType.get([nc], self.f32)
        # runtime zero (0.0 * f32(tid)): an f32 constant init would reach
        # the mma inline asm's integer-only "n" constraint (llc rejects);
        # tid-derived so MLIR can't constant-fold the dodge.
        acc0 = arith.mulf(self.dense_const(vty, tl.float32, 0.0),
                          self.splat(vty, arith.sitofp(self.f32, tid)))
        if one_shot:
            # single-buffer whole-K schedule: every K tile is staged by
            # the prologue, so one wait-all + one barrier covers the loop.
            if dyn_smem:
                self._cp_async_wait_dyn(0)
            else:
                nvgpu.device_async_wait(grp_pre, num_groups=0)
            gpu.barrier()
            iter_args = [acc0, acc0] if x3 else [acc0]
            for_op = scf.ForOp(self.c_idx(0), self.to_index(n_tiles),
                               self.c_idx(1), iter_args=iter_args)
            block = _ensure_block(for_op.regions[0])
            ivf = self._wir_mark_loop(for_op)
            with ir.InsertionPoint(block):
                if x3:
                    i_idx, acc_in, acc2_in = block.arguments
                else:
                    i_idx, acc_in = block.arguments
                    acc2_in = None
                i32v = arith.index_cast(self.i32, i_idx)
                acc_out, acc2_out = compute(i32v, acc_in, acc2_in, ivf)
                scf.YieldOp([acc_out, acc2_out] if x3 else [acc_out])
        elif f2f:
            # LDG.128 -> register tile -> STS staging: one bar.sync per K
            # tile, no cp.async groups; the register tile holds tile
            # i+stages-1 and is stored into the freed slot after the bar.
            tile_i32 = arith.divsi(arith.addi(K_i32, c(bk - 1)), c(bk))
            last = arith.subi(tile_i32, c(1))
            ldb = b_off.row.stride

            def clamp_tile(t_i32):
                return self.select(
                    self.compare("<", t_i32, tile_i32, tl.int32), t_i32,
                    last)

            def k_adv_a(t_i32):
                return arith.muli(clamp_tile(t_i32), c(bk))

            def k_adv_b(t_i32):
                k0 = k_adv_a(t_i32)
                return arith.muli(k0, self.as_i32(ldb))

            # prologue: fill stages-1 smem slots via LDG+STS (all LDGs
            # issued before the stores so the loads overlap), then load
            # tile stages-1 into the register tile
            pro_regs_a, pro_regs_b = [], []
            for t_ in range(stages - 1):
                pro_regs_a.append(self._mma_f2f_slots(
                    pre_a, a_parg, k_adv_a(c(t_)), smem_a, 0, esz, False))
                pro_regs_b.append(self._mma_f2f_slots(
                    pre_b, b_parg, k_adv_b(c(t_)), smem_b, 0, esz, False))
            for t_ in range(stages - 1):
                for (src, dst), v in zip(pre_a, pro_regs_a[t_]):
                    self._mma_f2f_sts(
                        smem_a, arith.addi(arith.muli(c(t_), c(bm * bk)),
                                           dst), esz, v)
                for (src, dst), v in zip(pre_b, pro_regs_b[t_]):
                    self._mma_f2f_sts(
                        smem_b, arith.addi(arith.muli(c(t_), c(bk * bn)),
                                           dst), esz, v)
            regs0 = self._mma_f2f_regs_ldg(
                pre_a, a_parg, k_adv_a(c(stages - 1))) + \
                self._mma_f2f_regs_ldg(pre_b, b_parg, k_adv_b(c(stages - 1)))
            gpu.barrier()
            iter_args = [acc0] + regs0
            for_op = scf.ForOp(self.c_idx(0), self.to_index(n_tiles),
                               self.c_idx(1), iter_args=iter_args)
            block = _ensure_block(for_op.regions[0])
            ivf = self._wir_mark_loop(for_op)
            with ir.InsertionPoint(block):
                i_idx, acc_in = block.arguments[0], block.arguments[1]
                regs_in = list(block.arguments[2:])
                i32v = arith.index_cast(self.i32, i_idx)
                stage = arith.remsi(i32v, c(stages))
                na = len(pre_a)
                slot_stage = arith.remsi(arith.addi(i32v, c(stages - 1)),
                                         c(stages))
                gpu.barrier()
                self._mma_f2f_regs_sts(
                    pre_a, regs_in[:na], smem_a,
                    arith.muli(slot_stage, c(bm * bk)), esz)
                self._mma_f2f_regs_sts(
                    pre_b, regs_in[na:], smem_b,
                    arith.muli(slot_stage, c(bk * bn)), esz)
                t_next = arith.addi(i32v, c(stages))
                regs_out = self._mma_f2f_regs_ldg(
                    pre_a, a_parg, k_adv_a(t_next)) + \
                    self._mma_f2f_regs_ldg(pre_b, b_parg, k_adv_b(t_next))
                acc_out, _ = compute(stage, acc_in, None,
                                     FMo(ivf, stages)
                                     if ivf is not None else None)
                scf.YieldOp([acc_out] + regs_out)
        elif stages == 1 or not one_bar:
            # two-barrier schedule (the only correct one for a single smem
            # buffer): issue tile i+stages-1 first, then wait tile i's
            # group; two bar.sync per iteration (data-landed + reuse).
            iter_args = [acc0, acc0] if x3 else [acc0]
            for_op = scf.ForOp(self.c_idx(0), self.to_index(n_tiles),
                               self.c_idx(1), iter_args=iter_args)
            block = _ensure_block(for_op.regions[0])
            ivf = self._wir_mark_loop(for_op)
            with ir.InsertionPoint(block):
                if x3:
                    i_idx, acc_in, acc2_in = block.arguments
                else:
                    i_idx, acc_in = block.arguments
                    acc2_in = None
                i32v = arith.index_cast(self.i32, i_idx)
                stage = arith.remsi(i32v, c(stages))
                grp = issue_tile(arith.addi(i32v, c(stages - 1)),
                             FA(ivf, FC(stages - 1))
                             if ivf is not None else None)
                if dyn_smem:
                    self._cp_async_wait_dyn(stages - 1)
                else:
                    nvgpu.device_async_wait(grp, num_groups=stages - 1)
                gpu.barrier()
                acc_out, acc2_out = compute(stage, acc_in, acc2_in,
                                            FMo(ivf, stages)
                                            if ivf is not None else None)
                gpu.barrier()
                scf.YieldOp([acc_out, acc2_out] if x3 else [acc_out])
        else:
            # ONE barrier per K tile: wait_group(stages-2); bar; issue tile
            # i+stages-1; compute tile i (the CUTLASS multistage handshake;
            # the group token threads through the loop as an iter_arg).
            iter_args = [acc0, acc0, grp_pre] if x3 else \
                ([acc0] if dyn_smem else [acc0, grp_pre])
            for_op = scf.ForOp(self.c_idx(0), self.to_index(n_tiles),
                               self.c_idx(1), iter_args=iter_args)
            block = _ensure_block(for_op.regions[0])
            ivf = self._wir_mark_loop(for_op)
            with ir.InsertionPoint(block):
                if x3:
                    i_idx, acc_in, acc2_in, tok_in = block.arguments
                elif dyn_smem:
                    i_idx, acc_in = block.arguments
                    tok_in = None
                else:
                    i_idx, acc_in, tok_in = block.arguments
                    acc2_in = None
                i32v = arith.index_cast(self.i32, i_idx)
                stage = arith.remsi(i32v, c(stages))
                if dyn_smem:
                    # same handshake without SSA tokens: cp.async groups are
                    # hardware state in the dyn (inline-PTX) path
                    self._cp_async_wait_dyn(stages - 2)
                    gpu.barrier()
                    issue_tile(arith.addi(i32v, c(stages - 1)),
                             FA(ivf, FC(stages - 1))
                             if ivf is not None else None)
                    acc_out, _ = compute(stage, acc_in, None,
                                         FMo(ivf, stages)
                                         if ivf is not None else None)
                    scf.YieldOp([acc_out])
                else:
                    nvgpu.device_async_wait(tok_in, num_groups=stages - 2)
                    gpu.barrier()
                    grp = issue_tile(arith.addi(i32v, c(stages - 1)),
                             FA(ivf, FC(stages - 1))
                             if ivf is not None else None)
                    acc_out, acc2_out = compute(stage, acc_in, acc2_in,
                                                FMo(ivf, stages)
                                                if ivf is not None else None)
                    scf.YieldOp([acc_out, acc2_out, grp]
                                if x3 else [acc_out, grp])
        val = for_op.results[0]
        if x3:
            # big (hi.hi) + small (hi.lo + lo.hi) running sums merge here
            val = arith.addf(for_op.results[0], for_op.results[1])
        out = Tensor(tl.float32, (bm, bn),
                     Fragment((bm, bn), atom.kind, "C", (wn_m, wn_n),
                              (atoms_m, atoms_n)),
                     val, nc)
        return out

    # -- mma epilogue (pass layer: C fragment -> global layout) --------------

    def store_m4(self, pt: PtrTensor, value: Tensor, mask=None,
                 bias_pt: PtrTensor | None = None,
                 epi: str | None = None):
        """Store an "m4"-laid-out (BM, BN) tile (from mma_tile): per lane,
        the two column-adjacent accumulators of one row go out as one
        fragment (8B store, scalar when masked); bf16 outputs pack via
        cvt.rn.bf16x2 (one 4B word). bias_pt (optional (BN,) bf16/f32
        tile): fused bias epilogue, added BEFORE the bf16 pack (single
        rounding). epi="smem": smem-transpose epilogue — the fragment is
        staged through swizzled smem, re-read row-contiguous so stores
        go out as STG.E.128 per lane (same numerics/mask semantics)."""
        off = pt.off
        parg = pt.arg
        if not (isinstance(value.layout, Fragment)
                and value.layout.role == "C"):
            raise TileConfigError(
                f"store_m4 expects an m4 C-fragment value, got {value!r}")
        if off.shape != value.shape or len(off.shape) != 2:
            raise TileConfigError(
                f"store_m4 shape mismatch: {off.shape} vs {value.shape}")
        if parg.elem not in (tl.float32, tl.bfloat16):
            raise TileConfigError(
                f"store_m4 stores f32/bf16 outputs, got {parg.elem}")
        if not (isinstance(off.col.stride, int) and off.col.stride == 1):
            raise TileConfigError("store_m4 needs unit column stride")
        if mask is not None and not isinstance(mask, SepMask):
            raise TileConfigError("store_m4 masks must be symbolic (SepMask)")
        if epi is not None and epi != "smem":
            raise TileConfigError(
                f"store_m4 epi must be None/'smem', got {epi!r}")
        if bias_pt is not None:
            if len(bias_pt.off.shape) != 1 \
                    or bias_pt.off.shape[0] != value.shape[1]:
                raise TileConfigError(
                    f"store_m4 bias tile must be ({value.shape[1]},), got "
                    f"{bias_pt.off.shape}")
            if bias_pt.arg.elem not in (tl.float32, tl.bfloat16):
                raise TileConfigError(
                    f"store_m4 bias must be f32/bf16, got {bias_pt.arg.elem}")
            if parg.elem != tl.bfloat16:
                raise TileConfigError(
                    "store_m4 bias epilogue is a bf16-out feature (the "
                    "single-rounding Linear epilogue)")
        if epi == "smem":
            self._store_m4_smem(pt, value, mask, bias_pt)
            return
        bf16_out = parg.elem == tl.bfloat16
        frag = value.layout
        (wn_m, wn_n), (atoms_m, atoms_n) = frag.warps, frag.atoms
        wa_m, wa_n = value.shape[0] // wn_m, value.shape[1] // wn_n
        c = self.c_i32
        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        warp = arith.divsi(tid, c(32))
        g = arith.divsi(lane, c(4))
        t = arith.remsi(lane, c(4))
        wy = arith.divsi(warp, c(wn_n))
        wx = arith.remsi(warp, c(wn_n))
        v2 = ir.VectorType.get([2], self.f32)
        v2b = ir.VectorType.get([2], tl.bfloat16.mlir())
        v1i = ir.VectorType.get([1], self.i32)
        for im in range(atoms_m):
            for in_ in range(atoms_n):
                i0 = (im * atoms_n + in_) * 4
                col0 = arith.addi(
                    arith.addi(arith.muli(wx, c(wa_n)), c(in_ * 8)),
                    arith.muli(t, c(2)))
                for half in range(2):
                    r = arith.addi(
                        arith.addi(arith.muli(wy, c(wa_m)),
                                   c(im * 16 + 8 * half)), g)
                    addr = arith.addi(self.eval_affine(off.row, r),
                                      self.eval_affine(off.col, col0))
                    if mask is None:
                        frag_m, all_m = None, None
                    else:
                        frag_m, all_m = self.mask_frag(mask, r, 2, col0)
                    if bias_pt is not None:
                        baddr = self.eval_affine(bias_pt.off.col, col0)
                        bv = self._load_frag(bias_pt.arg, baddr, 1, 2,
                                             frag_m, all_m,
                                             self.const(bias_pt.arg.elem,
                                                        0.0))
                        b0v = vector.extract(bv, [], [0])
                        b1v = vector.extract(bv, [], [1])
                        if bias_pt.arg.elem == tl.bfloat16:
                            b0v = arith.extf(self.f32, b0v)
                            b1v = arith.extf(self.f32, b1v)
                    if bf16_out:
                        x0 = vector.extract(value.val, [], [i0 + 2 * half])
                        x1 = vector.extract(
                            value.val, [], [i0 + 2 * half + 1])
                        if bias_pt is not None:
                            x0 = arith.addf(x0, b0v)
                            x1 = arith.addf(x1, b1v)
                        if frag_m is None and all_m is None:
                            packed = vector.insert(
                                self._mma_pack_bf16x2(x0, x1),
                                self.dense_const(v1i, tl.int32, 0), [], [0])
                            vector.StoreOp(vector.bitcast(v2b, packed),
                                           parg.scalar_view,
                                           [self.to_index(addr)])
                            continue
                        b0 = arith.truncf(tl.bfloat16.mlir(), x0)
                        b1 = arith.truncf(tl.bfloat16.mlir(), x1)
                        pair = vector.insert(
                            b1, vector.insert(
                                b0, self.dense_const(v2b, tl.bfloat16, 0.0),
                                [], [0]),
                            [], [1])
                        self._store_frag(parg, addr, 1, pair, 2,
                                         frag_m, all_m)
                        continue
                    pair = vector.extract_strided_slice(
                        v2, value.val, [i0 + 2 * half], [2], [1])
                    self._store_frag(parg, addr, 1, pair, 2, frag_m, all_m)

    def _smem_epi_base(self, nbytes: int):
        """16B-aligned raw shared-window byte address (i32) of the m4
        epilogue staging buffer + an "aliases dyn staging" flag (a
        pre-phase-1 barrier is then mandatory). Static scratch while the
        48KB budget holds, else the dynamic smem region above any dyn
        staging bytes; ``nbytes`` must include 16B of align-up slack."""
        c = self.c_i32
        if getattr(self, "_smem_bytes", 0) + nbytes <= 48 * 1024:
            smem = self._scratch_smem("mma_epi", -(-nbytes // 4),
                                      tl.float32)
            raw = self._mma_smem_i32(smem, 0, 1)
            return arith.andi(arith.addi(raw, c(15)), c(-16)), False
        off = getattr(self, "_dyn_smem_bytes", 0)
        self._dyn_smem_reserve(off + nbytes)
        raw = self._dyn_smem_i32()
        if off:
            raw = arith.addi(raw, c(off))
        return arith.andi(arith.addi(raw, c(15)), c(-16)), off > 0

    def _store_m4_smem(self, pt: PtrTensor, value: Tensor, mask,
                       bias_pt: PtrTensor | None):
        """smem-transpose m4 epilogue (store_m4 epi="smem"). Phase 1:
        lanes write accumulator pairs (bias added first, bf16 packed —
        direct-path numerics) into a shared buffer at fragment
        coordinates, 16B chunk index XOR-swizzled by row (conflict-free).
        Phase 2 (one CTA barrier later): the tile is read back as
        row-contiguous 16B chunks and stored to global via _store_frag
        (one STG.E.128 per lane when aligned, scalar fallback). Requires
        a power-of-two chunk count per row. The mask only filters the
        global write — the full tile is always staged."""
        off = pt.off
        parg = pt.arg
        bf16_out = parg.elem == tl.bfloat16
        frag = value.layout
        (wn_m, wn_n), (atoms_m, atoms_n) = frag.warps, frag.atoms
        bm, bn = value.shape
        wa_m, wa_n = bm // wn_m, bn // wn_n
        esz = parg.elem.itemsize
        e16 = 16 // esz  # elements per 16B chunk (4 f32 / 8 bf16)
        if bn % e16:
            raise TileConfigError(
                f"store_m4 epi=smem needs BN % {e16} == 0, got {bn}")
        cpr = bn // e16  # 16B chunks per row
        if cpr & (cpr - 1):
            # the XOR swizzle stays inside the row only for power-of-two
            # chunk counts (same constraint as the A/B staging swizzle)
            raise TileConfigError(
                f"store_m4 epi=smem needs a power-of-two 16B-chunk row "
                f"(BN={bn} gives {cpr} chunks)")
        # XOR-swizzle mask on 16B-chunk indices (chunk ^ (row & swz)):
        # cpr-1 keeps the XOR inside the (power-of-two) chunk row; 15 caps
        # the pattern at the row's low 4 bits (16-row period, spanning
        # <= 16 chunks = 256B)
        swz = min(cpr - 1, 15)
        base_i32, aliased = self._smem_epi_base(bm * bn * esz + 16)
        c = self.c_i32
        tid = self.tid()
        lane = arith.remsi(tid, c(32))
        warp = arith.divsi(tid, c(32))
        g = arith.divsi(lane, c(4))
        t = arith.remsi(lane, c(4))
        wy = arith.divsi(warp, c(wn_n))
        wx = arith.remsi(warp, c(wn_n))

        def swz_addr(row, col):
            """Swizzled smem byte address of the 16B-chunk-aligned
            element (row, col); col need only be chunk-resident (its
            in-chunk offset is preserved)."""
            ch = arith.divsi(col, c(e16))
            sw = arith.xori(ch, arith.andi(row, c(swz))) if swz else ch
            scol = arith.addi(arith.muli(sw, c(e16)),
                              arith.remsi(col, c(e16)))
            return arith.addi(
                base_i32,
                arith.muli(arith.addi(arith.muli(row, c(bn)),
                                      scol), c(esz)))

        if aliased or getattr(self, "_epi_stores", 0):
            gpu.barrier()
        # phase 1: fragment -> swizzled smem (bias applied in-register,
        # same rounding as the direct store)
        for im in range(atoms_m):
            for in_ in range(atoms_n):
                i0 = (im * atoms_n + in_) * 4
                col0 = arith.addi(
                    arith.addi(arith.muli(wx, c(wa_n)), c(in_ * 8)),
                    arith.muli(t, c(2)))
                for half in range(2):
                    r = arith.addi(
                        arith.addi(arith.muli(wy, c(wa_m)),
                                   c(im * 16 + 8 * half)), g)
                    x0 = vector.extract(value.val, [], [i0 + 2 * half])
                    x1 = vector.extract(value.val, [], [i0 + 2 * half + 1])
                    if bias_pt is not None:
                        frag_m, all_m = self.mask_frag(mask, r, 2, col0) \
                            if mask is not None else (None, None)
                        baddr = self.eval_affine(bias_pt.off.col, col0)
                        bv = self._load_frag(bias_pt.arg, baddr, 1, 2,
                                             frag_m, all_m,
                                             self.const(bias_pt.arg.elem,
                                                        0.0))
                        b0v = vector.extract(bv, [], [0])
                        b1v = vector.extract(bv, [], [1])
                        if bias_pt.arg.elem == tl.bfloat16:
                            b0v = arith.extf(self.f32, b0v)
                            b1v = arith.extf(self.f32, b1v)
                        x0 = arith.addf(x0, b0v)
                        x1 = arith.addf(x1, b1v)
                    saddr = swz_addr(r, col0)
                    if bf16_out:
                        packed = self._mma_pack_bf16x2(x0, x1)
                        nvvm.InlinePtxOp([], [saddr, packed], [],
                                         "st.shared.b32 [$0], $1;")
                    else:
                        nvvm.InlinePtxOp([], [saddr, x0, x1], [],
                                         "st.shared.v2.f32 [$0], {$1, $2};")
        gpu.barrier()
        # phase 2: row-contiguous 16B chunks -> global (vector fast path
        # with runtime alignment check inside _store_frag)
        q_chunks = bm * cpr
        nt = self.num_threads
        n_iter = -(-q_chunks // nt)
        for i in range(n_iter):
            q = tid if i == 0 else arith.addi(tid, c(i * nt))

            def emit_chunk():
                row = arith.divsi(q, c(cpr))
                ch = arith.remsi(q, c(cpr))
                col = arith.muli(ch, c(e16))
                addr = arith.addi(self.eval_affine(off.row, row),
                                  self.eval_affine(off.col, col))
                frag_m, all_m = self.mask_frag(mask, row, e16, col) \
                    if mask is not None else (None, None)
                if bf16_out:
                    p = list(nvvm.InlinePtxOp(
                        [self.i32] * 4, [swz_addr(row, col)], [],
                        "ld.shared.v4.b32 {$0,$1,$2,$3}, [$4];").results)
                    vi = self.dense_const(ir.VectorType.get([4], self.i32),
                                          tl.int32, 0)
                    for j in range(4):
                        vi = vector.insert(p[j], vi, [], [j])
                    vec = vector.bitcast(
                        ir.VectorType.get([8], tl.bfloat16.mlir()), vi)
                else:
                    x = list(nvvm.InlinePtxOp(
                        [self.f32] * 4, [swz_addr(row, col)], [],
                        "ld.shared.v4.f32 {$0,$1,$2,$3}, [$4];").results)
                    vec = self.dense_const(
                        ir.VectorType.get([4], self.f32), tl.float32, 0.0)
                    for j in range(4):
                        vec = vector.insert(x[j], vec, [], [j])
                self._store_frag(parg, addr, 1, vec, e16, frag_m, all_m)

            if q_chunks % nt and i == n_iter - 1:
                if_op = scf.IfOp(self.compare("<", q, c(q_chunks),
                                              tl.int32), [], has_else=False)
                with ir.InsertionPoint(_ensure_block(if_op.regions[0])):
                    emit_chunk()
                    scf.YieldOp([])
            else:
                emit_chunk()
        self._epi_stores = getattr(self, "_epi_stores", 0) + 1

def _broadcast_shapes(a: tuple[int, ...], b: tuple[int, ...]):
    """Numpy-style broadcast for the currently supported cases, else None."""
    if a == b:
        return a
    if a == ():
        return b
    if b == ():
        return a
    if len(a) == 1 and len(b) == 2 and b[0] == 1 and a[0] == b[1]:
        return b
    if len(b) == 1 and len(a) == 2 and a[0] == 1 and b[0] == a[1]:
        return a
    if len(a) == 2 and len(b) == 2:
        r = max(a[0], b[0])
        c = max(a[1], b[1])
        if (a[0] in (1, r)) and (b[0] in (1, r)) and \
                (a[1] in (1, c)) and (b[1] in (1, c)):
            return (r, c)
    if len(a) == 1 and len(b) == 2 and a[0] == b[1]:
        return b
    if len(b) == 1 and len(a) == 2 and b[0] == a[1]:
        return a
    return None
