"""MLIR -> LLVM IR -> PTX -> cubin lowering pipeline.

The input is a hardcoded MLIR module (text) whose device kernel lives in
a standalone ``gpu.module`` (``gpu.func ... kernel``). The pipeline:

    gpu.func kernel
      |  upstream conversion passes (driven by mlir Python bindings)
      v
    llvm dialect + nvvm intrinsics  (still nested in gpu.module)
      |  extract device ops into a plain builtin.module (Python)
      v
    mlir-translate --mlir-to-llvmir
      v
    llc -mtriple=nvptx64-nvidia-cuda -mcpu=<chip> -O3
      v
    PTX
      |  ptxas -arch=<chip>
      v
    cubin (bytes)

No gpu.launch / host-side gpu ops are used: launching is done by the runtime
via the CUDA Driver API (see minitriton/runtime/cuda_driver.py).
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from mlir import ir
from mlir.passmanager import PassManager

# Target GPU arch for llc/ptxas; override via MINITRITON_CHIP (e.g. sm_80).
DEFAULT_TRIPLE = "nvptx64-nvidia-cuda"
DEFAULT_CHIP = os.environ.get("MINITRITON_CHIP", "sm_89")

# Pass pipeline run on the whole module. ``convert-gpu-to-nvvm`` lowers
# gpu.func (incl. memref descriptor arguments) to llvm dialect + nvvm
# intrinsics; scf must be gone first, arith is finalized afterwards.
# convert-nvvm-to-llvm handles nvvm ops emitted by the tile builder
# (e.g. inline_ptx for ex2.approx); vector/math are lowered for NVPTX.
# convert-nvgpu-to-nvvm lowers nvgpu.device_async_copy/create_group/wait
# (cp.async) used by the pipelined matmul; a no-op otherwise.
DEVICE_PIPELINE = (
    "builtin.module(gpu.module("
    "convert-scf-to-cf,"
    "convert-nvgpu-to-nvvm,"
    "convert-gpu-to-nvvm,"
    "convert-nvvm-to-llvm,"
    "convert-vector-to-llvm,"
    "convert-ub-to-llvm,"  # 2D vector.broadcast lowers through ub.poison
    "convert-arith-to-llvm,"
    "convert-math-to-llvm,"
    "reconcile-unrealized-casts"
    "))"
)

# Generic upstream optimization stage: runs after
# the python W-IR passes, before conversions. Pure canonicalization/CSE
# today; override/extend via MINITRITON_OPT_PASSES ("" disables).
OPT_PIPELINE = os.environ.get("MINITRITON_OPT_PASSES",
                              "builtin.module(canonicalize,cse)")


class LoweringError(RuntimeError):
    pass


def _tool(name: str) -> str:
    """Locate a toolchain binary: conda env bin dir first, then PATH."""
    candidates = [
        Path(sys.prefix) / "bin" / name,
        Path(sys.executable).parent / name,
    ]
    for c in candidates:
        if c.is_file() and os.access(c, os.X_OK):
            return str(c)
    found = shutil.which(name)
    if found:
        return found
    raise LoweringError(f"toolchain binary not found: {name}")


def _ptxas() -> str:
    env = os.environ.get("MINITRITON_PTXAS")
    if env:
        return env
    default = "/usr/local/cuda/bin/ptxas"
    if os.path.isfile(default):
        return default
    # pip nvidia-cuda-nvcc-cuXX wheels: site-packages/nvidia/cuda_nvcc/bin/
    try:
        import importlib.util
        spec = importlib.util.find_spec("nvidia.cuda_nvcc")
        if spec and spec.submodule_search_locations:
            p = Path(list(spec.submodule_search_locations)[0]) / "bin" \
                / "ptxas"
            if p.is_file() and os.access(p, os.X_OK):
                return str(p)
    except Exception:
        pass
    return _tool("ptxas")


def _build_dir(build_dir: str | os.PathLike | None) -> Path:
    if build_dir is not None:
        d = Path(build_dir)
    else:
        d = Path(os.environ.get(
            "MINITRITON_BUILD_DIR",
            Path(__file__).resolve().parents[2] / "build",
        ))
    d.mkdir(parents=True, exist_ok=True)
    return d


def _run(cmd: list[str], **kw) -> None:
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True, **kw)
    except subprocess.CalledProcessError as e:
        raise LoweringError(
            f"command failed ({e.returncode}): {' '.join(cmd)}\n{e.stderr}"
        ) from e


def lower_device_module(mlir_text: str) -> str:
    """Run conversion passes and return the lowered device module as MLIR text.

    Input: a module containing a standalone ``gpu.module`` with gpu.func
    kernels. Output: a plain module of llvm dialect ops (nvvm intrinsics).
    """
    with ir.Context() as ctx, ir.Location.unknown(ctx):
        mod = ir.Module.parse(mlir_text, ctx)
        if os.environ.get("MINITRITON_WIR_DEBUG") == "1":
            _pre = _build_dir(os.environ.get("MINITRITON_BUILD_DIR"))
            (_pre / "_last_pre_pass.mlir").write_text(str(mod))
        # python W-IR passes — generic, annotation-driven
        from . import passes as _wir_passes
        _wir_passes.run_python_passes(mod)
        if os.environ.get("MINITRITON_WIR_DEBUG") == "1":
            (_pre / "_last_post_pass.mlir").write_text(str(mod))
        if OPT_PIPELINE:
            PassManager.parse(OPT_PIPELINE, ctx).run(mod.operation)
        PassManager.parse(DEVICE_PIPELINE, ctx).run(mod.operation)
        gpu_mods = [op for op in mod.body.operations if op.name == "gpu.module"]
        if len(gpu_mods) != 1:
            raise LoweringError(f"expected exactly 1 gpu.module, got {len(gpu_mods)}")
        device_mod = ir.Module.create(loc=ir.Location.unknown(ctx))
        for op in list(gpu_mods[0].regions[0].blocks[0].operations):
            device_mod.body.append(op)
        return str(device_mod)


def compile_to_cubin(
    mlir_text: str,
    name: str = "kernel",
    chip: str = DEFAULT_CHIP,
    build_dir: str | os.PathLike | None = None,
) -> bytes:
    """Compile an MLIR module (standalone gpu.module) all the way to cubin.

    Intermediate artifacts (.mlir/.ll/.ptx/.cubin) are written to a temp dir
    and discarded; set MINITRITON_KEEP_INTERMEDIATES=1 to keep them in
    ``build_dir`` (default: <repo>/build or $MINITRITON_BUILD_DIR) for
    debugging.
    """
    device_mlir = lower_device_module(mlir_text)
    if os.environ.get("MINITRITON_KEEP_INTERMEDIATES") == "1":
        return _compile_in(_build_dir(build_dir), name, device_mlir, chip)
    with tempfile.TemporaryDirectory(prefix="minitriton-") as tmp:
        return _compile_in(Path(tmp), name, device_mlir, chip)


def _compile_in(out: Path, name: str, device_mlir: str, chip: str) -> bytes:
    device_path = out / f"{name}.device.mlir"
    ll_path = out / f"{name}.ll"
    ptx_path = out / f"{name}.ptx"
    cubin_path = out / f"{name}.cubin"
    device_path.write_text(device_mlir)

    _run([_tool("mlir-translate"), "--mlir-to-llvmir",
          str(device_path), "-o", str(ll_path)])
    _run([_tool("llc"), f"-mtriple={DEFAULT_TRIPLE}", f"-mcpu={chip}", "-O3",
          str(ll_path), "-o", str(ptx_path)])
    _run([_ptxas(), f"-arch={chip}", str(ptx_path), "-o", str(cubin_path)])

    return cubin_path.read_bytes()
