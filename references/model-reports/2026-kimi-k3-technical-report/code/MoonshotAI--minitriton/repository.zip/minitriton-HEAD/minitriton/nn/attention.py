"""Causal self-attention.

Forward: fused flash-style kernel on CUDA (online softmax, head dim
64) via ``FlashAttentionFn``; elsewhere (CPU, other head dims, or
``fused=False``) an unfused matmul+mask+softmax composition that autograd
traces op-by-op. The fused path's backward is the fused
delta/dQ/dV/dK kernel set (recomputing P from the forward's lse); the
unfused composition remains as the fallback for non-CUDA/float/head-dim
configs. The fused forward has three precision tiers —
``precision="fp32"`` (default for f32 inputs; exact FMA), ``"tf32"``
(tensor-core mma, f32 in/out; explicit opt-in or the backend allow_tf32
flag) and ``"bf16"`` (tensor-core mma, bf16 in/out by input dtype, f32
accumulate, f32 lse). Backward: fused fp32 kernels for f32 tensors; the
bf16 tier (train-amp) runs NATIVE bf16 mma backward kernels (f32
accumulators) — MT_ATTN_BWD_F32=1 falls back to the fused f32 route
(same kernels on f32 upcasts, grads cast back); the unfused
composite (upcast, (B,H,T,T)-materializing) is kept only as the
MT_ATTN_UNFUSED/fallback path.
"""

from __future__ import annotations

import math

import numpy as np

from .. import ops
from .. import precision as _prec
from ..autograd.engine import Function
from ..frontend import types as tl_types
from ..tensor import Tensor, tensor as mk_tensor
from .layers import Linear
from .module import Module

_MASK_CACHE: dict = {}
_MASK_CACHE_CAP = 8  # (n, n) fp32 masks are n^2 * 4B each — never grow
# this cache unboundedly (clear-and-refill on overflow, like _PLANS)


def _causal_mask_add(n: int, device: str) -> Tensor:
    """Additive (n, n) causal mask: 0 on/below the diagonal, -1e9 above."""
    key = (n, device)
    m = _MASK_CACHE.get(key)
    if m is None:
        if len(_MASK_CACHE) >= _MASK_CACHE_CAP:
            _MASK_CACHE.clear()
        m = mk_tensor(np.triu(np.full((n, n), -1e9, dtype=np.float32), k=1),
                      device=device)
        _MASK_CACHE[key] = m
    return m


def unfused_causal_attention(q: Tensor, k: Tensor, v: Tensor,
                             scale: float) -> Tensor:
    """softmax(q @ k.T * scale + causal_mask) @ v, composed from eager ops
    (autograd traces it directly; also the CPU implementation)."""
    n = q.shape[-2]
    s = ops.matmul(q, k.transpose(-1, -2)) * scale
    s = s + _causal_mask_add(n, q.device)
    p = ops.softmax(s, dim=-1)
    return ops.matmul(p, v)


def unfused_attention(q: Tensor, k: Tensor, v: Tensor,
                      scale: float) -> Tensor:
    """softmax(q @ k.T * scale) @ v — FULL (non-causal) attention, composed
    from eager ops (autograd traces it directly; also the CPU path)."""
    s = ops.matmul(q, k.transpose(-1, -2)) * scale
    p = ops.softmax(s, dim=-1)
    return ops.matmul(p, v)


class FlashAttentionFn(Function):
    """Fused flash-attention forward + fused kernel backward (the
    unfused composite remains as the fallback). The forward
    may take the tensor-core mma kernels (precision="tf32" f32 in/out, or
    "bf16" by input dtype); the backward is the fused fp32 kernels for
    f32 tensors, and the NATIVE bf16 mma kernels for the bf16 tier
    (f32 accumulators, bf16 grads; MT_ATTN_BWD_F32=1 opts back out to
    the fused f32 kernels on f32 upcasts, grads cast back — the
    unfused composite bwd is the MT_ATTN_UNFUSED/fallback path).
    """

    @classmethod
    def forward(cls, ctx, q, k, v, scale, precision=None):
        # materialize the kernel's (B*H, T, hd) layout once: the forward
        # op also .contiguous()es internally (a no-op on these), and the
        # backward then reuses the saved contiguous copies instead of
        # re-copying the strided head views per layer per step
        q, k, v = q.contiguous(), k.contiguous(), v.contiguous()
        out, lse = ops.flash_attention_forward(q, k, v, scale, with_lse=True,
                                               precision=precision)
        ctx.save_for_backward(q, k, v, out, lse)
        ctx.meta["scale"] = scale
        return out

    @classmethod
    def backward(cls, ctx, g):
        q, k, v, o, lse = ctx.saved
        scale = ctx.meta["scale"]
        if g.device == "cuda" and q.shape[-1] == 64:
            in_dtype = q.dtype
            if in_dtype == tl_types.float32 and g.dtype == tl_types.float32:
                return list(ops.flash_attention_backward(
                    q, k, v, o, g.contiguous(), lse, scale,
                    precision="fp32"))
            if in_dtype == tl_types.bfloat16 and not _prec.attn_bwd_f32():
                # native bf16 mma backward: bf16 operands end to end (one
                # cast of the upstream grad to bf16 if the residual seam
                # handed us f32), f32 accumulators, bf16 grads out
                gb = g if g.dtype == tl_types.bfloat16 else \
                    g.astype(tl_types.bfloat16)
                return list(ops.flash_attention_backward(
                    q, k, v, o, gb.contiguous(), lse, scale,
                    precision="bf16"))
            if in_dtype == tl_types.bfloat16:
                # MT_ATTN_BWD_F32 mixed-precision route: the FUSED
                # f32 flash kernels on f32 upcasts of q/k/v/o/g (the
                # unfused f32 composite is the MT_ATTN_UNFUSED fallback;
                # it materializes (B,H,T,T) operands ~14 times per
                # layer), grads cast back to bf16
                q32, k32, v32, o32, g32 = (t.astype(tl_types.float32)
                                           for t in (q, k, v, o, g))
                dq, dk, dv = ops.flash_attention_backward(
                    q32, k32, v32, o32, g32.contiguous(), lse, scale,
                    precision="fp32")
                return [t.astype(in_dtype) for t in (dq, dk, dv)]
        q, k, v = ctx.saved[:3]
        in_dtype = q.dtype
        if in_dtype != tl_types.float32:
            # unfused fallback (MT_ATTN_UNFUSED or non-CUDA/head-dim):
            # compute in f32, cast the grads back
            q, k, v = (t.astype(tl_types.float32) for t in (q, k, v))
            g = g.astype(tl_types.float32)
        g = g.contiguous()
        n = q.shape[-2]
        s = ops.matmul(q, k.transpose(-1, -2)) * scale
        s = s + _causal_mask_add(n, q.device)
        p = ops.softmax(s, dim=-1)
        dv = ops.matmul(p.transpose(-1, -2), g)
        dp = ops.matmul(g, v.transpose(-1, -2))
        # softmax backward needs no explicit causal mask: p == 0 above the
        # diagonal, so masked positions contribute nothing to dx or to the
        # row sums (dx = p * (g - rowsum(g * p))).
        ds = ops.softmax_backward_rows(dp, p, -1)
        dq = ops.matmul(ds, k) * scale
        dk = ops.matmul(ds.transpose(-1, -2), q) * scale
        grads = [dq, dk, dv]
        if in_dtype != tl_types.float32:
            grads = [t.astype(in_dtype) for t in grads]
        return grads


class FlashAttentionQkvFn(Function):
    """qkv-packed fused flash: one tape node for (B, T, 3C) -> (B, T, C).
    The kernels read the q/k/v column thirds with a 3C row stride and
    write the output in (B, T, C) layout, so the head-split/merge
    materializations and the split-backward cat never exist; the
    backward writes dq/k/v into the column thirds of one (B, T, 3C)
    dqkv buffer. bf16 tier: native bf16 mma kernels. fp32 tier:
    exact-FMA kernels (the upstream grad stays f32 end to end)."""

    @classmethod
    def forward(cls, ctx, qkv, n_head, scale, precision=None):
        prec = precision
        if prec is None:
            if qkv.dtype == tl_types.bfloat16:
                prec = "bf16"
            else:
                from ..device.cuda.ops import get_allow_tf32
                prec = "tf32" if get_allow_tf32() else "fp32"
        out, lse = ops.flash_attention_forward_qkv(
            qkv, n_head, scale, prec)
        ctx.save_for_backward(qkv, out, lse)
        ctx.meta.update(n_head=n_head, scale=scale, precision=prec)
        return out

    @classmethod
    def backward(cls, ctx, g):
        qkv, o, lse = ctx.saved
        n_head, scale = ctx.meta["n_head"], ctx.meta["scale"]
        prec = ctx.meta["precision"]
        if prec == "bf16":
            if _prec.attn_bwd_f32():
                # MT_ATTN_BWD_F32 A/B lever (same route as
                # FlashAttentionFn): fused f32 qkv kernels on f32
                # upcasts, grads cast back — without this branch the
                # lever is a silent no-op on the qkv-packed path
                dqkv = ops.flash_attention_backward_qkv(
                    qkv.astype(tl_types.float32),
                    o.astype(tl_types.float32),
                    g.astype(tl_types.float32).contiguous(),
                    lse, n_head, scale, "fp32")
                return [dqkv.astype(qkv.dtype)]
            gb = g if g.dtype == tl_types.bfloat16 else \
                g.astype(tl_types.bfloat16)
            return [ops.flash_attention_backward_qkv(
                qkv, o, gb, lse, n_head, scale, "bf16")]
        # fp32/tf32 tiers: fused fp32 backward on the f32 upstream grad
        return [ops.flash_attention_backward_qkv(
            qkv, o, g.contiguous(), lse, n_head, scale, "fp32")]


def causal_attention(q: Tensor, k: Tensor, v: Tensor, scale: float | None = None,
                     fused: bool = True,
                     precision: str | None = None) -> Tensor:
    hd = q.shape[-1]
    if scale is None:
        scale = 1.0 / math.sqrt(hd)
    # MT_ATTN_UNFUSED (opt-in precision mode): force the unfused composite
    # so the matmul/row-kernel precision levers cover attention too
    if fused and not _prec.attn_unfused() and q.device == "cuda" and hd == 64 \
            and q.dtype in (tl_types.float32, tl_types.bfloat16):
        return FlashAttentionFn.apply(q, k, v, scale, precision)
    return unfused_causal_attention(q, k, v, scale)


class CausalSelfAttention(Module):
    """nanoGPT-style causal self-attention: qkv projection, multi-head
    split, causal attention, output projection.

    precision: fused-path precision tier — None (default:
    fp32 for f32 inputs, bf16 for bf16 inputs; the backend allow_tf32
    flag additionally routes f32 to tf32), or an explicit "fp32" /
    "tf32" / "bf16" forwarded to ops.flash_attention_forward."""

    def __init__(self, n_embd: int, n_head: int, fused: bool = True,
                 device: str = "cuda", seed=None, precision: str | None = None):
        super().__init__()
        if n_embd % n_head != 0:
            raise ValueError(f"n_embd {n_embd} not divisible by n_head {n_head}")
        self.n_head = n_head
        self.head_dim = n_embd // n_head
        self.c_attn = Linear(n_embd, 3 * n_embd, device=device, seed=seed)
        # independent streams: the same seed would make c_proj an exact
        # prefix copy of c_attn (Parameter.normal re-seeds per call)
        self.c_proj = Linear(n_embd, n_embd, device=device,
                             seed=None if seed is None else seed + 1)
        self.fused = fused
        self.precision = precision

    def forward(self, x: Tensor) -> Tensor:
        b, t, c = x.shape
        h, hd = self.n_head, self.head_dim
        qkv = self.c_attn(x)
        if self.fused and not _prec.attn_unfused() and hd == 64 \
                and x.device == "cuda" \
                and qkv.dtype in (tl_types.bfloat16, tl_types.float32):
            # qkv-packed fused path: no head-split/merge copies, no
            # split-backward cat (FlashAttentionQkvFn is one tape node)
            y = FlashAttentionQkvFn.apply(
                qkv, h, 1.0 / math.sqrt(hd), self.precision)
            return self.c_proj(y)
        q, k, v = ops.split(qkv, c, dim=-1)

        def heads(u):
            return u.reshape(b, t, h, hd).transpose(1, 2)

        y = causal_attention(heads(q), heads(k), heads(v), fused=self.fused,
                             precision=self.precision)
        y = y.transpose(1, 2).reshape(b, t, c)
        return self.c_proj(y)
