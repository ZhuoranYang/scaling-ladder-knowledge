"""CUDA eager backend: DSL-pipeline kernel launches (compiled + cached)
plus host-side shape/stride juggling.
"""

from __future__ import annotations

import math
import os

from ... import precision as _prec
from ...frontend import types as tl_types
from ...tensor import Tensor, empty, _contig_strides
from . import elementwise as ew
from . import kernels as K

from .elementwise import (_PLANS, _PLAN_CAP, _plan_out)  # noqa: F401


def _guard_i32_elems(t: Tensor | None, op: str) -> None:
    """i32 addressing backstop for the non-elementwise kernel families
    (their address algebra is i32 too): loudly reject any input tensor
    whose element count OR max reachable element offset is at/over the
    2**31-element limit (see elementwise._I32_ELEM_LIMIT). The span
    check must run here, at the op entry: _mm_prep* passes
    unit-last-stride views (e.g. base[::2] of an over-limit base)
    through with their strides intact, and drops the stride information
    for everything else. The norm/misc/ce row kernels row-chunk larger
    inputs and are deliberately NOT guarded."""
    if t is not None:
        n = t.numel()
        ew._guard_i32_numel(n, op)
        if n:
            ew._guard_i32_offset(ew._i32_span(t), op)


# ---------------------------------------------------------------------------
# matmul / bmm
# ---------------------------------------------------------------------------

def _mm_prep(t: Tensor, allow_trans: bool = False) -> Tensor:
    if t.dtype != tl_types.float32:
        t = t.astype(tl_types.float32)
    if t.strides[-1] != 1:
        # pure transpose views go straight to matmul_v2's transposed
        # staging (no eager copy); bmm has no such path
        if not (allow_trans and K._trans_kstride(t) is not None):
            t = t.contiguous()
    return t


def _mm_prep_ds(t: Tensor) -> Tensor:
    """fp64 (double-single) route prep: matmul_ds_kernel hardcodes the
    row strides to K/N (row-major contiguous operands), so a unit last
    stride alone is NOT sufficient — a column-slice view (row stride
    != K) would be read at wrong row offsets. Force full contiguity."""
    t = _mm_prep(t)
    if t.strides != _contig_strides(t.shape):
        t = t.contiguous()
    return t


# ---------------------------------------------------------------------------
# tf32 opt-in (torch allow_tf32 semantics) + bf16 mma routes
# ---------------------------------------------------------------------------

_ALLOW_TF32 = False


def set_allow_tf32(v: bool):
    """Enable tf32 mma for f32 matmuls (mirrors torch's allow_tf32):
    operands rounded rn to tf32, fp32 accumulate. Default off (exact FMA
    kernel)."""
    global _ALLOW_TF32
    _ALLOW_TF32 = bool(v)


def get_allow_tf32() -> bool:
    return _ALLOW_TF32


def _mm_prep_dtype(t: Tensor, dtype, allow_trans: bool = False) -> Tensor:
    """_mm_prep variant preserving the dtype (for the mma routes)."""
    if t.dtype != dtype:
        t = t.astype(dtype)
    if t.strides[-1] != 1:
        if not (allow_trans and K._trans_kstride(t) is not None):
            t = t.contiguous()
    return t


def _mm_prep_layout(t: Tensor, allow_trans: bool = False) -> Tensor:
    """Layout-only _mm_prep (keeps the operand dtype; f32 operands go to
    the mma kernel's in-register cast, no materialized astype)."""
    if t.strides[-1] != 1:
        if not (allow_trans and K._trans_kstride(t) is not None):
            t = t.contiguous()
    return t


def _mma_stride_check(a, b, atom) -> bool:
    # a/b are post-_mm_prep*: the op-entry i32 guard already validated
    # their reachable offsets (a prepped tensor is an entry-checked
    # view, a fresh contiguous copy, or a pure-transpose view whose span
    # is numel - 1)
    ta, tb = K._trans_kstride(a), K._trans_kstride(b)
    sam = ta if ta is not None else a.strides[0]
    sbk = tb if tb is not None else b.strides[0]
    return K.mma_strides_ok(atom, sam, sbk, a.dtype, b.dtype)


def matmul(a: Tensor, b: Tensor, bias=None) -> Tensor:
    _guard_i32_elems(a, "matmul")
    _guard_i32_elems(b, "matmul")
    _guard_i32_elems(bias, "matmul")
    if _prec.matmul_fp64():
        # fp64-quality route (opt-in): contiguous operands, double-single
        # compensated kernel; skips the autotuned fp32 pipeline entirely
        a, b = _mm_prep_ds(a), _mm_prep_ds(b)
        M, Kd = a.shape
        K2, N = b.shape
        if Kd != K2:
            raise RuntimeError(f"matmul shape mismatch {a.shape} @ {b.shape}")
        out = empty((M, N), tl_types.float32, "cuda")
        if M == 0 or N == 0:
            return out
        if Kd == 0:
            from ...tensor import zeros
            return zeros((M, N), tl_types.float32, "cuda")
        K.launch_matmul_ds(a, b, out, M, N, Kd)
        # no bias epilogue in the ds kernel — add it eagerly (same as
        # the tf32 route below)
        return out + bias if bias is not None else out
    a, b = _mm_prep(a, allow_trans=True), _mm_prep(b, allow_trans=True)
    M, Kd = a.shape
    K2, N = b.shape
    if Kd != K2:
        raise RuntimeError(f"matmul shape mismatch {a.shape} @ {b.shape}")
    out = empty((M, N), tl_types.float32, "cuda")
    if M == 0 or N == 0:
        return out
    if Kd == 0:
        from ...tensor import zeros
        return zeros((M, N), tl_types.float32, "cuda")
    if _ALLOW_TF32 and _mma_stride_check(a, b, "tf32"):
        # tf32 tensor-core mma (opt-in); f32 accumulator, no fp32 change
        # when the flag is off
        K.launch_matmul_mma(a, b, out, M, N, Kd, "tf32")
        if bias is not None:
            # no f32 bias epilogue in the mma store (bf16-out only)
            return out + bias
    else:
        if bias is None and _mm_fp32_splitk(a, b, out, M, N, Kd):
            return out
        K.launch_matmul(a, b, out, M, N, Kd, bias=bias)
    return out


# fp32 split-K routing for K-heavy wgrad shapes (the plain grid
# underfills the SMs there): both paths timed once per shape key,
# winner cached (0 = plain); split wins also persist to disk.
_SPLITK_PICKS_FP32: dict = {}


def _fp32_splitk_disk_path(key: tuple):
    import hashlib
    from ...runtime.cache import cache_root, codegen_fingerprint
    from ...runtime.autotune import TUNE_VERSION
    h = hashlib.sha256()
    h.update(codegen_fingerprint().encode())
    h.update(TUNE_VERSION.encode())
    h.update(repr(key).encode())
    return cache_root() / "autotune" / "fp32_splitk" \
        / f"{h.hexdigest()[:24]}.json"


def _fp32_splitk_disk_load(key: tuple) -> int:
    import json
    path = _fp32_splitk_disk_path(key)
    if path.is_file():
        try:
            return int(json.loads(path.read_text())["split_k"])
        except Exception:
            return 0
    return 0


def _fp32_splitk_disk_save(key: tuple, pick: int) -> None:
    import json
    try:
        path = _fp32_splitk_disk_path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"key": repr(key), "split_k": pick}))
    except Exception:
        pass


def _mm_fp32_splitk(a: Tensor, b: Tensor, out: Tensor, M: int, N: int,
                    Kd: int) -> bool:
    if os.environ.get("MT_FP32_SPLITK", "1") == "0":
        # opt-out for convergence/reproducibility runs: split-K reduces
        # partials in a different (deterministic) order than single-pass
        # SGEMM; plain GEMM keeps torch-order
        return False
    ta = K._trans_kstride(a)
    tb = K._trans_kstride(b)
    sam = ta if ta is not None else a.strides[0]
    sbk = tb if tb is not None else b.strides[0]
    key = (M, N, Kd, sam, sbk, ta is not None, tb is not None)
    pick = _SPLITK_PICKS_FP32.get(key)
    if pick is None:
        pick = _fp32_splitk_disk_load(key)
        if not pick and Kd >= 4096 and Kd >= 4 * M:
            from ...runtime.autotune import do_bench
            plain_fn = lambda: K.launch_matmul(a, b, out, M, N, Kd)
            # interleaved best-of-2 + a switch margin: a one-shot
            # plain-then-split measurement is biased against split
            ms_plain = do_bench(plain_fn)
            partials = _splitk_ws(M, N)

            def splitk_step():
                sk = K.launch_matmul_v2_splitk(a, b, partials, M, N, Kd)
                K.launch_splitk_reduce(partials, sk, out, M * N)

            splitk_step()  # autotune the split kernel before timing
            ms_split = do_bench(splitk_step)
            ms_plain = min(ms_plain, do_bench(plain_fn))
            ms_split = min(ms_split, do_bench(splitk_step))
            if ms_split < ms_plain * 0.97:
                pick = K.splitk_v2_pick(M, N, Kd, sam, sbk,
                                        ta is not None, tb is not None)
                _fp32_splitk_disk_save(key, pick)
        _SPLITK_PICKS_FP32[key] = pick
    if not pick:
        return False
    partials = _splitk_ws(M, N)
    # reduce with the split count the LAUNCHER used (sk), never a stored
    # pick — a re-tuned launch may differ, and reducing stale planes
    # would read unwritten workspace
    sk = K.launch_matmul_v2_splitk(a, b, partials, M, N, Kd)
    K.launch_splitk_reduce(partials, sk, out, M * N)
    return True


def matmul_bf16(a: Tensor, b: Tensor, out_dtype=None, bias=None) -> Tensor:
    """bf16 mma, f32 accumulate; bf16 or f32 operands (f32 rounded to bf16
    in-kernel, same RN as astype). out_dtype bf16 (default, torch dtype
    rules) or f32 (raw accumulator, the mixed-precision backward route).
    Non-conforming strides fall back to f32 compute. Optional (N,) bias
    is fused into the epilogue (single-rounding, bf16-out route only)."""
    _guard_i32_elems(a, "matmul_bf16")
    _guard_i32_elems(b, "matmul_bf16")
    _guard_i32_elems(bias, "matmul_bf16")
    import numpy as np
    if out_dtype is None:
        out_dtype = tl_types.bfloat16
    if out_dtype not in (tl_types.bfloat16, tl_types.float32):
        raise ValueError(f"matmul_bf16 out_dtype must be bf16/f32, "
                         f"got {out_dtype}")
    for t in (a, b):
        if t.dtype not in (tl_types.bfloat16, tl_types.float32):
            raise ValueError(f"matmul_bf16 expects bf16/f32 operands, got "
                             f"{a.dtype} @ {b.dtype}")
    if bias is not None and out_dtype != tl_types.bfloat16:
        raise ValueError("matmul_bf16 bias epilogue needs bf16 out_dtype")
    if a.ndim == 1 and b.ndim == 1:
        out = matmul_bf16(a.reshape((1, a.shape[0])),
                          b.reshape((b.shape[0], 1)),
                          out_dtype=out_dtype, bias=bias)
        return out.reshape(())
    if a.ndim == 1:
        out = matmul_bf16(a.reshape((1, a.shape[0])), b,
                          out_dtype=out_dtype, bias=bias)
        return out.reshape(out.shape[1:])
    if b.ndim == 1:
        out = matmul_bf16(a, b.reshape((b.shape[0], 1)),
                          out_dtype=out_dtype, bias=bias)
        return out.reshape(out.shape[:-1])
    if a.ndim == 2 and b.ndim == 2:
        return _mm_bf16_2d(a, b, out_dtype, bias)
    if b.ndim == 2:
        k = a.shape[-1]
        a2 = a.reshape((a.numel() // k, k))
        out = _mm_bf16_2d(a2, b, out_dtype, bias)
        return out.reshape(a.shape[:-1] + (b.shape[1],))
    batch = tuple(np.broadcast_shapes(a.shape[:-2], b.shape[:-2]))
    if bias is not None:
        raise NotImplementedError(
            "batched matmul_bf16 with bias is not supported "
            "(bmm_bf16 has no bias epilogue)")
    av = a.broadcast_to(batch + a.shape[-2:]) if a.shape[:-2] != batch else a
    bv = b.broadcast_to(batch + b.shape[-2:]) if b.shape[:-2] != batch else b
    if len(batch) > 1:
        B = math.prod(batch)
        av = av.contiguous().reshape((B,) + av.shape[-2:])
        bv = bv.contiguous().reshape((B,) + bv.shape[-2:])
    out = bmm_bf16(av, bv, out_dtype=out_dtype)
    return out.reshape(batch + out.shape[-2:])


def _mm_bf16_2d(a: Tensor, b: Tensor, out_dtype, bias=None) -> Tensor:
    a = _mm_prep_layout(a, allow_trans=True)
    b = _mm_prep_layout(b, allow_trans=True)
    M, Kd = a.shape
    K2, N = b.shape
    if Kd != K2:
        raise RuntimeError(f"matmul shape mismatch {a.shape} @ {b.shape}")
    if M == 0 or N == 0:
        return empty((M, N), out_dtype, "cuda")
    if Kd == 0:
        from ...tensor import zeros
        return zeros((M, N), out_dtype, "cuda")
    if bias is not None and (bias.ndim != 1 or bias.shape[0] != N):
        raise RuntimeError(f"matmul_bf16 bias must be ({N},), got "
                           f"{bias.shape}")
    if _mma_stride_check(a, b, "bf16"):
        # f32 accumulate; bf16 rounds on store inside the kernel (direct
        # store, no f32 temp + cast pass), f32 stores the accumulator;
        # f32 operands stage as f32 and pack in-register (no cast op)
        out = empty((M, N), out_dtype, "cuda")
        if out_dtype == tl_types.float32 and _mm_bf16_splitk(a, b, out,
                                                             M, N, Kd):
            return out
        K.launch_matmul_mma(a, b, out, M, N, Kd, "bf16", bias=bias)
        return out
    # ineligible strides (odd row strides): fall back to the public
    # matmul() route on f32 upcasts (exact f32, or tf32 mma when the
    # allow_tf32 flag is on), cast back
    out = matmul(a.astype(tl_types.float32), b.astype(tl_types.float32))
    if bias is not None:
        out = out + bias
    return out if out_dtype == tl_types.float32 else \
        out.astype(tl_types.bfloat16)


# split-K routing for K-heavy wgrad shapes on the f32-out path (same
# judgement as the fp32 route). Persisting the judgement to disk also
# pins the reduction order across processes — a flipping judgement would
# make the bf16 path nondeterministic between runs.
_SPLITK_PICKS: dict = {}


def _bf16_splitk_disk_path(key: tuple):
    import hashlib
    from ...runtime.cache import cache_root, codegen_fingerprint
    from ...runtime.autotune import TUNE_VERSION
    h = hashlib.sha256()
    h.update(codegen_fingerprint().encode())
    h.update(TUNE_VERSION.encode())
    h.update(repr(key).encode())
    return cache_root() / "autotune" / "bf16_splitk" \
        / f"{h.hexdigest()[:24]}.json"


def _bf16_splitk_disk_load(key: tuple) -> int:
    import json
    path = _bf16_splitk_disk_path(key)
    if path.is_file():
        try:
            return int(json.loads(path.read_text())["split_k"])
        except Exception:
            return 0
    return 0


def _bf16_splitk_disk_save(key: tuple, pick: int) -> None:
    import json
    try:
        path = _bf16_splitk_disk_path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"key": repr(key), "split_k": pick}))
    except Exception:
        pass


def _mm_bf16_splitk(a: Tensor, b: Tensor, out: Tensor, M: int, N: int,
                    Kd: int) -> bool:
    ta = K._trans_kstride(a)
    tb = K._trans_kstride(b)
    sam = ta if ta is not None else a.strides[0]
    sbk = tb if tb is not None else b.strides[0]
    key = (M, N, Kd, sam, sbk, ta is not None, tb is not None,
           a.dtype, b.dtype)
    pick = _SPLITK_PICKS.get(key)
    if pick is None:
        pick = _bf16_splitk_disk_load(key)
        if not pick and Kd >= 4096 and Kd >= 4 * M:
            from ...runtime.autotune import do_bench
            plain_fn = lambda: K.launch_matmul_mma(a, b, out, M, N, Kd,
                                                   "bf16")
                # best-of-2 both sides + a switch margin (a one-shot
                # judgement is a coin flip under timing noise)
            ms_plain = min(do_bench(plain_fn), do_bench(plain_fn))
            partials = _splitk_ws(M, N)

            def splitk_step():
                sk = K.launch_matmul_mma_splitk(a, b, partials, M, N, Kd,
                                                "bf16")
                K.launch_splitk_reduce(partials, sk, out, M * N)

            splitk_step()  # autotune the split kernel before timing
            ms_split = min(do_bench(splitk_step), do_bench(splitk_step))
            if ms_split < ms_plain * 0.97:
                pick = K.splitk_pick("bf16", M, N, Kd, sam, sbk,
                                     ta is not None, tb is not None,
                                     a.dtype, b.dtype)
                _bf16_splitk_disk_save(key, pick)
        _SPLITK_PICKS[key] = pick
    if not pick:
        return False
    partials = _splitk_ws(M, N)
    # reduce with the launcher's actual split count, like the fp32 route
    sk = K.launch_matmul_mma_splitk(a, b, partials, M, N, Kd, "bf16")
    K.launch_splitk_reduce(partials, sk, out, M * N)
    return True


_SPLITK_MAX = 16  # partial planes budgeted during the one-time judgement

# split-K partials workspace, cached per (M, N) and shared by every
# split-K call of that shape: no per-call alloc, and the cached buffer
# (created at warmup) is what makes split-K legal inside CUDA-graph
# capture (cuMemAlloc during capture is illegal). Uncapped on purpose:
# an evicted buffer could still be replayed by a captured graph.
_SPLITK_WS: dict = {}


def _splitk_ws(M: int, N: int) -> Tensor:
    ws = _SPLITK_WS.get((M, N))
    if ws is None:
        ws = empty((_SPLITK_MAX, M, N), tl_types.float32, "cuda")
        _SPLITK_WS[(M, N)] = ws
    return ws


def bmm(a: Tensor, b: Tensor) -> Tensor:
    _guard_i32_elems(a, "bmm")
    _guard_i32_elems(b, "bmm")
    if _prec.matmul_fp64():
        # fp64 ds kernel hardcodes row strides (see _mm_prep_ds)
        a, b = _mm_prep_ds(a), _mm_prep_ds(b)
    else:
        a, b = _mm_prep(a), _mm_prep(b)
    B, M, Kd = a.shape
    B2, K2, N = b.shape
    if Kd != K2 or B != B2:
        raise RuntimeError(f"bmm shape mismatch {a.shape} @ {b.shape}")
    out = empty((B, M, N), tl_types.float32, "cuda")
    if B == 0 or M == 0 or N == 0:
        return out
    if _prec.matmul_fp64():
        K.launch_matmul_ds(a, b, out, M, N, Kd, B=B)
    elif _ALLOW_TF32 and K.mma_strides_ok("tf32", a.strides[1], b.strides[1]):
        K.launch_bmm_mma(a, b, out, B, M, N, Kd, "tf32")
    else:
        K.launch_bmm(a, b, out, B, M, N, Kd)
    return out


def bmm_bf16(a: Tensor, b: Tensor, out_dtype=None) -> Tensor:
    _guard_i32_elems(a, "bmm_bf16")
    _guard_i32_elems(b, "bmm_bf16")
    a = _mm_prep_dtype(a, tl_types.bfloat16, allow_trans=False)
    b = _mm_prep_dtype(b, tl_types.bfloat16, allow_trans=False)
    if out_dtype is None:
        out_dtype = tl_types.bfloat16
    B, M, Kd = a.shape
    B2, K2, N = b.shape
    if Kd != K2 or B != B2:
        raise RuntimeError(f"bmm shape mismatch {a.shape} @ {b.shape}")
    if B == 0 or M == 0 or N == 0:
        return empty((B, M, N), out_dtype, "cuda")
    if K.mma_strides_ok("bf16", a.strides[1], b.strides[1]):
        out = empty((B, M, N), out_dtype, "cuda")
        K.launch_bmm_mma(a, b, out, B, M, N, Kd, "bf16")
        return out
    out = bmm(a.astype(tl_types.float32), b.astype(tl_types.float32))
    return out if out_dtype == tl_types.float32 else \
        out.astype(tl_types.bfloat16)


# ---------------------------------------------------------------------------
# reduction / nn row primitives (shared layer hands us 2D contiguous rows)
# ---------------------------------------------------------------------------

def reduce_row(op: str, x2d: Tensor, out_dtype) -> Tensor:
    if x2d.dtype != out_dtype:
        x2d = x2d.astype(out_dtype)
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = x2d.shape
    out = empty((R,), out_dtype, "cuda")
    if R:
        pkey = ("rr", op, x2d.shape, x2d.dtype, out_dtype)
        fl = _PLANS.get(pkey)
        if fl is not None:
            fl((x2d._buffer_arg(), out._buffer_arg(), C))
            return out
        fl = K.launch_reduce_row(x2d, out, C, op, out_dtype)
        if fl is not None:
            if len(_PLANS) >= _PLAN_CAP:
                _PLANS.clear()
            _PLANS[pkey] = fl
    return out


def reduce_col_sum(x2d: Tensor, out_dtype) -> Tensor:
    """Column sums of a contiguous f32 (R, C): direct column-reduce
    partials + fold (the permute+contiguous+reduce_row route would
    materialize a strided copy)."""
    R, C = x2d.shape
    out = empty((C,), out_dtype, "cuda")
    if R == 0:
        return out
    pkey = ("rcs", x2d.shape, x2d.dtype, out_dtype)
    ent = _PLANS.get(pkey)
    if ent is not None:
        fl1, tail1, fl2, tail2, parts, pb = ent
        fl1((x2d._buffer_arg(), pb, *tail1))
        fl2((pb, out._buffer_arg(), *tail2))
        return out
    _, _, _, _, rch, _ = K.col_sum_geometry(R, C, x2d.dtype.itemsize)
    partials = empty((rch, C), tl_types.float32, "cuda")
    ret = K.launch_reduce_col_sum(x2d, partials, out, R, C)
    if ret is not None and ret[0] is not None and ret[1] is not None:
        fl1, fl2, parts, slice_rows, rch2 = ret
        if len(_PLANS) >= _PLAN_CAP:
            _PLANS.clear()
        _PLANS[pkey] = (fl1, (R, C, slice_rows), fl2, (C,), parts,
                        parts._buffer_arg())
    return out


def reduce_full(op: str, x: Tensor, out_dtype) -> Tensor:
    if x.dtype != out_dtype:
        x = x.astype(out_dtype)
    if not x.is_contiguous():
        x = x.contiguous()
    if not x.numel():
        # empty reduce: sum -> identity 0 (numpy/torch), max/min raise
        if op == "sum":
            from ...tensor import zeros
            return zeros((), out_dtype, "cuda")
        raise RuntimeError(f"{op} of an empty tensor")
    out = empty((), out_dtype, "cuda")
    if x.numel():
        pkey = ("rf", op, x.shape, x.dtype, out_dtype)
        ent = _PLANS.get(pkey)
        if ent is not None:
            fl1, tail1, fl2, tail2, part, pb = ent
            fl1((x._buffer_arg(), pb, *tail1))
            fl2((pb, out._buffer_arg(), *tail2))
            return out
        ret = K.launch_reduce_full(x, out, op, out_dtype)
        if ret is not None and ret[0] is not None and ret[1] is not None:
            fl1, fl2, part, grid, nchunk = ret
            if len(_PLANS) >= _PLAN_CAP:
                _PLANS.clear()
            _PLANS[pkey] = (fl1, (x.numel(), nchunk), fl2, (grid,), part,
                            part._buffer_arg())
    return out


def argmax_rows(x2d: Tensor) -> Tensor:
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = x2d.shape
    out = empty((R,), tl_types.int64, "cuda")
    if R:
        K.launch_argmax_row(x2d, out, C)
    return out


def softmax_rows(x2d: Tensor, log: bool) -> Tensor:
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = x2d.shape
    out = empty(x2d.shape, x2d.dtype, "cuda")
    if R:
        K.launch_softmax(x2d, out, C, log)
    return out


def layer_norm_rows(x2d: Tensor, w, b, eps: float, out_dtype=None) -> Tensor:
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = x2d.shape
    out = empty(x2d.shape, out_dtype or x2d.dtype, "cuda")
    if R:
        pkey = ("ln", x2d.shape, x2d.dtype, out.dtype,
                w is not None and w.dtype, b is not None and b.dtype)
        fl = _PLANS.get(pkey)
        if fl is not None:
            fl((x2d._buffer_arg(), (w if w is not None else x2d)._buffer_arg(),
                (b if b is not None else x2d)._buffer_arg(), out._buffer_arg(), C, eps))
            return out
        fl = K.launch_layernorm(x2d, w, b, out, C, eps)
        if fl is not None:
            if len(_PLANS) >= _PLAN_CAP:
                _PLANS.clear()
            _PLANS[pkey] = fl
    return out


def add_layernorm_rows(x2d: Tensor, res2d: Tensor, w, b, eps: float,
                       need_sum: bool = False):
    """Fused residual-add + layer_norm on (R, C) rows (case-fusions).
    Returns (out, s) with s = x + res when need_sum else None."""
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    if not res2d.is_contiguous():
        res2d = res2d.contiguous()
    R, C = x2d.shape
    out = empty(x2d.shape, x2d.dtype, "cuda")
    s = empty(x2d.shape, x2d.dtype, "cuda") if need_sum else None
    if R:
        K.launch_add_layernorm(x2d, res2d, w, b, out, s, C, eps)
    return out, s


def rms_norm_rows(x2d: Tensor, w, eps: float) -> Tensor:
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = x2d.shape
    out = empty(x2d.shape, x2d.dtype, "cuda")
    if R:
        K.launch_rmsnorm(x2d, w, out, C, eps)
    return out


def embedding_rows(w2d: Tensor, idx1d: Tensor) -> Tensor:
    w = w2d if w2d.is_contiguous() else w2d.contiguous()
    idx = idx1d
    if idx.dtype != tl_types.int32:
        idx = idx.astype(tl_types.int32)
    if not idx.is_contiguous():
        idx = idx.contiguous()
    C = w.shape[1]
    out = empty((idx.numel(), C), w.dtype, "cuda")
    if idx.numel():
        K.launch_embedding(w, idx, out, C)
    return out


def cross_entropy_rows(x2d: Tensor, t1d: Tensor) -> Tensor:
    x = x2d if x2d.is_contiguous() else x2d.contiguous()
    t = t1d
    if t.dtype != tl_types.int32:
        t = t.astype(tl_types.int32)
    if not t.is_contiguous():
        t = t.contiguous()
    R, C = x.shape
    out = empty((R,), x.dtype, "cuda")
    if R:
        K.launch_cross_entropy_rows(x, t, out, C)
    return out


# ---------------------------------------------------------------------------
# backward primitives (mirror device/cpu numpy implementations)
# ---------------------------------------------------------------------------

def softmax_backward_rows(g2d: Tensor, y2d: Tensor) -> Tensor:
    R, C = g2d.shape
    out = empty(g2d.shape, g2d.dtype, "cuda")
    if R:
        K.launch_softmax_backward(g2d, y2d, out, C, log=False)
    return out


def log_softmax_backward_rows(g2d: Tensor, y2d: Tensor) -> Tensor:
    R, C = g2d.shape
    out = empty(g2d.shape, g2d.dtype, "cuda")
    if R:
        K.launch_softmax_backward(g2d, y2d, out, C, log=True)
    return out


def layernorm_backward_rows(g2d: Tensor, x2d: Tensor, w, eps: float):
    R, C = g2d.shape
    dx = empty(g2d.shape, g2d.dtype, "cuda")
    xh = empty(g2d.shape, g2d.dtype, "cuda")
    if R:
        pkey = ("lnb", g2d.shape, g2d.dtype, x2d.dtype,
                w is not None and w.dtype)
        fl = _PLANS.get(pkey)
        if fl is not None:
            fl((g2d._buffer_arg(), x2d._buffer_arg(),
                (w if w is not None else g2d)._buffer_arg(), dx._buffer_arg(),
                xh._buffer_arg(), C, eps))
            return dx, xh
        fl = K.launch_layernorm_backward(g2d, x2d, w, dx, xh, C, eps)
        if fl is not None:
            if len(_PLANS) >= _PLAN_CAP:
                _PLANS.clear()
            _PLANS[pkey] = fl
    return dx, xh


def layernorm_backward_fused(g2d: Tensor, x2d: Tensor, w, eps: float):
    """Full fused LN backward: (dx, dgamma, dbeta) without materializing
    xhat or the g*xhat product (the weight-grad column sums recompute
    xhat from per-row (mean, rstd) stats — bit-identical f32 math,
    ~(R,C)*4B*4 less traffic per LN)."""
    R, C = g2d.shape
    f32 = tl_types.float32
    dx = empty(g2d.shape, g2d.dtype, "cuda")
    dgamma = empty((C,), f32, "cuda")
    dbeta = empty((C,), f32, "cuda")
    if R:
        pkey = ("lnbf", g2d.shape, g2d.dtype, x2d.dtype,
                w is not None and w.dtype)
        ent = _PLANS.get(pkey)
        if ent is not None:
            fl1, fl2, fl3, st, pa, pb, tail = ent
            fl1((g2d._buffer_arg(), x2d._buffer_arg(),
                 (w if w is not None else g2d)._buffer_arg(), dx._buffer_arg(),
                 st._buffer_arg(), C, eps))
            fl2((g2d._buffer_arg(), x2d._buffer_arg(), st._buffer_arg(),
                 pa._buffer_arg(), pb._buffer_arg(), *tail))
            # pa holds the g sums (dbeta), pb the g*xhat sums (dgamma)
            fl3((pa._buffer_arg(), pb._buffer_arg(),
                 dbeta._buffer_arg(), dgamma._buffer_arg(), C))
            return dx, dgamma, dbeta
        fl1, fl2, fl3, st, pa, pb, tail = \
            K.launch_layernorm_backward_fused(g2d, x2d, w, dx, dbeta,
                                              dgamma, R, C, eps)
        if fl2 is not None and fl3 is not None:
            if len(_PLANS) >= _PLAN_CAP:
                _PLANS.clear()
            _PLANS[pkey] = (fl1, fl2, fl3, st, pa, pb, tail)
    return dx, dgamma, dbeta


def layernorm_backward_dx(g2d: Tensor, x2d: Tensor, w, eps: float):
    """dx-only fused LN backward (no weight/bias grads wanted): the
    stats row kernel alone — no xhat, no column-sum stages."""
    R, C = g2d.shape
    dx = empty(g2d.shape, g2d.dtype, "cuda")
    if R:
        pkey = ("lnbdx", g2d.shape, g2d.dtype, x2d.dtype,
                w is not None and w.dtype)
        ent = _PLANS.get(pkey)
        if ent is not None:
            fl, st = ent
            fl((g2d._buffer_arg(), x2d._buffer_arg(),
                (w if w is not None else g2d)._buffer_arg(), dx._buffer_arg(),
                st._buffer_arg(), C, eps))
            return dx
        fl, st = K.launch_layernorm_backward_dx(g2d, x2d, w, dx, R, C,
                                                eps)
        if fl is not None:
            if len(_PLANS) >= _PLAN_CAP:
                _PLANS.clear()
            _PLANS[pkey] = (fl, st)
    return dx


def rmsnorm_backward_rows(g2d: Tensor, x2d: Tensor, w, eps: float):
    R, C = g2d.shape
    dx = empty(g2d.shape, g2d.dtype, "cuda")
    xr = empty(g2d.shape, g2d.dtype, "cuda")
    if R:
        K.launch_rmsnorm_backward(g2d, x2d, w, dx, xr, C, eps)
    return dx, xr


def cross_entropy_backward_rows(x2d: Tensor, t1d: Tensor,
                                grows: Tensor) -> Tensor:
    R, C = x2d.shape
    out = empty(x2d.shape, x2d.dtype, "cuda")
    if R:
        K.launch_cross_entropy_backward(x2d, t1d, grows, out, C)
    return out


def embedding_backward_rows(g2d: Tensor, idx1d: Tensor,
                            num_rows: int) -> Tensor:
    from ...tensor import zeros
    C = g2d.shape[1]
    dw = zeros((num_rows, C), g2d.dtype, "cuda")
    if idx1d.numel():
        if _prec.embed_fp64():
            K.launch_embedding_backward_ds(g2d, idx1d, dw, C, num_rows)
        else:
            K.launch_embedding_backward(g2d, idx1d, dw, C)
    return dw


def copy_into_view(dst_view: Tensor, src: Tensor):
    """Copy src into the (possibly strided) dst_view of a base tensor."""
    shape = dst_view.shape if dst_view.ndim > 0 else (1,)
    sv = src if src.ndim > 0 else src.reshape((1,))
    ckey = ("civ", shape, dst_view._st, dst_view.dtype, dst_view._offset,
            sv.shape, sv._st, sv.dtype, sv._offset)
    ent = _PLANS.get(ckey)
    if ent is not None:
        fl, args = ent
        args[0] = sv._buffer_arg()
        args[1] = dst_view._buffer_arg()
        fl(args)
        return
    spec = ew.operand_spec(sv, shape)
    # 0-d dst: strides is () — treat as the (1,) unit-stride form
    out_mode = 1 if dst_view.ndim == 0 or dst_view.strides[-1] == 1 else 2
    k = ew.nd_unary("ndu_copy", "{x}", len(shape), sv.dtype, dst_view.dtype,
                    dst_view.dtype, spec[2], out_mode=out_mode,
                    pipelined=ew.short_rows(shape))
    fl, args = ew.launch_nd(k, len(shape), shape, [spec],
                            dst_view._buffer_arg(),
                            out_strides=[int(s) for s in dst_view.strides[:-1]],
                            out_last_stride=int(dst_view.strides[-1])
                            if dst_view.ndim else 1)
    if fl is not None:
        if len(_PLANS) >= _PLAN_CAP:
            _PLANS.clear()
        _PLANS[ckey] = (fl, args)


def adamw_step(p: Tensor, g: Tensor, m: Tensor, v: Tensor, lr_t: float,
               wd_lr: float, b1: float, b2: float, eps: float,
               torch_eps: bool = False, s2: float = 1.0):
    """Fused AdamW update, in place on p/m/v (nn.optim.AdamW)."""
    n = p.numel()
    pkey = ("adamw", n, p.dtype, g.dtype, torch_eps)
    ent = _PLANS.get(pkey)
    if ent is not None:
        ent((p._buffer_arg(), g._buffer_arg(), m._buffer_arg(),
             v._buffer_arg(), n, lr_t, wd_lr, b1, 1.0 - b1, b2, 1.0 - b2,
             eps, s2))
        return
    fl = K.launch_adamw(p, g, m, v, n, lr_t, wd_lr, b1, b2, eps,
                        torch_eps=torch_eps, s2=s2)
    if fl is not None:
        if len(_PLANS) >= _PLAN_CAP:
            _PLANS.clear()
        _PLANS[pkey] = fl


def kda_forward(kn, qn, v, beta, loga, g, gt, c, emc, s0,
                output_final_state: bool = False):
    """KDA forward: DSL kernels in device/cuda/kernels/kda.py;
    inputs are the shared layer's preprocessed tensors (ops/kda.py).
    loga is unused on CUDA (the decay cumsum g is precomputed eagerly)."""
    _guard_i32_elems(kn, "kda_forward")
    _guard_i32_elems(qn, "kda_forward")
    _guard_i32_elems(v, "kda_forward")
    _guard_i32_elems(beta, "kda_forward")
    _guard_i32_elems(loga, "kda_forward")
    _guard_i32_elems(g, "kda_forward")
    _guard_i32_elems(gt, "kda_forward")
    _guard_i32_elems(c, "kda_forward")
    _guard_i32_elems(emc, "kda_forward")
    _guard_i32_elems(s0, "kda_forward")
    from .kernels import kda as kda_k
    return kda_k.kda_forward(kn, qn, v, beta, g, gt, c, emc, s0,
                             output_final_state)


def kda_forward_fused(q, k, v, x_beta, x_decay, s0,
                      output_final_state: bool = False):
    """v2 fused KDA forward: raw public-contract inputs, the
    whole eager K0 preprocessing folded into two kernels + the one-dot
    affine-map state scan (device/cuda/kernels/kda.py)."""
    _guard_i32_elems(q, "kda_forward_fused")
    _guard_i32_elems(k, "kda_forward_fused")
    _guard_i32_elems(v, "kda_forward_fused")
    _guard_i32_elems(x_beta, "kda_forward_fused")
    _guard_i32_elems(x_decay, "kda_forward_fused")
    _guard_i32_elems(s0, "kda_forward_fused")
    from .kernels import kda as kda_k
    return kda_k.kda_forward_fused(q, k, v, x_beta, x_decay, s0,
                                   output_final_state)


def kda_forward_mma(kn, qn, v, beta, loga, g, gt, c, emc, s0,
                    output_final_state: bool = False,
                    precision: str = "tf32"):
    """KDA forward on tensor cores (tf32/bf16 tiers): DSL
    kernels in device/cuda/kernels/kda_mma.py. Same preprocessed contract as
    kda_forward; public tensors stay f32."""
    _guard_i32_elems(kn, "kda_forward_mma")
    _guard_i32_elems(qn, "kda_forward_mma")
    _guard_i32_elems(v, "kda_forward_mma")
    _guard_i32_elems(beta, "kda_forward_mma")
    _guard_i32_elems(loga, "kda_forward_mma")
    _guard_i32_elems(g, "kda_forward_mma")
    _guard_i32_elems(gt, "kda_forward_mma")
    _guard_i32_elems(c, "kda_forward_mma")
    _guard_i32_elems(emc, "kda_forward_mma")
    _guard_i32_elems(s0, "kda_forward_mma")
    from .kernels import kda_mma as kda_m
    return kda_m.kda_forward_mma(kn, qn, v, beta, g, gt, c, emc, s0,
                                 output_final_state, atom=precision)


def l2norm_rows(x2d: Tensor) -> Tensor:
    """Fused l2norm on (R, C) rows (KDA preprocessing; one pass)."""
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = x2d.shape
    out = empty(x2d.shape, x2d.dtype, "cuda")
    if R:
        from .kernels import kda as kda_k
        kda_k.launch_kda_l2norm(x2d, out, R, C)
    return out


def flash_attention_forward(q: Tensor, k: Tensor, v: Tensor, scale: float,
                            with_lse: bool = False,
                            precision: str | None = None):
    """Fused causal flash attention; q/k/v (B, H, T, hd) -> (B, H, T, hd)
    (natural key layout; the transpose folds into smem staging). with_lse
    also returns the (B, H, T) log-sum-exp for the fused backward.

    precision: "fp32" (exact FMA), "tf32"/"bf16" (mma, f32 accumulate;
    the bf16 tier takes bf16 inputs and returns bf16 out, lse f32).
    None routes by dtype (+tf32 flag)."""
    _guard_i32_elems(q, "flash_attention_forward")
    _guard_i32_elems(k, "flash_attention_forward")
    _guard_i32_elems(v, "flash_attention_forward")
    B, H, T, HD = q.shape
    if precision is None:
        precision = "bf16" if q.dtype == tl_types.bfloat16 else \
            ("tf32" if get_allow_tf32() else "fp32")
    qc = q.contiguous().reshape((B * H, T, HD))
    kc = k.contiguous().reshape((B * H, T, HD))
    vc = v.contiguous().reshape((B * H, T, HD))
    out = empty(q.shape, q.dtype, "cuda")
    if precision in ("tf32", "bf16"):
        lse = empty((B, H, T), tl_types.float32, "cuda")
        K.launch_flash_attention_mma(qc, kc, vc,
                                     out.reshape((B * H, T, HD)),
                                     lse.reshape((B * H, T)), scale,
                                     atom=precision, num_warps=4)
        return (out, lse) if with_lse else out
    if precision != "fp32":
        raise ValueError(f"unknown flash attention precision {precision!r}")
    lse = empty((B, H, T), q.dtype, "cuda")
    K.launch_flash_attention(qc, kc, vc, out.reshape((B * H, T, HD)),
                             lse.reshape((B * H, T)), scale, num_warps=4)
    return (out, lse) if with_lse else out


def flash_attention_backward(q: Tensor, k: Tensor, v: Tensor, o: Tensor,
                             do: Tensor, lse: Tensor, scale: float,
                             precision: str | None = None):
    """Fused flash backward. precision=None routes by dtype (f32 -> fp32
    kernels, bf16 -> bf16 mma kernels); "fp32" forces the f32 kernels
    (bf16 inputs must be upcast by the caller)."""
    _guard_i32_elems(q, "flash_attention_backward")
    _guard_i32_elems(k, "flash_attention_backward")
    _guard_i32_elems(v, "flash_attention_backward")
    _guard_i32_elems(o, "flash_attention_backward")
    _guard_i32_elems(do, "flash_attention_backward")
    _guard_i32_elems(lse, "flash_attention_backward")
    B, H, T, HD = q.shape
    if precision is None:
        precision = "bf16" if q.dtype == tl_types.bfloat16 else "fp32"
    qc = q.contiguous().reshape((B * H, T, HD))
    kc = k.contiguous().reshape((B * H, T, HD))
    vc = v.contiguous().reshape((B * H, T, HD))
    oc = o.contiguous().reshape((B * H, T, HD))
    doc = do.contiguous().reshape((B * H, T, HD))
    lse_c = lse.contiguous().reshape((B * H, T))
    dq = empty(q.shape, q.dtype, "cuda")
    dk = empty(q.shape, q.dtype, "cuda")
    dv = empty(q.shape, q.dtype, "cuda")
    if precision == "bf16":
        delta = empty((B, H, T), tl_types.float32, "cuda").reshape(
            (B * H, T))
        K.launch_flash_attention_bwd_bf16(
            qc, kc, vc, oc, doc, lse_c, delta,
            dq.reshape((B * H, T, HD)), dk.reshape((B * H, T, HD)),
            dv.reshape((B * H, T, HD)), scale, num_warps=4)
        return dq, dk, dv
    if precision != "fp32":
        raise ValueError(
            f"unknown flash attention backward precision {precision!r}")
    delta = empty((B, H, T), q.dtype, "cuda").reshape((B * H, T))
    K.launch_flash_attention_bwd(
        qc, kc, vc, oc, doc, lse_c, delta,
        dq.reshape((B * H, T, HD)), dk.reshape((B * H, T, HD)),
        dv.reshape((B * H, T, HD)), scale, num_warps=4)
    return dq, dk, dv


def flash_attention_forward_qkv(qkv: Tensor, n_head: int, scale: float,
                                precision: str = "bf16"):
    """qkv-packed fused forward: qkv (B, T, 3C) -> fresh (out (B, T, C),
    lse (B*H, T) f32) straight from the column thirds — no head-split/
    merge copies. precision "bf16" (mma) or "fp32" (exact-FMA)."""
    _guard_i32_elems(qkv, "flash_attention_forward_qkv")
    B, T, C3 = qkv.shape
    C = C3 // 3
    out = empty((B, T, C), qkv.dtype, "cuda")
    lse = empty((B * n_head, T), tl_types.float32, "cuda")
    if precision == "fp32":
        K.launch_flash_attention_qkv(qkv, out, lse, n_head, scale,
                                     num_warps=4)
    else:
        K.launch_flash_attention_mma_qkv(qkv, out, lse, n_head, scale,
                                         atom=precision, num_warps=4)
    return out, lse


def flash_attention_backward_qkv(qkv: Tensor, o: Tensor, do: Tensor,
                                 lse: Tensor, n_head: int, scale: float,
                                 precision: str = "bf16"):
    """qkv-packed fused backward: -> dqkv (B, T, 3C) with the q/k/v
    grads written straight into the column thirds. precision "bf16"
    (native bf16 mma) or "fp32" (exact-FMA)."""
    _guard_i32_elems(qkv, "flash_attention_backward_qkv")
    _guard_i32_elems(o, "flash_attention_backward_qkv")
    _guard_i32_elems(do, "flash_attention_backward_qkv")
    _guard_i32_elems(lse, "flash_attention_backward_qkv")
    B, T, C3 = qkv.shape
    dqkv = empty(qkv.shape, qkv.dtype, "cuda")
    delta = empty((B * n_head, T), tl_types.float32, "cuda")
    if precision in ("fp32", "tf32"):
        # fp32 and tf32 tiers share the exact-FMA fused backward
        K.launch_flash_attention_bwd_qkv(qkv, o, do, lse, delta, dqkv,
                                         n_head, scale, num_warps=4)
    else:
        K.launch_flash_attention_bwd_bf16_qkv(qkv, o, do, lse, delta,
                                              dqkv, n_head, scale,
                                              num_warps=4)
    return dqkv


# ---------------------------------------------------------------------------
# sparse / message passing primitives
# ---------------------------------------------------------------------------

def _i32c(t: Tensor) -> Tensor:
    t = t if t.dtype == tl_types.int32 else t.astype(tl_types.int32)
    return t if t.is_contiguous() else t.contiguous()


def _f32c(t: Tensor) -> Tensor:
    t = t if t.dtype == tl_types.float32 else t.astype(tl_types.float32)
    return t if t.is_contiguous() else t.contiguous()


def gather_flat(x1d: Tensor, idx1d: Tensor) -> Tensor:
    out = empty((idx1d.numel(),), x1d.dtype, "cuda")
    K.launch_gather_flat(x1d, idx1d, out, idx1d.numel())
    return out


def scatter_add_flat(src1d: Tensor, idx1d: Tensor, num_rows: int) -> Tensor:
    from ...tensor import zeros
    out = zeros((num_rows,), src1d.dtype, "cuda")
    K.launch_scatter_flat(src1d, idx1d, out, idx1d.numel())
    return out


def gather_cols(x2d: Tensor, idx2d: Tensor) -> Tensor:
    """out[r, j] = x[r, idx[r, j]]: x (R, C), idx (R, E)."""
    R, E = idx2d.shape
    C = x2d.shape[1]
    out = empty((R, E), x2d.dtype, "cuda")
    K.launch_gather_cols(x2d, idx2d, out, E, C)
    return out


def gather_rc(x2d: Tensor, idx2d: Tensor) -> Tensor:
    """out[i, j] = x[idx[i, j], j]: x (N, C), idx (E, D) with D == C."""
    E, D = idx2d.shape
    C = x2d.shape[1]
    out = empty((E, D), x2d.dtype, "cuda")
    K.launch_gather_rc(x2d, idx2d, out, D, C)
    return out


def gather_cols_backward(g2d: Tensor, idx2d: Tensor, C: int) -> Tensor:
    from ...tensor import zeros
    R, E = idx2d.shape
    dx = zeros((R, C), g2d.dtype, "cuda")
    K.launch_gather_cols_backward(g2d, idx2d, dx, E, C)
    return dx


def gather_rc_backward(g2d: Tensor, idx2d: Tensor, N: int) -> Tensor:
    from ...tensor import zeros
    E, D = idx2d.shape
    C = D
    dx = zeros((N, C), g2d.dtype, "cuda")
    K.launch_gather_rc_backward(g2d, idx2d, dx, D, C)
    return dx


def segment_reduce_values(v1d: Tensor, rp1d: Tensor, op: str) -> Tensor:
    R = rp1d.numel() - 1
    out = empty((R,), v1d.dtype, "cuda")
    K.launch_segment_reduce(v1d, rp1d, out, R, op)
    return out


def segment_reduce_backward(g1d: Tensor, v1d: Tensor, rp1d: Tensor,
                            op: str) -> Tensor:
    from ...tensor import zeros
    R = rp1d.numel() - 1
    gv = zeros((v1d.numel(),), g1d.dtype, "cuda")
    if v1d.numel():
        K.launch_segment_reduce_backward(v1d, g1d, rp1d, gv, R, op)
    return gv


def spmm_csr_forward(rp1d: Tensor, col1d: Tensor, val1d: Tensor,
                     b2d: Tensor) -> Tensor:
    R = rp1d.numel() - 1
    K_rows, N = b2d.shape
    out = empty((R, N), val1d.dtype, "cuda")
    K.launch_spmm_csr(rp1d, col1d, val1d, b2d, out, R, N)
    return out


def spmm_csr_backward_val(g2d: Tensor, rp1d: Tensor, col1d: Tensor,
                          b2d: Tensor) -> Tensor:
    """dval[k] = <g[row(k)], B[col[k]]>; N <= 8192 (row-block)."""
    N = b2d.shape[1]
    if N > 8192:
        raise NotImplementedError(
            f"spmm_csr backward for val requires dense width <= 8192, "
            f"got {N}")
    R = rp1d.numel() - 1
    dv = empty((col1d.numel(),), g2d.dtype, "cuda")
    K.launch_spmm_csr_backward_val(g2d, rp1d, col1d, b2d, dv, R, N,
                                   col1d.numel())
    return dv


def spmm_csr_backward_dense(g2d: Tensor, rp1d: Tensor, col1d: Tensor,
                            val1d: Tensor, K_rows: int) -> Tensor:
    from ...tensor import zeros
    R = rp1d.numel() - 1
    N = g2d.shape[1]
    db = zeros((K_rows, N), g2d.dtype, "cuda")
    if val1d.numel():
        K.launch_spmm_csr_backward_dense(g2d, rp1d, col1d, val1d, db, R, N)
    return db


# ---------------------------------------------------------------------------
# searchsorted / coo_sort_by_key
# ---------------------------------------------------------------------------

def searchsorted(a1d: Tensor, v1d: Tensor, side: str) -> Tensor:
    if a1d.ndim != 1 or v1d.ndim != 1:
        raise RuntimeError("searchsorted expects 1D sorted_seq and values")
    i32 = tl_types.int32
    out = empty((v1d.numel(),), i32, "cuda")
    K.launch_searchsorted(a1d, v1d, out, v1d.numel(), a1d.numel(), side)
    return out


def coo_sort_by_key(keys1d: Tensor, vals1d: Tensor) -> tuple[Tensor, Tensor]:
    """Stable-is-not-guaranteed bitonic sort of (keys, vals); keys i32 <
    2**31-1. Pads to the next power of 2 with a sentinel key."""
    from ...tensor import arange
    N = keys1d.numel()
    i32 = tl_types.int32
    N2 = max(2, 1 << (N - 1).bit_length())
    if vals1d.dtype == i32 or vals1d.dtype.is_float:
        pass
    else:
        raise RuntimeError(
            f"coo_sort_by_key currently supports i32/f32 payloads, got "
            f"{vals1d.dtype}")
    ks = empty((N2,), keys1d.dtype, "cuda")
    vs = empty((N2,), vals1d.dtype, "cuda")
    K.launch_bitonic_pad(keys1d, vals1d, ks, vs, N, 2**31 - 1, N2)
    id_buf = arange(0, N2, dtype=i32, device="cuda")
    K.launch_bitonic_sort(ks, vs, id_buf, N2)
    return ks[:N].contiguous(), vs[:N].contiguous()
