"""Shared helpers of the device/cuda kernels package:
split-K partials fold + column-sum geometry + the row-block picker.

All kernels assume the *last* dim of every operand is unit-stride (the
eager layer calls .contiguous() when that is not the case); other strides
are runtime i32 arguments.

``import minitriton as tl`` here resolves against the partially initialized
package (frontend/runtime names are exported before the eager layer is
imported), which is what makes the decorators work at import time.

NOTE: no ``from __future__ import annotations`` here — kernel parameter
annotations (``tl.constexpr``) must stay real objects for the DSL binder.
"""

import minitriton as tl


@tl.kernel
def splitk_reduce_kernel(p_ptr, o_ptr, C, S: tl.constexpr,
                         OUT_BF16: tl.constexpr, BLOCK: tl.constexpr):
    """out[c] = sum over the S split planes of the (S, C) f32 partials.
    OUT_BF16 packs the f32 accumulator to bf16 on store (bf16 column-sum
    output contract; plain f32 store otherwise)."""
    offs = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    m = offs < C
    acc = tl.load(p_ptr + offs, mask=m, other=0.0)
    for s in range(1, S):
        acc = acc + tl.load(p_ptr + s * C + offs, mask=m, other=0.0)
    if OUT_BF16:
        acc = tl.cast(acc, tl.bfloat16)
    tl.store(o_ptr + offs, acc, mask=m)


def launch_splitk_reduce(partials, split_k: int, out, C: int):
    BLOCK = 128
    from ....frontend import types as _t
    return splitk_reduce_kernel[((C + BLOCK - 1) // BLOCK,)](
        partials._buffer_arg(), out._buffer_arg(), C, S=split_k,
        OUT_BF16=out.dtype == _t.bfloat16, BLOCK=BLOCK, num_warps=4)


def _row_block(C: int) -> int:
    b = max(128, ((C + 127) // 128) * 128)
    if b > 8192:
        raise NotImplementedError(
            f"row length {C} exceeds the single-pass reduction limit of "
            "8192; split the reduction or use a smaller row")
    return b



def _col_vec_bc(C: int, itemsize: int):
    """(BC, num_warps, even) for a vectorized column walk: every thread
    should own a 16B contiguous fragment (ept = 16/itemsize) and
    ideally cover C exactly (EVEN_C drops the mask -> vector loads)."""
    ept = 16 // itemsize
    if C % (ept * 32) == 0:
        nt = C // ept
        if 32 <= nt <= 1024 and nt % 32 == 0:
            return C, nt // 32, True
    BC = 32 * ept * 4  # 128 threads
    return BC, 4, False


def col_sum_geometry(R: int, C: int, itemsize: int, target_rows: int = 96):
    """The one place the column-reduce geometry is decided (BC, warps,
    even, ncol, rch, slice_rows) — caller and launcher MUST agree on the
    partial-plane count or the kernel writes past the (rch, C) partials
    buffer."""
    BC, nw, even = _col_vec_bc(C, itemsize)
    ncol = (C + BC - 1) // BC
    rch = max(1, min(target_rows, (512 + ncol - 1) // ncol, R))
    slice_rows = (R + rch - 1) // rch
    rch = (R + slice_rows - 1) // slice_rows
    return BC, nw, even, ncol, rch, slice_rows




__all__ = [
    "splitk_reduce_kernel",
    "launch_splitk_reduce",
    "_row_block",
    "_col_vec_bc",
    "col_sum_geometry",
]
