"""Flash attention kernels of the device/cuda kernels package:
forward (fp32 dot_t3 / tf32-bf16 tl.mma, plain + qkv-packed) and
backward (delta + dq/dkv, fp32 / native bf16, plain + qkv-packed),
all pure DSL.

All kernels assume the *last* dim of every operand is unit-stride (the
eager layer calls .contiguous() when that is not the case); other strides
are runtime i32 arguments.

``import minitriton as tl`` here resolves against the partially initialized
package (frontend/runtime names are exported before the eager layer is
imported), which is what makes the decorators work at import time.

NOTE: no ``from __future__ import annotations`` here — kernel parameter
annotations (``tl.constexpr``) must stay real objects for the DSL binder.
"""

import minitriton as tl


# ---------------------------------------------------------------------------
# flash attention forward: causal, fp32, online softmax.
# Pure-DSL kernel (row-per-thread "t3" mapping: BM == num_threads, q rows
# streamed from L1, s/p/acc rows in registers, kt/v tiles streamed
# global->smem via cp.async on the general scheduling constructs).
# The kernel also writes the per-row lse (log-sum-exp of scaled
# scores), which the fused backward kernels below consume.
# ---------------------------------------------------------------------------

@tl.kernel
def flash_attention_fwd_f32_qkv_dsl_kernel(qkv_ptr, o_ptr, lse_ptr, T,
                                           scale, H: tl.constexpr,
                                           C: tl.constexpr, HD: tl.constexpr,
                                           BM: tl.constexpr, BN: tl.constexpr,
                                           EVEN_T: tl.constexpr):
    """fp32 causal flash forward on the packed layouts, pure DSL: the
    (B, T, 3C)/(B, T, C) address algebra over the same constructs as
    flash_attention_fwd_f32_dsl_kernel (bit-equal)."""
    pid_m = (T + BM - 1) // BM - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    q0 = pid_m * BM
    offs_m = q0 + tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_d = tl.arange(0, HD)
    base3 = b * (T * (3 * C)) + h * HD
    baseo = b * (T * C) + h * HD
    q_pt = qkv_ptr + base3 + offs_m[:, None] * (3 * C) + offs_d[None, :]
    o_pt = o_ptr + baseo + offs_m[:, None] * C + offs_d[None, :]
    lay_r = tl.t3_layout((BM, HD))
    lay_1 = tl.t3_layout((BM, 1))
    row_i = tl.materialize(offs_m[:, None], LAYOUT=lay_1)
    acc = tl.zeros((BM, HD), tl.float32, LAYOUT=lay_r)
    m = tl.zeros((BM, 1), tl.float32, LAYOUT=lay_1) - float("inf")
    l = tl.zeros((BM, 1), tl.float32, LAYOUT=lay_1)
    ceil_t = ((T + BN - 1) // BN) * BN
    hi1b = q0 + BM
    hi2 = tl.where(hi1b < ceil_t, hi1b, ceil_t)
    if EVEN_T:
        k_buf = tl.smem((HD, BN), tl.float32)
        v_buf = tl.smem((2 * BN, HD), tl.float32)
        last0 = ((hi2 - 1) // BN) * BN
        k0n = tl.where(BN < hi2, BN, last0)
        tk = tl.async_copy(
            k_buf, qkv_ptr + base3 + C + offs_n[:, None] * (3 * C) +
            offs_d[None, :], TRANS=True)
        tl.async_copy(
            v_buf, qkv_ptr + base3 + 2 * C + offs_n[:, None] * (3 * C) +
            offs_d[None, :], EVEN=True)
        tok = tl.async_copy(
            v_buf, qkv_ptr + base3 + 2 * C + (k0n + offs_n)[:, None] *
            (3 * C) + offs_d[None, :], EVEN=True,
            OFFSET=(k0n // BN % 2) * (BN * HD))
        for k0 in range(0, hi2, BN):
            par = k0 // BN % 2
            tl.async_wait(tok, 1)
            tl.barrier()
            q_row = tl.load(q_pt, LAYOUT=lay_r, mask=(offs_m < T)[:, None])
            s = tl.dot_t3(q_row, k_buf)
            tl.barrier()
            k_next = tl.where(k0 + BN < hi2, k0 + BN, last0)
            tk = tl.async_copy(
                k_buf, qkv_ptr + base3 + C + (k_next + offs_n)[:, None] *
                (3 * C) + offs_d[None, :], TRANS=True)
            s = s * scale
            masked = k0 >= q0
            if masked:
                s = tl.where((row_i >= tl.materialize(k0 + offs_n))
                             & (tl.materialize(k0 + offs_n) < T),
                             s, -1e9)
            mn = tl.maximum(m, tl.max(s, axis=1))
            alpha = tl.exp(m - mn)
            p = tl.exp(s - mn)
            l = l * alpha + tl.sum(p, axis=1)
            m = mn
            acc = acc * alpha
            acc = tl.dot_t3(p, v_buf, acc, OFFSET=par * (BN * HD))
            tl.barrier()
            v_next = tl.where(k0 + 2 * BN < hi2, k0 + 2 * BN, last0)
            tok = tl.async_copy(
                v_buf, qkv_ptr + base3 + 2 * C + (v_next + offs_n)[:, None]
                * (3 * C) + offs_d[None, :], EVEN=True,
                OFFSET=par * (BN * HD))
        tl.async_wait(tok, 0)
    else:
        k_buf = tl.smem((HD, BN), tl.float32)
        v_buf = tl.smem((BN, HD), tl.float32)
        for k0 in range(0, hi2, BN):
            offs_kv = k0 + offs_n
            kv_ok = (offs_kv < T)[:, None]
            t1 = tl.async_copy(
                k_buf, qkv_ptr + base3 + C + offs_kv[:, None] * (3 * C) +
                offs_d[None, :], TRANS=True, MASK=kv_ok)
            t2 = tl.async_copy(
                v_buf, qkv_ptr + base3 + 2 * C + offs_kv[:, None] *
                (3 * C) + offs_d[None, :], MASK=kv_ok)
            tl.async_wait(t2, 0)
            tl.barrier()
            q_row = tl.load(q_pt, LAYOUT=lay_r, mask=(offs_m < T)[:, None])
            s = tl.dot_t3(q_row, k_buf)
            s = s * scale
            masked = k0 >= q0
            if masked:
                s = tl.where((row_i >= tl.materialize(offs_kv))
                             & (tl.materialize(offs_kv) < T), s, -1e9)
            mn = tl.maximum(m, tl.max(s, axis=1))
            alpha = tl.exp(m - mn)
            p = tl.exp(s - mn)
            l = l * alpha + tl.sum(p, axis=1)
            m = mn
            acc = acc * alpha
            acc = tl.dot_t3(p, v_buf, acc)
            tl.barrier()
    o = acc / l
    tl.store(o_pt, o, mask=(offs_m < T)[:, None])
    lse = m + tl.log(l)
    tl.store(lse_ptr + bh * T + offs_m[:, None], lse,
             mask=(offs_m < T)[:, None])


@tl.kernel
def flash_attention_fwd_f32_dsl_kernel(q_ptr, kt_ptr, v_ptr, o_ptr, lse_ptr,
                                       T, scale, HD: tl.constexpr,
                                       BM: tl.constexpr, BN: tl.constexpr,
                                       EVEN_T: tl.constexpr):
    """fp32 causal flash-attention forward, t3 row-per-thread, pure DSL:
    thread tid owns q row q0+tid in registers and streams kv tiles —
    s = q·Kᵀ via dot_t3 against TRANS-staged K, online softmax
    (register-local row max/sum via tl.max/tl.sum on the t3 row),
    acc = acc·alpha + p·V via dot_t3 against natural-staged V;
    stores the output row and lse = m + ln(l). Bit-equal by
    construction (same FMA chains, same reduction forms, same ex2)."""
    pid_m = (T + BM - 1) // BM - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    q0 = pid_m * BM
    offs_m = q0 + tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_d = tl.arange(0, HD)
    base = bh * (T * HD)
    q_pt = q_ptr + base + offs_m[:, None] * HD + offs_d[None, :]
    o_pt = o_ptr + base + offs_m[:, None] * HD + offs_d[None, :]
    lay_r = tl.t3_layout((BM, HD))
    lay_1 = tl.t3_layout((BM, 1))
    row_i = tl.materialize(offs_m[:, None], LAYOUT=lay_1)
    acc = tl.zeros((BM, HD), tl.float32, LAYOUT=lay_r)
    m = tl.zeros((BM, 1), tl.float32, LAYOUT=lay_1) - float("inf")
    l = tl.zeros((BM, 1), tl.float32, LAYOUT=lay_1)
    ceil_t = ((T + BN - 1) // BN) * BN
    hi1b = q0 + BM
    hi2 = tl.where(hi1b < ceil_t, hi1b, ceil_t)
    if EVEN_T:
        # the intrinsic's schedule verbatim: single-buffered k (t+1
        # staged right after the QK dot), parity double-buffered v (t+2
        # into the OFFSET half) — one carried token, wait(1) covers both
        k_buf = tl.smem((HD, BN), tl.float32)
        v_buf = tl.smem((2 * BN, HD), tl.float32)
        last0 = ((hi2 - 1) // BN) * BN
        k0n = tl.where(BN < hi2, BN, last0)
        tk = tl.async_copy(
            k_buf,
            kt_ptr + base + offs_n[:, None] * HD + offs_d[None, :],
            TRANS=True)
        tl.async_copy(
            v_buf,
            v_ptr + base + offs_n[:, None] * HD + offs_d[None, :],
            EVEN=True)
        tok = tl.async_copy(
            v_buf,
            v_ptr + base + (k0n + offs_n)[:, None] * HD + offs_d[None, :],
            EVEN=True, OFFSET=(k0n // BN % 2) * (BN * HD))
        for k0 in range(0, hi2, BN):
            par = k0 // BN % 2
            tl.async_wait(tok, 1)
            tl.barrier()
            q_row = tl.load(q_pt, LAYOUT=lay_r, mask=(offs_m < T)[:, None])
            s = tl.dot_t3(q_row, k_buf)
            tl.barrier()
            k_next = tl.where(k0 + BN < hi2, k0 + BN, last0)
            tk = tl.async_copy(
                k_buf,
                kt_ptr + base + (k_next + offs_n)[:, None] * HD +
                offs_d[None, :], TRANS=True)
            s = s * scale
            masked = k0 >= q0
            if masked:
                s = tl.where((row_i >= tl.materialize(k0 + offs_n))
                             & (tl.materialize(k0 + offs_n) < T),
                             s, -1e9)
            mn = tl.maximum(m, tl.max(s, axis=1))
            alpha = tl.exp(m - mn)
            p = tl.exp(s - mn)
            l = l * alpha + tl.sum(p, axis=1)
            m = mn
            acc = acc * alpha
            acc = tl.dot_t3(p, v_buf, acc, OFFSET=par * (BN * HD))
            tl.barrier()
            v_next = tl.where(k0 + 2 * BN < hi2, k0 + 2 * BN, last0)
            tok = tl.async_copy(
                v_buf,
                v_ptr + base + (v_next + offs_n)[:, None] * HD +
                offs_d[None, :], EVEN=True, OFFSET=par * (BN * HD))
        tl.async_wait(tok, 0)
    else:
        k_buf = tl.smem((HD, BN), tl.float32)
        v_buf = tl.smem((BN, HD), tl.float32)
        for k0 in range(0, hi2, BN):
            offs_kv = k0 + offs_n
            kv_ok = (offs_kv < T)[:, None]
            t1 = tl.async_copy(
                k_buf,
                kt_ptr + base + offs_kv[:, None] * HD + offs_d[None, :],
                TRANS=True, MASK=kv_ok)
            t2 = tl.async_copy(
                v_buf,
                v_ptr + base + offs_kv[:, None] * HD + offs_d[None, :],
                MASK=kv_ok)
            tl.async_wait(t2, 0)
            tl.barrier()
            q_row = tl.load(q_pt, LAYOUT=lay_r, mask=(offs_m < T)[:, None])
            s = tl.dot_t3(q_row, k_buf)
            s = s * scale
            masked = k0 >= q0
            if masked:
                s = tl.where((row_i >= tl.materialize(offs_kv))
                             & (tl.materialize(offs_kv) < T), s, -1e9)
            mn = tl.maximum(m, tl.max(s, axis=1))
            alpha = tl.exp(m - mn)
            p = tl.exp(s - mn)
            l = l * alpha + tl.sum(p, axis=1)
            m = mn
            acc = acc * alpha
            acc = tl.dot_t3(p, v_buf, acc)
            tl.barrier()
    o = acc / l
    tl.store(o_pt, o, mask=(offs_m < T)[:, None])
    lse = m + tl.log(l)
    tl.store(lse_ptr + bh * T + offs_m[:, None], lse,
             mask=(offs_m < T)[:, None])


def launch_flash_attention(q, k, v, out, lse, scale: float,
                           num_warps: int = 4, tm: int = 1):
    """q/k/v: (BH, T, HD) contiguous, natural layout (no pre-transpose);
    lse: (BH, T) f32 output (per-row log-sum-exp of scaled scores).

    Constraints: f32, HD == 64, tm == 1; BM = 32 * num_warps rows per
    program."""
    BH, T, HD = q.shape
    if HD != 64:
        raise NotImplementedError(
            f"flash attention currently supports head dim 64, got {HD}")
    BM, BN = 32 * num_warps * tm, 64
    grid = ((T + BM - 1) // BM, BH)
    if tm != 1:
        raise NotImplementedError(
            "flash attention fwd DSL currently supports tm == 1")
    flash_attention_fwd_f32_dsl_kernel[grid](
        q._buffer_arg(), k._buffer_arg(), v._buffer_arg(),
        out._buffer_arg(), lse._buffer_arg(), T, scale,
        HD=HD, BM=BM, BN=BN, EVEN_T=T % BN == 0, num_warps=num_warps)


# ---------------------------------------------------------------------------
# flash attention forward, tensor-core mma: tf32 / bf16 tiers.
# Pure-DSL kernel over tl.mma + the general scheduling constructs (warp-
# slab mapping: each warp owns a (BM/warps, 64) slab of S/P/O in its mma C
# fragment; online softmax is warp-local via width-4 butterflies; the P->A
# fragment conversion is register-only). kt is passed as the (HD, BN)
# transpose VIEW (unit row stride) — no eager pre-transpose, same as the
# fp32 kernel.

# ---------------------------------------------------------------------------

@tl.kernel
def flash_attention_fwd_mma_qkv_dsl_kernel(qkv_ptr, o_ptr, lse_ptr, T,
                                           scale, H: tl.constexpr,
                                           C: tl.constexpr, HD: tl.constexpr,
                                           BM: tl.constexpr, BN: tl.constexpr,
                                           ATOM: tl.constexpr,
                                           EVEN_T: tl.constexpr):
    """Causal flash forward, mma tier, on the packed layouts, pure DSL:
    the (B, T, 3C)/(B, T, C) address algebra over the same constructs as
    flash_attention_fwd_mma_dsl_kernel (bit-equal)."""
    pid_m = (T + BM - 1) // BM - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    q0 = pid_m * BM
    offs_m = q0 + tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_d = tl.arange(0, HD)
    base3 = b * (T * (3 * C)) + h * HD
    baseo = b * (T * C) + h * HD
    q_pt = qkv_ptr + base3 + offs_m[:, None] * (3 * C) + offs_d[None, :]
    o_pt = o_ptr + baseo + offs_m[:, None] * C + offs_d[None, :]
    lay_a = tl.mma_layout("A", (BM, HD), ATOM)
    lay_c = tl.mma_layout("C", (BM, BN), ATOM)
    lay_co = tl.mma_layout("C", (BM, HD), ATOM)
    lay_as = tl.mma_layout("A", (BM, BN), ATOM)
    lay_s1 = tl.sliced(lay_c, 1)
    q_fr = tl.load(q_pt, LAYOUT=lay_a, mask=(offs_m < T)[:, None])
    rowsf = tl.materialize(offs_m[:, None], LAYOUT=lay_c)
    acc = tl.zeros((BM, HD), tl.float32, LAYOUT=lay_co)
    m = tl.zeros((BM, 1), tl.float32, LAYOUT=lay_s1) - float("inf")
    l = tl.zeros((BM, 1), tl.float32, LAYOUT=lay_s1)
    ceil_t = ((T + BN - 1) // BN) * BN
    hi1b = q0 + BM
    hi2 = tl.where(hi1b < ceil_t, hi1b, ceil_t)
    if ATOM == "bf16":
        elem = tl.bfloat16
    else:
        elem = tl.float32
    if EVEN_T:
        k_pipe = tl.stage_pipe((BN, HD), elem, TRANS=True, EVEN=True)
        v_pipe = tl.stage_pipe((2 * BN, HD), elem, EVEN=True)
        last0 = ((hi2 - 1) // BN) * BN
        k0n = tl.where(BN < hi2, BN, last0)
        tk = tl.async_stage(
            k_pipe, qkv_ptr + base3 + C + offs_d[:, None] +
            offs_n[None, :] * (3 * C))
        tv0 = tl.async_stage(
            v_pipe, qkv_ptr + base3 + 2 * C + offs_n[:, None] * (3 * C) +
            offs_d[None, :])
        tv1 = tl.async_stage(
            v_pipe, qkv_ptr + base3 + 2 * C + (k0n + offs_n)[:, None] *
            (3 * C) + offs_d[None, :],
            OFFSET=(k0n // BN % 2) * (BN * HD))
        for k0 in range(0, hi2, BN):
            par = k0 // BN % 2
            s = tl.mma(q_fr, tk, PENDING=1)
            k_next = tl.where(k0 + BN < hi2, k0 + BN, last0)
            tk = tl.async_stage(
                k_pipe, qkv_ptr + base3 + C + offs_d[:, None] +
                (k_next + offs_n)[None, :] * (3 * C))
            s = s * scale
            masked = k0 + BN > q0
            if masked:
                s = tl.where(
                    (rowsf >= tl.materialize((k0 + offs_n)[None, :],
                                             LAYOUT=lay_c))
                    & (tl.materialize((k0 + offs_n)[None, :],
                                      LAYOUT=lay_c) < T),
                    s, -1e9)
            mn = tl.maximum(m, tl.max(s, axis=1))
            alpha = tl.exp(m - mn)
            p = tl.exp(s - mn)
            l = l * alpha + tl.sum(p, axis=1)
            m = mn
            acc = acc * alpha
            pa = tl.convert_layout(p, lay_as)
            v_next = tl.where(k0 + 2 * BN < hi2, k0 + 2 * BN, last0)
            if par == 0:
                acc = tl.mma(pa, tv0, acc, PENDING=2)
                tv0 = tl.async_stage(
                    v_pipe, qkv_ptr + base3 + 2 * C +
                    (v_next + offs_n)[:, None] * (3 * C) + offs_d[None, :],
                    OFFSET=par * (BN * HD))
            else:
                acc = tl.mma(pa, tv1, acc, PENDING=2)
                tv1 = tl.async_stage(
                    v_pipe, qkv_ptr + base3 + 2 * C +
                    (v_next + offs_n)[:, None] * (3 * C) + offs_d[None, :],
                    OFFSET=par * (BN * HD))
        tl.async_wait(tv0, 0)
    else:
        kr_pipe = tl.stage_pipe((BN, HD), elem, TRANS=True)
        vr_pipe = tl.stage_pipe((BN, HD), elem)
        for k0 in range(0, hi2, BN):
            offs_kv = k0 + offs_n
            t1 = tl.async_stage(
                kr_pipe, qkv_ptr + base3 + C + offs_d[:, None] +
                offs_kv[None, :] * (3 * C), MASK=(offs_kv < T)[None, :])
            t2 = tl.async_stage(
                vr_pipe, qkv_ptr + base3 + 2 * C + offs_kv[:, None] *
                (3 * C) + offs_d[None, :], MASK=(offs_kv < T)[:, None])
            tl.async_wait(t2, 0)
            tl.barrier()
            s = tl.mma(q_fr, t1, PENDING=0)
            s = s * scale
            masked = k0 + BN > q0
            if masked:
                s = tl.where(
                    (rowsf >= tl.materialize(offs_kv[None, :],
                                             LAYOUT=lay_c))
                    & (tl.materialize(offs_kv[None, :],
                                      LAYOUT=lay_c) < T),
                    s, -1e9)
            mn = tl.maximum(m, tl.max(s, axis=1))
            alpha = tl.exp(m - mn)
            p = tl.exp(s - mn)
            l = l * alpha + tl.sum(p, axis=1)
            m = mn
            acc = acc * alpha
            pa = tl.convert_layout(p, lay_as)
            acc = tl.mma(pa, t2, acc, PENDING=0)
            tl.barrier()
    o = acc / l
    tl.store(o_pt, o, mask=(offs_m < T)[:, None])
    lse = m + tl.log(l)
    tl.store(lse_ptr + bh * T + offs_m[:, None], lse,
             mask=(offs_m < T)[:, None])


@tl.kernel
def flash_attention_fwd_mma_dsl_kernel(q_ptr, kt_ptr, v_ptr, o_ptr, lse_ptr,
                                       T, scale, HD: tl.constexpr,
                                       BM: tl.constexpr, BN: tl.constexpr,
                                       ATOM: tl.constexpr,
                                       EVEN_T: tl.constexpr):
    """Causal flash-attention forward, tensor-core mma tier (tf32/bf16),
    pure DSL: warp-slab
    mapping (warp wy owns a (BM/warps, 64) slab of S/P/O in its mma C
    fragment), Q A fragments held loop-invariant, S = Q.Kᵀ via tl.mma
    against the trans-staged K pipe, online softmax warp-local
    (tl.max/tl.sum on the fragment -> narrow Sliced stats), P -> A via
    convert_layout, acc = acc.alpha + P.V via tl.mma against the parity
    double-buffered V halves (async_stage OFFSET). Bit-equal by
    construction (same mma orders, same butterfly reductions, same
    ex2/pack forms)."""
    pid_m = (T + BM - 1) // BM - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    q0 = pid_m * BM
    offs_m = q0 + tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_d = tl.arange(0, HD)
    base = bh * (T * HD)
    q_pt = q_ptr + base + offs_m[:, None] * HD + offs_d[None, :]
    o_pt = o_ptr + base + offs_m[:, None] * HD + offs_d[None, :]
    lay_a = tl.mma_layout("A", (BM, HD), ATOM)
    lay_c = tl.mma_layout("C", (BM, BN), ATOM)
    lay_co = tl.mma_layout("C", (BM, HD), ATOM)
    lay_as = tl.mma_layout("A", (BM, BN), ATOM)
    lay_s1 = tl.sliced(lay_c, 1)
    q_fr = tl.load(q_pt, LAYOUT=lay_a, mask=(offs_m < T)[:, None])
    rowsf = tl.materialize(offs_m[:, None], LAYOUT=lay_c)
    acc = tl.zeros((BM, HD), tl.float32, LAYOUT=lay_co)
    m = tl.zeros((BM, 1), tl.float32, LAYOUT=lay_s1) - float("inf")
    l = tl.zeros((BM, 1), tl.float32, LAYOUT=lay_s1)
    ceil_t = ((T + BN - 1) // BN) * BN
    hi1b = q0 + BM
    hi2 = tl.where(hi1b < ceil_t, hi1b, ceil_t)
    if ATOM == "bf16":
        elem = tl.bfloat16
    else:
        elem = tl.float32
    if EVEN_T:
        # the intrinsic's schedule: single-buffered K, parity V — one
        # wait per dot, k[t+1] behind the softmax, v[t+2] into the
        # OFFSET half the dot just vacated
        k_pipe = tl.stage_pipe((BN, HD), elem, TRANS=True, EVEN=True)
        v_pipe = tl.stage_pipe((2 * BN, HD), elem, EVEN=True)
        last0 = ((hi2 - 1) // BN) * BN
        k0n = tl.where(BN < hi2, BN, last0)
        tk = tl.async_stage(
            k_pipe, kt_ptr + base + offs_d[:, None] +
            offs_n[None, :] * HD)
        tv0 = tl.async_stage(
            v_pipe, v_ptr + base + offs_n[:, None] * HD + offs_d[None, :])
        tv1 = tl.async_stage(
            v_pipe, v_ptr + base + (k0n + offs_n)[:, None] * HD +
            offs_d[None, :], OFFSET=(k0n // BN % 2) * (BN * HD))
        for k0 in range(0, hi2, BN):
            par = k0 // BN % 2
            s = tl.mma(q_fr, tk, PENDING=1)
            k_next = tl.where(k0 + BN < hi2, k0 + BN, last0)
            tk = tl.async_stage(
                k_pipe, kt_ptr + base + offs_d[:, None] +
                (k_next + offs_n)[None, :] * HD)
            s = s * scale
            masked = k0 + BN > q0
            if masked:
                s = tl.where(
                    (rowsf >= tl.materialize((k0 + offs_n)[None, :],
                                             LAYOUT=lay_c))
                    & (tl.materialize((k0 + offs_n)[None, :],
                                      LAYOUT=lay_c) < T),
                    s, -1e9)
            mn = tl.maximum(m, tl.max(s, axis=1))
            alpha = tl.exp(m - mn)
            p = tl.exp(s - mn)
            l = l * alpha + tl.sum(p, axis=1)
            m = mn
            acc = acc * alpha
            pa = tl.convert_layout(p, lay_as)
            v_next = tl.where(k0 + 2 * BN < hi2, k0 + 2 * BN, last0)
            if par == 0:
                acc = tl.mma(pa, tv0, acc, PENDING=2)
                tv0 = tl.async_stage(
                    v_pipe,
                    v_ptr + base + (v_next + offs_n)[:, None] * HD +
                    offs_d[None, :], OFFSET=par * (BN * HD))
            else:
                acc = tl.mma(pa, tv1, acc, PENDING=2)
                tv1 = tl.async_stage(
                    v_pipe,
                    v_ptr + base + (v_next + offs_n)[:, None] * HD +
                    offs_d[None, :], OFFSET=BN * HD)
        tl.async_wait(tv0, 0)
    else:
        kr_pipe = tl.stage_pipe((BN, HD), elem, TRANS=True)
        vr_pipe = tl.stage_pipe((BN, HD), elem)
        for k0 in range(0, hi2, BN):
            offs_kv = k0 + offs_n
            t1 = tl.async_stage(
                kr_pipe, kt_ptr + base + offs_d[:, None] +
                offs_kv[None, :] * HD, MASK=(offs_kv < T)[None, :])
            t2 = tl.async_stage(
                vr_pipe, v_ptr + base + offs_kv[:, None] * HD +
                offs_d[None, :], MASK=(offs_kv < T)[:, None])
            tl.async_wait(t2, 0)
            tl.barrier()
            s = tl.mma(q_fr, t1, PENDING=0)
            s = s * scale
            masked = k0 + BN > q0
            if masked:
                s = tl.where(
                    (rowsf >= tl.materialize(offs_kv[None, :],
                                             LAYOUT=lay_c))
                    & (tl.materialize(offs_kv[None, :],
                                      LAYOUT=lay_c) < T),
                    s, -1e9)
            mn = tl.maximum(m, tl.max(s, axis=1))
            alpha = tl.exp(m - mn)
            p = tl.exp(s - mn)
            l = l * alpha + tl.sum(p, axis=1)
            m = mn
            acc = acc * alpha
            pa = tl.convert_layout(p, lay_as)
            acc = tl.mma(pa, t2, acc, PENDING=0)
            tl.barrier()
    o = acc / l
    tl.store(o_pt, o, mask=(offs_m < T)[:, None])
    lse = m + tl.log(l)
    tl.store(lse_ptr + bh * T + offs_m[:, None], lse,
             mask=(offs_m < T)[:, None])


def launch_flash_attention_mma(q, k, v, out, lse, scale: float,
                               atom: str = "tf32", num_warps: int = 4):
    """q/k/v: (BH, T, HD) contiguous, natural layout (no pre-transpose);
    out: like q (f32 for the tf32 tier, bf16 for bf16); lse: (BH, T) f32.

    Constraints: HD == 64; BM = 16 * num_warps rows per program (one
    16-row mma slab per warp)."""
    BH, T, HD = q.shape
    if HD != 64:
        raise NotImplementedError(
            f"flash attention mma currently supports head dim 64, got {HD}")
    BM, BN = 16 * num_warps, 64
    grid = ((T + BM - 1) // BM, BH)
    flash_attention_fwd_mma_dsl_kernel[grid](
        q._buffer_arg(), k._buffer_arg(), v._buffer_arg(),
        out._buffer_arg(), lse._buffer_arg(), T, scale,
        HD=HD, BM=BM, BN=BN, ATOM=atom, EVEN_T=T % BN == 0,
        num_warps=num_warps)


# ---------------------------------------------------------------------------
# qkv-packed strided flash variants (bf16 tier): the kernels read q/k/v
# straight from the projection's (B, T, 3C) output buffer (column offsets
# 0 / C / 2C, row stride 3C) and write the attention output in (B, T, C)
# layout — the head-split/merge materializations and the split-backward
# cat all disappear from the train step. Same builder entry points, same
# numerics; only the address algebra changes (strides are constexpr so
# the staging keeps its 16B alignment proofs).
# ---------------------------------------------------------------------------

def launch_flash_attention_mma_qkv(qkv, out, lse, H: int, scale: float,
                                   atom: str = "bf16", num_warps: int = 4):
    """qkv: (B, T, 3C) bf16 projection output; out: (B, T, C); lse:
    (B*H, T) f32. Same contract as launch_flash_attention_mma otherwise."""
    B, T, C3 = qkv.shape
    C = C3 // 3
    HD = C // H
    if HD != 64:
        raise NotImplementedError(
            f"flash attention mma qkv currently supports head dim 64, got {HD}")
    BM, BN = 16 * num_warps, 64
    grid = ((T + BM - 1) // BM, B * H)
    return flash_attention_fwd_mma_qkv_dsl_kernel[grid](
        qkv._buffer_arg(), out._buffer_arg(), lse._buffer_arg(), T, scale,
        H=H, C=C, HD=HD, BM=BM, BN=BN, ATOM=atom, EVEN_T=T % BN == 0,
        num_warps=num_warps)



# ---------------------------------------------------------------------------
# flash attention backward: fused delta/dQ/dV/dK kernels, all
# t3 row-per-thread like the forward (Builder.flash_attention_bwd_*).
# ---------------------------------------------------------------------------

@tl.kernel
def flash_bwd_delta_kernel(do_ptr, o_ptr, delta_ptr,
                           HD: tl.constexpr, BLOCK: tl.constexpr):
    """delta[row] = sum(do[row, :] * o[row, :]) over (BH*T) rows."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < HD
    do = tl.load(do_ptr + row * HD + offs, mask=m, other=0.0)
    o = tl.load(o_ptr + row * HD + offs, mask=m, other=0.0)
    tl.store(delta_ptr + row, tl.sum(do * o))


def launch_flash_bwd_delta(do, o, delta, HD: int = 64):
    R = do.numel() // HD
    flash_bwd_delta_kernel[(R,)](do._buffer_arg(), o._buffer_arg(),
                                 delta._buffer_arg(), HD=HD, BLOCK=128,
                                 num_warps=4)


@tl.kernel
def flash_bwd_dq_f32_dsl_kernel(q_ptr, kt_ptr, vt_ptr, do_ptr, lse_ptr,
                                delta_ptr, dq_ptr, T, scale,
                                HD: tl.constexpr, BM: tl.constexpr,
                                BN: tl.constexpr, EVEN_T: tl.constexpr):
    """fp32 dQ for one BM == num_threads q-row block, t3 row-per-thread,
    pure DSL:
    thread tid owns q row q0+tid in registers and loops kv tiles —
    s = q·Kᵀ and dp = dO·Vᵀ as dot_t3 against TRANS-staged smem tiles,
    p = exp(s·scale − lse_i), ds = p∘(dp − delta_i), acc += ds @
    natural-staged K. Bit-equal by construction (same ascending-k FMA
    chains, same ex2 form, same guarded IO)."""
    pid_m = (T + BM - 1) // BM - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    q0 = pid_m * BM
    offs_m = q0 + tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_d = tl.arange(0, HD)
    base = bh * (T * HD)
    q_pt = q_ptr + base + offs_m[:, None] * HD + offs_d[None, :]
    do_pt = do_ptr + base + offs_m[:, None] * HD + offs_d[None, :]
    dq_pt = dq_ptr + base + offs_m[:, None] * HD + offs_d[None, :]
    lay_r = tl.t3_layout((BM, HD))
    lay_1 = tl.t3_layout((BM, 1))
    q_row = tl.load(q_pt, LAYOUT=lay_r, mask=(offs_m < T)[:, None])
    do_row = tl.load(do_pt, LAYOUT=lay_r, mask=(offs_m < T)[:, None])
    lse_i = tl.load(lse_ptr + bh * T + offs_m[:, None], LAYOUT=lay_1,
                    mask=(offs_m < T)[:, None])
    delta_i = tl.load(delta_ptr + bh * T + offs_m[:, None], LAYOUT=lay_1,
                      mask=(offs_m < T)[:, None])
    row_i = tl.materialize(offs_m[:, None], LAYOUT=lay_1)
    acc = tl.zeros((BM, HD), tl.float32, LAYOUT=lay_r)
    ceil_t = ((T + BN - 1) // BN) * BN
    hi1b = q0 + BM
    hi2 = tl.where(hi1b < ceil_t, hi1b, ceil_t)
    if EVEN_T:
        kt_buf = tl.smem((HD, BN), tl.float32)
        vt_buf = tl.smem((HD, BN), tl.float32)
        kn_buf = tl.smem((BN, HD), tl.float32)
        for k0 in tl.pipelined(range(0, hi2, BN), stages=2):
            s = tl.dot_t3(q_row, p_kt)
            p_kt = tl.stage(
                kt_buf,
                kt_ptr + base + (k0 + offs_n)[:, None] * HD + offs_d[None, :],
                TRANS=True)
            dp = tl.dot_t3(do_row, p_vt)
            p_vt = tl.stage(
                vt_buf,
                vt_ptr + base + (k0 + offs_n)[:, None] * HD + offs_d[None, :],
                TRANS=True)
            m = s * scale
            masked = k0 >= q0
            cols = tl.materialize(k0 + offs_n)
            keep = (row_i >= cols) & (cols < T)
            if masked:
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_i)
            ds = p * (dp - delta_i)
            acc = tl.dot_t3(ds, p_kn, acc)
            p_kn = tl.stage(
                kn_buf,
                kt_ptr + base + (k0 + offs_n)[:, None] * HD + offs_d[None, :],
                EVEN=True)
    else:
        kt_buf = tl.smem((HD, BN), tl.float32)
        vt_buf = tl.smem((HD, BN), tl.float32)
        kn_buf = tl.smem((BN, HD), tl.float32)
        for k0 in range(0, hi2, BN):
            offs_kv = k0 + offs_n
            kv_ok = (offs_kv < T)[:, None]
            t1 = tl.async_copy(
                kt_buf,
                kt_ptr + base + offs_kv[:, None] * HD + offs_d[None, :],
                TRANS=True, MASK=kv_ok)
            t2 = tl.async_copy(
                vt_buf,
                vt_ptr + base + offs_kv[:, None] * HD + offs_d[None, :],
                TRANS=True, MASK=kv_ok)
            t3 = tl.async_copy(
                kn_buf,
                kt_ptr + base + offs_kv[:, None] * HD + offs_d[None, :],
                MASK=kv_ok)
            tl.async_wait(t3, 0)
            tl.barrier()
            s = tl.dot_t3(q_row, kt_buf)
            dp = tl.dot_t3(do_row, vt_buf)
            m = s * scale
            masked = k0 >= q0
            cols = tl.materialize(offs_kv)
            keep = (row_i >= cols) & (cols < T)
            if masked:
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_i)
            ds = p * (dp - delta_i)
            acc = tl.dot_t3(ds, kn_buf, acc)
            tl.barrier()
    tl.store(dq_pt, acc * scale, mask=(offs_m < T)[:, None])


@tl.kernel
def flash_bwd_dkv_f32_dsl_kernel(k_ptr, v_ptr, qt_ptr, do_ptr,
                                 lse_ptr, delta_ptr, dv_ptr, dk_ptr, T,
                                 scale, HD: tl.constexpr, BNK: tl.constexpr,
                                 BNI: tl.constexpr, EVEN_T: tl.constexpr):
    """fp32 fused dV+dK for one BNK == num_threads kv-row block, t3
    row-per-thread, pure DSL: one q-tile pass per kv block — Sᵀ/dPᵀ as
    dot_t3 against TRANS-staged Q/dO, pT = exp(sT·scale − lse_i),
    dV += pT @ dO and dK += dsT @ Q against natural-staged tiles, sharing
    the qt stage / Sᵀ dot / exp / stat loads (the fp32 twin of the bf16
    fused-dkv win; bit-equal vs the split kernels by construction)."""
    pid_n = (T + BNK - 1) // BNK - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    k0 = pid_n * BNK
    offs_kv = k0 + tl.arange(0, BNK)
    offs_i = tl.arange(0, BNI)
    offs_d = tl.arange(0, HD)
    base = bh * (T * HD)
    k_pt = k_ptr + base + offs_kv[:, None] * HD + offs_d[None, :]
    v_pt = v_ptr + base + offs_kv[:, None] * HD + offs_d[None, :]
    dv_pt = dv_ptr + base + offs_kv[:, None] * HD + offs_d[None, :]
    dk_pt = dk_ptr + base + offs_kv[:, None] * HD + offs_d[None, :]
    lay_r = tl.t3_layout((BNK, HD))
    lay_1 = tl.t3_layout((BNK, 1))
    k_row = tl.load(k_pt, LAYOUT=lay_r, mask=(offs_kv < T)[:, None])
    v_row = tl.load(v_pt, LAYOUT=lay_r, mask=(offs_kv < T)[:, None])
    row_j = tl.materialize(offs_kv[:, None], LAYOUT=lay_1)
    accv = tl.zeros((BNK, HD), tl.float32, LAYOUT=lay_r)
    acck = tl.zeros((BNK, HD), tl.float32, LAYOUT=lay_r)
    ceil_t = ((T + BNI - 1) // BNI) * BNI
    if EVEN_T:
        # 3 x 16KB buffers == the 48KB static budget exactly: dpT reads
        # the natural dO tile strided (TRANS_B) instead of staging a
        # fourth transposed dO tile
        qt_buf = tl.smem((HD, BNI), tl.float32)
        don_buf = tl.smem((BNI, HD), tl.float32)
        qn_buf = tl.smem((BNI, HD), tl.float32)
        cols0 = tl.materialize(offs_i)
        keep = cols0 >= row_j  # typed pre-def; the real mask is per-tile
        for i0 in tl.pipelined(range(k0, ceil_t, BNI), stages=2):
            sT = tl.dot_t3(k_row, p_qt)
            p_qt = tl.stage(
                qt_buf,
                qt_ptr + base + (i0 + offs_i)[:, None] * HD + offs_d[None, :],
                TRANS=True)
            dpT = tl.dot_t3(v_row, p_don, TRANS_B=True)
            offs_iq = i0 + offs_i
            lse_b = tl.load(lse_ptr + bh * T + offs_iq,
                            mask=(offs_iq < T), other=0.0)
            delta_b = tl.load(delta_ptr + bh * T + offs_iq,
                              mask=(offs_iq < T), other=0.0)
            cols = tl.materialize(offs_iq)
            m = sT * scale
            masked = (i0 < k0 + BNK) | (i0 + BNI > T)
            if masked:
                keep = (cols >= row_j) & (cols < T)
                m = tl.where(keep, m, -1e9)
            pT = tl.exp(m - lse_b)
            dsT = pT * (dpT - delta_b)
            accv = tl.dot_t3(pT, p_don, accv)
            p_don = tl.stage(
                don_buf,
                do_ptr + base + (i0 + offs_i)[:, None] * HD + offs_d[None, :],
                EVEN=True)
            acck = tl.dot_t3(dsT, p_qn, acck)
            p_qn = tl.stage(
                qn_buf,
                qt_ptr + base + (i0 + offs_i)[:, None] * HD + offs_d[None, :],
                EVEN=True)
    else:
        qt_buf = tl.smem((HD, BNI), tl.float32)
        don_buf = tl.smem((BNI, HD), tl.float32)
        qn_buf = tl.smem((BNI, HD), tl.float32)
        cols0 = tl.materialize(offs_i)
        keep = cols0 >= row_j
        for i0 in range(k0, ceil_t, BNI):
            offs_iq = i0 + offs_i
            q_ok = (offs_iq < T)[:, None]
            t1 = tl.async_copy(
                qt_buf,
                qt_ptr + base + offs_iq[:, None] * HD + offs_d[None, :],
                TRANS=True, MASK=q_ok)
            t3 = tl.async_copy(
                don_buf,
                do_ptr + base + offs_iq[:, None] * HD + offs_d[None, :],
                MASK=q_ok)
            t4 = tl.async_copy(
                qn_buf,
                qt_ptr + base + offs_iq[:, None] * HD + offs_d[None, :],
                MASK=q_ok)
            tl.async_wait(t4, 0)
            tl.barrier()
            sT = tl.dot_t3(k_row, qt_buf)
            dpT = tl.dot_t3(v_row, don_buf, TRANS_B=True)
            lse_b = tl.load(lse_ptr + bh * T + offs_iq,
                            mask=(offs_iq < T), other=0.0)
            delta_b = tl.load(delta_ptr + bh * T + offs_iq,
                              mask=(offs_iq < T), other=0.0)
            cols = tl.materialize(offs_iq)
            m = sT * scale
            masked = (i0 < k0 + BNK) | (i0 + BNI > T)
            if masked:
                keep = (cols >= row_j) & (cols < T)
                m = tl.where(keep, m, -1e9)
            pT = tl.exp(m - lse_b)
            dsT = pT * (dpT - delta_b)
            accv = tl.dot_t3(pT, don_buf, accv)
            acck = tl.dot_t3(dsT, qn_buf, acck)
            tl.barrier()
    tl.store(dv_pt, accv, mask=(offs_kv < T)[:, None])
    tl.store(dk_pt, acck * scale, mask=(offs_kv < T)[:, None])


def launch_flash_attention_bwd(q, k, v, o, do, lse, delta, dq, dk, dv,
                               scale: float, num_warps: int = 4):
    """Fused flash backward (pure-DSL fp32 route). q/k/v/o/do (BH, T, HD)
    contiguous natural layout; lse/delta (BH, T) f32; dq/dk/dv
    preallocated like q. Three launches: delta, dQ, fused dV+dK."""
    BH, T, HD = q.shape
    if HD != 64:
        raise NotImplementedError(
            f"flash attention bwd currently supports head dim 64, got {HD}")
    launch_flash_bwd_delta(do, o, delta, HD)
    BM, BN = 32 * num_warps, 64
    flash_bwd_dq_f32_dsl_kernel[((T + BM - 1) // BM, BH)](
        q._buffer_arg(), k._buffer_arg(), v._buffer_arg(), do._buffer_arg(),
        lse._buffer_arg(), delta._buffer_arg(), dq._buffer_arg(), T, scale,
        HD=HD, BM=BM, BN=BN, EVEN_T=T % BN == 0, num_warps=num_warps)
    BNK = 32 * num_warps
    grid_kv = ((T + BNK - 1) // BNK, BH)
    flash_bwd_dkv_f32_dsl_kernel[grid_kv](
        k._buffer_arg(), v._buffer_arg(), q._buffer_arg(),
        do._buffer_arg(), lse._buffer_arg(), delta._buffer_arg(),
        dv._buffer_arg(), dk._buffer_arg(), T, scale,
        HD=HD, BNK=BNK, BNI=64, EVEN_T=T % 64 == 0, num_warps=num_warps)


# ---------------------------------------------------------------------------
# qkv-packed strided flash variants (fp32 tier): same address-algebra
# change as the bf16 qkv variants — q/k/v read straight from the (B, T,
# 3C) projection buffer, output/dqkv written in (B, T, C) / (B, T, 3C)
# layouts. Same FMA builder entry points, bit-identical numerics.
# ---------------------------------------------------------------------------

def launch_flash_attention_qkv(qkv, out, lse, H: int, scale: float,
                               num_warps: int = 4, tm: int = 1):
    """qkv: (B, T, 3C) f32 projection output; out: (B, T, C) f32; lse:
    (B*H, T) f32. Same contract as launch_flash_attention otherwise."""
    B, T, C3 = qkv.shape
    C = C3 // 3
    HD = C // H
    if HD != 64:
        raise NotImplementedError(
            f"flash attention qkv currently supports head dim 64, got {HD}")
    BM, BN = 32 * num_warps * tm, 64
    grid = ((T + BM - 1) // BM, B * H)
    if tm != 1:
        raise NotImplementedError(
            "flash attention qkv DSL currently supports tm == 1")
    return flash_attention_fwd_f32_qkv_dsl_kernel[grid](
        qkv._buffer_arg(), out._buffer_arg(), lse._buffer_arg(), T, scale,
        H=H, C=C, HD=HD, BM=BM, BN=BN, EVEN_T=T % BN == 0,
        num_warps=num_warps)


@tl.kernel
def flash_bwd_delta_qkv_rows_kernel(do_ptr, o_ptr, delta_ptr, T,
                                    H: tl.constexpr, C: tl.constexpr,
                                    HD: tl.constexpr, RPB: tl.constexpr):
    """delta[row] = sum(do[row, :] * o[row, :]) for RPB consecutive rows;
    do/o rows live in (B, T, C) f32 buffers (grid (T/RPB, BH))."""
    pid = tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    rows = pid * RPB + tl.arange(0, RPB)
    offs = b * (T * C) + h * HD + rows[:, None] * C + \
        tl.arange(0, HD)[None, :]
    do32 = tl.load(do_ptr + offs)
    o32 = tl.load(o_ptr + offs)
    d = tl.sum(do32 * o32, axis=1)
    tl.store(delta_ptr + (bh * T + rows)[:, None] +
             tl.arange(0, 1)[None, :], d)


@tl.kernel
def flash_bwd_dq_f32_qkv_dsl_kernel(qkv_ptr, do_ptr, lse_ptr, delta_ptr,
                                    dqkv_ptr, T, scale, H: tl.constexpr,
                                    C: tl.constexpr, HD: tl.constexpr,
                                    BM: tl.constexpr, BN: tl.constexpr,
                                    EVEN_T: tl.constexpr):
    """fp32 dQ on the packed layouts, pure DSL: the (B, T, 3C)/(B, T, C)
    address algebra over the same constructs as
    flash_bwd_dq_f32_dsl_kernel (bit-equal)."""
    pid_m = (T + BM - 1) // BM - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    q0 = pid_m * BM
    offs_m = q0 + tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_d = tl.arange(0, HD)
    base3 = b * (T * (3 * C)) + h * HD
    baseo = b * (T * C) + h * HD
    q_pt = qkv_ptr + base3 + offs_m[:, None] * (3 * C) + offs_d[None, :]
    do_pt = do_ptr + baseo + offs_m[:, None] * C + offs_d[None, :]
    dq_pt = dqkv_ptr + base3 + offs_m[:, None] * (3 * C) + offs_d[None, :]
    lay_r = tl.t3_layout((BM, HD))
    lay_1 = tl.t3_layout((BM, 1))
    q_row = tl.load(q_pt, LAYOUT=lay_r, mask=(offs_m < T)[:, None])
    do_row = tl.load(do_pt, LAYOUT=lay_r, mask=(offs_m < T)[:, None])
    lse_i = tl.load(lse_ptr + bh * T + offs_m[:, None], LAYOUT=lay_1,
                    mask=(offs_m < T)[:, None])
    delta_i = tl.load(delta_ptr + bh * T + offs_m[:, None], LAYOUT=lay_1,
                      mask=(offs_m < T)[:, None])
    row_i = tl.materialize(offs_m[:, None], LAYOUT=lay_1)
    acc = tl.zeros((BM, HD), tl.float32, LAYOUT=lay_r)
    ceil_t = ((T + BN - 1) // BN) * BN
    hi1b = q0 + BM
    hi2 = tl.where(hi1b < ceil_t, hi1b, ceil_t)
    if EVEN_T:
        kt_buf = tl.smem((HD, BN), tl.float32)
        vt_buf = tl.smem((HD, BN), tl.float32)
        kn_buf = tl.smem((BN, HD), tl.float32)
        for k0 in tl.pipelined(range(0, hi2, BN), stages=2):
            s = tl.dot_t3(q_row, p_kt)
            p_kt = tl.stage(
                kt_buf, qkv_ptr + base3 + C + (k0 + offs_n)[:, None] *
                (3 * C) + offs_d[None, :], TRANS=True)
            dp = tl.dot_t3(do_row, p_vt)
            p_vt = tl.stage(
                vt_buf, qkv_ptr + base3 + 2 * C + (k0 + offs_n)[:, None] *
                (3 * C) + offs_d[None, :], TRANS=True)
            m = s * scale
            masked = k0 >= q0
            cols = tl.materialize(k0 + offs_n)
            keep = (row_i >= cols) & (cols < T)
            if masked:
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_i)
            ds = p * (dp - delta_i)
            acc = tl.dot_t3(ds, p_kn, acc)
            p_kn = tl.stage(
                kn_buf, qkv_ptr + base3 + C + (k0 + offs_n)[:, None] *
                (3 * C) + offs_d[None, :], EVEN=True)
    else:
        kt_buf = tl.smem((HD, BN), tl.float32)
        vt_buf = tl.smem((HD, BN), tl.float32)
        kn_buf = tl.smem((BN, HD), tl.float32)
        for k0 in range(0, hi2, BN):
            offs_kv = k0 + offs_n
            kv_ok = (offs_kv < T)[:, None]
            t1 = tl.async_copy(
                kt_buf, qkv_ptr + base3 + C + offs_kv[:, None] * (3 * C) +
                offs_d[None, :], TRANS=True, MASK=kv_ok)
            t2 = tl.async_copy(
                vt_buf, qkv_ptr + base3 + 2 * C + offs_kv[:, None] *
                (3 * C) + offs_d[None, :], TRANS=True, MASK=kv_ok)
            t3 = tl.async_copy(
                kn_buf, qkv_ptr + base3 + C + offs_kv[:, None] * (3 * C) +
                offs_d[None, :], MASK=kv_ok)
            tl.async_wait(t3, 0)
            tl.barrier()
            s = tl.dot_t3(q_row, kt_buf)
            dp = tl.dot_t3(do_row, vt_buf)
            m = s * scale
            masked = k0 >= q0
            cols = tl.materialize(offs_kv)
            keep = (row_i >= cols) & (cols < T)
            if masked:
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_i)
            ds = p * (dp - delta_i)
            acc = tl.dot_t3(ds, kn_buf, acc)
            tl.barrier()
    tl.store(dq_pt, acc * scale, mask=(offs_m < T)[:, None])


@tl.kernel
def flash_bwd_dkv_f32_qkv_dsl_kernel(qkv_ptr, do_ptr, lse_ptr, delta_ptr,
                                     dqkv_ptr, T, scale, H: tl.constexpr,
                                     C: tl.constexpr, HD: tl.constexpr,
                                     BNK: tl.constexpr, BNI: tl.constexpr,
                                     EVEN_T: tl.constexpr):
    """fp32 fused dV+dK on the packed layouts, pure DSL: the packed
    address algebra over the same constructs as
    flash_bwd_dkv_f32_dsl_kernel (bit-equal); grads land straight in the
    q/k/v column slots of the (B, T, 3C) dqkv buffer."""
    pid_n = (T + BNK - 1) // BNK - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    k0 = pid_n * BNK
    offs_kv = k0 + tl.arange(0, BNK)
    offs_i = tl.arange(0, BNI)
    offs_d = tl.arange(0, HD)
    base3 = b * (T * (3 * C)) + h * HD
    baseo = b * (T * C) + h * HD
    k_pt = qkv_ptr + base3 + C + offs_kv[:, None] * (3 * C) + offs_d[None, :]
    v_pt = qkv_ptr + base3 + 2 * C + offs_kv[:, None] * (3 * C) + \
        offs_d[None, :]
    dv_pt = dqkv_ptr + base3 + 2 * C + offs_kv[:, None] * (3 * C) + \
        offs_d[None, :]
    dk_pt = dqkv_ptr + base3 + C + offs_kv[:, None] * (3 * C) + \
        offs_d[None, :]
    lay_r = tl.t3_layout((BNK, HD))
    lay_1 = tl.t3_layout((BNK, 1))
    k_row = tl.load(k_pt, LAYOUT=lay_r, mask=(offs_kv < T)[:, None])
    v_row = tl.load(v_pt, LAYOUT=lay_r, mask=(offs_kv < T)[:, None])
    row_j = tl.materialize(offs_kv[:, None], LAYOUT=lay_1)
    accv = tl.zeros((BNK, HD), tl.float32, LAYOUT=lay_r)
    acck = tl.zeros((BNK, HD), tl.float32, LAYOUT=lay_r)
    ceil_t = ((T + BNI - 1) // BNI) * BNI
    if EVEN_T:
        qt_buf = tl.smem((HD, BNI), tl.float32)
        don_buf = tl.smem((BNI, HD), tl.float32)
        qn_buf = tl.smem((BNI, HD), tl.float32)
        cols0 = tl.materialize(offs_i)
        keep = cols0 >= row_j  # typed pre-def; the real mask is per-tile
        for i0 in tl.pipelined(range(k0, ceil_t, BNI), stages=2):
            sT = tl.dot_t3(k_row, p_qt)
            p_qt = tl.stage(
                qt_buf, qkv_ptr + base3 + (i0 + offs_i)[:, None] *
                (3 * C) + offs_d[None, :], TRANS=True)
            dpT = tl.dot_t3(v_row, p_don, TRANS_B=True)
            offs_iq = i0 + offs_i
            lse_b = tl.load(lse_ptr + bh * T + offs_iq,
                            mask=(offs_iq < T), other=0.0)
            delta_b = tl.load(delta_ptr + bh * T + offs_iq,
                              mask=(offs_iq < T), other=0.0)
            cols = tl.materialize(offs_iq)
            m = sT * scale
            masked = (i0 < k0 + BNK) | (i0 + BNI > T)
            if masked:
                keep = (cols >= row_j) & (cols < T)
                m = tl.where(keep, m, -1e9)
            pT = tl.exp(m - lse_b)
            dsT = pT * (dpT - delta_b)
            accv = tl.dot_t3(pT, p_don, accv)
            p_don = tl.stage(
                don_buf, do_ptr + baseo + (i0 + offs_i)[:, None] * C +
                offs_d[None, :], EVEN=True)
            acck = tl.dot_t3(dsT, p_qn, acck)
            p_qn = tl.stage(
                qn_buf, qkv_ptr + base3 + (i0 + offs_i)[:, None] *
                (3 * C) + offs_d[None, :], EVEN=True)
    else:
        qt_buf = tl.smem((HD, BNI), tl.float32)
        don_buf = tl.smem((BNI, HD), tl.float32)
        qn_buf = tl.smem((BNI, HD), tl.float32)
        cols0 = tl.materialize(offs_i)
        keep = cols0 >= row_j
        for i0 in range(k0, ceil_t, BNI):
            offs_iq = i0 + offs_i
            q_ok = (offs_iq < T)[:, None]
            t1 = tl.async_copy(
                qt_buf, qkv_ptr + base3 + offs_iq[:, None] * (3 * C) +
                offs_d[None, :], TRANS=True, MASK=q_ok)
            t3 = tl.async_copy(
                don_buf, do_ptr + baseo + offs_iq[:, None] * C +
                offs_d[None, :], MASK=q_ok)
            t4 = tl.async_copy(
                qn_buf, qkv_ptr + base3 + offs_iq[:, None] * (3 * C) +
                offs_d[None, :], MASK=q_ok)
            tl.async_wait(t4, 0)
            tl.barrier()
            sT = tl.dot_t3(k_row, qt_buf)
            dpT = tl.dot_t3(v_row, don_buf, TRANS_B=True)
            lse_b = tl.load(lse_ptr + bh * T + offs_iq,
                            mask=(offs_iq < T), other=0.0)
            delta_b = tl.load(delta_ptr + bh * T + offs_iq,
                              mask=(offs_iq < T), other=0.0)
            cols = tl.materialize(offs_iq)
            m = sT * scale
            masked = (i0 < k0 + BNK) | (i0 + BNI > T)
            if masked:
                keep = (cols >= row_j) & (cols < T)
                m = tl.where(keep, m, -1e9)
            pT = tl.exp(m - lse_b)
            dsT = pT * (dpT - delta_b)
            accv = tl.dot_t3(pT, don_buf, accv)
            acck = tl.dot_t3(dsT, qn_buf, acck)
            tl.barrier()
    tl.store(dv_pt, accv, mask=(offs_kv < T)[:, None])
    tl.store(dk_pt, acck * scale, mask=(offs_kv < T)[:, None])


def launch_flash_attention_bwd_qkv(qkv, o, do, lse, delta, dqkv,
                                   H: int, scale: float, num_warps: int = 4):
    """fp32 fused flash backward on the packed layouts: qkv/o/do
    (B, T, 3C) / (B, T, C) f32; lse/delta (B*H, T) f32; dqkv
    preallocated (B, T, 3C) f32."""
    B, T, C3 = qkv.shape
    C = C3 // 3
    HD = C // H
    if HD != 64:
        raise NotImplementedError(
            f"flash attention bwd qkv currently supports head dim 64, got {HD}")
    if T % 32:
        raise NotImplementedError(
            f"flash attention bwd qkv needs T % 32 == 0, got {T}")
    flash_bwd_delta_qkv_rows_kernel[(T // 32, B * H)](
        do._buffer_arg(), o._buffer_arg(), delta._buffer_arg(), T,
        H=H, C=C, HD=HD, RPB=32, num_warps=2)
    BM = 32 * num_warps
    flash_bwd_dq_f32_qkv_dsl_kernel[((T + BM - 1) // BM, B * H)](
        qkv._buffer_arg(), do._buffer_arg(), lse._buffer_arg(),
        delta._buffer_arg(), dqkv._buffer_arg(), T, scale,
        H=H, C=C, HD=HD, BM=BM, BN=64, EVEN_T=T % 64 == 0,
        num_warps=num_warps)
    BNK = 32 * num_warps
    grid_kv = ((T + BNK - 1) // BNK, B * H)
    flash_bwd_dkv_f32_qkv_dsl_kernel[grid_kv](
        qkv._buffer_arg(), do._buffer_arg(), lse._buffer_arg(),
        delta._buffer_arg(), dqkv._buffer_arg(), T, scale,
        H=H, C=C, HD=HD, BNK=BNK, BNI=64, EVEN_T=T % 64 == 0,
        num_warps=num_warps)



# ---------------------------------------------------------------------------
# flash attention backward, native bf16 tensor-core mma (train-amp): the
# same three-kernel split as the f32 fused backward, but the operands stay
# bf16 end to end and the five matmuls run mma.m16n8k16 (warp-slab mapping
# like the mma forward). Pure-DSL kernels
# over the general tile-level mma primitives (compiler/builder.py "tile-
# level mma DSL primitives").
# ---------------------------------------------------------------------------

@tl.kernel
def flash_bwd_delta_bf16_kernel(do_ptr, o_ptr, delta_ptr,
                                HD: tl.constexpr, BLOCK: tl.constexpr):
    """delta[row] = sum(do[row, :] * o[row, :]) over (BH*T) rows; bf16
    loads, f32 product + accumulation."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < HD
    do32 = tl.cast(tl.load(do_ptr + row * HD + offs, mask=m, other=0.0),
                   tl.float32)
    o32 = tl.cast(tl.load(o_ptr + row * HD + offs, mask=m, other=0.0),
                  tl.float32)
    tl.store(delta_ptr + row, tl.sum(do32 * o32))


def launch_flash_bwd_delta_bf16(do, o, delta, HD: int = 64):
    R = do.numel() // HD
    if HD == 64 and R % 32 == 0:
        # row-batch path: 32 rows per program (dist tile + axis-1 reduce)
        # — the one-program-per-row form needed 163840 launches, which
        # is pure launch-rate tax
        return flash_bwd_delta_bf16_rows_kernel[(R // 32,)](
            do._buffer_arg(), o._buffer_arg(), delta._buffer_arg(),
            HD=HD, RPB=32, num_warps=2)
    flash_bwd_delta_bf16_kernel[(R,)](do._buffer_arg(), o._buffer_arg(),
                                      delta._buffer_arg(), HD=HD, BLOCK=128,
                                      num_warps=4)


@tl.kernel
def flash_bwd_delta_bf16_rows_kernel(do_ptr, o_ptr, delta_ptr,
                                     HD: tl.constexpr, RPB: tl.constexpr):
    """delta[row] = sum(do[row, :] * o[row, :]) for RPB consecutive rows
    (rows exact multiple of RPB; the (RPB, HD) tile is dist so the axis-1
    reduce lowers to warp butterflies)."""
    pid = tl.program_id(0)
    rows = pid * RPB + tl.arange(0, RPB)
    offs = rows[:, None] * HD + tl.arange(0, HD)[None, :]
    do32 = tl.cast(tl.load(do_ptr + offs), tl.float32)
    o32 = tl.cast(tl.load(o_ptr + offs), tl.float32)
    d = tl.sum(do32 * o32, axis=1)
    tl.store(delta_ptr + rows[:, None] + tl.arange(0, 1)[None, :], d)


@tl.kernel
def flash_bwd_dq_bf16_dsl_kernel(q_ptr, kt_ptr, vt_ptr, do_ptr, lse_ptr,
                                 delta_ptr, dq_ptr, T, scale,
                                 HD: tl.constexpr, BM: tl.constexpr,
                                 BN: tl.constexpr, EVEN_T: tl.constexpr):
    """bf16 dQ for one q-row block, pure DSL: the warp-slab choreography
    composed from the
    general tile-level primitives — layout-requested A-operand loads,
    tl.mma (register-A x staged-B, software-pipelined via stage_pipe/
    async_stage), narrow Sliced stat loads for lse/delta, convert_layout
    for the dS -> A pack. Bit-equal by construction (same
    mma order, same pack, same ex2 form, same store packing)."""
    # reverse the q-block order: the block with the longest k loop starts
    # first (better tail packing across SMs)
    pid_m = (T + BM - 1) // BM - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    q0 = pid_m * BM
    offs_m = q0 + tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_d = tl.arange(0, HD)
    base = bh * (T * HD)
    q_pt = q_ptr + base + offs_m[:, None] * HD + offs_d[None, :]
    do_pt = do_ptr + base + offs_m[:, None] * HD + offs_d[None, :]
    dq_pt = dq_ptr + base + offs_m[:, None] * HD + offs_d[None, :]
    lay_a = tl.mma_layout("A", (BM, HD), "bf16")
    lay_c = tl.mma_layout("C", (BM, BN), "bf16")
    lay_co = tl.mma_layout("C", (BM, HD), "bf16")
    q_fr = tl.load(q_pt, LAYOUT=lay_a, mask=(offs_m < T)[:, None])
    do_fr = tl.load(do_pt, LAYOUT=lay_a, mask=(offs_m < T)[:, None])
    rowsf = tl.materialize(offs_m[:, None], LAYOUT=lay_c)
    lse_b = tl.load(lse_ptr + bh * T + offs_m[:, None], LAYOUT=lay_c,
                    mask=(offs_m < T)[:, None], other=0.0)
    delta_b = tl.load(delta_ptr + bh * T + offs_m[:, None], LAYOUT=lay_c,
                      mask=(offs_m < T)[:, None], other=0.0)
    acc = tl.zeros((BM, HD), tl.float32, LAYOUT=lay_co)
    ceil_t = ((T + BN - 1) // BN) * BN
    hi1b = q0 + BM
    hi2 = tl.where(hi1b < ceil_t, hi1b, ceil_t)
    if EVEN_T:
        # tl.pipelined single-buffer rotation (explicit sugar): the three
        # tl.stage sites below describe the tiles THIS iteration consumes;
        # the construct emits the prologue, the next-tile restages and
        # the drain (PENDING defaults to 2/1/0 in consume order)
        kt_pipe = tl.stage_pipe((BN, HD), tl.bfloat16, TRANS=True,
                                EVEN=True)
        vt_pipe = tl.stage_pipe((BN, HD), tl.bfloat16, TRANS=True,
                                EVEN=True)
        kn_pipe = tl.stage_pipe((BN, HD), tl.bfloat16, EVEN=True)
        for k0 in tl.pipelined(range(0, hi2, BN), stages=2):
            s = tl.mma(q_fr, p_kt)
            p_kt = tl.stage(
                kt_pipe,
                kt_ptr + base + offs_d[:, None] + (k0 + offs_n)[None, :] * HD)
            m = s * scale
            masked = k0 + BN > q0
            colsf = tl.materialize((k0 + offs_n)[None, :], LAYOUT=lay_c)
            keep = (rowsf >= colsf) & (colsf < T)
            if masked:
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_b)
            dp = tl.mma(do_fr, p_vt)
            p_vt = tl.stage(
                vt_pipe,
                vt_ptr + base + offs_d[:, None] + (k0 + offs_n)[None, :] * HD)
            ds = p * (dp - delta_b)
            ds_a = tl.convert_layout(ds, tl.mma_layout("A", (BM, BN),
                                                       "bf16"))
            acc = tl.mma(ds_a, p_kn, acc)
            p_kn = tl.stage(
                kn_pipe,
                kt_ptr + base + (k0 + offs_n)[:, None] * HD + offs_d[None, :])
    else:
        # ragged-T path (correctness shapes): synchronous staging with
        # zfill row guards
        for k0 in range(0, hi2, BN):
            offs_kv = k0 + offs_n
            kt_pt = kt_ptr + base + offs_d[:, None] + offs_kv[None, :] * HD
            vt_pt = vt_ptr + base + offs_d[:, None] + offs_kv[None, :] * HD
            kn_pt = kt_ptr + base + offs_kv[:, None] * HD + offs_d[None, :]
            colsf = tl.materialize(offs_kv[None, :], LAYOUT=lay_c)
            keep = (rowsf >= colsf) & (colsf < T)
            kv_ok = (offs_kv < T)[None, :]
            s = tl.mma(q_fr, kt_pt, TRANS_B=True, MASK=kv_ok)
            m = s * scale
            masked = k0 + BN > q0
            if masked:
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_b)
            dp = tl.mma(do_fr, vt_pt, TRANS_B=True, MASK=kv_ok)
            ds = p * (dp - delta_b)
            ds_a = tl.convert_layout(ds, tl.mma_layout("A", (BM, BN),
                                                       "bf16"))
            acc = tl.mma(ds_a, kn_pt, acc, TRANS_B=False,
                         MASK=(offs_kv < T)[:, None])
    tl.store(dq_pt, acc * scale, mask=(offs_m < T)[:, None])


@tl.kernel
def flash_bwd_dkv_bf16_dsl_kernel(k_ptr, v_ptr, qt_ptr, dot_ptr, do_ptr,
                                  lse_ptr, delta_ptr, dv_ptr, dk_ptr, T,
                                  scale, HD: tl.constexpr, BNK: tl.constexpr,
                                  BNI: tl.constexpr, EVEN_T: tl.constexpr):
    """bf16 fused dV+dK for one kv-row block, pure DSL: one q-tile
    pass per kv block, Sᵀ/dPᵀ recomputed once and fed to both
    accumulates — the same general tile-level primitives as
    flash_bwd_dq_bf16_dsl_kernel."""
    pid_n = (T + BNK - 1) // BNK - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    k0 = pid_n * BNK
    offs_kv = k0 + tl.arange(0, BNK)
    offs_i = tl.arange(0, BNI)
    offs_d = tl.arange(0, HD)
    base = bh * (T * HD)
    k_pt = k_ptr + base + offs_kv[:, None] * HD + offs_d[None, :]
    v_pt = v_ptr + base + offs_kv[:, None] * HD + offs_d[None, :]
    dv_pt = dv_ptr + base + offs_kv[:, None] * HD + offs_d[None, :]
    dk_pt = dk_ptr + base + offs_kv[:, None] * HD + offs_d[None, :]
    lay_a = tl.mma_layout("A", (BNK, HD), "bf16")
    lay_as = tl.mma_layout("A", (BNK, BNI), "bf16")
    lay_c = tl.mma_layout("C", (BNK, BNI), "bf16")
    lay_co = tl.mma_layout("C", (BNK, HD), "bf16")
    k_fr = tl.load(k_pt, LAYOUT=lay_a, mask=(offs_kv < T)[:, None])
    v_fr = tl.load(v_pt, LAYOUT=lay_a, mask=(offs_kv < T)[:, None])
    rowsf = tl.materialize(offs_kv[:, None], LAYOUT=lay_c)
    accv = tl.zeros((BNK, HD), tl.float32, LAYOUT=lay_co)
    acck = tl.zeros((BNK, HD), tl.float32, LAYOUT=lay_co)
    ceil_t = ((T + BNI - 1) // BNI) * BNI
    if EVEN_T:
        # tl.pipelined single-buffer rotation (see the dq kernel)
        qt_pipe = tl.stage_pipe((BNI, HD), tl.bfloat16, TRANS=True,
                                EVEN=True)
        dot_pipe = tl.stage_pipe((BNI, HD), tl.bfloat16, TRANS=True,
                                 EVEN=True)
        don_pipe = tl.stage_pipe((BNI, HD), tl.bfloat16, EVEN=True)
        qn_pipe = tl.stage_pipe((BNI, HD), tl.bfloat16, EVEN=True)
        cols0 = tl.materialize(offs_i[None, :], LAYOUT=lay_c)
        keep = cols0 >= rowsf  # typed pre-def; the real mask is per-tile
        for i0 in tl.pipelined(range(k0, ceil_t, BNI), stages=2):
            pT = tl.mma(k_fr, p_qt)
            p_qt = tl.stage(
                qt_pipe,
                qt_ptr + base + offs_d[:, None] + (i0 + offs_i)[None, :] * HD)
            dpT = tl.mma(v_fr, p_dot)
            p_dot = tl.stage(
                dot_pipe,
                dot_ptr + base + offs_d[:, None] + (i0 + offs_i)[None, :] * HD)
            offs_iq = i0 + offs_i
            colsf = tl.materialize(offs_iq[None, :], LAYOUT=lay_c)
            lse_b = tl.load(lse_ptr + bh * T + offs_iq[None, :],
                            LAYOUT=lay_c, mask=(offs_iq < T)[None, :],
                            other=0.0)
            delta_b = tl.load(delta_ptr + bh * T + offs_iq[None, :],
                              LAYOUT=lay_c, mask=(offs_iq < T)[None, :],
                              other=0.0)
            m = pT * scale
            masked = (i0 < k0 + BNK) | (i0 + BNI > T)
            if masked:
                keep = (colsf >= rowsf) & (colsf < T)
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_b)
            ds = p * (dpT - delta_b)
            p_a = tl.convert_layout(p, lay_as)
            ds_a = tl.convert_layout(ds, lay_as)
            accv = tl.mma(p_a, p_don, accv)
            p_don = tl.stage(
                don_pipe,
                do_ptr + base + (i0 + offs_i)[:, None] * HD + offs_d[None, :])
            acck = tl.mma(ds_a, p_qn, acck)
            p_qn = tl.stage(
                qn_pipe,
                qt_ptr + base + (i0 + offs_i)[:, None] * HD + offs_d[None, :])
    else:
        for i0 in range(k0, ceil_t, BNI):
            offs_iq = i0 + offs_i
            qt_pt = qt_ptr + base + offs_d[:, None] + offs_iq[None, :] * HD
            dot_pt = dot_ptr + base + offs_d[:, None] + \
                offs_iq[None, :] * HD
            don_pt = do_ptr + base + offs_iq[:, None] * HD + offs_d[None, :]
            qn_pt = qt_ptr + base + offs_iq[:, None] * HD + offs_d[None, :]
            q_ok = (offs_iq < T)[None, :]
            pT = tl.mma(k_fr, qt_pt, TRANS_B=True, MASK=q_ok)
            dpT = tl.mma(v_fr, dot_pt, TRANS_B=True, MASK=q_ok)
            colsf = tl.materialize(offs_iq[None, :], LAYOUT=lay_c)
            lse_b = tl.load(lse_ptr + bh * T + offs_iq[None, :],
                            LAYOUT=lay_c, mask=(offs_iq < T)[None, :],
                            other=0.0)
            delta_b = tl.load(delta_ptr + bh * T + offs_iq[None, :],
                              LAYOUT=lay_c, mask=(offs_iq < T)[None, :],
                              other=0.0)
            m = pT * scale
            masked = (i0 < k0 + BNK) | (i0 + BNI > T)
            keep = (colsf >= rowsf) & (colsf < T)
            if masked:
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_b)
            ds = p * (dpT - delta_b)
            p_a = tl.convert_layout(p, lay_as)
            ds_a = tl.convert_layout(ds, lay_as)
            accv = tl.mma(p_a, don_pt, accv, TRANS_B=False,
                          MASK=(offs_iq < T)[:, None])
            acck = tl.mma(ds_a, qn_pt, acck, TRANS_B=False,
                          MASK=(offs_iq < T)[:, None])
    tl.store(dv_pt, accv, mask=(offs_kv < T)[:, None])
    tl.store(dk_pt, acck * scale, mask=(offs_kv < T)[:, None])


def launch_flash_attention_bwd_bf16(q, k, v, o, do, lse, delta, dq, dk, dv,
                                    scale: float, num_warps: int = 4):
    """Native bf16 fused flash backward. q/k/v/o/do (BH, T, HD) contiguous
    natural layout bf16; lse/delta (BH, T) f32; dq/dk/dv preallocated like
    q (bf16). Three launches: delta, dQ, fused dV+dK."""
    BH, T, HD = q.shape
    if HD != 64:
        raise NotImplementedError(
            f"flash attention bwd mma currently supports head dim 64, got {HD}")
    launch_flash_bwd_delta_bf16(do, o, delta, HD)
    BQ = 16 * num_warps
    flash_bwd_dq_bf16_dsl_kernel[((T + BQ - 1) // BQ, BH)](
        q._buffer_arg(), k._buffer_arg(), v._buffer_arg(), do._buffer_arg(),
        lse._buffer_arg(), delta._buffer_arg(), dq._buffer_arg(), T, scale,
        HD=HD, BM=BQ, BN=64, EVEN_T=T % 64 == 0, num_warps=num_warps)
    BNK = 16 * num_warps
    grid_kv = ((T + BNK - 1) // BNK, BH)
    flash_bwd_dkv_bf16_dsl_kernel[grid_kv](
        k._buffer_arg(), v._buffer_arg(), q._buffer_arg(), do._buffer_arg(),
        do._buffer_arg(), lse._buffer_arg(), delta._buffer_arg(),
        dv._buffer_arg(), dk._buffer_arg(), T, scale,
        HD=HD, BNK=BNK, BNI=64, EVEN_T=T % 64 == 0, num_warps=num_warps)


# ---------------------------------------------------------------------------
# qkv-packed strided flash backward (bf16 tier): mirrors of the kernels
# above with the (B, T, 3C) / (B, T, C) address algebra (constexpr row
# strides, (b, h) decoded from the block index). q/k/v grads are written
# into the q/k/v column slots of one (B, T, 3C) dqkv buffer, so the
# head-split backward is free (no cat).
# ---------------------------------------------------------------------------

@tl.kernel
def flash_bwd_delta_bf16_rows_qkv_kernel(do_ptr, o_ptr, delta_ptr, T,
                                         H: tl.constexpr, C: tl.constexpr,
                                         HD: tl.constexpr, RPB: tl.constexpr):
    """Strided twin of flash_bwd_delta_bf16_rows_kernel: do/o rows live in
    (B, T, C) buffers (row stride C, head offset h*HD); grid (T/RPB, BH).
    """
    pid = tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    rows = pid * RPB + tl.arange(0, RPB)
    offs = b * (T * C) + h * HD + rows[:, None] * C + \
        tl.arange(0, HD)[None, :]
    do32 = tl.cast(tl.load(do_ptr + offs), tl.float32)
    o32 = tl.cast(tl.load(o_ptr + offs), tl.float32)
    d = tl.sum(do32 * o32, axis=1)
    tl.store(delta_ptr + (bh * T + rows)[:, None] +
             tl.arange(0, 1)[None, :], d)


@tl.kernel
def flash_bwd_dq_bf16_qkv_dsl_kernel(qkv_ptr, do_ptr, lse_ptr, delta_ptr,
                                     dqkv_ptr, T, scale, H: tl.constexpr,
                                     C: tl.constexpr, HD: tl.constexpr,
                                     BM: tl.constexpr, BN: tl.constexpr,
                                     EVEN_T: tl.constexpr):
    """bf16 dQ on the packed layouts, pure DSL: the (B, T, 3C)/(B, T,
    C) address algebra over the same general primitives as
    flash_bwd_dq_bf16_dsl_kernel."""
    pid_m = (T + BM - 1) // BM - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    q0 = pid_m * BM
    offs_m = q0 + tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_d = tl.arange(0, HD)
    base3 = b * (T * (3 * C)) + h * HD
    baseo = b * (T * C) + h * HD
    q_pt = qkv_ptr + base3 + offs_m[:, None] * (3 * C) + offs_d[None, :]
    do_pt = do_ptr + baseo + offs_m[:, None] * C + offs_d[None, :]
    dq_pt = dqkv_ptr + base3 + offs_m[:, None] * (3 * C) + offs_d[None, :]
    lay_a = tl.mma_layout("A", (BM, HD), "bf16")
    lay_c = tl.mma_layout("C", (BM, BN), "bf16")
    lay_co = tl.mma_layout("C", (BM, HD), "bf16")
    q_fr = tl.load(q_pt, LAYOUT=lay_a, mask=(offs_m < T)[:, None])
    do_fr = tl.load(do_pt, LAYOUT=lay_a, mask=(offs_m < T)[:, None])
    rowsf = tl.materialize(offs_m[:, None], LAYOUT=lay_c)
    lse_b = tl.load(lse_ptr + bh * T + offs_m[:, None], LAYOUT=lay_c,
                    mask=(offs_m < T)[:, None], other=0.0)
    delta_b = tl.load(delta_ptr + bh * T + offs_m[:, None], LAYOUT=lay_c,
                      mask=(offs_m < T)[:, None], other=0.0)
    acc = tl.zeros((BM, HD), tl.float32, LAYOUT=lay_co)
    ceil_t = ((T + BN - 1) // BN) * BN
    hi1b = q0 + BM
    hi2 = tl.where(hi1b < ceil_t, hi1b, ceil_t)
    if EVEN_T:
        kt_pipe = tl.stage_pipe((BN, HD), tl.bfloat16, TRANS=True,
                                EVEN=True)
        vt_pipe = tl.stage_pipe((BN, HD), tl.bfloat16, TRANS=True,
                                EVEN=True)
        kn_pipe = tl.stage_pipe((BN, HD), tl.bfloat16, EVEN=True)
        for k0 in tl.pipelined(range(0, hi2, BN), stages=2):
            s = tl.mma(q_fr, p_kt)
            p_kt = tl.stage(
                kt_pipe, qkv_ptr + base3 + C + offs_d[:, None] +
                (k0 + offs_n)[None, :] * (3 * C))
            m = s * scale
            masked = k0 + BN > q0
            colsf = tl.materialize((k0 + offs_n)[None, :], LAYOUT=lay_c)
            keep = (rowsf >= colsf) & (colsf < T)
            if masked:
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_b)
            dp = tl.mma(do_fr, p_vt)
            p_vt = tl.stage(
                vt_pipe, qkv_ptr + base3 + 2 * C + offs_d[:, None] +
                (k0 + offs_n)[None, :] * (3 * C))
            ds = p * (dp - delta_b)
            ds_a = tl.convert_layout(ds, tl.mma_layout("A", (BM, BN),
                                                       "bf16"))
            acc = tl.mma(ds_a, p_kn, acc)
            p_kn = tl.stage(
                kn_pipe, qkv_ptr + base3 + C + (k0 + offs_n)[:, None] *
                (3 * C) + offs_d[None, :])
    else:
        for k0 in range(0, hi2, BN):
            offs_kv = k0 + offs_n
            kt_pt = qkv_ptr + base3 + C + offs_d[:, None] + \
                offs_kv[None, :] * (3 * C)
            vt_pt = qkv_ptr + base3 + 2 * C + offs_d[:, None] + \
                offs_kv[None, :] * (3 * C)
            kn_pt = qkv_ptr + base3 + C + offs_kv[:, None] * (3 * C) + \
                offs_d[None, :]
            colsf = tl.materialize(offs_kv[None, :], LAYOUT=lay_c)
            keep = (rowsf >= colsf) & (colsf < T)
            kv_ok = (offs_kv < T)[None, :]
            s = tl.mma(q_fr, kt_pt, TRANS_B=True, MASK=kv_ok)
            m = s * scale
            masked = k0 + BN > q0
            if masked:
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_b)
            dp = tl.mma(do_fr, vt_pt, TRANS_B=True, MASK=kv_ok)
            ds = p * (dp - delta_b)
            ds_a = tl.convert_layout(ds, tl.mma_layout("A", (BM, BN),
                                                       "bf16"))
            acc = tl.mma(ds_a, kn_pt, acc, TRANS_B=False,
                         MASK=(offs_kv < T)[:, None])
    tl.store(dq_pt, acc * scale, mask=(offs_m < T)[:, None])


@tl.kernel
def flash_bwd_dkv_bf16_qkv_dsl_kernel(qkv_ptr, do_ptr, lse_ptr, delta_ptr,
                                      dqkv_ptr, T, scale, H: tl.constexpr,
                                      C: tl.constexpr, HD: tl.constexpr,
                                      BNK: tl.constexpr, BNI: tl.constexpr,
                                      EVEN_T: tl.constexpr):
    """bf16 fused dV+dK on the packed layouts, pure DSL: the packed
    address algebra over the same general primitives as
    flash_bwd_dkv_bf16_dsl_kernel."""
    pid_n = (T + BNK - 1) // BNK - 1 - tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    k0 = pid_n * BNK
    offs_kv = k0 + tl.arange(0, BNK)
    offs_i = tl.arange(0, BNI)
    offs_d = tl.arange(0, HD)
    base3 = b * (T * (3 * C)) + h * HD
    baseo = b * (T * C) + h * HD
    k_pt = qkv_ptr + base3 + C + offs_kv[:, None] * (3 * C) + offs_d[None, :]
    v_pt = qkv_ptr + base3 + 2 * C + offs_kv[:, None] * (3 * C) + \
        offs_d[None, :]
    dv_pt = dqkv_ptr + base3 + 2 * C + offs_kv[:, None] * (3 * C) + \
        offs_d[None, :]
    dk_pt = dqkv_ptr + base3 + C + offs_kv[:, None] * (3 * C) + \
        offs_d[None, :]
    lay_a = tl.mma_layout("A", (BNK, HD), "bf16")
    lay_as = tl.mma_layout("A", (BNK, BNI), "bf16")
    lay_c = tl.mma_layout("C", (BNK, BNI), "bf16")
    lay_co = tl.mma_layout("C", (BNK, HD), "bf16")
    k_fr = tl.load(k_pt, LAYOUT=lay_a, mask=(offs_kv < T)[:, None])
    v_fr = tl.load(v_pt, LAYOUT=lay_a, mask=(offs_kv < T)[:, None])
    rowsf = tl.materialize(offs_kv[:, None], LAYOUT=lay_c)
    accv = tl.zeros((BNK, HD), tl.float32, LAYOUT=lay_co)
    acck = tl.zeros((BNK, HD), tl.float32, LAYOUT=lay_co)
    ceil_t = ((T + BNI - 1) // BNI) * BNI
    if EVEN_T:
        qt_pipe = tl.stage_pipe((BNI, HD), tl.bfloat16, TRANS=True,
                                EVEN=True)
        dot_pipe = tl.stage_pipe((BNI, HD), tl.bfloat16, TRANS=True,
                                 EVEN=True)
        don_pipe = tl.stage_pipe((BNI, HD), tl.bfloat16, EVEN=True)
        qn_pipe = tl.stage_pipe((BNI, HD), tl.bfloat16, EVEN=True)
        cols0 = tl.materialize(offs_i[None, :], LAYOUT=lay_c)
        keep = cols0 >= rowsf  # typed pre-def; the real mask is per-tile
        for i0 in tl.pipelined(range(k0, ceil_t, BNI), stages=2):
            pT = tl.mma(k_fr, p_qt)
            p_qt = tl.stage(
                qt_pipe, qkv_ptr + base3 + offs_d[:, None] +
                (i0 + offs_i)[None, :] * (3 * C))
            dpT = tl.mma(v_fr, p_dot)
            p_dot = tl.stage(
                dot_pipe, do_ptr + baseo + offs_d[:, None] +
                (i0 + offs_i)[None, :] * C)
            offs_iq = i0 + offs_i
            colsf = tl.materialize(offs_iq[None, :], LAYOUT=lay_c)
            lse_b = tl.load(lse_ptr + bh * T + offs_iq[None, :],
                            LAYOUT=lay_c, mask=(offs_iq < T)[None, :],
                            other=0.0)
            delta_b = tl.load(delta_ptr + bh * T + offs_iq[None, :],
                              LAYOUT=lay_c, mask=(offs_iq < T)[None, :],
                              other=0.0)
            m = pT * scale
            masked = (i0 < k0 + BNK) | (i0 + BNI > T)
            if masked:
                keep = (colsf >= rowsf) & (colsf < T)
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_b)
            ds = p * (dpT - delta_b)
            p_a = tl.convert_layout(p, lay_as)
            ds_a = tl.convert_layout(ds, lay_as)
            accv = tl.mma(p_a, p_don, accv)
            p_don = tl.stage(
                don_pipe, do_ptr + baseo + (i0 + offs_i)[:, None] * C +
                offs_d[None, :])
            acck = tl.mma(ds_a, p_qn, acck)
            p_qn = tl.stage(
                qn_pipe, qkv_ptr + base3 + (i0 + offs_i)[:, None] *
                (3 * C) + offs_d[None, :])
    else:
        for i0 in range(k0, ceil_t, BNI):
            offs_iq = i0 + offs_i
            qt_pt = qkv_ptr + base3 + offs_d[:, None] + \
                offs_iq[None, :] * (3 * C)
            dot_pt = do_ptr + baseo + offs_d[:, None] + offs_iq[None, :] * C
            don_pt = do_ptr + baseo + offs_iq[:, None] * C + offs_d[None, :]
            qn_pt = qkv_ptr + base3 + offs_iq[:, None] * (3 * C) + \
                offs_d[None, :]
            q_ok = (offs_iq < T)[None, :]
            pT = tl.mma(k_fr, qt_pt, TRANS_B=True, MASK=q_ok)
            dpT = tl.mma(v_fr, dot_pt, TRANS_B=True, MASK=q_ok)
            colsf = tl.materialize(offs_iq[None, :], LAYOUT=lay_c)
            lse_b = tl.load(lse_ptr + bh * T + offs_iq[None, :],
                            LAYOUT=lay_c, mask=(offs_iq < T)[None, :],
                            other=0.0)
            delta_b = tl.load(delta_ptr + bh * T + offs_iq[None, :],
                              LAYOUT=lay_c, mask=(offs_iq < T)[None, :],
                              other=0.0)
            m = pT * scale
            masked = (i0 < k0 + BNK) | (i0 + BNI > T)
            keep = (colsf >= rowsf) & (colsf < T)
            if masked:
                m = tl.where(keep, m, -1e9)
            p = tl.exp(m - lse_b)
            ds = p * (dpT - delta_b)
            p_a = tl.convert_layout(p, lay_as)
            ds_a = tl.convert_layout(ds, lay_as)
            accv = tl.mma(p_a, don_pt, accv, TRANS_B=False,
                          MASK=(offs_iq < T)[:, None])
            acck = tl.mma(ds_a, qn_pt, acck, TRANS_B=False,
                          MASK=(offs_iq < T)[:, None])
    tl.store(dv_pt, accv, mask=(offs_kv < T)[:, None])
    tl.store(dk_pt, acck * scale, mask=(offs_kv < T)[:, None])


def launch_flash_attention_bwd_bf16_qkv(qkv, o, do, lse, delta, dqkv,
                                        H: int, scale: float,
                                        num_warps: int = 4):
    """Native bf16 fused flash backward on the packed layouts: qkv/o/do
    (B, T, 3C) / (B, T, C); lse/delta (B*H, T) f32; dqkv preallocated
    (B, T, 3C) bf16. Three launches: delta, dQ, fused dV+dK."""
    B, T, C3 = qkv.shape
    C = C3 // 3
    HD = C // H
    if HD != 64:
        raise NotImplementedError(
            f"flash attention bwd qkv currently supports head dim 64, got {HD}")
    if T % 32:
        raise NotImplementedError(
            f"flash attention bwd qkv needs T % 32 == 0, got {T}")
    flash_bwd_delta_bf16_rows_qkv_kernel[(T // 32, B * H)](
        do._buffer_arg(), o._buffer_arg(), delta._buffer_arg(), T,
        H=H, C=C, HD=HD, RPB=32, num_warps=2)
    BQ = 16 * num_warps
    flash_bwd_dq_bf16_qkv_dsl_kernel[((T + BQ - 1) // BQ, B * H)](
        qkv._buffer_arg(), do._buffer_arg(), lse._buffer_arg(),
        delta._buffer_arg(), dqkv._buffer_arg(), T, scale,
        H=H, C=C, HD=HD, BM=BQ, BN=64, EVEN_T=T % 64 == 0,
        num_warps=num_warps)
    BNK = 16 * num_warps
    grid_kv = ((T + BNK - 1) // BNK, B * H)
    flash_bwd_dkv_bf16_qkv_dsl_kernel[grid_kv](
        qkv._buffer_arg(), do._buffer_arg(), lse._buffer_arg(),
        delta._buffer_arg(), dqkv._buffer_arg(), T, scale,
        H=H, C=C, HD=HD, BNK=BNK, BNI=64, EVEN_T=T % 64 == 0,
        num_warps=num_warps)



__all__ = [
    "flash_attention_fwd_f32_qkv_dsl_kernel",
    "flash_attention_fwd_f32_dsl_kernel",
    "launch_flash_attention",
    "flash_attention_fwd_mma_qkv_dsl_kernel",
    "flash_attention_fwd_mma_dsl_kernel",
    "launch_flash_attention_mma",
    "launch_flash_attention_mma_qkv",
    "flash_bwd_delta_kernel",
    "launch_flash_bwd_delta",
    "flash_bwd_dq_f32_dsl_kernel",
    "flash_bwd_dkv_f32_dsl_kernel",
    "launch_flash_attention_bwd",
    "launch_flash_attention_qkv",
    "flash_bwd_delta_qkv_rows_kernel",
    "flash_bwd_dq_f32_qkv_dsl_kernel",
    "flash_bwd_dkv_f32_qkv_dsl_kernel",
    "launch_flash_attention_bwd_qkv",
    "flash_bwd_delta_bf16_kernel",
    "launch_flash_bwd_delta_bf16",
    "flash_bwd_delta_bf16_rows_kernel",
    "flash_bwd_dq_bf16_dsl_kernel",
    "flash_bwd_dkv_bf16_dsl_kernel",
    "launch_flash_attention_bwd_bf16",
    "flash_bwd_delta_bf16_rows_qkv_kernel",
    "flash_bwd_dq_bf16_qkv_dsl_kernel",
    "flash_bwd_dkv_bf16_qkv_dsl_kernel",
    "launch_flash_attention_bwd_bf16_qkv",
]
