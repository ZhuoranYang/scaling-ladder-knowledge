"""Minimal torch-style module/parameter system.

``Parameter`` is a leaf ``Tensor`` with requires_grad=True; ``Module``
registers parameters/submodules by attribute assignment and provides
``parameters()`` (dedup'd, so tied weights appear once), ``zero_grad()``
and ``to(device)``.
"""

from __future__ import annotations

import numpy as np

from ..autograd.engine import _no_grad
from ..tensor import Tensor


class Parameter(Tensor):
    """A leaf tensor that accumulates gradients (model weight)."""

    def __init__(self, data, dtype=None, device: str = "cuda"):
        super().__init__(data, dtype=dtype, device=device,
                         requires_grad=True)

    @classmethod
    def normal(cls, shape, std: float = 0.02, device: str = "cuda",
               seed: int | None = None) -> "Parameter":
        rng = np.random.default_rng(seed)
        arr = (rng.standard_normal(shape) * std).astype(np.float32)
        return cls(arr, device=device)

    @classmethod
    def zeros(cls, shape, device: str = "cuda") -> "Parameter":
        return cls(np.zeros(shape, dtype=np.float32), device=device)

    @classmethod
    def ones(cls, shape, device: str = "cuda") -> "Parameter":
        return cls(np.ones(shape, dtype=np.float32), device=device)

    def __repr__(self):
        return f"tl.nn.Parameter(shape={self.shape}, device={self.device!r})"


class Module:
    training: bool

    def __init__(self):
        object.__setattr__(self, "_parameters", {})
        object.__setattr__(self, "_modules", {})
        object.__setattr__(self, "training", True)

    def _drop_registered(self, name):
        """Remove every registry entry made under attr ``name`` — including
        the indexed ``name.0``/``name.1`` keys of a bare list of submodules,
        which a plain pop of ``name`` never reached."""
        self._parameters.pop(name, None)
        for k in [k for k in self._modules
                  if k == name or k.startswith(name + ".")]:
            del self._modules[k]

    def __setattr__(self, name, value):
        self._drop_registered(name)  # replacing any previously registered attr
        if isinstance(value, Parameter):
            self._parameters[name] = value
            for m in self._modules.values():
                # identity, not name: an upward re-registration of the
                # same object removes the child's stale entry; a
                # submodule's own same-named parameter must survive
                for k, p in list(m._parameters.items()):
                    if p is value:
                        del m._parameters[k]
        else:
            if isinstance(value, Module):
                self._modules[name] = value
            elif isinstance(value, (list, tuple)) and value and all(
                    isinstance(v, Module) for v in value):
                # a bare list of submodules registers its elements,
                # otherwise their parameters would be swallowed
                for i, v in enumerate(value):
                    self._modules[f"{name}.{i}"] = v
        object.__setattr__(self, name, value)

    def __delattr__(self, name):
        # keep the registries in sync with the attribute namespace:
        # dropping an attr must drop its parameter/module entries too,
        # otherwise parameters() keeps yielding detached params
        self._drop_registered(name)
        object.__delattr__(self, name)

    def parameters(self):
        seen = set()

        def walk(mod):
            for p in mod._parameters.values():
                if id(p) not in seen:
                    seen.add(id(p))
                    yield p
            for m in mod._modules.values():
                yield from walk(m)

        return walk(self)

    def zero_grad(self):
        for p in self.parameters():
            p.grad = None

    def train(self, mode: bool = True):
        self.training = mode
        for m in self._modules.values():
            m.train(mode)
        return self

    def eval(self):
        return self.train(False)

    def to(self, device: str):
        """Move all parameters (and their grads) to device in place."""
        with _no_grad():
            for p in self.parameters():
                if p.device == device:
                    continue
                grad = p.grad  # _steal overwrites .grad with the moved
                moved = p.to(device)  # tensor's (None), so keep it aside
                p._steal(moved)
                p.requires_grad = True
                p.grad = None if grad is None else grad.to(device)
        return self

    def forward(self, *args, **kwargs):
        raise NotImplementedError

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)
