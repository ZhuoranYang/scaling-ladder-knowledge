"""Pooled caching allocator for device memory.

Freed buffers go back to per-size-class
free lists instead of cuMemFree, so eager ops and training
loops don't pay a synchronous cuMemAlloc per call:

- **size classes**: request sizes are rounded up to class boundaries
  (512B below 1MB, 1MB below 32MB, 8MB above), which caps fragmentation
  from the many distinct activation sizes a training step produces;
- **peak statistics**: in-use (``allocated``) and pool-held (``reserved``)
  byte counters with peaks, for memory reporting;
- **``MT_ALLOCATOR=off``**: bypass the pool entirely (direct
  cuMemAlloc/cuMemFree per call) for debugging and leak checks.

Only base (offset-0) allocations owned by ``empty``/``zeros``/... are
pooled; view buffers and from_numpy buffers are unaffected. The public
interface is ``_alloc(numel, dtype) -> Buffer``.

Cross-stream reuse safety. ``_PooledBuffer`` carries
``home_stream`` (the stream it was checked out on). A buffer freed while
its home stream is non-0 gets a release-time event attached; a later
reuse on a DIFFERENT stream waits that event before handing the buffer
out. The single-stream fast path (home 0) creates zero events.
"""

from __future__ import annotations

import os

from ..frontend.types import DType
from . import cuda_driver as _drv
from . import streams as _streams
from .buffer import Buffer

_MB = 1 << 20


def _size_class(nbytes: int) -> int:
    """Round nbytes up to the allocator's size-class granularity."""
    if nbytes <= _MB:
        return (nbytes + 511) & ~511
    if nbytes <= 32 * _MB:
        return (nbytes + _MB - 1) & ~(_MB - 1)
    return (nbytes + 8 * _MB - 1) & ~(8 * _MB - 1)


class PooledAllocator:
    """Size-classed caching allocator with peak usage statistics."""

    def __init__(self, pooled: bool = True):
        self.pooled = pooled
        self._free: dict[int, list["_PooledBuffer"]] = {}
        # A training step holds dozens
        # of same-class activation buffers live at once; with a small cap
        # every overflow goes to cuMemFree (which *synchronizes the
        # device*) and the matching cuMemAlloc — hundreds of driver calls
        # per step, CPU-side stall. 256 covers the steady-state working
        # set (reserved then tracks peak allocated, ~10 GiB for the
        # char-GPT); size-class rounding still caps fragmentation, and
        # the env var allows tightening for leak hunts.
        self.max_free_per_class = int(
            os.environ.get("MT_POOL_MAX_FREE", "256"))
        self.allocated = 0      # bytes currently checked out
        self.reserved = 0       # bytes the pool holds (free + in use)
        self.peak_allocated = 0
        self.peak_reserved = 0
        # CUDA graph capture (runtime/graph.py): while recording, every
        # alloc is echoed here so the graph's whole device footprint can
        # be pinned afterwards (a pinned address is never handed out
        # again — the replayed kernels keep writing/reading it).
        self._record: list | None = None

    # -- Buffer protocol ----------------------------------------------------

    def alloc(self, numel: int, dtype: DType) -> Buffer:
        want = numel * dtype.itemsize
        nbytes = _size_class(want) if self.pooled else want
        if self.pooled:
            lst = self._free.get(nbytes)
            if lst:
                buf = lst.pop()
                ev = buf._sync_event
                if ev is not None:
                    # cross-stream reuse: order the reusing stream
                    # after the point up to which the buffer's home stream
                    # used it. Same-stream reuse needs nothing (FIFO).
                    buf._sync_event = None
                    pool = _streams.default_pool()
                    cur = _drv._current_launch_stream
                    if cur != buf.home_stream:
                        pool.wait(cur, ev)
                    pool.recycle(ev)
                buf.home_stream = _drv._current_launch_stream
                buf.dtype = dtype
                buf.nelem = nbytes // dtype.itemsize
                buf.nbytes = nbytes
                buf._freed = False
                self.allocated += nbytes
                self.peak_allocated = max(self.peak_allocated, self.allocated)
                if self._record is not None:
                    self._record.append(buf)
                return buf
        buf = _PooledBuffer(self, nbytes, dtype)
        buf.home_stream = _drv._current_launch_stream
        self.allocated += nbytes
        self.reserved += nbytes
        self.peak_allocated = max(self.peak_allocated, self.allocated)
        self.peak_reserved = max(self.peak_reserved, self.reserved)
        if self._record is not None:
            self._record.append(buf)
        return buf

    def release(self, buf: "_PooledBuffer"):
        self.allocated -= buf.nbytes
        if self.pooled:
            lst = self._free.setdefault(buf.nbytes, [])
            if len(lst) >= self.max_free_per_class:
                # free-list cap: overflow buffers go back to CUDA. The cap
                # bounds per-class retention so reserved bytes cannot track
                # the union of every transient size ever seen (with the
                # 256 default this only trips for pathological
                # many-live-same-class patterns). cuMemFree synchronizes
                # the device, so no cross-stream guard is needed here.
                self.reserved -= buf.nbytes
                buf.device.free(buf.ptr)
            else:
                if buf.home_stream:
                    # the home stream may still have this buffer's last
                    # uses in flight; attach the point a different-stream
                    # reuse must wait on (see alloc). Scope-exit joins
                    # usually subsume it; this is the belt for releases
                    # that outlive their scope.
                    pool = _streams.default_pool()
                    buf._sync_event = pool.record(buf.home_stream)
                lst.append(buf)
        else:
            self.reserved -= buf.nbytes
            buf.device.free(buf.ptr)  # _freed already set by _PooledBuffer.free

    # -- statistics -----------------------------------------------------------

    def release_all_free(self):
        """Return every pooled free block to CUDA. Between-model memory
        hygiene: the pool's per-class retention otherwise accumulates the
        union of every transient size seen across many sequential
        workloads in one process (e.g. benchmarks running dozens of
        model/block combos), eventually exhausting the device. Pinned
        graph buffers are never in the free lists, so captures survive.
        """
        if not self.pooled:
            return
        for lst in self._free.values():
            for buf in lst:
                self.reserved -= buf.nbytes
                if buf._sync_event is not None:
                    # same recycle as unpin_buffers: the event handle
                    # goes back to the pool instead of leaking
                    _streams.default_pool().recycle(buf._sync_event)
                    buf._sync_event = None
                buf.device.free(buf.ptr)
        self._free.clear()

    def memory_stats(self) -> dict:
        return {
            "allocated_bytes": self.allocated,
            "reserved_bytes": self.reserved,
            "peak_allocated_bytes": self.peak_allocated,
            "peak_reserved_bytes": self.peak_reserved,
            "pool_free_bytes": self.reserved - self.allocated,
            "num_free_buffers": sum(len(v) for v in self._free.values()),
        }

    def reset_peak_stats(self):
        self.peak_allocated = self.allocated
        self.peak_reserved = self.reserved

    # -- CUDA graph footprint pinning ----------------------------------------

    def pin_buffers(self, bufs) -> list:
        """Evict every currently-free buffer whose address appears in
        ``bufs`` from the free lists, permanently reserving the address.
        A captured CUDA graph reads/writes those addresses on every
        replay, so the pool must never hand them to a later allocation.
        Buffers still live are left to their owners (the graph consumer
        holds them). Returns the pinned buffers (keep to unpin later)."""
        want = {b.ptr for b in bufs}
        pinned = []
        for lst in self._free.values():
            keep = []
            for b in lst:
                (pinned if b.ptr in want else keep).append(b)
            lst[:] = keep
        return pinned

    def unpin_buffers(self, pinned) -> None:
        """Return pinned buffers to their free lists (graph teardown)."""
        for b in pinned:
            b._freed = True
            b.home_stream = 0
            if b._sync_event is not None:
                _streams.default_pool().recycle(b._sync_event)
                b._sync_event = None
            self._free.setdefault(b.nbytes, []).append(b)


class _PooledBuffer(Buffer):
    def __init__(self, pool: PooledAllocator, nbytes: int, dtype: DType):
        # Buffer.__init__ computes nbytes from nelem; we allocate by bytes.
        super().__init__((nbytes + dtype.itemsize - 1) // dtype.itemsize,
                         dtype)
        self.nbytes = nbytes
        self.nelem = nbytes // dtype.itemsize
        self._pool = pool
        # live tensor owners (Tensor._make increments, Tensor.__del__
        # decrements and frees at 0); deterministic pool returns that do
        # not rely on Buffer.__del__ timing
        self._owners = 0
        # cross-stream reuse guard (see PooledAllocator.alloc/release)
        self.home_stream = 0
        self._sync_event = None

    def free(self):
        if not self._freed:
            self._freed = True
            self._pool.release(self)


_ALLOCATOR = PooledAllocator(pooled=os.environ.get("MT_ALLOCATOR", "on")
                             != "off")


def _alloc(numel: int, dtype: DType) -> Buffer:
    """Device allocation for numel elements, padded to a 4-byte multiple so
    memset32 fill never writes past the end."""
    nbytes = numel * dtype.itemsize
    pad = (-nbytes) % 4
    return _ALLOCATOR.alloc(numel + pad // dtype.itemsize, dtype)


def memory_stats() -> dict:
    """Allocator counters: allocated/reserved bytes (+peaks) and pool fill."""
    return _ALLOCATOR.memory_stats()


def release_all_free():
    """Return every pooled free block to CUDA (see PooledAllocator)."""
    _ALLOCATOR.release_all_free()


def reset_peak_stats():
    """Reset peak counters to the current levels (e.g. after warmup)."""
    _ALLOCATOR.reset_peak_stats()
