"""CPU eager backend: numpy implementations of the eager primitives.

This is the numerical oracle for the CUDA backend;
it only needs to be correct, not fast. Functions here receive/return
``Tensor`` objects on device "cpu" with the same signatures as the CUDA
backend's eager entry points (the shared layer in minitriton/ops/ does
shape and dtype normalization before dispatching). A few fused fast
paths have no CPU twin: ``kda_forward_fused`` composes from the
unfused primitives on CPU, and the qkv-packed flash variants are
CUDA-only (their callers guard on device).
"""

from __future__ import annotations

import numpy as np

from ...frontend import types as tl_types
from ...tensor import Tensor, np_dtype_of


def _wrap(arr: np.ndarray, dtype=None) -> Tensor:
    arr = np.asarray(arr)
    if dtype is not None and arr.dtype != np_dtype_of(dtype):
        arr = arr.astype(np_dtype_of(dtype))
    return Tensor._make(arr, arr.shape, dtype or _dtype(arr), "cpu")


def _dtype(arr):
    from ...tensor import dtype_of_numpy
    return dtype_of_numpy(arr)


# ---------------------------------------------------------------------------
# elementwise
# ---------------------------------------------------------------------------

_GELU_C = 0.7978845608028654  # sqrt(2/pi)


def _erf_np(x):
    """Exact erf reference (oracle only): math.erf vectorized."""
    import math
    return np.vectorize(math.erf)(x)


def _gelu_bw_np(g, x):
    u = _GELU_C * (x + 0.044715 * x**3)
    t = np.tanh(u)
    return g * (0.5 * (1.0 + t) + 0.5 * x * (1.0 - t**2) * _GELU_C
                * (1.0 + 3.0 * 0.044715 * x**2))


def _gelu_bw_erf_np(g, x):
    # d/dx gelu = 0.5*(1+erf(x/sqrt(2))) + x*exp(-x^2/2)/sqrt(2*pi)
    return g * (0.5 * (1.0 + _erf_np(x * 0.7071067811865476))
                + 0.3989422804014327 * x * np.exp(-0.5 * x * x))


def _silu_bw_np(g, x):
    s = 1.0 / (1.0 + np.exp(-x))
    return g * (s * (1.0 + x * (1.0 - s)))


_UNARY_NP = {
    "neg": lambda x: -x,
    "abs": np.abs,
    "relu": lambda x: np.maximum(x, 0),
    "exp": np.exp,
    "log": np.log,
    "sqrt": np.sqrt,
    "tanh": np.tanh,
    "sigmoid": lambda x: 1.0 / (1.0 + np.exp(-x)),
    # stable log(sigmoid(x)) = min(x, 0) - log(1 + exp(-|x|)) (KDA)
    "log_sigmoid": lambda x: np.where(x > 0, 0.0, x)
                            - np.log(np.exp(-np.abs(x)) + 1.0),
    "gelu": lambda x: 0.5 * x * (1.0 + np.tanh(_GELU_C * (x + 0.044715 * x**3))),
    "silu": lambda x: x / (1.0 + np.exp(-x)),
}

_BINARY_NP = {
    "add": lambda a, b: a + b,
    "sub": lambda a, b: a - b,
    "mul": lambda a, b: a * b,
    "div": lambda a, b: a / b,
    "pow": np.power,
    # backward exprs: (g, x-or-y) -> input grad
    "relu_bw": lambda g, x: g * (x > 0),
    "abs_bw": lambda g, x: g * np.sign(x),
    "gelu_bw": _gelu_bw_np,
    "silu_bw": _silu_bw_np,
    "sigmoid_bw": lambda g, y: g * y * (1.0 - y),
    "tanh_bw": lambda g, y: g * (1.0 - y * y),
    # comparisons: f32 1.0/0.0 mask, same convention as the CUDA side
    "eq": lambda a, b: (a == b).astype(np.float32),
    "ne": lambda a, b: (a != b).astype(np.float32),
    "lt": lambda a, b: (a < b).astype(np.float32),
    "le": lambda a, b: (a <= b).astype(np.float32),
    "gt": lambda a, b: (a > b).astype(np.float32),
    "ge": lambda a, b: (a >= b).astype(np.float32),
}


# gelu default = erf-exact (torch semantics), matching the CUDA tables;
# MT_GELU_TANH=1 keeps the tanh reference.
from ... import precision as _prec  # noqa: E402

if _prec.gelu_erf():
    _UNARY_NP["gelu"] = lambda x: 0.5 * x * (
        1.0 + _erf_np(x * 0.7071067811865476))
    _BINARY_NP["gelu_bw"] = _gelu_bw_erf_np


def unary(op: str, a: Tensor, out_dtype) -> Tensor:
    x = a._storage
    if a.dtype != out_dtype:
        x = x.astype(np_dtype_of(out_dtype))
    return _wrap(_UNARY_NP[op](x), out_dtype)


_CMP_OPS = frozenset(("eq", "ne", "lt", "le", "gt", "ge"))


def binary(op: str, a: Tensor, b: Tensor, out_dtype) -> Tensor:
    x, y = a._storage, b._storage
    npt = np_dtype_of(out_dtype)
    if op in _CMP_OPS:
        # comparisons compute in the promoted input dtype (exact ints);
        # pre-casting to the f32 output would round past 2^24
        ct = np.promote_types(x.dtype, y.dtype)
        if x.dtype != ct:
            x = x.astype(ct)
        if y.dtype != ct:
            y = y.astype(ct)
    else:
        if x.dtype != npt:
            x = x.astype(npt)
        if y.dtype != npt:
            y = y.astype(npt)
    return _wrap(_BINARY_NP[op](x, y), out_dtype)


def binary_scalar(op: str, a: Tensor, s, side: str, out_dtype) -> Tensor:
    x = a._storage
    npt = np_dtype_of(out_dtype)
    if op not in _CMP_OPS and x.dtype != npt:
        x = x.astype(npt)
    fn = _BINARY_NP[op]
    out = fn(x, s) if side == "r" else fn(s, x)
    return _wrap(out, out_dtype)


# ---------------------------------------------------------------------------
# fused elementwise forward ops (case-fusions)
# ---------------------------------------------------------------------------

def swiglu(a: Tensor, b: Tensor, out_dtype) -> Tensor:
    """silu(a) * b — numpy oracle for the fused CUDA kernel."""
    x, y = a._storage, b._storage
    npt = np_dtype_of(out_dtype)
    if x.dtype != npt:
        x = x.astype(npt)
    if y.dtype != npt:
        y = y.astype(npt)
    return _wrap(x / (1.0 + np.exp(-x)) * y, out_dtype)


# ---------------------------------------------------------------------------
# movement
# ---------------------------------------------------------------------------

def contiguous(a: Tensor) -> Tensor:
    return _wrap(np.ascontiguousarray(a._storage), a.dtype)


def astype(a: Tensor, dtype) -> Tensor:
    return _wrap(a._storage.astype(np_dtype_of(dtype)), dtype)


def cat(tensors: list[Tensor], dim: int, out_dtype) -> Tensor:
    arrs = [t._storage for t in tensors]
    return _wrap(np.concatenate(arrs, axis=dim), out_dtype)


# ---------------------------------------------------------------------------
# matmul
# ---------------------------------------------------------------------------

def matmul(a: Tensor, b: Tensor) -> Tensor:
    return _wrap(a._storage @ b._storage)


def bmm(a: Tensor, b: Tensor) -> Tensor:
    return _wrap(np.matmul(a._storage, b._storage))


# ---------------------------------------------------------------------------
# reduction primitives (shared layer handles dim/keepdim juggling)
# ---------------------------------------------------------------------------

def reduce_row(op: str, x2d: Tensor, out_dtype) -> Tensor:
    fn = {"sum": np.sum, "max": np.max, "min": np.min}[op]
    return _wrap(fn(x2d._storage, axis=1), out_dtype)


def reduce_full(op: str, x: Tensor, out_dtype) -> Tensor:
    fn = {"sum": np.sum, "max": np.max, "min": np.min}[op]
    return _wrap(fn(x._storage), out_dtype)


def argmax_rows(x2d: Tensor) -> Tensor:
    return _wrap(np.argmax(x2d._storage, axis=1), tl_types.int64)


# ---------------------------------------------------------------------------
# nn primitives (row-wise: x is (R, C))
# ---------------------------------------------------------------------------

def softmax_rows(x2d: Tensor, log: bool) -> Tensor:
    x = x2d._storage
    z = x - x.max(axis=1, keepdims=True)
    e = np.exp(z)
    if log:
        return _wrap(z - np.log(e.sum(axis=1, keepdims=True)))
    return _wrap(e / e.sum(axis=1, keepdims=True))


def layer_norm_rows(x2d: Tensor, w, b, eps: float) -> Tensor:
    x = x2d._storage
    mean = x.mean(axis=1, keepdims=True)
    var = x.var(axis=1, keepdims=True)
    y = (x - mean) / np.sqrt(var + eps)
    if w is not None:
        y = y * w._storage
    if b is not None:
        y = y + b._storage
    return _wrap(y)


def add_layernorm_rows(x2d: Tensor, res2d: Tensor, w, b, eps: float,
                       need_sum: bool = False):
    """Fused residual-add + layer_norm — numpy oracle. Returns (out, s)
    with s = x + res when need_sum else None."""
    s = x2d._storage + res2d._storage
    mean = s.mean(axis=1, keepdims=True)
    var = s.var(axis=1, keepdims=True)
    y = (s - mean) / np.sqrt(var + eps)
    if w is not None:
        y = y * w._storage
    if b is not None:
        y = y + b._storage
    return _wrap(y), (_wrap(s) if need_sum else None)


def rms_norm_rows(x2d: Tensor, w, eps: float) -> Tensor:
    x = x2d._storage
    ms = (x * x).mean(axis=1, keepdims=True)
    y = x / np.sqrt(ms + eps)
    if w is not None:
        y = y * w._storage
    return _wrap(y)


def embedding_rows(w2d: Tensor, idx1d: Tensor) -> Tensor:
    return _wrap(w2d._storage[idx1d._storage])


def cross_entropy_rows(x2d: Tensor, t1d: Tensor) -> Tensor:
    x = x2d._storage
    z = x - x.max(axis=1, keepdims=True)
    lse = np.log(np.exp(z).sum(axis=1)) + x.max(axis=1)
    xt = x[np.arange(x.shape[0]), t1d._storage]
    return _wrap(lse - xt)


# ---------------------------------------------------------------------------
# backward primitives (oracle for the CUDA kernels)
# ---------------------------------------------------------------------------

def softmax_backward_rows(g2d: Tensor, y2d: Tensor) -> Tensor:
    g, y = g2d._storage, y2d._storage
    s = (g * y).sum(axis=1, keepdims=True)
    return _wrap(y * (g - s))


def log_softmax_backward_rows(g2d: Tensor, y2d: Tensor) -> Tensor:
    g, y = g2d._storage, y2d._storage
    s = g.sum(axis=1, keepdims=True)
    return _wrap(g - np.exp(y) * s)


def layernorm_backward_rows(g2d: Tensor, x2d: Tensor, w, eps: float):
    g, x = g2d._storage, x2d._storage
    c = x.shape[1]
    mean = x.mean(axis=1, keepdims=True)
    var = x.var(axis=1, keepdims=True)
    rstd = 1.0 / np.sqrt(var + eps)
    xhat = (x - mean) * rstd
    u = g if w is None else g * w._storage
    dx = rstd * (u - u.mean(axis=1, keepdims=True)
                 - xhat * (u * xhat).mean(axis=1, keepdims=True))
    return _wrap(dx), _wrap(xhat)


def rmsnorm_backward_rows(g2d: Tensor, x2d: Tensor, w, eps: float):
    g, x = g2d._storage, x2d._storage
    ms = (x * x).mean(axis=1, keepdims=True)
    rstd = 1.0 / np.sqrt(ms + eps)
    xr = x * rstd
    u = g if w is None else g * w._storage
    dx = rstd * (u - xr * (u * xr).mean(axis=1, keepdims=True))
    return _wrap(dx), _wrap(xr)


def cross_entropy_backward_rows(x2d: Tensor, t1d: Tensor, grows: Tensor) -> Tensor:
    x = x2d._storage
    z = x - x.max(axis=1, keepdims=True)
    e = np.exp(z)
    p = e / e.sum(axis=1, keepdims=True)
    p[np.arange(x.shape[0]), t1d._storage] -= 1.0
    return _wrap(p * grows._storage[:, None])


def embedding_backward_rows(g2d: Tensor, idx1d: Tensor, num_rows: int) -> Tensor:
    dw = np.zeros((num_rows, g2d._storage.shape[1]),
                  dtype=g2d._storage.dtype)
    np.add.at(dw, idx1d._storage, g2d._storage)
    return _wrap(dw)


def copy_into_view(dst_view: Tensor, src: Tensor):
    np.copyto(dst_view._storage, src._storage)


def adamw_step(p: Tensor, g: Tensor, m: Tensor, v: Tensor, lr_t: float,
               wd_lr: float, b1: float, b2: float, eps: float,
               torch_eps: bool = False, s2: float = 1.0):
    m._storage[...] = b1 * m._storage + (1.0 - b1) * g._storage
    v._storage[...] = b2 * v._storage + (1.0 - b2) * g._storage ** 2
    if torch_eps:
        p._storage[...] = (
            p._storage - wd_lr * p._storage
            - lr_t * m._storage / (np.sqrt(v._storage) / s2 + eps))
    else:
        p._storage[...] = (p._storage - wd_lr * p._storage
                           - lr_t * m._storage / (np.sqrt(v._storage) + eps))


def flash_attention_forward(q: Tensor, k: Tensor, v: Tensor, scale: float,
                            with_lse: bool = False,
                            precision: str | None = None):
    raise NotImplementedError(
        "flash attention forward is CUDA-only; use the unfused composition "
        "(nn.attention.unfused_causal_attention) on CPU")


def flash_attention_backward(q: Tensor, k: Tensor, v: Tensor, o: Tensor,
                             do: Tensor, lse: Tensor, scale: float,
                             precision: str | None = None):
    raise NotImplementedError(
        "flash attention backward is CUDA-only; use the unfused composite "
        "backward on CPU")


# ---------------------------------------------------------------------------
# KDA (Kimi Delta Attention) forward.
#   S_t = (I - beta k k^T) Diag(alpha) S_{t-1} + beta k v^T ; o_t = S_t^T q_t
# Chunkwise closed form (chunk C=64) in fp64 — the numerical oracle of the
# CUDA kernels (validated against the naive recurrence at 1.8e-14).
# ---------------------------------------------------------------------------

_KDA_CHUNK = 64


def _kda_chunk_np(kn, qn, v, beta, loga, s0=None):
    """fp64 chunkwise KDA forward on *preprocessed* inputs.

    kn/qn (B, H, T, dk) l2-normalized, v (B, H, T, dv), beta (B, H, T) in
    (0, 1), loga (B, H, T, dk) log decay gates, s0 (B, H, dk, dv) or None.
    Returns (o, S_end) as fp64 arrays. C stays a parameter of the math
    (the GPU kernels hardwire C=64)."""
    dt = np.float64
    kn, qn, v = (np.asarray(x, dt) for x in (kn, qn, v))
    beta, loga = np.asarray(beta, dt), np.asarray(loga, dt)
    B, H, T, dk = kn.shape
    dv = v.shape[-1]
    C = _KDA_CHUNK
    NC = (T + C - 1) // C

    def _pad(x):
        n = NC * C - x.shape[2]
        if n == 0:
            return x
        pad = [(0, 0)] * x.ndim
        pad[2] = (0, n)
        return np.pad(x, pad)

    kn, qn, v, loga, beta = (_pad(x) for x in (kn, qn, v, loga, beta))
    o = np.zeros((B, H, NC * C, dv), dtype=dt)
    S = np.zeros((B, H, dk, dv), dtype=dt) if s0 is None \
        else np.asarray(s0, dt).copy()
    eye = np.eye(C, dtype=dt)
    strict = np.tril(np.ones((C, C), dtype=dt), -1)
    incl = np.tril(np.ones((C, C), dtype=dt))
    for b in range(B):
        for h in range(H):
            s = S[b, h]
            for c in range(NC):
                lo = c * C
                loga_c = loga[b, h, lo:lo + C]
                g = np.cumsum(loga_c, axis=0)            # (C, dk) inclusive
                gT = g[-1]                               # chunk-end decay
                d = np.exp(g)
                kn_c = kn[b, h, lo:lo + C]
                delta = d * kn_c                         # read keys
                qhat = d * qn[b, h, lo:lo + C]
                wtil = beta[b, h, lo:lo + C][:, None] * kn_c / d  # write keys
                L = (delta @ wtil.T) * strict
                M = np.linalg.inv(eye + L)               # exact UT inverse
                e0 = delta @ s
                vt = M @ (v[b, h, lo:lo + C] - e0)       # pseudo-values
                o[b, h, lo:lo + C] = qhat @ s + ((qhat @ wtil.T) * incl) @ vt
                wtT = beta[b, h, lo:lo + C][:, None] * kn_c \
                    * np.exp(gT[None, :] - g)            # tail-shifted writes
                s = np.exp(gT)[:, None] * s + wtT.T @ vt
            S[b, h] = s
    return o[:, :, :T], S


def kda_forward(kn, qn, v, beta, loga, g, gt, cshift, emc, s0,
                output_final_state: bool):
    """CPU backend for ops.kda_forward: numpy chunkwise oracle in fp64
    (returned as f32 tensors, like the CUDA backend). g/gt/cshift/emc are
    computed by the shared layer for the CUDA kernels and ignored here —
    the oracle recomputes all decay bookkeeping from loga in fp64."""
    o, s = _kda_chunk_np(kn._storage, qn._storage, v._storage,
                         beta._storage, loga._storage,
                         None if s0 is None else s0._storage)
    o_t = _wrap(o.astype(np.float32))
    s_t = _wrap(s.astype(np.float32))
    return (o_t, s_t) if output_final_state else o_t


def l2norm_rows(x2d: Tensor) -> Tensor:
    x = x2d._storage
    return _wrap(x / np.sqrt((x * x).sum(axis=1, keepdims=True)))


# ---------------------------------------------------------------------------
# sparse / message passing primitives
# numpy/scipy oracle for the CUDA kernels.
# ---------------------------------------------------------------------------

def gather_flat(x1d: Tensor, idx1d: Tensor) -> Tensor:
    return _wrap(x1d._storage[idx1d._storage])


def scatter_add_flat(src1d: Tensor, idx1d: Tensor, num_rows: int) -> Tensor:
    out = np.zeros((num_rows,), dtype=src1d._storage.dtype)
    np.add.at(out, idx1d._storage, src1d._storage)
    return _wrap(out)


def gather_cols(x2d: Tensor, idx2d: Tensor) -> Tensor:
    return _wrap(np.take_along_axis(x2d._storage, idx2d._storage, axis=1))


def gather_rc(x2d: Tensor, idx2d: Tensor) -> Tensor:
    return _wrap(x2d._storage[idx2d._storage,
                              np.arange(idx2d.shape[1], dtype=np.int64)])


def gather_cols_backward(g2d: Tensor, idx2d: Tensor, C: int) -> Tensor:
    dx = np.zeros((idx2d.shape[0], C), dtype=g2d._storage.dtype)
    rows = np.arange(idx2d.shape[0], dtype=np.int64)[:, None]
    np.add.at(dx, (rows, idx2d._storage), g2d._storage)
    return _wrap(dx)


def gather_rc_backward(g2d: Tensor, idx2d: Tensor, N: int) -> Tensor:
    dx = np.zeros((N, idx2d.shape[1]), dtype=g2d._storage.dtype)
    cols = np.arange(idx2d.shape[1], dtype=np.int64)
    np.add.at(dx, (idx2d._storage, cols), g2d._storage)
    return _wrap(dx)


def segment_reduce_values(v1d: Tensor, rp1d: Tensor, op: str) -> Tensor:
    v, rp = v1d._storage, rp1d._storage
    R = rp.shape[0] - 1
    out = np.zeros((R,), dtype=v.dtype)
    for r in range(R):
        s, e = int(rp[r]), int(rp[r + 1])
        if e > s:
            out[r] = v[s:e].sum() if op == "sum" else v[s:e].max()
        elif op == "max":
            out[r] = float("-inf")  # neutral element of an empty segment
    return _wrap(out)


def segment_reduce_backward(g1d: Tensor, v1d: Tensor, rp1d: Tensor,
                            op: str) -> Tensor:
    g, v, rp = g1d._storage, v1d._storage, rp1d._storage
    R = rp.shape[0] - 1
    gv = np.zeros(v.shape, dtype=v.dtype)
    for r in range(R):
        s, e = int(rp[r]), int(rp[r + 1])
        if e <= s:
            continue
        if op == "sum":
            gv[s:e] = g[r]
        else:
            gv[s:e] = np.where(v[s:e] == v[s:e].max(), g[r], 0.0)
    return _wrap(gv)


def spmm_csr_forward(rp1d: Tensor, col1d: Tensor, val1d: Tensor,
                     b2d: Tensor) -> Tensor:
    from scipy.sparse import csr_matrix
    rp, col, val = rp1d._storage, col1d._storage, val1d._storage
    R = rp.shape[0] - 1
    a = csr_matrix((val, col, rp), shape=(R, b2d.shape[0]),
                   dtype=np.float32)
    return _wrap(np.asarray(a @ b2d._storage, dtype=np.float32))


def spmm_csr_backward_val(g2d: Tensor, rp1d: Tensor, col1d: Tensor,
                          b2d: Tensor) -> Tensor:
    g, rp, col, b = (g2d._storage, rp1d._storage, col1d._storage,
                     b2d._storage)
    dv = np.zeros(col.shape, dtype=np.float32)
    for r in range(rp.shape[0] - 1):
        s, e = int(rp[r]), int(rp[r + 1])
        if e > s:
            dv[s:e] = (b[col[s:e]] * g[r]).sum(axis=1)
    return _wrap(dv)


def spmm_csr_backward_dense(g2d: Tensor, rp1d: Tensor, col1d: Tensor,
                            val1d: Tensor, K_rows: int) -> Tensor:
    g, rp, col, val = (g2d._storage, rp1d._storage, col1d._storage,
                       val1d._storage)
    db = np.zeros((K_rows, g.shape[1]), dtype=np.float32)
    for r in range(rp.shape[0] - 1):
        s, e = int(rp[r]), int(rp[r + 1])
        if e > s:
            np.add.at(db, col[s:e], val[s:e, None] * g[r])
    return _wrap(db)


# ---------------------------------------------------------------------------
# searchsorted / coo_sort_by_key
# ---------------------------------------------------------------------------

def searchsorted(a1d: Tensor, v1d: Tensor, side: str) -> Tensor:
    return _wrap(np.searchsorted(a1d._storage, v1d._storage, side=side)
                 .astype(np.int32))


def coo_sort_by_key(keys1d: Tensor, vals1d: Tensor) -> tuple[Tensor, Tensor]:
    keys, vals = keys1d._storage, vals1d._storage
    perm = np.argsort(keys, kind="stable")
    return _wrap(keys[perm]), _wrap(vals[perm])
