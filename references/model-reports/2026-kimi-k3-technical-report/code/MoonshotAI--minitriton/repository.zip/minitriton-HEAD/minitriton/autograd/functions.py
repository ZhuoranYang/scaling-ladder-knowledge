"""Backward rules for the eager ops.

One ``Function`` subclass per wrapped op in ``minitriton/ops/``; view ops
(reshape/permute/slice/...) are handled by ``view_backward`` through the
tensor.py hook. Backward math reuses the public eager ops (they run under
``no_grad`` during the backward traversal, so no new tape is recorded) plus
the fused backward primitives added to the shared layer
(``ops.softmax_backward_rows`` & friends).

Contract: ``backward(ctx, g)`` returns one grad (or None) per *tensor*
argument of forward, in argument order. Integer tensors (indices/targets)
get None. ``ctx.save_for_backward`` stashes the tensors backward needs.
"""

from __future__ import annotations

import math
import os
from typing import ClassVar

from .. import precision as _prec
from ..frontend import types as tl_types
from ..tensor import Tensor, canonical_dim, canonical_dims, zeros
from .engine import Context, Function

# Shape threshold for the wgrad/dgrad side-stream overlap — a scope
# costs a few microseconds of event round-trips, so below a dw kernel
# of roughly that length the overlap cannot pay for itself. 1<<27 MACs
# is about that scale. Overridable for probing.
_OVERLAP_MIN_MACS = int(
    os.environ.get("MT_STREAM_OVERLAP_MIN_MACS", str(1 << 27)))


def _dw_overlap_ok(macs: int) -> bool:
    return _prec.stream_overlap() and macs >= _OVERLAP_MIN_MACS


# Warm-first-call set: a shape's first overlap candidate runs the
# serialized path first (autotune/timing assumes the default stream);
# later calls launch on the side stream with the same kernel + config —
# bit-identical.
_OVERLAP_WARMED: "set[tuple]" = set()


def _ops():
    from .. import ops
    return ops


def _raw(name):
    return _ops()._RAW[name]


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _unbroadcast(g: Tensor, shape, dtype=None) -> Tensor:
    """Sum g down to a broadcast-compatible shape (torch's grad rule).
    dtype (optional) overrides the sum's output dtype (e.g. f32 param
    grads summed from a bf16 grad tensor — f32 accumulate either way)."""
    shape = tuple(shape)
    # fast path: several reduced LEADING dims of a contiguous g fold into
    # one 2D column-sum via a free reshape (the per-dim loop below
    # materializes a permuted copy + a (prod(lead), shape[0]) row-reduce
    # per dim — e.g. the (B, T, C) -> (C,) bias grads do a 1.3M-row
    # 32-wide reduce per Linear per step)
    if len(shape) < g.ndim and g.is_contiguous() and g.numel():
        lead = g.ndim - len(shape)
        nfold = 1
        for s in g.shape[:lead]:
            nfold *= s
        if nfold:
            g = g.reshape((nfold,) + tuple(g.shape[lead:]))
            g = g.sum(dim=0, dtype=dtype)
            for d in range(len(shape)):
                if shape[d] == 1 and g.shape[d] != 1:
                    g = g.sum(dim=d, keepdim=True, dtype=dtype)
            return g.reshape(shape) if g.shape != shape else g
    while g.ndim > len(shape):
        g = g.sum(dim=0, dtype=dtype)
    for d in range(len(shape)):
        if shape[d] == 1 and g.shape[d] != 1:
            g = g.sum(dim=d, keepdim=True, dtype=dtype)
    return g.reshape(shape) if g.shape != shape else g


def _bw(op: str, g: Tensor, x: Tensor) -> Tensor:
    """Elementwise backward expr (relu_bw/gelu_bw/...) via the shared layer.

    Mixed-precision grad contract: when the forward edge was bf16
    (x bf16) and the upstream grad rides the f32 grad chain, the result
    stores bf16 — the grad of a bf16-valued interior edge is bf16
    (torch AMP's own semantics: its elementwise backwards emit bf16).
    The store's cvt.rn is the same rounding the mma f32-staged pack
    would apply, so the mma consumers (Linear/Matmul backwards) produce
    bit-identical da/dw off the bf16 tensor while its write and both
    staged reads halve."""
    if g.dtype == tl_types.float32 and x.dtype == tl_types.bfloat16 \
            and g.device == "cuda":
        return _ops()._binary_op(op, g, x, tl_types.bfloat16)
    return _ops()._binary_op(op, g, x)


def _colsum(o, x2d) -> Tensor:
    """Column sums of a 2D tensor via sum(dim=0) in <=8192-row slices
    (the row-reduce kernel caps at 8192; GPT batch*token can exceed it).
    Slices are views; each slice reduce is one permute+row-reduce."""
    R, C = x2d.shape
    if R <= 8192:
        return o.sum(x2d, dim=0)
    acc = o.sum(x2d[:8192], dim=0)
    for s in range(8192, R, 8192):
        acc = acc + o.sum(x2d[s:s + 8192], dim=0)
    return acc


def _wrap_op(name, raw, fn_cls):
    import functools

    from . import engine

    @functools.wraps(raw)
    def wrapped(*args, **kwargs):
        if engine.is_grad_enabled() and engine.any_requires_grad(args, kwargs):
            return fn_cls.apply(*args, **kwargs)
        return raw(*args, **kwargs)

    return wrapped


def install(ops_globals: dict):
    """Replace the public functions in minitriton/ops/ with autograd-aware
    wrappers; the raw versions stay reachable as ``ops._RAW[name]``."""
    mapping = {
        "add": Add, "sub": Sub, "mul": Mul, "div": Div, "pow": Pow,
        "neg": Neg, "abs": Abs, "relu": Relu, "exp": Exp, "log": Log,
        "sqrt": Sqrt, "tanh": Tanh, "sigmoid": Sigmoid, "gelu": Gelu,
        "silu": Silu, "log_sigmoid": LogSigmoid,
        "matmul": Matmul, "bmm": Bmm,
        "sum": Sum, "mean": Mean, "max": Max, "min": Min,
        "softmax": Softmax, "log_softmax": LogSoftmax,
        "layer_norm": LayerNorm, "rms_norm": RMSNorm,
        "embedding": Embedding, "cross_entropy": CrossEntropy,
        "cat": Cat, "split": Split,
        "contiguous": Contiguous, "astype": AsType,
        "broadcast_to": BroadcastTo,
        "swiglu": Swiglu, "add_layernorm": AddLayerNorm,
    }
    raw = {}
    for name, fn_cls in mapping.items():
        raw[name] = ops_globals[name]
        ops_globals[name] = _wrap_op(name, raw[name], fn_cls)
    ops_globals["_RAW"] = raw


# ---------------------------------------------------------------------------
# elementwise binary
# ---------------------------------------------------------------------------

class _Binary(Function):
    """Common machinery: remembers which operands were tensors."""

    @classmethod
    def forward(cls, ctx: Context, a, b):
        ctx.meta["a"], ctx.meta["b"] = a, b
        ctx.save_for_backward(*[t for t in (a, b) if isinstance(t, Tensor)])
        return _raw(cls.OP)(a, b)

    @classmethod
    def grads(cls, ctx: Context, g):
        a, b = ctx.meta["a"], ctx.meta["b"]
        out = []
        if isinstance(a, Tensor):
            out.append(_unbroadcast(cls.da(g, a, b, ctx), a.shape))
        if isinstance(b, Tensor):
            out.append(_unbroadcast(cls.db(g, a, b, ctx), b.shape))
        return out

    @classmethod
    def backward(cls, ctx: Context, g):
        return cls.grads(ctx, g)


class Add(_Binary):
    OP = "add"
    da = staticmethod(lambda g, a, b, ctx: g)
    db = staticmethod(lambda g, a, b, ctx: g)


class Sub(_Binary):
    OP = "sub"
    da = staticmethod(lambda g, a, b, ctx: g)
    db = staticmethod(lambda g, a, b, ctx: _ops().neg(g))


class Mul(_Binary):
    OP = "mul"
    da = staticmethod(lambda g, a, b, ctx: _ops().mul(g, b))
    db = staticmethod(lambda g, a, b, ctx: _ops().mul(g, a))


class Div(_Binary):
    OP = "div"
    da = staticmethod(lambda g, a, b, ctx: _ops().div(g, b))

    @staticmethod
    def db(g, a, b, ctx):
        o = _ops()
        return o.div(o.mul(o.neg(g), a), o.mul(b, b))


class Pow(_Binary):
    OP = "pow"

    @staticmethod
    def da(g, a, b, ctx):
        o = _ops()
        # b - 1 python-side when b is a scalar: ops on two scalars would
        # create the intermediate on the default device
        bm1 = b - 1 if not isinstance(b, Tensor) else o.sub(b, 1)
        return o.mul(g, o.mul(b, o.pow(a, bm1)))

    @staticmethod
    def db(g, a, b, ctx):
        o = _ops()
        out = ctx.saved[-1]  # forward output saved last
        if isinstance(a, Tensor):
            la = o.log(a)
        else:
            # log of a non-positive real base: forward is NaN there too
            # (pow is only real for integer exponents), so the grad is NaN
            # rather than a math-domain exception
            la = math.log(a) if a > 0 else float("nan")
        return o.mul(o.mul(g, out), la)

    @classmethod
    def forward(cls, ctx: Context, a, b):
        out = _raw("pow")(a, b)
        ctx.meta["a"], ctx.meta["b"] = a, b
        ctx.save_for_backward(*[t for t in (a, b) if isinstance(t, Tensor)],
                              out)
        return out


# ---------------------------------------------------------------------------
# elementwise unary
# ---------------------------------------------------------------------------

class _Unary(Function):
    @classmethod
    def forward(cls, ctx: Context, a):
        out = _raw(cls.OP)(a)
        ctx.save_for_backward(a, out)
        return out


class Neg(_Unary):
    OP = "neg"

    @classmethod
    def backward(cls, ctx, g):
        return [_ops().neg(g)]


class Abs(_Unary):
    OP = "abs"

    @classmethod
    def backward(cls, ctx, g):
        a, _ = ctx.saved
        return [_bw("abs_bw", g, a)]


class Relu(_Unary):
    OP = "relu"

    @classmethod
    def backward(cls, ctx, g):
        a, _ = ctx.saved
        return [_bw("relu_bw", g, a)]


class Exp(_Unary):
    OP = "exp"

    @classmethod
    def backward(cls, ctx, g):
        _, out = ctx.saved
        return [_ops().mul(g, out)]


class Log(_Unary):
    OP = "log"

    @classmethod
    def backward(cls, ctx, g):
        a, _ = ctx.saved
        return [_ops().div(g, a)]


class Sqrt(_Unary):
    OP = "sqrt"

    @classmethod
    def backward(cls, ctx, g):
        _, out = ctx.saved
        return [_ops().div(_ops().mul(g, 0.5), out)]


class Tanh(_Unary):
    OP = "tanh"

    @classmethod
    def backward(cls, ctx, g):
        _, out = ctx.saved
        return [_bw("tanh_bw", g, out)]


class Sigmoid(_Unary):
    OP = "sigmoid"

    @classmethod
    def backward(cls, ctx, g):
        _, out = ctx.saved
        return [_bw("sigmoid_bw", g, out)]


class Gelu(_Unary):
    OP = "gelu"

    @classmethod
    def backward(cls, ctx, g):
        a, _ = ctx.saved
        return [_bw("gelu_bw", g, a)]


class Silu(_Unary):
    OP = "silu"

    @classmethod
    def backward(cls, ctx, g):
        a, _ = ctx.saved
        return [_bw("silu_bw", g, a)]


class LogSigmoid(_Unary):
    OP = "log_sigmoid"

    @classmethod
    def backward(cls, ctx, g):
        a, _ = ctx.saved
        # d/dx log_sigmoid(x) = 1 - sigmoid(x)
        return [_ops().mul(g, _ops().sub(1.0, _ops().sigmoid(a)))]


# ---------------------------------------------------------------------------
# fused elementwise forward ops (case-fusions)
# ---------------------------------------------------------------------------

class Swiglu(Function):
    """out = silu(a) * b. Backward is two elementwise compositions through
    the existing generator exprs: da = silu_bw(g, a) * b, db = g * silu(a)
    (each unbroadcast to its input's shape)."""

    @classmethod
    def forward(cls, ctx, a, b):
        ctx.save_for_backward(a, b)
        return _raw("swiglu")(a, b)

    @classmethod
    def backward(cls, ctx, g):
        a, b = ctx.saved
        o = _ops()
        da = o.mul(_bw("silu_bw", g, a), b)
        db = o.mul(g, o.silu(a))
        return [_unbroadcast(da, a.shape), _unbroadcast(db, b.shape)]


# ---------------------------------------------------------------------------
# matmul / bmm
# ---------------------------------------------------------------------------

def _mm_backward(a: Tensor, b: Tensor, g: Tensor):
    o = _ops()
    if a.dtype == tl_types.bfloat16 and b.dtype == tl_types.bfloat16 \
            and a.device == "cuda":
        # mixed-precision backward (bf16 params): grads rounded to bf16
        # inside the mma kernels, f32 accumulate out — the chain between
        # layers stays fp32 (torch AMP's effective boundary).
        return _mm_backward_bf16(a, b, g)
    return _mm_backward_generic(a, b, g)


def _mm_backward_bf16(a: Tensor, b: Tensor, g: Tensor):
    o = _ops()
    f32 = tl_types.float32
    if a.ndim == 1 and b.ndim == 1:
        # dot: elementwise backward (mirrors _mm_backward_generic; the
        # grad of a bf16-valued edge through an elementwise rule follows
        # the same promotion as the f32 route)
        return o.mul(g, b), o.mul(g, a)
    if a.ndim == 1:  # (K,) @ (K,N) -> (N,)
        da = o.matmul_bf16(g, b.t(), out_dtype=f32)
        db = o.matmul_bf16(a.reshape((a.shape[0], 1)),
                           g.reshape((1, g.shape[0])), out_dtype=f32)
        return da, db
    if b.ndim == 1:  # (M,K) @ (K,) -> (M,)
        da = o.matmul_bf16(g.reshape(g.shape + (1,)),
                           b.reshape((1, b.shape[0])), out_dtype=f32)
        da = da.reshape(a.shape)
        db = o.matmul_bf16(a.t(), g, out_dtype=f32)
        return da, db
    if a.ndim == 2 and b.ndim == 2:
        return (o.matmul_bf16(g, b.t(), out_dtype=f32),
                o.matmul_bf16(a.t(), g, out_dtype=f32))
    if b.ndim == 2:  # (..., K) @ (K, N): fold batch dims (mirrors forward)
        k, n = a.shape[-1], b.shape[1]
        g2 = g.reshape((-1, n))
        da = o.matmul_bf16(g2, b.t(), out_dtype=f32).reshape(a.shape)
        db = o.matmul_bf16(a.reshape((-1, k)).t(), g2, out_dtype=f32)
        return da, db
    da = _unbroadcast(o.matmul_bf16(g, b.transpose(-1, -2), out_dtype=f32),
                      a.shape)
    db = _unbroadcast(o.matmul_bf16(a.transpose(-1, -2), g, out_dtype=f32),
                      b.shape)
    return da, db


def _mm_backward_generic(a: Tensor, b: Tensor, g: Tensor):
    o = _ops()
    if a.ndim == 1 and b.ndim == 1:
        return o.mul(g, b), o.mul(g, a)
    if a.ndim == 1:  # (K,) @ (K,N) -> (N,)
        da = o.matmul(g, b.t())
        db = o.matmul(a.reshape((a.shape[0], 1)), g.reshape((1, g.shape[0])))
        return da, db
    if b.ndim == 1:  # (M,K) @ (K,) -> (M,)
        da = o.matmul(g.reshape(g.shape + (1,)), b.reshape((1, b.shape[0])))
        da = da.reshape(a.shape)
        db = o.matmul(a.t(), g)
        return da, db
    if a.ndim == 2 and b.ndim == 2:
        return o.matmul(g, b.t()), o.matmul(a.t(), g)
    if b.ndim == 2:  # (..., K) @ (K, N): fold batch dims (mirrors forward)
        k, n = a.shape[-1], b.shape[1]
        g2 = g.reshape((-1, n))
        da = o.matmul(g2, b.t()).reshape(a.shape)
        db = o.matmul(a.reshape((-1, k)).t(), g2)
        return da, db
    # general batched: bmm + unbroadcast over broadcast batch dims
    da = _unbroadcast(o.matmul(g, b.transpose(-1, -2)), a.shape)
    db = _unbroadcast(o.matmul(a.transpose(-1, -2), g), b.shape)
    return da, db


class Matmul(Function):
    @classmethod
    def forward(cls, ctx, a, b, bias=None):
        ctx.save_for_backward(a, b)
        ctx.meta["bias_shape"] = bias.shape if bias is not None else None
        return _raw("matmul")(a, b, bias=bias)

    @classmethod
    def backward(cls, ctx, g):
        a, b = ctx.saved
        grads = list(_mm_backward(a, b, g))
        if ctx.meta["bias_shape"] is not None:
            # dbias: g summed over the dims the bias broadcast across —
            # the same rule and f32 param-grad contract as Linear
            grads.append(_unbroadcast(g, ctx.meta["bias_shape"],
                                      dtype=tl_types.float32))
        return grads


class Bmm(Matmul):
    pass


class Linear(Function):
    """y = x @ weight.T (+ bias) as ONE tape node (nn.Linear).

    Functionally the Matmul+Add composition, except the weight grad is
    computed directly in the parameter's (out, in) orientation —
    dw = g.T @ x — instead of x.T @ g plus a permute-view backward: the
    view made every Linear parameter grad a non-contiguous transpose,
    which then forced the non-contiguous scalar path in
    GradScaler.unscale_ (one CUDA upload + cuMemFree per scalar) and
    extra contiguous() copies in AdamW/clip. da math is unchanged
    (da = g @ w, same operands as _mm_backward's g @ b.t()); dw is the
    same dot products in transposed storage order; the bf16
    mixed-precision route is the same mma path (f32 grads out)."""

    @classmethod
    def forward(cls, ctx, x, weight, bias=None):
        ctx.save_for_backward(x, weight)
        ctx.meta["bias"] = bias is not None
        if bias is not None and x.dtype == tl_types.bfloat16 \
                and weight.dtype == tl_types.bfloat16 and x.device == "cuda":
            # fused bias epilogue: the bias rides the mma epilogue into
            # the f32 accumulators (cublasLt single-rounding semantics),
            # no separate broadcast-add pass
            y = _ops().matmul_bf16(x, weight.t(),
                                   out_dtype=tl_types.bfloat16, bias=bias)
            return y
        if bias is not None and x.dtype == tl_types.float32 \
                and weight.dtype == tl_types.float32 and x.device == "cuda":
            # fused fp32 bias epilogue (store_t2): the same f32 add the
            # composed route computes, bit-identical, no broadcast pass
            o = _ops()
            x2 = x.reshape((-1, weight.shape[1]))
            y = o.matmul(x2, weight.t(), bias=bias)
            return y.reshape(x.shape[:-1] + (weight.shape[0],))
        y = _raw("matmul")(x, weight.t())
        if bias is not None:
            y = _raw("add")(y, bias)
        return y

    @classmethod
    def backward(cls, ctx, g):
        x, w = ctx.saved
        o = _ops()
        out_f, in_f = w.shape
        g2 = g.reshape((-1, out_f))
        x2 = x.reshape((-1, in_f))
        if x.dtype == tl_types.bfloat16 and w.dtype == tl_types.bfloat16 \
                and x.device == "cuda":
            # same routing as _mm_backward: the (possibly f32) upstream
            # grad feeds both mma products, rounded to bf16 INSIDE the
            # kernels (cast-in-staging); grads out f32
            f32 = tl_types.float32
            okey = (g2.shape[0], out_f, in_f)
            if _dw_overlap_ok(okey[0] * out_f * in_f) \
                    and okey in _OVERLAP_WARMED:
                # dw on the side stream, da on the default stream
                # (fork/join); the engine joins at backward's end, and
                # keepalive pins the side branch's inputs until the side
                # work completes. Same kernels/configs as serialized —
                # bit-identical grads.
                from ..runtime import streams
                with streams.stream(streams.default_pool().side(),
                                    join=False):
                    dw = o.matmul_bf16(g2.t(), x2, out_dtype=f32)
                    with streams.placement(0):
                        da = o.matmul_bf16(g2, w, out_dtype=f32)
                # AFTER the scope exit: the exit has parked this scope's
                # pending entry that keepalive attaches to
                streams.keepalive(g2, x2, w)
                da = da.reshape(x.shape)
            else:
                if _dw_overlap_ok(okey[0] * out_f * in_f):
                    _OVERLAP_WARMED.add(okey)  # see _OVERLAP_WARMED note
                da = o.matmul_bf16(g2, w, out_dtype=f32).reshape(x.shape)
                dw = o.matmul_bf16(g2.t(), x2, out_dtype=f32)
        else:
            da = o.matmul(g2, w).reshape(x.shape)
            dw = o.matmul(g2.t(), x2)
        grads = [da, dw]
        if ctx.meta["bias"]:
            # param grad in f32 (fp32 master contract); a bf16 g_pre
            # sums through the direct colsum (f32 accumulate) — the
            # pre-sum bf16 rounding is torch AMP's own dbias semantics
            grads.append(_unbroadcast(g, (out_f,),
                                      dtype=tl_types.float32))
        return grads


def linear(x, weight, bias=None):
    """Autograd-aware Linear entry used by nn.Linear (records one node)."""
    from . import engine
    if engine.is_grad_enabled() and engine.any_requires_grad(
            (x, weight, bias), {}):
        return Linear.apply(x, weight, bias)
    # raw path (no tape): keep it at the shared ops layer
    y = _ops().matmul(x, weight.t())
    return _ops().add(y, bias) if bias is not None else y


# ---------------------------------------------------------------------------
# reductions
# ---------------------------------------------------------------------------

def _expand_reduced(g: Tensor, shape, dim, keepdim: bool) -> Tensor:
    """Broadcast a reduced grad back to the input shape."""
    if dim is None:
        if not keepdim:
            g = g.reshape((1,) * len(shape))
    elif not keepdim:
        dims = dim if isinstance(dim, (tuple, list)) else (dim,)
        # ascending canonical dims: each unsqueeze restores one removed
        # axis without shifting the positions of the remaining inserts
        # (unsqueeze takes a single int)
        for d in sorted(canonical_dims(dims, len(shape))):
            g = g.unsqueeze(d)
    return g.broadcast_to(shape)


class Sum(Function):
    @classmethod
    def forward(cls, ctx, a, dim=None, keepdim=False, dtype=None):
        ctx.meta.update(dim=dim, keepdim=keepdim, shape=a.shape)
        return _raw("sum")(a, dim=dim, keepdim=keepdim, dtype=dtype)

    @classmethod
    def backward(cls, ctx, g):
        return [_expand_reduced(g, ctx.meta["shape"], ctx.meta["dim"],
                                ctx.meta["keepdim"])]


class Mean(Function):
    @classmethod
    def forward(cls, ctx, a, dim=None, keepdim=False, dtype=None):
        ctx.meta.update(dim=dim, keepdim=keepdim, shape=a.shape)
        # element count of the reduced extent (same rule as ops.mean:
        # canonicalized per-dim product, so tuple/list dims work)
        if dim is None:
            n = a.numel()
        elif isinstance(dim, (tuple, list)):
            n = 1
            for d in canonical_dims(dim, a.ndim):
                n *= a.shape[d]
        else:
            n = a.shape[canonical_dim(dim, a.ndim)]
        ctx.meta["n"] = n
        return _raw("mean")(a, dim=dim, keepdim=keepdim, dtype=dtype)

    @classmethod
    def backward(cls, ctx, g):
        g2 = _expand_reduced(g, ctx.meta["shape"], ctx.meta["dim"],
                             ctx.meta["keepdim"])
        n = ctx.meta["n"]
        if n == 0:
            # mean over an empty extent: the grad broadcasts to an empty
            # tensor (nothing to scale), like torch — not a division error
            return [g2]
        return [_ops().mul(g2, 1.0 / n)]


class _MaxMin(Function):
    OP = "max"

    @classmethod
    def forward(cls, ctx, a, dim=None, keepdim=False):
        out = _raw(cls.OP)(a, dim=dim, keepdim=keepdim)
        ctx.save_for_backward(a, out)
        ctx.meta.update(dim=dim, keepdim=keepdim, shape=a.shape)
        return out

    @classmethod
    def backward(cls, ctx, g):
        a, out = ctx.saved
        y = _expand_reduced(out, a.shape, ctx.meta["dim"],
                            ctx.meta["keepdim"])
        ge = _expand_reduced(g, a.shape, ctx.meta["dim"],
                             ctx.meta["keepdim"])
        # ties share the gradient (torch routes to the first extremum)
        return [_ops().mul(_bw("eq", a, y), ge)]


class Max(_MaxMin):
    OP = "max"


class Min(_MaxMin):
    OP = "min"


# ---------------------------------------------------------------------------
# nn ops
# ---------------------------------------------------------------------------

class Softmax(Function):
    @classmethod
    def forward(cls, ctx, a, dim=-1):
        out = _raw("softmax")(a, dim=dim)
        ctx.save_for_backward(out)
        ctx.meta["dim"] = dim
        return out

    @classmethod
    def backward(cls, ctx, g):
        (out,) = ctx.saved
        # same grad-dtype contract as LayerNorm.backward: the row kernel
        # wants g in the forward dtype
        if g.dtype != out.dtype:
            g = g.astype(out.dtype)
        return [_ops().softmax_backward_rows(g, out, ctx.meta["dim"])]


class LogSoftmax(Function):
    @classmethod
    def forward(cls, ctx, a, dim=-1):
        out = _raw("log_softmax")(a, dim=dim)
        ctx.save_for_backward(out)
        ctx.meta["dim"] = dim
        return out

    @classmethod
    def backward(cls, ctx, g):
        (out,) = ctx.saved
        # same grad-dtype contract as LayerNorm.backward: the row kernel
        # wants g in the forward dtype
        if g.dtype != out.dtype:
            g = g.astype(out.dtype)
        return [_ops().log_softmax_backward_rows(g, out, ctx.meta["dim"])]


class LayerNorm(Function):
    @classmethod
    def forward(cls, ctx, a, normalized_shape, weight=None, bias=None,
                eps=1e-5, out_dtype=None):
        out = _raw("layer_norm")(a, normalized_shape, weight, bias, eps,
                                 out_dtype=out_dtype)
        ctx.save_for_backward(a, weight, bias)
        ctx.meta.update(ns=normalized_shape, eps=eps,
                        w_t=isinstance(weight, Tensor),
                        b_t=isinstance(bias, Tensor),
                        in_dtype=a.dtype)
        return out

    @classmethod
    def backward(cls, ctx, g):
        a, weight, bias = ctx.saved
        o = _ops()
        ns = ctx.meta["ns"]
        if isinstance(ns, int):
            ns = (ns,)
        c = math.prod(ns)
        # a bf16 producer (out_dtype) hands the backward the upstream grad
        # in the out dtype; the row kernel wants g in x's dtype
        if g.dtype != a.dtype:
            g = g.astype(a.dtype)
        g2 = g.reshape((g.numel() // c, c))
        x2 = a.reshape((a.numel() // c, c))
        w = weight.reshape((c,)) if weight is not None else None
        if g.device == "cuda":
            # every affine combination takes the fused path (xhat never
            # materialized); the weight-optional cases simply discard the
            # grads they do not need
            if ctx.meta["w_t"] or ctx.meta["b_t"]:
                dx2, dgamma, dbeta = o.layernorm_backward_fused(
                    g2, x2, w, ctx.meta["eps"])
                grads = [dx2.reshape(a.shape)]
                if ctx.meta["w_t"]:
                    grads.append(dgamma.reshape(weight.shape))
                if ctx.meta["b_t"]:
                    grads.append(dbeta.reshape(bias.shape))
                return grads
            return [o.layernorm_backward_dx(g2, x2, w, ctx.meta["eps"])
                    .reshape(a.shape)]
        dx2, xhat = o.layernorm_backward_rows(g2, x2, w, ctx.meta["eps"])
        grads = [dx2.reshape(a.shape)]
        if ctx.meta["w_t"]:
            grads.append(_colsum(o, o.mul(g2, xhat))
                         .reshape(weight.shape))
        if ctx.meta["b_t"]:
            grads.append(_colsum(o, g2).reshape(bias.shape))
        return grads


class AddLayerNorm(Function):
    """out = layer_norm(a + res); optionally also returns the residual sum.
    Backward reuses the fused layernorm backward on the saved sum s:
    ds = LN'(g, s) flows to BOTH a and res (d(a+res)/da = d(a+res)/dres = 1);
    with return_residual=True the upstream grad of the sum output adds in."""

    @classmethod
    def forward(cls, ctx, a, res, normalized_shape, weight=None, bias=None,
                eps=1e-5, return_residual=False):
        y, s = _raw("add_layernorm")(a, res, normalized_shape, weight, bias,
                                     eps, return_residual=True)
        ctx.save_for_backward(s, weight, bias)
        ctx.meta.update(ns=normalized_shape, eps=eps,
                        w_t=isinstance(weight, Tensor),
                        b_t=isinstance(bias, Tensor),
                        ret_res=return_residual)
        return (y, s) if return_residual else y

    @classmethod
    def backward(cls, ctx, g):
        s, weight, bias = ctx.saved
        o = _ops()
        ns = ctx.meta["ns"]
        if isinstance(ns, int):
            ns = (ns,)
        c = math.prod(ns)
        g_s = None
        if ctx.meta["ret_res"]:
            g, g_s = g
        g2 = g.reshape((g.numel() // c, c))
        s2 = s.reshape((s.numel() // c, c))
        w = weight.reshape((c,)) if weight is not None else None
        if ctx.meta["w_t"] and ctx.meta["b_t"] and g.device == "cuda":
            ds2, dgamma, dbeta = o.layernorm_backward_fused(
                g2, s2, w, ctx.meta["eps"])
            ds = ds2.reshape(s.shape)
            if g_s is not None:
                ds = o.add(ds, g_s)
            return [ds, ds, dgamma.reshape(weight.shape),
                    dbeta.reshape(bias.shape)]
        ds2, shat = o.layernorm_backward_rows(g2, s2, w, ctx.meta["eps"])
        ds = ds2.reshape(s.shape)
        if g_s is not None:
            ds = o.add(ds, g_s)
        grads = [ds, ds]  # d out / d a = d out / d res = ds
        if ctx.meta["w_t"]:
            grads.append(_colsum(o, o.mul(g2, shat)).reshape(weight.shape))
        if ctx.meta["b_t"]:
            grads.append(_colsum(o, g2).reshape(bias.shape))
        return grads


class RMSNorm(Function):
    @classmethod
    def forward(cls, ctx, a, normalized_shape, weight=None, eps=1e-6):
        out = _raw("rms_norm")(a, normalized_shape, weight, eps)
        ctx.save_for_backward(a, weight)
        ctx.meta.update(ns=normalized_shape, eps=eps,
                        w_t=isinstance(weight, Tensor))
        return out

    @classmethod
    def backward(cls, ctx, g):
        a, weight = ctx.saved
        o = _ops()
        ns = ctx.meta["ns"]
        if isinstance(ns, int):
            ns = (ns,)
        c = math.prod(ns)
        # same grad-dtype contract as LayerNorm.backward: the row kernel
        # wants g in x's dtype
        if g.dtype != a.dtype:
            g = g.astype(a.dtype)
        g2 = g.reshape((g.numel() // c, c))
        x2 = a.reshape((a.numel() // c, c))
        w = weight.reshape((c,)) if weight is not None else None
        dx2, xr = o.rmsnorm_backward_rows(g2, x2, w, ctx.meta["eps"])
        grads = [dx2.reshape(a.shape)]
        if ctx.meta["w_t"]:
            grads.append(_colsum(o, o.mul(g2, xr)).reshape(weight.shape))
        return grads


class Embedding(Function):
    @classmethod
    def forward(cls, ctx, weight, indices):
        out = _raw("embedding")(weight, indices)
        ctx.save_for_backward(indices)
        ctx.meta["w_shape"] = weight.shape
        return out

    @classmethod
    def backward(cls, ctx, g):
        (idx,) = ctx.saved
        o = _ops()
        v, c = ctx.meta["w_shape"]
        g2 = g.reshape((idx.numel(), c))
        if g2.dtype != tl_types.float32:
            # mixed-precision contract (same shape as the flash-attention
            # bf16 backward): the atomic scatter-add kernel is f32-only,
            # so compute in f32 and cast the grad back to the incoming
            # dtype
            dw = o.embedding_backward_rows(
                g2.astype(tl_types.float32), idx.reshape((idx.numel(),)), v)
            dw = dw.astype(g2.dtype)
        else:
            dw = o.embedding_backward_rows(g2, idx.reshape((idx.numel(),)),
                                           v)
        return [dw, None]


class CrossEntropy(Function):
    @classmethod
    def forward(cls, ctx, logits, target, reduction="mean"):
        out = _raw("cross_entropy")(logits, target, reduction=reduction)
        ctx.save_for_backward(logits, target)
        ctx.meta["reduction"] = reduction
        return out

    @classmethod
    def backward(cls, ctx, g):
        x, t = ctx.saved
        o = _ops()
        n, c = x.shape
        red = ctx.meta["reduction"]
        if red == "mean":
            g = o.mul(g, 1.0 / n)
        if red in ("mean", "sum"):
            grows = g.reshape((1,)).broadcast_to((n,)).contiguous()
        else:
            grows = g.reshape((n,))
        x2 = x.reshape((n, c))
        t1 = t.reshape((n,))
        dx = o.cross_entropy_backward_rows(x2, t1, grows)
        return [dx.reshape(x.shape), None]


# ---------------------------------------------------------------------------
# movement ops
# ---------------------------------------------------------------------------

class Cat(Function):
    @classmethod
    def forward(cls, ctx, tensors, dim=0):
        ts = list(tensors)
        ctx.meta.update(dim=dim % ts[0].ndim,
                        sizes=[t.shape[dim % ts[0].ndim] for t in ts])
        return _raw("cat")(ts, dim=dim)

    @classmethod
    def backward(cls, ctx, g):
        dim, sizes = ctx.meta["dim"], ctx.meta["sizes"]
        idx = [slice(None)] * g.ndim
        grads, off = [], 0
        for s in sizes:
            idx[dim] = slice(off, off + s)
            grads.append(g[tuple(idx)])
            off += s
        return grads


class Split(Function):
    @classmethod
    def forward(cls, ctx, a, split_size_or_sections, dim=0):
        out = _raw("split")(a, split_size_or_sections, dim=dim)
        ctx.meta["dim"] = dim % a.ndim
        return out

    @classmethod
    def backward(cls, ctx, gs):
        return [_raw("cat")(list(gs), dim=ctx.meta["dim"])]


class Contiguous(Function):
    @classmethod
    def forward(cls, ctx, a):
        return _raw("contiguous")(a)

    @classmethod
    def backward(cls, ctx, g):
        return [g]


class AsType(Function):
    @classmethod
    def forward(cls, ctx, a, dtype):
        ctx.meta["src_dtype"] = a.dtype
        return _raw("astype")(a, dtype)

    @classmethod
    def backward(cls, ctx, g):
        return [g.astype(ctx.meta["src_dtype"])]


class BroadcastTo(Function):
    @classmethod
    def forward(cls, ctx, a, shape):
        ctx.meta["shape"] = a.shape
        return _raw("broadcast_to")(a, shape)

    @classmethod
    def backward(cls, ctx, g):
        return [_unbroadcast(g, ctx.meta["shape"])]


# ---------------------------------------------------------------------------
# view-op backwards (tensor.py hook; op names as recorded by _record_view)
# ---------------------------------------------------------------------------

def view_backward(op: str, src: Tensor, meta, g: Tensor) -> Tensor:
    o = _ops()
    if op == "reshape":
        return g.reshape(src.shape)
    if op == "permute":
        inv = [0] * len(meta)
        for i, d in enumerate(meta):
            inv[d] = i
        return g.permute(inv)
    if op == "unsqueeze":
        return g.reshape(src.shape)
    if op == "broadcast_to":
        return _unbroadcast(g, meta)
    if op == "getitem":
        z = zeros(src.shape, src.dtype, src.device)
        o._copy_into_view(z[meta], g)
        return z
    if op == "to":
        return g.to(src.device)
    raise RuntimeError(f"unknown view op for backward: {op!r}")
