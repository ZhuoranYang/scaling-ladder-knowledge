"""Operator semantics for the DSL: broadcasting, dtype promotion, and the
value-class dispatch used by the code generator.

Value classes (see compiler/builder.py): CExpr (compile-time), Scalar,
Tensor (materialized block), SepOff (symbolic offsets), SepMask (symbolic
mask), PtrTensor (address tensor). Everything here is pure rule logic; all
MLIR emission goes through the Builder.
"""

from __future__ import annotations

from mlir import ir
from mlir.dialects import arith, vector

from ..frontend import types as tl
from ..compiler.builder import (
    Affine, Builder, CExpr, MatOff, Pred, PtrTensor, Scalar, SepMask, SepOff,
    Tensor, TileConfigError,
)
from ..compiler.layout import (
    Fragment, Replicated, Sliced, dist_layout, is_dist, is_flat,
    is_rep_like, is_t3, rep_layout,
)

_BINOP_NAME = {
    "Add": "add", "Sub": "sub", "Mult": "mul", "Div": "truediv",
    "FloorDiv": "floordiv", "Mod": "mod",
}


class SemanticsError(TileConfigError):
    """Type/broadcast rule violation with a DSL-actionable message."""


def _py_binop(op: str, a, b):
    # NB: dispatch lazily — a dict literal would evaluate every arm, so a
    # zero `b` would raise even for mul/add (context-folding +0.0/-0.0).
    if op == "add":
        return a + b
    if op == "sub":
        return a - b
    if op == "mul":
        return a * b
    if op == "truediv":
        return a / b
    if op == "floordiv":
        return a // b
    if op == "mod":
        return a % b
    raise KeyError(op)


def _py_cmp(op: str, a, b) -> bool:
    if op == "<":
        return a < b
    if op == "<=":
        return a <= b
    if op == ">":
        return a > b
    if op == ">=":
        return a >= b
    if op == "==":
        return a == b
    if op == "!=":
        return a != b
    raise KeyError(op)


_FLIP_CMP = {"<": ">", "<=": ">=", ">": "<", ">=": "<=", "==": "==", "!=": "!="}


# ---------------------------------------------------------------------------
# conversions
# ---------------------------------------------------------------------------

def materialize(b: Builder, v):
    """SepOff/SepMask -> materialized Tensor; everything else passes through."""
    if isinstance(v, SepOff):
        return b.materialize_offsets(v)
    if isinstance(v, SepMask):
        return b.materialize_mask(v)
    return v


def _to_scalar(b: Builder, v, dtype: tl.DType | None = None) -> Scalar:
    """CExpr/Scalar -> Scalar of the requested (or natural) dtype."""
    if isinstance(v, Scalar):
        if dtype is not None and v.dtype != dtype:
            return Scalar(dtype, _cast(b, v.val, v.dtype, dtype))
        return v
    if isinstance(v, CExpr):
        x = v.value
        if dtype is None:
            dtype = tl.float32 if isinstance(x, float) else tl.int32
        if dtype.is_float:
            return Scalar(dtype, b.const(dtype, float(x)))
        return Scalar(dtype, b.const(dtype, int(x)))
    raise SemanticsError(f"expected a scalar value, got {v!r}")


def _is_float_scalar(v) -> bool:
    """CExpr float literal or runtime float-dtype Scalar."""
    return (isinstance(v, CExpr) and isinstance(v.value, float)) or \
        (isinstance(v, Scalar) and v.dtype.is_float)


def _cast(b: Builder, val, src: tl.DType, dst: tl.DType):
    if src == dst:
        return val
    ty = val.type
    if isinstance(ty, ir.VectorType):
        rty = ir.VectorType.get(ty.shape, dst.mlir())
    else:
        rty = dst.mlir()
    if src == tl.int1 and dst.is_float:
        return arith.uitofp(rty, val)  # mask -> 0.0/1.0
    if src.is_int and dst.is_float:
        return arith.sitofp(rty, val)
    if src.is_float and dst.is_int:
        return arith.fptosi(rty, val)
    if src.is_int and dst.is_int and src.itemsize < dst.itemsize:
        return arith.extsi(rty, val)
    if src.is_int and dst.is_int and src.itemsize > dst.itemsize:
        return arith.trunci(rty, val)
    if src.is_float and dst.is_float and src.itemsize < dst.itemsize:
        return arith.extf(rty, val)
    if src.is_float and dst.is_float and src.itemsize > dst.itemsize:
        return arith.truncf(rty, val)
    raise SemanticsError(f"cannot cast {src} to {dst}")


def cast(b: Builder, v, dtype: tl.DType):
    """Explicit value cast (tl.cast): scalars and blocks, lane-wise."""
    v = materialize(b, v)
    if isinstance(v, CExpr):
        x = v.value
        s = Scalar(tl.float32 if isinstance(x, float) else tl.int32,
                   b.const(tl.float32 if isinstance(x, float) else tl.int32,
                           float(x) if isinstance(x, float) else int(x)))
        v = s
    if isinstance(v, Scalar):
        return Scalar(dtype, _cast(b, v.val, v.dtype, dtype))
    if isinstance(v, Tensor):
        return Tensor(dtype, v.shape, v.layout,
                      _cast(b, v.val, v.dtype, dtype), v.ept)
    raise SemanticsError(f"tl.cast expects a scalar or block, got {v!r}")


def where(b: Builder, cond, x, y):
    """tl.where(cond, x, y): lane-wise select; cond is an i1 block/mask."""
    cond = materialize(b, cond)
    if isinstance(x, (CExpr, Scalar)):
        # float scalar against an int tensor: the pair computes in f32 —
        # casting the scalar down to the int dtype would silently
        # truncate its fraction (binop's CExpr-float branch computes in
        # f32 too; the rules differ where the tensor is float)
        dt = None
        if isinstance(y, Tensor):
            dt = tl.float32 if _is_float_scalar(x) and y.dtype.is_int \
                else y.dtype
        x = _to_scalar(b, x, dt)
    if isinstance(y, (CExpr, Scalar)):
        dt = None
        if isinstance(x, Tensor):
            dt = tl.float32 if _is_float_scalar(y) and x.dtype.is_int \
                else x.dtype
        y = _to_scalar(b, y, dt)
    if isinstance(x, Scalar) and isinstance(y, Tensor):
        if x.dtype.is_float and y.dtype.is_int:
            y = _promote_tensor_dtype(b, y, x.dtype)
        x = _splat_like(b, x, y)
    if isinstance(y, Scalar) and isinstance(x, Tensor):
        if y.dtype.is_float and x.dtype.is_int:
            x = _promote_tensor_dtype(b, x, y.dtype)
        y = _splat_like(b, y, x)
    if isinstance(x, Tensor) and isinstance(y, Tensor):
        x, y = broadcast_tensors(b, x, y)
        if not isinstance(cond, Tensor) or cond.dtype != tl.int1:
            raise SemanticsError(f"tl.where cond must be an i1 block, got {cond!r}")
        if cond.shape != x.shape:
            if is_t3(x.layout) and len(cond.shape) == 1 \
                    and cond.shape[0] == x.shape[1] \
                    and is_rep_like(cond.layout):
                cond = b.bcast_rep_rows(cond, x.layout)
            elif len(cond.shape) == 1 and len(x.shape) == 2 \
                    and cond.shape[0] == x.shape[1] and is_dist(x.layout) \
                    and is_dist(cond.layout):
                vty = b.vec_type([1, cond.ept], tl.int1)
                cond = Tensor(tl.int1, (1, cond.shape[0]),
                              dist_layout((1, cond.shape[0]), b.num_threads),
                              vector.shape_cast(vty, cond.val), cond.ept)
                vty2 = b.vec_type([x.shape[0], x.ept], tl.int1)
                cond = Tensor(tl.int1, x.shape, dist_layout(x.shape, b.num_threads),
                              vector.broadcast(vty2, cond.val), cond.ept)
            else:
                raise SemanticsError(
                    f"tl.where cond shape {cond.shape} does not broadcast to "
                    f"{x.shape}")
        return Tensor(x.dtype, x.shape, x.layout,
                      b.select(cond.val, x.val, y.val), x.ept)
    if isinstance(x, Scalar) and isinstance(y, Scalar) and isinstance(cond, Scalar):
        if cond.dtype != tl.int1:
            raise SemanticsError("tl.where scalar cond must be i1")
        dt = _promote_dtype(x.dtype, y.dtype)
        xv = _cast(b, x.val, x.dtype, dt)
        yv = _cast(b, y.val, y.dtype, dt)
        return Scalar(dt, b.select(cond.val, xv, yv))
    raise SemanticsError(
        f"tl.where: unsupported operands {type(x).__name__}, "
        f"{type(y).__name__}")


def _promote_dtype(a: tl.DType, c: tl.DType) -> tl.DType:
    if a == c:
        return a
    if a.is_float and c.is_int:
        return a
    if a.is_int and c.is_float:
        return c
    if a.is_float and c.is_float:
        return a if a.itemsize >= c.itemsize else c
    if a.is_int and c.is_int:
        return a if a.itemsize >= c.itemsize else c
    return a


# ---------------------------------------------------------------------------
# tensor broadcasting
# ---------------------------------------------------------------------------

def _splat_like(b: Builder, s: Scalar, t: Tensor) -> Tensor:
    v = _cast(b, s.val, s.dtype, t.dtype) if s.dtype != t.dtype else s.val
    return Tensor(t.dtype, t.shape, t.layout, b.splat(t.val.type, v), t.ept)


def _is_frag_row_vec(t, n: int) -> bool:
    """(N,)/(1, N) small-vector value broadcastable into an mma C
    fragment of width N (the tier-1 bcast_to_frag_c source form)."""
    return isinstance(t, Tensor) and t.shape in ((n,), (1, n)) and (
        isinstance(t.layout, Replicated) or is_dist(t.layout))


def _is_rep_row(t, n: int) -> bool:
    """(N,) rep-like row vector broadcastable across the rows of a t3
    tile of width N (the per-column statistic source form)."""
    return isinstance(t, Tensor) and t.shape == (n,) and \
        is_rep_like(t.layout)


def _is_t3_col_scalar(t, m: int = None) -> bool:
    """t3 (M, 1) row-per-thread scalar value (one value per thread — the
    row statistic / row coordinate form)."""
    return isinstance(t, Tensor) and len(t.shape) == 2 \
        and t.shape[1] == 1 and is_t3(t.layout) \
        and (m is None or t.shape[0] == m)


def broadcast_tensors(b: Builder, x: Tensor, y: Tensor):
    """Bring two tensors to a common (shape, layout) for elementwise ops."""
    if x.dtype != y.dtype:
        dt = _promote_dtype(x.dtype, y.dtype)
        x = Tensor(dt, x.shape, x.layout, _cast(b, x.val, x.dtype, dt), x.ept)
        y = Tensor(dt, y.shape, y.layout, _cast(b, y.val, y.dtype, dt), y.ept)
    if x.shape == y.shape and x.layout == y.layout:
        return x, y

    # mma C fragment + (N,)/(1, N) row vector: broadcast the vector into
    # the fragment's columns via the tier-1 bcast_to_frag_c rule — the
    # mma matmul epilogue's bias add.
    if isinstance(x.layout, Fragment) and x.layout.role == "C" \
            and _is_frag_row_vec(y, x.shape[1]):
        return x, b.convert_layout(y, x.layout)
    if isinstance(y.layout, Fragment) and y.layout.role == "C" \
            and _is_frag_row_vec(x, y.shape[1]):
        return b.convert_layout(x, y.layout), y

    # t3 row-per-thread tile + (C,) rep row vector: broadcast the
    # per-column statistic across the rows (register selection only —
    # every thread already holds the whole rep vector).
    if is_t3(x.layout) and len(x.shape) == 2 and x.shape[1] > 1 \
            and _is_rep_row(y, x.shape[1]):
        return x, b.bcast_rep_rows(y, x.layout)
    if is_t3(y.layout) and len(y.shape) == 2 and y.shape[1] > 1 \
            and _is_rep_row(x, y.shape[1]):
        return b.bcast_rep_rows(x, y.layout), y

    # t3 (BM, 1) row scalar: splat its per-thread value — across the
    # columns of a t3 (BM, C) tile, or against a (C,) rep vector (the
    # result stays rep: every thread holds the whole vector).
    if is_t3(x.layout) and len(x.shape) == 2 and x.shape[1] > 1 \
            and _is_t3_col_scalar(y, x.shape[0]):
        return x, b.bcast_t3_col(y, x.layout)
    if is_t3(y.layout) and len(y.shape) == 2 and y.shape[1] > 1 \
            and _is_t3_col_scalar(x, y.shape[0]):
        return b.bcast_t3_col(x, y.layout), y
    if _is_t3_col_scalar(x) and len(y.shape) == 1 \
            and is_rep_like(y.layout):
        return b.bcast_t3_scalar_to_rep(x, y.layout), y
    if _is_t3_col_scalar(y) and len(x.shape) == 1 \
            and is_rep_like(x.layout):
        return x, b.bcast_t3_scalar_to_rep(y, x.layout)

    # (C,) dist treated as (1, C) for broadcasting against 2D dist.
    if len(x.shape) == 1 and len(y.shape) == 2 and is_dist(x.layout) \
            and is_dist(y.layout) and x.shape[0] == y.shape[1]:
        vty = b.vec_type([1, x.ept], x.dtype)
        x = Tensor(x.dtype, (1, x.shape[0]),
                   dist_layout((1, x.shape[0]), b.num_threads),
                   vector.shape_cast(vty, x.val), x.ept)
    if len(y.shape) == 1 and len(x.shape) == 2 and is_dist(y.layout) \
            and is_dist(x.layout) and y.shape[0] == x.shape[1]:
        vty = b.vec_type([1, y.ept], y.dtype)
        y = Tensor(y.dtype, (1, y.shape[0]),
                   dist_layout((1, y.shape[0]), b.num_threads),
                   vector.shape_cast(vty, y.val), y.ept)

    if len(x.shape) == 2 and len(y.shape) == 2 \
            and is_dist(x.layout) and is_dist(y.layout) and x.ept == y.ept:
        r, c = y.shape if x.shape[0] == 1 else x.shape
        if (x.shape in ((r, c), (r, 1), (1, c))) and (y.shape in ((r, c), (r, 1), (1, c))):
            vty = b.vec_type([r, x.ept], x.dtype)
            xv = vector.broadcast(vty, x.val) if x.shape != (r, c) else x.val
            yv = vector.broadcast(vty, y.val) if y.shape != (r, c) else y.val
            lay = dist_layout((r, c), b.num_threads)
            return (Tensor(x.dtype, (r, c), lay, xv, x.ept),
                    Tensor(y.dtype, (r, c), lay, yv, y.ept))

    # dist 2D broadcast against a replicated (R, 1) column (rep-like:
    # Replicated or a Sliced reduce result).
    if len(x.shape) == 2 and len(y.shape) == 2 \
            and is_dist(x.layout) and is_rep_like(y.layout) \
            and y.shape[1] == 1 and y.shape[0] == x.shape[0]:
        vty = b.vec_type([x.shape[0], x.ept], x.dtype)
        yv = vector.broadcast(vty, y.val)
        return x, Tensor(y.dtype, x.shape, dist_layout(x.shape, b.num_threads),
                         yv, x.ept)
    if len(x.shape) == 2 and len(y.shape) == 2 \
            and is_dist(y.layout) and is_rep_like(x.layout) \
            and x.shape[1] == 1 and x.shape[0] == y.shape[0]:
        vty = b.vec_type([y.shape[0], y.ept], y.dtype)
        xv = vector.broadcast(vty, x.val)
        return Tensor(x.dtype, y.shape, dist_layout(y.shape, b.num_threads),
                      xv, y.ept), y

    # replicated small tensors: numpy-style within reason
    if is_rep_like(x.layout) and is_rep_like(y.layout):
        shape = _rep_broadcast_shape(x.shape, y.shape)
        if shape is not None:
            vty = b.vec_type(list(shape), x.dtype)
            xv = vector.broadcast(vty, x.val) if x.shape != shape else x.val
            yv = vector.broadcast(vty, y.val) if y.shape != shape else y.val
            ept = 1
            for s in shape:
                ept *= s
            return (Tensor(x.dtype, shape, rep_layout(shape), xv, ept),
                    Tensor(y.dtype, shape, rep_layout(shape), yv, ept))

    if is_flat(x.layout) and is_flat(y.layout) and x.shape == y.shape:
        return x, y

    raise SemanticsError(
        f"cannot broadcast {x!r} against {y!r}: currently supports same-layout "
        "elementwise ops, scalar splat, (R,1)/(1,C) broadcast on "
        "distributed tiles, and replicated small-tensor broadcast")


def _rep_broadcast_shape(a, b):
    if a == b:
        return a
    if len(a) == 2 and len(b) == 2:
        r = a[0] if a[0] != 1 else b[0]
        c = a[1] if a[1] != 1 else b[1]
        if (a[0] in (1, r)) and (b[0] in (1, r)) and (a[1] in (1, c)) \
                and (b[1] in (1, c)):
            return (r, c)
    return None


# ---------------------------------------------------------------------------
# binary operators
# ---------------------------------------------------------------------------

def binop(b: Builder, op: str, lhs, rhs):
    # 0. compile-time on both sides
    if isinstance(lhs, CExpr) and isinstance(rhs, CExpr):
        return CExpr(_py_binop(op, lhs.value, rhs.value))

    # 1. pointer arithmetic
    if isinstance(lhs, PtrTensor):
        if op not in ("add", "sub"):
            raise SemanticsError(f"unsupported pointer arithmetic: {op}")
        sign = 1 if op == "add" else -1
        if isinstance(rhs, CExpr):
            if not isinstance(rhs.value, int):
                raise SemanticsError("pointer offsets must be integers")
            if isinstance(lhs.off, MatOff):
                return PtrTensor(lhs.arg,
                                 b.off_mat_shift(lhs.off, sign * int(rhs.value)))
            return PtrTensor(lhs.arg, b.off_shift(lhs.off, sign * int(rhs.value)))
        if isinstance(rhs, Scalar):
            if rhs.dtype != tl.int32:
                raise SemanticsError("pointer offsets must be i32 scalars")
            delta = rhs.val if sign > 0 else b._base_neg(rhs.val)
            if isinstance(lhs.off, MatOff):
                return PtrTensor(lhs.arg, b.off_mat_shift(lhs.off, delta))
            return PtrTensor(lhs.arg, b.off_shift(lhs.off, delta))
        if isinstance(rhs, SepOff):
            if sign < 0:
                raise SemanticsError("cannot subtract an offset tensor from a pointer")
            if isinstance(lhs.off, MatOff):
                return PtrTensor(lhs.arg, b.off_mat_combine(lhs.off, rhs))
            return PtrTensor(lhs.arg, b.off_combine(lhs.off, rhs, +1))
        if isinstance(rhs, Tensor):
            # materialized-index path: ptr + i32 block -> MatOff
            # address tensor; gathers/scatters emit per-lane accesses.
            if sign < 0:
                raise SemanticsError(
                    "cannot subtract an index block from a pointer")
            if isinstance(lhs.off, MatOff):
                raise SemanticsError(
                    "only one materialized index block per address; "
                    "combine index blocks arithmetically first")
            if lhs.off.shape == ():
                base = b.eval_affine(lhs.off.col, 0)
                off = b.off_mat_shift(b.off_mat(rhs), base)
            elif lhs.off.shape == rhs.shape:
                off = b.off_mat_combine(b.off_mat(rhs), lhs.off)
            else:
                raise SemanticsError(
                    f"materialized index block of shape {rhs.shape} does not "
                    f"match the symbolic offset shape {lhs.off.shape} ("
                    "scalar base or same shape only)")
            return PtrTensor(lhs.arg, off)
        raise SemanticsError(f"unsupported pointer operand: {rhs!r}")
    if isinstance(rhs, PtrTensor) and op == "add":
        return binop(b, op, rhs, lhs)

    # 2. symbolic offsets
    if isinstance(lhs, SepOff) or isinstance(rhs, SepOff):
        return _sepoff_binop(b, op, lhs, rhs)

    # 3. scalars
    lhs = materialize(b, lhs)
    rhs = materialize(b, rhs)
    if isinstance(lhs, (CExpr, Scalar)) and isinstance(rhs, (CExpr, Scalar)):
        if op == "truediv":
            x = _to_scalar(b, lhs, tl.float32)
            y = _to_scalar(b, rhs, tl.float32)
            return Scalar(tl.float32, b.binary("truediv", x.val, y.val, tl.float32))
        x = _to_scalar(b, lhs)
        y = _to_scalar(b, rhs)
        dt = _promote_dtype(x.dtype, y.dtype)
        if dt == tl.int1:
            raise SemanticsError(f"cannot apply {op} to i1 values")
        if op == "floordiv" and dt.is_float:
            raise SemanticsError("// on floats is not supported; use /")
        xv = _cast(b, x.val, x.dtype, dt)
        yv = _cast(b, y.val, y.dtype, dt)
        return Scalar(dt, b.binary(op, xv, yv, dt))

    # 4. blocks (with scalar splat)
    if isinstance(lhs, Tensor) and isinstance(rhs, Tensor):
        if _frag_elem_pair(lhs, rhs):
            _check_block_arith(op, lhs.dtype)
            return b.binop_frag(op, lhs, rhs)
        x, y = broadcast_tensors(b, lhs, rhs)
        _check_block_arith(op, x.dtype)
        return Tensor(x.dtype, x.shape, x.layout,
                      b.binary(op, x.val, y.val, x.dtype), x.ept)
    if isinstance(lhs, Tensor) and isinstance(rhs, (CExpr, Scalar)):
        # float scalar against an int tensor promotes the pair to f32 —
        # casting the scalar down to the int dtype would silently
        # truncate its fraction; CExpr float literals and runtime float
        # Scalars both follow this rule
        dt = tl.float32 if _is_float_scalar(rhs) and (
            lhs.dtype.is_int or isinstance(rhs, CExpr)) else lhs.dtype
        s = _to_scalar(b, rhs, dt)
        x = _promote_tensor_dtype(b, lhs, s.dtype)
        t = _splat_like(b, s, x)
        _check_block_arith(op, x.dtype)
        return Tensor(x.dtype, x.shape, x.layout,
                      b.binary(op, x.val, t.val, x.dtype), x.ept)
    if isinstance(rhs, Tensor) and isinstance(lhs, (CExpr, Scalar)):
        dt = tl.float32 if _is_float_scalar(lhs) and (
            rhs.dtype.is_int or isinstance(lhs, CExpr)) else rhs.dtype
        s = _to_scalar(b, lhs, dt)
        y = _promote_tensor_dtype(b, rhs, s.dtype)
        t = _splat_like(b, s, y)
        _check_block_arith(op, y.dtype)
        return Tensor(y.dtype, y.shape, y.layout,
                      b.binary(op, t.val, y.val, y.dtype), y.ept)

    raise SemanticsError(
        f"unsupported operands for {op}: {type(lhs).__name__} and "
        f"{type(rhs).__name__}")


def _frag_elem_pair(x: Tensor, y: Tensor) -> bool:
    """Should this Tensor pair take the per-element fragment path
    (builder.binop_frag)? True when both sides broadcast against one
    mma C fragment: the full Fragment("C"), or a Sliced(Fragment) row/
    column statistic, on both sides."""
    def _fk(t):
        if isinstance(t.layout, Fragment):
            return t.layout if t.layout.role == "C" else None
        if isinstance(t.layout, Sliced) \
                and isinstance(t.layout.parent, Fragment) \
                and t.layout.parent.role == "C":
            return t.layout.parent
        return None

    lx, ly = _fk(x), _fk(y)
    if lx is None or ly is None:
        return False
    # a full fragment anchors the pair; two sliced forms must share the
    # parent fragment
    return lx == ly


def _promote_tensor_dtype(b: Builder, t: Tensor, dt: tl.DType) -> Tensor:
    if t.dtype == dt:
        return t
    return Tensor(dt, t.shape, t.layout, _cast(b, t.val, t.dtype, dt), t.ept)


def _check_block_arith(op: str, dtype: tl.DType):
    if op == "truediv" and dtype.is_int:
        raise SemanticsError("/ on integer blocks is not supported; use floats")
    if op == "floordiv" and dtype.is_float:
        raise SemanticsError("// on float blocks is not supported")


def _sepoff_binop(b: Builder, op: str, lhs, rhs):
    if isinstance(lhs, SepOff) and isinstance(rhs, CExpr):
        v = rhs.value
        if not isinstance(v, int):
            raise SemanticsError("offset arithmetic requires integer constants")
        if op == "add":
            return b.off_shift(lhs, v)
        if op == "sub":
            return b.off_shift(lhs, -v)
        if op == "mul":
            return b.off_scale(lhs, v)
    if isinstance(rhs, SepOff) and isinstance(lhs, CExpr):
        v = lhs.value
        if not isinstance(v, int):
            raise SemanticsError("offset arithmetic requires integer constants")
        if op == "add":
            return b.off_shift(rhs, v)
        if op == "sub":
            return _scalar_minus_off(b, v, rhs)
        if op == "mul":
            return b.off_scale(rhs, v)
    if isinstance(lhs, SepOff) and isinstance(rhs, Scalar) and op in ("add", "sub"):
        delta = rhs.val if op == "add" else b._base_neg(rhs.val)
        return b.off_shift(lhs, delta)
    if isinstance(lhs, SepOff) and isinstance(rhs, Scalar) and op == "mul":
        return b.off_scale(lhs, rhs.val)
    if isinstance(rhs, SepOff) and isinstance(lhs, Scalar) and op == "mul":
        return b.off_scale(rhs, lhs.val)
    if isinstance(rhs, SepOff) and isinstance(lhs, Scalar) and op == "add":
        return b.off_shift(rhs, lhs.val)
    if isinstance(lhs, SepOff) and isinstance(rhs, SepOff):
        if op == "add":
            return b.off_combine(lhs, rhs, +1)
        if op == "sub":
            return b.off_combine(lhs, rhs, -1)
        raise SemanticsError(
            f"{op} of two offset tensors is not separable (currently supports +/- only)")
    raise SemanticsError(
        f"unsupported offset arithmetic: {op} between "
        f"{type(lhs).__name__} and {type(rhs).__name__}")


def _scalar_minus_off(b: Builder, v: int, off: SepOff) -> SepOff:
    neg = b.off_scale(off, -1)
    return b.off_shift(neg, v)


# ---------------------------------------------------------------------------
# comparisons
# ---------------------------------------------------------------------------

def compare(b: Builder, op: str, lhs, rhs):
    if isinstance(lhs, CExpr) and isinstance(rhs, CExpr):
        return CExpr(_py_cmp(op, lhs.value, rhs.value))

    # symbolic offsets -> symbolic masks
    if isinstance(lhs, SepOff) or isinstance(rhs, SepOff):
        if isinstance(lhs, SepOff) and isinstance(rhs, SepOff):
            raise SemanticsError(
                "comparing two offset tensors is not supported")
        if isinstance(rhs, SepMask) or isinstance(lhs, SepMask):
            raise SemanticsError("cannot compare masks")
        if isinstance(lhs, SepOff):
            return _sepoff_cmp(b, op, lhs, rhs)
        return _sepoff_cmp(b, _FLIP_CMP[op], rhs, lhs)

    lhs = materialize(b, lhs)
    rhs = materialize(b, rhs)
    if isinstance(lhs, (CExpr, Scalar)) and isinstance(rhs, (CExpr, Scalar)):
        x = _to_scalar(b, lhs)
        y = _to_scalar(b, rhs)
        dt = _promote_dtype(x.dtype, y.dtype)
        xv = _cast(b, x.val, x.dtype, dt)
        yv = _cast(b, y.val, y.dtype, dt)
        return Scalar(tl.int1, b.compare(op, xv, yv, dt))
    if isinstance(lhs, Tensor) and isinstance(rhs, Tensor):
        if _frag_elem_pair(lhs, rhs):
            return b.binop_frag(op, lhs, rhs, compare=True)
        x, y = broadcast_tensors(b, lhs, rhs)
        return Tensor(tl.int1, x.shape, x.layout,
                      b.compare(op, x.val, y.val, x.dtype), x.ept)
    if isinstance(lhs, Tensor) and isinstance(rhs, (CExpr, Scalar)):
        # float scalar against an int tensor compares in f32 — truncating
        # the scalar to the int dtype would compare against the wrong
        # bound (x < 1.5 would become x < 1), the same promotion rule
        # binop's CExpr-float branch uses
        dt = tl.float32 if _is_float_scalar(rhs) and lhs.dtype.is_int \
            else lhs.dtype
        s = _to_scalar(b, rhs, dt)
        x = _promote_tensor_dtype(b, lhs, dt)
        t = _splat_like(b, s, x)
        return Tensor(tl.int1, x.shape, x.layout,
                      b.compare(op, x.val, t.val, x.dtype), x.ept)
    if isinstance(rhs, Tensor) and isinstance(lhs, (CExpr, Scalar)):
        dt = tl.float32 if _is_float_scalar(lhs) and rhs.dtype.is_int \
            else rhs.dtype
        s = _to_scalar(b, lhs, dt)
        y = _promote_tensor_dtype(b, rhs, dt)
        t = _splat_like(b, s, y)
        return Tensor(tl.int1, y.shape, y.layout,
                      b.compare(op, t.val, y.val, y.dtype), y.ept)
    raise SemanticsError(
        f"unsupported comparison {op} between {type(lhs).__name__} and "
        f"{type(rhs).__name__}")


def _sepoff_cmp(b: Builder, op: str, off: SepOff, bound) -> SepMask:
    if isinstance(bound, CExpr):
        bound_v = bound.value
        if not isinstance(bound_v, int):
            raise SemanticsError("offset comparisons require integer bounds")
        bound = bound_v
    elif isinstance(bound, Scalar):
        if bound.dtype != tl.int32:
            raise SemanticsError("offset comparisons require i32 bounds")
        bound = bound.val
    else:
        raise SemanticsError(f"cannot compare offsets against {bound!r}")

    if len(off.shape) <= 1:
        return SepMask(off.shape, [], [Pred(off.col, op, bound)])
    # 2D: the predicate is separable only if one side is identically zero
    row_zero = b._is_zero(off.row)
    col_zero = b._is_zero(off.col)
    if col_zero:
        return SepMask(off.shape, [Pred(off.row, op, bound)], [])
    if row_zero:
        return SepMask(off.shape, [], [Pred(off.col, op, bound)])
    raise SemanticsError(
        "comparison of a 2D row+col offset tensor is not separable; compare "
        "the row and column offsets separately, e.g. "
        "mask=(offs_m < M)[:, None] & (offs_n < N)[None, :]")


# ---------------------------------------------------------------------------
# logical ops
# ---------------------------------------------------------------------------

def logical(b: Builder, op: str, lhs, rhs):
    if isinstance(lhs, CExpr) and isinstance(rhs, CExpr):
        return CExpr(bool(lhs.value) and bool(rhs.value) if op == "and"
                     else bool(lhs.value) or bool(rhs.value))
    if isinstance(lhs, SepMask) and isinstance(rhs, SepMask):
        if op == "or":
            raise SemanticsError("mask | is not supported; use &")
        return lhs.combine(rhs)
    lhs = materialize(b, lhs)
    rhs = materialize(b, rhs)
    fn = b.and_i1 if op == "and" else arith.ori
    if isinstance(lhs, Tensor) and isinstance(rhs, Tensor):
        if lhs.dtype != tl.int1 or rhs.dtype != tl.int1:
            raise SemanticsError(f"{op} requires i1 blocks")
        if _frag_elem_pair(lhs, rhs):
            return b.binop_frag(op, lhs, rhs)
        x, y = broadcast_tensors(b, lhs, rhs)
        return Tensor(tl.int1, x.shape, x.layout, fn(x.val, y.val), x.ept)
    if isinstance(lhs, Scalar) and isinstance(rhs, Scalar):
        if lhs.dtype != tl.int1 or rhs.dtype != tl.int1:
            raise SemanticsError(f"{op} requires i1 scalars")
        return Scalar(tl.int1, fn(lhs.val, rhs.val))
    raise SemanticsError(
        f"unsupported operands for {op}: {type(lhs).__name__} and "
        f"{type(rhs).__name__}")


def neg(b: Builder, v):
    if isinstance(v, CExpr):
        return CExpr(-v.value)
    if isinstance(v, SepOff):
        return b.off_scale(v, -1)
    if isinstance(v, Scalar):
        zero = _to_scalar(b, CExpr(0.0 if v.dtype.is_float else 0), v.dtype)
        return Scalar(v.dtype, b.binary("sub", zero.val, v.val, v.dtype))
    if isinstance(v, Tensor):
        zero = _to_scalar(b, CExpr(0.0 if v.dtype.is_float else 0), v.dtype)
        z = _splat_like(b, zero, v)
        return Tensor(v.dtype, v.shape, v.layout,
                      b.binary("sub", z.val, v.val, v.dtype), v.ept)
    raise SemanticsError(f"cannot negate {v!r}")


def invert(b: Builder, v):
    if isinstance(v, Tensor) and v.dtype == tl.int1:
        one = _splat_like(b, _to_scalar(b, CExpr(1), tl.int1), v)
        return Tensor(tl.int1, v.shape, v.layout, arith.xori(v.val, one.val), v.ept)
    if isinstance(v, Scalar) and v.dtype == tl.int1:
        return Scalar(tl.int1, arith.xori(v.val, b.const(tl.int1, 1)))
    raise SemanticsError(f"~ is only supported on i1 (mask) values, got {v!r}")
