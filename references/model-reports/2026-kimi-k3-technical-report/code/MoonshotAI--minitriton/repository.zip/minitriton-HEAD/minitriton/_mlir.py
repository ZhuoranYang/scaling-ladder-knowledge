"""MLIR import guard.

The MLIR Python bindings are a hard runtime dependency (the compiler
lowers through upstream MLIR dialects) but are not published on PyPI,
so they cannot sit in pyproject's `dependencies` — a bare
`pip install .` leaves them missing and the first mlir import fails.
Fail here with the two working install routes instead of a bare
ModuleNotFoundError. Imported once at the package root.
"""

try:
    import mlir  # noqa: F401
except ImportError as e:  # pragma: no cover - depends on the environment
    raise ImportError(
        "minitriton requires the MLIR Python bindings (mlir>=22), which "
        "are not on PyPI. Install them from conda-forge "
        "(conda install -c conda-forge mlir-python-bindings mlir) or "
        "from the mlir-wheels index: pip install \"mlir>=22\" -f "
        "https://github.com/makslevental/mlir-wheels/releases/"
        "expanded_assets/latest — see the README Quick start."
    ) from e
