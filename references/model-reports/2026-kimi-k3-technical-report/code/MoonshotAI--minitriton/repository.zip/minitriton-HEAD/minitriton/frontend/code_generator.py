"""Python AST -> MLIR code generator and the ``@tl.kernel`` front end.

``@tl.kernel`` marks a Python function as a DSL kernel. On first launch
(``kernel[grid](*args)``) the source is parsed with ``ast`` and walked by
``CodeGenerator``, which drives the tile Builder
(``minitriton/compiler/builder.py``) to emit MLIR; the module then goes
through the lowering pipeline to a cubin.

Whitelisted syntax (everything else fails *early and loud* with line
numbers):

- function def (no nesting), assignments, augmented assignments
- binary/unary ops, comparisons, ``and``/``or`` (no short-circuit)
- ``if`` / ``for i in range(...)`` (loop-carried variables supported)
- subscripts only for newaxis: ``x[:, None]`` / ``x[None, :]`` / ``x[None]``
- calls to the ``tl.*`` builtin vocabulary: program_id, arange,
  load/store, zeros, reduce/sum/max/min, exp, dot, matmul_tile,
  mma/mma_tile, atomic_add, async_copy/stage, constexpr, ...
- ``tl.constexpr`` parameter annotations and captured constexpr globals

Captured globals (``tl.constexpr`` values, plain int/float/bool constants,
``@tl.inline`` helpers — whose free variables resolve in the helper's own
module) bake into the MLIR at trace time; their current values/sources are
sampled into every compile-cache key (memory, disk, fast-launch) so editing
one invalidates the cached cubins.
"""

from __future__ import annotations

import ast
import ctypes
import inspect
import textwrap

from mlir.dialects import vector

from ..compiler.builder import (
    AsyncTok, Builder, CExpr, PtrTensor, Scalar, SepMask, SepOff, SmemBuf,
    StagePipe, Tensor, TileConfigError,
)
from ..compiler.layout import (
    Layout, dist_layout, is_dist, is_rep_like, rep_layout,
)
from ..compiler.lowering import DEFAULT_CHIP, compile_to_cubin
from ..runtime import cache as rt_cache
from ..runtime.buffer import Buffer, get_device
from ..runtime.cuda_driver import memref1d_params
from . import semantics as sem
from . import types as tl


class DSLCompileError(Exception):
    """Whitelist violation or DSL type error, with kernel line info."""


class _TLNamespace:
    """Marker for the `tl` package object inside kernel code."""

    def __init__(self, name="tl"):
        self.name = name


class _TLAttr:
    """Marker for `tl.<name>` inside kernel code."""

    def __init__(self, name):
        self.name = name


class _NonTLCallable:
    """Marker for a captured callable that is not a tl.* builtin."""

    def __init__(self, name):
        self.name = name


class _BuiltinCtor:
    """Marker for float/int/bool constant conversion."""

    def __init__(self, fn):
        self.fn = fn


class _InlineFn:
    """@tl.inline wrapper: a DSL helper function the frontend inlines
    into @tl.kernel bodies at trace time (the scheduling-helper
    mechanism — the helper's source is visited
    like kernel code, with its parameters bound and a single value
    returned)."""

    _MISSING = object()

    def __init__(self, fn):
        self.fn = fn
        self.__name__ = getattr(fn, "__name__", repr(fn))
        self.__doc__ = fn.__doc__
        self._tree = None
        self._src_lines = None

    @property
    def tree(self):
        if self._tree is None:
            src = textwrap.dedent(inspect.getsource(self.fn))
            self._tree = ast.parse(src)
            self._src_lines = src.splitlines()
        return self._tree

    @property
    def src(self):
        """Dedented helper source (cached); mixed into compile-cache keys
        so editing a helper invalidates cached cubins of every kernel
        that inlines it."""
        _ = self.tree
        return "\n".join(self._src_lines)


_BINOPS = {
    ast.Add: "add", ast.Sub: "sub", ast.Mult: "mul", ast.Div: "truediv",
    ast.FloorDiv: "floordiv", ast.Mod: "mod",
}
_CMPOPS = {
    ast.Lt: "<", ast.LtE: "<=", ast.Gt: ">", ast.GtE: ">=",
    ast.Eq: "==", ast.NotEq: "!=",
}


def _rebased(b, v):
    if isinstance(v, PtrTensor):
        return PtrTensor(v.arg, v.off.materialize_bases(b))
    return v.materialize_bases(b)


# ---------------------------------------------------------------------------
# captured-global cache keying (triton's used_global_vals, done statically)
# ---------------------------------------------------------------------------

_DEP_MISSING = object()


def _fn_bound_names(fndef) -> set:
    bound = {a.arg for a in fndef.args.args}
    for n in ast.walk(fndef):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
            bound.add(n.id)
    return bound


def _collect_global_deps(fndef, gscope: dict, deps: list, seen: set):
    """Static superset of the globals a kernel (transitively, its
    @tl.inline helpers) may capture at trace time, as (scope, name)
    pairs. Static (not trace-time) so the compile-cache key is known
    BEFORE tracing; a superset only over-keys (a pruned branch's global
    still salts the key), never under-keys. Helpers recurse with the
    helper's OWN module globals — the same scope _inline_call switches
    to at trace time."""
    bound = _fn_bound_names(fndef)
    for n in ast.walk(fndef):
        if not isinstance(n, ast.Name) or isinstance(n.ctx, ast.Store):
            continue
        name = n.id
        if name in bound or name in ("float", "int", "bool", "range"):
            continue
        if name not in gscope:
            continue  # unresolved here: trace reports it loudly
        val = gscope[name]
        key = (id(gscope), name)
        if key in seen:
            continue
        seen.add(key)
        deps.append((gscope, name))
        if isinstance(val, _InlineFn):
            sub = [d for d in val.tree.body
                   if isinstance(d, ast.FunctionDef)]
            if sub:
                _collect_global_deps(sub[0], val.fn.__globals__, deps,
                                     seen)


def _sample_global(scope: dict, name: str):
    """One captured global's current keyable value: constexpr/plain
    values key on their VALUE, @tl.inline helpers on their source (the
    helper body is part of the traced program), the tl namespace and
    dtypes on their identity. Anything the trace would reject keys on a
    stable marker; callables on their source when available."""
    val = scope.get(name, _DEP_MISSING)
    if val is _DEP_MISSING:
        return (name, "<deleted>")
    if isinstance(val, tl.constexpr):
        return (name, "constexpr", repr(val.value))
    if isinstance(val, _InlineFn):
        return (name, "inline", val.src)
    if isinstance(val, tl.DType):
        return (name, "dtype", val.name)
    if val is None or isinstance(val, (int, float, bool, str)):
        return (name, "value", repr(val))
    import minitriton as tl_pkg
    if val is tl_pkg or getattr(val, "__name__", "") == "minitriton":
        return (name, "tl")
    if inspect.ismodule(val):
        return (name, "module", val.__name__)
    if callable(val):
        try:
            return (name, "fn", textwrap.dedent(inspect.getsource(val)))
        except (OSError, TypeError):
            return (name, "callable",
                    getattr(val, "__qualname__", None) or repr(val))
    return (name, "object", repr(val))


class CodeGenerator(ast.NodeVisitor):
    def __init__(self, b: Builder, kernel_name: str, src_lines: list[str],
                 gscope: dict, env: dict):
        self.b = b
        self.kernel_name = kernel_name
        self.src_lines = src_lines
        self.gscope = gscope
        self.env = env
        # >0 while visiting statements nested inside an if/for region:
        # a return there would silently mis-trace (inline helpers: both
        # regions overwrite _inline_ret; kernels: the bare return is a
        # no-op), so visit_Return rejects it loudly
        self._cf_depth = 0

    # -- helpers ---------------------------------------------------------------

    def err(self, node, msg: str):
        line = ""
        if hasattr(node, "lineno") and 1 <= node.lineno <= len(self.src_lines):
            line = (f"\n  {self.src_lines[node.lineno - 1].rstrip()}"
                    f"\n  {' ' * (getattr(node, 'col_offset', 0))}^")
        raise DSLCompileError(
            f"{self.kernel_name}: line {getattr(node, 'lineno', '?')}: {msg}{line}")

    def eval(self, node):
        return self.visit(node)

    def _as_cexpr_int(self, node, what: str) -> int:
        v = self.eval(node)
        if not isinstance(v, CExpr) or not isinstance(v.value, int):
            self.err(node, f"{what} must be a compile-time integer, got {v!r}")
        return v.value

    @staticmethod
    def _assigned_names(stmts) -> set[str]:
        names = set()
        for n in ast.walk(ast.Module(body=stmts, type_ignores=[])):
            if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store,)):
                names.add(n.id)
        return names

    def _collect_carried(self, names):
        """Prepare loop/if-carried variables: CExpr -> Scalar, pack
        (types, values, templates)."""
        types, values, templates = [], [], {}
        for n in names:
            v = self.env[n]
            if isinstance(v, CExpr):
                v = sem._to_scalar(self.b, v)
            if isinstance(v, (PtrTensor, SepOff)):
                v = _rebased(self.b, v)
            self.env[n] = v
            if isinstance(v, SepMask):
                self.err_hint(n)
            items = v.carry_items()
            templates[n] = v
            types += [t for t, _ in items]
            values += [x for _, x in items]
        return types, values, templates

    def err_hint(self, name):
        raise DSLCompileError(
            f"{self.kernel_name}: variable {name!r} is a symbolic mask and "
            "cannot be carried across control flow; recompute it inside the "
            "block instead")

    def _carry_vals(self, names, templates, node):
        """Current carry values for `names`, with type-stability checks."""
        vals = []
        for n in names:
            v = self.env[n]
            if isinstance(v, CExpr):
                v = sem._to_scalar(self.b, v)
                self.env[n] = v
            if isinstance(v, SepMask):
                self.err_hint(n)
            items = v.carry_items()
            want = templates[n].carry_items()
            if len(items) != len(want) or \
                    [str(t) for t, _ in items] != [str(t) for t, _ in want]:
                self.err(node, f"variable {n!r} changes type across control "
                               f"flow ({templates[n]!r} -> {v!r}); keep the "
                               f"type of loop/if-carried variables fixed")
            sk_now = getattr(v, "carried_structure", None)
            sk_tpl = getattr(templates[n], "carried_structure", None)
            if sk_now is not None and sk_tpl is not None \
                    and sk_now() != sk_tpl():
                self.err(node,
                         f"variable {n!r} changes its offset structure "
                         f"across control flow ({templates[n]!r} -> {v!r}): "
                         "a carried symbolic offset may only update its "
                         "base, the stride/length structure must stay "
                         "fixed — recompute the rescaled offsets inside "
                         "the loop, or carry the multiplier as a scalar "
                         "and scale at the use site")
            vals += [x for _, x in items]
        return vals

    @staticmethod
    def _split_results(names, templates, flat):
        out, pos = {}, 0
        for n in names:
            arity = len(templates[n].carry_items())
            out[n] = templates[n].rebuild(flat[pos:pos + arity])
            pos += arity
        return out

    # -- statements --------------------------------------------------------------

    def visit_statements(self, stmts):
        for k, st in enumerate(stmts):
            if isinstance(st, ast.Return) and k != len(stmts) - 1:
                self.err(st, "return is only allowed as the last statement")
            self.visit(st)

    def visit_FunctionDef(self, node):
        self.err(node, "nested function definitions are not supported")

    def visit_AsyncFunctionDef(self, node):
        self.err(node, "async is not supported in DSL kernels")

    def visit_ClassDef(self, node):
        self.err(node, "class definitions are not supported in DSL kernels")

    def visit_Return(self, node):
        if self._cf_depth > 0:
            self.err(node, "return is only allowed as the last top-level "
                           "statement — a return nested inside if/for "
                           "cannot be traced (restructure the control "
                           "flow, e.g. compute both values and select "
                           "with tl.where)")
        if getattr(self, "_inline_depth", 0) > 0:
            if node.value is None:
                self.err(node, "@tl.inline helpers must return a value")
            self._inline_ret = self.eval(node.value)
            return
        if node.value is not None:
            self.err(node, "kernels cannot return values (write results "
                           "through pointer arguments)")
        # bare return: codegen ends the function at finish(); only valid as
        # the last top-level statement, enforced by the driver below.

    def visit_Assign(self, node):
        if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
            self.err(node, "only single-name assignments are supported "
                           "(no tuple unpacking or subscript assignment)")
        self.env[node.targets[0].id] = self.eval(node.value)

    def visit_AnnAssign(self, node):
        if not isinstance(node.target, ast.Name):
            self.err(node, "only simple annotated assignments are supported")
        if node.value is None:
            self.err(node, "bare declarations are not supported; assign a value")
        self.env[node.target.id] = self.eval(node.value)

    def visit_AugAssign(self, node):
        if not isinstance(node.target, ast.Name):
            self.err(node, "augmented assignment only supports simple names")
        op = _BINOPS.get(type(node.op))
        if op is None:
            self.err(node, f"unsupported augmented operator: {ast.dump(node.op)}")
        cur = self.env.get(node.target.id)
        if cur is None:
            self.err(node, f"undefined variable {node.target.id!r}")
        self.env[node.target.id] = sem.binop(self.b, op, cur, self.eval(node.value))

    def visit_Expr(self, node):
        self.eval(node.value)

    def visit_Pass(self, node):
        pass

    def visit_If(self, node):
        test = self.eval(node.test)
        if isinstance(test, CExpr):
            self._cf_depth += 1
            try:
                self.visit_statements(node.body if test.value
                                      else node.orelse)
            finally:
                self._cf_depth -= 1
            return
        if not isinstance(test, Scalar) or test.dtype != tl.int1:
            self.err(node.test, f"if condition must be a scalar i1 or "
                                f"compile-time bool, got {test!r}")
        assigned = self._assigned_names(node.body) | self._assigned_names(node.orelse)
        results = sorted(assigned)
        for n in results:
            if n not in self.env:
                self.err(node, f"variable {n!r} is defined only inside one "
                               f"branch of this if; define it before the if")
        types, _, templates = self._collect_carried(results)
        if_op = self.b._if_op(test.val, types)

        saved = dict(self.env)
        self._cf_depth += 1
        try:
            with self.b._region(if_op.regions[0]):
                self.visit_statements(node.body)
                self.b._yield(self._carry_vals(results, templates, node))
            self.env = dict(saved)
            with self.b._region(if_op.regions[1]):
                self.visit_statements(node.orelse)
                self.b._yield(self._carry_vals(results, templates, node))
        finally:
            self._cf_depth -= 1
        self.env.update(self._split_results(results, templates,
                                            list(if_op.results)))

    def visit_For(self, node):
        if node.orelse:
            self.err(node, "for-else is not supported")
        if not isinstance(node.target, ast.Name):
            self.err(node, "for target must be a simple name")
        pipelined = self._pipelined_spec(node)
        if not (isinstance(node.iter, ast.Call)
                and isinstance(node.iter.func, ast.Name)
                and node.iter.func.id == "range") and pipelined is None:
            self.err(node, "only `for i in range(...)` loops are supported")
        iter_call = node.iter if pipelined is None else pipelined[0]
        args = [self.eval(a) for a in iter_call.args]
        if iter_call.keywords:
            self.err(node, "range() takes no keyword arguments")
        if len(args) == 1:
            lo, hi, step = CExpr(0), args[0], CExpr(1)
        elif len(args) == 2:
            lo, hi, step = args[0], args[1], CExpr(1)
        elif len(args) == 3:
            lo, hi, step = args
        else:
            self.err(node, "range() takes 1-3 arguments")
        if not isinstance(step, CExpr) or not isinstance(step.value, int) \
                or step.value <= 0:
            self.err(node, "range step must be a positive compile-time integer")
        if pipelined is not None:
            self._cf_depth += 1
            try:
                self._visit_pipelined_for(node, (lo, hi, step),
                                          pipelined[1])
            finally:
                self._cf_depth -= 1
            return

        assigned = self._assigned_names(node.body)
        pre = set(self.env)
        carried = sorted(n for n in assigned if n in self.env
                         and n != node.target.id)
        types, values, templates = self._collect_carried(carried)

        lo_v = self._bound_value(node, lo)
        hi_v = self._bound_value(node, hi)
        for_op, block = self.b._for_op(lo_v, hi_v, step.value, values)

        with self.b._block_ip(block):
            self.env[node.target.id] = Scalar(tl.int32, self.b._iv_i32(block))
            # carried variables become the loop's block arguments
            self.env.update(self._split_results(
                carried, templates, list(block.arguments[1:])))
            self._cf_depth += 1
            try:
                self.visit_statements(node.body)
            finally:
                self._cf_depth -= 1
            self.b._yield(self._carry_vals(carried, templates, node))
        self.env.update(self._split_results(carried, templates,
                                            list(for_op.results)))
        # names first assigned inside the body (and the loop target) refer
        # to region-local SSA values; leaving them in env lets a later
        # loop capture them as stale carried operands (undeclared SSA in
        # the emitted module) — drop them
        for n in assigned:
            if n not in pre:
                self.env.pop(n, None)
        if node.target.id not in pre:
            self.env.pop(node.target.id, None)

    def _offset_scalar(self, node, offset):
        """OFFSET= values: i32 runtime scalar or compile-time int."""
        if offset is None or isinstance(offset, Scalar):
            return offset
        if isinstance(offset, CExpr) and isinstance(offset.value, int):
            return Scalar(tl.int32, self.b.c_i32(offset.value))
        self.err(node, "OFFSET must be an i32 scalar or a compile-time int")

    def _resolve_pipe_pending(self, node, b_pt, pending):
        """tl.mma / tl.dot_t3 promise-PENDING resolution: inside a
        tl.pipelined body the default is mechanical — (M-1-j) newer
        groups from the previous iteration's sites after j, plus this
        iteration's sites already emitted above this consume
        (stage_seen). Also rejects consuming a promise below its site
        (that token stages the NEXT tile)."""
        if pending.value is not None or not isinstance(b_pt, AsyncTok) \
                or getattr(self, "_pipe_pending", None) is None:
            return pending
        if getattr(self, "_restage_toks", None) is not None \
                and id(b_pt) in self._restage_toks:
            self.err(node, "this promise is consumed BELOW its tl.stage "
                           "site — that token stages the NEXT tile; move "
                           "the consume above the site")
        key = id(b_pt.pipe)
        if key not in self._pipe_pending:
            self.err(node, "promise is not one of this tl.pipelined "
                           "loop's tl.stage sites")
        return CExpr(self._pipe_pending[key] + self._stage_seen)

    def _pipelined_spec(self, node):
        """`for i in tl.pipelined(range(...), stages=N)`? -> (range_call,
        stages) or None. Explicit loop-level pipeline annotation:
        a fixed syntactic rotation of the annotated loop only — never an
        inferring pass."""
        it = node.iter
        if not (isinstance(it, ast.Call)
                and isinstance(it.func, ast.Attribute)
                and it.func.attr == "pipelined"):
            return None
        fn = self.eval(it.func)
        if not isinstance(fn, _TLAttr):
            self.err(node.iter.func, "tl.pipelined is a tl.* construct")
        stages = CExpr(2)
        pos, seen = [], False
        for a in it.args:
            pos.append(a)
        for kw in it.keywords:
            if kw.arg != "stages":
                self.err(kw, f"tl.pipelined: unexpected kwarg {kw.arg!r}")
            stages = self.eval(kw.value)
            seen = True
        if len(pos) == 2 and not seen:
            stages = self.eval(pos.pop())
        if len(pos) != 1 or not isinstance(pos[0], ast.Call) \
                or not isinstance(pos[0].func, ast.Name) \
                or pos[0].func.id != "range":
            self.err(it, "tl.pipelined expects tl.pipelined(range(...), "
                         "stages=N)")
        if not isinstance(stages, CExpr) or stages.value != 2:
            self.err(it, "tl.pipelined currently supports stages=2 "
                         "(single-buffer rotation)")
        return pos[0], 2

    @staticmethod
    def _is_stage_assign(st) -> bool:
        return isinstance(st, ast.Assign) and len(st.targets) == 1 \
            and isinstance(st.targets[0], ast.Name) \
            and isinstance(st.value, ast.Call) \
            and isinstance(st.value.func, ast.Attribute) \
            and st.value.func.attr == "stage"

    def _emit_stage(self, st):
        """Emit one tl.stage site as an async copy/stage with the current
        env (prologue: iv := lo; rotation restage: iv := clamp(iv+step)).
        StagePipe sites stage mma-swizzled; SmemBuf sites are raw
        async_copies (EVEN/TRANS knobs passed through)."""
        call = st.value
        if len(call.args) != 2:
            self.err(call, "tl.stage expects (pipe_or_buf, ptr_tile)")
        pipe = self.eval(call.args[0])
        pt = self.eval(call.args[1])
        kwargs = {kw.arg: self.eval(kw.value) for kw in call.keywords}
        mask = kwargs.pop("MASK", None)
        even = kwargs.pop("EVEN", CExpr(False))
        trans = kwargs.pop("TRANS", CExpr(False))
        if kwargs:
            self.err(call, f"tl.stage: unexpected kwargs {sorted(kwargs)}")
        if not isinstance(pt, PtrTensor):
            self.err(call.args[1], "tl.stage expects a pointer tile")
        if mask is not None and not isinstance(mask, SepMask):
            self.err(call, "tl.stage MASK must be a symbolic mask")
        for v, nm in ((even, "EVEN"), (trans, "TRANS")):
            if not isinstance(v, CExpr):
                self.err(call, f"tl.stage {nm} must be compile-time")
        if isinstance(pipe, CExpr) and isinstance(pipe.value, StagePipe):
            if even.value or trans.value:
                self.err(call, "EVEN/TRANS on a StagePipe are set at "
                               "tl.stage_pipe creation, not at the site")
            self.env[st.targets[0].id] = self.b.async_stage(pipe.value, pt,
                                                            mask=mask)
            return
        if isinstance(pipe, CExpr) and isinstance(pipe.value, SmemBuf):
            self.env[st.targets[0].id] = self.b.async_copy(
                pipe.value, pt, mask=mask, even=bool(even.value),
                trans=bool(trans.value))
            return
        self.err(call.args[0], "tl.stage pipe must be a tl.stage_pipe or "
                               "tl.smem value bound to a name")

    def _visit_pipelined_for(self, node, bounds, stages: int):
        """Lower `for i in tl.pipelined(range(lo, hi, step), stages=2)`:
        mechanical single-buffer rotation of the annotated loop —

          * prologue: every `name = tl.stage(pipe, pt)` site (top level of
            the body, program order) is emitted once with i := lo;
          * body: each site emits IN ITS OWN POSITION with i :=
            min(i+step, hi-step) — the site's position is where the NEXT
            tile's copy issues (the canonical form is the hand-written
            pipeline minus prologue/drain/clamp bookkeeping); a promise
            must be consumed ABOVE its site (consuming below it reads
            the next tile — rejected at trace time);
          * drain: tl.async_wait(last site, 0) after the loop.

        tl.mma's PENDING defaults mechanically inside: site j of M may
        leave M-1-j newer groups in flight (sites must be consumed in
        stage order). The rotation is a fixed rewrite of this loop only —
        no detection, no heuristics (the explicit-sugar rule)."""
        iv = node.target.id
        lo, hi, step = bounds
        site_set, sites = set(), []
        for st in node.body:
            if self._is_stage_assign(st):
                sites.append(st)
                site_set.add(id(st))
        if not sites:
            self.err(node, "tl.pipelined loop body has no tl.stage sites")
        for st in node.body:
            for sub in ast.walk(st):
                if isinstance(sub, ast.Call) \
                        and isinstance(sub.func, ast.Attribute):
                    nm = sub.func.attr
                    if nm == "stage" and id(st) not in site_set:
                        self.err(sub, "tl.stage sites must be top-level "
                                      "`name = tl.stage(pipe, ptr_tile)` "
                                      "statements")
                    if nm in ("async_stage", "async_wait"):
                        self.err(sub, "inside tl.pipelined use tl.stage "
                                      "(the drain is automatic)")
                    if nm == "pipelined":
                        self.err(sub, "nested tl.pipelined loops are not "
                                      "supported")
        names = [st.targets[0].id for st in sites]
        if len(set(names)) != len(names):
            self.err(node, "tl.stage promise names must be distinct")
        if iv in names:
            self.err(node, "tl.stage promise name collides with the loop "
                           "variable")

        # pipe -> mechanical PENDING (site j of M: M-1-j newer groups)
        pend = {}
        for j, st in enumerate(sites):
            p = self.eval(st.value.args[0])
            if not isinstance(p, CExpr) \
                    or not isinstance(p.value, (StagePipe, SmemBuf)):
                self.err(st.value.args[0],
                         "tl.stage pipe must be a tl.stage_pipe or "
                         "tl.smem value")
            pend[id(p.value)] = len(sites) - 1 - j

        assigned = self._assigned_names(node.body)
        pre = set(self.env)

        # prologue (before _collect_carried so the promises are carried)
        saved = dict(self.env)
        for s in range(stages - 1):
            self.env[iv] = sem.binop(self.b, "add",
                                     sem._to_scalar(self.b, lo), CExpr(s * step.value))
            for st in sites:
                self._emit_stage(st)
        prologue = {n: self.env[n] for n in names}
        self.env = dict(saved)
        self.env.update(prologue)

        carried = sorted(n for n in assigned if n in self.env and n != iv)
        types, values, templates = self._collect_carried(carried)
        lo_v = self._bound_value(node, lo)
        hi_v = self._bound_value(node, hi)
        for_op, block = self.b._for_op(lo_v, hi_v, step.value, values)
        with self.b._block_ip(block):
            self.env[iv] = Scalar(tl.int32, self.b._iv_i32(block))
            self.env.update(self._split_results(
                carried, templates, list(block.arguments[1:])))
            self._pipe_pending = pend
            self._restage_toks = set()
            self._stage_seen = 0
            iv_val = self.env[iv]
            nxt = sem.binop(self.b, "add", iv_val, CExpr(step.value))
            hi_s = sem._to_scalar(self.b, hi)
            clamped = sem.where(
                self.b, sem.compare(self.b, "<", nxt, hi_s), nxt,
                sem.binop(self.b, "sub", hi_s, CExpr(step.value)))
            for st in node.body:
                if id(st) in site_set:
                    self.env[iv] = clamped
                    self._emit_stage(st)
                    self._restage_toks.add(id(self.env[st.targets[0].id]))
                    self._stage_seen += 1
                    self.env[iv] = iv_val
                else:
                    self.visit(st)
            self._pipe_pending = None
            self._restage_toks = None
            self._stage_seen = None
            self.b._yield(self._carry_vals(carried, templates, node))
        self.env.update(self._split_results(carried, templates,
                                            list(for_op.results)))
        # drain
        self.b.async_wait(self.env[names[-1]], 0)
        for n in assigned:
            if n not in pre:
                self.env.pop(n, None)
        if iv not in pre:
            self.env.pop(iv, None)

    def _bound_value(self, node, v):
        if isinstance(v, CExpr):
            if not isinstance(v.value, int):
                self.err(node, "range bounds must be integers")
            return v.value
        if isinstance(v, Scalar) and v.dtype == tl.int32:
            return v.val
        self.err(node, f"range bounds must be integers or i32 scalars, got {v!r}")

    def visit_While(self, node):
        self.err(node, "while-loops are not supported (use for-range)")

    def visit_Break(self, node):
        self.err(node, "break is not supported")

    def visit_Continue(self, node):
        self.err(node, "continue is not supported")

    def visit_Try(self, node):
        self.err(node, "try/except is not supported")

    def visit_With(self, node):
        self.err(node, "with statements are not supported")

    def visit_Raise(self, node):
        self.err(node, "raise is not supported")

    def visit_Assert(self, node):
        self.err(node, "assert is not supported in kernels")

    def visit_Import(self, node):
        self.err(node, "imports inside kernels are not supported")

    def visit_ImportFrom(self, node):
        self.err(node, "imports inside kernels are not supported")

    def visit_Global(self, node):
        self.err(node, "global declarations are not supported")

    def visit_Nonlocal(self, node):
        self.err(node, "closures/nonlocal are not supported (capture only "
                       "tl.* and tl.constexpr globals)")

    def generic_visit(self, node):
        self.err(node, f"unsupported syntax: {type(node).__name__} "
                       f"(whitelist: def/assign/if/for-range/binop/compare/"
                       f"subscript-newaxis/tl.* calls)")

    # -- expressions ---------------------------------------------------------------

    def visit_Constant(self, node):
        if isinstance(node.value, (int, float, bool, str)) or node.value is None:
            return CExpr(node.value)
        self.err(node, f"unsupported constant: {node.value!r}")

    def visit_Name(self, node):
        if isinstance(node.ctx, ast.Store):
            self.err(node, "internal error: unexpected store context")
        if node.id in self.env:
            return self.env[node.id]
        if node.id in self.gscope:
            return self._from_global(node, self.gscope[node.id])
        import builtins
        if node.id in ("float", "int", "bool"):
            return _BuiltinCtor(getattr(builtins, node.id))
        self.err(node, f"undefined name {node.id!r} (kernels capture only "
                       f"tl.* and tl.constexpr globals)")

    def _from_global(self, node, val):
        import minitriton as tl_pkg
        if val is tl_pkg or getattr(val, "__name__", "") in ("minitriton",):
            return _TLNamespace()
        if isinstance(val, _InlineFn):
            return val
        if isinstance(val, tl.constexpr):
            return CExpr(val.value)
        if isinstance(val, tl.DType):
            return CExpr(val)
        if isinstance(val, (int, float, bool)):
            return CExpr(val)
        if callable(val):
            return _NonTLCallable(getattr(val, "__name__", repr(val)))
        self.err(node, f"cannot capture global {val!r} in a kernel; wrap it "
                       f"in tl.constexpr or pass it as an argument")

    def visit_BinOp(self, node):
        if isinstance(node.op, ast.BitAnd):
            return sem.logical(self.b, "and", self.eval(node.left),
                               self.eval(node.right))
        if isinstance(node.op, ast.BitOr):
            return sem.logical(self.b, "or", self.eval(node.left),
                               self.eval(node.right))
        op = _BINOPS.get(type(node.op))
        if op is None:
            self.err(node, f"unsupported binary operator: {type(node.op).__name__} "
                           f"(+ - * / // % & | on masks)")
        return sem.binop(self.b, op, self.eval(node.left), self.eval(node.right))

    def visit_UnaryOp(self, node):
        v = self.eval(node.operand)
        if isinstance(node.op, ast.USub):
            return sem.neg(self.b, v)
        if isinstance(node.op, ast.UAdd):
            return v
        if isinstance(node.op, ast.Invert):
            return sem.invert(self.b, v)
        if isinstance(node.op, ast.Not):
            if isinstance(v, CExpr):
                return CExpr(not v.value)
            self.err(node, "'not' is only supported on compile-time values; "
                           "use ~ on masks")
        self.err(node, f"unsupported unary operator: {type(node.op).__name__}")

    def visit_BoolOp(self, node):
        op = "and" if isinstance(node.op, ast.And) else "or"
        vals = [self.eval(v) for v in node.values]
        out = vals[0]
        for v in vals[1:]:
            out = sem.logical(self.b, op, out, v)
        return out

    def visit_Compare(self, node):
        if len(node.ops) != 1:
            self.err(node, "chained comparisons are not supported")
        op = _CMPOPS.get(type(node.ops[0]))
        if op is None:
            self.err(node, f"unsupported comparison: {type(node.ops[0]).__name__}")
        return sem.compare(self.b, op, self.eval(node.left),
                           self.eval(node.comparators[0]))

    def visit_IfExp(self, node):
        self.err(node, "conditional expressions (a if c else b) are not "
                       "supported; use an if statement")

    def visit_Tuple(self, node):
        vals = [self.eval(e) for e in node.elts]
        out = []
        for v in vals:
            if not isinstance(v, CExpr):
                self.err(node, "tuples must be compile-time (shapes, grids)")
            out.append(v.value)
        return CExpr(tuple(out))

    def visit_List(self, node):
        return self.visit_Tuple(node)

    def visit_Subscript(self, node):
        base = self.eval(node.value)
        sl = node.slice
        axes = sl.elts if isinstance(sl, ast.Tuple) else [sl]
        kinds = []
        for a in axes:
            if isinstance(a, ast.Slice) and a.lower is None and a.upper is None \
                    and a.step is None:
                kinds.append("full")
            elif isinstance(a, ast.Constant) and a.value is None:
                kinds.append("new")
            else:
                self.err(a, "only `:` and `None` (newaxis) subscripts are "
                            "supported on blocks")
        if isinstance(base, SepMask):
            n_new = kinds.count("new")
            if n_new != 1:
                self.err(node, "currently supports exactly one newaxis on a 1D mask")
            # numpy semantics: m[None] == m[None, :] -> (1, C); the data
            # axis sits at the position of `:` (or last for bare [None])
            axis = kinds.index("full") if "full" in kinds else 1
            return base.newaxis(axis)
        if isinstance(base, (SepOff, Tensor)):
            return self._newaxis(node, base, kinds)
        self.err(node, f"subscript is not supported on {type(base).__name__}")

    def _newaxis(self, node, v, kinds):
        n_new = kinds.count("new")
        n_full = kinds.count("full")
        src_dim = len(v.shape) if not isinstance(v.shape, int) else v.shape
        if n_new != 1 or src_dim != 1:
            self.err(node, "currently supports exactly one newaxis on a 1D value "
                           "(x[:, None], x[None, :], x[None])")
        # position of the data axis: where `:` sits; a bare x[None] is
        # numpy's x[None, :] — (1, N), data axis last
        axis = kinds.index("full") if n_full else 1
        if isinstance(v, SepOff):
            return self.b.off_newaxis(v, axis)
        # materialized tensor
        if is_rep_like(v.layout):
            dst = (v.shape[0], 1) if axis == 0 else (1, v.shape[0])
            return Tensor(v.dtype, dst, rep_layout(dst),
                          vector.shape_cast(self.b.vec_type(list(dst), v.dtype),
                                            v.val), v.ept)
        if is_dist(v.layout) and axis == 1:  # (C,) -> (1, C)
            dst = (1, v.shape[0])
            return Tensor(v.dtype, dst, dist_layout(dst, self.b.num_threads),
                          vector.shape_cast(self.b.vec_type([1, v.ept], v.dtype),
                                            v.val), v.ept)
        self.err(node, "x[:, None] on a distributed block would need a "
                       "layout conversion; keep index math symbolic "
                       "(arange-derived offsets handle it automatically)")

    def visit_Slice(self, node):
        self.err(node, "partial slicing is not supported (only `:` and "
                       "newaxis)")

    def visit_Attribute(self, node):
        base = self.eval(node.value)
        if isinstance(base, _TLNamespace):
            if node.attr in tl.PUBLIC_DTYPES:
                return CExpr(tl.PUBLIC_DTYPES[node.attr])
            return _TLAttr(node.attr)
        if isinstance(base, CExpr) and node.attr == "value":
            return base
        self.err(node, f"unsupported attribute access: .{node.attr} "
                       f"(kernels may only reference tl.*)")

    def visit_Call(self, node):
        fn = self.eval(node.func)
        if isinstance(fn, _BuiltinCtor):
            args = [self.eval(a) for a in node.args]
            if len(args) != 1 or not isinstance(args[0], CExpr):
                self.err(node, "float()/int()/bool() take one compile-time "
                               "argument in kernels")
            return CExpr(fn.fn(args[0].value))
        if isinstance(fn, _InlineFn):
            args = [self.eval(a) for a in node.args]
            kwargs = {kw.arg: self.eval(kw.value) for kw in node.keywords}
            return self._inline_call(node, fn, args, kwargs)
        if isinstance(fn, _NonTLCallable):
            self.err(node, f"only tl.* calls are supported inside kernels "
                           f"(cannot call {fn.name!r})")
        if not isinstance(fn, _TLAttr):
            self.err(node, "only tl.* calls are supported inside kernels")
        args = [self.eval(a) for a in node.args]
        kwargs = {kw.arg: self.eval(kw.value) for kw in node.keywords}
        return self._call_tl(node, fn.name, args, kwargs)

    def _inline_call(self, node, ifn: _InlineFn, args, kwargs):
        """Inline one @tl.inline helper call: bind its parameters in a
        fresh scope and visit its body like kernel code. Helpers take
        plain positional/keyword parameters and return exactly one
        value (as the last top-level statement); they see tl.* and
        tl.constexpr globals but NOT the caller's locals. Free variables
        resolve in the HELPER's own module globals (self.gscope switches
        along with env/src_lines) — a kernel-module global with the same
        name must never shadow the helper's."""
        if getattr(self, "_inline_depth", 0) >= 8:
            self.err(node, "@tl.inline call depth exceeds 8 (recursion?)")
        fndefs = [n for n in ifn.tree.body if isinstance(n, ast.FunctionDef)]
        if len(fndefs) != 1:
            self.err(node, f"{ifn.__name__}: expected one function "
                           "definition")
        fndef = fndefs[0]
        params = fndef.args
        if params.vararg or params.kwarg or params.kwonlyargs:
            self.err(node, "@tl.inline helpers take plain positional/"
                           "keyword parameters only (no *args/**kwargs)")
        names = [a.arg for a in params.args]
        if len(args) > len(names):
            self.err(node, f"{ifn.__name__} takes {len(names)} arguments, "
                           f"got {len(args)}")
        bind = dict(zip(names, args))
        defaults = [None] * (len(names) - len(params.defaults)) + \
            list(params.defaults)
        for k, v in kwargs.items():
            if k not in names:
                self.err(node, f"{ifn.__name__}: unexpected kwarg {k!r}")
            if k in bind:
                self.err(node, f"{ifn.__name__}: {k!r} given twice")
            bind[k] = v
        saved_env, saved_src = self.env, self.src_lines
        saved_gscope = self.gscope
        self.env = dict(bind)
        self.src_lines = ifn._src_lines or saved_src
        self.gscope = ifn.fn.__globals__
        self._inline_depth = getattr(self, "_inline_depth", 0) + 1
        self._inline_ret = _InlineFn._MISSING
        try:
            # parameter defaults resolve in the HELPER's module globals
            # (same rule as free variables in the body): they must be
            # evaluated after the gscope switch, not in the caller's
            for name, dflt in zip(names[len(args):], defaults[len(args):]):
                if name in kwargs:
                    continue
                if dflt is None:
                    self.err(node, f"{ifn.__name__}: missing argument "
                                   f"{name!r}")
                self.env[name] = self.eval(dflt)
            self.visit_statements(fndef.body)
        finally:
            self._inline_depth -= 1
            ret = self._inline_ret
            self.src_lines = saved_src
            self.env = saved_env
            self.gscope = saved_gscope
        if ret is _InlineFn._MISSING:
            self.err(node, f"@tl.inline helper {ifn.__name__} did not "
                           "return a value")
        return ret

    def _call_tl(self, node, name: str, args: list, kwargs: dict):
        b = self.b

        def no_kw():
            if kwargs:
                self.err(node, f"tl.{name} takes no keyword arguments "
                               f"({sorted(kwargs)})")

        def want(n):
            if len(args) != n:
                self.err(node, f"tl.{name} expects {n} argument(s), got {len(args)}")

        if name == "program_id":
            no_kw()
            want(1)
            a = args[0]
            if not isinstance(a, CExpr) or a.value not in (0, 1, 2):
                self.err(node, "tl.program_id axis must be a compile-time 0/1/2")
            return b.program_id(a.value)

        if name == "arange":
            no_kw()
            want(2)
            lo, hi = args
            if not (isinstance(lo, CExpr) and isinstance(hi, CExpr)
                    and isinstance(lo.value, int) and isinstance(hi.value, int)):
                self.err(node, "tl.arange bounds must be compile-time integers")
            if hi.value <= lo.value:
                self.err(node, "tl.arange requires start < end")
            return SepOff.arange(lo.value, hi.value - lo.value)

        if name == "zeros":
            want(2)
            shape, dt = args
            shape = self._shape_value(node, shape)
            dt = self._dtype_value(node, dt)
            lay = kwargs.pop("LAYOUT", None)
            if kwargs:
                self.err(node, f"tl.zeros: unexpected kwargs {sorted(kwargs)}")
            if lay is not None:
                if not isinstance(lay, CExpr) or not isinstance(lay.value, Layout):
                    self.err(node, "tl.zeros LAYOUT must be a compile-time "
                                   "layout value")
                return b.zeros(shape, dt, layout=lay.value)
            return b.zeros(shape, dt)

        if name == "mma_layout":
            no_kw()
            want(3)
            role, shape, atom = args
            if not (isinstance(role, CExpr) and isinstance(role.value, str)
                    and isinstance(atom, CExpr)
                    and isinstance(atom.value, str)):
                self.err(node, "tl.mma_layout role/atom must be compile-time "
                               "strings")
            shape = self._shape_value(node, shape)
            from ..compiler.layout import mma_layout as _mma_lay
            return CExpr(_mma_lay(role.value, shape, atom.value,
                                  b.num_threads))

        if name == "t3_layout":
            no_kw()
            want(1)
            shape = self._shape_value(node, args[0])
            from ..compiler.layout import t3_layout as _t3_lay
            return CExpr(_t3_lay(shape, 1, b.num_threads))

        if name == "sliced":
            no_kw()
            want(2)
            lay, dim = args
            if not isinstance(lay, CExpr) or not isinstance(lay.value, Layout):
                self.err(node, "tl.sliced parent must be a layout value")
            if not isinstance(dim, CExpr) or dim.value not in (0, 1):
                self.err(node, "tl.sliced dim must be 0 or 1")
            from ..compiler.layout import Sliced as _Sl
            return CExpr(_Sl(lay.value, dim.value))

        if name == "convert_layout":
            no_kw()
            want(2)
            v, lay = args
            if not isinstance(v, Tensor):
                self.err(node, f"tl.convert_layout expects a block value, "
                               f"got {v!r}")
            if not isinstance(lay, CExpr) or not isinstance(lay.value, Layout):
                self.err(node, "tl.convert_layout dst must be a "
                               "compile-time layout value")
            return b.convert_layout(v, lay.value)

        if name == "materialize":
            want(1)
            lay = kwargs.pop("LAYOUT", None)
            if kwargs:
                self.err(node, f"tl.materialize: unexpected kwargs "
                               f"{sorted(kwargs)}")
            if lay is not None:
                if not isinstance(lay, CExpr) or not isinstance(lay.value, Layout):
                    self.err(node, "tl.materialize LAYOUT must be a "
                                   "compile-time layout value")
                if not isinstance(args[0], SepOff):
                    self.err(node, "tl.materialize LAYOUT expects a symbolic "
                                   "offset source")
                return b.materialize_to(args[0], lay.value)
            return sem.materialize(b, args[0])

        if name == "load":
            want(1)
            pt = args[0]
            mask = kwargs.pop("mask", None)
            other = kwargs.pop("other", None)
            lay = kwargs.pop("LAYOUT", None)
            if kwargs:
                self.err(node, f"tl.load: unexpected kwargs {sorted(kwargs)}")
            if not isinstance(pt, PtrTensor):
                self.err(node, f"tl.load expects a pointer tensor, got {pt!r}")
            if mask is not None and not isinstance(mask, (SepMask, Tensor)):
                self.err(node, f"tl.load mask must be a mask value, got {mask!r}")
            if lay is not None:
                if not isinstance(lay, CExpr) or not isinstance(lay.value, Layout):
                    self.err(node, "tl.load LAYOUT must be a compile-time "
                                   "layout value")
                return b.load(pt, mask=mask, other=other, layout=lay.value)
            return b.load(pt, mask=mask, other=other)

        if name == "store":
            if len(args) != 2:
                self.err(node, "tl.store expects (pointer, value)")
            pt, val = args
            mask = kwargs.pop("mask", None)
            bias = kwargs.pop("bias", None)
            epi = kwargs.pop("EPI", None)
            if kwargs:
                self.err(node, f"tl.store: unexpected kwargs {sorted(kwargs)}")
            if not isinstance(pt, PtrTensor):
                self.err(node, f"tl.store expects a pointer tensor, got {pt!r}")
            if mask is not None and not isinstance(mask, (SepMask, Tensor)):
                self.err(node, f"tl.store mask must be a mask value, got {mask!r}")
            if bias is not None and not isinstance(bias, PtrTensor):
                self.err(node, f"tl.store bias must be a pointer tile, "
                         f"got {bias!r}")
            epi_v = None
            if epi is not None:
                if not isinstance(epi, CExpr) or epi.value not in ("", "smem"):
                    self.err(node, "tl.store EPI must be a compile-time "
                             "'' | 'smem'")
                epi_v = epi.value or None
            # no layout routing here: builder.store dispatches on
            # value.layout (Fragment -> store_m4,
            # "t2" -> store_t2, everything else the default path)
            b.store(pt, val, mask=mask, bias_pt=bias, epi=epi_v)
            return None

        if name == "atomic_add":
            want(2)
            pt, val = args
            mask = kwargs.pop("mask", None)
            if kwargs:
                self.err(node, f"tl.atomic_add: unexpected kwargs {sorted(kwargs)}")
            if not isinstance(pt, PtrTensor):
                self.err(node, f"tl.atomic_add expects a pointer tensor, "
                               f"got {pt!r}")
            if mask is not None and not isinstance(mask, (SepMask, Tensor)):
                self.err(node, f"tl.atomic_add mask must be a mask value, "
                               f"got {mask!r}")
            b.atomic_add(pt, val, mask=mask)
            return None

        if name in ("reduce", "sum", "max", "min"):
            axis = None
            if name == "reduce":
                x = args[0] if args else None
                op = kwargs.pop("op", args[1] if len(args) > 1 else None)
                axis = kwargs.pop("axis", args[2] if len(args) > 2 else None)
                if kwargs:
                    self.err(node, f"tl.reduce: unexpected kwargs {sorted(kwargs)}")
                if isinstance(op, CExpr):
                    op = op.value
                if op not in ("sum", "max", "min"):
                    self.err(node, "tl.reduce op must be 'sum'/'max'/'min'")
            else:
                want(1)
                axis = kwargs.pop("axis", None)
                if kwargs:
                    self.err(node, f"tl.{name}: unexpected kwargs {sorted(kwargs)}")
                x, op = args[0], name
            if axis is not None:
                if not isinstance(axis, CExpr) or axis.value not in (0, 1, None):
                    self.err(node, "tl.reduce currently supports axis=None/0/1")
                if axis.value == 1:  # row-wise: 2D dist block -> (R, 1) rep
                    return b.reduce_axis1(x, op)
            if not isinstance(x, Tensor):
                self.err(node, f"tl.{name} expects a block value, got {x!r}")
            return b.reduce(x, op)

        if name == "exp":
            want(1)
            no_kw()
            return b.exp(args[0])

        if name in ("maximum", "minimum"):
            want(2)
            no_kw()
            x, y = (sem.materialize(b, a) for a in args)
            if isinstance(x, (CExpr, Scalar)) and isinstance(y, (CExpr, Scalar)):
                xx = sem._to_scalar(b, x)
                yy = sem._to_scalar(b, y)
                dt = sem._promote_dtype(xx.dtype, yy.dtype)
                return Scalar(dt, b.binary(
                    name, sem._cast(b, xx.val, xx.dtype, dt),
                    sem._cast(b, yy.val, yy.dtype, dt), dt))
            return sem.binop(b, name, x, y)

        if name == "log":
            want(1)
            no_kw()
            return b.log(args[0])

        if name == "sqrt":
            want(1)
            no_kw()
            return b.sqrt(args[0])

        if name in ("sin", "cos"):
            want(1)
            no_kw()
            return (b.sin if name == "sin" else b.cos)(args[0])

        if name == "where":
            want(3)
            no_kw()
            return sem.where(b, args[0], args[1], args[2])

        if name == "cast":
            want(2)
            no_kw()
            dt = self._dtype_value(node, args[1])
            return sem.cast(b, args[0], dt)

        if name == "matmul_tile":
            if len(args) != 5:
                self.err(node, "tl.matmul_tile expects (a_ptrs, b_ptrs, K, "
                               "TM, TN)")
            a_pt, b_pt, kk, tm, tn = args
            if not isinstance(a_pt, PtrTensor) or not isinstance(b_pt, PtrTensor):
                self.err(node, "tl.matmul_tile expects pointer tiles for a/b")
            if not isinstance(tm, CExpr) or not isinstance(tn, CExpr) \
                    or not isinstance(tm.value, int) \
                    or not isinstance(tn.value, int):
                self.err(node, "tl.matmul_tile TM/TN must be compile-time ints")
            if not isinstance(kk, (Scalar, CExpr)):
                self.err(node, "tl.matmul_tile K must be an i32 scalar")
            kw = dict(kwargs)
            stages = kw.pop("STAGES", CExpr(2))
            vec = kw.pop("VEC", CExpr(True))
            even_k = kw.pop("EVEN_K", CExpr(True))
            a_mask = kw.pop("a_mask", None)
            b_mask = kw.pop("b_mask", None)
            a_trans = kw.pop("TRANS_A", CExpr(False))
            b_trans = kw.pop("TRANS_B", CExpr(False))
            one_bar = kw.pop("ONE_BAR", CExpr(False))
            if kw:
                self.err(node, f"tl.matmul_tile: unexpected kwargs {sorted(kw)}")
            for v, nm in ((stages, "STAGES"), (vec, "VEC"), (even_k, "EVEN_K"),
                          (a_trans, "TRANS_A"), (b_trans, "TRANS_B"),
                          (one_bar, "ONE_BAR")):
                if not isinstance(v, CExpr):
                    self.err(node, f"tl.matmul_tile {nm} must be compile-time")
            for msk, nm in ((a_mask, "a_mask"), (b_mask, "b_mask")):
                if msk is not None and not isinstance(msk, SepMask):
                    self.err(node, f"tl.matmul_tile {nm} must be a symbolic "
                                   f"mask (or omitted)")
            return b.matmul_tile(a_pt, b_pt, kk, tm.value, tn.value,
                                 stages=int(stages.value),
                                 vec=bool(vec.value),
                                 even_k=bool(even_k.value),
                                 a_mask=a_mask, b_mask=b_mask,
                                 a_trans=bool(a_trans.value),
                                 b_trans=bool(b_trans.value),
                                 one_bar=bool(one_bar.value))

        if name == "mma_tile":
            if len(args) != 3:
                self.err(node, "tl.mma_tile expects (a_ptrs, b_ptrs, K)")
            a_pt, b_pt, kk = args
            if not isinstance(a_pt, PtrTensor) or not isinstance(b_pt, PtrTensor):
                self.err(node, "tl.mma_tile expects pointer tiles for a/b")
            if not isinstance(kk, (Scalar, CExpr)):
                self.err(node, "tl.mma_tile K must be an i32 scalar")
            kw = dict(kwargs)
            atom = kw.pop("ATOM", CExpr("tf32"))
            wn_m = kw.pop("WN_M", CExpr(None))
            wn_n = kw.pop("WN_N", CExpr(None))
            stages = kw.pop("STAGES", CExpr(2))
            vec = kw.pop("VEC", CExpr(True))
            even_k = kw.pop("EVEN_K", CExpr(True))
            a_mask = kw.pop("a_mask", None)
            b_mask = kw.pop("b_mask", None)
            a_trans = kw.pop("TRANS_A", CExpr(False))
            b_trans = kw.pop("TRANS_B", CExpr(False))
            a_tvec = kw.pop("TVEC_A", CExpr(False))
            b_tvec = kw.pop("TVEC_B", CExpr(False))
            one_bar = kw.pop("ONE_BAR", CExpr(False))
            f2f = kw.pop("F2F", CExpr(False))
            dyn_smem = kw.pop("DYN_SMEM", CExpr(False))
            one_shot = kw.pop("ONE_SHOT", CExpr(False))
            if kw:
                self.err(node, f"tl.mma_tile: unexpected kwargs {sorted(kw)}")
            if not isinstance(atom, CExpr) or atom.value not in \
                    ("tf32", "tf32x3", "bf16"):
                self.err(node, "tl.mma_tile ATOM must be a compile-time "
                               "'tf32' | 'tf32x3' | 'bf16'")
            for v, nm in ((stages, "STAGES"), (vec, "VEC"),
                          (even_k, "EVEN_K"), (a_trans, "TRANS_A"),
                          (b_trans, "TRANS_B"), (a_tvec, "TVEC_A"),
                          (b_tvec, "TVEC_B"), (wn_m, "WN_M"),
                          (wn_n, "WN_N"), (one_bar, "ONE_BAR"),
                          (f2f, "F2F"), (dyn_smem, "DYN_SMEM"),
                          (one_shot, "ONE_SHOT")):
                if not isinstance(v, CExpr):
                    self.err(node, f"tl.mma_tile {nm} must be compile-time")
            for v, nm in ((wn_m, "WN_M"), (wn_n, "WN_N")):
                if v.value is not None and not isinstance(v.value, int):
                    self.err(node, f"tl.mma_tile {nm} must be an int or "
                                   "omitted")
            for msk, nm in ((a_mask, "a_mask"), (b_mask, "b_mask")):
                if msk is not None and not isinstance(msk, SepMask):
                    self.err(node, f"tl.mma_tile {nm} must be a symbolic "
                                   "mask (or omitted)")
            return b.mma_tile(a_pt, b_pt, kk, atom=atom.value,
                              wn_m=wn_m.value, wn_n=wn_n.value,
                              stages=int(stages.value),
                              vec=bool(vec.value),
                              even_k=bool(even_k.value),
                              a_mask=a_mask, b_mask=b_mask,
                              a_trans=bool(a_trans.value),
                              b_trans=bool(b_trans.value),
                              a_tvec=bool(a_tvec.value),
                              b_tvec=bool(b_tvec.value),
                              one_bar=bool(one_bar.value),
                              f2f=bool(f2f.value),
                              dyn_smem=bool(dyn_smem.value),
                              one_shot=bool(one_shot.value))

        if name in ("solve_tril", "_wir_solve_tril"):
            want(6)
            a_pt, ai_pt, pid_t, pid_bh, tt, hh = args
            if not isinstance(a_pt, PtrTensor) or not isinstance(ai_pt, PtrTensor):
                self.err(node, "tl.solve_tril expects pointer tensors for "
                               "A and Ai")
            for s, nm in ((pid_t, "pid_t"), (pid_bh, "pid_bh"),
                          (tt, "T"), (hh, "H")):
                if not isinstance(s, Scalar):
                    self.err(node, f"tl.solve_tril {nm} must be a runtime "
                                   f"scalar, got {s!r}")
            kw = dict(kwargs)
            bt = kw.pop("BT", CExpr(64))
            cu_pt = kw.pop("cu_seqlens", None)
            ci_pt = kw.pop("chunk_indices", None)
            if kw:
                self.err(node, f"tl.solve_tril: unexpected kwargs {sorted(kw)}")
            if not isinstance(bt, CExpr) or not isinstance(bt.value, int):
                self.err(node, "tl.solve_tril BT must be a compile-time int")
            if (cu_pt is None) != (ci_pt is None):
                self.err(node, "tl.solve_tril: cu_seqlens and chunk_indices "
                               "must be given together")
            for p, nm in ((cu_pt, "cu_seqlens"), (ci_pt, "chunk_indices")):
                if p is not None and not isinstance(p, PtrTensor):
                    self.err(node, f"tl.solve_tril {nm} must be a pointer "
                                   f"tensor, got {p!r}")
            fn = b.solve_tril if name == "solve_tril" else b.solve_tril_wir
            return fn(a_pt, ai_pt, pid_t, pid_bh, tt, hh, bt.value,
                      cu_pt=cu_pt, ci_pt=ci_pt)

        if name == "dot":
            if not (2 <= len(args) <= 3):
                self.err(node, "tl.dot expects (a, b[, acc])")
            acc = args[2] if len(args) == 3 else kwargs.pop("acc", None)
            if kwargs:
                self.err(node, f"tl.dot: unexpected kwargs {sorted(kwargs)}")
            a, bb = args[0], args[1]
            if not isinstance(a, Tensor) or not isinstance(bb, Tensor):
                self.err(node, "tl.dot operands must be block values")
            return b.dot(a, bb, acc)

        if name == "mma":
            if not (2 <= len(args) <= 3):
                self.err(node, "tl.mma expects (a_frag, b_ptrs_or_tok[, acc])")
            a, b_pt = args[0], args[1]
            acc = args[2] if len(args) == 3 else kwargs.pop("acc", None)
            kw = dict(kwargs)
            trans_b = kw.pop("TRANS_B", CExpr(False))
            even = kw.pop("EVEN", CExpr(False))
            pending = kw.pop("PENDING", CExpr(None))
            mask = kw.pop("MASK", None)
            if kw:
                self.err(node, f"tl.mma: unexpected kwargs {sorted(kw)}")
            if not isinstance(a, Tensor):
                self.err(node, "tl.mma a must be a Fragment('A') block "
                               "value")
            if not isinstance(b_pt, (PtrTensor, AsyncTok)):
                self.err(node, "tl.mma b must be a pointer tile or an "
                               "async_stage promise")
            for v, nm in ((trans_b, "TRANS_B"), (even, "EVEN")):
                if not isinstance(v, CExpr):
                    self.err(node, f"tl.mma {nm} must be compile-time")
            if not isinstance(pending, CExpr) or not (
                    pending.value is None or isinstance(pending.value, int)):
                self.err(node, "tl.mma PENDING must be a compile-time int")
            pending = self._resolve_pipe_pending(node, b_pt, pending)
            if mask is not None and not isinstance(mask, SepMask):
                self.err(node, "tl.mma MASK must be a symbolic mask "
                               "(or omitted)")
            if acc is not None and not isinstance(acc, Tensor):
                self.err(node, "tl.mma acc must be a block value "
                               "(or omitted)")
            return b.mma(a, b_pt, acc, trans_b=bool(trans_b.value),
                         mask=mask, even=bool(even.value),
                         pending=pending.value)

        if name == "dot_t3":
            if not (2 <= len(args) <= 3):
                self.err(node, "tl.dot_t3 expects (a_t3, buf_or_tok[, acc])")
            a, bb = args[0], args[1]
            acc = args[2] if len(args) == 3 else kwargs.pop("acc", None)
            kw = dict(kwargs)
            pending = kw.pop("PENDING", CExpr(None))
            trans_b = kw.pop("TRANS_B", CExpr(False))
            offset = kw.pop("OFFSET", None)
            if kw:
                self.err(node, f"tl.dot_t3: unexpected kwargs {sorted(kw)}")
            if not isinstance(a, Tensor):
                self.err(node, "tl.dot_t3 a must be a t3 block value")
            if not isinstance(bb, (CExpr, AsyncTok)):
                self.err(node, "tl.dot_t3 b must be a tl.smem buffer or "
                               "an async_copy promise")
            if isinstance(bb, CExpr) and not isinstance(bb.value, SmemBuf):
                self.err(node, "tl.dot_t3 b must be a tl.smem buffer or "
                               "an async_copy promise")
            if not isinstance(pending, CExpr) or not (
                    pending.value is None or isinstance(pending.value, int)):
                self.err(node, "tl.dot_t3 PENDING must be a "
                               "compile-time int")
            if not isinstance(trans_b, CExpr):
                self.err(node, "tl.dot_t3 TRANS_B must be compile-time")
            offset = self._offset_scalar(node, offset)
            pending = self._resolve_pipe_pending(node, bb, pending)
            if acc is not None and not isinstance(acc, Tensor):
                self.err(node, "tl.dot_t3 acc must be a block value "
                               "(or omitted)")
            return b.dot_t3(a, bb.value if isinstance(bb, CExpr) else bb,
                            acc, pending=pending.value,
                            trans_b=bool(trans_b.value), offset=offset)

        if name == "stage":
            self.err(node, "tl.stage is only meaningful as a top-level "
                           "`name = tl.stage(pipe, ptr_tile)` site inside "
                           "a tl.pipelined loop")

        if name == "pipelined":
            self.err(node, "tl.pipelined is only meaningful as the loop "
                           "iterable of `for i in tl.pipelined(range(...), "
                           "stages=N)`")

        if name == "stage_pipe":
            want(2)
            shape = self._shape_value(node, args[0])
            elem = self._dtype_value(node, args[1])
            kw = dict(kwargs)
            trans = kw.pop("TRANS", CExpr(False))
            even = kw.pop("EVEN", CExpr(False))
            if kw:
                self.err(node, f"tl.stage_pipe: unexpected kwargs "
                               f"{sorted(kw)}")
            for v, nm in ((trans, "TRANS"), (even, "EVEN")):
                if not isinstance(v, CExpr):
                    self.err(node, f"tl.stage_pipe {nm} must be compile-time")
            return CExpr(b.stage_pipe(shape, elem,
                                      trans=bool(trans.value),
                                      even=bool(even.value)))

        if name == "async_stage":
            if len(args) != 2:
                self.err(node, "tl.async_stage expects (pipe, b_ptrs)")
            pipe, b_pt = args
            mask = kwargs.pop("MASK", None)
            offset = kwargs.pop("OFFSET", None)
            if kwargs:
                self.err(node, f"tl.async_stage: unexpected kwargs "
                               f"{sorted(kwargs)}")
            if not isinstance(pipe, CExpr) or not isinstance(pipe.value, StagePipe):
                self.err(node, "tl.async_stage pipe must be a tl.stage_pipe "
                               "value")
            if not isinstance(b_pt, PtrTensor):
                self.err(node, "tl.async_stage b must be a pointer tile")
            if mask is not None and not isinstance(mask, SepMask):
                self.err(node, "tl.async_stage MASK must be a symbolic mask "
                               "(or omitted)")
            if isinstance(offset, CExpr) and isinstance(offset.value, int):
                rows, cols = (b_pt.off.shape[1], b_pt.off.shape[0]) \
                    if pipe.value.trans else b_pt.off.shape
                if offset.value + rows * cols \
                        > pipe.value.rows * pipe.value.cols:
                    self.err(node, f"tl.async_stage: OFFSET {offset.value} + "
                                   f"the {rows}x{cols} tile overruns the "
                                   f"{pipe.value.rows}x{pipe.value.cols} pipe "
                                   f"({offset.value + rows * cols} > "
                                   f"{pipe.value.rows * pipe.value.cols} "
                                   "elements)")
            offset = self._offset_scalar(node, offset)
            return b.async_stage(pipe.value, b_pt, mask=mask, offset=offset)

        if name == "async_wait":
            want(2)
            no_kw()
            tok, n = args
            if not isinstance(tok, AsyncTok):
                self.err(node, "tl.async_wait expects an async promise "
                               "(async_stage/async_copy)")
            if not isinstance(n, CExpr) or not isinstance(n.value, int):
                self.err(node, "tl.async_wait pending must be a "
                               "compile-time int")
            b.async_wait(tok, n.value)
            return None

        if name == "smem":
            no_kw()
            want(2)
            shape = self._shape_value(node, args[0])
            dt = self._dtype_value(node, args[1])
            return CExpr(b.smem_alloc(shape, dt))

        if name == "async_copy":
            if len(args) != 2:
                self.err(node, "tl.async_copy expects (buf, ptr_tile)")
            buf, pt = args
            mask = kwargs.pop("MASK", None)
            even = kwargs.pop("EVEN", CExpr(False))
            trans = kwargs.pop("TRANS", CExpr(False))
            offset = kwargs.pop("OFFSET", None)
            if kwargs:
                self.err(node, f"tl.async_copy: unexpected kwargs "
                               f"{sorted(kwargs)}")
            if not isinstance(buf, CExpr) or not isinstance(buf.value, SmemBuf):
                self.err(node, "tl.async_copy buf must be a tl.smem value")
            if not isinstance(pt, PtrTensor):
                self.err(node, "tl.async_copy expects a pointer tile")
            for v, nm in ((even, "EVEN"), (trans, "TRANS")):
                if not isinstance(v, CExpr):
                    self.err(node, f"tl.async_copy {nm} must be compile-time")
            if mask is not None and not isinstance(mask, SepMask):
                self.err(node, "tl.async_copy MASK must be a symbolic mask")
            offset = self._offset_scalar(node, offset)
            return b.async_copy(buf.value, pt, mask=mask,
                                even=bool(even.value),
                                trans=bool(trans.value), offset=offset)

        if name == "barrier":
            want(0)
            no_kw()
            b.barrier()
            return None

        if name == "load_smem":
            want(1)
            no_kw()
            if not isinstance(args[0], CExpr) \
                    or not isinstance(args[0].value, SmemBuf):
                self.err(node, "tl.load_smem expects a tl.smem value")
            return b.load_smem(args[0].value)

        if name == "store_smem":
            want(2)
            no_kw()
            buf, v = args
            if not isinstance(buf, CExpr) or not isinstance(buf.value, SmemBuf):
                self.err(node, "tl.store_smem buf must be a tl.smem value")
            if not isinstance(v, Tensor):
                self.err(node, "tl.store_smem expects a block value")
            b.store_smem(buf.value, v)
            return None

        if name == "constexpr":
            want(1)
            no_kw()
            return CExpr(args[0].value if isinstance(args[0], CExpr) else args[0])

        self.err(node, f"unknown tl.* builtin: tl.{name}")

    def _shape_value(self, node, v):
        if isinstance(v, CExpr):
            s = v.value
            if isinstance(s, int):
                return (s,)
            if isinstance(s, tuple) and all(isinstance(x, int) for x in s):
                if len(s) in (1, 2):
                    return tuple(s)
        self.err(node, f"shape must be a compile-time int or (int, int), got {v!r}")

    def _dtype_value(self, node, v):
        if isinstance(v, CExpr) and isinstance(v.value, tl.DType):
            return v.value
        self.err(node, f"expected a dtype (e.g. tl.float32), got {v!r}")


# ---------------------------------------------------------------------------
# Kernel front end
# ---------------------------------------------------------------------------


class CompiledKernel:
    """A cubin loaded on the default device, with its launch ABI."""

    def __init__(self, name: str, cubin: bytes, bindings: list,
                 num_warps: int, dyn_smem: int = 0, static_smem: int = 0):
        self.name = name
        self.cubin = cubin
        self.bindings = bindings  # per kernel parameter
        self.num_warps = num_warps
        self.num_threads = num_warps * 32
        self.dyn_smem = dyn_smem  # dynamic smem bytes supplied at launch
        dev = get_device()
        self._fn = dev.load_module(cubin).function(name)
        # the driver's default dynamic-smem cap is 48KB MINUS the kernel's
        # static usage, so the opt-in threshold is the combined size
        if dyn_smem > 0 and static_smem + dyn_smem > 48 * 1024:
            self._fn.set_max_dynamic_smem(dyn_smem)

    def launch(self, grid: tuple, args: tuple):
        params = []
        for bind, arg in zip(self.bindings, args):
            kind = bind[0]
            if kind == "ptr":
                vl = tl.VECTOR_LANES[bind[1].name]
                params += memref1d_params(arg.ptr, arg.nelem)
                params += memref1d_params(arg.ptr, arg.nelem // vl)
            elif kind == "i32":
                params.append(ctypes.c_int32(arg))
            elif kind == "f32":
                params.append(ctypes.c_float(arg))
            elif kind == "constexpr":
                continue
            else:
                raise RuntimeError(f"bad binding {bind}")
        g = tuple(grid) + (1, 1, 1)
        self._fn.launch(g[:3], (self.num_threads, 1, 1), params,
                        shared_mem=self.dyn_smem)


class _FastLaunch:
    """Pre-marshalled launch state.

    One entry per (kernel, arg-structure, constexprs, num_warps, grid): the
    ctypes parameter objects and the cuLaunchKernel pointer array are built
    once; a launch then only refreshes the device pointers / scalar values
    in place and hits the driver — no per-launch sha256, binding walk, or
    ctypes allocation. Runtime scalar *values* are deliberately not part of
    the cache key (they are re-written every launch); constexpr values are
    (positional ones key on their value via ``_args_key``'s constexpr
    positions, keyword ones via ``_kw_key``).
    """

    __slots__ = ("drv", "grid", "block", "ptrs", "shared", "_params",
                 "_ptr_slots", "_scalar_slots")

    def __init__(self, ck: "CompiledKernel", grid: tuple, bindings: list,
                 args: tuple):
        params = []
        self._ptr_slots = []     # (arg_pos, base) -> one c_uint64 per ptr
        self._scalar_slots = []  # (arg_pos, index)
        for pos, (bind, arg) in enumerate(zip(bindings, args)):
            kind = bind[0]
            if kind == "ptr":
                vl = tl.VECTOR_LANES[bind[1].name]
                base = len(params)
                # memref ABI (allocated, aligned, offset, size, stride),
                # twice (flat + vectorized twin) — the four pointer slots
                # carry the same address in this runtime, so ALIAS them to
                # one c_uint64: a launch then writes it once per buffer
                # instead of four times
                pp = ctypes.c_uint64(arg.ptr)
                off = ctypes.c_int64(0)
                n_flat = ctypes.c_int64(arg.nelem)
                n_vec = ctypes.c_int64(arg.nelem // vl)
                s1 = ctypes.c_int64(1)
                params += [pp, pp, off, n_flat, s1, pp, pp, off, n_vec, s1]
                self._ptr_slots.append((pos, base))
            elif kind == "i32":
                self._scalar_slots.append((pos, len(params)))
                params.append(ctypes.c_int32(arg))
            elif kind == "f32":
                self._scalar_slots.append((pos, len(params)))
                params.append(ctypes.c_float(arg))
            elif kind == "constexpr":
                continue
            else:
                raise RuntimeError(f"bad binding {bind}")
        self._params = params  # keeps the ctypes objects alive
        self.ptrs = (ctypes.c_void_p * len(params))(
            *[ctypes.addressof(p) for p in params])
        self.drv = ck._fn
        self.grid = tuple(grid) + (1, 1, 1)
        self.block = (ck.num_threads, 1, 1)
        self.shared = ck.dyn_smem

    def __call__(self, args: tuple):
        params = self._params
        for pos, base in self._ptr_slots:
            params[base].value = args[pos].ptr
        for pos, idx in self._scalar_slots:
            params[idx].value = args[pos]
        self.drv.launch_prebuilt(self.grid[:3], self.block, self.ptrs,
                                 self.shared)


_INT_MARK = ("i32",)
_F32_MARK = ("f32",)


def _args_key(args: tuple, ce_positions=frozenset()) -> tuple:
    """Structural cache key for the launch fast path: pointer args key on
    (dtype, nelem) — both baked into the memref ABI — runtime scalars only
    on their kind (values are refreshed per launch). Positions holding a
    ``tl.constexpr`` parameter (``ce_positions``, from the signature) key
    on the VALUE: a different constexpr means a different cubin, so two
    launches differing only there must never share an entry. Raises
    TypeError for argument types the fast path does not handle (caller
    falls back)."""
    out = []
    ap = out.append
    for i, a in enumerate(args):
        if i in ce_positions:
            try:
                hash(a)
            except TypeError:
                a = repr(a)
            ap(("constexpr", a))
        elif isinstance(a, Buffer):
            ap((a.dtype, a.nelem))
        elif type(a) is int:
            ap(_INT_MARK)
        elif type(a) is float:
            ap(_F32_MARK)
        else:
            raise TypeError(f"fast launch: unsupported arg {type(a)}")
    return tuple(out)


def _kw_key(kwargs: dict) -> tuple:
    n = len(kwargs)
    if n == 0:
        return ()
    if n == 1:
        k, v = next(iter(kwargs.items()))
        try:
            hash(v)
        except TypeError:
            v = repr(v)
        return ((k, v),)
    items = []
    for k, v in sorted(kwargs.items()):
        try:
            hash(v)
        except TypeError:
            v = repr(v)
        items.append((k, v))
    return tuple(items)


class Kernel:
    """``@tl.kernel`` decorator product. Launch with ``kernel[grid](*args)``."""

    def __init__(self, fn, autotuner=None):
        self.fn = fn
        self.name = fn.__name__
        self.autotuner = autotuner
        try:
            self.src = textwrap.dedent(inspect.getsource(fn))
        except (OSError, TypeError) as e:
            raise DSLCompileError(
                f"cannot get source of kernel {fn.__name__!r}: {e}") from e
        self.src_lines = self.src.splitlines()
        self.tree = ast.parse(self.src)
        self.gscope = fn.__globals__
        self.sig = inspect.signature(fn)
        self._compiled: dict = {}
        self._fast: dict = {}
        self._launchers: dict = {}

    # -- argument binding -----------------------------------------------------

    def _ce_positions(self) -> frozenset:
        """Positional indices of tl.constexpr parameters (cached; computed
        lazily because _source_kernel instances bypass __init__). _args_key
        keys those positions on their value — the same classification
        _bind applies (the launcher never passes a constexpr_override)."""
        ce = self.__dict__.get("_ce_pos")
        if ce is None:
            ce = self._ce_pos = frozenset(
                i for i, p in enumerate(self.sig.parameters.values())
                if tl.is_constexpr_ann(p.annotation))
        return ce

    def _global_deps(self) -> tuple:
        """(scope, name) pairs of the captured-global superset (cached;
        computed lazily because _source_kernel instances bypass
        __init__)."""
        deps = self.__dict__.get("_deps")
        if deps is None:
            found: list = []
            fndefs = [n for n in self.tree.body
                      if isinstance(n, ast.FunctionDef)]
            if fndefs:
                _collect_global_deps(fndefs[0], self.gscope, found, set())
            deps = self._deps = tuple(found)
        return deps

    def _sample_globals(self) -> tuple:
        """Current keyable values of the captured globals (constexpr
        values, plain numbers, @tl.inline helper sources, ...). Mixed
        into every cache layer's key (mem _compiled, disk cache, launch
        _fast, autotuner _fast) so editing a captured constant or a
        helper's source invalidates all of them — the values bake into
        the MLIR at trace time, so a key that ignores them replays a
        stale cubin."""
        out = []
        for scope, name in self._global_deps():
            try:
                out.append(_sample_global(scope, name))
            except Exception:
                out.append((name, "<unkeyable>"))
        return tuple(out)

    def _bind(self, args: tuple, constexpr_override: dict | None,
              launch_kwargs: dict | None = None):
        """Map positional+keyword args to (binding, value) per signature."""
        params = list(self.sig.parameters.values())
        launch_kwargs = dict(launch_kwargs or {})
        full = list(args)
        for p in params[len(full):]:
            if p.name in launch_kwargs:
                full.append(launch_kwargs.pop(p.name))
        if launch_kwargs:
            raise DSLCompileError(
                f"{self.name}: unexpected arguments {sorted(launch_kwargs)}")
        if len(full) != len(params):
            raise DSLCompileError(
                f"{self.name}: expected {len(params)} arguments, got {len(full)}")
        args = tuple(full)
        bindings, values, constexprs = [], [], []
        for p, a in zip(params, args):
            is_ce = tl.is_constexpr_ann(p.annotation) \
                or (constexpr_override and p.name in constexpr_override)
            if is_ce:
                v = constexpr_override[p.name] if constexpr_override \
                    and p.name in constexpr_override else a
                if isinstance(v, tl.constexpr):
                    v = v.value
                bindings.append(("constexpr", p.name))
                values.append(v)
                constexprs.append((p.name, repr(v)))
                continue
            if isinstance(a, Buffer):
                bindings.append(("ptr", a.dtype))
            elif isinstance(a, bool):
                raise DSLCompileError(
                    f"{self.name}: bool argument {p.name!r} unsupported")
            elif isinstance(a, int):
                if not (-2**31 <= a < 2**31):
                    raise DSLCompileError(
                        f"{self.name}: int argument {p.name}={a} out of i32 "
                        f"range")
                bindings.append(("i32",))
            elif isinstance(a, float):
                bindings.append(("f32",))
            else:
                raise DSLCompileError(
                    f"{self.name}: unsupported argument type for {p.name!r}: "
                    f"{type(a).__name__} (want Buffer/int/float/tl.constexpr)")
            values.append(a)
        return bindings, values, tuple(constexprs)

    # -- compilation -----------------------------------------------------------

    def _compile(self, bindings: list, constexprs: tuple, values: tuple,
                 num_warps: int) -> CompiledKernel:
        sig_key = tuple(b for b in bindings)
        key = rt_cache.make_key(self.src, sig_key, constexprs, num_warps,
                                DEFAULT_CHIP,
                                extra=self._sample_globals())
        hit = self._compiled.get(key)
        if hit is not None:
            return hit
        cubin = rt_cache.get_cache().get(key)
        dyn_smem = 0
        static_smem = 0
        if cubin is None:
            mlir_text, dyn_smem, static_smem = self._emit_mlir(
                bindings, values, num_warps)
            cubin = compile_to_cubin(mlir_text, name=f"{self.name}_{key[:8]}")
            rt_cache.get_cache().put(key, cubin, {
                "kernel": self.name, "signature": repr(sig_key),
                "constexprs": repr(constexprs), "num_warps": num_warps,
                "arch": DEFAULT_CHIP, "dyn_smem": dyn_smem,
                "static_smem": static_smem,
            })
        else:
            # dyn smem is an ABI property of the compiled artifact (a
            # constexpr function); recover it from the meta sidecar on a
            # disk hit (older entries predate the field -> 0 = static only)
            meta = rt_cache.get_cache().get_meta(key)
            dyn_smem = int(meta.get("dyn_smem", 0)) if meta else 0
            static_smem = int(meta.get("static_smem", 0)) if meta else 0
        ck = CompiledKernel(self.name, cubin, bindings, num_warps, dyn_smem,
                            static_smem)
        self._compiled[key] = ck
        return ck

    def _emit_mlir(self, bindings: list, values: tuple, num_warps: int):
        params = []
        env = {}
        for (p, bind, v) in zip(self.sig.parameters.values(), bindings, values):
            if bind[0] == "constexpr":
                env[p.name] = CExpr(v)
            elif bind[0] == "ptr":
                params.append((p.name, ("ptr", bind[1])))
            else:
                params.append((p.name, tl.DTYPES[bind[0]]))
        with Builder(self.name, num_warps * 32) as b:
            env.update(b.begin(params))
            gen = CodeGenerator(b, self.name, self.src_lines, self.gscope, env)
            fndefs = [n for n in self.tree.body if isinstance(n, ast.FunctionDef)]
            if len(fndefs) != 1:
                raise DSLCompileError(
                    f"{self.name}: expected exactly one function definition")
            gen.visit_statements(fndefs[0].body)
            return b.finish(), b.dyn_smem_bytes, b.static_smem_bytes

    # -- launch ------------------------------------------------------------------

    def __getitem__(self, grid):
        try:
            cached = self._launchers.get(grid)
        except TypeError:
            cached = None
        if cached is not None:
            return cached

        def launcher(*args, **kwargs):
            num_warps = kwargs.pop("num_warps", None)
            if self.autotuner is not None:
                return self.autotuner.launch(self, grid, args, num_warps,
                                             kwargs)
            nw = num_warps or 4
            key = None
            if type(grid) is tuple:
                try:
                    key = (nw, grid, _args_key(args, self._ce_positions()),
                           _kw_key(kwargs), self._sample_globals())
                except TypeError:
                    key = None  # unusual arg type: stay on the slow path
            if key is not None:
                fl = self._fast.get(key)
                if fl is not None:
                    fl(args)
                    return fl
            bindings, values, constexprs = self._bind(args, None, kwargs)
            ck = self._compile(bindings, constexprs, values, nw)
            g = grid(dict(zip(self.sig.parameters, values))) \
                if callable(grid) else grid
            # cacheable only when every runtime arg arrived positionally
            # (kwarg-filled params would not line up with raw args later)
            if key is not None and all(
                    b[0] == "constexpr" or i < len(args)
                    for i, b in enumerate(bindings)):
                fl = _FastLaunch(ck, tuple(g), bindings, values)
                self._fast[key] = fl
                fl(args)
                return fl
            ck.launch(tuple(g), tuple(values))
            return None
        try:
            self._launchers[grid] = launcher
        except TypeError:
            pass
        return launcher

    # introspection for autotuner
    def compile_with(self, args: tuple, config: dict, num_warps: int,
                     launch_kwargs: dict | None = None):
        bindings, values, constexprs = self._bind(args, config, launch_kwargs)
        ck = self._compile(bindings, constexprs, values, num_warps)
        return ck, values


def kernel(fn=None, **kwargs):
    """``@tl.kernel`` decorator."""
    if fn is None:
        return lambda f: Kernel(f, **kwargs)
    return Kernel(fn, **kwargs)


def inline(fn):
    """``@tl.inline`` decorator: mark a Python function as a DSL helper
    inlinable into @tl.kernel bodies (the scheduling-helper library's
    mechanism — see minitriton/sched/)."""
    return _InlineFn(fn)
