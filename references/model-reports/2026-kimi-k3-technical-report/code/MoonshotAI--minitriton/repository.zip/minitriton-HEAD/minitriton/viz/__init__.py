"""minitriton.viz — pixel buffer, render kernels, Window.

Sim tensors -> render kernel -> (H, W, 3) f32 pixel buffer on GPU ->
D2H -> PNG frame sequence (headless default) or a pygame window (when a
display is available). Buffer / render / window are three independent
layers:

- ``PixelBuffer`` — the (H, W, 3) f32 GPU canvas; ``resolve()`` clamps to
  [0, 1] and returns uint8 (D2H sync); ``save_png()`` uses the stdlib PNG
  writer (no PIL/matplotlib dependency).
- render passes ``clear/particles/heatmap/mesh`` — @tl.kernel scatter /
  sample writes *into* an existing buffer, so passes compose on a frame.
  World coords are [0, 1] with y up (sim convention) by default.
- ``Window`` — ``show(buf)`` + event polling (space = pause, n = single
  step, esc/close = quit). With ``display=True`` it tries pygame and
  automatically degrades to the frame mode when no display is available
  (headless servers). Frame mode saves ``frame_%05d.png`` under
  ``frames_dir`` every ``save_every`` calls.
"""

from __future__ import annotations

import tempfile
import warnings
from pathlib import Path

import numpy as np

import minitriton as tl

from . import _cmap, _png, kernels as _K

__all__ = [
    "PixelBuffer", "Window", "clear", "particles", "heatmap", "mesh",
    "CMAPS", "lookup",
]


class PixelBuffer:
    """(H, W, 3) f32 canvas living on the GPU."""

    def __init__(self, H: int, W: int, device: str = "cuda"):
        if H < 1 or W < 1:
            raise ValueError(f"PixelBuffer dims must be >= 1, got {H}x{W}")
        self.H, self.W = int(H), int(W)
        self.tensor = tl.zeros((self.H, self.W, 3), tl.float32, device)
        if device != "cuda":
            warnings.warn("viz render kernels are CUDA; PixelBuffer on "
                          f"{device!r} can only hold data", stacklevel=2)

    @property
    def shape(self) -> tuple[int, int]:
        return (self.H, self.W)

    def resolve(self) -> np.ndarray:
        """D2H sync -> (H, W, 3) uint8, values clamped to [0, 1]."""
        f = np.clip(self.tensor.numpy().astype(np.float64), 0.0, 1.0)
        return np.round(f * 255.0).astype(np.uint8)

    def save_png(self, path) -> None:
        _png.write_png(str(path), self.resolve())

    def write_png(self, path) -> None:
        warnings.warn("write_png is deprecated; use save_png",
                      DeprecationWarning, stacklevel=2)
        self.save_png(path)


# ---------------------------------------------------------------------------
# render passes (in place on a PixelBuffer)
# ---------------------------------------------------------------------------

def clear(buf: PixelBuffer, color=(0.0, 0.0, 0.0)) -> PixelBuffer:
    """Fill the whole frame with a color (default black)."""
    r, g, b = (float(c) for c in color)
    _K.launch_fill(buf.tensor, r, g, b)
    return buf


def particles(buf: PixelBuffer, x, y, color=(0.9, 0.9, 0.9), radius: int = 0,
              y_up: bool = True) -> PixelBuffer:
    """Scatter plot particles at world pos (x, y) 1D f32 tensors."""
    x = tl.ops._tensor(x).contiguous()
    y = tl.ops._tensor(y).contiguous()
    n = x.numel()
    if y.numel() != n:
        raise RuntimeError(f"x/y length mismatch: {n} vs {y.numel()}")
    if n and radius >= 0:
        _K.launch_particles(buf.tensor, x, y, n, buf.W, buf.H, color,
                            radius, y_up)
    return buf


def heatmap(buf: PixelBuffer, field, cmap: str = "viridis",
            vmin=None, vmax=None) -> PixelBuffer:
    """Nearest-sample a 2D field tensor up to the frame resolution and map
    it through an 8-stop piecewise-linear colormap (see viz._cmap).
    vmin/vmax default to the field min/max (a D2H sync; pass explicit
    values in hot loops)."""
    field = tl.ops._tensor(field).contiguous()
    if field.ndim != 2:
        raise RuntimeError(f"heatmap field must be 2D, got {field.shape}")
    lo = float(field.min().numpy()) if vmin is None else float(vmin)
    hi = float(field.max().numpy()) if vmax is None else float(vmax)
    dr = hi - lo
    if dr <= 0:
        dr = 1.0
    stops = tl.tensor(np.asarray(_cmap.stops_flat(cmap), dtype=np.float32),
                      device=field.device)
    _K.launch_heatmap(buf.tensor, field, stops, lo, dr, buf.W, buf.H)
    return buf


def mesh(buf: PixelBuffer, verts, edges, vcolor=(0.9, 0.9, 0.9),
         ecolor=(0.3, 0.6, 1.0), y_up: bool = True) -> PixelBuffer:
    """Wireframe-lite: vertex dots + edge midpoints. verts (V, 2) f32 world
    coords, edges (E, 2) int indices."""
    verts = tl.ops._tensor(verts)
    edges = tl.ops._tensor(edges)
    if verts.ndim != 2 or verts.shape[1] != 2:
        raise RuntimeError(f"mesh verts must be (V, 2), got {verts.shape}")
    if edges.ndim != 2 or edges.shape[1] != 2:
        raise RuntimeError(f"mesh edges must be (E, 2), got {edges.shape}")
    e = edges.shape[0]
    if e:
        # kernels index flat buffers: views must be materialized, and
        # offsets are i32 blocks (numpy integer arrays default to i64)
        _K.launch_mesh(buf.tensor, verts.contiguous(),
                       edges.contiguous().astype(tl.int32),
                       e, buf.W, buf.H, vcolor, ecolor, y_up)
    return buf


CMAPS = _cmap.CMAPS
lookup = _cmap.lookup


# ---------------------------------------------------------------------------
# Window
# ---------------------------------------------------------------------------

def _try_display(W: int, H: int, title: str):
    """Import pygame and open a window; raises when headless/unavailable."""
    import pygame
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption(title)
    return pygame, screen


class Window:
    """Event-capable display front for the pixel buffer.

    ``show(buf)`` returns one of "continue" / "paused" / "quit". Keys
    (display mode): SPACE toggles pause, n = advance one step while
    paused, ESC/close = quit. Frame mode never reports pause/quit keys;
    pass ``max_frames`` to stop a headless run.
    """

    def __init__(self, H: int, W: int, title: str = "minitriton.viz",
                 frames_dir=None, display: bool = False, fps: int = 60,
                 save_every: int = 1, max_frames: int | None = None):
        self.H, self.W = int(H), int(W)
        self.mode = "frames"
        self._pg = None
        self._screen = None
        if display:
            try:
                self._pg, self._screen = _try_display(self.W, self.H, title)
                self.mode = "display"
            except Exception as e:  # headless: SDL cannot open a window
                warnings.warn(f"viz: display unavailable ({e}); using PNG "
                              "frames", stacklevel=2)
        if self.mode == "frames":
            d = frames_dir or tempfile.mkdtemp(prefix="mt_viz_frames_")
            self.frames_dir = Path(d)
            self.frames_dir.mkdir(parents=True, exist_ok=True)
        else:
            self.frames_dir = (Path(frames_dir) if frames_dir else None)
            if self.frames_dir:
                self.frames_dir.mkdir(parents=True, exist_ok=True)
        self.fps = int(fps)
        self.save_every = max(1, int(save_every))
        self.max_frames = max_frames
        self.count = 0
        self.paused = False
        self.quit = False
        self._step_once = False
        self._clock = self._pg.time.Clock() if self._pg else None

    def _pump(self):
        for ev in self._pg.event.get():
            if ev.type == self._pg.QUIT:
                self.quit = True
            elif ev.type == self._pg.KEYDOWN:
                if ev.key == self._pg.K_ESCAPE:
                    self.quit = True
                elif ev.key == self._pg.K_SPACE:
                    self.paused = not self.paused
                elif ev.key == self._pg.K_n:
                    self._step_once = True

    def _save_frame(self, u8: np.ndarray):
        p = self.frames_dir / f"frame_{self.count:05d}.png"
        _png.write_png(str(p), u8)
        return p

    def show(self, buf: PixelBuffer) -> str:
        """Present a frame; returns 'continue' | 'paused' | 'quit'."""
        if self.max_frames is not None and self.count >= self.max_frames:
            return "quit"
        u8 = buf.resolve() if isinstance(buf, PixelBuffer) else buf
        if self.mode == "frames":
            if self.count % self.save_every == 0 and self.frames_dir:
                self._save_frame(u8)
            self.count += 1
            return "continue"
        # display mode
        self._pump()
        if self.quit:
            return "quit"
        if self.frames_dir and self.count % self.save_every == 0:
            self._save_frame(u8)
        if self.paused and not self._step_once:
            self._clock.tick(self.fps)
            return "paused"
        self._step_once = False
        surf = self._pg.surfarray.make_surface(
            np.ascontiguousarray(u8.transpose(1, 0, 2)))
        self._screen.blit(surf, (0, 0))
        self._pg.display.flip()
        self._clock.tick(self.fps)
        self.count += 1
        return "continue"

    def frame_count_reached(self) -> bool:
        """True once max_frames have been presented (any mode)."""
        return (self.max_frames is not None
                and self.count >= self.max_frames)

    def close(self):
        if self._pg:
            self._pg.quit()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
