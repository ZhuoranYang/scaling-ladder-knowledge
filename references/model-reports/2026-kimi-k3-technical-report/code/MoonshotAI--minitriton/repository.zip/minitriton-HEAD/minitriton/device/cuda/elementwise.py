"""Generic elementwise/copy kernel generator for the CUDA backend: one
generator emits the @tl.kernel *source* for every elementwise op, then
reuses the normal compile+cache pipeline. Three kernel shapes cover all
access patterns: ``flat`` (contiguous same-shape 1D), ``scalar`` (tensor
op python-scalar), ``nd`` (universal strided/broadcast, ndim <= 6).
"""

from __future__ import annotations

import ast
import inspect
import numbers
import re
import textwrap

from ... import precision as _prec
from ...frontend import types as tl_types
from ...frontend.code_generator import Kernel
from ...tensor import Tensor, empty, _contig_strides, promote_dtype

_NUM_WARPS = 4
_THREADS = _NUM_WARPS * 32
_FLAT_BLOCK = 1024
_ND_BLOCK_CHOICES = (128, 256, 512, 1024, 2048, 4096)
_MAX_NDIM = 6

# i32 addressing backstop: the DSL kernels' address algebra (and every
# int kernel arg) is i32, so a single tensor at/over 2**31 elements wraps
# addresses — nondeterministic CUDA_ERROR_ILLEGAL_ADDRESS or, worse,
# silent reads/writes of other allocations. launch_flat/launch_nd below
# refuse such launches loudly. The norm/misc/ce row kernels are NOT
# guarded here on purpose: they row-chunk over-budget inputs
# (kernels/{norm,misc,ce}.py `_I32_ELEM_BUDGET`).
_I32_ELEM_LIMIT = 1 << 31

_kernel_cache: dict = {}


def _i32_guard_msg(op: str, what: str, n: int) -> str:
    return (f"{op}: {what} {n} >= 2^31 — this CUDA path uses i32 address "
            f"arithmetic, so a single tensor is limited to 2^31 - 1 "
            f"elements; the norm/misc/cross-entropy row "
            f"kernels support row-chunked processing of larger inputs — "
            f"route through them or split the tensor")


def _guard_i32_numel(n: int, op: str) -> None:
    """Raise loudly when an element count crosses the i32 addressing
    limit (at exactly 2**31 the numel kernel arg itself overflows i32)."""
    if n >= _I32_ELEM_LIMIT:
        raise RuntimeError(_i32_guard_msg(op, "element count", n))


def _guard_i32_offset(span: int, op: str) -> None:
    """Raise loudly when a max reachable element offset (0-based) leaves
    the i32 range: strided views of an over-limit base tensor wrap their
    in-kernel i32 stride products even when the view itself is small."""
    if span >= _I32_ELEM_LIMIT:
        raise RuntimeError(_i32_guard_msg(op, "max element offset", span))


def _i32_span(t) -> int:
    """Max reachable element offset (0-based) of a (possibly strided)
    tensor view: the sum over dims of (shape - 1) * stride. The launch
    pointer already carries the view offset, so this is exactly the
    range the in-kernel i32 address algebra must cover."""
    return sum((int(s) - 1) * int(st)
               for s, st in zip(t.shape, t.strides))


def _tl_module():
    import minitriton as tl_pkg
    return tl_pkg


def _source_kernel(name: str, src: str, params: list[str],
                   constexprs: frozenset[str]) -> Kernel:
    src = textwrap.dedent(src)
    tree = ast.parse(src)
    fndefs = [n for n in tree.body if isinstance(n, ast.FunctionDef)]
    assert len(fndefs) == 1, f"generated kernel {name} must have one def"
    sig = inspect.Signature([
        inspect.Parameter(
            p, inspect.Parameter.POSITIONAL_OR_KEYWORD,
            annotation=tl_types.constexpr if p in constexprs
            else inspect.Parameter.empty)
        for p in params
    ])
    k = Kernel.__new__(Kernel)
    k.fn = None
    k.name = name
    k.autotuner = None
    k.src = src
    k.src_lines = src.splitlines()
    k.tree = tree
    k.gscope = {"tl": _tl_module()}
    k.sig = sig
    k._compiled = {}
    k._fast = {}
    k._launchers = {}
    return k


def _dt(dtype) -> str:
    return {"f32": "tl.float32", "f16": "tl.float16", "bf16": "tl.bfloat16",
            "i32": "tl.int32", "i64": "tl.int64"}[dtype.name]


def _wrap_compute(val: str, in_dt, compute_dt) -> str:
    """load-cast wrapper for one operand value (store-cast is the
    caller's _cast_out)."""
    if in_dt != compute_dt:
        val = f"tl.cast({val}, {_dt(compute_dt)})"
    return val


def _cast_out(expr: str, compute_dt, out_dt) -> str:
    if compute_dt != out_dt:
        return f"tl.cast(({expr}), {_dt(out_dt)})"
    return expr


# ---------------------------------------------------------------------------
# flat kernels
# ---------------------------------------------------------------------------

def flat_unary(name: str, expr: str, in_dt, out_dt, compute_dt) -> Kernel:
    """expr uses {x}; grid = ceil(N / 1024)."""
    key = ("fu", expr, in_dt.name, out_dt.name, compute_dt.name)
    k = _kernel_cache.get(key)
    if k is None:
        x = _wrap_compute("x", in_dt, compute_dt)
        body = _cast_out(expr.format(x=x), compute_dt, out_dt)
        k = _source_kernel(name, f"""
            @tl.kernel
            def {name}(x_ptr, out_ptr, N, BLOCK: tl.constexpr):
                pid = tl.program_id(0)
                offs = pid * BLOCK + tl.arange(0, BLOCK)
                m = offs < N
                x = tl.load(x_ptr + offs, mask=m)
                tl.store(out_ptr + offs, {body}, mask=m)
            """, ["x_ptr", "out_ptr", "N", "BLOCK"], frozenset({"BLOCK"}))
        _kernel_cache[key] = k
    return k


def flat_binary(name: str, expr: str, a_dt, b_dt, out_dt,
                compute_dt) -> Kernel:
    """expr uses {a} {b}; both operands contiguous, same shape. Mixed
    input dtypes cast to compute_dt at load (same source when
    a_dt == b_dt, so same-dtype ops reuse their cubins)."""
    key = ("fb2", expr, a_dt.name, b_dt.name, out_dt.name, compute_dt.name)
    k = _kernel_cache.get(key)
    if k is None:
        a = _wrap_compute("a", a_dt, compute_dt)
        b = _wrap_compute("b", b_dt, compute_dt)
        body = _cast_out(expr.format(a=a, b=b), compute_dt, out_dt)
        k = _source_kernel(name, f"""
            @tl.kernel
            def {name}(a_ptr, b_ptr, out_ptr, N, BLOCK: tl.constexpr):
                pid = tl.program_id(0)
                offs = pid * BLOCK + tl.arange(0, BLOCK)
                m = offs < N
                a = tl.load(a_ptr + offs, mask=m)
                b = tl.load(b_ptr + offs, mask=m)
                tl.store(out_ptr + offs, {body}, mask=m)
            """, ["a_ptr", "b_ptr", "out_ptr", "N", "BLOCK"],
            frozenset({"BLOCK"}))
        _kernel_cache[key] = k
    return k


def scalar_binary(name: str, expr: str, t_dt, out_dt, compute_dt,
                  s_kind: str, side: str) -> Kernel:
    """tensor <op> scalar; scalar passed as f32 (s_kind='f') or i32 ('i')
    kernel argument named s; side='r' -> x op s, side='l' -> s op x."""
    key = ("sb", expr, t_dt.name, out_dt.name, compute_dt.name, s_kind, side)
    k = _kernel_cache.get(key)
    if k is None:
        x = _wrap_compute("x", t_dt, compute_dt)
        if s_kind == "f" and compute_dt != tl_types.float32:
            s = f"tl.cast(s, {_dt(compute_dt)})"
        else:
            s = "s"
        a, b = (x, s) if side == "r" else (s, x)
        body = _cast_out(expr.format(a=a, b=b), compute_dt, out_dt)
        k = _source_kernel(name, f"""
            @tl.kernel
            def {name}(x_ptr, out_ptr, s, N, BLOCK: tl.constexpr):
                pid = tl.program_id(0)
                offs = pid * BLOCK + tl.arange(0, BLOCK)
                m = offs < N
                x = tl.load(x_ptr + offs, mask=m)
                tl.store(out_ptr + offs, {body}, mask=m)
            """, ["x_ptr", "out_ptr", "s", "N", "BLOCK"],
            frozenset({"BLOCK"}))
        _kernel_cache[key] = k
    return k


# ---------------------------------------------------------------------------
# universal nd kernel
# ---------------------------------------------------------------------------

def nd_block(n_cols: int) -> int:
    for c in _ND_BLOCK_CHOICES:
        if c >= max(n_cols, _THREADS):
            return c
    return _ND_BLOCK_CHOICES[-1]


def short_rows(out_shape) -> bool:
    """Whether the shape is short-row/high-grid (the 64-wide heads-copy
    class), so the 4-row pipelined template + row-blocked grid apply.
    Template/RPB mismatches stay numerically safe (clamped sub-rows)."""
    rows = 1
    for s in tuple(out_shape)[:-1]:
        rows *= s
    cols = out_shape[-1] if out_shape else 1
    return 1 <= cols < 2048 and rows >= 1024


def _divmod_chain(ndim: int, var: str = "pid") -> tuple[list[str], list[str]]:
    """(divisor arg names, source lines) decomposing `var` into
    i0..i_{n-2}."""
    divs = [f"D{d}" for d in range(1, ndim - 1)]  # D_d = prod(shape[d:-1])
    lines = []
    for d in range(ndim - 1):
        if d == ndim - 2:
            lines.append(f"i{d} = rem" if d else f"i0 = {var}")
        elif d == 0:
            lines.append(f"i0 = {var} // D1")
            lines.append(f"rem = {var} - i0 * D1")
        else:
            lines.append(f"i{d} = rem // D{d + 1}")
            lines.append(f"rem = rem - i{d} * D{d + 1}")
    return divs, lines


def _operand_load(tag: str, dtype, ndim: int, vec_mode: int,
                  compute_dt) -> tuple[list[str], list[str], str]:
    """-> (param names, source lines, value var name). vec_mode: 1 = unit
    stride vector load, 0 = stride-0 (scalar + splat), 2 = runtime stride
    (arg <tag>sL)."""
    params = [f"{tag}_ptr"] + [f"{tag}s{d}" for d in range(ndim - 1)]
    base = f"{tag}_base"
    lines = []
    acc = None
    for d in range(ndim - 1):
        term = f"i{d} * {tag}s{d}"
        acc = term if acc is None else f"{acc} + {term}"
    lines.append(f"{base} = {acc}" if acc else f"{base} = 0")
    if vec_mode == 1:
        lines.append(f"{tag} = tl.load({tag}_ptr + {base} + (c0 + offs), "
                     f"mask=m)")
    elif vec_mode == 0:
        lines.append(f"{tag}_v = tl.load({tag}_ptr + {base})")
        lines.append(f"{tag} = tl.zeros((BLOCK,), {_dt(dtype)}) + {tag}_v")
    else:
        params.append(f"{tag}sL")
        lines.append(f"{tag} = tl.load({tag}_ptr + {base} + "
                     f"(c0 + offs) * {tag}sL, mask=m)")
    val = tag
    if dtype != compute_dt:
        lines.append(f"{tag} = tl.cast({tag}, {_dt(compute_dt)})")
    return params, lines, val


def nd_binary(name: str, expr: str, ndim: int, a_dt, b_dt, out_dt,
              compute_dt, a_mode: int, b_mode: int) -> Kernel:
    """Universal broadcast/strided binary kernel (see module docstring).
    RPB row-block: each program handles RPB outer rows (short-row shapes
    otherwise launch one nearly-idle program per 64-wide row)."""
    key = ("ndb", expr, ndim, a_dt.name, b_dt.name, out_dt.name,
           compute_dt.name, a_mode, b_mode)
    k = _kernel_cache.get(key)
    if k is None:
        divs, chain = _divmod_chain(ndim, "rr")
        pa, la, va = _operand_load("a", a_dt, ndim, a_mode, compute_dt)
        pb, lb, vb = _operand_load("b", b_dt, ndim, b_mode, compute_dt)
        out_st = [f"os{d}" for d in range(ndim - 1)]
        oacc = " + ".join(f"i{d} * os{d}" for d in range(ndim - 1))
        obase = f"obase + {oacc}" if oacc else "obase"
        body = _cast_out(expr.format(a=va, b=vb), compute_dt, out_dt)
        i1 = "        "
        i2 = "            "
        src_lines = [
            f"@tl.kernel",
            f"def {name}(a_ptr, b_ptr, out_ptr, C, R, "
            + ", ".join(divs + pa[1:] + pb[1:] + out_st + ["obase"])
            + ", BLOCK: tl.constexpr, RPB: tl.constexpr):",
            f"{i1}pid = tl.program_id(0)",
            f"{i1}r0 = pid * RPB",
            f"{i1}r1 = tl.where(r0 + RPB < R, r0 + RPB, R)",
            f"{i1}offs = tl.arange(0, BLOCK)",
            f"{i1}for rr in range(r0, r1):",
            *[f"{i2}{l}" for l in chain],
            f"{i2}for c0 in range(0, C, BLOCK):",
            f"{i2}    m = (c0 + offs) < C",
            *[f"{i2}    {l}" for l in la + lb],
            f"{i2}    tl.store(out_ptr + {obase} + (c0 + offs), "
            f"{body}, mask=m)",
        ]
        params = ["a_ptr", "b_ptr", "out_ptr", "C", "R"] + divs + pa[1:] + \
            pb[1:] + out_st + ["obase", "BLOCK", "RPB"]
        k = _source_kernel(name, "\n".join(src_lines), params,
                           frozenset({"BLOCK", "RPB"}))
        _kernel_cache[key] = k
    return k


def nd_unary(name: str, expr: str, ndim: int, in_dt, out_dt, compute_dt,
             in_mode: int, out_mode: int = 1,
             pipelined: bool = False) -> Kernel:
    """Universal strided unary kernel; also the copy/cast/cat engine
    (expr = 'x' copies, expr = 'tl.cast(...)' casts). pipelined: RPB rows
    per program, four rows pipelined per iteration (short-row shapes),
    out-of-range sub-rows clamped onto the last valid row. out_mode:
    1 = unit-stride store, 2 = runtime last-dim stride (arg ``osL``,
    used by copy_into_view)."""
    key = ("ndu", expr, ndim, in_dt.name, out_dt.name, compute_dt.name,
           in_mode, out_mode, pipelined)
    k = _kernel_cache.get(key)
    if k is None:
        out_st = [f"os{d}" for d in range(ndim - 1)]
        body = _cast_out(expr.format(x="{X}"), compute_dt, out_dt)
        olast = "(c0 + offs)" if out_mode == 1 else "(c0 + offs) * osL"
        i1, i2, i3 = "        ", "            ", "                "
        px = [f"xs{d}" for d in range(ndim - 1)]

        def one_row(sfx: str, rvar: str) -> list[str]:
            """Scalar index lines for sub-row `rvar` (renamed div/mod +
            base accumulations suffixed `sfx`)."""
            _, chain = _divmod_chain(ndim, rvar)
            ren = {f"i{d}": f"i{d}{sfx}" for d in range(ndim - 1)}
            ren["rem"] = f"rem{sfx}"
            out_l = []
            for l in chain:
                for a_, b_ in ren.items():
                    l = re.sub(rf"\b{a_}\b", b_, l)
                out_l.append(l)
            acc = " + ".join(f"i{d}{sfx} * {px[d]}" for d in range(ndim - 1))
            out_l.append(f"xbase{sfx} = {acc}" if acc else f"xbase{sfx} = 0")
            oacc = " + ".join(f"i{d}{sfx} * {out_st[d]}"
                              for d in range(ndim - 1))
            out_l.append(f"obase{sfx} = obase + {oacc}" if oacc
                         else f"obase{sfx} = obase")
            return out_l

        def vec_load(sfx: str) -> list[str]:
            if in_mode == 1:
                out_l = [f"x{sfx} = tl.load(x_ptr + xbase{sfx} + "
                         f"(c0 + offs), mask=m)"]
            elif in_mode == 0:
                out_l = [f"x{sfx}_v = tl.load(x_ptr + xbase{sfx})",
                         f"x{sfx} = tl.zeros((BLOCK,), {_dt(in_dt)}) + "
                         f"x{sfx}_v"]
            else:
                out_l = [f"x{sfx} = tl.load(x_ptr + xbase{sfx} + "
                         f"(c0 + offs) * xsL, mask=m)"]
            if in_dt != compute_dt:
                out_l.append(f"x{sfx} = tl.cast(x{sfx}, {_dt(compute_dt)})")
            return out_l

        def store(sfx: str) -> str:
            return (f"tl.store(out_ptr + obase{sfx} + {olast}, "
                    f"{body.format(X='x' + sfx)}, mask=m)")

        params_extra = ["xsL"] if in_mode == 2 else []
        # out_mode == 2: the store's last-dim stride is a runtime arg too
        # (osL) — it must be in the signature or every positional after
        # it binds one slot early (the launch_nd arg order is ptrs, C, R,
        # divs, per-operand strides+[sL], out strides, [osL], obase)
        params_os = ["osL"] if out_mode == 2 else []
        divs = [f"D{d}" for d in range(1, ndim - 1)]
        head = [
            f"@tl.kernel",
            f"def {name}(x_ptr, out_ptr, C, R, "
            + ", ".join(divs + px + params_extra + out_st + params_os
                        + ["obase"])
            + ", BLOCK: tl.constexpr, RPB: tl.constexpr):",
            f"{i1}pid = tl.program_id(0)",
            f"{i1}r0 = pid * RPB",
            f"{i1}r1 = tl.where(r0 + RPB < R, r0 + RPB, R)",
            f"{i1}offs = tl.arange(0, BLOCK)",
        ]
        if pipelined:
            pre, loads, stores = [], [], []
            for u in range(4):
                sfx = f"u{u}"
                if u:
                    pre.append(f"rk{u} = tl.where(rr + {u} < r1, rr + {u},"
                               f" r1 - 1)")
                    pre += one_row(sfx, f"rk{u}")
                else:
                    pre += one_row(sfx, "rr")
                loads += vec_load(sfx)
                stores.append(store(sfx))
            src_lines = head + [
                f"{i1}for rr in range(r0, r1, 4):",
                *[f"{i2}{l}" for l in pre],
                f"{i2}for c0 in range(0, C, BLOCK):",
                f"{i3}m = (c0 + offs) < C",
                *[f"{i3}{l}" for l in loads],
                *[f"{i3}{l}" for l in stores],
            ]
        else:
            pre = one_row("u0", "rr")
            src_lines = head + [
                f"{i1}for rr in range(r0, r1):",
                *[f"{i2}{l}" for l in pre],
                f"{i2}for c0 in range(0, C, BLOCK):",
                f"{i3}m = (c0 + offs) < C",
                *[f"{i3}{l}" for l in vec_load("u0")],
                f"{i3}{store('u0')}",
            ]
        params = ["x_ptr", "out_ptr", "C", "R"] + divs + px + \
            params_extra + out_st + params_os + ["obase", "BLOCK", "RPB"]
        k = _source_kernel(name, "\n".join(src_lines), params,
                           frozenset({"BLOCK", "RPB"}))
        _kernel_cache[key] = k
    return k


# ---------------------------------------------------------------------------
# launchers (host side)
# ---------------------------------------------------------------------------

def _base16_ok(t) -> bool:
    """Effective 16B alignment of a (possibly view-offset) tensor's base:
    pools are >=256B aligned, so the view byte offset decides — vectorized
    paths must check this (the in-kernel check can't see the offset)."""
    return (t._offset * t.dtype.itemsize) % 16 == 0


def operand_spec(t, out_shape) -> tuple:
    """(buffer_arg, row_strides, vec_mode, last_stride) for operand t
    (already broadcast/reshaped to out_shape). vec_mode: 1 = unit stride,
    0 = broadcast/scalar (stride 0 or size-1), 2 = runtime stride."""
    st = t.strides
    row = [int(s) for s in st[:-1]]
    sl = int(st[-1])
    if t.shape[-1] == 1 and out_shape[-1] > 1:
        mode, sl = 0, 0
    elif sl == 0:
        mode = 0
    elif sl == 1 and _base16_ok(t):
        mode = 1
    else:
        mode = 2  # runtime stride (scalar loads); also the misaligned base
    return (t._buffer_arg(), row, mode, sl)


def launch_flat(k: Kernel, bufs: list, n: int, extra: list = ()):
    """Launch a flat elementwise kernel; returns the resolved launch plan
    (_FastLaunch) when the kernel fast-pathed (used by the op-level plan
    cache in device/cuda/ops.py; None on the slow path)."""
    _guard_i32_numel(n, "elementwise flat kernel")
    grid = ((n + _FLAT_BLOCK - 1) // _FLAT_BLOCK,)
    return k[grid](*bufs, *extra, n, BLOCK=_FLAT_BLOCK, num_warps=_NUM_WARPS)


def launch_nd(k: Kernel, ndim: int, out_shape, operands: list, out_buf,
              out_strides=None, out_base: int = 0, out_last_stride: int = 1):
    """Launch an nd kernel. operands: operand_spec() tuples; arg order
    matches the codegen exactly: ptrs..., C, divs..., per-operand (row
    strides + [sL]), out strides, [osL], obase."""
    from ...tensor import _contig_strides  # local import: avoid cycle
    rows = 1
    for s in out_shape[:-1]:
        rows *= s
    n_cols = out_shape[-1] if out_shape else 1
    if rows == 0 or n_cols == 0:
        return
    divs = []
    for d in range(1, ndim - 1):
        v = 1
        for s in out_shape[d:-1]:
            v *= s
        divs.append(v)
    ost = list(out_strides) if out_strides is not None else \
        list(_contig_strides(out_shape)[:-1])
    # i32 addressing backstop: the out element count, each operand's max
    # reachable offset, and the out buffer's max reachable offset (cat
    # passes a big obase into a shared buffer) must all stay below 2**31
    # — refuse loudly instead of wrapping into other memory.
    _guard_i32_numel(rows * n_cols, "elementwise nd kernel")
    for _, row_st, mode, sl in operands:
        span = sum((int(out_shape[d]) - 1) * st
                   for d, st in enumerate(row_st))
        if mode == 1:
            span += n_cols - 1
        elif mode == 2:
            span += (n_cols - 1) * sl
        _guard_i32_offset(span, "elementwise nd kernel operand")
    ospan = out_base + (n_cols - 1) * out_last_stride + \
        sum((int(out_shape[d]) - 1) * int(s) for d, s in enumerate(ost))
    _guard_i32_offset(ospan, "elementwise nd kernel output")
    args = [spec[0] for spec in operands]
    args.append(out_buf)
    args.append(int(n_cols))
    args += divs
    for buf, row_st, mode, sl in operands:
        args += row_st
        if mode == 2:
            args.append(sl)
    args += [int(s) for s in ost]
    if out_last_stride != 1:
        args.append(int(out_last_stride))
    args.append(int(out_base))
    block = nd_block(n_cols)
    # row-block: short rows (e.g. 64-wide heads) would otherwise launch
    # one program per row — 300K+ tiny programs for one contiguous() call.
    if short_rows(out_shape):
        rpb = max(4, min(16, 512 // max(n_cols, 1)))
    else:
        rpb = 1
    args.insert(len(operands) + 2, int(rows))   # R right after C
    fl = k[((rows + rpb - 1) // rpb,)](*args, BLOCK=block, RPB=rpb,
                                       num_warps=_NUM_WARPS)
    return fl, args


# ---------------------------------------------------------------------------
# elementwise expression vocabulary + op dispatch (moved out of ops.py)
# ---------------------------------------------------------------------------
# The expr tables are the generator's input vocabulary: the kind tags
# drive compute-dtype routing, the templates are the DSL source it
# compiles. The functions below are the launch dispatch plus the shared
# op-launch plan cache (kept here: this module is the device layer's
# leaf — importing it any higher would cycle).
# ---------------------------------------------------------------------------
# elementwise expression tables
# ---------------------------------------------------------------------------

_GELU_C = "0.7978845608028654"  # sqrt(2/pi)

# op -> (expr template, compute kind): "arith" computes in the tensor's
# own dtype; "f32" casts operands to f32 in-kernel (approx PTX math).
_UNARY = {
    "neg": ("(-({x}))", "arith"),
    "abs": ("tl.where({x} < 0, -({x}), {x})", "arith"),
    "relu": ("tl.where({x} > 0, {x}, {zero})", "arith"),
    "exp": ("tl.exp({x})", "f32"),
    "log": ("tl.log({x})", "f32"),
    "sqrt": ("tl.sqrt({x})", "f32"),
    "tanh": ("(1.0 - 2.0 / (tl.exp(2.0 * ({x})) + 1.0))", "f32"),
    "sigmoid": ("(1.0 / (1.0 + tl.exp(-({x}))))", "f32"),
    # stable log(sigmoid(x)) = min(x, 0) - log(1 + exp(-|x|)) (KDA decay
    # gates: naive log(sigmoid(x)) underflows fp32 below ~ -87)
    "log_sigmoid": ("(tl.where({x} > 0, 0.0, {x}) "
                    "- tl.log(tl.exp(-(tl.where({x} < 0, -({x}), {x}))) "
                    "+ 1.0))", "f32"),
    "gelu": ("(0.5 * ({x}) * (1.0 + (1.0 - 2.0 / (tl.exp(2.0 * "
             + _GELU_C + " * (({x}) + 0.044715 * ({x}) * ({x}) * ({x}))) "
             "+ 1.0))))", "f32"),
    "silu": ("(({x}) * (1.0 / (1.0 + tl.exp(-({x})))))", "f32"),
}

_BINARY = {
    "add": "({a} + {b})",
    "sub": "({a} - {b})",
    "mul": "({a} * {b})",
    "div": "({a} / {b})",
    "pow": "tl.exp(({b}) * tl.log({a}))",  # tensor ** tensor (float only)
}

# Comparison ops (eager dunder path): predicate evaluated in the promoted
# input dtype (exact for int pairs), stored as an f32 1.0/0.0 mask — no
# bool dtype (torch deviation: the result dtype is f32, not bool).
_BINARY_CMP = {
    "eq": "({a} == {b})",
    "ne": "({a} != {b})",
    "lt": "({a} < {b})",
    "le": "({a} <= {b})",
    "gt": "({a} > {b})",
    "ge": "({a} >= {b})",
}

# Backward exprs: (g, x-or-y) -> input grad, same elementwise
# generator path as the forward ops. kind semantics as in _UNARY.
_GELU_U = ("(" + _GELU_C + " * (({b}) + 0.044715 * ({b}) * ({b}) * ({b})))")
_GELU_T = ("(1.0 - 2.0 / (tl.exp(2.0 * (" + _GELU_U + ")) + 1.0))")
_SILU_S = "(1.0 / (1.0 + tl.exp(-({b}))))"

_BINARY_BW = {
    "relu_bw": ("(tl.where({b} > 0, {a}, 0.0))", "arith"),
    "abs_bw": ("(tl.where({b} > 0, {a}, tl.where({b} < 0, -({a}), 0.0)))",
               "arith"),
    "gelu_bw": ("(({a}) * (0.5 * (1.0 + " + _GELU_T + ") + 0.5 * ({b}) * "
                "(1.0 - " + _GELU_T + " * " + _GELU_T + ") * " + _GELU_C +
                " * (1.0 + 0.134145 * ({b}) * ({b}))))", "f32"),
    "silu_bw": ("(({a}) * (" + _SILU_S + " * (1.0 + ({b}) * (1.0 - "
                + _SILU_S + "))))", "f32"),
    "sigmoid_bw": ("(({a}) * ({b}) * (1.0 - ({b})))", "arith"),
    "tanh_bw": ("(({a}) * (1.0 - ({b}) * ({b})))", "arith"),
    # NOTE: no "eq" here — it resolves through _BINARY_CMP so int pairs
    # compare in the promoted int dtype (f32 lost equality past 2^24)
}

# Fused forward ops (case-fusions): multi-term elementwise expressions that
# reuse the exact same flat/nd generator path as the backward exprs above.
_FUSED_BINARY = {
    # silu(a) * b (SwiGLU): one kernel, 12n traffic vs 20n composed
    "swiglu": ("(({a}) * (1.0 / (1.0 + tl.exp(-({a})))) * ({b}))", "f32"),
}


# ---------------------------------------------------------------------------
# erf-exact gelu (opt-in, MT_GELU_ERF): 0.5*x*(1 + erf(x/sqrt(2))), erf
# via a two-region fit: |u|<=1 -> u*P(u^2); 1<|u|<3.92 ->
# sign(u)*(1-exp(-u^2)*T(|u|)); beyond -> sign(u). ~2 ulp vs torch.erf.
# ---------------------------------------------------------------------------

# region 1: erf(u) = u * P(z), z = u^2 (Horner, descending powers of z)
_ERF_P = (-9.670153128e-06, 1.126354322e-04, -8.483177159e-04,
          5.220921566e-03, -2.686536907e-02, 1.128378087e-01,
          -3.761263829e-01, 1.128379167e+00)
# region 2: erfc(|u|) = exp(-z) * T(|u|) (Horner, descending powers of u)
_ERF_T = (1.803180647e-06, -5.119228320e-05, 6.584589961e-04,
          -5.086642549e-03, 2.639791120e-02, -9.764891464e-02,
          2.670133772e-01, -5.532047367e-01, 8.825114803e-01,
          -1.086030633e+00, 9.930225587e-01)


def _horner(coefs, var: str) -> str:
    s = f"({coefs[0]!r})"
    for c in coefs[1:]:
        s = f"({s} * {var} + ({c!r}))"
    return s


def _erf_expr(u: str) -> str:
    au = f"tl.where({u} < 0, -({u}), {u})"
    z = f"(({u}) * ({u}))"
    p = _horner(_ERF_P, z)
    t = _horner(_ERF_T, au)
    e2 = f"(1.0 - tl.exp(-({z})) * {t})"
    mag = f"tl.where({au} <= 1.0, {au} * {p}, tl.where({au} < 3.92, {e2}, 1.0))"
    return f"tl.where({u} < 0, -({mag}), {mag})"


_GELU_ERF = ("(0.5 * ({x}) * (1.0 + "
             + _erf_expr("(0.7071067811865476 * ({x}))") + "))")
# d/dx gelu = 0.5*(1+erf(u)) + x*exp(-x^2/2)/sqrt(2*pi), u = x/sqrt(2)
_GELU_BW_ERF = ("(({a}) * (0.5 * (1.0 + "
                + _erf_expr("(0.7071067811865476 * ({b}))")
                + ") + 0.3989422804014327 * ({b}) * "
                "tl.exp(-0.5 * ({b}) * ({b}))))")

# gelu default = torch-exact erf (MT_GELU_TANH=1 restores the tanh fast
# path). Patched INTO the tables so every consumer shares one semantics.
if _prec.gelu_erf():
    _UNARY["gelu"] = (_GELU_ERF, "f32")
    _BINARY_BW["gelu_bw"] = (_GELU_BW_ERF, "f32")


def _pow_scalar_expr(p, out_dtype) -> tuple[str, str]:
    """(expr, compute kind) for x ** p with a python-number p."""
    if isinstance(p, numbers.Integral) or (isinstance(p, numbers.Real)
                                        and float(p).is_integer()):
        n = int(p)
        if n == 0:
            return ("(({a}) * 0 + 1)", "arith") if out_dtype.is_int else \
                   ("(({a}) * 0.0 + 1.0)", "arith")
        if n == 1:
            return ("{a}", "arith")
        if n == 2:
            return ("({a} * {a})", "arith")
        if n == 3:
            return ("(({a} * {a}) * {a})", "arith")
        if n == -1:
            return ("(1.0 / {a})", "f32")
        if n == -2:
            return ("(1.0 / ({a} * {a}))", "f32")
    if p == 0.5:
        return ("tl.sqrt({a})", "f32")
    return ("tl.exp(({b}) * tl.log({a}))", "f32")


def _compute_dt(kind: str, out_dtype):
    return tl_types.float32 if kind == "f32" else out_dtype


# ---------------------------------------------------------------------------
# op-level launch plans (steady-state fast path)
# ---------------------------------------------------------------------------
# A plan stacks the per-call resolution of a FLAT elementwise op behind
# one structural key (op, shapes, strides, dtypes, offsets, plus the pow
# scalar's value) and holds the pre-marshalled _FastLaunch; a hit only
# allocates the output and refreshes buffer pointers / scalar values.
# _PLAN_CAP guards pathological growth.

_PLANS: dict = {}
_PLAN_CAP = 32768


def _plan_out(plan):
    from ...runtime.allocator import _ALLOCATOR  # local import: cycle
    _, out_shape, out_dtype, strides, padded, _ = plan
    buf = _ALLOCATOR.alloc(padded, out_dtype)
    return Tensor._make(buf, out_shape, out_dtype, "cuda", strides)


def _plan_put(key, fl, out, numel: int):
    """Capture a resolved flat launch as a plan (first-call path).
    Layout: (numel_logical, out_shape, out_dtype, out_strides,
    padded_numel, fl)."""
    if fl is None or numel == 0:
        return
    if len(_PLANS) >= _PLAN_CAP:
        _PLANS.clear()
    from ...tensor import _contig_strides
    _PLANS[key] = (numel, out.shape, out.dtype, _contig_strides(out.shape),
                   out._storage.nelem, fl)


def _map(a: Tensor, out_dtype, expr: str, kind: str = "arith",
         name: str = "map") -> Tensor:
    """contiguous()/astype()/unary engine: flat if possible, else nd."""
    key = ("m", name, expr, out_dtype, a.shape, a._st, a.dtype, a._offset)
    plan = _PLANS.get(key)
    if plan is not None:
        out = _plan_out(plan)
        plan[5]((a._buffer_arg(), out._buffer_arg(), plan[0]))
        return out
    nkey = ("mnd", name, expr, out_dtype, a.shape, a._st, a.dtype,
            a._offset)
    ent = _PLANS.get(nkey)
    if ent is not None:
        fl, args, meta = ent
        out = _plan_out(meta)
        args[0] = a._buffer_arg()
        args[1] = out._buffer_arg()
        fl(args)
        return out
    compute = _compute_dt(kind, out_dtype)
    out = empty(a.shape, out_dtype, "cuda")
    if a.numel() == 0:
        return out
    if a.is_contiguous() and _base16_ok(a):
        k = flat_unary(f"fu_{name}", expr, a.dtype, out_dtype, compute)
        fl = launch_flat(k, [a._buffer_arg(), out._buffer_arg()],
                            a.numel())
        _plan_put(key, fl, out, a.numel())
        return out
    shape = a.shape if a.ndim > 0 else (1,)
    t = a if a.ndim > 0 else a.reshape((1,))
    k = nd_unary(f"ndu_{name}", expr, len(shape), t.dtype, out_dtype,
                    compute, operand_spec(t, shape)[2],
                    pipelined=short_rows(shape))
    fl, args = launch_nd(k, len(shape), shape,
                            [operand_spec(t, shape)], out._buffer_arg())
    if fl is not None:
        if len(_PLANS) >= _PLAN_CAP:
            _PLANS.clear()
        from ...tensor import _contig_strides
        _PLANS[nkey] = (fl, args, (out.numel(), out.shape, out.dtype,
                                   _contig_strides(out.shape),
                                   out._storage.nelem, None))
    return out


def contiguous(a: Tensor) -> Tensor:
    return _map(a, a.dtype, "{x}", name="copy")


def astype(a: Tensor, dtype) -> Tensor:
    return _map(a, dtype, "{x}", name=f"cast_{a.dtype.name}_{dtype.name}")


def unary(op: str, a: Tensor, out_dtype) -> Tensor:
    expr, kind = _UNARY[op]  # gelu already flag-patched at table build
    zero = "0" if out_dtype.is_int else "0.0"
    return _map(a, out_dtype, expr.replace("{zero}", zero), kind=kind,
                name=f"{op}_{a.dtype.name}")


# ---------------------------------------------------------------------------
# binary
# ---------------------------------------------------------------------------

def _binary_nd(a: Tensor, b: Tensor, out_dtype, expr: str, compute,
               out_shape, name: str) -> Tensor:
    out = empty(out_shape, out_dtype, "cuda")
    if out.numel() == 0:
        return out
    shape = out_shape if out_shape else (1,)
    av = a.broadcast_to(shape) if a.shape != shape else a
    bv = b.broadcast_to(shape) if b.shape != shape else b
    sa = operand_spec(av, shape)
    sb = operand_spec(bv, shape)
    k = nd_binary(f"ndb_{name}", expr, len(shape), a.dtype, b.dtype,
                     out_dtype, compute, sa[2], sb[2])
    launch_nd(k, len(shape), shape, [sa, sb], out._buffer_arg())
    return out


def binary(op: str, a: Tensor, b: Tensor, out_dtype) -> Tensor:
    import numpy as np
    pkey = ("b", op, out_dtype, a.shape, a._st, a.dtype, a._offset,
            b.shape, b._st, b.dtype, b._offset)
    plan = _PLANS.get(pkey)
    if plan is not None:
        out = _plan_out(plan)
        plan[5]((a._buffer_arg(), b._buffer_arg(), out._buffer_arg(),
                 plan[0]))
        return out
    bw = _BINARY_BW.get(op)
    cmp_ = _BINARY_CMP.get(op)
    if bw is not None:
        expr, kind = bw  # gelu_bw already flag-patched at table build
        compute = _compute_dt(kind, out_dtype)
    elif cmp_ is not None:
        expr = f"(tl.cast({cmp_}, tl.float32))"
        compute = promote_dtype(a.dtype, b.dtype)
    else:
        expr = _BINARY[op]
        compute = tl_types.float32 if op == "pow" else out_dtype
    out_shape = tuple(np.broadcast_shapes(a.shape, b.shape))
    name = f"{op}_{a.dtype.name}_{b.dtype.name}"
    if a.shape == b.shape and a.is_contiguous() and b.is_contiguous() \
            and _base16_ok(a) and _base16_ok(b):
        out = empty(a.shape, out_dtype, "cuda")
        if a.numel() == 0:
            return out
        # mixed input dtypes cast to `compute` at load (generator), same
        # numerics as the nd path's per-operand load-cast
        k = flat_binary(f"fb_{name}", expr, a.dtype, b.dtype, out_dtype,
                           compute)
        fl = launch_flat(k, [a._buffer_arg(), b._buffer_arg(),
                                out._buffer_arg()], a.numel())
        _plan_put(pkey, fl, out, a.numel())
        return out
    if b.numel() == 1 and b.shape != ():
        b = b.reshape(())
    if a.numel() == 1 and a.shape != ():
        a = a.reshape(())
    if b.shape == ():
        return binary_scalar(op, a, b.item(), "r", out_dtype)
    if a.shape == ():
        return binary_scalar(op, b, a.item(), "l", out_dtype)
    return _binary_nd(a, b, out_dtype, expr, compute, out_shape, name)


def binary_scalar(op: str, a: Tensor, s, side: str, out_dtype) -> Tensor:
    if op == "pow" and side == "r":
        expr, kind = _pow_scalar_expr(s, out_dtype)
        compute = _compute_dt(kind, out_dtype)
    elif op == "pow":
        expr, kind = _BINARY["pow"], "f32"
        compute = _compute_dt(kind, out_dtype)
    elif op in _BINARY_CMP:
        expr = f"(tl.cast({_BINARY_CMP[op]}, tl.float32))"
        # int tensor with an int scalar compares exactly (i64 when the
        # scalar overflows i32); anything float compares in f32
        if a.dtype.is_int and isinstance(s, numbers.Integral):
            compute = a.dtype if -2**31 <= s < 2**31 else tl_types.int64
        else:
            compute = tl_types.float32
    else:
        expr, kind = _BINARY[op], "arith"
        compute = _compute_dt(kind, out_dtype)
    # f16/bf16 with a float scalar: compute in f32 for accuracy
    if isinstance(s, float) and out_dtype != tl_types.float32 \
            and out_dtype.is_float:
        compute = tl_types.float32
    s_kind = "f" if out_dtype.is_float or isinstance(s, float) else "i"
    if op in _BINARY_CMP and a.dtype.is_int and isinstance(
            s, numbers.Integral):
        s_kind = "i"  # exact int compare: no float round-trip of s
    conv = float if s_kind == "f" else int
    s_val = conv(s)
    # the flat kernel ABI takes i32 scalars only: a big int scalar must
    # NEVER take a cached flat plan (its value is not in the key)
    big_int = s_kind == "i" and not (-2**31 <= s_val < 2**31)
    # the expr may special-case by scalar VALUE (pow): plans key on it
    # there; every other op's expr is value-independent
    sval_key = float(s) if op == "pow" else None
    pkey = ("s", op, side, s_kind, sval_key, out_dtype, a.shape, a._st,
            a.dtype, a._offset)
    if not big_int:
        plan = _PLANS.get(pkey)
        if plan is not None:
            out = _plan_out(plan)
            plan[5]((a._buffer_arg(), out._buffer_arg(), s_val, plan[0]))
            return out
    out = empty(a.shape, out_dtype, "cuda")
    if a.numel() == 0:
        return out
    name = f"{op}_{a.dtype.name}_{side}"
    if big_int:
        # materialize the scalar as an i64 0-d tensor and take the
        # universal nd path (promotion rules then handle i32 tensor +
        # i64 scalar like torch).
        import numpy as np
        from ...tensor import tensor as mk_tensor
        st = mk_tensor(s_val, dtype=tl_types.int64, device="cuda")
        lhs, rhs = (a, st) if side == "r" else (st, a)
        out_shape = tuple(np.broadcast_shapes(lhs.shape, rhs.shape))
        return _binary_nd(lhs, rhs, out_dtype, expr, compute, out_shape,
                          name)
    if a.is_contiguous() and _base16_ok(a):
        k = scalar_binary(f"sb_{name}", expr, a.dtype, out_dtype, compute,
                             s_kind, side)
        fl = launch_flat(k, [a._buffer_arg(), out._buffer_arg()],
                            a.numel(), extra=[s_val])
        _plan_put(pkey, fl, out, a.numel())
        return out
    # non-contiguous: materialize the scalar as a 0-d tensor and take the
    # nd path directly (binary() would recurse). Int compute materializes
    # in an int dtype — an f32 round-trip rounds thresholds past 2^24.
    import numpy as np
    from ...tensor import tensor as mk_tensor
    st = mk_tensor(s_val, dtype=compute if getattr(compute, "is_int",
                                                   False) else out_dtype,
                   device="cuda")
    lhs, rhs = (a, st) if side == "r" else (st, a)
    out_shape = tuple(np.broadcast_shapes(lhs.shape, rhs.shape))
    return _binary_nd(lhs, rhs, out_dtype, expr, compute, out_shape, name)


# ---------------------------------------------------------------------------
# fused elementwise forward ops (case-fusions)
# ---------------------------------------------------------------------------

def swiglu(a: Tensor, b: Tensor, out_dtype) -> Tensor:
    """silu(a) * b in one kernel: flat when both operands are contiguous
    same-shape, else the universal nd (broadcast/strided) form."""
    import numpy as np
    pkey = ("w", "swiglu", out_dtype, a.shape, a._st, a.dtype, a._offset,
            b.shape, b._st, b.dtype, b._offset)
    plan = _PLANS.get(pkey)
    if plan is not None:
        out = _plan_out(plan)
        plan[5]((a._buffer_arg(), b._buffer_arg(), out._buffer_arg(),
                 plan[0]))
        return out
    expr, kind = _FUSED_BINARY["swiglu"]
    compute = _compute_dt(kind, out_dtype)
    out_shape = tuple(np.broadcast_shapes(a.shape, b.shape))
    name = f"swiglu_{a.dtype.name}_{b.dtype.name}"
    if a.shape == b.shape and a.is_contiguous() and b.is_contiguous() \
            and a.dtype == b.dtype and _base16_ok(a) and _base16_ok(b):
        out = empty(a.shape, out_dtype, "cuda")
        if a.numel() == 0:
            return out
        k = flat_binary(f"fb_{name}", expr, a.dtype, b.dtype, out_dtype,
                           compute)
        fl = launch_flat(k, [a._buffer_arg(), b._buffer_arg(),
                                out._buffer_arg()], a.numel())
        _plan_put(pkey, fl, out, a.numel())
        return out
    return _binary_nd(a, b, out_dtype, expr, compute, out_shape, name)


# ---------------------------------------------------------------------------
# cat
# ---------------------------------------------------------------------------

def cat(tensors: list[Tensor], dim: int, out_dtype) -> Tensor:
    import numpy as np
    out_shape = list(tensors[0].shape)
    out_shape[dim] = sum(t.shape[dim] for t in tensors)
    out_shape = tuple(out_shape)
    ckey = ("cat", dim, out_dtype,
            tuple((t.shape, t._st, t.dtype, t._offset) for t in tensors))
    ent = _PLANS.get(ckey)
    if ent is not None:
        meta, pieces = ent
        out = _plan_out(meta)
        # pieces were recorded only for non-empty tensors; zip against the
        # same filtered list or every piece after a 0-size tensor binds to
        # the wrong buffer
        live = (t for t in tensors if t.numel())
        for (fl, args), t in zip(pieces, live):
            args[0] = t._buffer_arg()
            args[1] = out._buffer_arg()
            fl(args)
        return out
    out = empty(out_shape, out_dtype, "cuda")
    if out.numel() == 0:
        return out
    ost = _contig_strides(out_shape)
    offset = 0
    pieces = []
    for t in tensors:
        if t.numel() == 0:
            continue
        shape = t.shape if t.ndim > 0 else (1,)
        tv = t if t.ndim > 0 else t.reshape((1,))
        spec = operand_spec(tv, shape)
        k = nd_unary("ndu_cat", "{x}", len(shape), tv.dtype, out_dtype,
                        out_dtype, spec[2], pipelined=short_rows(shape))
        fl, args = launch_nd(k, len(shape), shape, [spec],
                                out._buffer_arg(),
                                out_strides=ost[:-1],
                                out_base=offset * ost[dim])
        if fl is not None:
            pieces.append((fl, args))
        offset += t.shape[dim]
    if pieces and len(pieces) == len([t for t in tensors if t.numel()]):
        if len(_PLANS) >= _PLAN_CAP:
            _PLANS.clear()
        _PLANS[ckey] = ((out.numel(), out.shape, out.dtype,
                         _contig_strides(out.shape), out._storage.nelem,
                         None), pieces)
    return out
