"""minitriton/sched — the explicit-scheduling helper library.

This module is the **scheduling-choreography corpus written in the DSL**
-- not the compiler (zero MLIR/emitted code, zero layout/lane knowledge;
everything unfolds through the `tl.*` vocabulary at trace time), not the
backends (no driver/launch), not ops/nn (no eager API, no autograd).
`sched/` is the in-package home of this corpus: generic choreography
skeletons (pipeline shapes, tile-loop structures) that the application
kernels in kernels/examples compose via `@tl.inline`. The boundary with
application kernels: everything here is application-agnostic choreography
(no flash/kda/attention semantics, no epilogue business logic); the names
describe **scheduling shapes**, not fusion business.

Everything here is a plain Python function decorated with `@tl.inline`;
call sites inside `@tl.kernel` bodies are inlined at trace time.
"""

from .pipeline import gemm_2stage_bf16
from . import rowfam

__all__ = ["gemm_2stage_bf16", "rowfam"]
