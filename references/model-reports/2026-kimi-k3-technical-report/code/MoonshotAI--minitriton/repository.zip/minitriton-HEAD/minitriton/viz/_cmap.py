"""Colormap tables for viz render kernels.

Single source of truth: 8 stops sampled at t = 0..1 (step 1/7) from the
matplotlib colormaps of the same names. The GPU kernels receive
the stops as runtime f32 arguments and do piecewise-linear interpolation;
the numpy oracle in tests uses ``lookup`` below, so kernel and reference
can never drift apart.
"""

from __future__ import annotations

import numpy as np

CMAPS: dict[str, tuple[tuple[float, float, float], ...]] = {
    # matplotlib viridis @ t = 0, 1/7, ..., 1
    "viridis": (
        (0.2670, 0.0049, 0.3294), (0.2752, 0.1949, 0.4960),
        (0.2124, 0.3597, 0.5517), (0.1534, 0.4970, 0.5577),
        (0.1223, 0.6332, 0.5304), (0.2889, 0.7584, 0.4284),
        (0.6266, 0.8546, 0.2234), (0.9932, 0.9062, 0.1439),
    ),
    # matplotlib magma @ t = 0, 1/7, ..., 1
    "magma": (
        (0.0015, 0.0005, 0.0139), (0.1351, 0.0684, 0.3150),
        (0.3721, 0.0928, 0.4991), (0.5945, 0.1757, 0.5012),
        (0.8289, 0.2622, 0.4306), (0.9734, 0.4615, 0.3620),
        (0.9973, 0.7335, 0.5052), (0.9871, 0.9914, 0.7495),
    ),
    "gray": tuple((t, t, t) for t in np.linspace(0.0, 1.0, 8)),
    # water: deep navy body -> surface cyan -> white foam (SPH demo palette)
    "water": (
        (0.008, 0.024, 0.078), (0.016, 0.071, 0.196),
        (0.024, 0.157, 0.353), (0.043, 0.302, 0.553),
        (0.118, 0.475, 0.718), (0.318, 0.639, 0.847),
        (0.596, 0.812, 0.929), (0.918, 0.973, 1.000),
    ),
}

NS_STOPS = 8


def lookup(name: str, t):
    """Numpy oracle: piecewise-linear colormap lookup at t in [0, 1]."""
    stops = np.asarray(CMAPS[name], dtype=np.float64)
    tc = np.clip(np.asarray(t, dtype=np.float64), 0.0, 1.0) * (NS_STOPS - 1)
    k = np.clip(tc.astype(np.int64), 0, NS_STOPS - 2)
    f = tc - k
    rgb = stops[k] * (1.0 - f[..., None]) + stops[k + 1] * f[..., None]
    return rgb.astype(np.float32)


def stops_flat(name: str) -> list[float]:
    """The 8x3 stops flattened r0..r7,g0..g7,b0..b7 for kernel args."""
    if name not in CMAPS:
        raise ValueError(f"unknown colormap {name!r} (have {sorted(CMAPS)})")
    arr = np.asarray(CMAPS[name], dtype=np.float32)
    return [float(v) for v in arr.T.reshape(-1)]
