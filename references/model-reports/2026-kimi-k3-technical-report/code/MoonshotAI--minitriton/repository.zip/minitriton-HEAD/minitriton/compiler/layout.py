"""Unified tile-layout algebra — pure Python, zero MLIR.

Compile-time metadata only: a Layout describes how a tile's elements are
distributed over a thread block's registers. It is *not* an MLIR type and
never touches the emission layer; the builder consumes it to pick
emission strategies. Frozen dataclasses: hashable, usable in cache keys,
round-trippable through a compact text form.

Coverage of the five hand-rolled layout systems, as
parameter-instance constructors (dist_layout/flat_layout/rep_layout/
t2_layout/t3_layout + Fragment; default_layout is the load-time default
rule):

| # | system   | constructor                                            |
|---|----------|--------------------------------------------------------|
| 1 | SepOff   | (address form, not a data layout — see accepts_addr)   |
| 2 | t2       | Blocked(spt=(tm, 4), thr=(nt_m, nt_n))                 |
| 3 | t3       | Blocked(spt=(tm, C), thr=(nt, 1)) — C=64 in current use |
| 4 | MatOff   | (address form, not a data layout — see accepts_addr)   |
| 5 | m4 A/B/C | Fragment(role="A"/"B"/"C")                             |
|   | dist     | Blocked (1D: spt=(ept,), thr=(nt,); 2D: (1,ept)/(1,nt))|
|   | flat     | Blocked(spt=(1, ept), thr=(R, C//ept))                 |
|   | rep      | Replicated                                             |
|   | reduce (R,1) | Sliced(Blocked, dim=1)                             |

Semantics notes:

- Thread ids decompose over the thread grid row-major (last dim fastest):
  ``tx = tid % nt_n, ty = tid // nt_n`` for t2 — the same convention every
  hand-rolled system uses.
- ``regs_per_thread()`` is the *total* per-thread register/element count,
  uniform across constructors (t2: tm*tn; m4 C: 4*atoms_m*atoms_n; rep:
  prod(shape); dist 1D: shape[-1]/num_threads; dist 2D: R*(C/num_threads)
  — note builder's ``Tensor.ept`` for a 2D dist value is the per-row VEC,
  this is the whole-tile accounting).
- Fragment carries an optional ``ldsm`` field (ldmatrix variant
  "x4"/"x2"/"x2t"/"x4t", mirroring builder._mma_ldsm_*) so the m4 semantics
  are fully expressible as data; emission (swizzle, addresses) stays in the
  builder. The text form omits it when it is the default "x4".
"""

from __future__ import annotations

import ast
import re

from dataclasses import dataclass

__all__ = [
    "Layout",
    "LayoutError",
    "Blocked",
    "Replicated",
    "Sliced",
    "Fragment",
    "parse",
    "convert_t1",
    "convert_plan",
    "default_layout",
    "dist_layout",
    "flat_layout",
    "mma_layout",
    "rep_layout",
    "t2_layout",
    "t3_layout",
    "is_dist",
    "is_flat",
    "is_rep_like",
    "is_t2",
    "is_t3",
    "store_compatible",
    "vec_ept",
]


class LayoutError(ValueError):
    """Malformed layout definition, text form, or ownership query."""


# mma.sync atom geometry, mirroring builder.mma_atom as pure
# data: kind -> (m, n, k, ep) with ep = elements per operand register.
_ATOM_GEOM = {
    "tf32": (16, 8, 8, 1),
    "tf32x3": (16, 8, 8, 1),
    "bf16": (16, 8, 16, 2),
}

# ldmatrix variants (builder._mma_ldsm_x4/_x2/_x2_trans/_x4_trans).
_LDSM_MODES = ("x4", "x2", "x2t", "x4t")

_ROLES = ("A", "B", "C")

_LAYOUT_CTORS = ("blocked", "fragment", "rep", "slice")

_KWARG_RE = re.compile(r"^([a-z_]+)=(.*)$", re.S)


def _prod(t) -> int:
    p = 1
    for v in t:
        p *= v
    return p


def _ceil_div(a: int, b: int) -> int:
    return -(-a // b)


def _as_int_tuple(v, name: str) -> tuple[int, ...]:
    try:
        t = tuple(int(x) for x in v)
    except TypeError:
        raise LayoutError(f"{name} must be an iterable of ints, got {v!r}")
    if not t:
        raise LayoutError(f"{name} must be non-empty")
    if any(x <= 0 for x in t):
        raise LayoutError(f"{name} entries must be positive, got {t}")
    return t


def _fmt_tuple(t) -> str:
    """Compact tuple text: (64,64) / (4,)."""
    if len(t) == 1:
        return f"({t[0]},)"
    return "(" + ",".join(str(v) for v in t) + ")"


class Layout:
    """Abstract base: ownership query + register accounting + text form."""

    shape: tuple[int, ...]

    def owns(self, coord, tid: int, num_threads: int) -> bool:
        """Does thread `tid` (of `num_threads`) hold element `coord`?"""
        raise NotImplementedError

    def regs_per_thread(self) -> int:
        """Total per-thread register/element count under this layout."""
        raise NotImplementedError

    def dump(self) -> str:
        """Compact text form; Layout.parse(dump()) == self."""
        raise NotImplementedError

    def accepts_addr(self, off) -> bool:
        """Address-form compatibility query: SepOff/MatOff stay
        outside the algebra; this makes the shape check load/store already
        do implicitly explicit. Duck-typed: anything with a ``.shape``."""
        return tuple(getattr(off, "shape", ())) == tuple(self.shape)

    @staticmethod
    def parse(s: str) -> "Layout":
        return parse(s)

    # -- shared query validation --------------------------------------------

    def _check_coord(self, coord) -> tuple[int, ...]:
        try:
            c = tuple(int(x) for x in coord)
        except TypeError:
            raise LayoutError(f"coord must be an iterable of ints, got {coord!r}")
        if len(c) != len(self.shape):
            raise LayoutError(
                f"coord {c} rank != layout rank {len(self.shape)} ({self.dump()})")
        for x, s in zip(c, self.shape):
            if not 0 <= x < s:
                raise LayoutError(f"coord {c} out of bounds for shape {self.shape}")
        return c

    @staticmethod
    def _check_tid(tid: int, num_threads: int) -> tuple[int, int]:
        tid, nt = int(tid), int(num_threads)
        if nt <= 0:
            raise LayoutError(f"num_threads must be positive, got {nt}")
        if not 0 <= tid < nt:
            raise LayoutError(f"tid {tid} out of range for num_threads {nt}")
        return tid, nt

    def __repr__(self):
        return self.dump()


@dataclass(frozen=True)
class Blocked(Layout):
    """Per-thread contiguous/cyclic blocking (triton Blocked subset).

    The layout covers a base extent (size_per_thread * threads, elementwise)
    which repeats cyclically over the tensor shape. dist/flat/t2/t3 are all
    parameter instances of this (see module docstring).
    """

    shape: tuple[int, ...]
    size_per_thread: tuple[int, ...]
    threads: tuple[int, ...]
    order: tuple[int, ...]

    def __post_init__(self):
        shape = _as_int_tuple(self.shape, "shape")
        spt = _as_int_tuple(self.size_per_thread, "size_per_thread")
        thr = _as_int_tuple(self.threads, "threads")
        order = tuple(int(d) for d in self.order)
        nd = len(shape)
        if not (len(spt) == len(thr) == len(order) == nd):
            raise LayoutError(
                f"rank mismatch: shape {shape}, spt {spt}, thr {thr}, ord {order}")
        if sorted(order) != list(range(nd)):
            raise LayoutError(f"order must be a permutation of range({nd}), "
                              f"got {order}")
        object.__setattr__(self, "shape", shape)
        object.__setattr__(self, "size_per_thread", spt)
        object.__setattr__(self, "threads", thr)
        object.__setattr__(self, "order", order)

    def owns(self, coord, tid: int, num_threads: int) -> bool:
        coord = self._check_coord(coord)
        tid, nt = self._check_tid(tid, num_threads)
        if _prod(self.threads) != nt:
            raise LayoutError(
                f"thread grid {self.threads} (product {_prod(self.threads)}) "
                f"!= num_threads {nt}")
        want, stride = 0, 1
        # order[d] fastest-first: the thread id strides along dims in
        # the order they are listed (every current constructor passes
        # the identity-fastest-last order, e.g. (1, 0) for 2D)
        for d in self.order:
            ext = self.size_per_thread[d] * self.threads[d]
            tcoord = (coord[d] % ext) // self.size_per_thread[d]
            want += tcoord * stride
            stride *= self.threads[d]
        return tid == want

    def regs_per_thread(self) -> int:
        regs = 1
        for spt, thr, s in zip(self.size_per_thread, self.threads, self.shape):
            regs *= spt * _ceil_div(s, spt * thr)
        return regs

    def dump(self) -> str:
        return (f"blocked({_fmt_tuple(self.shape)}, "
                f"spt={_fmt_tuple(self.size_per_thread)}, "
                f"thr={_fmt_tuple(self.threads)}, "
                f"ord={_fmt_tuple(self.order)})")


@dataclass(frozen=True)
class Replicated(Layout):
    """Every thread holds the full tensor (small shapes only, as today)."""

    shape: tuple[int, ...]

    def __post_init__(self):
        object.__setattr__(self, "shape", _as_int_tuple(self.shape, "shape"))

    def owns(self, coord, tid: int, num_threads: int) -> bool:
        self._check_coord(coord)
        self._check_tid(tid, num_threads)
        return True

    def regs_per_thread(self) -> int:
        return _prod(self.shape)

    def dump(self) -> str:
        return f"rep({_fmt_tuple(self.shape)})"


@dataclass(frozen=True)
class Sliced(Layout):
    """Drop one dim of the parent (reduce results, (R,1)/(1,C) broadcast
    sources). A thread owns a sliced coordinate iff it owned at least
    one parent coordinate along the sliced dim — the result replicates
    across the sliced dim's threads (triton SliceLayout semantics; matches
    the current rep treatment of reduce results)."""

    parent: Layout
    dim: int

    def __post_init__(self):
        if not isinstance(self.parent, Layout):
            raise LayoutError(f"parent must be a Layout, got {self.parent!r}")
        nd = len(self.parent.shape)
        dim = int(self.dim)
        if not -nd <= dim < nd:
            raise LayoutError(f"dim {dim} out of range for parent rank {nd}")
        object.__setattr__(self, "dim", dim % nd)

    @property
    def shape(self) -> tuple[int, ...]:
        p = self.parent.shape
        return p[: self.dim] + p[self.dim + 1:]

    def owns(self, coord, tid: int, num_threads: int) -> bool:
        coord = self._check_coord(coord)
        self._check_tid(tid, num_threads)
        d = self.dim
        for v in range(self.parent.shape[d]):
            if self.parent.owns(coord[:d] + (v,) + coord[d:], tid, num_threads):
                return True
        return False

    def regs_per_thread(self) -> int:
        p = self.parent
        if isinstance(p, Blocked):
            regs = 1
            for d in range(len(p.shape)):
                if d == self.dim:
                    continue
                regs *= (p.size_per_thread[d]
                         * _ceil_div(p.shape[d],
                                     p.size_per_thread[d] * p.threads[d]))
            return regs
        if isinstance(p, Replicated):
            return _prod(self.shape)
        if isinstance(p, Fragment):
            # the narrow row/column statistic of an mma tile (the lse /
            # delta / bias form): per lane only the values its fragment
            # rows (dim=1: one per (atom_m, half)) or columns (dim=0:
            # one per (atom_n, pair)) need — the rest of the broadcast
            # is layout metadata, zero registers.
            am, an = p.atoms
            return am * 2 if self.dim == 1 else an * 2
        raise LayoutError(
            f"regs_per_thread undefined for Sliced({type(p).__name__})")

    def dump(self) -> str:
        return f"slice({self.parent.dump()}, dim={self.dim})"


@dataclass(frozen=True)
class Fragment(Layout):
    """mma fragment (m4 system): atom geometry + role + warp grid +
    atom repeat counts.

    ``atoms[d]`` is the repeat count of the atom along shape dim d within
    one warp tile, in units of that dim's atom extent: role A (m, k),
    role B (k, n), role C (m, n). Geometry invariant (checked at
    construction): ``shape[d] == eff_warps[d] * atoms[d] * ext[d]`` where
    the effective warp grid drops the replicated dim — A replicates across
    the warp grid's n dim (all wx warps read the same A slab, so the K dim
    is not split by warps[1]), B across the m dim, C splits both.

    Ownership formulas (per-lane, g = lane//4, t = lane%4, warp grid
    row-major like Blocked) follow the builder docstrings: C = store_m4,
    A = _mma_frag_a, B = _mma_frag_b. A fragments
    replicate across the warp grid's n dim, B across the m dim.
    ``ldsm`` records the ldmatrix variant (x4/x2/x2t/x4t); it is metadata
    for the emission layer and defaults to "x4".
    """

    shape: tuple[int, int]
    atom: str
    role: str
    warps: tuple[int, int]
    atoms: tuple[int, int]
    ldsm: str = "x4"

    def __post_init__(self):
        shape = _as_int_tuple(self.shape, "shape")
        if len(shape) != 2:
            raise LayoutError(f"fragment shape must be 2D, got {shape}")
        if self.atom not in _ATOM_GEOM:
            raise LayoutError(
                f"unknown mma atom {self.atom!r} (have {sorted(_ATOM_GEOM)})")
        if self.role not in _ROLES:
            raise LayoutError(f"role must be one of {_ROLES}, got {self.role!r}")
        warps = _as_int_tuple(self.warps, "warps")
        atoms = _as_int_tuple(self.atoms, "atoms")
        if len(warps) != 2 or len(atoms) != 2:
            raise LayoutError(f"warps/atoms must be 2-tuples, got "
                              f"{warps}/{atoms}")
        if self.ldsm not in _LDSM_MODES:
            raise LayoutError(
                f"ldsm must be one of {_LDSM_MODES}, got {self.ldsm!r}")
        ext = self._extents(shape, self.atom, self.role)
        # the replicated dim is not split by the warp grid: A's K dim is
        # read by every wx warp, B's K dim by every wy warp.
        eff = {"A": (warps[0], 1), "B": (1, warps[1]), "C": warps}[self.role]
        for d in (0, 1):
            want = eff[d] * atoms[d] * ext[d]
            if shape[d] != want:
                raise LayoutError(
                    f"fragment geometry mismatch on dim {d} (role "
                    f"{self.role}): shape {shape[d]} != eff_warps {eff[d]} "
                    f"* atoms {atoms[d]} * ext {ext[d]}")
        object.__setattr__(self, "shape", shape)
        object.__setattr__(self, "warps", warps)
        object.__setattr__(self, "atoms", atoms)

    @staticmethod
    def _extents(shape, atom, role) -> tuple[int, int, int]:
        """(ext_d0, ext_d1, ep): atom tile extents per dim + elems/reg."""
        m, n, k, ep = _ATOM_GEOM[atom]
        return {"A": (m, k, ep), "B": (k, n, ep), "C": (m, n, ep)}[role]

    def owns(self, coord, tid: int, num_threads: int) -> bool:
        coord = self._check_coord(coord)
        tid, nt = self._check_tid(tid, num_threads)
        n_warps = self.warps[0] * self.warps[1]
        if nt != n_warps * 32:
            raise LayoutError(
                f"warp grid {self.warps} needs {n_warps * 32} threads, "
                f"got num_threads {nt}")
        lane, warp = tid % 32, tid // 32
        wy, wx = warp // self.warps[1], warp % self.warps[1]
        g, t = lane // 4, lane % 4
        e0, e1, ep = self._extents(self.shape, self.atom, self.role)
        wa0 = self.shape[0] // self.warps[0]
        wa1 = self.shape[1] // self.warps[1]
        if self.role == "A":
            # rows: warp slab wy (replicated across wx); element
            # (g + 8*(j%2), t*ep + (j//2)*(k/2) + e) of atom (im, h).
            lr = coord[0] - wy * wa0
            if not 0 <= lr < wa0:
                return False
            gg = (lr % e0) % 8
            rem = coord[1] % e1
            tt = (rem % (e1 // 2)) // ep
            return gg == g and tt == t
        if self.role == "B":
            # cols: warp slab wx (replicated across wy); element
            # (t*ep + j*(k/2) + e, g) of atom (h, in_).
            ln = coord[1] - wx * wa1
            if not 0 <= ln < wa1:
                return False
            gg = ln % e1
            rem = coord[0] % e0
            tt = (rem % (e0 // 2)) // ep
            return gg == g and tt == t
        # role C (store_m4): element (g + 8*(j//2), t*2 + j%2) of atom
        # (im, in_) inside the warp tile.
        lr = coord[0] - wy * wa0
        ln = coord[1] - wx * wa1
        if not (0 <= lr < wa0 and 0 <= ln < wa1):
            return False
        gg = (lr % e0) % 8
        tt = (ln % e1) // 2
        return gg == g and tt == t

    def regs_per_thread(self) -> int:
        # C: 4 f32 accumulators per atom (builder's nc); A: 4 i32 operand
        # regs per atom; B: 2 i32 regs per atom (_mma_sync operand lists).
        per_atom = 2 if self.role == "B" else 4
        return per_atom * self.atoms[0] * self.atoms[1]

    def dump(self) -> str:
        s = (f"fragment({_fmt_tuple(self.shape)}, atom={self.atom}, "
             f"role={self.role}, warps={_fmt_tuple(self.warps)}, "
             f"atoms={_fmt_tuple(self.atoms)}")
        if self.ldsm != "x4":
            s += f", ldsm={self.ldsm}"
        return s + ")"


# ---------------------------------------------------------------------------
# Text form: parse is the exact inverse of dump.
# ---------------------------------------------------------------------------

def _split_top(s: str) -> list[str]:
    """Split on commas at paren depth 0 (nested layouts stay whole)."""
    parts, depth, cur = [], 0, []
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur))
    return [p.strip() for p in parts if p.strip()]


def _body(s: str, name: str) -> str:
    inner = s[len(name) + 1: -1]
    depth = 0
    for ch in inner:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if depth < 0:
            break
    if not s.endswith(")") or depth != 0:
        raise LayoutError(f"unbalanced parens in layout string: {s!r}")
    return inner


def _kwargs(parts: list[str]) -> tuple[list[str], dict[str, str]]:
    pos, kw = [], {}
    for p in parts:
        m = _KWARG_RE.match(p)
        if m is None:
            pos.append(p)
        else:
            kw[m.group(1)] = m.group(2).strip()
    return pos, kw


def _tuple(v: str, name: str) -> tuple[int, ...]:
    try:
        t = ast.literal_eval(v)
    except (SyntaxError, ValueError):
        raise LayoutError(f"cannot parse {name} tuple from {v!r}")
    if not isinstance(t, tuple) or not all(isinstance(x, int) for x in t):
        raise LayoutError(f"{name} must be a tuple of ints, got {v!r}")
    return t


def parse(s: str) -> Layout:
    """Inverse of Layout.dump's text form."""
    if not isinstance(s, str):
        raise LayoutError(f"parse expects a str, got {s!r}")
    s = s.strip()
    if s.startswith("blocked("):
        pos, kw = _kwargs(_split_top(_body(s, "blocked")))
        if len(pos) != 1 or set(kw) != {"spt", "thr", "ord"}:
            raise LayoutError(f"malformed blocked layout: {s!r}")
        return Blocked(_tuple(pos[0], "shape"),
                       _tuple(kw["spt"], "spt"),
                       _tuple(kw["thr"], "thr"),
                       _tuple(kw["ord"], "ord"))
    if s.startswith("fragment("):
        pos, kw = _kwargs(_split_top(_body(s, "fragment")))
        if len(pos) != 1 or not {"atom", "role", "warps", "atoms"} <= set(kw):
            raise LayoutError(f"malformed fragment layout: {s!r}")
        extra = set(kw) - {"atom", "role", "warps", "atoms", "ldsm"}
        if extra:
            raise LayoutError(f"unknown fragment keys {sorted(extra)} in {s!r}")
        return Fragment(_tuple(pos[0], "shape"),
                        kw["atom"], kw["role"],
                        _tuple(kw["warps"], "warps"),
                        _tuple(kw["atoms"], "atoms"),
                        kw.get("ldsm", "x4"))
    if s.startswith("rep("):
        pos, kw = _kwargs(_split_top(_body(s, "rep")))
        if len(pos) != 1 or kw:
            raise LayoutError(f"malformed rep layout: {s!r}")
        return Replicated(_tuple(pos[0], "shape"))
    if s.startswith("slice("):
        pos, kw = _kwargs(_split_top(_body(s, "slice")))
        if len(pos) != 1 or set(kw) != {"dim"}:
            raise LayoutError(f"malformed slice layout: {s!r}")
        try:
            dim = int(kw["dim"])
        except ValueError:
            raise LayoutError(f"slice dim must be an int, got {kw['dim']!r}")
        return Sliced(parse(pos[0]), dim)
    raise LayoutError(f"cannot parse layout (expected one of "
                      f"{_LAYOUT_CTORS}): {s!r}")


# ---------------------------------------------------------------------------
# convert_layout tier-1 rule table: matching is pure layout metadata
# (this module); emission lives in the builder (Builder.convert_layout).
# ---------------------------------------------------------------------------

def convert_t1(src: Layout, dst: Layout) -> str | None:
    """Tier-1 register-conversion rule match: the name of the rule
    whose constraints (src, dst) satisfies, else None.

    "frag_c_to_a" (rules #1/#2): an mma C fragment becomes the A operand
    fragment of the same tile and atom (the C n dim is the A k dim) —
    register-only: bf16 packs adjacent accumulator pairs (cvt.rn.bf16x2,
    zero shuffles), tf32 does a quad shfl.idx + select + cvt.rna per
    register. Requires the single-warp-column grid (warps[1] == 1): every
    warp's C row slab then spans the whole K extent, so the conversion
    stays warp-local. Geometry beyond that is pinned by the Fragment
    invariants (same shape + same atom => A's atoms[1] = shape[1]//k).

    "bcast_to_frag_c": a small (N,)/(1, N)
    vector (Replicated, or 1D/(1, N) dist Blocked) broadcasts into an
    mma C fragment's columns — the bias add of the mma matmul epilogue.
    Register-only: rep sources select among the vector registers (the
    warp column wx and the quad lane t are runtime). A dist source is
    register-feasible only when every warp's fragment column slab lives
    in its own lanes (warps[1] * 32 == the source's thread count —
    then one shfl.idx to the owner lane + a select over the static reg
    index); wider slabs need cross-warp traffic and fall to tier-2.
    """
    if (isinstance(src, Fragment) and isinstance(dst, Fragment)
            and src.role == "C" and dst.role == "A"
            and src.atom == dst.atom and src.shape == dst.shape
            and src.warps == dst.warps and src.warps[1] == 1
            and src.atoms[0] == dst.atoms[0]):
        return "frag_c_to_a"
    if isinstance(dst, Fragment) and dst.role == "C" \
            and _is_row_vector(src, dst.shape[1]):
        if isinstance(src, Replicated):
            return "bcast_to_frag_c"
        # dist: register-feasible iff each warp's slab is warp-local
        nt = _prod(src.threads)
        if dst.warps[1] * 32 == nt:
            return "bcast_to_frag_c"
    return None


def _is_row_vector(lay, n: int) -> bool:
    """(N,)/(1, N) small-vector layout: Replicated, or a dist Blocked —
    the bias-row forms the mma epilogue broadcasts into a C fragment."""
    if isinstance(lay, Replicated):
        return lay.shape in ((n,), (1, n))
    if isinstance(lay, Blocked):
        return is_dist(lay) and lay.shape in ((n,), (1, n))
    return False


def convert_plan(src: Layout, dst: Layout) -> str:
    """Tier selection for one in-kernel layout conversion.

    Returns "t0" (identity / pure-metadata), "t1:<rule>" (register-tier
    rule hit), or "t2" (smem round-trip — the structural fallback for
    every register-layout pair without a tier-1 rule; the builder
    additionally checks the 48KB static smem budget before emitting).

    tier-3 (global round-trip) is *never* selected here by design: it is
    unavailable inside a kernel and exists only as the graph engine's
    do-not-fuse cost item (2x tensor bytes of DRAM traffic, charged by
    the fusion rules — decision path documented, not
    implemented in convert_layout).
    """
    if src == dst:
        return "t0"
    rule = convert_t1(src, dst)
    if rule is not None:
        return f"t1:{rule}"
    return "t2"


# ---------------------------------------------------------------------------
# Parameter-instance constructors for the codebase's Blocked/Replicated
# layout families: dist/flat/rep/t2/t3 as data.
# ---------------------------------------------------------------------------

def _require_nt(num_threads) -> int:
    if num_threads is None:
        raise LayoutError("this layout needs num_threads")
    nt = int(num_threads)
    if nt <= 0:
        raise LayoutError(f"num_threads must be positive, got {nt}")
    return nt


def dist_layout(shape, num_threads) -> Blocked:
    """"dist": last dim split evenly over a 1D
    thread grid; 1D: spt=(ept,) thr=(nt,); 2D: spt=(1, ept) thr=(1, nt)."""
    shape = _as_int_tuple(shape, "shape")
    nt = _require_nt(num_threads)
    c = shape[-1]
    if c % nt:
        raise LayoutError(f"dist needs shape[-1] % num_threads == 0, "
                          f"got {shape} vs {nt}")
    if len(shape) == 1:
        return Blocked(shape, (c // nt,), (nt,), (0,))
    if len(shape) == 2:
        return Blocked(shape, (1, c // nt), (1, nt), (1, 0))
    raise LayoutError(f"dist supports 1D/2D only, got {shape}")


def flat_layout(shape, num_threads) -> Blocked:
    """"flat": a contiguous raveled run per thread, spt=(1, ept)
    thr=(R, C//ept)."""
    shape = _as_int_tuple(shape, "shape")
    nt = _require_nt(num_threads)
    if len(shape) != 2:
        raise LayoutError(f"flat supports 2D only, got {shape}")
    r, c = shape
    if (r * c) % nt:
        raise LayoutError(f"flat needs (R*C) % num_threads == 0, "
                          f"got {shape} vs {nt}")
    ept = (r * c) // nt
    if c % ept:
        raise LayoutError(f"flat needs C % ept == 0, got C={c}, ept={ept}")
    return Blocked(shape, (1, ept), (r, c // ept), (1, 0))


def rep_layout(shape) -> Replicated:
    """"rep": every thread holds a full copy (small shapes only)."""
    return Replicated(_as_int_tuple(shape, "shape"))


def mma_layout(role: str, shape, atom: str, num_threads) -> Fragment:
    """Warp-slab mma fragment layout (the DSL ``tl.mma_layout``): the
    warp grid stacks all warps along the m dim (warps=(W, 1)) — the
    flash/kda warp-slab convention, where every warp's C row slab spans
    the whole n extent (and its A row slab the whole K extent), which is
    exactly what the tier-1 frag_c_to_a conversion and the row/column
    broadcast rules require. ``atoms`` derives from the shape and the
    atom geometry; the Fragment invariant validates the result. Role "B"
    is not offered (B operands are staged through smem, never register-
    resident at DSL level)."""
    shape = _as_int_tuple(shape, "shape")
    if len(shape) != 2:
        raise LayoutError(f"mma_layout supports 2D shapes, got {shape}")
    if atom not in _ATOM_GEOM:
        raise LayoutError(f"unknown mma atom {atom!r}")
    nt = _require_nt(num_threads)
    if nt % 32:
        raise LayoutError(f"mma_layout needs num_threads % 32 == 0, got {nt}")
    warps = nt // 32
    m, n, k, _ep = _ATOM_GEOM[atom]
    if role == "A":
        atoms = (shape[0] // (warps * m), shape[1] // k)
    elif role == "C":
        atoms = (shape[0] // (warps * m), shape[1] // n)
    else:
        raise LayoutError(
            f"mma_layout role {role!r}: only 'A'/'C' are DSL-constructible "
            "(B operands live in staged smem)")
    return Fragment(shape, atom, role, (warps, 1), atoms)


def t2_layout(shape, tm: int, tn: int, num_threads) -> Blocked:
    """"t2" (matmul_tile/store_t2): 2D thread tile; the tm x tn micro tile
    is tm rows x tn/4 16B column chunks strided by nt_n*4, i.e. a (tm, 4)
    base tile repeating along columns."""
    shape = _as_int_tuple(shape, "shape")
    nt = _require_nt(num_threads)
    if len(shape) != 2:
        raise LayoutError(f"t2 supports 2D only, got {shape}")
    tm, tn = int(tm), int(tn)
    bm, bn = shape
    if tm not in (1, 2, 4, 8) or tn % 4 != 0 or tn < 4:
        raise LayoutError(f"t2 needs tm in (1,2,4,8) and tn % 4 == 0, "
                          f"got tm={tm}, tn={tn}")
    if tm * tn > 64:
        raise LayoutError(f"t2 accumulator too large: tm*tn = {tm * tn} > 64")
    if bm % tm or bn % tn:
        raise LayoutError(f"t2 tile {shape} not divisible by ({tm}, {tn})")
    nt_m, nt_n = bm // tm, bn // tn
    if nt_m * nt_n != nt:
        raise LayoutError(f"t2 thread grid ({nt_m}, {nt_n}) != num_threads "
                          f"{nt}")
    return Blocked(shape, (tm, 4), (nt_m, nt_n), (1, 0))


def t3_layout(shape, tm: int, num_threads) -> Blocked:
    """"t3" (flash_attention_fwd's row-per-thread mapping): each thread
    owns tm full rows of the head dim in registers."""
    shape = _as_int_tuple(shape, "shape")
    nt = _require_nt(num_threads)
    if len(shape) != 2:
        raise LayoutError(f"t3 supports 2D only, got {shape}")
    tm = int(tm)
    r, c = shape
    if r != nt * tm:
        raise LayoutError(f"t3 needs shape[0] == num_threads * tm, "
                          f"got {shape}, nt={nt}, tm={tm}")
    return Blocked(shape, (tm, c), (nt, 1), (1, 0))


# ---------------------------------------------------------------------------
# Structural predicates (the store/emission dispatch): which parameter
# instance a Blocked/Layout value is. These classify exactly the layouts
# the constructors above (and Fragment) produce — no others exist.
# ---------------------------------------------------------------------------

def is_dist(lay) -> bool:
    """dist parameter instance: a Blocked whose thread grid splits only
    the last dim (all leading thread dims are 1)."""
    return (isinstance(lay, Blocked)
            and all(t == 1 for t in lay.threads[:-1]))


def is_flat(lay) -> bool:
    """flat parameter instance: a 2D Blocked whose thread grid's first
    dim spans the whole row dim (thr=(R, C//ept), R > 1, spt=(1, ept)).
    (A (1, C) dist has thr=(1, nt) — the shape[0] > 1 condition keeps
    it out.)"""
    return (isinstance(lay, Blocked) and len(lay.shape) == 2
            and lay.shape[0] > 1
            and lay.threads[0] == lay.shape[0]
            and lay.size_per_thread[0] == 1)


def is_rep_like(lay) -> bool:
    """Per-thread full-copy values: Replicated, or Sliced (reduce
    results — the sliced dim's threads all owned a parent coordinate,
    so the result replicates across them). Emission treats both
    as 'rep' (a whole vector<shape> per thread)."""
    return isinstance(lay, (Replicated, Sliced))


def store_compatible(value_lay, addr_lay) -> bool:
    """Can a value in ``value_lay`` be stored through an address whose
    default layout is ``addr_lay``? Exact equality, or both rep-like:
    a full per-thread copy is the same value form on both sides (e.g.
    storing a Sliced reduce result through a rep address)."""
    return value_lay == addr_lay or (is_rep_like(value_lay)
                                     and is_rep_like(addr_lay))


def is_t2(lay) -> bool:
    """t2 parameter instance: 2D Blocked, (tm, 4) per-thread base tile,
    order (1, 0), the thread grid splitting both dims. Note: tm=1, tn=4
    t2 is structurally identical to an ept=4 flat (same ownership map) —
    dispatch order (is_t2 before the flat arm) resolves it
    deterministically; they share every owned address anyway."""
    return (isinstance(lay, Blocked) and len(lay.shape) == 2
            and lay.order == (1, 0)
            and lay.size_per_thread[1] == 4
            and lay.threads[0] > 1
            and lay.threads[0] * lay.size_per_thread[0] == lay.shape[0]
            and lay.threads[1] * 4 <= lay.shape[1])


def is_t3(lay) -> bool:
    """t3 parameter instance (row-per-thread, the flash t3 mapping):
    2D Blocked, order (1, 0), the thread grid spanning only the row dim
    (thr=(R/tm, 1)) and each thread owning tm FULL rows (spt=(tm, C))."""
    return (isinstance(lay, Blocked) and len(lay.shape) == 2
            and lay.order == (1, 0)
            and lay.threads[1] == 1
            and lay.size_per_thread[1] == lay.shape[1]
            and lay.threads[0] * lay.size_per_thread[0] == lay.shape[0])


def vec_ept(lay: Layout) -> int:
    """The builder Tensor.ept convention for a Layout: dist keeps the
    per-row VEC (spt[-1] — for a 2D dist tile this is *not*
    the whole-tile register count); every other layout's ept is the
    whole-tile per-thread register count (flat: ept; t2: tm*tn; t3:
    tm*C (C=64 in current use); rep-like: prod; Fragment: the
    operand/accumulator regs)."""
    if is_dist(lay):
        return lay.size_per_thread[-1]
    return lay.regs_per_thread()


def default_layout(shape, num_threads) -> Layout:
    """The load-time default rule (layout follows the value; this
    is only the pick when nothing requests otherwise): dist when the
    last dim splits evenly, else flat when a raveled run fits, else rep."""
    shape = _as_int_tuple(shape, "shape")
    nt = _require_nt(num_threads)
    if len(shape) == 1:
        if shape[0] % nt == 0:
            return dist_layout(shape, nt)
        return rep_layout(shape)
    if len(shape) != 2:
        raise LayoutError(f"default_layout supports 1D/2D only, got {shape}")
    r, c = shape
    if c % nt == 0:
        return dist_layout(shape, nt)
    if (r * c) % nt == 0 and c > 1:
        ept = (r * c) // nt
        if c % ept == 0:
            return flat_layout(shape, nt)
    return rep_layout(shape)
