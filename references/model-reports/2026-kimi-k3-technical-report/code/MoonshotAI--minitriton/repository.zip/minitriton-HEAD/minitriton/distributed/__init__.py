"""Distributed package.

- ``ProcessGroup``: a thin tensor-level collective API over the ctypes
  libnccl binding (``distributed/nccl.py``): single machine, one
  process per GPU, f32 buffers, the default stream — ordered with
  every tl kernel launch.
- ``init_process_group(backend="nccl", rank, world_size, init_method)``:
  the unique id is exchanged through a rendezvous file
  (``init_method="file://<path>"`` or ``$MT_INIT_FILE``); ready-files form
  the post-init barrier. Rank/world default to ``$MT_RANK``/``$MT_WORLD_SIZE``.
- ``launch(fn, nproc, args=())``: minimal torchrun semantics — ``spawn``
  one process per rank, injecting ``MT_RANK/MT_WORLD_SIZE/MT_LOCAL_RANK/
  MT_DEVICE/MT_INIT_FILE`` into each child's environment.
- ``DistributedDataParallel(module)``: parameter broadcast at construction,
  then one flat f32 allreduce over all ``param.grad`` per ``sync_grads()``
  call (no bucketing/overlap).
"""

from __future__ import annotations

import multiprocessing as mp
import os
import tempfile
import time
from pathlib import Path

from ..frontend import types as tl_types
from ..tensor import Tensor
from . import nccl

_PG: "ProcessGroup | None" = None

_REDUCE_OPS = {"sum": nccl.ncclSum, "prod": nccl.ncclProd,
               "max": nccl.ncclMax, "min": nccl.ncclMin}


def _uid_bytes(uid: "nccl.NcclUniqueId") -> bytes:
    # a c_char array field truncates at the first NUL on attribute access;
    # read the full fixed-size struct instead
    import ctypes
    return ctypes.string_at(ctypes.addressof(uid),
                            nccl.NCCL_UNIQUE_ID_BYTES)


def _check_coll_tensor(t: Tensor, what: str):
    if t.device != "cuda":
        raise RuntimeError(f"{what}: collectives run on cuda tensors, got "
                           f"{t.device}")
    if t.dtype != tl_types.float32:
        raise RuntimeError(
            f"{what}: collectives are currently f32 only, got {t.dtype}")
    if not t.is_contiguous():
        raise RuntimeError(
            f"{what}: collective buffers must be contiguous "
            f"(call .contiguous() first)")


class ProcessGroup:
    """One NCCL communicator + rank bookkeeping (singleton per process)."""

    def __init__(self, rank: int, world_size: int, rendezvous: Path,
                 timeout_s: float = 120.0):
        uid_path = rendezvous.with_suffix(rendezvous.suffix + ".uid")
        ready_path = rendezvous.with_suffix(
            rendezvous.suffix + f".ready.{rank}")
        # Stale rendezvous files from a previous run must fail LOUD at
        # entry, before any NCCL work: with a leftover .uid a non-zero
        # rank would read the OLD unique id and hang the warmup allreduce
        # on a communicator rank 0 no longer owns (and leftover .ready
        # files defeat the post-init barrier). launch() always rendezvouses
        # on a fresh mkstemp name; this guards manual init_method reuse.
        if rank == 0 and uid_path.exists():
            raise RuntimeError(
                f"init_process_group: stale rendezvous file {uid_path} "
                f"from a previous run — delete it (and "
                f"{rendezvous}.ready.*) or use a fresh init_method path")
        if ready_path.exists():
            raise RuntimeError(
                f"init_process_group: stale ready file {ready_path} from "
                f"a previous run — delete it or use a fresh init_method "
                f"path")
        from ..runtime.buffer import get_device
        self._device = get_device()  # CUDA context current before NCCL init
        self.rank = rank
        self.world_size = world_size
        self._comm = nccl.NcclComm(rank, world_size)
        if rank == 0:
            uid = nccl.get_unique_id()
            tmp = rendezvous.with_suffix(rendezvous.suffix + f".tmp.{os.getpid()}")
            tmp.write_bytes(_uid_bytes(uid))
            os.replace(tmp, uid_path)  # atomic publish
        deadline = time.monotonic() + timeout_s
        while not uid_path.is_file():
            if time.monotonic() > deadline:
                raise TimeoutError(
                    f"init_process_group: {uid_path} did not appear within "
                    f"{timeout_s:.0f}s")
            time.sleep(0.01)
        raw = uid_path.read_bytes()
        if len(raw) != nccl.NCCL_UNIQUE_ID_BYTES:
            raise RuntimeError(
                f"init_process_group: corrupt uid file {uid_path} "
                f"({len(raw)} bytes)")
        uid = nccl.NcclUniqueId()
        import ctypes
        ctypes.memmove(ctypes.addressof(uid), raw,
                       nccl.NCCL_UNIQUE_ID_BYTES)
        self._comm.init_rank(uid)
        # post-init barrier: ready files + a warmup allreduce, so a broken
        # rendezvous fails at init, not mid-training
        ready_path.touch()
        while not all(
                rendezvous.with_suffix(rendezvous.suffix + f".ready.{r}").is_file()
                for r in range(world_size)):
            if time.monotonic() > deadline:
                raise TimeoutError("init_process_group: ready barrier timed "
                                   "out")
            time.sleep(0.01)
        import minitriton as tl
        warm = tl.ones((1,), device="cuda")
        self._comm.allreduce(warm._buffer_arg().ptr, warm._buffer_arg().ptr,
                             1, warm.dtype, nccl.ncclSum)
        self._device.synchronize()

    # -- collectives (buffer-level, f32; allreduce/broadcast in place) -----

    def allreduce(self, t: Tensor, op: str = "sum") -> Tensor:
        """In-place allreduce over a contiguous f32 cuda tensor."""
        _check_coll_tensor(t, "allreduce")
        if op not in _REDUCE_OPS:
            raise ValueError(f"allreduce op must be one of "
                             f"{sorted(_REDUCE_OPS)}, got {op!r}")
        ptr = t._buffer_arg().ptr
        self._comm.allreduce(ptr, ptr, t.numel(), t.dtype, _REDUCE_OPS[op])
        return t

    def broadcast(self, t: Tensor, root: int = 0) -> Tensor:
        """In-place broadcast of rank ``root``'s buffer to every rank."""
        _check_coll_tensor(t, "broadcast")
        ptr = t._buffer_arg().ptr
        self._comm.broadcast(ptr, ptr, t.numel(), t.dtype, int(root))
        return t

    def allgather(self, t: Tensor) -> Tensor:
        """-> concatenation of every rank's (identically shaped) tensor."""
        _check_coll_tensor(t, "allgather")
        from ..tensor import empty
        out = empty((self.world_size * t.numel(),), t.dtype, "cuda")
        self._comm.allgather(t._buffer_arg().ptr, out._buffer_arg().ptr,
                             t.numel(), t.dtype)
        return out.reshape((self.world_size,) + t.shape)

    def reduce_scatter(self, t: Tensor, op: str = "sum") -> Tensor:
        """Reduce (world_size * n,) tensor, scatter n-element shards."""
        _check_coll_tensor(t, "reduce_scatter")
        if op not in _REDUCE_OPS:
            raise ValueError(f"reduce_scatter op must be one of "
                             f"{sorted(_REDUCE_OPS)}, got {op!r}")
        if t.numel() % self.world_size != 0:
            raise RuntimeError(
                f"reduce_scatter: numel {t.numel()} not divisible by "
                f"world_size {self.world_size}")
        from ..tensor import empty
        out = empty((t.numel() // self.world_size,), t.dtype, "cuda")
        self._comm.reduce_scatter(t._buffer_arg().ptr, out._buffer_arg().ptr,
                                  out.numel(), t.dtype, _REDUCE_OPS[op])
        return out

    def barrier(self):
        """Host-blocking barrier: tiny allreduce + stream sync."""
        import minitriton as tl
        t = tl.zeros((1,), device="cuda")
        self.allreduce(t)
        self._device.synchronize()


# ---------------------------------------------------------------------------
# process-group lifecycle
# ---------------------------------------------------------------------------

def init_process_group(backend: str = "nccl", rank: int | None = None,
                       world_size: int | None = None,
                       init_method: str | None = None) -> ProcessGroup:
    """Create the process-wide process group (raises on a second call).
    Rank/world_size default to $MT_RANK/$MT_WORLD_SIZE; the
    rendezvous file comes from init_method="file://<path>" (default:
    $MT_INIT_FILE or a fresh temp path — only valid for world_size == 1)."""
    global _PG
    if _PG is not None:
        raise RuntimeError("init_process_group called twice")
    if backend != "nccl":
        raise NotImplementedError(
            f"distributed currently supports backend='nccl' only, got {backend!r}")
    rank = int(os.environ["MT_RANK"]) if rank is None else int(rank)
    world_size = int(os.environ["MT_WORLD_SIZE"]) if world_size is None \
        else int(world_size)
    if not (0 <= rank < world_size):
        raise ValueError(f"invalid rank {rank} for world_size {world_size}")
    init_method = init_method or os.environ.get("MT_INIT_FILE")
    if init_method is None:
        if world_size != 1:
            raise RuntimeError(
                "init_method needed for world_size > 1 (file://<path> or "
                "$MT_INIT_FILE)")
        fd, init_method = tempfile.mkstemp(prefix="mt_pg_")
        os.close(fd)
    if init_method.startswith("file://"):
        init_method = init_method[len("file://"):]
    _PG = ProcessGroup(rank, world_size, Path(init_method))
    return _PG


def get_process_group() -> ProcessGroup:
    if _PG is None:
        raise RuntimeError(
            "process group not initialized; call init_process_group first")
    return _PG


def is_initialized() -> bool:
    return _PG is not None


def destroy_process_group():
    global _PG
    if _PG is not None:
        _PG._comm.destroy()
        _PG = None


def get_rank() -> int:
    return get_process_group().rank


def get_world_size() -> int:
    return get_process_group().world_size


# ---------------------------------------------------------------------------
# launch: minimal torchrun semantics (spawn + env injection)
# ---------------------------------------------------------------------------

def _child_main(rank: int, world_size: int, init_file: str, fn, args):
    os.environ["MT_RANK"] = str(rank)
    os.environ["MT_WORLD_SIZE"] = str(world_size)
    os.environ["MT_LOCAL_RANK"] = str(rank)  # single node
    os.environ["MT_DEVICE"] = str(rank)
    os.environ["MT_INIT_FILE"] = init_file
    fn(rank, world_size, *args)


def launch(fn, nproc: int, args: tuple = ()):
    """Spawn ``nproc`` processes running ``fn(rank, world_size, *args)``.

    ``fn`` must be a module-level (picklable) function. The child's
    environment is injected with the MT_* rendezvous variables above, so
    ``fn`` can simply call ``init_process_group()``. Raises the first
    non-zero child exit as a RuntimeError (child tracebacks go to stderr).
    """
    if nproc < 1:
        raise ValueError(f"nproc must be >= 1, got {nproc}")
    ctx = mp.get_context("spawn")
    # spawn children do not inherit -u; without this their stdout is
    # block-buffered and the parent looks silent mid-run
    os.environ.setdefault("PYTHONUNBUFFERED", "1")
    fd, init_file = tempfile.mkstemp(prefix="mt_pg_")
    os.close(fd)
    os.unlink(init_file)  # only the name is used (uid/ready files below it)
    procs = [ctx.Process(target=_child_main,
                         args=(r, nproc, init_file, fn, tuple(args)))
             for r in range(nproc)]
    for p in procs:
        p.start()
    for p in procs:
        p.join()
    for suffix in (".uid",) + tuple(f".ready.{r}" for r in range(nproc)):
        try:
            os.unlink(init_file + suffix)
        except OSError:
            pass
    bad = [(i, p.exitcode) for i, p in enumerate(procs) if p.exitcode != 0]
    if bad:
        raise RuntimeError(
            f"distributed.launch: workers failed: {bad} "
            "(child tracebacks above)")


# ---------------------------------------------------------------------------
# DistributedDataParallel
# ---------------------------------------------------------------------------

class DistributedDataParallel:
    """Single-bucket DDP.

    Construction broadcasts rank 0's parameters to every rank. After
    ``loss.backward()``, call ``sync_grads()``: all parameter grads are
    packed into one flat f32 tensor, allreduced once (sum), averaged by
    1/world_size and scattered back into each ``param.grad``. No
    bucketing/overlap with the backward pass.
    """

    def __init__(self, module, process_group: ProcessGroup | None = None):
        self.module = module
        self.pg = process_group or get_process_group()
        self._params = list(module.parameters())
        self._flat_numel = sum(p.numel() for p in self._params)
        self.broadcast_parameters()

    # -- helpers -------------------------------------------------------------

    def _pack(self, tensors) -> Tensor:
        """Concatenate flattened tensors into one fresh f32 buffer."""
        import minitriton as tl
        flats = []
        for t in tensors:
            v = t.reshape((t.numel(),))
            flats.append(v if v.is_contiguous() else v.contiguous())
        if len(flats) == 1:
            return flats[0].contiguous()
        return tl.cat(flats, dim=0)

    def _unpack_into(self, flat: Tensor, dsts):
        from .. import ops
        off = 0
        for d in dsts:
            n = d.numel()
            ops._copy_into_view(d, flat[off:off + n].reshape(d.shape))
            off += n

    def broadcast_parameters(self, root: int = 0):
        """Rank ``root``'s parameters become every rank's parameters."""
        flat = self._pack([p for p in self._params])
        self.pg.broadcast(flat, root=root)
        self.pg._device.synchronize()
        self._unpack_into(flat, self._params)

    def sync_grads(self):
        """One flat allreduce (sum) over all param grads, averaged over
        the world. Every parameter must have a grad.

        No trailing device synchronize on purpose: the allreduce rides the
        same default stream as every tl kernel launch, so the
        clip/optimizer work queued after it is already ordered — a host
        sync here would flush the launch pipeline every step (measured:
        it throttles DDP steady-state throughput)."""
        grads = []
        for p in self._params:
            if p.grad is None:
                raise RuntimeError(
                    "DistributedDataParallel.sync_grads: a parameter has no "
                    "grad (frozen params are not supported)")
            grads.append(p.grad)
        flat = self._pack(grads)
        self.pg.allreduce(flat, op="sum")
        if self.pg.world_size != 1:
            flat = flat * (1.0 / self.pg.world_size)
        self._unpack_into(flat, grads)

    # -- Module-style delegation ------------------------------------------------

    def forward(self, *args, **kwargs):
        return self.module(*args, **kwargs)

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)

    def parameters(self):
        return iter(self._params)

    def zero_grad(self):
        self.module.zero_grad()

    def train(self, mode: bool = True):
        self.module.train(mode)
        return self

    def eval(self):
        self.module.eval()
        return self
