"""Graph-level fusion rule engine.

A declarative rule registry: every rule is an object with
``match / profitable / build``; the engine does one forward scan over the
``@tl.compile`` trace graph, tries enabled rules per node in priority
order, and marks claimed members covered. The output is the ``fused``
dict ``compile.py::_plan`` returns (root node -> group spec), with the
``"alias"`` spec type (edge-drop rules) and cast-absorbed members in
``"ew_chain"``.

Nodes are duck-typed (``kind``/``fn``/``args``/``shape``/``dtype`` —
``compile.py::_Node``); this module never imports ``compile.py`` (import
cycle).

Rules:

===============  ====  ===================================================
rule             prio  what
===============  ====  ===================================================
r2v_mm_v2_epilogue 105 matmul (fp32, allow_tf32 off) (+ bias) (+ unary)
                       on the mm_v2 path: epilogue on the f32 accumulator
                       before the t2 store (the fp32 sibling of R2')
r2p_mma_epilogue 110   matmul(_bf16) (+ bias) (+ unary) on the mma path:
                       fused mma_tile kernel, epilogue on the C fragment
                       (R2'; split-K candidates and stride-ineligible
                       graphs are rejected/degraded)
r2_mm_epilogue   100   matmul (+ bias add) (+ unary chain)
r8_trans_contig   90   ``permute -> contiguous`` feeding only matmul:
                       drop the copy (alias); the eager matmul TRANS-stages
                       the view (``_mm_prep(allow_trans=True)``)
r3_cast_fold      12   R1 + single-consumer ``astype(->f32)`` absorbed into
                       the chain; the leaf load becomes a load-cast
                       (``tl.cast`` house idiom); also allows R4 vocab
r4_bw_chain       11   R1 + backward/fused binary exprs
                       (``_BINARY_BW``/``_FUSED_BINARY``: gelu_bw→add & co)
r1_ew_chain       10   same-shape f32 elementwise chains
===============  ====  ===================================================

Richer vocabularies run first; with every rule enabled the planner is the
maximal-fusion superset. ``MT_FUSION_RULES="r3_cast_fold,r4_bw_chain"``
(comma-separated names) disables rules.

Cost model: purely structural — fuse iff the group
eliminates >=1 global round-trip (single-consumer intermediates are dead
once inlined). No measured-cost adjudication.

Stats: ``_STATS`` (one dict per ``plan()`` call: per-rule hits + reject
reasons + group/node counts), ``stats()`` / ``reset_stats()`` — same
convention as ``compiler/passes.py``.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from .frontend import types as tl_types

f32 = tl_types.float32

_EW_FNS = {"unary", "binary", "binary_scalar"}

# per-plan() dicts, for tests/debug (compiler/passes.py convention)
_STATS: list[dict] = []


def stats() -> list[dict]:
    return list(_STATS)


def reset_stats() -> None:
    _STATS.clear()


def _is_node(v) -> bool:
    return hasattr(v, "kind") and hasattr(v, "fn") and hasattr(v, "args")


def _ew_inputs(n) -> list:
    if n.fn == "unary":
        return [n.args[1]]
    if n.fn == "binary":
        return [n.args[1], n.args[2]]
    if n.fn == "binary_scalar":
        return [n.args[1]]
    return []


def _binary_vocab(allow_bw: bool) -> frozenset:
    """Binary op names the fused elementwise codegen can express."""
    from .device.cuda.elementwise import _BINARY, _BINARY_BW, _FUSED_BINARY
    vocab = set(_BINARY)  # add/sub/mul/div/pow
    if allow_bw:
        vocab |= set(_BINARY_BW) | set(_FUSED_BINARY)
    return frozenset(vocab)


def _unary_vocab() -> frozenset:
    from .device.cuda.elementwise import _UNARY
    return frozenset(_UNARY)


# ---------------------------------------------------------------------------
# rule infrastructure
# ---------------------------------------------------------------------------


@dataclass
class Match:
    root: object
    members: set
    params: dict = field(default_factory=dict)


class FusionRule:
    name: str = ""
    priority: int = 0

    def match(self, node, ctx) -> Match | None:
        return None

    def profitable(self, m: Match, ctx) -> bool:
        return True

    def build(self, m: Match, ctx) -> dict:
        raise NotImplementedError


RULES: list[FusionRule] = []


def register(cls):
    RULES.append(cls())
    return cls


def _disabled_names() -> set:
    raw = os.environ.get("MT_FUSION_RULES", "").strip()
    return {s.strip() for s in raw.split(",") if s.strip()}


class PlanCtx:
    def __init__(self, g):
        self.g = g
        self.consumers: dict = {}
        for n in g.nodes:
            for a in n.args:
                for v in (a if isinstance(a, tuple) else (a,)):
                    if _is_node(v):
                        self.consumers.setdefault(v, []).append(n)
        self.covered: set = set()
        self.rejects: dict = {}  # rule name -> {reason: count}

    def single_consumer(self, n):
        c = self.consumers.get(n, [])
        return c[0] if len(c) == 1 else None

    def reject(self, rule: str, reason: str) -> None:
        r = self.rejects.setdefault(rule, {})
        r[reason] = r.get(reason, 0) + 1


# ---------------------------------------------------------------------------
# R2 — matmul epilogue
# ---------------------------------------------------------------------------


@register
class R2MmEpilogue(FusionRule):
    name = "r2_mm_epilogue"
    priority = 100

    def match(self, node, ctx) -> Match | None:
        n = node
        if n.kind != "be" or n.fn != "matmul":
            return None
        unary_ok = _unary_vocab()
        chain = []
        bias_node = None
        cur = n
        c = ctx.single_consumer(cur)
        if c is not None and c.kind == "be" and c.fn == "binary" \
                and c.args[0] == "add":
            op, a_n, b_n, _ = c.args
            other = b_n if a_n is n else (a_n if b_n is n else None)
            if other is not None \
                    and other.shape in (n.shape[-1:], (1,) + n.shape[-1:]):
                bias_node = other
                chain.append(c)
                cur = c
                c = ctx.single_consumer(cur)
        while c is not None and c.kind == "be" and c.fn == "unary" \
                and c.args[0] in unary_ok:
            chain.append(c)
            cur = c
            c = ctx.single_consumer(cur)
        if not chain:
            ctx.reject(self.name, "no_epilogue")
            return None
        return Match(chain[-1], {n} | set(chain),
                     {"mm": n, "bias": bias_node, "chain": chain})

    def build(self, m: Match, ctx) -> dict:
        from .device.cuda.elementwise import _UNARY
        chain = m.params["chain"]
        # epilogue expr over the accumulator value v; the generated kernel
        # already computes v = acc + bias, so the expr covers only the
        # activation chain (the add node just proves the bias pattern)
        act_nodes = chain[1:] if chain and chain[0].args[0] == "add" \
            else chain
        expr = "v"
        for un in act_nodes:
            op = un.args[0]
            template, kind = _UNARY[op]
            expr = template.replace("{zero}", "0.0").format(x=f"({expr})")
        return {"type": "mm_epilogue", "mm": m.params["mm"],
                "bias": m.params["bias"], "expr": expr,
                "members": m.members}


# ---------------------------------------------------------------------------
# R2' — matmul epilogue on the mma path
# ---------------------------------------------------------------------------


def _allow_tf32_flag() -> bool:
    from .device.cuda.ops import get_allow_tf32
    return get_allow_tf32()


@register
class R2pMmaEpilogue(FusionRule):
    """matmul(_bf16) (+ bias add) (+ unary chain) routed to a fused
    mma_tile kernel: the epilogue runs on the f32 C fragment (bias via
    the tier-1 bcast_to_frag_c convert_layout rule), then store_m4
    (bf16 packed direct store for the bf16 tier, f32 for tf32).

    Match conditions mirror r2_mm_epilogue plus the mma-route guards:
    - bf16 tier: be.matmul_bf16 nodes (bf16/f32 operands). f32-out
      candidates for split-K (K >= 4096 and K >= 4*M — the same
      structural gate _mm_bf16_splitk uses before judging) are
      rejected: partials not yet reduced can't take an epilogue. The
      split-K pick itself is a runtime coin-flip below the gate, but
      it only ever applies above it, so the structural guard is exact.
    - tf32 tier: plain be.matmul nodes only while the allow_tf32 flag
      is on at plan time (the flag is part of the compile cache key,
      so it cannot flip between plan and exec;
      flag-off traces keep the r2 v1-dot route).
    - stride/atom eligibility is re-checked at exec time on the real
      tensors (_mma_stride_check + plain-or-pure-trans operands);
      ineligible graphs degrade to the eager replay (correct, just
      unfused) rather than failing.
    Priority above r2_mm_epilogue: the mma route wins when applicable.
    """
    name = "r2p_mma_epilogue"
    priority = 110

    def match(self, node, ctx) -> Match | None:
        n = node
        if n.kind != "be":
            return None
        if n.fn == "matmul_bf16":
            a_n, b_n, out_dtype, baked_bias = n.args
            out_dtype = out_dtype or tl_types.bfloat16
            atom = "bf16"
        elif n.fn == "matmul":
            if not _allow_tf32_flag():
                return None  # f32 exact path stays with r2 (v1 dot)
            a_n, b_n = n.args
            out_dtype, baked_bias = f32, None
            atom = "tf32"
        else:
            return None
        M, Kd = a_n.shape
        N = b_n.shape[1]
        if out_dtype == f32 and atom == "bf16" \
                and Kd >= 4096 and Kd >= 4 * M:
            ctx.reject(self.name, "splitk_candidate")
            return None
        unary_ok = _unary_vocab()
        chain = []
        bias_node = baked_bias
        cur = n
        c = ctx.single_consumer(cur)
        if c is not None and c.kind == "be" and c.fn == "binary" \
                and c.args[0] == "add":
            op, x_n, y_n, _ = c.args
            other = y_n if x_n is n else (x_n if y_n is n else None)
            if other is not None and other.shape in ((N,), (1, N)):
                if bias_node is not None:
                    ctx.reject(self.name, "double_bias")
                    return None
                bias_node = other
                chain.append(c)
                cur = c
                c = ctx.single_consumer(cur)
        while c is not None and c.kind == "be" and c.fn == "unary" \
                and c.args[0] in unary_ok:
            chain.append(c)
            cur = c
            c = ctx.single_consumer(cur)
        if not chain and bias_node is None:
            ctx.reject(self.name, "no_epilogue")
            return None
        return Match(chain[-1] if chain else n, {n} | set(chain),
                     {"mm": n, "bias": bias_node, "chain": chain,
                      "atom": atom, "out_dtype": out_dtype})

    def build(self, m: Match, ctx) -> dict:
        from .device.cuda.elementwise import _UNARY
        chain = m.params["chain"]
        # epilogue expr over v = acc (+ bias) — the add node just proves
        # the bias pattern (same convention as r2_mm_epilogue)
        act_nodes = chain[1:] if chain and chain[0].args[0] == "add" \
            else chain
        expr = "v"
        for un in act_nodes:
            op = un.args[0]
            template, kind = _UNARY[op]
            expr = template.replace("{zero}", "0.0").format(x=f"({expr})")
        return {"type": "mma_epilogue", "mm": m.params["mm"],
                "bias": m.params["bias"], "expr": expr,
                "atom": m.params["atom"],
                "out_dtype": m.params["out_dtype"],
                "chain": m.params["chain"],
                "members": m.members}


# ---------------------------------------------------------------------------
# R2v — matmul epilogue on the fp32 store_t2 (matmul_v2) path
# ---------------------------------------------------------------------------


@register
class R2vMmV2Epilogue(FusionRule):
    """matmul (fp32 exact path, allow_tf32 off) (+ bias add) (+ unary
    chain) routed to a fused matmul_v2 (store_t2) kernel: the epilogue
    runs on the f32 accumulator before the t2 store — the fp32 sibling
    of R2' (mma path), and a strict upgrade of r2's v1 dot for eligible
    fp32 shapes.

    Match conditions mirror r2_mm_epilogue plus the v2-route guards:
    plain be.matmul nodes only while the allow_tf32 flag is off (the
    tf32-on plain-matmul case belongs to R2'); split-K candidates
    (K >= 4096 and K >= 4*M — the same structural gate _mm_fp32_splitk
    uses before judging) are rejected: partials not yet reduced can't
    take an epilogue. Stride/layout eligibility is re-checked at exec
    time on the real tensors (unit-stride or pure-transpose operands);
    ineligible graphs degrade to the eager replay.
    Priority between R2' (110) and r2 (100).

    Epilogue semantics (the t2 store's bias_pt adds the bias on the way
    out; a bias value cannot broadcast onto the t2 accumulator in the
    v1 DSL):
    - unary chain, no bias: the whole chain fuses, expr applied to acc;
    - bias only: the matmul+add fuses (expr = identity);
    - bias + unary: only the matmul+bias fuses — the unary chain
      replays eagerly on the fused output (correct, and strictly better
      than r2's v1 dot for these shapes). Putting the unary inside too
      needs a tier-1 (1,C) -> Blocked(t2) broadcast in convert_layout
      (registered follow-up).
    """
    name = "r2v_mm_v2_epilogue"
    priority = 105

    def match(self, node, ctx) -> Match | None:
        n = node
        if n.kind != "be" or n.fn != "matmul":
            return None
        if _allow_tf32_flag():
            ctx.reject(self.name, "tf32_flag_on")
            return None  # tf32-on plain matmul belongs to R2'
        a_n, b_n = n.args
        M, Kd = a_n.shape
        N = b_n.shape[1]
        if Kd >= 4096 and Kd >= 4 * M:
            ctx.reject(self.name, "splitk_candidate")
            return None
        unary_ok = _unary_vocab()
        chain = []
        bias_node = None
        cur = n
        c = ctx.single_consumer(cur)
        if c is not None and c.kind == "be" and c.fn == "binary" \
                and c.args[0] == "add":
            op, x_n, y_n, _ = c.args
            other = y_n if x_n is n else (x_n if y_n is n else None)
            if other is not None and other.shape in ((N,), (1, N)):
                bias_node = other
                chain.append(c)
                cur = c
                c = ctx.single_consumer(cur)
        unary = []
        while c is not None and c.kind == "be" and c.fn == "unary" \
                and c.args[0] in unary_ok:
            unary.append(c)
            cur = c
            c = ctx.single_consumer(cur)
        if bias_node is not None and unary:
            # fuse only up to the bias add; the unary chain replays
            # eagerly on the fused output (see the docstring)
            return Match(chain[-1], {n} | set(chain),
                         {"mm": n, "bias": bias_node, "chain": chain,
                          "act": []})
        chain += unary
        if not chain and bias_node is None:
            ctx.reject(self.name, "no_epilogue")
            return None
        return Match(chain[-1] if chain else n, {n} | set(chain),
                     {"mm": n, "bias": bias_node, "chain": chain,
                      "act": unary})

    def build(self, m: Match, ctx) -> dict:
        from .device.cuda.elementwise import _UNARY
        # epilogue expr over v = acc — any bias rides the store_t2
        # bias_pt per-fragment add, so the expr covers only the unary
        # activation chain (same convention as r2/r2p for the add proof)
        expr = "v"
        for un in m.params["act"]:
            op = un.args[0]
            template, kind = _UNARY[op]
            expr = template.replace("{zero}", "0.0").format(x=f"({expr})")
        return {"type": "mm_v2_epilogue", "mm": m.params["mm"],
                "bias": m.params["bias"], "expr": expr,
                "chain": m.params["chain"],
                "members": m.members}


# ---------------------------------------------------------------------------
# R8 — permute -> contiguous feeding matmul: drop the copy
# ---------------------------------------------------------------------------


@register
class R8TransContig(FusionRule):
    name = "r8_trans_contig"
    priority = 90

    def match(self, node, ctx) -> Match | None:
        n = node
        if n.kind != "method" or n.fn != "contiguous":
            return None
        src = n.args[0]
        if not (_is_node(src) and src.kind == "method"
                and src.fn == "permute"):
            ctx.reject(self.name, "src_not_permute")
            return None
        cons = ctx.consumers.get(n, [])
        if not cons:
            ctx.reject(self.name, "output_node")
            return None  # graph output must materialize the real layout
        for c in cons:
            if not (c.kind == "be" and c.fn == "matmul"):
                ctx.reject(self.name, "consumer_not_matmul")
                return None
        return Match(n, {n}, {"src": src})

    def build(self, m: Match, ctx) -> dict:
        # alias: _Exec binds this node to the permute view; the eager
        # matmul TRANS-stages it (_mm_prep(allow_trans=True)), the copy
        # kernel never runs
        return {"type": "alias", "src": m.params["src"],
                "members": m.members}


# ---------------------------------------------------------------------------
# R1 / R4 / R3 — elementwise chain family (shared walker)
# ---------------------------------------------------------------------------


class _EwChainBase(FusionRule):
    """Same-shape f32 elementwise chains; vocab flags widen the family.

    allow_bw: binary ops from _BINARY_BW/_FUSED_BINARY (backward exprs).
    allow_cast: single-consumer astype(->f32) nodes are absorbed into the
    group (they never execute; their input becomes a load-cast leaf).
    """

    allow_bw = False
    allow_cast = False

    def _vocab_ok(self, n) -> bool:
        op = n.args[0]  # gelu tables are flag-patched at build: any form
        # in the vocab (erf default / tanh opt-out) is fusable as-is
        if n.fn == "unary":
            return op in _unary_vocab()
        if n.fn in ("binary", "binary_scalar"):
            return op in _binary_vocab(self.allow_bw)
        return False

    def _chain_node(self, n, shape) -> bool:
        return _is_node(n) and n.kind == "be" and n.fn in _EW_FNS \
            and n.shape == shape and n.dtype == f32 and self._vocab_ok(n)

    def _is_top(self, n, ctx) -> bool:
        """A chain root has no single consumer that would absorb it."""
        c = ctx.single_consumer(n)
        if c is None or not self._chain_node(c, n.shape):
            return True
        return False  # c would claim n as a member

    def match(self, node, ctx) -> Match | None:
        root = node
        if root.kind != "be" or root.fn not in _EW_FNS:
            return None
        if root.dtype != f32 or root.shape == ():
            return None  # fuses same-shape f32 chains only
        if not self._vocab_ok(root):
            ctx.reject(self.name, "root_op_not_expressible")
            return None
        if not self._is_top(root, ctx):
            return None  # mid-chain; the chain's top claims it
        members = {root}
        cast_members: set = set()
        frontier = [root]
        while frontier:
            cur = frontier.pop()
            for i_n in _ew_inputs(cur):
                if not _is_node(i_n) or i_n in covered_or_members(
                        ctx, members):
                    continue
                if self._chain_node(i_n, root.shape) \
                        and ctx.single_consumer(i_n) is cur:
                    members.add(i_n)
                    frontier.append(i_n)
                    continue
                if self.allow_cast and i_n.fn == "astype" \
                        and i_n.args[1] == f32 and i_n.shape == root.shape:
                    # absorb the cast: it vanishes, its input becomes a
                    # (load-cast) leaf — only if every consumer is inside
                    cast_members.add(i_n)
                    members.add(i_n)
        # eject casts with consumers outside the group (the cast tensor is
        # still needed elsewhere -> it must execute; it stays a plain leaf)
        for cn in list(cast_members):
            if any(c not in members for c in ctx.consumers.get(cn, [])):
                members.discard(cn)
                cast_members.discard(cn)
                ctx.reject(self.name, "cast_multi_consumer")
        if len(members) <= 1:
            ctx.reject(self.name, "chain_too_short")
            return None
        # every leaf must match the root shape exactly — the fused
        # kernel loads leaves flat (broadcasts would read OOB). Strides are
        # re-checked before launch by compile.py::_Exec._run_ew_group
        # (non-contiguous leaf -> eager replay).
        for m in members:
            ins = _ew_inputs(m) if m.fn in _EW_FNS else [m.args[0]]
            for i_n in ins:
                if _is_node(i_n) and i_n not in members \
                        and i_n.shape != root.shape:
                    ctx.reject(self.name, "leaf_shape_mismatch")
                    return None
        return Match(root, members, {"cast_members": cast_members})

    def profitable(self, m: Match, ctx) -> bool:
        # structural cost model: the group eliminates
        # >=1 single-consumer intermediate round-trip by construction
        return len(m.members) > 1

    def build(self, m: Match, ctx) -> dict:
        return {"type": "ew_chain", "members": m.members,
                "cast_members": m.params["cast_members"]}


def covered_or_members(ctx, members) -> set:
    return ctx.covered | members


@register
class R3CastFold(_EwChainBase):
    name = "r3_cast_fold"
    priority = 12
    allow_bw = True
    allow_cast = True


@register
class R4BwChain(_EwChainBase):
    name = "r4_bw_chain"
    priority = 11
    allow_bw = True


@register
class R1EwChain(_EwChainBase):
    name = "r1_ew_chain"
    priority = 10


# ---------------------------------------------------------------------------
# engine (backs compile.py::_plan)
# ---------------------------------------------------------------------------


def plan(g, out) -> dict:
    """-> (fused_groups: dict root node -> group spec)."""
    ctx = PlanCtx(g)
    disabled = _disabled_names()
    active = sorted((r for r in RULES if r.name not in disabled),
                    key=lambda r: -r.priority)
    st: dict = {"rules": {r.name: {"hit": 0} for r in active},
                "groups": 0, "fused_nodes": 0}
    fused: dict = {}
    for n in g.nodes:
        if n in ctx.covered or n.kind == "input":
            continue
        for r in active:
            m = r.match(n, ctx)
            if m is None:
                continue
            if not r.profitable(m, ctx):
                ctx.reject(r.name, "unprofitable")
                continue
            fused[m.root] = r.build(m, ctx)
            ctx.covered |= m.members
            st["rules"][r.name]["hit"] += 1
            break
    for name, reasons in ctx.rejects.items():
        if name in st["rules"]:
            st["rules"][name].update(reasons)
    st["groups"] = len(fused)
    st["fused_nodes"] = len(ctx.covered)
    _STATS.append(st)
    return fused
