"""Thin CUDA Driver API wrapper (cuda-python bindings).

Covers exactly what the compiler/runtime need: init, primary
context, mem alloc/free, HtoD/DtoH, module load from cubin, kernel launch,
stream synchronize. Every call checks its CUresult.
"""

from __future__ import annotations

import ctypes
from typing import Sequence

from cuda.bindings import driver

CU = driver  # alias for type names


class CudaError(RuntimeError):
    pass


def check(err, what: str = ""):
    """Unwrap a (result, ...) tuple and raise on non-success."""
    if isinstance(err, tuple):
        result = err[0]
        rest = err[1:]
    else:
        result, rest = err, ()
    if result != CU.CUresult.CUDA_SUCCESS:
        _, msg = CU.cuGetErrorString(result)
        raise CudaError(f"{what or 'CUDA call'} failed: {result} ({msg})")
    return rest[0] if len(rest) == 1 else rest


_initialized = False


def init() -> None:
    global _initialized
    if not _initialized:
        check(CU.cuInit(0), "cuInit")
        _initialized = True


# ---------------------------------------------------------------------------
# CUDA graph capture state (opt-in; see runtime/graph.py)
#
# While a capture is open, every stream-ordered call (kernel launch,
# memset) is rerouted from the legacy stream to the capture stream so it
# is recorded into the graph; host-side/synchronizing calls (alloc, free,
# memcpy, synchronize) are illegal and trip the guard with a clear error
# instead of a cryptic driver capture-invalidation.
# ---------------------------------------------------------------------------
_capture_stream: "int | None" = None


class CaptureError(RuntimeError):
    pass


def capture_active() -> bool:
    return _capture_stream is not None


def _guard_capture(what: str) -> None:
    if _capture_stream is not None:
        raise CaptureError(
            f"{what} is illegal during CUDA graph capture (pool miss or "
            f"host sync inside the captured region — warm up first)")


class GraphExec:
    """An instantiated CUDA graph: replay with ``launch(stream)``."""

    def __init__(self, device: "Device", handle):
        self.device = device
        self.handle = handle

    def launch(self, stream: int = 0) -> None:
        self.device.set_current()
        check(CU.cuGraphLaunch(self.handle, CU.CUstream(stream)),
              "cuGraphLaunch")


def begin_capture() -> None:
    """Open stream capture on a fresh non-blocking stream; until
    ``end_capture`` every launch/memset is recorded, not executed."""
    global _capture_stream
    if _capture_stream is not None:
        raise CaptureError("nested CUDA graph capture")
    dev = get_default_device()
    dev.set_current()
    stream = int(check(CU.cuStreamCreate(
        CU.CUstream_flags.CU_STREAM_NON_BLOCKING), "cuStreamCreate"))
    check(CU.cuStreamBeginCapture(
        CU.CUstream(stream),
        CU.CUstreamCaptureMode.CU_STREAM_CAPTURE_MODE_THREAD_LOCAL),
        "cuStreamBeginCapture")
    _capture_stream = stream


def end_capture() -> GraphExec:
    """Close the capture, instantiate an executable graph, destroy the
    recording stream, and pre-upload the graph to the device."""
    global _capture_stream
    stream = _capture_stream
    if stream is None:
        raise CaptureError("end_capture without begin_capture")
    _capture_stream = None
    dev = get_default_device()
    try:
        graph = check(CU.cuStreamEndCapture(CU.CUstream(stream)),
                      "cuStreamEndCapture")
        gexec = check(CU.cuGraphInstantiate(graph, 0), "cuGraphInstantiate")
        CU.cuGraphDestroy(graph)
        check(CU.cuGraphUpload(gexec, CU.CUstream(0)), "cuGraphUpload")
    finally:
        CU.cuStreamDestroy(CU.CUstream(stream))
    return GraphExec(dev, gexec)


def get_default_device() -> "Device":
    if _current_device is None:
        raise CudaError("no current CUDA device yet")
    return _current_device


# Launch fast path: this process is single-context, so once a
# device has been made current every later cuCtxSetCurrent is a no-op
# round-trip through the driver bindings. Track it and skip.
_current_device: "Device | None" = None

# Current launch stream, written by
# runtime.streams' scope context managers and read inline by the launch
# choke point below (one global load per launch). Process-global, not
# thread-local: the whole eager runtime (allocator, tape, compile caches)
# is single-threaded, so scopes are entered from the launching thread
# only. 0 = legacy default stream.
_current_launch_stream = 0


def _resolve_stream(stream: "int | None") -> int:
    return _current_launch_stream if stream is None else stream


def _ensure_current(dev: "Device") -> None:
    global _current_device
    if _current_device is not dev:
        dev.set_current()


class Device:
    """A GPU device holding its primary context (set current on operations)."""

    def __init__(self, ordinal: int = 0):
        init()
        self.ordinal = ordinal
        self.handle = check(CU.cuDeviceGet(ordinal), "cuDeviceGet")
        self.ctx = check(CU.cuDevicePrimaryCtxRetain(self.handle),
                         "cuDevicePrimaryCtxRetain")
        self.set_current()

    def set_current(self) -> None:
        global _current_device
        check(CU.cuCtxSetCurrent(self.ctx), "cuCtxSetCurrent")
        _current_device = self

    def alloc(self, nbytes: int) -> int:
        _guard_capture("cuMemAlloc")
        self.set_current()
        return int(check(CU.cuMemAlloc(nbytes), f"cuMemAlloc({nbytes})"))

    def free(self, ptr: int) -> None:
        _guard_capture("cuMemFree")
        self.set_current()
        check(CU.cuMemFree(ptr), "cuMemFree")

    def memcpy_h2d(self, dst: int, src, nbytes: int) -> None:
        """src: host address (int) or object exposing .ctypes.data / buffer."""
        _guard_capture("cuMemcpyHtoD")
        self.set_current()
        check(CU.cuMemcpyHtoD(dst, _host_addr(src), nbytes), "cuMemcpyHtoD")

    def memcpy_d2h(self, dst, src: int, nbytes: int) -> None:
        _guard_capture("cuMemcpyDtoH")
        self.set_current()
        check(CU.cuMemcpyDtoH(_host_addr(dst), src, nbytes), "cuMemcpyDtoH")

    def load_module(self, cubin: bytes) -> "Module":
        self.set_current()
        return Module(self, cubin)

    def synchronize(self) -> None:
        _guard_capture("cuStreamSynchronize")
        self.set_current()
        check(CU.cuStreamSynchronize(0), "cuStreamSynchronize")
        # also join side streams (MT_STREAM_OVERLAP): syncing only stream 0
        # would let scope work keep running past tl.synchronize(); the
        # driver bindings in this env expose cuStreamSynchronize but not
        # cuDeviceSynchronize
        from . import streams as _streams
        pool = _streams._POOL
        if pool is not None and pool._side is not None:
            check(CU.cuStreamSynchronize(pool._side),
                  "cuStreamSynchronize(side)")

    def memset32(self, ptr: int, value: int, count: int,
                 stream: "int | None" = None) -> None:
        """Async fill of ``count`` 32-bit words (used for L2 flushing)."""
        stream = _resolve_stream(stream)
        if _capture_stream is not None:
            stream = _capture_stream
        self.set_current()
        check(
            CU.cuMemsetD32Async(ptr, value, count, CU.CUstream(stream)),
            "cuMemsetD32Async",
        )


class Event:
    """CUDA event for stream-ordered timing (cuEventElapsedTime, ms)."""

    def __init__(self, device: Device):
        device.set_current()
        self.handle = check(
            CU.cuEventCreate(CU.CUevent_flags.CU_EVENT_DEFAULT), "cuEventCreate"
        )

    def record(self, stream: int = 0) -> None:
        check(CU.cuEventRecord(self.handle, CU.CUstream(stream)), "cuEventRecord")

    def wait(self, stream: int = 0) -> None:
        """Order ``stream``'s subsequently submitted work after this event
        (cuStreamWaitEvent)."""
        check(CU.cuStreamWaitEvent(CU.CUstream(stream), self.handle, 0),
              "cuStreamWaitEvent")

    def query(self) -> bool:
        """Non-blocking completion test (cuEventQuery): True once every
        operation preceding this event's record has finished."""
        err = CU.cuEventQuery(self.handle)
        result = err[0] if isinstance(err, tuple) else err
        if result == CU.CUresult.CUDA_SUCCESS:
            return True
        if result == CU.CUresult.CUDA_ERROR_NOT_READY:
            return False
        check((result,), "cuEventQuery")

    @staticmethod
    def elapsed_ms(start: "Event", end: "Event") -> float:
        return float(check(CU.cuEventElapsedTime(start.handle, end.handle),
                           "cuEventElapsedTime"))


def _host_addr(obj) -> int:
    if isinstance(obj, int):
        return obj
    if hasattr(obj, "ctypes") and hasattr(obj.ctypes, "data"):
        return obj.ctypes.data
    return ctypes.addressof(obj)


class Module:
    def __init__(self, device: Device, cubin: bytes):
        self.device = device
        self.handle = check(CU.cuModuleLoadData(cubin), "cuModuleLoadData")

    def function(self, name: str) -> "Kernel":
        fn = check(CU.cuModuleGetFunction(self.handle, name.encode()),
                   f"cuModuleGetFunction({name})")
        return Kernel(self, fn, name)


class Kernel:
    def __init__(self, module: Module, handle, name: str):
        self.module = module
        self.handle = handle
        self.name = name
        self._err_what = f"cuLaunchKernel({name})"
        self._cu_launch = CU.cuLaunchKernel
        self._streams = {}  # int stream -> CUstream object (bind once)

    def set_max_dynamic_smem(self, nbytes: int) -> None:
        """Opt the function into >48KB dynamic shared memory
        (CU_FUNC_ATTRIBUTE_MAX_DYNAMIC_SHARED_SIZE_BYTES); call once before
        launching with ``shared_mem`` above the 48KB static default."""
        self.module.device.set_current()
        check(CU.cuFuncSetAttribute(
            self.handle,
            CU.CUfunction_attribute.CU_FUNC_ATTRIBUTE_MAX_DYNAMIC_SHARED_SIZE_BYTES,
            nbytes), f"cuFuncSetAttribute({self.name}, {nbytes})")

    def launch(
        self,
        grid: tuple[int, int, int],
        block: tuple[int, int, int],
        params: Sequence[ctypes._SimpleCData],
        shared_mem: int = 0,
        stream: "int | None" = None,
    ) -> None:
        """Launch with params given as ctypes scalar instances (kept alive
        for the duration of the call)."""
        # cuLaunchKernel wants an array of pointers, one per kernel parameter.
        ptrs = (ctypes.c_void_p * len(params))(
            *[ctypes.addressof(p) for p in params]
        )
        self.launch_prebuilt(grid, block, ptrs, shared_mem, stream)

    def launch_prebuilt(
        self,
        grid: tuple[int, int, int],
        block: tuple[int, int, int],
        ptrs,
        shared_mem: int = 0,
        stream: "int | None" = None,
    ) -> None:
        """Launch with a pre-marshalled ``c_void_p`` array of parameter
        pointers (the launch fast path; every launch funnels here).
        ``stream=None`` launches on the thread-local current stream
        (runtime.streams; 0 when no scope is active)."""
        _ensure_current(self.module.device)
        if stream is None:
            stream = _current_launch_stream  # inline: hot path
        cs = _capture_stream
        if cs is not None:
            stream = cs
        st = self._streams.get(stream)
        if st is None:
            st = self._streams.setdefault(stream, CU.CUstream(stream))
        err = self._cu_launch(
            self.handle,
            grid[0], grid[1], grid[2],
            block[0], block[1], block[2],
            shared_mem, st,
            ctypes.addressof(ptrs), 0,
        )
        result = err[0] if isinstance(err, tuple) else err
        if result != CU.CUresult.CUDA_SUCCESS:
            check((result,), self._err_what)


def memref1d_params(ptr: int, n: int) -> list:
    """Kernel parameters for one lowered ``memref<?xf32>`` argument:
    (allocated_ptr, aligned_ptr, offset, size, stride)."""
    return [
        ctypes.c_uint64(ptr),
        ctypes.c_uint64(ptr),
        ctypes.c_int64(0),
        ctypes.c_int64(n),
        ctypes.c_int64(1),
    ]
