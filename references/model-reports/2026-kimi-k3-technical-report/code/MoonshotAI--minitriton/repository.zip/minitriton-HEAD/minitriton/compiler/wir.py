"""W-IR: warp-level IR facade.

A thin typed layer on top of the MLIR Builder that makes sub-CTA structure
explicit so GENERIC passes (compiler/passes.py) can recover performance from
naive phase-structured programs:

- ``Idx``    i32 index values carry an affine annotation (tid / loop iv with
             const div/mod); anything not provably affine is opaque and no
             pass will touch the surrounding loop (conservative by design).
- ``Shmem``  named workgroup scratch (builder._scratch_smem); every access
             records its element-offset form on the emitted op as a
             ``wir.off`` attribute, so passes can enumerate exact per-thread
             offset sets instead of re-running alias analysis.
- ``par_loop(n, "warp")``  side-effect-only scf.for with static trip
             count and no carried values; P1 proves legality before
             distributing it over warps (other ``wir.map`` values are
             left sequential).

The naive program contains NO synchronization (barriers / warp syncs):
pass P2 derives and inserts the minimal sync set from the same exact per-
thread offset evaluation. Programs stay correct if every pass bails (the
scf.for then runs redundantly across warps, computing identical values at
identical addresses).
"""

from __future__ import annotations

import json
from contextlib import contextmanager

from mlir import ir
from mlir.dialects import arith, memref, vector

from ..frontend import types as tl

# ---------------------------------------------------------------------------
# affine annotation AST + serialization
# ---------------------------------------------------------------------------
# forms are nested tuples: ("c", v) | ("tid",) | ("iv", lid)
#                        | ("add"|"mul", a, b) | ("div"|"mod", a, k:int)
#                        | ("and", a, k:int) | ("xor", a, b)
# The bitwise forms exist for smem XOR swizzles: chunk ^ (row & mask) is
# not affine, but it is exactly evaluable — and the pass machinery only
# needs exact per-thread offset sets (eval_form), never affine algebra.

def _fold(op, a, b):
    if a[0] == "c" and b[0] == "c":
        if op == "add":
            return ("c", a[1] + b[1])
        if op == "mul":
            return ("c", a[1] * b[1])
        if op == "xor":
            return ("c", a[1] ^ b[1])
    return None


def form_const(v):
    return ("c", int(v))


def form_add(a, b):
    if a is None or b is None:
        return None
    if a == ("c", 0):
        return b
    if b == ("c", 0):
        return a
    return _fold("add", a, b) or ("add", a, b)


def form_mul(a, b):
    if a is None or b is None:
        return None
    if a == ("c", 0) or b == ("c", 0):
        return ("c", 0)
    if a == ("c", 1):
        return b
    if b == ("c", 1):
        return a
    return _fold("mul", a, b) or ("mul", a, b)


def form_div(a, k):
    if a is None or k <= 0:
        return None
    if a[0] == "c":
        return ("c", a[1] // k) if a[1] >= 0 else None
    if a[0] == "mul" and a[1][0] == "c" and a[1][1] % k == 0:
        return form_mul(("c", a[1][1] // k), a[2])
    if a[0] == "mul" and a[2][0] == "c" and a[2][1] % k == 0:
        return form_mul(a[1], ("c", a[2][1] // k))
    return ("div", a, int(k))


def form_mod(a, k):
    if a is None or k <= 0:
        return None
    if a[0] == "c":
        return ("c", a[1] % k) if a[1] >= 0 else None
    return ("mod", a, int(k))


def form_and(a, k):
    """Bitwise and with a constant (swizzle masks)."""
    if a is None or k < 0:
        return None
    if a[0] == "c":
        return ("c", a[1] & k)
    return ("and", a, int(k))


def form_xor(a, b):
    """Bitwise xor (swizzled chunk permutation); constants fold."""
    if a is None or b is None:
        return None
    if a == ("c", 0):
        return b
    if b == ("c", 0):
        return a
    return _fold("xor", a, b) or ("xor", a, b)


def eval_form(form, tid, iv=0):
    """Exact evaluation; all indices here are non-negative (python // %)."""
    tag = form[0]
    if tag == "c":
        return form[1]
    if tag == "tid":
        return tid
    if tag == "iv":
        return iv
    if tag == "add":
        return eval_form(form[1], tid, iv) + eval_form(form[2], tid, iv)
    if tag == "mul":
        return eval_form(form[1], tid, iv) * eval_form(form[2], tid, iv)
    if tag == "div":
        return eval_form(form[1], tid, iv) // form[2]
    if tag == "and":
        return eval_form(form[1], tid, iv) & form[2]
    if tag == "xor":
        return eval_form(form[1], tid, iv) ^ eval_form(form[2], tid, iv)
    return eval_form(form[1], tid, iv) % form[2]


def parse_form(s):
    """JSON attribute text -> form tuple (or None for opaque)."""
    try:
        raw = json.loads(s)
    except ValueError:
        return None

    def build(node):
        if node is None:
            return None
        tag = node[0]
        if tag in ("c", "iv"):
            return (tag, node[1])
        if tag == "tid":
            return ("tid",)
        if tag in ("add", "mul", "xor"):
            a, b = build(node[1]), build(node[2])
            return None if a is None or b is None else (tag, a, b)
        if tag in ("div", "mod", "and"):
            a = build(node[1])
            return None if a is None else (tag, a, node[2])
        return None

    return build(raw)


def dump_form(f):
    return json.dumps(f) if f is not None else "null"


def uses_iv(form, lid):
    if form is None:
        return False
    if form[0] == "iv":
        return form[1] == lid
    return any(isinstance(x, tuple) and uses_iv(x, lid) for x in form[1:])


def subst_iv(form, lid, repl):
    """Return form with ("iv", lid) replaced by the form repl."""
    if form is None:
        return None
    if form[0] == "iv":
        return repl if form[1] == lid else form
    tag = form[0]
    if tag in ("c", "tid"):
        return form
    if tag in ("add", "mul", "xor"):
        return (tag, subst_iv(form[1], lid, repl), subst_iv(form[2], lid, repl))
    return (tag, subst_iv(form[1], lid, repl), form[2])  # div/mod/and: k untouched


# ---------------------------------------------------------------------------
# typed values
# ---------------------------------------------------------------------------

class Idx:
    """i32 scalar with an affine annotation (form None == opaque)."""

    __slots__ = ("val", "form")

    def __init__(self, val, form):
        self.val = val
        self.form = form


class Shmem:
    """Named workgroup scratch buffer; addresses in f32 elements."""

    __slots__ = ("role", "memref", "nelems")

    def __init__(self, role, memref, nelems):
        self.role = role
        self.memref = memref
        self.nelems = nelems


# ---------------------------------------------------------------------------
# facade
# ---------------------------------------------------------------------------

class WIR:
    """Bound to a Builder; emits naive warp-level programs with annotations."""

    def __init__(self, b):
        self.b = b
        self._lid = 0

    # -- scalars -------------------------------------------------------------

    def idx(self, v) -> Idx:
        """int | Idx -> Idx (materialized i32 value + form)."""
        if isinstance(v, Idx):
            return v
        return Idx(self.b.c_i32(v), form_const(v))

    def tid(self) -> Idx:
        return Idx(self.b.tid(), ("tid",))

    def _ibin(self, a, b, arith_fn, form_fn) -> Idx:
        a, b = self.idx(a), self.idx(b)
        return Idx(arith_fn(a.val, b.val), form_fn(a.form, b.form))

    def add(self, a, b) -> Idx:
        return self._ibin(a, b, arith.addi, form_add)

    def mul(self, a, b) -> Idx:
        return self._ibin(a, b, arith.muli, form_mul)

    def sub(self, a, b) -> Idx:
        a, b = self.idx(a), self.idx(b)
        return Idx(arith.subi(a.val, b.val),
                   form_add(a.form, form_mul(("c", -1), b.form)))

    def div(self, a, k: int) -> Idx:
        a = self.idx(a)
        return Idx(arith.divsi(a.val, self.b.c_i32(k)), form_div(a.form, k))

    def mod(self, a, k: int) -> Idx:
        a = self.idx(a)
        return Idx(arith.remsi(a.val, self.b.c_i32(k)), form_mod(a.form, k))

    def f32(self, v: float) -> ir.Value:
        return self.b.const(tl.float32, v)

    # -- shared memory ---------------------------------------------------------

    def shmem(self, role: str, nelems: int) -> Shmem:
        m = self.b._scratch_smem(role, nelems, tl.float32)
        # the dependence-class role is the buffer's global symbol
        # ("smem_<role>") — the same name builder-side annotations use,
        # so WIR accesses and builder accesses share one role space
        return Shmem(self.b._wir_smem_role(m), m, nelems)

    def _annotate(self, op, sh: Shmem, form, vl: int):
        at = op.operation.attributes
        at["wir.sh"] = ir.StringAttr.get(sh.role)
        at["wir.off"] = ir.StringAttr.get(dump_form(form))
        at["wir.vl"] = ir.IntegerAttr.get(ir.IntegerType.get_signless(64), vl)

    def shload(self, sh: Shmem, offset) -> ir.Value:
        offset = self.idx(offset)
        op = memref.LoadOp(sh.memref, [self.b.to_index(offset.val)])
        self._annotate(op, sh, offset.form, 1)
        return op.result

    def shstore(self, sh: Shmem, offset, v: ir.Value):
        offset = self.idx(offset)
        op = memref.StoreOp(v, sh.memref, [self.b.to_index(offset.val)])
        self._annotate(op, sh, offset.form, 1)

    def shload_vec(self, sh: Shmem, offset, vty):
        offset = self.idx(offset)
        op = vector.LoadOp(vty, sh.memref, [self.b.to_index(offset.val)])
        self._annotate(op, sh, offset.form, vty.shape[0])
        return op.result

    def shstore_vec(self, sh: Shmem, offset, v):
        offset = self.idx(offset)
        op = vector.StoreOp(v, sh.memref, [self.b.to_index(offset.val)])
        self._annotate(op, sh, offset.form,
                       ir.VectorType(v.type).shape[0])

    # -- control flow ----------------------------------------------------------

    @contextmanager
    def par_loop(self, n: int, map: str = "warp"):
        """Annotated side-effect-only loop; `map` is a scheduling hint."""
        lid = self._lid
        self._lid += 1
        for_op, block = self.b._for_op(0, n, 1, [])
        at = for_op.operation.attributes
        at["wir.map"] = ir.StringAttr.get(map)
        at["wir.lid"] = ir.IntegerAttr.get(ir.IntegerType.get_signless(64),
                                           lid)
        at["wir.nw"] = ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), self.b.num_threads // 32)
        with self.b._block_ip(block):
            yield Idx(self.b._iv_i32(block), ("iv", lid))
            self.b._yield([])
