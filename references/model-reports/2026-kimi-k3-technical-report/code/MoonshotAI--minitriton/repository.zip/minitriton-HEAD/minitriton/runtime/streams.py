"""Stream-scope infrastructure for cross-kernel overlap.

Scope-granular event model — no global async runtime, no dependency
analysis:

- ``stream(s)`` context manager. Enter: record E0 on the current stream,
  ``s`` waits E0 (everything already launched on the current stream — the
  producers — is ordered before the scope body). Exit: record E1 on ``s``.
  With the default ``join=True`` the previous stream waits E1 right away
  (anything launched after the scope observes the scope's work; host
  readbacks issued after the scope are covered too — the join is enqueued
  on the legacy stream and the blocking DtoH copy honors legacy-stream
  ordering. Reading scope-produced tensors from INSIDE the scope is
  outside the contract). The body's read/write set is NOT tracked per
  buffer; the contract is that every producer was already launched on
  the current stream before entry (single-stream program order guarantees
  it).
- ``stream(s, join=False)`` defers the join: E1 is parked in the pool
  (one pending entry per stream; a later scope on the same stream
  supersedes its event — FIFO makes the newer event strictly stronger —
  and carries the entry's keepalive set over) and the previous stream
  waits it at the next ``join_pending()``. Contract:
  (a) every tensor the body launched work on stays alive until the join
  (``keepalive(*ts)``); (b) nothing consumes a body output on another
  stream before the join — the autograd tape enforces both
  (``engine.backward`` joins at the end and before accumulating a
  side-produced grad); (c) allocator reuse across streams stays guarded
  by the release-time events in ``runtime/allocator.py``.
  Bounded memory: keepalives are released as soon as their scope's side
  work has actually completed (the next fork reaps fired events via
  cuEventQuery), and if the parked keepalive bytes ever reach
  ``MT_STREAM_OVERLAP_KEEPALIVE_MAX`` (default 1 GiB) the pool joins
  immediately instead of growing further — the overlap window shortens,
  correctness never depends on the budget.
- ``StreamPool``: lazily created non-default streams (ONE side stream
  covers the representative need — Linear wgrad/dgrad overlap) plus a
  small event pool so scopes don't pay cuEventCreate per use.
- ``current_stream()``: the launch stream the scope managers set (0 =
  legacy default). The single launch choke point
  (``cuda_driver.launch_prebuilt``) reads it inline whenever a launch
  does not pass an explicit stream; single-stream code never leaves 0 and
  never creates an event. Process-global rather than thread-local: the
  eager runtime (allocator, tape, compile caches) is single-threaded, so
  scopes are only ever entered from the launching thread — and a plain
  global keeps the per-launch read at one global load.

The allocator's cross-stream correctness half lives in
``runtime/allocator.py`` (``_PooledBuffer.home_stream`` + a release-time
event that a different-stream reuse waits on).

Overlap idiom (why ``placement`` exists): a strict reading of the scope
API — side branch inside ``with stream(side)``, main branch after the
block — serializes, because the exit join makes all LATER main work wait
E1. Real concurrency needs both branches queued between fork and join:

    with stream(pool.side()):            # fork: side waits main's tail
        dw = matmul(g2.t(), x2)          #   side branch
        with placement(0):               #   main branch, no events:
            da = matmul(g2, w)           #   queued BEFORE the exit join
    # exit: E1(side); main waits E1 — da is already queued, unaffected

``placement`` is correct only when the placed work is independent of
everything launched on the scope's stream since the fork (the same
contract the scope body relies on). CUDA graph capture: scopes are a
no-op while capturing (the capture reroutes every launch to the capture
stream, which would serialize the body anyway — the guard skips the
scope's events and stream switch entirely so capture semantics stay
identical to the non-overlap path).
"""

from __future__ import annotations

import os
from contextlib import contextmanager

from . import cuda_driver as _drv

# parked-keepalive byte cap for join=False scopes (module docstring);
# join immediately past it instead of letting the deferred window pin an
# unbounded working set (the GPT-training keepalive set reached ~2.75G
# without a cap — fatal once a graph capture pins the footprint)
_KEEPALIVE_BUDGET = int(
    os.environ.get("MT_STREAM_OVERLAP_KEEPALIVE_MAX", str(1 << 30)))


def current_stream() -> int:
    """The current launch stream (0 = legacy default stream)."""
    return _drv._current_launch_stream


class StreamPool:
    """Lazily created side stream(s) + event pool (see module docstring)."""

    def __init__(self):
        self._side: "int | None" = None
        self._free_events: "list[_drv.Event]" = []
        # deferred joins: stream handle -> [exit event, keepalive refs,
        # keepalive nbytes]. One entry per stream: a later scope on the
        # same stream supersedes the event (strictly stronger, FIFO) and
        # inherits the refs.
        self._pending: "dict[int, list]" = {}
        # diagnostic counter (tests assert single-stream code keeps it 0)
        self.events_created = 0

    def side(self) -> int:
        """Handle of the one side stream (non-0), created on first use."""
        if self._side is None:
            dev = _drv.get_default_device()
            dev.set_current()
            self._side = int(_drv.check(_drv.CU.cuStreamCreate(
                _drv.CU.CUstream_flags.CU_STREAM_NON_BLOCKING),
                "cuStreamCreate"))
        return self._side

    def record(self, stream: int) -> "_drv.Event":
        """Record a pooled event on ``stream``; caller owns it until
        ``recycle``."""
        if self._free_events:
            ev = self._free_events.pop()
        else:
            ev = _drv.Event(_drv.get_default_device())
            self.events_created += 1
        ev.record(stream)
        return ev

    def wait(self, stream: int, ev: "_drv.Event") -> None:
        """Order ``stream``'s subsequently submitted work after ``ev``."""
        ev.wait(stream)

    def recycle(self, ev: "_drv.Event") -> None:
        """Return an event to the pool. Safe right after ``wait``: the
        stream captured a snapshot of the event's state at wait time."""
        self._free_events.append(ev)


_POOL: "StreamPool | None" = None


def default_pool() -> StreamPool:
    global _POOL
    if _POOL is None:
        _POOL = StreamPool()
    return _POOL


@contextmanager
def stream(s: int, join: bool = True):
    """Scope-granular stream scope with the documented E0/E1 event model
    (module docstring). Nesting on the SAME stream is free (no events);
    so is entering while a CUDA graph capture is active (module
    docstring). ``join=False`` parks the exit event in the pool instead
    of making the previous stream wait it at once."""
    prev = current_stream()
    if s == prev or _drv.capture_active():
        yield
        return
    pool = default_pool()
    _reap(pool)
    e0 = pool.record(prev)
    pool.wait(s, e0)
    pool.recycle(e0)
    _drv._current_launch_stream = s
    try:
        yield
    finally:
        _drv._current_launch_stream = prev
        e1 = pool.record(s)
        if join:
            pool.wait(prev, e1)
            pool.recycle(e1)
        else:
            entry = pool._pending.get(s)
            if entry is not None:
                # never waited on; E1 (recorded later on the same FIFO
                # stream) is strictly stronger and covers the old refs
                pool.recycle(entry[0])
                entry[0] = e1
                # superseding re-parks the scope: move the entry to the
                # newest position (pop + re-insert keeps the plain dict's
                # insertion order) so keepalive()'s "latest scope" lookup
                # (reversed insertion order) attaches to THIS scope, not
                # to an unrelated stream parked in between
                pool._pending[s] = pool._pending.pop(s)
            else:
                pool._pending[s] = [e1, [], 0]


def _reap(pool: StreamPool) -> None:
    """Release pending entries whose side work has already completed
    (non-blocking cuEventQuery); their keepalive sets drop out here."""
    done = [s for s, entry in pool._pending.items() if entry[0].query()]
    for s in done:
        pool.recycle(pool._pending[s][0])
        del pool._pending[s]


def pending() -> bool:
    """True while a join=False scope's exit event is still un-joined
    (completed-but-unreaped entries count — joins are conservative)."""
    pool = default_pool()
    return bool(pool._pending)


def keepalive(*objs) -> None:
    """Hold references to the latest join=False scope's input tensors
    until its side work completes (reaped at the next fork) or the next
    ``join_pending`` — whichever comes first. Past the byte budget the
    pool joins immediately (module docstring)."""
    pool = default_pool()
    if not pool._pending:
        return  # no open deferred scope (e.g. capture-guarded no-op)
    entry = next(reversed(pool._pending.values()))
    entry[1].extend(objs)
    nb = 0
    for t in objs:
        nb += int(getattr(getattr(t, "_storage", None), "nbytes", 0)
                  or 0)
    entry[2] += nb
    if sum(e[2] for e in pool._pending.values()) >= _KEEPALIVE_BUDGET:
        join_pending()


def join_pending() -> None:
    """Make the current stream wait every parked scope-exit event, then
    release the keepalive sets. No-op (and cheap) when nothing is
    pending; a stream FIFO join also covers everything an earlier join
    covered."""
    pool = default_pool()
    if not pool._pending:
        return
    cur = current_stream()
    for entry in pool._pending.values():
        pool.wait(cur, entry[0])
        pool.recycle(entry[0])
    pool._pending.clear()


@contextmanager
def placement(s: int):
    """TLS-only stream switch: NO events. Expert escape hatch for the
    fork-join body idiom (module docstring); correct only for work
    independent of everything the enclosing scope launched since its
    fork."""
    prev = current_stream()
    _drv._current_launch_stream = s
    try:
        yield
    finally:
        _drv._current_launch_stream = prev
