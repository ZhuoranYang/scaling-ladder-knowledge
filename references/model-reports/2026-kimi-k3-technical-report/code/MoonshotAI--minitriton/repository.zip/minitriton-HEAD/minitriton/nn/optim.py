"""AdamW optimizer (fused single-kernel update) + grad clipping +
bf16 mixed-precision helpers (GradScaler, BF16AdamW)."""

from __future__ import annotations

import math
import sys

from .. import ops
from .. import precision as _prec
from ..autograd.engine import _no_grad
from ..frontend import types as tl_types
from ..tensor import Tensor, zeros


class AdamW:
    """Decoupled-weight-decay AdamW. State (m, v) lazily allocated per
    parameter; the update is one fused kernel launch per parameter
    (device/cuda adamw_kernel; numpy mirror on CPU)."""

    def __init__(self, params, lr: float = 1e-3, betas=(0.9, 0.999),
                 eps: float = 1e-8, weight_decay: float = 0.01):
        self.params = list(params)
        self.lr = float(lr)
        self.b1, self.b2 = float(betas[0]), float(betas[1])
        self.eps = float(eps)
        self.weight_decay = float(weight_decay)
        self.t = 0
        self._state: dict[int, tuple[Tensor, Tensor]] = {}

    def zero_grad(self):
        for p in self.params:
            p.grad = None

    def step(self):
        self.t += 1
        if _prec.adamw_eps():
            # torch-exact eps placement (the default; the else branch is
            # the MT_ADAMW_FOLDED_EPS=1 opt-in): lr/(1-b1^t) unfolded,
            # denom = sqrt(v)/sqrt(1-b2^t) + eps
            lr_t = self.lr / (1.0 - self.b1 ** self.t)
            s2 = math.sqrt(1.0 - self.b2 ** self.t)
        else:
            lr_t = self.lr * math.sqrt(1.0 - self.b2 ** self.t) / \
                (1.0 - self.b1 ** self.t)
            s2 = 1.0
        wd_lr = self.lr * self.weight_decay
        with _no_grad():
            for p in self.params:
                if p.grad is None:
                    continue
                if not p.is_contiguous():
                    raise RuntimeError("AdamW expects contiguous parameters")
                g = p.grad.contiguous()
                st = self._state.get(id(p))
                if st is None:
                    st = (zeros(p.shape, p.dtype, p.device),
                          zeros(p.shape, p.dtype, p.device))
                    self._state[id(p)] = st
                m, v = st
                ops.adamw_step(p, g, m, v, lr_t, wd_lr, self.b1, self.b2,
                               self.eps, torch_eps=_prec.adamw_eps(), s2=s2)


def clip_grad_norm(params, max_norm: float, eps: float = 1e-6) -> float:
    """Scale all grads so their global L2 norm <= max_norm. Returns the
    (pre-clip) total norm. One host sync for the norm value."""
    params = list(params)  # may be a generator; it is iterated twice
    total = None
    for p in params:
        if p.grad is None:
            continue
        s = ops.sum(ops.mul(p.grad, p.grad))
        total = s if total is None else ops.add(total, s)
    if total is None:
        return 0.0
    norm = float(total) ** 0.5
    clip = max_norm / (norm + eps)
    if clip < 1.0:
        with _no_grad():
            for p in params:
                if p.grad is not None:
                    p.grad = ops.mul(p.grad, clip)
    return norm


# ---------------------------------------------------------------------------
# bf16 mixed-precision training
# ---------------------------------------------------------------------------

# smallest positive normal double — GradScaler.scale floor (see update())
_MIN_SCALE = sys.float_info.min


class GradScaler:
    """Dynamic loss scaling for low-precision (bf16) training — minimal
    ``torch.cuda.amp.GradScaler`` semantics.

    Loss is multiplied by ``scale`` before backward so gradients occupy
    the range of the low-precision dtype; ``unscale_`` divides the grads
    back (in fp32) *before* gradient clipping; ``update(found_inf)``
    halves the scale on a non-finite step and doubles it after
    ``growth_interval`` consecutive finite steps. bf16 shares fp32's
    exponent range, so true overflow is rare — the guard's main job is
    the NaN-check skip. ``init_scale`` 2**15 follows the fp16 convention;
    dividing/multiplying by a power of two is exact, so the
    scale/unscale round trip costs nothing (outside subnormals).

    Typical loop::

        scaler = nn.GradScaler()
        loss = scaler.scale_loss(model(x, y))
        model.zero_grad()
        loss.backward()
        scaler.unscale_(model.parameters())
        total = nn.clip_grad_norm(model.parameters(), 1.0)
        finite = math.isfinite(total)
        if finite:
            opt.step()
        else:
            model.zero_grad()      # purge the stale (non-finite) grads
        scaler.update(not finite)
    """

    def __init__(self, init_scale: float = 2.0 ** 15,
                 growth_interval: int = 2000, backoff_factor: float = 0.5,
                 growth_factor: float = 2.0):
        self.scale = float(init_scale)
        self.growth_interval = int(growth_interval)
        self.backoff_factor = float(backoff_factor)
        self.growth_factor = float(growth_factor)
        self._good = 0  # consecutive finite steps since the last change

    def scale_loss(self, loss: Tensor) -> Tensor:
        return loss * self.scale

    def unscale_(self, params):
        """grad <- grad / scale, computed in fp32 (grads become f32
        tensors). Call once per backward, before clip_grad_norm."""
        inv = 1.0 / self.scale
        with _no_grad():
            for p in params:
                if p.grad is None:
                    continue
                g = p.grad
                if g.dtype != tl_types.float32:
                    g = ops.astype(g, tl_types.float32)
                p.grad = ops.mul(g, inv)

    def update(self, found_inf: bool):
        if found_inf:
            # floor at the smallest normal double: ~1090 consecutive
            # halvings would otherwise underflow scale to 0.0 and crash
            # the next unscale_ with a ZeroDivisionError
            self.scale = max(self.scale * self.backoff_factor, _MIN_SCALE)
            self._good = 0
        else:
            self._good += 1
            if self._good >= self.growth_interval:
                self.scale *= self.growth_factor
                self._good = 0


class BF16AdamW(AdamW):
    """AdamW over bf16 (or other low-precision) parameters via fp32
    master weights: for every parameter the optimizer holds an fp32
    master copy; ``step()`` casts the (unscaled) grad to fp32, runs the
    fused f32 AdamW update on the master (so moments/state are fp32 too),
    and copies the master back into the parameter (cast to its dtype,
    in place — the Parameter object and its storage are preserved).

    Trade-off vs. keeping only fp32 moment state: +4 B/param for the
    master copy, in exchange for not rounding away updates below the
    bf16 resolution (~2**-8 relative) — at lr ~1e-3 on O(0.02) weights
    most early updates are smaller than that. Grads must be unscaled
    (GradScaler) before step(); clip beforehand as usual.

    ``masters`` (optional): {id(param): fp32 tensor} of pre-conversion
    fp32 weight copies. Pass these when converting an fp32-initialized
    model to bf16 (train_gpt._convert_bf16_ returns them): initializing
    the master by rounding it to bf16 at init biases sub-ulp coherent
    updates (they round away on the param instead of accumulating across
    the quantization floor — a measurable early-step convergence hit).
    Params missing from the mapping get their master from the current
    value.
    """

    def __init__(self, params, lr: float = 1e-3, betas=(0.9, 0.999),
                 eps: float = 1e-8, weight_decay: float = 0.01,
                 masters: dict | None = None):
        params = list(params)
        with _no_grad():
            self._master = []
            for p in params:
                m = masters.get(id(p)) if masters else None
                if m is None:
                    # f32 params: astype would alias the param's storage;
                    # mul by 1.0 forces a real copy
                    m = p.detach() * 1.0 if p.dtype == tl_types.float32 \
                        else p.detach().contiguous() \
                        .astype(tl_types.float32)
                self._master.append(m)
        # state (m, v) plus the fused update live on the f32 masters
        self._inner = AdamW(self._master, lr, betas, eps, weight_decay)
        super().__init__(params, lr, betas, eps, weight_decay)

    @property
    def t(self):
        return self._inner.t

    @t.setter
    def t(self, v):
        self._inner.t = v

    def zero_grad(self):
        super().zero_grad()
        for m in self._master:
            m.grad = None

    def step(self):
        with _no_grad():
            for p, m in zip(self.params, self._master):
                if p.grad is None:
                    m.grad = None
                else:
                    g = p.grad
                    m.grad = g if g.dtype == tl_types.float32 else \
                        ops.astype(g, tl_types.float32)
        self._inner.lr = self.lr
        self._inner.step()
        with _no_grad():
            for p, m in zip(self.params, self._master):
                if m.grad is not None:
                    # f32 -> param dtype cast is folded into the copy
                    ops._copy_into_view(p, m)
