"""Eager backends: ``cpu`` (numpy oracle) and ``cuda`` (DSL kernels)."""
