"""Built-in viz render kernels (@tl.kernel DSL).

Sim data is already tensors; rendering is just another kernel. All kernels
write into a persistent (H, W, 3) f32 pixel buffer *in place* (flat
H*W*3 addressing) so several render passes compose on one frame
(e.g. heatmap background + particle overlay). World coordinates x, y are
in [0, 1]; y_up=1 maps y=1 to the top row of the image (sim convention).

- ``_particles_kernel`` — scatter one (2R+1)^2 dot per particle with
  MatOff scatter stores; out-of-bounds particles are clipped.
- ``_heatmap_kernel`` — nearest-neighbor field sampling + 8-stop
  piecewise-linear colormap (stops loaded from a 24-float table, i.e. the
  colormap is data, not codegen).
- ``_mesh_kernel`` — per edge: scatter both endpoint dots and the edge
  midpoint (wireframe-lite; shared endpoints plotted twice, harmless).

NOTE: no ``from __future__ import annotations`` here — kernel params rely
on real ``tl.constexpr`` annotation objects.
"""

import minitriton as tl


@tl.kernel
def fill_kernel(buf_ptr, R, G, B, TOTAL, BLOCK: tl.constexpr):
    """buf = (R, G, B) everywhere (flat H*W*3 f32 buffer, in place)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < TOTAL
    z = tl.zeros((BLOCK,), tl.float32)
    tl.store(buf_ptr + offs * 3, z + R, mask=m)
    tl.store(buf_ptr + offs * 3 + 1, z + G, mask=m)
    tl.store(buf_ptr + offs * 3 + 2, z + B, mask=m)


def launch_fill(buf, r, g, b):
    total = buf.numel() // 3
    fill_kernel[((total + 511) // 512,)](buf._buffer_arg(), r, g, b, total,
                                         BLOCK=512, num_warps=4)


@tl.kernel
def particles_kernel(img_ptr, x_ptr, y_ptr, N, W, H, Wf, Hf,
                     CR, CG, CB,
                     R: tl.constexpr, YUP: tl.constexpr,
                     BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m, other=-1.0)
    y = tl.load(y_ptr + offs, mask=m, other=-1.0)
    if YUP:
        y = 1.0 - y
    px = tl.cast(x * Wf, tl.int32)
    py = tl.cast(y * Hf, tl.int32)
    z = tl.zeros((BLOCK,), tl.float32)
    rr = z + CR
    gg = z + CG
    bb = z + CB
    for dy in range(-R, R + 1):
        for dx in range(-R, R + 1):
            qx = px + dx
            qy = py + dy
            inside = (qx >= 0) & (qx < W) & (qy >= 0) & (qy < H) & m
            addr = qy * (W * 3) + qx * 3
            tl.store(img_ptr + addr, rr, mask=inside)
            tl.store(img_ptr + addr + 1, gg, mask=inside)
            tl.store(img_ptr + addr + 2, bb, mask=inside)


def launch_particles(buf, x, y, N: int, W: int, H: int, color, radius: int,
                     y_up: bool):
    cr, cg, cb = (float(c) for c in color)
    particles_kernel[((N + 255) // 256,)](
        buf._buffer_arg(), x._buffer_arg(), y._buffer_arg(), N, W, H,
        float(W), float(H), cr, cg, cb, R=int(radius), YUP=1 if y_up else 0,
        BLOCK=256, num_warps=4)


@tl.kernel
def heatmap_kernel(img_ptr, f_ptr, stops_ptr, HF, WF, H, W, TOTAL,
                   VMIN, INVDR, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < TOTAL
    idx = tl.cast(offs, tl.int32)  # materialized flat pixel index
    py = idx // W
    px = idx - py * W
    fy = (py * HF) // H
    fx = (px * WF) // W
    v = tl.load(f_ptr + (fy * WF + fx), mask=m, other=1e30)
    z = tl.zeros((BLOCK,), tl.float32)
    t = (v - VMIN) * INVDR
    t = tl.where(t < 0.0, z, t)
    t = tl.where(t > 1.0, z + 1.0, t)
    u = t * 7.0  # 8 stops -> 7 segments
    k = tl.cast(u, tl.int32)
    k = tl.where(k > 6, 6, k)
    f = u - tl.cast(k, tl.float32)
    # colormap stops live in a 24-float table [r0..r7, g0..g7, b0..b7]:
    # channel c: lo = stops[c*8 + k], hi = stops[c*8 + k + 1]
    r0 = tl.load(stops_ptr + k)
    r1 = tl.load(stops_ptr + k + 1)
    g0 = tl.load(stops_ptr + k + 8)
    g1 = tl.load(stops_ptr + k + 9)
    b0 = tl.load(stops_ptr + k + 16)
    b1 = tl.load(stops_ptr + k + 17)
    rr = r0 + (r1 - r0) * f
    gg = g0 + (g1 - g0) * f
    bb = b0 + (b1 - b0) * f
    tl.store(img_ptr + idx * 3, rr, mask=m)
    tl.store(img_ptr + idx * 3 + 1, gg, mask=m)
    tl.store(img_ptr + idx * 3 + 2, bb, mask=m)


def launch_heatmap(buf, field, stops, vmin: float, dr: float, W: int, H: int):
    hf, wf = field.shape
    total = H * W
    heatmap_kernel[((total + 255) // 256,)](
        buf._buffer_arg(), field._buffer_arg(), stops._buffer_arg(),
        hf, wf, H, W, total, float(vmin), 1.0 / float(dr) if dr else 1.0,
        BLOCK=256, num_warps=4)



@tl.kernel
def mesh_kernel(img_ptr, v_ptr, e_ptr, E, W, H, Wf, Hf,
                CVR, CVG, CVB, CER, CEG, CEB,
                YUP: tl.constexpr, BLOCK: tl.constexpr):
    """Per edge: plot both endpoints (vertex color) and the edge midpoint
    (edge color). Masked lanes keep x/y at -1 and are clipped."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < E
    a = tl.load(e_ptr + 2 * offs, mask=m, other=-1)
    b = tl.load(e_ptr + 2 * offs + 1, mask=m, other=-1)
    ax = tl.load(v_ptr + 2 * a, mask=m, other=-1.0)
    ay = tl.load(v_ptr + 2 * a + 1, mask=m, other=-1.0)
    bx = tl.load(v_ptr + 2 * b, mask=m, other=-1.0)
    by = tl.load(v_ptr + 2 * b + 1, mask=m, other=-1.0)
    if YUP:
        ay = 1.0 - ay
        by = 1.0 - by
    mx = (ax + bx) * 0.5
    my = (ay + by) * 0.5
    z = tl.zeros((BLOCK,), tl.float32)
    # endpoints (vertex color), written out for both ends of the edge
    pax = tl.cast(ax * Wf, tl.int32)
    pay = tl.cast(ay * Hf, tl.int32)
    ain = (pax >= 0) & (pax < W) & (pay >= 0) & (pay < H) & m
    aaddr = pay * (W * 3) + pax * 3
    tl.store(img_ptr + aaddr, z + CVR, mask=ain)
    tl.store(img_ptr + aaddr + 1, z + CVG, mask=ain)
    tl.store(img_ptr + aaddr + 2, z + CVB, mask=ain)
    pbx = tl.cast(bx * Wf, tl.int32)
    pby = tl.cast(by * Hf, tl.int32)
    binm = (pbx >= 0) & (pbx < W) & (pby >= 0) & (pby < H) & m
    baddr = pby * (W * 3) + pbx * 3
    tl.store(img_ptr + baddr, z + CVR, mask=binm)
    tl.store(img_ptr + baddr + 1, z + CVG, mask=binm)
    tl.store(img_ptr + baddr + 2, z + CVB, mask=binm)
    # edge midpoint (edge color)
    px = tl.cast(mx * Wf, tl.int32)
    py = tl.cast(my * Hf, tl.int32)
    inside = (px >= 0) & (px < W) & (py >= 0) & (py < H) & m
    addr = py * (W * 3) + px * 3
    tl.store(img_ptr + addr, z + CER, mask=inside)
    tl.store(img_ptr + addr + 1, z + CEG, mask=inside)
    tl.store(img_ptr + addr + 2, z + CEB, mask=inside)


def launch_mesh(buf, verts, edges, E: int, W: int, H: int, vcolor, ecolor,
                y_up: bool):
    cvr, cvg, cvb = (float(c) for c in vcolor)
    cer, ceg, ceb = (float(c) for c in ecolor)
    mesh_kernel[((E + 255) // 256,)](
        buf._buffer_arg(), verts._buffer_arg(), edges._buffer_arg(), E, W, H,
        float(W), float(H), cvr, cvg, cvb, cer, ceg, ceb,
        YUP=1 if y_up else 0, BLOCK=256, num_warps=4)
