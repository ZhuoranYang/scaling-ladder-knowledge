"""Basic layers: Linear / Embedding / LayerNorm / RMSNorm / CrossEntropyLoss."""

from __future__ import annotations

import numpy as np

from .. import ops
from ..tensor import Tensor
from .module import Module, Parameter


class Linear(Module):
    """y = x @ weight.T + bias; weight (out, in) ~ N(0, std)."""

    def __init__(self, in_features: int, out_features: int, bias: bool = True,
                 std: float = 0.02, device: str = "cuda", seed=None):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter.normal((out_features, in_features), std,
                                       device, seed)
        self.bias = Parameter.zeros((out_features,), device) if bias else None

    def forward(self, x: Tensor) -> Tensor:
        from ..autograd import functions as _f
        return _f.linear(x, self.weight, self.bias)

    def reinit_(self, std: float, seed=None):
        """Re-sample the weight in place (GPT-style scaled projections)."""
        rng = np.random.default_rng(seed)
        arr = (rng.standard_normal(self.weight.shape) * std).astype(np.float32)
        self.weight._steal(Tensor(arr, device=self.weight.device))
        self.weight.requires_grad = True
        return self


class Embedding(Module):
    def __init__(self, num_embeddings: int, embedding_dim: int,
                 std: float = 0.02, device: str = "cuda", seed=None):
        super().__init__()
        self.weight = Parameter.normal((num_embeddings, embedding_dim), std,
                                       device, seed)

    def forward(self, idx: Tensor) -> Tensor:
        return ops.embedding(self.weight, idx)


class LayerNorm(Module):
    def __init__(self, dim: int, eps: float = 1e-5, bias: bool = True,
                 device: str = "cuda"):
        super().__init__()
        self.dim = dim
        self.eps = eps
        self.weight = Parameter.ones((dim,), device)
        self.bias = Parameter.zeros((dim,), device) if bias else None

    def forward(self, x: Tensor, out_dtype=None) -> Tensor:
        return ops.layer_norm(x, (self.dim,), self.weight, self.bias,
                              self.eps, out_dtype=out_dtype)


class RMSNorm(Module):
    def __init__(self, dim: int, eps: float = 1e-6, device: str = "cuda"):
        super().__init__()
        self.dim = dim
        self.eps = eps
        self.weight = Parameter.ones((dim,), device)

    def forward(self, x: Tensor) -> Tensor:
        return ops.rms_norm(x, (self.dim,), self.weight, self.eps)


class CrossEntropyLoss(Module):
    """cross_entropy over the last dim; logits (..., C) with int targets."""

    def __init__(self, reduction: str = "mean"):
        super().__init__()
        self.reduction = reduction

    def forward(self, logits: Tensor, target: Tensor) -> Tensor:
        c = logits.shape[-1]
        x = logits.reshape((logits.numel() // c, c))
        t = target.reshape((target.numel(),))
        return ops.cross_entropy(x, t, reduction=self.reduction)
