"""CUDA graph capture/replay of shape-stable kernel sequences (opt-in).

A training step's forward+backward issues the same kernels in the same
order on every step: shapes are fixed, the pooled allocator is
deterministic under a repeated alloc/free sequence, and every device
pointer a kernel reads is therefore stable once the pool is warm.
Capturing that sequence once and replaying it removes the per-launch
Python/tape/driver tax in exchange for one
``cuGraphLaunch``.

Contract for the captured callable (violations raise ``CaptureError`` or
invalidate the capture):

- no H2D/D2H copies, host synchronizations, or pool-miss allocations
  inside — warm the exact code path up first (same shapes, same opts);
- replay-invariance: the same op sequence every call. Host scalars baked
  into kernel parameters (loss scale, clip coefficients, lr) are frozen
  at capture — key the capture on every value that can change and
  re-capture when it does;
- input data must live in persistent device buffers refreshed before
  each replay (the graph reads the captured addresses, not new tensors);
- outputs consumed after replay must be the tensors returned by the
  capture call (their buffers stay alive and are rewritten in place by
  every replay).

Every address allocated during capture is pinned in the pool
(``PooledAllocator.pin_buffers``) so later eager allocations can never
land inside the graph's footprint; ``Graph.teardown()`` releases the
pins and destroys the exec.

This module is the thin runtime primitive; the training-step assembly
(persistent input buffers, grad re-attachment, scaler-keyed
re-capture) lives with the training benchmarks.
"""

from __future__ import annotations

import sys

from . import allocator as _alloc_mod
from . import cuda_driver as _drv
from .cuda_driver import CaptureError  # noqa: F401  (re-export)


class Graph:
    """A captured executable graph plus its pinned pool footprint."""

    def __init__(self, exec_: _drv.GraphExec, out, pinned: list):
        self.exec = exec_
        self.out = out          # whatever the captured callable returned
        self._pinned = pinned

    def launch(self, stream: int = 0) -> None:
        self.exec.launch(stream)

    def teardown(self) -> None:
        if self.exec is not None:
            _drv.check(_drv.CU.cuGraphExecDestroy(self.exec.handle),
                       "cuGraphExecDestroy")
            self.exec = None
        if self._pinned:
            _alloc_mod._ALLOCATOR.unpin_buffers(self._pinned)
            self._pinned = []

    def __del__(self):
        # a dropped graph must not pin its pool footprint forever (the
        # training bench sweeps several graph configs in one process —
        # without this each config leaked its whole pinned working set).
        # `sys` is imported at module level: a function-level import can
        # itself raise ImportError once the interpreter's import
        # machinery is torn down (noisy "Exception ignored" at exit)
        if sys.is_finalizing():
            return
        try:
            self.teardown()
        except Exception:
            pass


def capture(fn) -> Graph:
    """Run ``fn()`` under stream capture and return the ``Graph``.

    The callable runs exactly once (its launches are recorded, not
    executed); afterwards ``graph.launch()`` replays the whole recorded
    sequence. All pool addresses allocated during the run are pinned.
    """
    allocs: list = []
    pool = _alloc_mod._ALLOCATOR
    prev_record = pool._record
    pool._record = allocs
    began = False
    try:
        _drv.begin_capture()
        began = True
        out = fn()
        gexec = _drv.end_capture()
    except BaseException:
        # never leave the capture flag set behind an abort — but only
        # unwind a capture THIS call opened: a nested capture()'s
        # begin_capture raises with the OUTER capture still active, and
        # ending that one would destroy the outer graph
        if began and _drv.capture_active():
            try:
                _drv.end_capture()
            except Exception:
                pass
        raise
    finally:
        # restore the previous recording list on EVERY exit path: a
        # nested capture that failed before begin must not strand its
        # dead list here — the outer's later allocations would then
        # escape pin_buffers and replay would clobber their reusers
        pool._record = prev_record
    return Graph(gexec, out, pool.pin_buffers(allocs))


def capture_active() -> bool:
    return _drv.capture_active()
