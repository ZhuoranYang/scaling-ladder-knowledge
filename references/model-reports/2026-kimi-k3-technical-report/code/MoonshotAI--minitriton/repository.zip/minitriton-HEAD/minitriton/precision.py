"""Opt-in high-precision modes (all default OFF; the fast path is
unchanged unless an env var is set). Read once at import time.

Compile levers are import-time constants: the builder and the
compile-cache fingerprint both consume import-time snapshots, so
REASSIGNING a lever global at runtime (``precision._ROW_FP64 = True``)
is unsupported and uniformly inert — flip the env var and restart the
process instead. (The one exception is the runtime-only
``MT_STREAM_OVERLAP`` lever below, which is read live by design.)

Levers:

- ``MT_MATMUL_FP64=1``   matmul/bmm accumulate in fp64 quality via a
  double-single (Dekker TwoProd + TwoSum) compensated kernel — error
  ~K*eps^2 (~1e-11 rel), i.e. indistinguishable from an fp64
  accumulator at fp32 output precision. Slow (GEMV-per-row); meant for
  numerical comparisons, not training throughput.
- ``MT_EMBED_FP64=1``    embedding weight grad via a deterministic
  per-vocab-row scan with compensated accumulation (replaces the
  atomic scatter-add, whose order is nondeterministic).
- ``MT_ROW_FP64=1``      row-kernel sum reductions (softmax / layer_norm
  / rms_norm / cross_entropy, fwd+bwd, and the two-stage full reduce)
  use TwoSum-compensated accumulation in the builder.
- ``MT_PRECISE_MATH=1``  builder math: exp via a Cody-Waite + minimax
  polynomial (~1 ulp, replaces ex2.approx), sqrt via IEEE sqrt.rn
  (replaces sqrt.approx).
- ``MT_GELU_TANH=1``     gelu via the tanh approximation (fast path).
  DEFAULT is the two-region erf fit (torch's exact-gelu semantics —
  torch's own tanh form is the opt-in `approximate="tanh"`); the erf
  exprs are patched into the elementwise tables, so eager, fusion, and
  the r2v matmul epilogue all share the choice.
- ``MT_GELU_ERF=1``      no-op (erf is the default; kept so existing
  command lines don't break).
- ``MT_ADAMW_FOLDED_EPS=1``  AdamW with the folded-lr_t form
  (effective eps `eps/sqrt(1-b2^t)`). DEFAULT is the torch-exact
  placement: `denom = sqrt(v)/sqrt(1-b2^t) + eps` with `lr/(1-b1^t)`
  unfolded — zero extra ops (same kernel, different host constants).
- ``MT_ADAMW_EPS=1``     no-op (torch eps placement is the
  default).
- ``MT_ATTN_UNFUSED=1``  route causal attention through the unfused
  matmul+softmax composition (which then benefits from the matmul/row
  levers above) instead of the fused flash kernels.
- ``MT_ATTN_BWD_F32=1``  bf16 attention tier: backward through the fused
  f32 flash kernels on f32 upcasts (the pre-mma-bwd route), instead of
  the native bf16 mma backward kernels. Debugging/A-B lever.
- ``MT_FP64_ALL=1``      master switch: enables all of the above EXCEPT
  the opt-out levers (MT_ATTN_BWD_F32 and MT_ADAMW_FOLDED_EPS stay
  off); it also FORCES erf-gelu regardless of MT_GELU_TANH.

- ``MT_FP32_SPLITK=0``  disable fp32 split-K (its deterministic but
  non-cuBLAS-order reduction changes rounding; plain GEMM keeps
  torch-order). Convergence/reproducibility lever. Launch-routing only:
  read live per matmul and picks between two already-compiled kernels,
  so it is NOT part of the compile-cache fingerprint (no cubin changes).

Runtime-only lever (NOT folded into the compile-cache fingerprint — it
changes launch streams, not compiled code):

- ``MT_STREAM_OVERLAP=1``  cross-kernel overlap:
  ``Linear.backward`` runs its wgrad branch on a side stream concurrent
  with the dgrad branch (scope-granular events; shapes below
  ``MT_STREAM_OVERLAP_MIN_MACS`` stay on the default stream). Default OFF.

The compile levers above are folded into the compile-cache fingerprint
(runtime/cache.py), so flipping one never reuses a stale cubin.
"""

from __future__ import annotations

import os


def _on(name: str) -> bool:
    return os.environ.get(name, "") not in ("", "0")


_ALL = _on("MT_FP64_ALL")
_MATMUL_FP64 = _ALL or _on("MT_MATMUL_FP64")
_EMBED_FP64 = _ALL or _on("MT_EMBED_FP64")
_ROW_FP64 = _ALL or _on("MT_ROW_FP64")
_PRECISE_MATH = _ALL or _on("MT_PRECISE_MATH")
# erf-exact gelu is the DEFAULT (torch semantics); MT_GELU_TANH=1 opts
# back into the tanh fast path. MT_FP64_ALL always forces erf.
_GELU_ERF = _ALL or not _on("MT_GELU_TANH")
# torch-exact AdamW eps placement is the DEFAULT (zero cost, torch
# formula); MT_ADAMW_FOLDED_EPS=1 restores the folded-lr_t form.
_ADAMW_EPS = _ALL or not _on("MT_ADAMW_FOLDED_EPS")
_ATTN_UNFUSED = _ALL or _on("MT_ATTN_UNFUSED")
_ATTN_BWD_F32 = _on("MT_ATTN_BWD_F32")  # opt-OUT lever: NOT part of _ALL
# MT_STREAM_OVERLAP is a launch-routing lever (side streams, not compiled
# code): read live per call in stream_overlap() — see its docstring.


def matmul_fp64() -> bool:
    return _MATMUL_FP64


def embed_fp64() -> bool:
    return _EMBED_FP64


def row_fp64() -> bool:
    return _ROW_FP64


def precise_math() -> bool:
    return _PRECISE_MATH


def gelu_erf() -> bool:
    return _GELU_ERF


def adamw_eps() -> bool:
    return _ADAMW_EPS


def attn_unfused() -> bool:
    return _ATTN_UNFUSED


def attn_bwd_f32() -> bool:
    """bf16 attention tier: force the f32-upcast fused backward."""
    return _ATTN_BWD_F32


def stream_overlap() -> bool:
    """Linear.backward wgrad/dgrad side-stream overlap (opt-in).
    Launch-routing only (side streams, not compiled code): read LIVE
    per call like MT_FP32_SPLITK, so a mid-process env flip works and
    the lever stays out of the compile-cache fingerprint."""
    return _on("MT_STREAM_OVERLAP")


def fingerprint() -> str:
    """Effective lever states for the compile-cache key (cache.py) —
    resolved booleans, not raw env strings, so a flipped *default* (like
    erf-gelu) invalidates cubins compiled under the old
    default instead of silently reusing them."""
    return (f"matmul_fp64={_MATMUL_FP64}|embed_fp64={_EMBED_FP64}"
            f"|row_fp64={_ROW_FP64}|precise_math={_PRECISE_MATH}"
            f"|gelu_erf={_GELU_ERF}|adamw_eps={_ADAMW_EPS}"
            f"|attn_unfused={_ATTN_UNFUSED}"
            f"|attn_bwd_f32={_ATTN_BWD_F32}")


def active() -> list[str]:
    """Names of the levers currently on (for benchmark logging)."""
    out = []
    if _MATMUL_FP64:
        out.append("matmul_fp64")
    if _EMBED_FP64:
        out.append("embed_fp64")
    if _ROW_FP64:
        out.append("row_fp64")
    if _PRECISE_MATH:
        out.append("precise_math")
    if _GELU_ERF and not _ALL and _on("MT_GELU_ERF"):
        out.append("gelu_erf")
    if not _GELU_ERF:
        out.append("gelu_tanh")
    if _ADAMW_EPS and not _ALL and _on("MT_ADAMW_EPS"):
        out.append("adamw_eps")
    if not _ADAMW_EPS:
        out.append("adamw_folded_eps")
    if _ATTN_UNFUSED:
        out.append("attn_unfused")
    if _ATTN_BWD_F32:
        out.append("attn_bwd_f32")
    if stream_overlap():
        out.append("stream_overlap")
    return out
