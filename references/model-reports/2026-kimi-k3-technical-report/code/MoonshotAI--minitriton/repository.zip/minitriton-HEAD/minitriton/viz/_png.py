"""Dependency-free 8-bit RGB PNG writer (stdlib zlib/struct only).

viz targets headless servers; the PNG frame path must not depend on PIL or
matplotlib being importable. Rows are stored with filter type 0 (None).
"""

from __future__ import annotations

import struct
import zlib

import numpy as np

_SIG = b"\x89PNG\r\n\x1a\n"


def _chunk(tag: bytes, payload: bytes) -> bytes:
    return (struct.pack(">I", len(payload)) + tag + payload
            + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF))


def encode_png(u8: np.ndarray) -> bytes:
    """u8 (H, W, 3) uint8 -> PNG file bytes."""
    if u8.dtype != np.uint8 or u8.ndim != 3 or u8.shape[2] != 3:
        raise ValueError(f"encode_png expects (H, W, 3) uint8, got "
                         f"{u8.shape} {u8.dtype}")
    h, w, _ = u8.shape
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)  # 8-bit truecolor
    # one filter byte (0 = None) at the start of every scanline
    raw = np.concatenate(
        [np.zeros((h, 1), np.uint8), u8.reshape(h, w * 3)], axis=1).tobytes()
    return (_SIG + _chunk(b"IHDR", ihdr)
            + _chunk(b"IDAT", zlib.compress(raw, 6))
            + _chunk(b"IEND", b""))


def write_png(path, u8: np.ndarray) -> None:
    with open(path, "wb") as f:
        f.write(encode_png(u8))


def decode_png4test(path) -> np.ndarray:
    """Minimal decoder for frames written by encode_png (filter type 0
    only, 8-bit RGB). Test helper: round-trips a frame without PIL."""
    with open(path, "rb") as f:
        data = f.read()
    if not data.startswith(_SIG):
        raise ValueError("not a PNG file")
    w = h = None
    idat = b""
    off = 8
    while off < len(data):
        ln = struct.unpack(">I", data[off:off + 4])[0]
        tag = data[off + 4:off + 8]
        payload = data[off + 8:off + 8 + ln]
        if tag == b"IHDR":
            w, h, bit, color, _, _, _ = struct.unpack(">IIBBBBB", payload)
            if bit != 8 or color != 2:
                raise ValueError("decoder supports 8-bit RGB only")
        elif tag == b"IDAT":
            idat += payload
        off += 12 + ln
    raw = zlib.decompress(idat)
    stride = 1 + w * 3
    out = np.empty((h, w, 3), np.uint8)
    for y in range(h):
        row = raw[y * stride:(y + 1) * stride]
        if row[0] != 0:
            raise ValueError(f"unexpected filter {row[0]}")
        out[y] = np.frombuffer(row[1:], np.uint8).reshape(w, 3)
    return out
