"""DSL type system: scalar dtypes, pointers, blocks and ``tl.constexpr``.

The DSL operates on:

- scalars: ``i32``/``i64``/``f32``/``f16``/``bf16`` (plus internal ``i1``)
- pointers: ``pointer(dtype)`` — a kernel argument pointing to device memory
- blocks (tensors): per-program tiles, e.g. ``tensor<BLOCKxf32>``; their
  *layout* (how elements map to threads) is a builder concern, see
  ``minitriton/compiler/builder.py``
- ``constexpr``: values known at compile time (baked into the generated
  MLIR, part of the compile cache key, like triton)
"""

from __future__ import annotations

import numpy as np
from mlir import ir


class DType:
    """Scalar element type. ``name`` follows the triton spelling."""

    def __init__(self, name: str, itemsize: int, kind: str):
        self.name = name
        self.itemsize = itemsize
        self.kind = kind  # 'int' | 'float' | 'bool'

    @property
    def is_float(self) -> bool:
        return self.kind == "float"

    @property
    def is_int(self) -> bool:
        return self.kind == "int"

    def mlir(self) -> ir.Type:
        return _MLIR_TYPES[self.name]()

    def numpy(self):
        if self.name not in _NUMPY_TYPES:
            raise TypeError(
                f"dtype {self.name} has no numpy equivalent for host roundtrip"
            )
        return _NUMPY_TYPES[self.name]

    def __repr__(self) -> str:
        return self.name

    def __eq__(self, other) -> bool:
        return isinstance(other, DType) and self.name == other.name

    def __hash__(self) -> int:
        return hash(self.name)


int1 = DType("i1", 1, "bool")
int32 = DType("i32", 4, "int")
int64 = DType("i64", 8, "int")
float16 = DType("f16", 2, "float")
bfloat16 = DType("bf16", 2, "float")
float32 = DType("f32", 4, "float")

_MLIR_TYPES = {
    "i1": lambda: ir.IntegerType.get_signless(1),
    "i32": lambda: ir.IntegerType.get_signless(32),
    "i64": lambda: ir.IntegerType.get_signless(64),
    "f16": lambda: ir.F16Type.get(),
    "bf16": lambda: ir.BF16Type.get(),
    "f32": lambda: ir.F32Type.get(),
}

_NUMPY_TYPES = {
    "i32": np.int32,
    "i64": np.int64,
    "f16": np.float16,
    "f32": np.float32,
}

# Lanes per 16-byte vector access, per dtype (used for the vector-view ABI).
VECTOR_LANES = {
    "i32": 4,
    "i64": 2,
    "f16": 8,
    "bf16": 8,
    "f32": 4,
}

SIGNED_INT_MIN = {"i32": -(2**31), "i64": -(2**63)}
SIGNED_INT_MAX = {"i32": 2**31 - 1, "i64": 2**63 - 1}

DTYPES = {d.name: d for d in (int1, int32, int64, float16, bfloat16, float32)}

# triton-spelled public names (tl.float32 etc.)
PUBLIC_DTYPES = {
    "float32": float32,
    "float16": float16,
    "bfloat16": bfloat16,
    "int32": int32,
    "int64": int64,
    "int1": int1,
}


class pointer:
    """Pointer to device memory, e.g. ``pointer(float32)`` = ``*f32``."""

    def __init__(self, elem: DType):
        self.elem = elem

    def __repr__(self) -> str:
        return f"*{self.elem}"

    def __eq__(self, other) -> bool:
        return isinstance(other, pointer) and self.elem == other.elem

    def __hash__(self) -> int:
        return hash(("ptr", self.elem))


class constexpr:
    """A compile-time constant.

    Used as a parameter annotation (``BLOCK: tl.constexpr``) or to wrap
    global values captured by a kernel. Constexpr values are baked into the
    generated code and are part of the compile-cache key.
    """

    def __init__(self, value):
        if isinstance(value, constexpr):
            value = value.value
        self.value = value

    def __repr__(self) -> str:
        return f"constexpr({self.value!r})"

    def __eq__(self, other) -> bool:
        return isinstance(other, constexpr) and self.value == other.value

    def __hash__(self) -> int:
        return hash(("constexpr", repr(self.value)))


def is_constexpr_ann(ann) -> bool:
    """True if a parameter annotation object means tl.constexpr."""
    return ann is constexpr or isinstance(ann, constexpr)
