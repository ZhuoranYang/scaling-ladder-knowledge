"""minitriton/sched/rowfam — the row family's COMPOSED reference forms
(softmax / log_softmax / layer_norm / rms_norm / cross_entropy, fwd +
bwd), written as clear tile-op compositions for clarity and
composability.

## The two forms, and which is which

- **Production (fused)**: the shape-optimized kernels in
  `device/cuda/kernels/` (single-block row kernels for C ≤ 8192,
  the split-reduction partials+merge route for wide CE rows, and the
  stat-fused `layernorm_backward_fused` chain that never materializes
  xhat). They sit at the memory roofline for most shapes and stay the
  production route for every family.
- **Composed (this module)**: the same math written as readable
  compositions — one simple @tl.kernel per logical op, plus eager op
  chains (mul / sub / sum(dim)) where that is the textbook
  decomposition. Use these as the numerics reference and the
  composability answer: anything the fused form does can be written
  this way, and the measured cost of doing so is in the table below.

## Numerics contract (verified in tests/test_sched_rowfam.py)

- softmax fwd/bwd, log_softmax fwd/bwd, LN fwd, rms fwd: composed is
  BIT-EQUAL to production (identical formula and reduction trees).
- LN bwd: dx BIT-EQUAL; dgamma/dbeta tolerance-only (the eager
  dim-1/dim-0 reductions order differently than the fused stat
  kernels' in-register trees and 4-way column walks).
- rms bwd: dx tolerance-only expectation vs production (same reason);
  dw tolerance-only.
- CE fwd/bwd at C ≤ 8192: BIT-EQUAL. Wide C (the composed online
  chunked loop vs the production split route): tolerance-only (online
  rescaling reorders the max/sum reductions).
- Tolerances (fp32: rtol 1e-5 class; the reduction-order deltas above
  measured far below that).

## Routing facts (composed reference route vs fused production)

- parity wherever the two forms are the same kernel shape: softmax
  fwd/bwd, LN fwd, rms fwd, CE fwd, CE bwd at C <= 2048
- fused production wins: LN/rms bwd (the stat-fused chain avoids the
  (R,C) xhat materialization and the eager launch chain) and CE bwd at
  C > 8192 (the split route)
- CE bwd at 2048 < C <= 8192 used to be a composed pocket; production
  now also routes the fused single-block form there when the row count
  fills it, so the routes agree in that range
- numbers: benchmarks/roofline/rowfam_report.py -> rowfam.csv (regenerable).
  Production keeps the fused route; this module is the documented
  reference route.
"""

import minitriton as tl
from .. import ops as _eager_ops  # eager compositions for the bwd chains
from ..tensor import Tensor, empty
from ..frontend import types as _t

# ---------------------------------------------------------------------------
# forward forms (textbook single-block compositions; C <= 8192 like the
# production row kernels)
# ---------------------------------------------------------------------------


@tl.kernel
def _softmax_fwd_kernel(x_ptr, out_ptr, C,
                        LOG: tl.constexpr, BLOCK: tl.constexpr):
    """softmax: e = exp(x - max); out = e / sum(e).
    log_softmax: out = (x - max) - log(sum(e))."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=float("-inf"))
    mx = tl.max(x)
    e = tl.exp(x - mx)
    s = tl.sum(e)
    if LOG:
        tl.store(out_ptr + row * C + offs, (x - mx) - tl.log(s), mask=m)
    else:
        tl.store(out_ptr + row * C + offs, e / s, mask=m)


@tl.kernel
def _ln_fwd_kernel(x_ptr, w_ptr, b_ptr, out_ptr, C, eps,
                   HAS_W: tl.constexpr, HAS_B: tl.constexpr,
                   BLOCK: tl.constexpr):
    """layer_norm: y = (x - mean) * rstd * w + b with
    mean = E[x], var = E[(x - mean)^2], rstd = 1/sqrt(var + eps)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    inv_c = 1.0 / C
    mean = tl.sum(x) * inv_c
    d = tl.where(m, x - mean, 0.0)
    var = tl.sum(d * d) * inv_c
    y = d * (1.0 / tl.sqrt(var + eps))
    if HAS_W:
        w = tl.load(w_ptr + offs, mask=m, other=0.0)
        y = y * w
    if HAS_B:
        bb = tl.load(b_ptr + offs, mask=m, other=0.0)
        y = y + bb
    tl.store(out_ptr + row * C + offs, y, mask=m)


@tl.kernel
def _rms_fwd_kernel(x_ptr, w_ptr, out_ptr, C, eps,
                    HAS_W: tl.constexpr, BLOCK: tl.constexpr):
    """rms_norm: y = x * rsqrt(E[x^2] + eps) * w."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    ms = tl.sum(x * x) * (1.0 / C)
    y = x * (1.0 / tl.sqrt(ms + eps))
    if HAS_W:
        w = tl.load(w_ptr + offs, mask=m, other=0.0)
        y = y * w
    tl.store(out_ptr + row * C + offs, y, mask=m)


@tl.kernel
def _ce_fwd_kernel(x_ptr, t_ptr, out_ptr, C, BLOCK: tl.constexpr):
    """NLL per row: logsumexp(x[row]) - x[row, t[row]]."""
    row = tl.program_id(0)
    t = tl.load(t_ptr + row)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=float("-inf"))
    mx = tl.max(x)
    e = tl.exp(x - mx)
    s = tl.sum(e)
    xt = tl.sum(tl.where(offs == t, x, 0.0))
    tl.store(out_ptr + row, (tl.log(s) + mx) - xt)


def _block(C: int) -> int:
    b = max(128, ((C + 127) // 128) * 128)
    if b > 8192:
        raise NotImplementedError(
            f"row length {C} exceeds the composed single-block limit of "
            "8192 (production split routes cover wide rows)")
    return b


def softmax(x2d: Tensor, log: bool = False) -> Tensor:
    """Composed softmax/log_softmax over the last dim of (R, C)."""
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = x2d.shape
    out = empty(x2d.shape, x2d.dtype, "cuda")
    if R:
        _softmax_fwd_kernel[(R,)](x2d._buffer_arg(), out._buffer_arg(),
                                  C, LOG=log, BLOCK=_block(C), num_warps=4)
    return out


def layer_norm(x2d: Tensor, w, b, eps: float) -> Tensor:
    """Composed layer_norm over the last dim; w/b optional."""
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = x2d.shape
    out = empty(x2d.shape, x2d.dtype, "cuda")
    if R:
        _ln_fwd_kernel[(R,)](x2d._buffer_arg(), (w if w is not None else x2d)._buffer_arg(),
                             (b if b is not None else x2d)._buffer_arg(), out._buffer_arg(),
                             C, eps, HAS_W=w is not None,
                             HAS_B=b is not None, BLOCK=_block(C),
                             num_warps=4)
    return out


def rms_norm(x2d: Tensor, w, eps: float) -> Tensor:
    """Composed rms_norm over the last dim; w optional."""
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = x2d.shape
    out = empty(x2d.shape, x2d.dtype, "cuda")
    if R:
        _rms_fwd_kernel[(R,)](x2d._buffer_arg(), (w if w is not None else x2d)._buffer_arg(),
                              out._buffer_arg(), C, eps,
                              HAS_W=w is not None, BLOCK=_block(C),
                              num_warps=4)
    return out


def cross_entropy(x2d: Tensor, t1d: Tensor) -> Tensor:
    """Composed NLL per row: logsumexp(x) - x[t]. Wide rows (C > 8192)
    take the online chunked form (tolerance vs the production split)."""
    x = x2d if x2d.is_contiguous() else x2d.contiguous()
    t = t1d
    if t.dtype != _t.int32:
        # the kernels compare offsets against t: i32 only (production
        # cross_entropy_rows applies the same conversion)
        t = t.astype(_t.int32)
    if not t.is_contiguous():
        t = t.contiguous()
    R, C = x.shape
    out = empty((R,), x.dtype, "cuda")
    if not R:
        return out
    if C <= 2048:
        _ce_fwd_kernel[(R,)](x._buffer_arg(), t._buffer_arg(),
                             out._buffer_arg(), C, BLOCK=_block(C),
                             num_warps=4)
    else:
        # 2048 < C: the online chunked loop at the production chunk
        # width — bit-equal to its SINGLE partials form where s == 1
        # (C <= 8192), tolerance vs its split route above that
        _ce_fwd_online_kernel[(R,)](x._buffer_arg(), t._buffer_arg(),
                                    out._buffer_arg(), C, BLOCK=1024,
                                    num_warps=4)
    return out


@tl.kernel
def _ce_fwd_online_kernel(x_ptr, t_ptr, out_ptr, C, BLOCK: tl.constexpr):
    """Wide-row CE: one online (max, sum) pass over the row in BLOCK
    chunks (the readable form of the split-reduction route)."""
    row = tl.program_id(0)
    t = tl.load(t_ptr + row)
    offs = tl.arange(0, BLOCK)
    m = float("-inf")
    s = 0.0
    for c0 in range(0, C, BLOCK):
        idx = c0 + offs
        x = tl.load(x_ptr + row * C + idx, mask=idx < C,
                    other=float("-inf"))
        mx = tl.max(x)
        nm = tl.where(mx > m, mx, m)
        s = s * tl.exp(m - nm) + tl.sum(tl.exp(x - nm))
        m = nm
    xt = tl.load(x_ptr + row * C + t)
    tl.store(out_ptr + row, (m + tl.log(s)) - xt)


# ---------------------------------------------------------------------------
# backward forms
# ---------------------------------------------------------------------------


@tl.kernel
def _softmax_bwd_kernel(g_ptr, y_ptr, dx_ptr, C,
                        LOG: tl.constexpr, BLOCK: tl.constexpr):
    """softmax bwd: dx = y * (g - sum(g*y));
    log_softmax bwd: dx = g - exp(y) * sum(g)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    g = tl.load(g_ptr + row * C + offs, mask=m, other=0.0)
    y = tl.load(y_ptr + row * C + offs, mask=m, other=0.0)
    if LOG:
        s = tl.sum(g)
        tl.store(dx_ptr + row * C + offs, g - tl.exp(y) * s, mask=m)
    else:
        s = tl.sum(g * y)
        tl.store(dx_ptr + row * C + offs, y * (g - s), mask=m)


def softmax_backward(g2d: Tensor, y2d: Tensor, log: bool = False) -> Tensor:
    """Composed softmax/log_softmax backward."""
    if not g2d.is_contiguous():
        g2d = g2d.contiguous()
    if not y2d.is_contiguous():
        y2d = y2d.contiguous()
    R, C = g2d.shape
    out = empty(g2d.shape, g2d.dtype, "cuda")
    if R:
        _softmax_bwd_kernel[(R,)](g2d._buffer_arg(), y2d._buffer_arg(),
                                  out._buffer_arg(), C, LOG=log,
                                  BLOCK=_block(C), num_warps=4)
    return out


@tl.kernel
def _ln_bwd_dx_kernel(g_ptr, x_ptr, w_ptr, dx_ptr, C, eps,
                      HAS_W: tl.constexpr, BLOCK: tl.constexpr):
    """LN bwd dx per row: dx = rstd*(u - mean(u) - xhat*mean(u*xhat)),
    u = g*w (or g), xhat = (x - mean)*rstd."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    g = tl.load(g_ptr + row * C + offs, mask=m, other=0.0)
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    inv_c = 1.0 / C
    mean = tl.sum(x) * inv_c
    d = tl.where(m, x - mean, 0.0)
    var = tl.sum(d * d) * inv_c
    rstd = 1.0 / tl.sqrt(var + eps)
    xh = d * rstd
    u = g
    if HAS_W:
        w = tl.load(w_ptr + offs, mask=m, other=0.0)
        u = g * w
    u_mean = tl.sum(u) * inv_c
    uxh_mean = tl.sum(u * xh) * inv_c
    dx = rstd * (u - u_mean - xh * uxh_mean)
    tl.store(dx_ptr + row * C + offs, dx, mask=m)


def layernorm_backward(g2d: Tensor, x2d: Tensor, w, eps: float,
                       want_dw: bool = True, want_db: bool = True):
    """Composed LN backward -> (dx, dgamma, dbeta): dx is one row
    kernel (bit-equal to production); the weight/bias grads are the
    textbook decomposition — materialize xhat = (x - mean)*rstd, then
    dgamma = sum(g*xhat, dim=0) and dbeta = sum(g, dim=0) as eager
    compositions (tolerance-only vs the stat-fused production chain)."""
    if not g2d.is_contiguous():
        g2d = g2d.contiguous()
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = g2d.shape
    f32 = _t.float32
    dx = empty(g2d.shape, g2d.dtype, "cuda")
    dgamma = empty((C,), f32, "cuda") if want_dw else None
    dbeta = empty((C,), f32, "cuda") if want_db else None
    if R:
        _ln_bwd_dx_kernel[(R,)](g2d._buffer_arg(), x2d._buffer_arg(),
                                (w if w is not None else g2d)._buffer_arg(),
                                dx._buffer_arg(), C, eps,
                                HAS_W=w is not None, BLOCK=_block(C),
                                num_warps=4)
        if want_dw or want_db:
            mean1 = _eager_ops.sum(x2d, dim=1).reshape((R, 1)) / C
            d = x2d - mean1
            var = _eager_ops.sum(d * d, dim=1) / C
            rstd1 = (1.0 / _eager_ops.sqrt(var + eps)).reshape((R, 1))
            xh = d * rstd1
            if want_dw:
                dgamma = _eager_ops.sum(g2d * xh, dim=0)
            if want_db:
                dbeta = _eager_ops.sum(g2d, dim=0)
    return dx, dgamma, dbeta


@tl.kernel
def _rms_bwd_dx_kernel(g_ptr, x_ptr, w_ptr, dx_ptr, C, eps,
                       HAS_W: tl.constexpr, BLOCK: tl.constexpr):
    """rmsnorm bwd dx per row: dx = rstd*(u - xr*mean(u*xr)),
    u = g*w (or g), xr = x*rstd."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    g = tl.load(g_ptr + row * C + offs, mask=m, other=0.0)
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    inv_c = 1.0 / C
    ms = tl.sum(x * x) * inv_c
    rstd = 1.0 / tl.sqrt(ms + eps)
    xr = x * rstd
    u = g
    if HAS_W:
        w = tl.load(w_ptr + offs, mask=m, other=0.0)
        u = g * w
    uxr_mean = tl.sum(u * xr) * inv_c
    dx = rstd * (u - xr * uxr_mean)
    tl.store(dx_ptr + row * C + offs, dx, mask=m)


def rmsnorm_backward(g2d: Tensor, x2d: Tensor, w, eps: float,
                     want_dw: bool = True):
    """Composed rmsnorm backward -> (dx, dw): dx one row kernel; the
    weight grad is dw = sum(g*xr, dim=0) with xr materialized eagerly
    (tolerance-only vs production's in-register stats)."""
    if not g2d.is_contiguous():
        g2d = g2d.contiguous()
    if not x2d.is_contiguous():
        x2d = x2d.contiguous()
    R, C = g2d.shape
    dx = empty(g2d.shape, g2d.dtype, "cuda")
    dw = empty((C,), _t.float32, "cuda") if want_dw else None
    if R:
        _rms_bwd_dx_kernel[(R,)](g2d._buffer_arg(), x2d._buffer_arg(),
                                 (w if w is not None else g2d)._buffer_arg(),
                                 dx._buffer_arg(), C, eps,
                                 HAS_W=w is not None, BLOCK=_block(C),
                                 num_warps=4)
        if want_dw:
            ms = _eager_ops.sum(x2d * x2d, dim=1) / C
            rstd1 = (1.0 / _eager_ops.sqrt(ms + eps)).reshape((R, 1))
            dw = _eager_ops.sum(g2d * (x2d * rstd1), dim=0)
    return dx, dw


@tl.kernel
def _ce_bwd_kernel(x_ptr, t_ptr, g_ptr, dx_ptr, C, BLOCK: tl.constexpr):
    """CE bwd per row: dx = (softmax(x) - onehot(t)) * g[row]."""
    row = tl.program_id(0)
    t = tl.load(t_ptr + row)
    gr = tl.load(g_ptr + row)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=float("-inf"))
    mx = tl.max(x)
    e = tl.exp(x - mx)
    s = tl.sum(e)
    p = e / s
    onehot = tl.cast(offs == t, tl.float32)
    tl.store(dx_ptr + row * C + offs, (p - onehot) * gr, mask=m)


@tl.kernel
def _ce_bwd_online_kernel(x_ptr, t_ptr, g_ptr, dx_ptr, C,
                          BLOCK: tl.constexpr):
    """Wide-row CE bwd: pass 1 computes lse online, pass 2 applies
    dx = (exp(x - lse) - onehot) * g — x is read twice, no partial
    planes (the readable form)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = float("-inf")
    s = 0.0
    for c0 in range(0, C, BLOCK):
        idx = c0 + offs
        x = tl.load(x_ptr + row * C + idx, mask=idx < C,
                    other=float("-inf"))
        mx = tl.max(x)
        nm = tl.where(mx > m, mx, m)
        s = s * tl.exp(m - nm) + tl.sum(tl.exp(x - nm))
        m = nm
    lse = m + tl.log(s)
    t = tl.load(t_ptr + row)
    gr = tl.load(g_ptr + row)
    for c0 in range(0, C, BLOCK):
        idx = c0 + offs
        msk = idx < C
        x = tl.load(x_ptr + row * C + idx, mask=msk, other=0.0)
        p = tl.exp(x - lse)
        onehot = tl.cast(idx == t, tl.float32)
        tl.store(dx_ptr + row * C + idx, (p - onehot) * gr, mask=msk)


def cross_entropy_backward(x2d: Tensor, t1d: Tensor,
                           grows: Tensor) -> Tensor:
    """Composed CE backward: (softmax(x) - onehot(t)) * g. Wide rows
    take the two-pass online form (tolerance vs the production split)."""
    t = t1d
    if t.dtype != _t.int32:
        # the kernels compare offsets against t: i32 only (same
        # conversion as the forward entry / the production route)
        t = t.astype(_t.int32)
    if not t.is_contiguous():
        t = t.contiguous()
    x = x2d if x2d.is_contiguous() else x2d.contiguous()
    g = grows if grows.is_contiguous() else grows.contiguous()
    R, C = x.shape
    out = empty(x.shape, x.dtype, "cuda")
    if not R:
        return out
    if C <= 8192:
        # the single-block form (production now routes it in this range
        # too when rows suffice; numbers regenerable via
        # benchmarks/roofline/rowfam_report.py)
        _ce_bwd_kernel[(R,)](x._buffer_arg(), t._buffer_arg(),
                             g._buffer_arg(), out._buffer_arg(), C,
                             BLOCK=_block(C), num_warps=4)
    else:
        _ce_bwd_online_kernel[(R,)](x._buffer_arg(), t._buffer_arg(),
                                    g._buffer_arg(),
                                    out._buffer_arg(), C, BLOCK=1024,
                                    num_warps=4)
    return out


__all__ = [
    "softmax", "softmax_backward",
    "layer_norm", "layernorm_backward",
    "rms_norm", "rmsnorm_backward",
    "cross_entropy", "cross_entropy_backward",
]
