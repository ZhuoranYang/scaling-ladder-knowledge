"""KDA forward on tensor cores — tf32/bf16 mma tiers of the
five-kernel pipeline in device/cuda/kernels/kda.py.

Tier contract (both tiers): f32 in/out at the public boundary, f32
accumulators everywhere; only the matmul inner products run on mma.sync.
K1s (tl.solve_tril UT inverse) stays the shared fp32 launch in all tiers
(f32 l/m planes), so the l/m/md/mv/hc-adjacent plane DTypes differ per
tier:

  plane        tf32 tier            bf16 tier
  delta/qh/wc/wt (K1 write keys)   f32     bf16 (cast at K1 store)
  l / m (K1 output / K1s inverse)  f32     f32 (solve_tril is fp32)
  md / mv (K1b factors)            f32     f32 (K2 casts on fragment load)
  hc / vt (K2 planes, K3 operands) f32     bf16 (packed at K2 store)
  v (K1b mv operand)               f32     bf16 (one cast pass upstream)
  o / s1                           f32     f32 (public contract)

Kernel mapping vs the fp32 pipeline — **all
four mma segments are pure DSL** (composed from the general tile
vocabulary):
  K1  kda_wy_mma_kernel   same wy elementwise build (dtype-parameterized
                          plane stores), then the L product as a
                          barrier + register-A x staged-B tl.mma tile
                          (strict-tril mask and the emc rescale applied
                          in-fragment)
  K1s (shared, kda.py)    tl.solve_tril, untouched
  K1b kda_mv_mma_kernel   md = M @ delta / mv = M @ v as tl.mma_tile
  K2  kda_state_mma_kernel  the whole scan as a runtime chunk loop
                          carrying S as an f32 mma C fragment (row-slab
                          warp grid (warps, 1), per-row decay via a
                          narrow (DK,1) stat load + tl.exp); vt = mv -
                          md @ S with the hc/vt planes round-tripped
                          through store_m4 + staged-B reads (barriered)
  K3  kda_out_mma_kernel  qh A fragments loaded once (used by both
                          dots), incl-tril mask + emc in fragment, the
                          Aq -> A-operand conversion via the tier-1
                          frag_c_to_a convert_layout (bf16: free pair
                          pack; tf32: quad shfl.idx + select + cvt.rna)

NOTE: no ``from __future__ import annotations`` here — kernel parameter
annotations (``tl.constexpr``) must stay real objects for the DSL binder.
"""

import minitriton as tl
from ....frontend import types as tl_types
from ....tensor import empty

from .kda import C64, _contig, alloc_wy_planes, launch_kda_solve

# per-tier plane dtype for the K1 write-key / K2-output planes
_PLANE_DT = {"tf32": tl_types.float32, "bf16": tl_types.bfloat16}


# ---------------------------------------------------------------------------
# K1 — wy build with dtype-parameterized plane stores + the L mma primitive.
# Same live-range-ordered body as kda.py's K1 (register pressure note
# there applies verbatim); only the plane-store dtype and the L product
# change.
# ---------------------------------------------------------------------------

@tl.kernel
def kda_wy_mma_kernel(kn_ptr, qn_ptr, beta_ptr, g_ptr, gt_ptr, c_ptr,
                      emc_ptr, l_ptr, delta_ptr, qh_ptr, wc_ptr, wt_ptr,
                      T, NC,
                      DK: tl.constexpr, C: tl.constexpr,
                      ATOM: tl.constexpr):
    pid = tl.program_id(0)
    bh = tl.program_id(1)
    offs = tl.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    base = bh * (T * DK)
    offs2 = offs[:, None] * DK + offs[None, :]          # (C, 64) plane-local
    offs2g = offs_t[:, None] * DK + offs[None, :]       # (C, 64) global rows
    offsC = offs[:, None] * C + offs[None, :]           # (C, C)
    offsG = slab * (C * DK) + offs2                     # g plane (C, DK)
    offsGT = slab * (C * DK) + offs[:, None] + offs[None, :] * DK
    beta_r = tl.load(beta_ptr + bh * T + offs_t[None, :],
                     mask=tm[None, :], other=0.0)       # (1, C)
    c = tl.load(c_ptr + slab)
    emc = tl.load(emc_ptr + slab)
    BF16: tl.constexpr = ATOM == "bf16"
    # ---- dk half 0: decayed read keys (stored, then dead) ----
    g0 = tl.load(g_ptr + offsG)
    kn0 = tl.load(kn_ptr + base + offs2g, mask=tm[:, None], other=0.0)
    qn0 = tl.load(qn_ptr + base + offs2g, mask=tm[:, None], other=0.0)
    eg0 = tl.exp(g0)
    if BF16:
        tl.store(delta_ptr + slab * (C * DK) + offs2,
                 tl.cast(eg0 * kn0, tl.bfloat16))
        tl.store(qh_ptr + slab * (C * DK) + offs2,
                 tl.cast(eg0 * qn0, tl.bfloat16))
    else:
        tl.store(delta_ptr + slab * (C * DK) + offs2, eg0 * kn0)
        tl.store(qh_ptr + slab * (C * DK) + offs2, eg0 * qn0)
    # ---- half 0: transposed write keys (stored, then dead) ----
    gt2_0 = tl.load(g_ptr + offsGT)                     # g transposed (slow)
    gt0 = tl.load(gt_ptr + slab * DK + offs[:, None])   # (64, 1) gT
    knT0 = tl.load(kn_ptr + base + offs[:, None] + offs_t[None, :] * DK,
                   mask=tm[None, :], other=0.0)         # kn trans (slow)
    wtT0 = knT0 * beta_r * tl.exp(gt0 - gt2_0)          # tail-shifted
    e0 = c - gt2_0
    e0 = tl.where(e0 > 80.0, 80.0, e0)
    e0 = tl.where(e0 < -80.0, -80.0, e0)
    wcT0 = knT0 * beta_r * tl.exp(e0)                   # write keys (64, C)
    if BF16:
        tl.store(wt_ptr + slab * (DK * C) + offsC,
                 tl.cast(wtT0, tl.bfloat16))
        tl.store(wc_ptr + slab * (DK * C) + offsC,
                 tl.cast(wcT0, tl.bfloat16))
    else:
        tl.store(wt_ptr + slab * (DK * C) + offsC, wtT0)
        tl.store(wc_ptr + slab * (DK * C) + offsC, wcT0)
    # ---- dk half 1 (dk=128) ----
    if DK == 128:
        g1 = tl.load(g_ptr + C + offsG)
        kn1 = tl.load(kn_ptr + base + C + offs2g, mask=tm[:, None],
                      other=0.0)
        qn1 = tl.load(qn_ptr + base + C + offs2g, mask=tm[:, None],
                      other=0.0)
        eg1 = tl.exp(g1)
        gt2_1 = tl.load(g_ptr + C + offsGT)
        gt1 = tl.load(gt_ptr + slab * DK + C + offs[:, None])
        knT1 = tl.load(kn_ptr + base + C + offs[:, None]
                       + offs_t[None, :] * DK, mask=tm[None, :], other=0.0)
        wtT1 = knT1 * beta_r * tl.exp(gt1 - gt2_1)
        e1 = c - gt2_1
        e1 = tl.where(e1 > 80.0, 80.0, e1)
        e1 = tl.where(e1 < -80.0, -80.0, e1)
        wcT1 = knT1 * beta_r * tl.exp(e1)
        if BF16:
            tl.store(delta_ptr + slab * (C * DK) + C + offs2,
                     tl.cast(eg1 * kn1, tl.bfloat16))
            tl.store(qh_ptr + slab * (C * DK) + C + offs2,
                     tl.cast(eg1 * qn1, tl.bfloat16))
            tl.store(wt_ptr + slab * (DK * C) + C * C + offsC,
                     tl.cast(wtT1, tl.bfloat16))
            tl.store(wc_ptr + slab * (DK * C) + C * C + offsC,
                     tl.cast(wcT1, tl.bfloat16))
        else:
            tl.store(delta_ptr + slab * (C * DK) + C + offs2, eg1 * kn1)
            tl.store(qh_ptr + slab * (C * DK) + C + offs2, eg1 * qn1)
            tl.store(wt_ptr + slab * (DK * C) + C * C + offsC, wtT1)
            tl.store(wc_ptr + slab * (DK * C) + C * C + offsC, wcT1)
    # ---- L = strict(delta @ wc) * emc, pure DSL: the CTA barrier makes
    # this program's plane stores visible to the fragment loads, then a
    # register-A x staged-B tl.mma tile with the strict-lower mask and
    # the emc rescale applied to the C fragment before the f32 store ----
    tl.barrier()
    offs_k = tl.arange(0, DK)
    a_pt = delta_ptr + slab * (C * DK) + offs[:, None] * DK \
        + offs_k[None, :]                               # (C, DK)
    b_pt = wc_ptr + slab * (DK * C) + offs_k[:, None] * C \
        + offs[None, :]                                 # (DK, C)
    l_pt = l_ptr + slab * (C * C) + offsC               # (C, C) f32
    lay_a = tl.mma_layout("A", (C, DK), ATOM)
    lay_c = tl.mma_layout("C", (C, C), ATOM)
    a_fr = tl.load(a_pt, LAYOUT=lay_a)
    lacc = tl.mma(a_fr, b_pt, EVEN=True)
    rowsf = tl.materialize(offs[:, None], LAYOUT=lay_c)
    colsf = tl.materialize(offs[None, :], LAYOUT=lay_c)
    lacc = tl.where(rowsf > colsf, lacc * emc, 0.0)
    tl.store(l_pt, lacc)


# ---------------------------------------------------------------------------
# K1b — pseudo-value factors via tl.mma_tile: md = M @ delta, mv = M @ v.
# m/delta/v planes staged from global (produced by earlier launches, so no
# in-kernel visibility hazards). md/mv stay f32 in both tiers (store_m4
# stores f32 accumulators); for the bf16 tier K2/K1b's fragment loaders
# round the f32 md/mv on read (identical rounding point to a bf16 store).
# mv's K covers the ragged last chunk (pad rows zero-filled): EVEN_K=False
# 4B staging unless T % C == 0.
# ---------------------------------------------------------------------------

@tl.kernel
def kda_mv_mma_kernel(m_ptr, delta_ptr, v_ptr, md_ptr, mv_ptr, T, NC, SPLIT,
                      DK: tl.constexpr, DV: tl.constexpr, C: tl.constexpr,
                      ATOM: tl.constexpr, EVEN_T: tl.constexpr):
    pid = tl.program_id(0)
    p2 = tl.program_id(1)
    bh = p2 // SPLIT
    sp = p2 % SPLIT
    offs = tl.arange(0, C)
    offs_t = pid * C + offs
    slab = bh * NC + pid
    offsC = offs[:, None] * C + offs[None, :]
    offs2 = offs[:, None] * DK + offs[None, :]
    offs_v = sp * C + tl.arange(0, C)
    m_pt = m_ptr + slab * (C * C) + offsC
    d_pt = delta_ptr + slab * (C * DK) + offs2
    md = tl.mma_tile(m_pt, d_pt, C, ATOM=ATOM, STAGES=1)
    tl.store(md_ptr + slab * (C * DK) + offs2, md)
    if DK == 128:
        d1_pt = delta_ptr + slab * (C * DK) + C + offs2
        md1 = tl.mma_tile(m_pt, d1_pt, C, ATOM=ATOM, STAGES=1)
        tl.store(md_ptr + slab * (C * DK) + C + offs2, md1)
    v_pt = v_ptr + bh * (T * DV) + offs_t[:, None] * DV + offs_v[None, :]
    mv_pt = mv_ptr + slab * (C * DV) + offs[:, None] * DV + offs_v[None, :]
    if EVEN_T:
        mv = tl.mma_tile(m_pt, v_pt, C, ATOM=ATOM, STAGES=1)
    else:
        # ragged K: zfill the pad rows (k >= T - t0); 4B masked staging.
        # K must be clamped to the single tile: the mma_tile K loop is
        # ceil(K/BK) tiles, so an unclamped rem would run a second tile.
        rem = T - pid * C
        mv = tl.mma_tile(m_pt, v_pt, tl.where(rem > C, C, rem),
                         ATOM=ATOM, STAGES=1, EVEN_K=False, VEC=False)
    tl.store(mv_pt, mv)


# ---------------------------------------------------------------------------
# K2 — state scan kernel: the whole sequential loop is DSL, S carried as
# an f32 mma C fragment across the runtime chunk loop.
# ---------------------------------------------------------------------------

@tl.kernel
def kda_state_mma_kernel(md_ptr, mv_ptr, wt_ptr, gt_ptr, s0_ptr,
                         hc_ptr, vt_ptr, s1_ptr, T, NC, SPLIT,
                         HAS_S0: tl.constexpr, DK: tl.constexpr,
                         DV: tl.constexpr, C: tl.constexpr,
                         ATOM: tl.constexpr):
    """K2, pure DSL: the chunked state scan with S carried as an f32 mma
    C fragment across the chunk loop.

    Composed from
    the general primitives: per chunk, store S_start to the hc plane
    (K3's operand) and barrier (the program's own stores become visible
    to the staged-B reads); e0 = md @ S_start; vt = mv - e0 (mv lands in
    the C layout via a full-tile fragment load) stored to its plane and
    barriered; the per-row decay rides a narrow (DK,1) stat load +
    tl.exp (the same ex2.approx form), then S += wt @ vt with the
    decayed fragment chained in as the accumulator. s1 is always f32.
    """
    pid = tl.program_id(0)
    bh = pid // SPLIT
    sp = pid % SPLIT
    offs = tl.arange(0, C)
    offs_k = tl.arange(0, DK)
    offs_v = sp * C + tl.arange(0, C)                   # dv columns owned
    slab0 = bh * NC
    offsC = offs_k[:, None] * C + offs[None, :]         # (DK, C)
    offs2 = offs[:, None] * DK + offs_k[None, :]        # (C, DK)
    offsS = offs_k[:, None] * DV + offs_v[None, :]      # (DK, 64) state
    offsMV = offs[:, None] * DV + offs_v[None, :]       # (C, 64)
    lay_ae = tl.mma_layout("A", (C, DK), ATOM)
    lay_as = tl.mma_layout("A", (DK, C), ATOM)
    lay_cs = tl.mma_layout("C", (DK, C), ATOM)
    lay_ce = tl.mma_layout("C", (C, C), ATOM)
    if HAS_S0:
        S = tl.load(s0_ptr + bh * (DK * DV) + offsS, LAYOUT=lay_cs)
    else:
        S = tl.zeros((DK, C), tl.float32, LAYOUT=lay_cs)
    for cc in range(0, NC):
        # 1. chunk-start state -> hc plane (K3's operand)
        hc_pt = hc_ptr + (slab0 + cc) * (DK * DV) + offsS
        tl.store(hc_pt, S)
        tl.barrier()
        # 2. e0 = md @ S (B stages the hc copy just stored)
        md_pt = md_ptr + (slab0 + cc) * (C * DK) + offs2
        e0 = tl.mma(tl.load(md_pt, LAYOUT=lay_ae), hc_pt, EVEN=True)
        # 3. vt = mv - e0 (mv read as a full C-fragment tile) -> vt plane
        mv_pt = mv_ptr + (slab0 + cc) * (C * DV) + offsMV
        vt = tl.load(mv_pt, LAYOUT=lay_ce) - e0
        vt_pt = vt_ptr + (slab0 + cc) * (C * DV) + offsMV
        tl.store(vt_pt, vt)
        tl.barrier()
        # 4. decay-scale S in-register (per-row gt), then S += wt @ vt
        gt_pt = gt_ptr + (slab0 + cc) * DK + offs_k[:, None]
        S = S * tl.exp(tl.load(gt_pt, LAYOUT=lay_cs))
        wt_pt = wt_ptr + (slab0 + cc) * (DK * C) + offsC
        S = tl.mma(tl.load(wt_pt, LAYOUT=lay_as), vt_pt, S, EVEN=True)
    tl.store(s1_ptr + bh * (DK * DV) + offsS, S)


# ---------------------------------------------------------------------------
# K3 — out kernel: o = incl(qh @ wc) * emc @ vt + qh @ hc, pure DSL.
# ---------------------------------------------------------------------------

@tl.kernel
def kda_out_mma_kernel(qh_ptr, wc_ptr, hc_ptr, vt_ptr, emc_ptr,
                       o_ptr, T, NC, SPLIT,
                       DK: tl.constexpr, DV: tl.constexpr, C: tl.constexpr,
                       ATOM: tl.constexpr):
    """K3, pure DSL: o = (incl_tril(qh @ wc) * emc) @ vt + qh @ hc.

    Choreography composed from the general primitives: the qh A fragments
    load once
    (layout-requested load) and serve both dots; the inclusive-tril
    mask + emc rescale applies to the Aq C fragment in-register
    (materialized row/col coordinates); the Aq -> A-operand conversion
    is the tier-1 frag_c_to_a convert_layout; the f32 store is
    row-masked by T (ragged last chunk)."""
    pid = tl.program_id(0)
    p2 = tl.program_id(1)
    bh = p2 // SPLIT
    sp = p2 % SPLIT
    offs = tl.arange(0, C)
    offs_t = pid * C + offs
    slab = bh * NC + pid
    q0 = pid * C
    offs_v = sp * C + tl.arange(0, C)
    emc = tl.load(emc_ptr + slab)
    offs_k = tl.arange(0, DK)
    qh_pt = qh_ptr + slab * (C * DK) + offs[:, None] * DK \
        + offs_k[None, :]
    wc_pt = wc_ptr + slab * (DK * C) + offs_k[:, None] * C \
        + offs[None, :]
    hc_pt = hc_ptr + slab * (DK * DV) + offs_k[:, None] * DV \
        + offs_v[None, :]
    vt_pt = vt_ptr + slab * (C * DV) + offs[:, None] * DV \
        + offs_v[None, :]
    o_pt = o_ptr + bh * (T * DV) + offs_t[:, None] * DV + offs_v[None, :]
    lay_a = tl.mma_layout("A", (C, DK), ATOM)
    lay_c = tl.mma_layout("C", (C, C), ATOM)
    q_fr = tl.load(qh_pt, LAYOUT=lay_a)
    aq = tl.mma(q_fr, wc_pt, EVEN=True)
    rowsf = tl.materialize(offs[:, None], LAYOUT=lay_c)
    colsf = tl.materialize(offs[None, :], LAYOUT=lay_c)
    aq = tl.where(rowsf >= colsf, aq * emc, 0.0)
    o = tl.mma(q_fr, hc_pt, EVEN=True)
    aq_a = tl.convert_layout(aq, tl.mma_layout("A", (C, C), ATOM))
    o = tl.mma(aq_a, vt_pt, o, EVEN=True)
    tl.store(o_pt, o, mask=(q0 + offs < T)[:, None])


# ---------------------------------------------------------------------------
# host-side launch / allocation helpers
# ---------------------------------------------------------------------------

def alloc_mma_planes(BH: int, NC: int, dk: int, atom: str):
    """delta/qh/wc/wt in the tier's operand dtype; l/m stay f32 (K1s)."""
    dt = _PLANE_DT[atom]
    f = tl_types.float32
    return {
        "l": empty((BH * NC, C64, C64), f, "cuda"),
        "m": empty((BH * NC, C64, C64), f, "cuda"),
        "delta": empty((BH * NC, C64, dk), dt, "cuda"),
        "qh": empty((BH * NC, C64, dk), dt, "cuda"),
        "wc": empty((BH * NC, dk, C64), dt, "cuda"),
        "wt": empty((BH * NC, dk, C64), dt, "cuda"),
    }


def launch_kda_wy_mma(kn, qn, beta, g, gt, c, emc, planes,
                      BH: int, T: int, NC: int, dk: int, atom: str,
                      num_warps: int = 2):
    # nw=2 keeps the wy elementwise section in the same layouts as the
    # fp32 K1 (flat x (1, C) rep broadcasts); the DSL L product only
    # needs num_threads % 32 == 0 (warp-slab mma layouts derive from the
    # kernel's thread count)
    kda_wy_mma_kernel[(NC, BH)](
        kn._buffer_arg(), qn._buffer_arg(), beta._buffer_arg(),
        g._buffer_arg(), gt._buffer_arg(), c._buffer_arg(),
        emc._buffer_arg(), planes["l"]._buffer_arg(),
        planes["delta"]._buffer_arg(), planes["qh"]._buffer_arg(),
        planes["wc"]._buffer_arg(), planes["wt"]._buffer_arg(),
        T, NC, DK=dk, C=C64, ATOM=atom, num_warps=num_warps)


def launch_kda_mv_mma(m_op, planes, mv_planes, v, BH: int, T: int,
                      NC: int, dk: int, dv: int, atom: str,
                      num_warps: int = 4):
    """m_op: the M inverse plane in the atom's operand dtype (f32 tf32 /
    bf16 — the bf16 tier casts f32 m once, one small pass)."""
    split = dv // C64
    kda_mv_mma_kernel[(NC, BH * split)](
        m_op._buffer_arg(), planes["delta"]._buffer_arg(),
        v._buffer_arg(), mv_planes["md"]._buffer_arg(),
        mv_planes["mv"]._buffer_arg(), T, NC, split,
        DK=dk, DV=dv, C=C64, ATOM=atom, EVEN_T=T % C64 == 0,
        num_warps=num_warps)


def launch_kda_state_mma(mv_planes, wt, gt, s0, hc, vt, s1,
                         BH: int, T: int, NC: int, dk: int, dv: int,
                         atom: str, num_warps: int = 4):
    split = dv // C64
    kda_state_mma_kernel[(BH * split,)](
        mv_planes["md"]._buffer_arg(), mv_planes["mv"]._buffer_arg(),
        wt._buffer_arg(), gt._buffer_arg(),
        (s0 if s0 is not None else mv_planes["md"])._buffer_arg(),
        hc._buffer_arg(), vt._buffer_arg(), s1._buffer_arg(),
        T, NC, split, HAS_S0=s0 is not None, DK=dk, DV=dv, C=C64,
        ATOM=atom, num_warps=num_warps)


def launch_kda_out_mma(planes, hc, vt, emc, o,
                       BH: int, T: int, NC: int, dk: int, dv: int,
                       atom: str, num_warps: int = 4):
    split = dv // C64
    kda_out_mma_kernel[(NC, BH * split)](
        planes["qh"]._buffer_arg(), planes["wc"]._buffer_arg(),
        hc._buffer_arg(), vt._buffer_arg(), emc._buffer_arg(),
        o._buffer_arg(), T, NC, split, DK=dk, DV=dv, C=C64,
        ATOM=atom, num_warps=num_warps)


# ---------------------------------------------------------------------------
# f32 -> bf16 cast pass (the K1b mv operand v in the bf16 tier; mma_tile
# asserts its staged operand dtype == the atom element)
# ---------------------------------------------------------------------------

@tl.kernel
def kda_cast_bf16_kernel(x_ptr, o_ptr, N, BLK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLK + tl.arange(0, BLK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m, other=0.0)
    tl.store(o_ptr + offs, tl.cast(x, tl.bfloat16), mask=m)


def cast_bf16(x):
    from ....tensor import empty as _empty
    out = _empty(x.shape, tl_types.bfloat16, "cuda")
    n = x.numel()
    if n:
        kda_cast_bf16_kernel[((n + 4095) // 4096,)](
            x._buffer_arg(), out._buffer_arg(), n, BLK=4096, num_warps=4)
    return out


# ---------------------------------------------------------------------------
# full forward (ops/kda.py contract, precision tier routed here)
# ---------------------------------------------------------------------------

def kda_forward_mma(kn, qn, v, beta, g, gt, c, emc, s0,
                    output_final_state: bool = False, atom: str = "tf32"):
    """KDA forward on tensor cores (tf32/bf16 tiers). Same preprocessed
    contract as device/cuda/kernels/kda.py's kda_forward; public tensors stay
    f32, accumulators are f32 everywhere."""
    if atom not in ("tf32", "bf16"):
        raise RuntimeError(f"kda_forward_mma: bad atom {atom!r}")
    B, H, T, dk = kn.shape
    dv = v.shape[-1]
    BH = B * H
    NC = (T + C64 - 1) // C64
    kn, qn, v = _contig(kn), _contig(qn), _contig(v)
    beta, g = _contig(beta), _contig(g)
    gt, c, emc = _contig(gt), _contig(c), _contig(emc)
    s0 = _contig(s0) if s0 is not None else None
    f = tl_types.float32
    dt = _PLANE_DT[atom]
    planes = alloc_mma_planes(BH, NC, dk, atom)
    from .kda import alloc_mv_planes
    mv_planes = alloc_mv_planes(BH, NC, dk, dv)     # f32 in both tiers
    hc = empty((BH * NC, dk, dv), dt, "cuda")
    vt = empty((BH * NC, C64, dv), dt, "cuda")
    s1 = empty((BH, dk, dv), f, "cuda")
    o = empty((B, H, T, dv), f, "cuda")
    vo = cast_bf16(v) if atom == "bf16" else v
    launch_kda_wy_mma(kn, qn, beta, g, gt, c, emc, planes, BH, T, NC, dk,
                      atom)
    launch_kda_solve(planes, BH, NC)
    m_op = cast_bf16(planes["m"]) if atom == "bf16" else planes["m"]
    launch_kda_mv_mma(m_op, planes, mv_planes, vo, BH, T, NC, dk, dv,
                      atom)
    launch_kda_state_mma(mv_planes, planes["wt"], gt, s0, hc, vt, s1,
                         BH, T, NC, dk, dv, atom)
    launch_kda_out_mma(planes, hc, vt, emc, o, BH, T, NC, dk, dv, atom)
    return (o, s1.reshape((B, H, dk, dv))) if output_final_state else o

__all__ = [
    "_PLANE_DT",
    "kda_wy_mma_kernel",
    "kda_mv_mma_kernel",
    "kda_state_mma_kernel",
    "kda_out_mma_kernel",
    "alloc_mma_planes",
    "launch_kda_wy_mma",
    "launch_kda_mv_mma",
    "launch_kda_state_mma",
    "launch_kda_out_mma",
    "kda_cast_bf16_kernel",
    "cast_bf16",
    "kda_forward_mma",
]
