"""Device memory buffer: the value kernels take as pointer arguments.

A ``Buffer`` owns a cuMemAlloc'd region on the default device and knows its
element dtype/shape. It is the minimal carrier between host code and DSL
kernels; ``Tensor`` wraps it.

The default device's ordinal comes from ``$MT_DEVICE``
(``tl.distributed.launch`` sets it to the local rank; with
``CUDA_VISIBLE_DEVICES=1,2`` rank r lands on the r-th visible GPU).
"""

from __future__ import annotations

import os
import sys

import numpy as np

from ..frontend import types as tl_types
from .cuda_driver import Device

_default_device: Device | None = None


def get_device() -> Device:
    """Process-wide default CUDA device, lazily initialized from $MT_DEVICE
    (default 0)."""
    global _default_device
    if _default_device is None:
        _default_device = Device(int(os.environ.get("MT_DEVICE", "0")))
    return _default_device


_NP_TO_DTYPE = {
    np.dtype(np.float32): tl_types.float32,
    np.dtype(np.float16): tl_types.float16,
    np.dtype(np.int32): tl_types.int32,
    np.dtype(np.int64): tl_types.int64,
}


class Buffer:
    """An owned device allocation with dtype/shape metadata."""

    def __init__(self, nelem: int, dtype: tl_types.DType, device: Device | None = None):
        if nelem < 1:
            raise ValueError("Buffer must hold at least 1 element")
        self.device = device or get_device()
        self.dtype = dtype
        self.nelem = int(nelem)
        self.nbytes = self.nelem * dtype.itemsize
        self.ptr = self.device.alloc(self.nbytes)
        self._freed = False

    @classmethod
    def from_numpy(cls, arr: np.ndarray, device: Device | None = None) -> "Buffer":
        arr = np.ascontiguousarray(arr)
        if arr.dtype not in _NP_TO_DTYPE:
            raise TypeError(f"unsupported numpy dtype for Buffer: {arr.dtype}")
        buf = cls(arr.size, _NP_TO_DTYPE[arr.dtype], device)
        buf.device.memcpy_h2d(buf.ptr, arr, buf.nbytes)
        return buf

    def to_numpy(self, shape=None) -> np.ndarray:
        out = np.empty(self.nelem, dtype=self.dtype.numpy())
        self.device.memcpy_d2h(out, self.ptr, self.nbytes)
        if shape is not None:
            out = out.reshape(shape)
        return out

    def free(self) -> None:
        if not self._freed:
            self.device.free(self.ptr)
            self._freed = True

    def __del__(self):
        # skip cuMemFree during interpreter shutdown: the CUDA context is
        # torn down with the process anyway, and calling into cuda-python
        # while finalizing crashes on the GIL.
        if sys.is_finalizing():
            return
        try:
            self.free()
        except Exception:
            pass

    def __repr__(self) -> str:
        return f"Buffer(nelem={self.nelem}, dtype={self.dtype}, ptr=0x{self.ptr:x})"
