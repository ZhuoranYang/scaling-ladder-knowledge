"""Shared eager op layer: one Python op definition,
two backend implementations. This module owns the *semantics* (torch
broadcasting, dtype promotion, dim/keepdim rules); ``device.cpu`` (numpy)
and ``device.cuda`` (DSL kernels) own the execution.

Dispatch: every op looks up the backend module by ``tensor.device`` and
calls the same function name there. CPU results are the numerical oracle
for CUDA (tests compare both against numpy references).
"""

from __future__ import annotations

import builtins as _bi
import math

import numpy as np

from ..frontend import types as tl_types
from ..tensor import Tensor, empty, promote_dtype, canonical_dim, canonical_dims

f16 = tl_types.float16
bf16 = tl_types.bfloat16
f32 = tl_types.float32
i32 = tl_types.int32
i64 = tl_types.int64

_BACKENDS = {}


def _be(device: str):
    m = _BACKENDS.get(device)
    if m is None:
        if device == "cpu":
            from ..device import cpu as m
        elif device == "cuda":
            from ..device import cuda as m
        else:
            raise ValueError(f"unknown device {device!r} (want cpu/cuda)")
        _BACKENDS[device] = m
    return m


def _is_scalar(x) -> bool:
    return isinstance(x, (int, float, np.integer, np.floating)) \
        and not isinstance(x, bool)


def _tensor(x, device=None) -> Tensor:
    if isinstance(x, Tensor):
        return x
    if isinstance(x, np.ndarray):
        from ..tensor import from_numpy
        return from_numpy(x, device=device or "cuda")
    if _is_scalar(x):
        from ..tensor import tensor as mk
        return mk(x, device=device or "cuda")
    raise TypeError(f"cannot convert {type(x).__name__} to a Tensor")


def _check_index_bounds(idx: Tensor, size: int, op: str) -> None:
    """Reject out-of-range indices loudly (torch semantics: negative
    indices raise, they do not wrap; empty idx is legal). Two device
    reduces + two host syncs per guarded call — safety over speed,
    done here so both backends share the same behavior.

    Skipped under @tl.compile tracing (device == "trace"): a proxy has
    no storage to reduce, and graphs are keyed on shapes, not data —
    a data-dependent bounds assert cannot be replayed at exec time, so
    a compiled embedding/cross_entropy runs without the check."""
    if idx.numel() == 0 or idx.device == "trace":
        return
    be = _be(idx.device)
    lo = be.reduce_full("min", idx, idx.dtype).item()
    hi = be.reduce_full("max", idx, idx.dtype).item()
    if lo < 0 or hi >= size:
        bad = lo if lo < 0 else hi
        raise IndexError(
            f"{op}: index {bad} out of bounds for range [0, {size})")


# ---------------------------------------------------------------------------
# dtype rules
# ---------------------------------------------------------------------------

def _scalar_out_dtype(t: Tensor, s) -> tl_types.DType:
    """python-scalar promotion (torch: scalars don't lift the category;
    an int scalar that does not fit the tensor's int dtype lifts to the
    bigger int dtype instead of silently truncating)."""
    if isinstance(s, (float, np.floating)):
        return t.dtype if t.dtype.is_float else f32
    if isinstance(s, (int, np.integer)) and t.dtype.is_int:
        if t.dtype == tl_types.int32 and not (-2**31 <= s < 2**31):
            return tl_types.int64
        return t.dtype
    return t.dtype


def _div_dtype(dt: tl_types.DType) -> tl_types.DType:
    return dt if dt.is_float else f32


def _unary_math_dtype(a: Tensor) -> tl_types.DType:
    return a.dtype if a.dtype.is_float else f32


# ---------------------------------------------------------------------------
# elementwise binary
# ---------------------------------------------------------------------------

def _binary(op, a, b):
    if _is_scalar(a) or _is_scalar(b):
        t = _tensor(b if _is_scalar(a) else a)
        s = a if _is_scalar(a) else b
        side = "l" if _is_scalar(a) else "r"
        out_dt = _scalar_out_dtype(t, s)
        if op == "div":
            out_dt = _div_dtype(out_dt)
        if op == "pow" and side == "l":
            # scalar ** tensor: exp(x * log(s)); float domain
            out_dt = out_dt if out_dt.is_float else f32
            return _be(t.device).binary("pow", full_like_scalar(t, s, out_dt),
                                        t, out_dt)
        return _be(t.device).binary_scalar(op, t, s, side, out_dt)
    a, b = _tensor(a), _tensor(b)
    if a.device != b.device:
        raise RuntimeError(
            f"operands on different devices: {a.device} vs {b.device}")
    out_dt = promote_dtype(a.dtype, b.dtype)
    if op == "div":
        out_dt = _div_dtype(out_dt)
    if op == "pow":
        out_dt = out_dt if out_dt.is_float else f32
    return _be(a.device).binary(op, a, b, out_dt)


def full_like_scalar(t: Tensor, s, dtype) -> Tensor:
    from ..tensor import tensor as mk
    return mk(s, dtype=dtype, device=t.device)


def add(a, b):
    return _binary("add", a, b)


def sub(a, b):
    return _binary("sub", a, b)


def mul(a, b):
    return _binary("mul", a, b)


def div(a, b):
    return _binary("div", a, b)


def pow(a, b):
    return _binary("pow", a, b)


# ---------------------------------------------------------------------------
# elementwise comparisons (dunder path; f32 1.0/0.0 mask — no bool dtype)
# ---------------------------------------------------------------------------

def _compare(op, a, b):
    if _is_scalar(a) or _is_scalar(b):
        # scalar route (like _binary): the scalar rides the kernel ABI —
        # materializing it via _tensor() would force the DEFAULT device
        # and crash cross-device for cpu tensors
        t = _tensor(b if _is_scalar(a) else a)
        s = a if _is_scalar(a) else b
        side = "l" if _is_scalar(a) else "r"
        return _be(t.device).binary_scalar(op, t, s, side, f32)
    a, b = _tensor(a), _tensor(b)
    if a.device != b.device:
        raise RuntimeError(
            f"operands on different devices: {a.device} vs {b.device}")
    return _be(a.device).binary(op, a, b, f32)


def eq(a, b):
    return _compare("eq", a, b)


def ne(a, b):
    return _compare("ne", a, b)


def lt(a, b):
    return _compare("lt", a, b)


def le(a, b):
    return _compare("le", a, b)


def gt(a, b):
    return _compare("gt", a, b)


def ge(a, b):
    return _compare("ge", a, b)


# ---------------------------------------------------------------------------
# elementwise unary
# ---------------------------------------------------------------------------

def _unary(op, a, out_dt=None):
    a = _tensor(a)
    out_dt = out_dt or _unary_math_dtype(a)
    return _be(a.device).unary(op, a, out_dt)


def neg(a):
    return _unary("neg", a, _tensor(a).dtype)


def abs(a):
    return _unary("abs", a, _tensor(a).dtype)


def relu(a):
    return _unary("relu", a, _tensor(a).dtype)


def exp(a):
    return _unary("exp", a)


def log(a):
    return _unary("log", a)


def sqrt(a):
    return _unary("sqrt", a)


def tanh(a):
    return _unary("tanh", a)


def sigmoid(a):
    return _unary("sigmoid", a)


def gelu(a):
    return _unary("gelu", a)


def silu(a):
    return _unary("silu", a)


def log_sigmoid(a):
    """log(sigmoid(x)), stable form (KDA decay gates — see
    ops/kda.py docstring). Records a grad edge like its unary siblings
    (d/dx = 1 - sigmoid(x)); KDA itself runs under no_grad."""
    a = _tensor(a)
    if a.dtype.is_int:
        a = a.astype(f32)
    return _be(a.device).unary("log_sigmoid", a, a.dtype)


# ---------------------------------------------------------------------------
# fused elementwise forward ops (case-fusions)
# ---------------------------------------------------------------------------

def swiglu(a, b) -> Tensor:
    """Fused SwiGLU activation: ``silu(a) * b`` in one kernel (torch
    broadcasting rules; one flat/nd kernel instead of silu+mul's two)."""
    a, b = _tensor(a), _tensor(b)
    if a.device != b.device:
        raise RuntimeError(
            f"operands on different devices: {a.device} vs {b.device}")
    out_dt = promote_dtype(a.dtype, b.dtype)
    if not out_dt.is_float:
        out_dt = f32
    return _be(a.device).swiglu(a, b, out_dt)


# ---------------------------------------------------------------------------
# movement
# ---------------------------------------------------------------------------

def contiguous(a: Tensor) -> Tensor:
    return _be(a.device).contiguous(a)


def astype(a: Tensor, dtype) -> Tensor:
    return _be(a.device).astype(a, dtype)


def cat(tensors, dim=0) -> Tensor:
    tensors = [_tensor(t) for t in tensors]
    if not tensors:
        raise RuntimeError("cat needs at least one tensor")
    dev = tensors[0].device
    if any(t.device != dev for t in tensors):
        raise RuntimeError("cat: all tensors must be on the same device")
    ndim = tensors[0].ndim
    dim = canonical_dim(dim, ndim)
    for t in tensors[1:]:
        if t.ndim != ndim or any(t.shape[d] != tensors[0].shape[d]
                                 for d in range(ndim) if d != dim):
            raise RuntimeError(
                f"cat: tensor shapes must match except along dim {dim}, "
                f"got {tensors[0].shape} and {t.shape}")
    out_dt = tensors[0].dtype
    for t in tensors[1:]:
        out_dt = promote_dtype(out_dt, t.dtype)
    casted = [t.astype(out_dt) if t.dtype != out_dt else t for t in tensors]
    return _be(dev).cat(casted, dim, out_dt)


def split(a: Tensor, split_size_or_sections, dim=0):
    a = _tensor(a)
    dim = canonical_dim(dim, a.ndim)
    n = a.shape[dim]
    if isinstance(split_size_or_sections, int):
        sz = split_size_or_sections
        if sz <= 0:
            raise RuntimeError("split size must be positive")
        cuts = list(range(0, n, sz))
        sizes = [_bi.min(sz, n - c) for c in cuts]
    else:
        sizes = list(split_size_or_sections)
        if any(s < 0 for s in sizes):
            raise RuntimeError(
                f"split sections must be non-negative, got {sizes}")
        if _bi.sum(sizes) != n:
            raise RuntimeError(
                f"split sections {sizes} do not sum to dim size {n}")
    out, off = [], 0
    for s in sizes:
        idx = [slice(None)] * a.ndim
        idx[dim] = slice(off, off + s)
        out.append(a[tuple(idx)])
        off += s
    return tuple(out)


def broadcast_to(a: Tensor, shape) -> Tensor:
    return _tensor(a).broadcast_to(shape)


# ---------------------------------------------------------------------------
# matmul / bmm
# ---------------------------------------------------------------------------

def matmul(a, b, bias=None) -> Tensor:
    a, b = _tensor(a), _tensor(b)
    if a.device != b.device:
        raise RuntimeError("matmul: devices differ")
    if a.dtype.is_int or b.dtype.is_int:
        raise RuntimeError("matmul requires float tensors")
    if bias is not None and (b.ndim != 2 or bias.ndim != 1
                             or bias.shape[0] != b.shape[1]):
        raise RuntimeError("matmul bias must be (N,) of the (K, N) rhs")
    dt = promote_dtype(a.dtype, b.dtype)
    if dt != f32:
        be = _be(a.device)
        if a.dtype == b.dtype == bf16 and hasattr(be, "matmul_bf16"):
            # bf16 tensor-core mma (f32 accumulate), not the f32 upcast
            return be.matmul_bf16(a, b, bias=bias)
        # tl.dot is f32; compute in f32 and cast back
        a2 = a.astype(f32) if a.dtype != f32 else a
        b2 = b.astype(f32) if b.dtype != f32 else b
        out = _matmul_f32(a2, b2)
        if bias is not None:
            out = out + bias
        return out.astype(dt)
    return _matmul_f32(a, b, bias=bias)


def _matmul_f32(a: Tensor, b: Tensor, bias=None) -> Tensor:
    be = _be(a.device)
    if a.ndim == 1 and b.ndim == 1:
        out = be.matmul(a.reshape((1, a.shape[0])), b.reshape((b.shape[0], 1)))
        if bias is not None:
            out = out + bias
        return out.reshape(())
    if a.ndim == 1:
        out = be.matmul(a.reshape((1, a.shape[0])), b)
        if bias is not None:
            out = out + bias
        return out.reshape(out.shape[1:])
    if b.ndim == 1:
        out = be.matmul(a, b.reshape((b.shape[0], 1)))
        if bias is not None:
            out = out + bias
        return out.reshape(out.shape[:-1])
    if a.ndim == 2 and b.ndim == 2:
        if a.device != "cuda":
            out = be.matmul(a, b)
            return out + bias if bias is not None else out
        return be.matmul(a, b, bias=bias)
    if b.ndim == 2:
        # (..., K) @ (K, N): fold the leading dims into one 2D matmul
        # (torch semantics; avoids materializing a broadcast b)
        k = a.shape[-1]
        a2 = a.reshape((a.numel() // k, k))
        if a.device != "cuda":
            out = be.matmul(a2, b)
            if bias is not None:
                out = out + bias
        else:
            out = be.matmul(a2, b, bias=bias)
        return out.reshape(a.shape[:-1] + (b.shape[1],))
    # batched: broadcast leading dims; bmm accepts stride-0 batch strides
    if bias is not None:
        raise NotImplementedError("matmul bias epilogue is 2D/flattened "
                                  "only (bmm path unimplemented)")
    batch = tuple(np.broadcast_shapes(a.shape[:-2], b.shape[:-2]))
    av = a.broadcast_to(batch + a.shape[-2:]) if a.shape[:-2] != batch else a
    bv = b.broadcast_to(batch + b.shape[-2:]) if b.shape[:-2] != batch else b
    if len(batch) > 1:
        B = math.prod(batch)
        av = av.contiguous().reshape((B,) + av.shape[-2:])
        bv = bv.contiguous().reshape((B,) + bv.shape[-2:])
    out = be.bmm(av, bv)
    return out.reshape(batch + out.shape[-2:])


def matmul_bf16(a, b, out_dtype=None, bias=None) -> Tensor:
    """bf16 tensor-core mma (f32 accumulate), CUDA only. Operands are
    bf16 or f32 — f32 operands are rounded to bf16 inside the kernel
    (staged as f32, packed in-register with the same RN as a
    materialized astype, so the result equals an explicit cast+matmul;
    this is the mixed-precision training *backward* route: no cast op
    is launched and the grad chain stays fp32 between layers).
    ``out_dtype``: bf16 (dtype-promotion semantics, default) or f32
    (the accumulator stored unrounded). The forward bf16-in/bf16-out
    route is plain ``ops.matmul`` on bf16 operands. ``bias`` (optional
    (N,) bf16/f32, bf16-out only): fused epilogue add (cublasLt
    single-rounding semantics)."""
    a, b = _tensor(a), _tensor(b)
    if a.device != b.device:
        raise RuntimeError("matmul_bf16: devices differ")
    if a.dtype not in (bf16, f32) or b.dtype not in (bf16, f32):
        raise RuntimeError(
            f"matmul_bf16 expects bf16/f32 operands, got {a.dtype} @ "
            f"{b.dtype}")
    be = _be(a.device)
    if not hasattr(be, "matmul_bf16"):
        raise RuntimeError("matmul_bf16 is CUDA-only")
    return be.matmul_bf16(a, b, out_dtype=out_dtype, bias=bias)


def bmm(a, b) -> Tensor:
    a, b = _tensor(a), _tensor(b)
    if a.ndim != 3 or b.ndim != 3:
        raise RuntimeError(f"bmm expects 3D tensors, got {a.shape} {b.shape}")
    return matmul(a, b)


# ---------------------------------------------------------------------------
# reductions
# ---------------------------------------------------------------------------

def _reduce(op, a, dim, keepdim, out_dt):
    a = _tensor(a)
    be = _be(a.device)
    if dim is None:
        out = be.reduce_full(op, a, out_dt)
        if keepdim:
            out = out.reshape((1,) * a.ndim)
        return out
    if isinstance(dim, (tuple, list)):
        dims = sorted(canonical_dims(dim, a.ndim))
        if not dims:
            # torch: reducing over () returns the input VALUES — but as a
            # new tensor; returning `a` itself lets the autograd wrapper
            # write a tape node onto the leaf and self-loop (backward
            # then never terminates)
            return a.astype(out_dt) if out_dt != a.dtype else a * 1
        if len(dims) == 1:
            dim = dims[0]  # fall through to the scalar-dim path
        else:
            # multi-dim reduction (torch parity): permute the reduced
            # dims to the back, flatten them into one axis, reduce it
            keep = [i for i in range(a.ndim) if i not in dims]
            if any(a.shape[d] == 0 for d in dims):
                if op != "sum":
                    raise RuntimeError(
                        f"cannot compute {op} over an empty dimension")
                from ..tensor import zeros as _zeros
                z_shape = tuple(1 if i in dims else a.shape[i]
                                for i in range(a.ndim)) if keepdim else tuple(a.shape[i] for i in keep)
                return _zeros(z_shape, out_dt, a.device)
            p = a.permute(keep + dims).contiguous()
            C = 1
            for d in dims:
                C *= a.shape[d]
            out = _reduce(op, p.reshape((p.numel() // C, C)), -1, False,
                          out_dt)
            out = out.reshape(tuple(a.shape[i] for i in keep))
            if keepdim:
                out = out.reshape(tuple(
                    1 if i in dims else a.shape[i]
                    for i in range(a.ndim)))
            return out
    d = canonical_dim(dim, a.ndim)
    if a.shape[d] == 0:
        if op != "sum":  # torch: max/min over an empty dim raises
            raise RuntimeError(f"cannot compute {op} over an empty "
                               "dimension")
        from ..tensor import zeros as _zeros
        z_shape = tuple(1 if i == d else a.shape[i]
                        for i in range(a.ndim)) if keepdim else a.shape[:d] + a.shape[d + 1:]
        return _zeros(z_shape, out_dt, a.device)
    if op == "sum" and d == 0 and a.ndim == 2 and a.is_contiguous() \
            and hasattr(be, "reduce_col_sum") and (
                (a.dtype == tl_types.float32 and out_dt == tl_types.float32)
                or (a.dtype == tl_types.bfloat16
                    and out_dt in (tl_types.bfloat16, tl_types.float32))):
        # direct column-reduce: f32 accumulation (bf16 packs on store in
        # the fold pass, matching the row-reduce's f32 compute; the
        # bf16 -> f32 form keeps the f32 fold for param grads)
        r = be.reduce_col_sum(a, out_dt)
        return r.reshape((1, a.shape[1])) if keepdim else r
    p = a if d == a.ndim - 1 else a.permute(
        [i for i in range(a.ndim) if i != d] + [d])
    pc = p.contiguous()
    C = pc.shape[-1]
    R = pc.numel() // C
    r = be.reduce_row(op, pc.reshape((R, C)), out_dt)
    shape_p = p.shape[:-1]  # remaining dims stay in original relative order
    if keepdim:
        out = r.reshape(shape_p + (1,))
        inv = [i for i in range(a.ndim) if i != d] + [d]
        return out.permute(_inverse_perm(inv))
    return r.reshape(shape_p)


def _inverse_perm(p):
    inv = [0] * len(p)
    for i, v in enumerate(p):
        inv[v] = i
    return inv


def sum(a, dim=None, keepdim=False, dtype=None):
    a = _tensor(a)
    out_dt = dtype or (i64 if a.dtype.is_int else a.dtype)
    return _reduce("sum", a, dim, keepdim, out_dt)


def mean(a, dim=None, keepdim=False, dtype=None):
    a = _tensor(a)
    out_dt = dtype or (a.dtype if a.dtype.is_float else f32)
    if dim is None:
        n = a.numel()
    elif isinstance(dim, (tuple, list)):
        n = 1
        for d in canonical_dims(dim, a.ndim):
            n *= a.shape[d]
    else:
        n = a.shape[canonical_dim(dim, a.ndim)]
    if n == 0:
        # torch: mean over an empty extent is NaN, not ZeroDivisionError
        return _reduce("sum", a, dim, keepdim, out_dt) + float("nan")
    out = _reduce("sum", a, dim, keepdim, out_dt)
    return _be(a.device).binary_scalar("mul", out, 1.0 / n, "r", out_dt)


def max(a, dim=None, keepdim=False):
    a = _tensor(a)
    return _reduce("max", a, dim, keepdim, a.dtype)


def min(a, dim=None, keepdim=False):
    a = _tensor(a)
    return _reduce("min", a, dim, keepdim, a.dtype)


def argmax(a, dim=None, keepdim=False):
    a = _tensor(a)
    be = _be(a.device)
    if not a.numel():
        raise RuntimeError("argmax of an empty tensor")
    if dim is None:
        flat = a.contiguous().reshape((1, a.numel()))
        r = be.argmax_rows(flat)
        out = r.reshape(())
        return out.reshape((1,) * a.ndim) if keepdim else out
    d = canonical_dim(dim, a.ndim)
    if a.shape[d] == 0:
        raise RuntimeError("argmax over an empty dimension")
    p = a if d == a.ndim - 1 else a.permute(
        [i for i in range(a.ndim) if i != d] + [d])
    pc = p.contiguous()
    C = pc.shape[-1]
    R = pc.numel() // C
    r = be.argmax_rows(pc.reshape((R, C)))
    shape_p = p.shape[:-1]  # remaining dims stay in original relative order
    if keepdim:
        out = r.reshape(shape_p + (1,))
        inv = [i for i in range(a.ndim) if i != d] + [d]
        return out.permute(_inverse_perm(inv))
    return r.reshape(shape_p)


# ---------------------------------------------------------------------------
# nn ops
# ---------------------------------------------------------------------------

def _rows2d(a: Tensor, dim: int):
    """permute dim to last, contiguous, view as (R, C); returns enough
    metadata to map the result back."""
    d = canonical_dim(dim, a.ndim)
    p = a if d == a.ndim - 1 else a.permute(
        [i for i in range(a.ndim) if i != d] + [d])
    pc = p.contiguous()
    C = pc.shape[-1]
    R = pc.numel() // C
    return p, pc.reshape((R, C)), d


def _from_rows2d(ref_p: Tensor, r2d: Tensor, d: int) -> Tensor:
    out = r2d.reshape(ref_p.shape)
    if d == ref_p.ndim - 1:
        return out
    inv = [i for i in range(ref_p.ndim) if i != d] + [d]
    return out.permute(_inverse_perm(inv)).contiguous()


def softmax(a, dim=-1) -> Tensor:
    a = _tensor(a)
    if a.dtype.is_int:
        a = a.astype(f32)
    p, rows, d = _rows2d(a, dim)
    r = _be(a.device).softmax_rows(rows, log=False)
    return _from_rows2d(p, r, d)


def log_softmax(a, dim=-1) -> Tensor:
    a = _tensor(a)
    if a.dtype.is_int:
        a = a.astype(f32)
    p, rows, d = _rows2d(a, dim)
    r = _be(a.device).softmax_rows(rows, log=True)
    return _from_rows2d(p, r, d)


def layer_norm(a, normalized_shape, weight=None, bias=None, eps=1e-5,
               out_dtype=None) -> Tensor:
    a = _tensor(a)
    if a.dtype.is_int:
        a = a.astype(f32)
    if out_dtype is not None and not out_dtype.is_float:
        raise ValueError(f"layer_norm out_dtype must be float, got "
                         f"{out_dtype}")
    if isinstance(normalized_shape, int):
        normalized_shape = (normalized_shape,)
    normalized_shape = tuple(normalized_shape)
    if a.shape[-len(normalized_shape):] != normalized_shape:
        raise RuntimeError(
            f"normalized_shape {normalized_shape} does not match the "
            f"trailing dims of {a.shape}")
    C = math.prod(normalized_shape)
    flat = a.contiguous().reshape((a.numel() // C, C))
    w = weight.reshape((C,)).contiguous() if weight is not None else None
    b = bias.reshape((C,)).contiguous() if bias is not None else None
    # pack-on-store producer (cast fusion): CUDA casts inside the row
    # kernel; other backends cast after the op (same numerics)
    kw = {"out_dtype": out_dtype} if (
        out_dtype is not None and a.device == "cuda") else {}
    r = _be(a.device).layer_norm_rows(flat, w, b, float(eps), **kw)
    r = r.reshape(a.shape)
    if out_dtype is not None and r.dtype != out_dtype:
        r = r.astype(out_dtype)
    return r


def add_layernorm(a, res, normalized_shape, weight=None, bias=None,
                  eps=1e-5, return_residual=False) -> Tensor:
    """Fused residual-add + layer_norm (case-fusions):
    ``layer_norm(a + res, ...)`` in one row kernel. ``a`` and ``res`` must
    have the same shape. With ``return_residual=True`` returns
    ``(out, a + res)`` — the sum is the next block's residual input."""
    a, res = _tensor(a), _tensor(res)
    if a.device != res.device:
        raise RuntimeError(
            f"operands on different devices: {a.device} vs {res.device}")
    if a.shape != res.shape:
        raise RuntimeError(
            f"add_layernorm: residual shape {res.shape} != input shape "
            f"{a.shape}")
    dt = promote_dtype(a.dtype, res.dtype)
    if not dt.is_float:
        dt = f32
    if a.dtype != dt:
        a = a.astype(dt)
    if res.dtype != dt:
        res = res.astype(dt)
    if isinstance(normalized_shape, int):
        normalized_shape = (normalized_shape,)
    normalized_shape = tuple(normalized_shape)
    if a.shape[-len(normalized_shape):] != normalized_shape:
        raise RuntimeError(
            f"normalized_shape {normalized_shape} does not match the "
            f"trailing dims of {a.shape}")
    C = math.prod(normalized_shape)
    flat_a = a.contiguous().reshape((a.numel() // C, C))
    flat_r = res.contiguous().reshape((res.numel() // C, C))
    w = weight.reshape((C,)).contiguous() if weight is not None else None
    b = bias.reshape((C,)).contiguous() if bias is not None else None
    y, s = _be(a.device).add_layernorm_rows(flat_a, flat_r, w, b, float(eps),
                                            need_sum=return_residual)
    y = y.reshape(a.shape)
    if return_residual:
        return y, s.reshape(a.shape)
    return y


def rms_norm(a, normalized_shape, weight=None, eps=1e-6) -> Tensor:
    a = _tensor(a)
    if a.dtype.is_int:
        a = a.astype(f32)
    if isinstance(normalized_shape, int):
        normalized_shape = (normalized_shape,)
    normalized_shape = tuple(normalized_shape)
    if a.shape[-len(normalized_shape):] != normalized_shape:
        raise RuntimeError(
            f"normalized_shape {normalized_shape} does not match the "
            f"trailing dims of {a.shape}")
    C = math.prod(normalized_shape)
    flat = a.contiguous().reshape((a.numel() // C, C))
    w = weight.reshape((C,)).contiguous() if weight is not None else None
    r = _be(a.device).rms_norm_rows(flat, w, float(eps))
    return r.reshape(a.shape)


def embedding(weight, indices) -> Tensor:
    weight = _tensor(weight)
    idx = _tensor(indices, device=weight.device)
    if idx.device != weight.device:
        idx = idx.to(weight.device)
    if weight.ndim != 2:
        raise RuntimeError("embedding weight must be 2D")
    if idx.dtype.is_float:
        raise RuntimeError("embedding indices must be integers")
    _check_index_bounds(idx, weight.shape[0], "embedding")
    r = _be(weight.device).embedding_rows(
        weight, idx.contiguous().reshape((idx.numel(),)))
    return r.reshape(idx.shape + (weight.shape[1],))


def cross_entropy(logits, target, reduction="mean") -> Tensor:
    x = _tensor(logits)
    t = _tensor(target, device=x.device)
    if t.device != x.device:
        t = t.to(x.device)
    if x.ndim != 2:
        raise RuntimeError(
            f"cross_entropy currently expects 2D logits (N, C), got {x.shape}")
    if t.dtype.is_float:
        raise RuntimeError("cross_entropy target must be an integer tensor")
    if t.numel() != x.shape[0]:
        raise RuntimeError(
            f"target numel {t.numel()} != batch {x.shape[0]}")
    _check_index_bounds(t, x.shape[1], "cross_entropy target")
    if x.dtype.is_int:
        x = x.astype(f32)
    if reduction not in ("none", "sum", "mean"):
        raise ValueError(f"bad reduction {reduction!r}")
    nll = _be(x.device).cross_entropy_rows(
        x, t.contiguous().reshape((t.numel(),)))
    if reduction == "none":
        return nll.reshape(t.shape)
    if reduction == "sum":
        return _be(x.device).reduce_full("sum", nll, x.dtype)
    s = _be(x.device).reduce_full("sum", nll, x.dtype)
    return _be(x.device).binary_scalar("mul", s, 1.0 / t.numel(), "r", x.dtype)


# ---------------------------------------------------------------------------
# backward primitives
#
# Fused backward row kernels + helpers used by autograd/functions.py. Same
# dispatch pattern as the forward primitives: the shared layer normalizes
# shapes (2D contiguous rows), both backends implement the same signatures
# (numpy is the numerical oracle).
# ---------------------------------------------------------------------------

def _binary_op(op: str, a, b, out_dtype=None) -> Tensor:
    """Backend binary with a custom elementwise expr (backward exprs like
    relu_bw/gelu_bw/eq live in the device layers' expression tables)."""
    a, b = _tensor(a), _tensor(b)
    if a.device != b.device:
        raise RuntimeError(f"operands on different devices: {a.device} vs "
                           f"{b.device}")
    return _be(a.device).binary(op, a, b,
                                out_dtype or promote_dtype(a.dtype, b.dtype))


def softmax_backward_rows(g: Tensor, y: Tensor, dim: int) -> Tensor:
    """d softmax(x)/dx given upstream g and forward output y = softmax(x)."""
    p, grows, d = _rows2d(g, dim)
    _, yrows, _ = _rows2d(y, dim)
    dx = _be(g.device).softmax_backward_rows(grows, yrows)
    return _from_rows2d(p, dx, d)


def log_softmax_backward_rows(g: Tensor, y: Tensor, dim: int) -> Tensor:
    """d log_softmax(x)/dx given upstream g and y = log_softmax(x)."""
    p, grows, d = _rows2d(g, dim)
    _, yrows, _ = _rows2d(y, dim)
    dx = _be(g.device).log_softmax_backward_rows(grows, yrows)
    return _from_rows2d(p, dx, d)


def layernorm_backward_rows(g2d: Tensor, x2d: Tensor, w, eps: float):
    """LayerNorm backward on (R, C) rows -> (dx, xhat).

    xhat is returned so the caller can cheaply get dw = sum_rows(g * xhat).
    """
    be = _be(g2d.device)
    g2c = g2d.contiguous()
    x2c = x2d.contiguous()
    wc = w.contiguous() if w is not None else None
    return be.layernorm_backward_rows(g2c, x2c, wc, float(eps))


def layernorm_backward_fused(g2d: Tensor, x2d: Tensor, w, eps: float):
    """LayerNorm backward on (R, C) rows -> (dx, dgamma, dbeta) with the
    xhat / g*xhat tensors never materialized (CUDA fused kernels, f32
    contract; everything else falls back to the composed path)."""
    if g2d.device != "cuda" or g2d.dtype != f32 or x2d.dtype != f32:
        dx, xhat = layernorm_backward_rows(g2d, x2d, w, eps)
        dgamma = sum(mul(g2d, xhat), dim=0) if w is not None else None
        dbeta = sum(g2d, dim=0)
        return dx, dgamma, dbeta
    be = _be(g2d.device)
    g2c = g2d.contiguous()
    x2c = x2d.contiguous()
    wc = w.contiguous() if w is not None else None
    return be.layernorm_backward_fused(g2c, x2c, wc, float(eps))


def layernorm_backward_dx(g2d: Tensor, x2d: Tensor, w, eps: float):
    """LayerNorm backward on (R, C) rows -> dx only (no weight/bias
    grads; on CUDA f32 the stats row kernel runs alone — xhat is never
    materialized)."""
    if g2d.device != "cuda" or g2d.dtype != f32 or x2d.dtype != f32:
        return layernorm_backward_rows(g2d, x2d, w, eps)[0]
    be = _be(g2d.device)
    g2c = g2d.contiguous()
    x2c = x2d.contiguous()
    wc = w.contiguous() if w is not None else None
    return be.layernorm_backward_dx(g2c, x2c, wc, float(eps))


def rmsnorm_backward_rows(g2d: Tensor, x2d: Tensor, w, eps: float):
    """RMSNorm backward on (R, C) rows -> (dx, xr) with xr = x * rstd."""
    be = _be(g2d.device)
    g2c = g2d.contiguous()
    x2c = x2d.contiguous()
    wc = w.contiguous() if w is not None else None
    return be.rmsnorm_backward_rows(g2c, x2c, wc, float(eps))


def cross_entropy_backward_rows(x2d: Tensor, t1d: Tensor, grows: Tensor) -> Tensor:
    """d cross_entropy/dlogits on (R, C) rows; grows (R,) is the per-row
    upstream scale (mean/sum folded in by the caller)."""
    be = _be(x2d.device)
    x = x2d.contiguous()
    t = t1d.contiguous()
    if t.dtype != i32:
        t = t.astype(i32)
    g = grows.contiguous()
    if g.dtype != x.dtype:
        g = g.astype(x.dtype)
    return be.cross_entropy_backward_rows(x, t, g)


def embedding_backward_rows(g2d: Tensor, idx1d: Tensor, num_rows: int) -> Tensor:
    """Embedding weight grad: dw[idx[i]] += g2d[i] (scatter-add)."""
    be = _be(g2d.device)
    g = g2d.contiguous()
    idx = idx1d.contiguous()
    if idx.dtype != i32:
        idx = idx.astype(i32)
    return be.embedding_backward_rows(g, idx, int(num_rows))


def _copy_into_view(dst_view: Tensor, src: Tensor):
    """Copy src into a (possibly strided) view of a base tensor; used for
    the slice/getitem backward (grad scatter into a zeros tensor)."""
    if src.shape != dst_view.shape:
        raise RuntimeError(f"copy_into_view shape mismatch: {src.shape} vs "
                           f"{dst_view.shape}")
    _be(dst_view.device).copy_into_view(dst_view, src.contiguous())


def flash_attention_forward(q: Tensor, k: Tensor, v: Tensor,
                            scale: float, with_lse: bool = False,
                            precision: str | None = None,
                            causal: bool = True) -> Tensor:
    """Fused causal flash-attention forward. q/k/v (B, H, T, hd);
    CUDA only (head dim 64). Raises on unsupported configs — callers
    fall back to the unfused composition. with_lse=True returns
    (out, lse) with the (B, H, T) per-row log-sum-exp (the
    fused backward consumes it).

    causal=False is NOT supported by the fused kernel (the mask is
    hard-coded); use ``nn.unfused_attention`` — the full-attention
    composition — instead. Raises NotImplementedError.

    precision: "fp32" (default for f32 inputs; exact FMA
    kernel), "tf32" (tensor-core mma, f32 in/out), "bf16" (tensor-core
    mma, bf16 in/out, f32 accumulate). None routes bf16 inputs to "bf16"
    and f32 inputs to "tf32" when the backend allow_tf32 flag is set,
    else "fp32"."""
    if not causal:
        raise NotImplementedError(
            "fused flash_attention_forward is causal-only "
            "(hard-coded mask); use nn.unfused_attention "
            "for full attention")
    return _be(q.device).flash_attention_forward(q, k, v, float(scale),
                                                 with_lse, precision)


def flash_attention_backward(q: Tensor, k: Tensor, v: Tensor, o: Tensor,
                             do: Tensor, lse: Tensor, scale: float,
                             precision: str | None = None):
    """Fused flash-attention backward: (dq, dk, dv) given the forward
    inputs/output/upstream grad and the per-row lse. precision=None
    routes by dtype (f32 kernels for f32, native bf16 mma for bf16);
    "fp32" forces the f32 fused kernels."""
    return _be(q.device).flash_attention_backward(q, k, v, o, do, lse,
                                                  float(scale),
                                                  precision=precision)


def flash_attention_forward_qkv(qkv: Tensor, n_head: int, scale: float,
                                precision: str = "bf16"):
    """qkv-packed fused flash forward: (B, T, 3C) -> (out (B, T, C),
    lse (B*H, T)). The kernels read/write the packed layouts directly
    (no head-split/merge materializations). CUDA bf16 only."""
    return _be(qkv.device).flash_attention_forward_qkv(
        qkv, int(n_head), float(scale), precision=precision)


def flash_attention_backward_qkv(qkv: Tensor, o: Tensor, do: Tensor,
                                 lse: Tensor, n_head: int, scale: float,
                                 precision: str = "bf16"):
    """qkv-packed fused flash backward: -> dqkv (B, T, 3C) (CUDA only;
    precision "bf16" native mma kernels, "fp32" exact-FMA kernels)."""
    return _be(qkv.device).flash_attention_backward_qkv(
        qkv, o, do, lse, int(n_head), float(scale), precision=precision)


def adamw_step(p: Tensor, g: Tensor, m: Tensor, v: Tensor, lr_t: float,
               wd_lr: float, b1: float, b2: float, eps: float,
               torch_eps: bool = False, s2: float = 1.0):
    """Fused AdamW update, in place on p/m/v (nn.optim.AdamW)."""
    _be(p.device).adamw_step(p, g, m, v, float(lr_t), float(wd_lr),
                             float(b1), float(b2), float(eps),
                             torch_eps=torch_eps, s2=float(s2))


# ---------------------------------------------------------------------------
# autograd hook: wrap the public ops above
# with tape-recording versions; raw implementations stay in ``_RAW``.
# ---------------------------------------------------------------------------

from ..autograd import functions as _ag_functions  # noqa: E402

_ag_functions.install(globals())

# KDA (Kimi Delta Attention) forward
from .kda import KDA_CHUNK, kda_forward  # noqa: E402, F401
