"""Tape-based autograd engine.

A minimal PyTorch-style reverse-mode autodiff:

- ``Tensor.requires_grad`` marks leaves that accumulate ``.grad``;
- ``Function`` subclasses implement ``forward(ctx, *args)`` /
  ``backward(ctx, grad)`` as classmethods, with ``ctx.save_for_backward``;
- every op application records a ``Node`` on the output's ``grad_fn``;
- ``backward(t, grad)`` walks the tape in reverse topological order,
  accumulating per-tensor grads with ``ops.add`` (grad accumulation goes
  through the normal dispatch, never raw buffer writes);
- ``no_grad`` disables recording (used inside ``Function.apply``'s forward
  and around the whole backward traversal, so backward rules can freely
  call the wrapped eager ops).

Non-goals: in-place autograd detection, higher-order
gradients, graph control beyond ``no_grad``/``detach``.
"""

from __future__ import annotations

import contextlib
import functools
import inspect
from typing import ClassVar

from ..runtime import streams as _streams
from ..tensor import Tensor

_grad_enabled = True


def is_grad_enabled() -> bool:
    return _grad_enabled


def _join_if_side(*ts) -> None:
    """Before a backward-chain kernel consumes a tensor produced on a
    side stream (``home_stream != 0``) while a join=False scope is still
    pending, drain the deferred joins first (streams module docstring,
    contract (b)). Cheap no-op when no overlap scope is open."""
    if _streams.pending() and any(
            getattr(t._storage, "home_stream", 0) for t in ts):
        _streams.join_pending()


@contextlib.contextmanager
def _no_grad():
    global _grad_enabled
    old = _grad_enabled
    _grad_enabled = False
    try:
        yield
    finally:
        _grad_enabled = old


class no_grad:
    """Context manager / decorator disabling tape recording."""

    def __enter__(self):
        self._cm = _no_grad()
        self._cm.__enter__()
        return self

    def __exit__(self, *exc):
        self._cm.__exit__(*exc)
        return False

    def __call__(self, fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with _no_grad():
                return fn(*args, **kwargs)
        return wrapper


# ---------------------------------------------------------------------------
# tape nodes
# ---------------------------------------------------------------------------

class Context:
    """Per-application state handed to Function.forward/backward."""

    __slots__ = ("saved", "meta")

    def __init__(self):
        self.saved: tuple = ()
        self.meta: dict = {}

    def save_for_backward(self, *tensors):
        self.saved = tuple(tensors)


class Node:
    """One tape edge: ``outs`` were produced from ``inputs``; ``_backward``
    maps a list of output grads to a list of input grads (None = no grad).

    ``severed`` is set when a backward pass consumes this node. It lives
    on the node (not only as the ``_SEVERED`` stamp on the original
    output tensors' ``grad_fn``) because aliases that share the node —
    e.g. a ``copy.copy`` of an output — never receive the stamp, and a
    second backward entering through such an alias must still raise
    instead of replaying the node with misrouted (silently zero) grads.
    """

    __slots__ = ("name", "inputs", "outs", "_backward", "severed")

    def __init__(self, name: str, inputs: tuple, outs: tuple, backward):
        self.name = name
        self.inputs = inputs
        self.outs = outs
        self._backward = backward
        self.severed = False


class _SeveredTape:
    """Sentinel stamped on ``Tensor.grad_fn`` when backward tears the tape
    down (the tape is single-use, like torch with retain_graph=False).
    Plain ``None`` would read as "leaf", so a second backward through the
    same (possibly shared) subgraph silently misrouted grads; ``backward``
    raises on this sentinel instead."""

    __slots__ = ()

    def __repr__(self):
        return "<severed grad_fn: tape consumed by backward>"


_SEVERED = _SeveredTape()


def _consumed(fn) -> bool:
    """grad_fn already consumed by an earlier backward: either the
    _SEVERED stamp on the original output tensor, or the node's own
    severed flag — the path an alias sharing the node (e.g. a
    copy.copy of the output) takes, since aliases never get stamped."""
    return fn is _SEVERED or (fn is not None
                              and getattr(fn, "severed", False))


def _iter_tensors(x):
    if isinstance(x, Tensor):
        yield x
    elif isinstance(x, (list, tuple)):
        for v in x:
            yield from _iter_tensors(v)


def any_requires_grad(args, kwargs) -> bool:
    # getattr: duck-typed tensor-likes (e.g. compile.py's _Proxy) may not
    # carry the autograd fields; they never require grad.
    return any(getattr(t, "requires_grad", False) for t in _iter_tensors(args)) \
        or any(getattr(t, "requires_grad", False)
               for t in _iter_tensors(tuple(kwargs.values())))


class Function:
    """Base class for differentiable ops.

    Subclasses implement ``forward(ctx, *args, **kwargs) -> Tensor | tuple``
    and ``backward(ctx, grad_or_grads) -> list`` returning one grad (or
    None) per *tensor* argument of forward, in argument order (non-tensor
    arguments are skipped). forward runs with grad recording off.
    """

    @classmethod
    def _forward_sig(cls):
        """Cached inspect.Signature of the subclass's forward (ctx, ...)."""
        sig = cls.__dict__.get("_fwd_sig")
        if sig is None:
            sig = inspect.signature(cls.forward)
            cls._fwd_sig = sig
        return sig

    @classmethod
    def apply(cls, *args, **kwargs):
        ctx = Context()
        with _no_grad():
            out = cls.forward(ctx, *args, **kwargs)
        if is_grad_enabled() and any_requires_grad(args, kwargs):
            # backward() returns one grad per tensor argument of forward in
            # SIGNATURE order, so the recorded inputs must be bound to the
            # signature too: recording (positional, kwargs insertion order)
            # silently swapped grads for keyword-called ops (mul(b=y, a=x))
            # or dropped them (embedding(indices=i, weight=w) — weight was
            # zipped with the grad meant for the signature's first param)
            bound = cls._forward_sig().bind(ctx, *args, **kwargs)
            inputs = tuple(_iter_tensors(tuple(bound.arguments.values())))
            outs = out if isinstance(out, tuple) else (out,)
            # ONE node per application, shared by every output (torch's
            # grad_fn model): per-output node instances each recomputed
            # the full backward and relied on pop-miss -> zeros, so a
            # 3-output op (split) ran its backward three times and fed
            # the input real+zeros+zeros accumulation adds
            node = Node(cls.__name__, inputs, outs,
                        lambda gs, _cls=cls, _ctx=ctx:
                        _cls.backward(_ctx, gs))
            for o in outs:
                o.requires_grad = True
                o.grad_fn = node
        return out


def record_view(src: Tensor, out: Tensor, op: str, meta) -> Tensor:
    """Autograd hook for metadata/view ops (called from tensor.py)."""
    if not (_grad_enabled and getattr(src, "requires_grad", False)):
        return out
    from .functions import view_backward
    out.requires_grad = True
    out.grad_fn = Node(f"view:{op}", (src,), (out,),
                       lambda g: (view_backward(op, src, meta, g),))
    return out


def record(out: Tensor, name: str, inputs: tuple, backward) -> Tensor:
    """Record a custom op whose forward already ran (used by nn code)."""
    if not (_grad_enabled and any(t.requires_grad for t in inputs)):
        return out
    out.requires_grad = True
    out.grad_fn = Node(name, tuple(inputs), (out,), backward)
    return out


# ---------------------------------------------------------------------------
# backward traversal
# ---------------------------------------------------------------------------

def backward(t: Tensor, grad: Tensor | None = None):
    """Reverse-mode autodiff starting at ``t`` (scalar if grad is None)."""
    from .. import ops
    from ..tensor import ones, zeros

    if _consumed(t.grad_fn):
        raise RuntimeError(
            "Trying to backward through the graph a second time; the tape "
            "was freed by the first backward call")
    if t.grad_fn is None and not t.requires_grad:
        raise RuntimeError(
            "element 0 of tensors does not require grad and does not have "
            "a grad_fn")
    if grad is None:
        if t.numel() != 1:
            raise RuntimeError(
                "grad can be implicitly created only for scalar outputs")
        grad = ones(t.shape, t.dtype, t.device)
    if t.grad_fn is None:
        # a leaf that requires grad accumulates the seed grad into .grad
        t.grad = grad if t.grad is None else ops.add(t.grad, grad)
        return

    topo, seen = [], set()
    # iterative post-order DFS (no nested closure: a recursive inner
    # function would form a self-referencing closure cycle holding the
    # whole tape hostage until the cyclic GC runs)
    stack = [(t, False)]
    while stack:
        v, processed = stack.pop()
        fn = v.grad_fn
        if _consumed(fn):
            raise RuntimeError(
                "Trying to backward through the graph a second time; the "
                "tape of a shared subgraph was freed by an earlier "
                "backward call")
        if fn is None or id(fn) in seen:
            continue
        if processed:
            seen.add(id(fn))
            topo.append(fn)
        else:
            stack.append((v, True))
            for inp in fn.inputs:
                stack.append((inp, False))
    grads: dict[Tensor, Tensor] = {t: grad}
    with _no_grad():
        for node in reversed(topo):
            gs = []
            for o in node.outs:
                g = grads.pop(o, None)
                if g is None:  # an output nobody consumed: zero grad
                    g = zeros(o.shape, o.dtype, o.device)
                gs.append(g)
            in_grads = node._backward(gs if len(gs) > 1 else gs[0])
            if len(in_grads) != len(node.inputs):
                raise RuntimeError(
                    f"{node.name}.backward returned {len(in_grads)} grads "
                    f"for {len(node.inputs)} tensor inputs")
            for inp, ig in zip(node.inputs, in_grads):
                if ig is None or not inp.requires_grad:
                    continue
                if inp.grad_fn is None:
                    if inp.grad is None:
                        inp.grad = ig
                    else:
                        _join_if_side(inp.grad, ig)
                        inp.grad = ops.add(inp.grad, ig)
                elif inp in grads:
                    _join_if_side(grads[inp], ig)
                    grads[inp] = ops.add(grads[inp], ig)
                else:
                    grads[inp] = ig
    # Drain any deferred side-stream joins (join=False scopes, e.g.
    # Linear's wgrad branch) before grads are handed to the optimizer or
    # the host — the tape-level policy's single safe point that needs no
    # dependency analysis (streams module docstring, contract (b)).
    _streams.join_pending()
    # the tape is single-use (like torch with retain_graph=False): sever it
    # so tensor<->node reference cycles die by refcount instead of waiting
    # for the cyclic GC (which let activation memory pile up between steps).
    # The node flag marks the tape consumed for every alias sharing the
    # node; the sentinel stamp additionally breaks the tensor->node
    # reference and guards the original tensors directly.
    for node in topo:
        node.severed = True
        for o in node.outs:
            o.grad_fn = _SEVERED
