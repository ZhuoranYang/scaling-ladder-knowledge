"""Minimal ctypes binding of libnccl.

Covers exactly what the distributed package needs: unique-id creation,
communicator init/destroy, and four collectives on the default
stream. No torch dependency; the library is located via ``$MT_NCCL_LIB``,
then the pip ``nvidia-nccl-cu*`` wheel (``site-packages/nvidia/nccl/lib``),
then the system linker cache.

Only the pieces in use are wrapped; every call checks its ``ncclResult_t``.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import os
import sys
from pathlib import Path

NCCL_UNIQUE_ID_BYTES = 128

ncclSuccess = 0

# ncclDataType_t (subset)
ncclInt8 = 0
ncclUint8 = 1
ncclInt32 = 2
ncclUint32 = 3
ncclInt64 = 4
ncclUint64 = 5
ncclFloat16 = 6
ncclFloat32 = 7
ncclFloat64 = 8

# ncclRedOp_t
ncclSum = 0
ncclProd = 1
ncclMax = 2
ncclMin = 3
ncclAvg = 4  # requires NCCL >= 2.10; not used by default

_DT_CODE = {
    "f16": ncclFloat16,
    "f32": ncclFloat32,
    "f64": ncclFloat64,
    "i32": ncclInt32,
    "i64": ncclInt64,
}


class NcclError(RuntimeError):
    pass


class NcclUniqueId(ctypes.Structure):
    _fields_ = [("internal", ctypes.c_char * NCCL_UNIQUE_ID_BYTES)]


_lib = None


def _candidates():
    env = os.environ.get("MT_NCCL_LIB")
    if env:
        yield env
    seen = set()
    for entry in sys.path:
        lib_dir = Path(entry) / "nvidia" / "nccl" / "lib"
        if lib_dir.is_dir() and lib_dir not in seen:
            seen.add(lib_dir)
            for so in sorted(lib_dir.glob("libnccl.so*")):
                yield str(so)
    found = ctypes.util.find_library("nccl")
    if found:
        yield found
    yield from ("libnccl.so.2", "libnccl.so")


def get_lib():
    """Load libnccl lazily (first use), configuring signatures."""
    global _lib
    if _lib is not None:
        return _lib
    errors = []
    for cand in _candidates():
        try:
            lib = ctypes.CDLL(cand)
            lib.ncclGetUniqueId
            _lib = lib
            break
        except (OSError, AttributeError) as e:
            errors.append(f"{cand}: {e}")
    if _lib is None:
        raise NcclError(
            "libnccl could not be loaded; set $MT_NCCL_LIB. Tried:\n  "
            + "\n  ".join(errors))
    _configure(_lib)
    return _lib


def _configure(lib):
    lib.ncclGetErrorString.restype = ctypes.c_char_p
    lib.ncclGetErrorString.argtypes = [ctypes.c_int]
    lib.ncclGetUniqueId.restype = ctypes.c_int
    lib.ncclGetUniqueId.argtypes = [ctypes.POINTER(NcclUniqueId)]
    lib.ncclCommInitRank.restype = ctypes.c_int
    lib.ncclCommInitRank.argtypes = [
        ctypes.POINTER(ctypes.c_void_p), ctypes.c_int, NcclUniqueId,
        ctypes.c_int,
    ]
    for name in ("ncclAllReduce", "ncclBroadcast", "ncclReduce",
                 "ncclReduceScatter", "ncclAllGather"):
        fn = getattr(lib, name)
        fn.restype = ctypes.c_int
        # (send, recv, count, dtype, [op/root], comm, stream) — set per call
    lib.ncclCommDestroy.restype = ctypes.c_int
    lib.ncclCommDestroy.argtypes = [ctypes.c_void_p]
    lib.ncclCommAbort.restype = ctypes.c_int
    lib.ncclCommAbort.argtypes = [ctypes.c_void_p]
    lib.ncclCommCount.restype = ctypes.c_int
    lib.ncclCommCount.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int)]
    lib.ncclCommUserRank.restype = ctypes.c_int
    lib.ncclCommUserRank.argtypes = [
        ctypes.c_void_p, ctypes.POINTER(ctypes.c_int)]


def check(result: int, what: str = ""):
    if result != ncclSuccess:
        lib = get_lib()
        msg = lib.ncclGetErrorString(result).decode()
        raise NcclError(f"{what or 'NCCL call'} failed: {msg} ({result})")


def dtype_code(dtype_name: str) -> int:
    code = _DT_CODE.get(dtype_name)
    if code is None:
        raise NcclError(
            f"unsupported NCCL dtype {dtype_name!r} (supported: f16/f32/f64/i32/i64)")
    return code


class NcclComm:
    """An ncclComm_t handle plus its rank/world metadata."""

    def __init__(self, rank: int, world_size: int):
        lib = get_lib()
        self._lib = lib
        self.handle = ctypes.c_void_p()
        self._rank = rank
        self._world = world_size

    def init_rank(self, uid: NcclUniqueId):
        check(self._lib.ncclCommInitRank(
            ctypes.byref(self.handle), self._world, uid, self._rank),
            "ncclCommInitRank")
        return self

    # -- collectives (in-place where NCCL allows it; stream 0 = the
    # default stream, ordered with every tl kernel launch) -----------------

    def _collective(self, name: str, send_ptr: int, recv_ptr: int,
                    count: int, dtype, op_or_root=None):
        fn = getattr(self._lib, name)
        dt = dtype_code(dtype.name if hasattr(dtype, "name") else dtype)
        args = [ctypes.c_void_p(send_ptr), ctypes.c_void_p(recv_ptr),
                ctypes.c_size_t(count), ctypes.c_int(dt)]
        if name in ("ncclAllReduce", "ncclReduce", "ncclReduceScatter"):
            args.append(ctypes.c_int(op_or_root))
        elif name == "ncclBroadcast":
            args.append(ctypes.c_int(op_or_root))
        args += [self.handle, ctypes.c_void_p(0)]
        check(fn(*args), name)

    def allreduce(self, send_ptr: int, recv_ptr: int, count: int, dtype,
                  op: int = ncclSum):
        self._collective("ncclAllReduce", send_ptr, recv_ptr, count, dtype,
                         op)

    def broadcast(self, send_ptr: int, recv_ptr: int, count: int, dtype,
                  root: int):
        self._collective("ncclBroadcast", send_ptr, recv_ptr, count, dtype,
                         root)

    def allgather(self, send_ptr: int, recv_ptr: int, count: int, dtype):
        self._collective("ncclAllGather", send_ptr, recv_ptr, count, dtype)

    def reduce_scatter(self, send_ptr: int, recv_ptr: int, recvcount: int,
                       dtype, op: int = ncclSum):
        self._collective("ncclReduceScatter", send_ptr, recv_ptr, recvcount,
                         dtype, op)

    def destroy(self):
        if self.handle:
            check(self._lib.ncclCommDestroy(self.handle), "ncclCommDestroy")
            self.handle = ctypes.c_void_p()


def get_unique_id() -> NcclUniqueId:
    lib = get_lib()
    uid = NcclUniqueId()
    check(lib.ncclGetUniqueId(ctypes.byref(uid)), "ncclGetUniqueId")
    return uid
