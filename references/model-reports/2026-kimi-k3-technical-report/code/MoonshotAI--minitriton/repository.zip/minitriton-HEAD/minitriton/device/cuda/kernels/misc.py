"""Assorted kernels of the device/cuda kernels package:
row/full/column reductions, argmax, embedding fwd/bwd, AdamW
(host + device-scalar graph-tail variants), gather/scatter/segment
ops, CSR spmm, searchsorted and bitonic sort.

All kernels assume the *last* dim of every operand is unit-stride (the
eager layer calls .contiguous() when that is not the case); other strides
are runtime i32 arguments.

``import minitriton as tl`` here resolves against the partially initialized
package (frontend/runtime names are exported before the eager layer is
imported), which is what makes the decorators work at import time.

NOTE: no ``from __future__ import annotations`` here — kernel parameter
annotations (``tl.constexpr``) must stay real objects for the DSL binder.
"""

import minitriton as tl
from ._common import (_row_block, col_sum_geometry,
                      launch_splitk_reduce)


@tl.kernel
def reduce_col_kernel(x_ptr, p_ptr, R, C, SLICE, BC: tl.constexpr,
                      EVEN_C: tl.constexpr):
    """Columnwise partial sums: p[rid, c] = sum of x[r, c] over rows
    [rid*SLICE, min(R, (rid+1)*SLICE)); x (R, C) contiguous f32-class,
    p (RCH, C) f32. Pointer-bump row walk + 4-way accumulators break the
    address recompute and the load-to-use dependence; a later
    splitk_reduce folds the RCH partial rows. EVEN_C (C % BC == 0) drops
    the column mask so the dist fragments take the 16B vector loads."""
    rid = tl.program_id(0)
    cid = tl.program_id(1)
    offs = cid * BC + tl.arange(0, BC)
    r0 = rid * SLICE
    r1 = tl.where(r0 + SLICE < R, r0 + SLICE, R)
    r4 = r1 - (r1 - (r0 + 1)) % 4
    if EVEN_C:
        a0 = tl.cast(tl.load(x_ptr + r0 * C + offs), tl.float32)
        a1 = a0 * 0.0
        a2 = a0 * 0.0
        a3 = a0 * 0.0
        base = x_ptr + (r0 + 1) * C + offs
        for r in range(r0 + 1, r4, 4):
            a0 = a0 + tl.cast(tl.load(base), tl.float32)
            a1 = a1 + tl.cast(tl.load(base + C), tl.float32)
            a2 = a2 + tl.cast(tl.load(base + 2 * C), tl.float32)
            a3 = a3 + tl.cast(tl.load(base + 3 * C), tl.float32)
            base = base + 4 * C
        base = x_ptr + r4 * C + offs
        for r in range(r4, r1):
            a0 = a0 + tl.cast(tl.load(base), tl.float32)
            base = base + C
        a0 = (a0 + a1) + (a2 + a3)
        tl.store(p_ptr + rid * C + offs, a0)
    else:
        m = offs < C
        a0 = tl.cast(tl.load(x_ptr + r0 * C + offs, mask=m, other=0.0),
                     tl.float32)
        a1 = a0 * 0.0
        a2 = a0 * 0.0
        a3 = a0 * 0.0
        base = x_ptr + (r0 + 1) * C + offs
        for r in range(r0 + 1, r4, 4):
            a0 = a0 + tl.cast(tl.load(base, mask=m, other=0.0), tl.float32)
            a1 = a1 + tl.cast(tl.load(base + C, mask=m, other=0.0),
                              tl.float32)
            a2 = a2 + tl.cast(tl.load(base + 2 * C, mask=m, other=0.0),
                              tl.float32)
            a3 = a3 + tl.cast(tl.load(base + 3 * C, mask=m, other=0.0),
                              tl.float32)
            base = base + 4 * C
        base = x_ptr + r4 * C + offs
        for r in range(r4, r1):
            a0 = a0 + tl.cast(tl.load(base, mask=m, other=0.0), tl.float32)
            base = base + C
        a0 = (a0 + a1) + (a2 + a3)
        tl.store(p_ptr + rid * C + offs, a0, mask=m)


def launch_reduce_col_sum(x, partials, out, R: int, C: int,
                          target_rows: int = 96):
    """out[c] = sum_r x[r, c] for contiguous (R, C); two deterministic
    passes (partials + splitk_reduce), no per-element atomics."""
    BC, nw, even, ncol, rch, slice_rows = col_sum_geometry(
        R, C, x.dtype.itemsize, target_rows)
    fl1 = reduce_col_kernel[(rch, ncol)](
        x._buffer_arg(), partials._buffer_arg(),
        R, C, slice_rows, BC=BC, EVEN_C=even, num_warps=nw)
    fl2 = launch_splitk_reduce(partials, rch, out, C)
    return fl1, fl2, partials, slice_rows, rch



# ---------------------------------------------------------------------------
# reductions
# ---------------------------------------------------------------------------

@tl.kernel
def reduce_row_kernel(x_ptr, out_ptr, C,
                      OP: tl.constexpr, OTHER: tl.constexpr,
                      SCALE: tl.constexpr, BLOCK: tl.constexpr,
                      CALC_F32: tl.constexpr):
    """One program per row: out[row] = reduce(x[row, :]) * SCALE.

    OP is a constexpr string ('sum'/'max'/'min'); OTHER = neutral element
    for masked lanes (constexpr so it materializes in the load dtype).
    CALC_F32: sub-fp32 float dtypes reduce in f32 (the warp shuffle is
    32-bit only, and bf16/f16 accumulation would be meaningless); the
    scalar store casts the result back to the output dtype."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=OTHER)
    if CALC_F32:
        x = tl.cast(x, tl.float32)
    if OP == "sum":
        r = tl.sum(x)
    elif OP == "max":
        r = tl.max(x)
    else:
        r = tl.min(x)
    tl.store(out_ptr + row, r * SCALE)


@tl.kernel
def reduce_full_stage1_kernel(x_ptr, part_ptr, N, nchunk,
                              OP: tl.constexpr, OTHER: tl.constexpr,
                              GRID: tl.constexpr, BLOCK: tl.constexpr,
                              CALC_F32: tl.constexpr):
    """Grid-stride stage 1: part[pid] = reduce over the program's chunks.

    Loop count nchunk = ceil(ceil(N/BLOCK) / GRID) is a runtime arg; the
    loop index decomposes into chunk addresses arithmetically. CALC_F32:
    sub-fp32 float dtypes reduce in f32 (see reduce_row_kernel)."""
    pid = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    acc = tl.load(x_ptr + pid * BLOCK + offs, mask=(pid * BLOCK + offs) < N,
                  other=OTHER)
    if CALC_F32:
        acc = tl.cast(acc, tl.float32)
    if OP == "sum":
        acc_s = tl.sum(acc)
    elif OP == "max":
        acc_s = tl.max(acc)
    else:
        acc_s = tl.min(acc)
    for i in range(1, nchunk):
        base = (pid + i * GRID) * BLOCK
        x = tl.load(x_ptr + base + offs, mask=(base + offs) < N, other=OTHER)
        if CALC_F32:
            x = tl.cast(x, tl.float32)
        if OP == "sum":
            acc_s = acc_s + tl.sum(x)
        elif OP == "max":
            mx = tl.max(x)
            acc_s = tl.where(mx > acc_s, mx, acc_s)
        else:
            mn = tl.min(x)
            acc_s = tl.where(mn < acc_s, mn, acc_s)
    tl.store(part_ptr + pid, acc_s)


def _neutral(op: str, dtype):
    """Neutral element for masked lanes, in the load dtype."""
    from ....frontend import types as t
    if dtype.is_int:
        return {"sum": 0, "max": t.SIGNED_INT_MIN[dtype.name],
                "min": t.SIGNED_INT_MAX[dtype.name]}[op]
    return {"sum": 0.0, "max": float("-inf"), "min": float("inf")}[op]


def launch_reduce_row(x, out, C: int, op: str, out_dtype):
    """x (R, C) contiguous rows -> out (R,)."""
    R = x.numel() // C if C else 0
    if R == 0:
        return
    other = _neutral(op, x.dtype)
    scale = 1 if x.dtype.is_int else 1.0
    block = _row_block(C)
    calc_f32 = x.dtype.is_float and x.dtype.itemsize < 4
    return reduce_row_kernel[(R,)](
        x._buffer_arg(), out._buffer_arg(), C,
        OP=op, OTHER=other, SCALE=scale, BLOCK=block,
        CALC_F32=calc_f32, num_warps=4)


def launch_reduce_full(x, out, op: str, out_dtype):
    """Full reduction to a 0-d/numel-1 tensor via two stages. Returns the
    two resolved fast-launch handles and the stage-1 scratch (the op-level
    plan cache reuses those across calls)."""
    N = x.numel()
    if N == 0:
        raise RuntimeError("cannot reduce an empty tensor")
    block = 1024
    nblocks = (N + block - 1) // block
    grid = min(nblocks, 8192)
    nchunk = (nblocks + grid - 1) // grid
    other = _neutral(op, x.dtype)
    calc_f32 = x.dtype.is_float and x.dtype.itemsize < 4
    from ....tensor import empty  # local import: avoid cycle
    part = empty((grid,), x.dtype, "cuda")
    fl1 = reduce_full_stage1_kernel[(grid,)](
        x._buffer_arg(), part._buffer_arg(),
        N, nchunk, OP=op, OTHER=other,
        GRID=grid, BLOCK=block, CALC_F32=calc_f32, num_warps=4)
    fl2 = launch_reduce_row(part, out, grid, op, out_dtype)
    return fl1, fl2, part, grid, nchunk



# ---------------------------------------------------------------------------
# embedding / cross_entropy / argmax
# ---------------------------------------------------------------------------

# Per-launch element budget: kernel addressing is i32, so a single launch
# may cover at most 2**31 - 1 elements; wider problems are split into
# row-range sub-launches by the launchers (row slices of the operands are
# passed as views), with guarded per-chunk kernels where the out-of-range
# address is data-driven (embedding weight rows, gathered/scattered rows,
# spmm dense-B rows) rather than program_id-driven.
_I32_ELEM_BUDGET = 2**31 - 1


def _i32_row_budget(C: int, itemsize: int) -> int:
    """Rows per launch: keep element offsets below 2**31 (i32 addressing)
    and the row-chunk view bases 16B-aligned (the vectorized load/store
    path assumes an aligned base; a row slice at an unaligned element
    offset would fault). Same discipline as ce.py's _ce_i32_row_budget."""
    align = 16 // itemsize
    budget = _I32_ELEM_BUDGET // C // align
    if budget == 0:
        raise NotImplementedError(
            f"row length {C} is too wide to chunk under i32 addressing")
    return budget * align

@tl.kernel
def embedding_kernel(w_ptr, idx_ptr, out_ptr, C, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    idx = tl.load(idx_ptr + row)
    offs = tl.arange(0, BLOCK)
    for c0 in range(0, C, BLOCK):
        m = (c0 + offs) < C
        w = tl.load(w_ptr + idx * C + c0 + offs, mask=m)
        tl.store(out_ptr + row * C + c0 + offs, w, mask=m)


@tl.kernel
def embedding_chunked_kernel(w_ptr, idx_ptr, out_ptr, C, V0, NV,
                             BLOCK: tl.constexpr):
    """embedding_kernel for one vocab row chunk [V0, V0+NV) of an
    over-budget weight (i32 addressing): rows whose idx falls outside the
    chunk neither load nor store (each chunk launch covers all R index
    rows; the chunk-relative row base idx*C then stays below 2**31)."""
    row = tl.program_id(0)
    idx = tl.load(idx_ptr + row + tl.zeros((BLOCK,), tl.int32)) - V0
    ok = (idx >= 0) & (idx < NV)
    offs = tl.arange(0, BLOCK)
    for c0 in range(0, C, BLOCK):
        m = ((c0 + offs) < C) & ok
        w = tl.load(w_ptr + idx * C + c0 + offs, mask=m)
        tl.store(out_ptr + row * C + c0 + offs, w, mask=m)


def launch_embedding(w, idx, out, C: int):
    R = idx.numel()
    if R == 0:
        return
    budget = _i32_row_budget(C, min(4, out.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep the out/idx element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_embedding(w, idx[r0:r1], out[r0:r1], C)
        return
    block = min(_row_block(C), 4096) if C <= 8192 else 4096
    V = w.numel() // C if C else 0
    wbudget = _i32_row_budget(C, w.dtype.itemsize)
    if V > wbudget:
        # over-budget weight: one guarded launch per vocab row chunk.
        for v0 in range(0, V, wbudget):
            v1 = min(v0 + wbudget, V)
            embedding_chunked_kernel[(R,)](
                w[v0:v1]._buffer_arg(), idx._buffer_arg(),
                out._buffer_arg(), C, v0, v1 - v0, BLOCK=block, num_warps=4)
        return
    embedding_kernel[(R,)](w._buffer_arg(), idx._buffer_arg(),
                           out._buffer_arg(), C, BLOCK=block, num_warps=4)



@tl.kernel
def argmax_row_kernel(x_ptr, out_ptr, C):
    """Scalar loop per row (correct, not fast; argmax is not on the
    benchmark hot path)."""
    row = tl.program_id(0)
    best = tl.load(x_ptr + row * C)
    bi = 0
    for j in range(1, C):
        v = tl.load(x_ptr + row * C + j)
        if v > best:
            best = v
            bi = j
    tl.store(out_ptr + row, bi)


def launch_argmax_row(x, out, C: int):
    R = x.numel() // C if C else 0
    if R == 0:
        return
    budget = _i32_row_budget(C, min(x.dtype.itemsize, 8))
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_argmax_row(x[r0:r1], out[r0:r1], C)
        return
    argmax_row_kernel[(R,)](x._buffer_arg(), out._buffer_arg(), C,
                            num_warps=4)



@tl.kernel
def embedding_backward_kernel(g_ptr, idx_ptr, dw_ptr, C, BLOCK: tl.constexpr):
    """dw[idx[row]] += g[row]  via red.global.add.f32 (tl.atomic_add)."""
    row = tl.program_id(0)
    idx = tl.load(idx_ptr + row)
    offs = tl.arange(0, BLOCK)
    for c0 in range(0, C, BLOCK):
        m = (c0 + offs) < C
        g = tl.load(g_ptr + row * C + c0 + offs, mask=m)
        tl.atomic_add(dw_ptr + idx * C + c0 + offs, g, mask=m)


@tl.kernel
def embedding_backward_chunked_kernel(g_ptr, idx_ptr, dw_ptr, C, V0, NV,
                                      BLOCK: tl.constexpr):
    """embedding_backward_kernel for one vocab row chunk [V0, V0+NV) of
    an over-budget dw (i32 addressing): rows whose idx falls outside the
    chunk contribute nothing (dw is zero-initialized; each chunk's
    atomics touch only its own rows)."""
    row = tl.program_id(0)
    idx = tl.load(idx_ptr + row + tl.zeros((BLOCK,), tl.int32)) - V0
    ok = (idx >= 0) & (idx < NV)
    offs = tl.arange(0, BLOCK)
    for c0 in range(0, C, BLOCK):
        m = ((c0 + offs) < C) & ok
        g = tl.load(g_ptr + row * C + c0 + offs, mask=m)
        tl.atomic_add(dw_ptr + idx * C + c0 + offs, g, mask=m)


def launch_embedding_backward(g, idx, dw, C: int):
    R = idx.numel()
    if R == 0:
        return
    budget = _i32_row_budget(C, min(4, g.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep the g/idx element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_embedding_backward(g[r0:r1], idx[r0:r1], dw, C)
        return
    block = min(_row_block(C), 4096) if C <= 8192 else 4096
    V = dw.numel() // C if C else 0
    vbudget = _i32_row_budget(C, dw.dtype.itemsize)
    if V > vbudget:
        # over-budget dw: one guarded launch per vocab row chunk.
        for v0 in range(0, V, vbudget):
            v1 = min(v0 + vbudget, V)
            embedding_backward_chunked_kernel[(R,)](
                g._buffer_arg(), idx._buffer_arg(),
                dw[v0:v1]._buffer_arg(), C, v0, v1 - v0, BLOCK=block,
                num_warps=4)
        return
    embedding_backward_kernel[(R,)](g._buffer_arg(), idx._buffer_arg(),
                                    dw._buffer_arg(), C, BLOCK=block,
                                    num_warps=4)


@tl.kernel
def embedding_backward_ds_kernel(g_ptr, idx_ptr, dw_ptr, R, C, V0,
                                 BLOCK: tl.constexpr):
    """Deterministic, fp64-quality embedding weight grad (opt-in,
    MT_EMBED_FP64): one program per vocab row v scans all R indices in a
    fixed serial order and accumulates the matching grad rows with
    TwoSum compensation (replaces the nondeterministic atomic
    scatter-add). V0 is the vocab row-chunk base: programs address the
    chunk-local dw view but match absolute indices (v + V0)."""
    v = tl.program_id(0)
    nb = tl.program_id(1)
    offs = nb * BLOCK + tl.arange(0, BLOCK)
    m = offs < C
    hi = tl.zeros((BLOCK,), tl.float32)
    lo = tl.zeros((BLOCK,), tl.float32)
    for r in range(0, R):
        i = tl.load(idx_ptr + r)
        gr = tl.load(g_ptr + r * C + offs, mask=m, other=0.0)
        take = gr * tl.cast(i == v + V0, tl.float32)
        s = hi + take
        z = s - hi
        err = (hi - (s - z)) + (take - z)
        lo = lo + err
        hi = s
    tl.store(dw_ptr + v * C + offs, hi + lo, mask=m)


def launch_embedding_backward_ds(g, idx, dw, C: int, V: int):
    R = idx.numel()
    if R == 0:
        return
    if R > _i32_row_budget(C, g.dtype.itemsize):
        # the per-vocab serial scan over all R grad rows cannot be
        # row-chunked without changing the compensated summation order;
        # fail loud rather than wrap the i32 row base.
        raise NotImplementedError(
            "embedding_backward_ds: >2**31-element grad rows are beyond "
            "the serial scan's i32 addressing; use the atomic embedding "
            "backward (MT_EMBED_FP64 off) for such shapes")
    block = 1024
    nb = (C + block - 1) // block
    vbudget = _i32_row_budget(C, dw.dtype.itemsize)
    if V > vbudget:
        # over-budget dw: one launch per vocab row chunk (V0 keeps the
        # index match absolute while dw stays chunk-local).
        for v0 in range(0, V, vbudget):
            v1 = min(v0 + vbudget, V)
            embedding_backward_ds_kernel[(v1 - v0, nb)](
                g._buffer_arg(), idx._buffer_arg(),
                dw[v0:v1]._buffer_arg(), R, C, v0, BLOCK=block,
                num_warps=4)
        return
    grid = (V, nb)
    embedding_backward_ds_kernel[grid](g._buffer_arg(), idx._buffer_arg(),
                                       dw._buffer_arg(), R, C, 0,
                                       BLOCK=block, num_warps=4)


@tl.kernel
def adamw_kernel(p_ptr, g_ptr, m_ptr, v_ptr, N, lr_t, wd_lr, b1, b1c, b2,
                 b2c, eps, s2, TORCH_EPS: tl.constexpr, BLOCK: tl.constexpr):
    """Fused AdamW step (decoupled weight decay, bias correction folded
    into lr_t/wd_lr on the host):
        m <- b1*m + (1-b1)*g ; v <- b2*v + (1-b2)*g^2
        p <- p - wd_lr*p - lr_t * m / (sqrt(v) + eps)

    TORCH_EPS (opt-in, MT_ADAMW_EPS): torch-exact eps placement —
    lr_t = lr/(1-b1^t), s2 = sqrt(1-b2^t), and the denominator is
    sqrt(v)/s2 + eps (the default folds s2 into lr_t, which scales the
    effective eps by 1/s2 vs torch)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    msk = offs < N
    p = tl.load(p_ptr + offs, mask=msk)
    g = tl.load(g_ptr + offs, mask=msk)
    mt = tl.load(m_ptr + offs, mask=msk)
    vt = tl.load(v_ptr + offs, mask=msk)
    mt = b1 * mt + b1c * g
    vt = b2 * vt + b2c * g * g
    if TORCH_EPS:
        p = p - wd_lr * p - lr_t * mt / (tl.sqrt(vt) / s2 + eps)
    else:
        p = p - wd_lr * p - lr_t * mt / (tl.sqrt(vt) + eps)
    tl.store(m_ptr + offs, mt, mask=msk)
    tl.store(v_ptr + offs, vt, mask=msk)
    tl.store(p_ptr + offs, p, mask=msk)


def launch_adamw(p, g, m, v, N: int, lr_t: float, wd_lr: float, b1: float,
                 b2: float, eps: float, torch_eps: bool = False,
                 s2: float = 1.0):
    block = 1024
    grid = ((N + block - 1) // block,)
    return adamw_kernel[grid](
        p._buffer_arg(), g._buffer_arg(), m._buffer_arg(),
        v._buffer_arg(), N, lr_t, wd_lr, b1, 1.0 - b1, b2,
        1.0 - b2, eps, s2, TORCH_EPS=torch_eps, BLOCK=block,
        num_warps=4)


# ---------------------------------------------------------------------------
# device-scalar optimizer variants (CUDA graph tail: lr/wd live in a small
# device buffer uploaded per step, clip factor and the finite gate are
# computed on-device from the norm accumulator — the whole step tail then
# replays with zero host syncs in the loop)
# ---------------------------------------------------------------------------

@tl.kernel
def clip_coef_kernel(total_ptr, sc_ptr, max_norm, eps):
    """sc[2] = clip factor, sc[3] = finite gate, from the norm sum-of-
    squares: clip = min(1, max_norm / (sqrt(total) + eps)), 0 when the
    total is non-finite (the skip-step gate; gate multiplies lr/wd in
    adamw_dev_kernel). Finite test: t*0 == 0 (inf/nan map to nan)."""
    total = tl.load(total_ptr)
    fin = total * 0.0 == 0.0
    gate = tl.where(fin, 1.0, 0.0)
    norm = tl.sqrt(total)
    clip = tl.where(norm + eps > max_norm, max_norm / (norm + eps), 1.0)
    tl.store(sc_ptr + 2, gate * clip)
    tl.store(sc_ptr + 3, gate)


@tl.kernel
def scale_dev_kernel(x_ptr, out_ptr, sc_ptr, N, SC_OFF: tl.constexpr,
                     BLOCK: tl.constexpr):
    """out = x * sc[SC_OFF] (the clip pass reading the on-device factor)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    msk = offs < N
    s = tl.load(sc_ptr + SC_OFF)
    tl.store(out_ptr + offs, tl.load(x_ptr + offs, mask=msk) * s, mask=msk)


@tl.kernel
def adamw_dev_kernel(p_ptr, g_ptr, m_ptr, v_ptr, N, sc_ptr, b1, b1c, b2,
                     b2c, eps, s2, TORCH_EPS: tl.constexpr,
                     S2_DEV: tl.constexpr, BLOCK: tl.constexpr):
    """adamw_kernel with lr_t/wd_lr read from the device scalar buffer and
    gated by sc[3] (0 on a non-finite step: moments and params then hold
    exactly, matching the host-side skip). TORCH_EPS: s2 comes from the
    launch arg (S2_DEV=0) or from sc[4] (S2_DEV=1 — the CUDA-graph path,
    where s2 changes per step and therefore must ride the buffer)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    msk = offs < N
    gate = tl.load(sc_ptr + 3)
    lr_t = tl.load(sc_ptr) * gate
    wd_lr = tl.load(sc_ptr + 1) * gate
    p = tl.load(p_ptr + offs, mask=msk)
    g = tl.load(g_ptr + offs, mask=msk)
    mt = tl.load(m_ptr + offs, mask=msk)
    vt = tl.load(v_ptr + offs, mask=msk)
    # gate in {0.0, 1.0}: gate*(update) + (1-gate)*hold — at gate 1 the
    # arithmetic is bit-identical to adamw_kernel's, at gate 0 the state
    # holds exactly (the non-finite skip)
    mt = gate * (b1 * mt + b1c * g) + (1.0 - gate) * mt
    vt = gate * (b2 * vt + b2c * g * g) + (1.0 - gate) * vt
    if TORCH_EPS:
        if S2_DEV:
            s2v = tl.load(sc_ptr + 4)
        else:
            s2v = s2
        p = p - wd_lr * p - lr_t * mt / (tl.sqrt(vt) / s2v + eps)
    else:
        p = p - wd_lr * p - lr_t * mt / (tl.sqrt(vt) + eps)
    tl.store(m_ptr + offs, mt, mask=msk)
    tl.store(v_ptr + offs, vt, mask=msk)
    tl.store(p_ptr + offs, p, mask=msk)


def launch_clip_coef(total, sc, max_norm: float, eps: float):
    return clip_coef_kernel[(1,)](total._buffer_arg(), sc._buffer_arg(),
                                  max_norm, eps, num_warps=1)


def launch_scale_dev(x, out, sc, sc_off: int):
    N = x.numel()
    block = 1024
    return scale_dev_kernel[((N + block - 1) // block,)](
        x._buffer_arg(), out._buffer_arg(), sc._buffer_arg(), N,
        SC_OFF=sc_off, BLOCK=block, num_warps=4)


def launch_adamw_dev(p, g, m, v, N: int, sc, b1: float, b2: float,
                     eps: float, torch_eps: bool = False, s2: float = 1.0,
                     s2_dev: bool = False):
    block = 1024
    grid = ((N + block - 1) // block,)
    return adamw_dev_kernel[grid](
        p._buffer_arg(), g._buffer_arg(), m._buffer_arg(),
        v._buffer_arg(), N, sc._buffer_arg(), b1, 1.0 - b1, b2,
        1.0 - b2, eps, s2, TORCH_EPS=torch_eps, S2_DEV=s2_dev,
        BLOCK=block, num_warps=4)



# ---------------------------------------------------------------------------

@tl.kernel
def gather_flat_kernel(x_ptr, idx_ptr, out_ptr, E, BLOCK: tl.constexpr):
    """out[e] = x[idx[e]]  (1D MatOff gather)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < E
    idx = tl.load(idx_ptr + offs, mask=m)
    tl.store(out_ptr + offs, tl.load(x_ptr + idx, mask=m), mask=m)


def launch_gather_flat(x, idx, out, E: int):
    if E == 0:
        return
    budget = _i32_row_budget(1, min(4, out.dtype.itemsize))
    if E > budget:
        # i32 addressing: keep the idx/out element offsets below 2**31
        # (the gathered addresses are i32 index values by construction).
        for e0 in range(0, E, budget):
            e1 = min(e0 + budget, E)
            launch_gather_flat(x, idx[e0:e1], out[e0:e1], e1 - e0)
        return
    gather_flat_kernel[((E + 511) // 512,)](x._buffer_arg(),
                                            idx._buffer_arg(),
                                            out._buffer_arg(), E, BLOCK=512,
                                            num_warps=4)


@tl.kernel
def scatter_flat_kernel(src_ptr, idx_ptr, out_ptr, E, BLOCK: tl.constexpr):
    """out[idx[e]] += src[e]  (1D MatOff atomic scatter)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < E
    idx = tl.load(idx_ptr + offs, mask=m)
    v = tl.load(src_ptr + offs, mask=m)
    tl.atomic_add(out_ptr + idx, v, mask=m)


def launch_scatter_flat(src, idx, out, E: int):
    if E == 0:
        return
    budget = _i32_row_budget(1, min(4, src.dtype.itemsize))
    if E > budget:
        # i32 addressing: keep the src/idx element offsets below 2**31
        # (the scattered addresses are i32 index values by construction).
        for e0 in range(0, E, budget):
            e1 = min(e0 + budget, E)
            launch_scatter_flat(src[e0:e1], idx[e0:e1], out, e1 - e0)
        return
    scatter_flat_kernel[((E + 511) // 512,)](src._buffer_arg(),
                                             idx._buffer_arg(),
                                             out._buffer_arg(), E, BLOCK=512,
                                             num_warps=4)


@tl.kernel
def gather_cols_kernel(x_ptr, idx_ptr, out_ptr, E, C, BLOCK: tl.constexpr):
    """out[r, j] = x[r, idx[r, j]]  (dim=1 gather, MatOff)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    for e0 in range(0, E, BLOCK):
        m = (e0 + offs) < E
        idx = tl.load(idx_ptr + row * E + e0 + offs, mask=m)
        v = tl.load(x_ptr + row * C + idx, mask=m)
        tl.store(out_ptr + row * E + e0 + offs, v, mask=m)


def launch_gather_cols(x, idx, out, E: int, C: int):
    R = idx.shape[0]
    if R == 0 or E == 0:
        return
    # x rows are C wide, idx/out rows E wide: the widest-row budget with
    # the smallest itemsize covers all three tensors' element offsets.
    budget = _i32_row_budget(max(C, E),
                             min(x.dtype.itemsize, 4, out.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_gather_cols(x[r0:r1], idx[r0:r1], out[r0:r1], E, C)
        return
    block = min(_row_block(E), 4096)
    gather_cols_kernel[(R,)](x._buffer_arg(), idx._buffer_arg(),
                             out._buffer_arg(), E, C, BLOCK=block,
                             num_warps=4)


@tl.kernel
def gather_rc_kernel(x_ptr, idx_ptr, out_ptr, D, C, BLOCK: tl.constexpr):
    """out[i, j] = x[idx[i, j], j]  (dim=0 gather, MatOff+SepOff combine)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    for d0 in range(0, D, BLOCK):
        m = (d0 + offs) < D
        idx = tl.load(idx_ptr + row * D + d0 + offs, mask=m)
        v = tl.load(x_ptr + idx * C + (d0 + offs), mask=m)
        tl.store(out_ptr + row * D + d0 + offs, v, mask=m)


@tl.kernel
def gather_rc_chunked_kernel(x_ptr, idx_ptr, out_ptr, D, C, X0, NX,
                             BLOCK: tl.constexpr):
    """gather_rc_kernel for one row chunk [X0, X0+NX) of an over-budget x
    (i32 addressing): lanes whose gathered row falls outside the chunk
    neither load nor store (the chunk-relative row base idx*C then stays
    below 2**31)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    for d0 in range(0, D, BLOCK):
        m = (d0 + offs) < D
        idx = tl.load(idx_ptr + row * D + d0 + offs, mask=m)
        ix = idx - X0
        mm = m & (ix >= 0) & (ix < NX)
        v = tl.load(x_ptr + ix * C + (d0 + offs), mask=mm)
        tl.store(out_ptr + row * D + d0 + offs, v, mask=mm)


def launch_gather_rc(x, idx, out, D: int, C: int):
    E = idx.shape[0]
    if E == 0 or D == 0:
        return
    budget = _i32_row_budget(D, min(4, out.dtype.itemsize))
    if E > budget:
        # i32 addressing: keep the idx/out element offsets below 2**31.
        for r0 in range(0, E, budget):
            r1 = min(r0 + budget, E)
            launch_gather_rc(x, idx[r0:r1], out[r0:r1], D, C)
        return
    block = min(_row_block(D), 4096)
    XR = x.numel() // C if C else 0
    xbudget = _i32_row_budget(C, x.dtype.itemsize)
    if XR > xbudget:
        # over-budget gather source: one guarded launch per x row chunk.
        for x0 in range(0, XR, xbudget):
            x1 = min(x0 + xbudget, XR)
            gather_rc_chunked_kernel[(E,)](
                x[x0:x1]._buffer_arg(), idx._buffer_arg(),
                out._buffer_arg(), D, C, x0, x1 - x0, BLOCK=block,
                num_warps=4)
        return
    gather_rc_kernel[(E,)](x._buffer_arg(), idx._buffer_arg(),
                           out._buffer_arg(), D, C, BLOCK=block,
                           num_warps=4)


@tl.kernel
def gather_cols_backward_kernel(g_ptr, idx_ptr, dx_ptr, E, C,
                                BLOCK: tl.constexpr):
    """dx[r, idx[r, j]] += g[r, j]  (MatOff atomic scatter)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    for e0 in range(0, E, BLOCK):
        m = (e0 + offs) < E
        idx = tl.load(idx_ptr + row * E + e0 + offs, mask=m)
        g = tl.load(g_ptr + row * E + e0 + offs, mask=m)
        tl.atomic_add(dx_ptr + row * C + idx, g, mask=m)


def launch_gather_cols_backward(g, idx, dx, E: int, C: int):
    R = idx.shape[0]
    if R == 0 or E == 0:
        return
    # g/idx rows are E wide, dx rows C wide (see launch_gather_cols).
    budget = _i32_row_budget(max(C, E),
                             min(g.dtype.itemsize, 4, dx.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31
        # (dx rows are disjoint across chunks, so the atomics keep their
        # per-element order).
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_gather_cols_backward(g[r0:r1], idx[r0:r1], dx[r0:r1],
                                        E, C)
        return
    block = min(_row_block(E), 4096)
    gather_cols_backward_kernel[(R,)](g._buffer_arg(), idx._buffer_arg(),
                                      dx._buffer_arg(), E, C, BLOCK=block,
                                      num_warps=4)


@tl.kernel
def gather_rc_backward_kernel(g_ptr, idx_ptr, dx_ptr, D, C,
                              BLOCK: tl.constexpr):
    """dx[idx[i, j], j] += g[i, j]  (MatOff atomic scatter)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    for d0 in range(0, D, BLOCK):
        m = (d0 + offs) < D
        idx = tl.load(idx_ptr + row * D + d0 + offs, mask=m)
        g = tl.load(g_ptr + row * D + d0 + offs, mask=m)
        tl.atomic_add(dx_ptr + idx * C + (d0 + offs), g, mask=m)


@tl.kernel
def gather_rc_backward_chunked_kernel(g_ptr, idx_ptr, dx_ptr, D, C, X0, NX,
                                      BLOCK: tl.constexpr):
    """gather_rc_backward_kernel for one row chunk [X0, X0+NX) of an
    over-budget dx (i32 addressing): lanes whose scattered row falls
    outside the chunk contribute nothing (dx is zero-initialized; each
    chunk's atomics touch only its own rows)."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    for d0 in range(0, D, BLOCK):
        m = (d0 + offs) < D
        idx = tl.load(idx_ptr + row * D + d0 + offs, mask=m)
        ix = idx - X0
        mm = m & (ix >= 0) & (ix < NX)
        g = tl.load(g_ptr + row * D + d0 + offs, mask=mm)
        tl.atomic_add(dx_ptr + ix * C + (d0 + offs), g, mask=mm)


def launch_gather_rc_backward(g, idx, dx, D: int, C: int):
    E = idx.shape[0]
    if E == 0 or D == 0:
        return
    budget = _i32_row_budget(D, min(4, g.dtype.itemsize))
    if E > budget:
        # i32 addressing: keep the g/idx element offsets below 2**31.
        for r0 in range(0, E, budget):
            r1 = min(r0 + budget, E)
            launch_gather_rc_backward(g[r0:r1], idx[r0:r1], dx, D, C)
        return
    block = min(_row_block(D), 4096)
    XR = dx.numel() // C if C else 0
    xbudget = _i32_row_budget(C, dx.dtype.itemsize)
    if XR > xbudget:
        # over-budget dx: one guarded launch per dx row chunk.
        for x0 in range(0, XR, xbudget):
            x1 = min(x0 + xbudget, XR)
            gather_rc_backward_chunked_kernel[(E,)](
                g._buffer_arg(), idx._buffer_arg(),
                dx[x0:x1]._buffer_arg(), D, C, x0, x1 - x0, BLOCK=block,
                num_warps=4)
        return
    gather_rc_backward_kernel[(E,)](g._buffer_arg(), idx._buffer_arg(),
                                    dx._buffer_arg(), D, C, BLOCK=block,
                                    num_warps=4)


@tl.kernel
def segment_reduce_kernel(v_ptr, rp_ptr, out_ptr,
                          OP: tl.constexpr, BLOCK: tl.constexpr):
    """out[r] = reduce(v[rp[r]:rp[r+1]]) — one program per CSR row, the
    segment walked in BLOCK chunks with a lane-wise carried accumulator
    (row reduction = the tl.reduce row primitives)."""
    r = tl.program_id(0)
    start = tl.load(rp_ptr + r)
    seg = tl.load(rp_ptr + r + 1) - start
    offs = tl.arange(0, BLOCK)
    if OP == "sum":
        acc = tl.zeros((BLOCK,), tl.float32)
        for k0 in range(0, seg, BLOCK):
            m = (k0 + offs) < seg
            acc = acc + tl.load(v_ptr + start + k0 + offs, mask=m, other=0.0)
        tl.store(out_ptr + r, tl.sum(acc))
    else:
        acc = tl.zeros((BLOCK,), tl.float32) + float("-inf")
        for k0 in range(0, seg, BLOCK):
            m = (k0 + offs) < seg
            v = tl.load(v_ptr + start + k0 + offs, mask=m, other=float("-inf"))
            acc = tl.where(v > acc, v, acc)
        tl.store(out_ptr + r, tl.max(acc))


def launch_segment_reduce(v, rp, out, R: int, op: str):
    if R == 0:
        return
    segment_reduce_kernel[(R,)](v._buffer_arg(), rp._buffer_arg(),
                                out._buffer_arg(), OP=op, BLOCK=1024,
                                num_warps=4)


@tl.kernel
def segment_sum_backward_kernel(g_ptr, rp_ptr, gv_ptr, BLOCK: tl.constexpr):
    """gv[k] = g[row(k)]  (segment-sum backward: broadcast the row grad)."""
    r = tl.program_id(0)
    start = tl.load(rp_ptr + r)
    seg = tl.load(rp_ptr + r + 1) - start
    gr = tl.load(g_ptr + r)
    offsb = gr + tl.zeros((BLOCK,), tl.float32)
    offs = tl.arange(0, BLOCK)
    for k0 in range(0, seg, BLOCK):
        m = (k0 + offs) < seg
        tl.store(gv_ptr + start + k0 + offs, offsb, mask=m)


@tl.kernel
def segment_max_backward_kernel(v_ptr, g_ptr, rp_ptr, gv_ptr,
                                BLOCK: tl.constexpr):
    """gv[k] = g[row(k)] where v[k] == row max else 0 (max backward; all
    tied maxima receive the grad, matching the max(dim) backward rule)."""
    r = tl.program_id(0)
    start = tl.load(rp_ptr + r)
    seg = tl.load(rp_ptr + r + 1) - start
    offs = tl.arange(0, BLOCK)
    acc = tl.zeros((BLOCK,), tl.float32) + float("-inf")
    for k0 in range(0, seg, BLOCK):
        m = (k0 + offs) < seg
        v = tl.load(v_ptr + start + k0 + offs, mask=m, other=float("-inf"))
        acc = tl.where(v > acc, v, acc)
    mx = tl.max(acc)
    gr = tl.load(g_ptr + r)
    offsb = gr + tl.zeros((BLOCK,), tl.float32)
    zb = tl.zeros((BLOCK,), tl.float32)
    for k0 in range(0, seg, BLOCK):
        m2 = (k0 + offs) < seg
        v2 = tl.load(v_ptr + start + k0 + offs, mask=m2, other=float("-inf"))
        tl.store(gv_ptr + start + k0 + offs,
                 tl.where(v2 == mx, offsb, zb), mask=m2)


def launch_segment_reduce_backward(v, g, rp, gv, R: int, op: str):
    if R == 0:
        return
    if op == "sum":
        segment_sum_backward_kernel[(R,)](g._buffer_arg(), rp._buffer_arg(),
                                          gv._buffer_arg(), BLOCK=1024,
                                          num_warps=4)
    else:
        segment_max_backward_kernel[(R,)](v._buffer_arg(), g._buffer_arg(),
                                          rp._buffer_arg(), gv._buffer_arg(),
                                          BLOCK=1024, num_warps=4)


@tl.kernel
def spmm_csr_kernel(rp_ptr, col_ptr, val_ptr, b_ptr, out_ptr, N,
                    BN: tl.constexpr):
    """out = A @ B with A in CSR (rp/col/val): one program per (row, N
    tile); the row's segment loop gathers B rows through a runtime-scalar
    base shift (correctness-first; wider tiles/matmul_tile are a possible
    optimization)."""
    r = tl.program_id(0)
    nb = tl.program_id(1)
    offs = nb * BN + tl.arange(0, BN)
    nm = offs < N
    start = tl.load(rp_ptr + r)
    end = tl.load(rp_ptr + r + 1)
    acc = tl.zeros((BN,), tl.float32)
    for k in range(start, end):
        c = tl.load(col_ptr + k)
        w = tl.load(val_ptr + k)
        brow = tl.load(b_ptr + c * N + offs, mask=nm, other=0.0)
        acc = acc + w * brow
    tl.store(out_ptr + r * N + offs, acc, mask=nm)


@tl.kernel
def spmm_csr_bchunked_kernel(rp_ptr, col_ptr, val_ptr, b_ptr, out_ptr, N,
                             B0, NB, ACC: tl.constexpr, BN: tl.constexpr):
    """spmm_csr_kernel for one row chunk [B0, B0+NB) of an over-budget
    dense B (i32 addressing): nonzeros whose B row falls outside the
    chunk contribute exactly zero (the masked load yields other=0.0);
    the first chunk stores, later chunks accumulate — kernel launches on
    one stream are serial, so the cross-chunk sum order is fixed."""
    r = tl.program_id(0)
    nb = tl.program_id(1)
    offs = nb * BN + tl.arange(0, BN)
    nm = offs < N
    start = tl.load(rp_ptr + r)
    end = tl.load(rp_ptr + r + 1)
    acc = tl.zeros((BN,), tl.float32)
    zb = tl.zeros((BN,), tl.int32)
    for k in range(start, end):
        c = tl.load(col_ptr + k)
        w = tl.load(val_ptr + k)
        inb = ((zb + (c - B0)) >= 0) & ((zb + (c - B0)) < NB)
        brow = tl.load(b_ptr + (c - B0) * N + offs, mask=nm & inb,
                       other=0.0)
        acc = acc + w * brow
    if ACC:
        tl.atomic_add(out_ptr + r * N + offs, acc, mask=nm)
    else:
        tl.store(out_ptr + r * N + offs, acc, mask=nm)


def launch_spmm_csr(rp, col, val, b, out, R: int, N: int):
    if R == 0 or N == 0:
        return
    # rp is (R+1,): max(N, 2) keeps its offsets under the budget too.
    budget = _i32_row_budget(max(N, 2), min(4, out.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep the out/rp element offsets below 2**31
        # (col/val are indexed by absolute i32 rp values throughout).
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_spmm_csr(rp[r0:r1 + 1], col, val, b, out[r0:r1],
                            r1 - r0, N)
        return
    grid = (R, (N + 127) // 128)
    KR = b.numel() // N
    bbudget = _i32_row_budget(N, b.dtype.itemsize)
    if KR > bbudget:
        # over-budget dense B: one guarded launch per B row chunk, store
        # then accumulate.
        for b0 in range(0, KR, bbudget):
            b1 = min(b0 + bbudget, KR)
            spmm_csr_bchunked_kernel[grid](
                rp._buffer_arg(), col._buffer_arg(), val._buffer_arg(),
                b[b0:b1]._buffer_arg(), out._buffer_arg(), N, b0, b1 - b0,
                ACC=b0 > 0, BN=128, num_warps=4)
        return
    spmm_csr_kernel[grid](rp._buffer_arg(), col._buffer_arg(),
                          val._buffer_arg(), b._buffer_arg(),
                          out._buffer_arg(), N, BN=128, num_warps=4)


@tl.kernel
def spmm_csr_backward_val_kernel(g_ptr, rp_ptr, col_ptr, b_ptr, dv_ptr, N,
                                 BT: tl.constexpr):
    """dval[k] = <g[row(k)], B[col[k]]>  (full-row dot; N <= 8192)."""
    r = tl.program_id(0)
    start = tl.load(rp_ptr + r)
    end = tl.load(rp_ptr + r + 1)
    offs = tl.arange(0, BT)
    nm = offs < N
    grow = tl.load(g_ptr + r * N + offs, mask=nm, other=0.0)
    for k in range(start, end):
        c = tl.load(col_ptr + k)
        brow = tl.load(b_ptr + c * N + offs, mask=nm, other=0.0)
        tl.store(dv_ptr + k, tl.sum(grow * brow))


@tl.kernel
def spmm_csr_backward_val_bchunked_kernel(g_ptr, rp_ptr, col_ptr, b_ptr,
                                          dv_ptr, N, B0, NB,
                                          BT: tl.constexpr):
    """spmm_csr_backward_val_kernel for one row chunk [B0, B0+NB) of an
    over-budget dense B (i32 addressing): only nonzeros whose B row is in
    the chunk compute and store their dv element (each k is stored by
    exactly one chunk launch)."""
    r = tl.program_id(0)
    start = tl.load(rp_ptr + r)
    end = tl.load(rp_ptr + r + 1)
    offs = tl.arange(0, BT)
    nm = offs < N
    grow = tl.load(g_ptr + r * N + offs, mask=nm, other=0.0)
    for k in range(start, end):
        c = tl.load(col_ptr + k)
        brow = tl.zeros((BT,), tl.float32)
        if ((c - B0) >= 0) & ((c - B0) < NB):
            brow = tl.load(b_ptr + (c - B0) * N + offs, mask=nm, other=0.0)
            tl.store(dv_ptr + k, tl.sum(grow * brow))


@tl.kernel
def spmm_csr_backward_dense_kernel(g_ptr, rp_ptr, col_ptr, val_ptr, db_ptr,
                                   N, BN: tl.constexpr):
    """dB[col[k]] += val[k] * g[row(k)]  (atomic row scatter; = Aᵀ @ g)."""
    r = tl.program_id(0)
    nb = tl.program_id(1)
    offs = nb * BN + tl.arange(0, BN)
    nm = offs < N
    grow = tl.load(g_ptr + r * N + offs, mask=nm, other=0.0)
    start = tl.load(rp_ptr + r)
    end = tl.load(rp_ptr + r + 1)
    for k in range(start, end):
        c = tl.load(col_ptr + k)
        w = tl.load(val_ptr + k)
        tl.atomic_add(db_ptr + c * N + offs, w * grow, mask=nm)


@tl.kernel
def spmm_csr_backward_dense_bchunked_kernel(g_ptr, rp_ptr, col_ptr, val_ptr,
                                            db_ptr, N, B0, NB,
                                            BN: tl.constexpr):
    """spmm_csr_backward_dense_kernel for one row chunk [B0, B0+NB) of an
    over-budget dB (i32 addressing): nonzeros whose dB row falls outside
    the chunk contribute nothing (dB is zero-initialized; each chunk's
    atomics touch only its own rows)."""
    r = tl.program_id(0)
    nb = tl.program_id(1)
    offs = nb * BN + tl.arange(0, BN)
    nm = offs < N
    grow = tl.load(g_ptr + r * N + offs, mask=nm, other=0.0)
    start = tl.load(rp_ptr + r)
    end = tl.load(rp_ptr + r + 1)
    zb = tl.zeros((BN,), tl.int32)
    for k in range(start, end):
        c = tl.load(col_ptr + k)
        w = tl.load(val_ptr + k)
        inb = ((zb + (c - B0)) >= 0) & ((zb + (c - B0)) < NB)
        tl.atomic_add(db_ptr + (c - B0) * N + offs, w * grow,
                      mask=nm & inb)


def launch_spmm_csr_backward_val(g, rp, col, b, dv, R: int, N: int, nnz: int):
    if nnz == 0:
        return
    budget = _i32_row_budget(max(N, 2), min(4, g.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep the g/rp element offsets below 2**31 (dv
        # is indexed by absolute i32 nonzero positions throughout).
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_spmm_csr_backward_val(g[r0:r1], rp[r0:r1 + 1], col, b,
                                         dv, r1 - r0, N, nnz)
        return
    block = _row_block(N)
    KR = b.numel() // N
    bbudget = _i32_row_budget(N, b.dtype.itemsize)
    if KR > bbudget:
        # over-budget dense B: one guarded launch per B row chunk.
        for b0 in range(0, KR, bbudget):
            b1 = min(b0 + bbudget, KR)
            spmm_csr_backward_val_bchunked_kernel[(R,)](
                g._buffer_arg(), rp._buffer_arg(), col._buffer_arg(),
                b[b0:b1]._buffer_arg(), dv._buffer_arg(), N, b0, b1 - b0,
                BT=block, num_warps=4)
        return
    spmm_csr_backward_val_kernel[(R,)](g._buffer_arg(), rp._buffer_arg(),
                                       col._buffer_arg(), b._buffer_arg(),
                                       dv._buffer_arg(), N, BT=block,
                                       num_warps=4)


def launch_spmm_csr_backward_dense(g, rp, col, val, db, R: int, N: int):
    if R == 0 or N == 0:
        return
    budget = _i32_row_budget(max(N, 2), min(4, g.dtype.itemsize))
    if R > budget:
        # i32 addressing: keep the g/rp element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_spmm_csr_backward_dense(g[r0:r1], rp[r0:r1 + 1], col,
                                           val, db, r1 - r0, N)
        return
    grid = (R, (N + 127) // 128)
    KR = db.numel() // N
    bbudget = _i32_row_budget(N, db.dtype.itemsize)
    if KR > bbudget:
        # over-budget dB: one guarded launch per dB row chunk.
        for b0 in range(0, KR, bbudget):
            b1 = min(b0 + bbudget, KR)
            spmm_csr_backward_dense_bchunked_kernel[grid](
                g._buffer_arg(), rp._buffer_arg(), col._buffer_arg(),
                val._buffer_arg(), db[b0:b1]._buffer_arg(), N, b0,
                b1 - b0, BN=128, num_warps=4)
        return
    spmm_csr_backward_dense_kernel[grid](
        g._buffer_arg(), rp._buffer_arg(), col._buffer_arg(),
        val._buffer_arg(), db._buffer_arg(), N, BN=128, num_warps=4)


# ---------------------------------------------------------------------------
# searchsorted / coo_sort_by_key
# ---------------------------------------------------------------------------

@tl.kernel
def searchsorted_kernel(a_ptr, v_ptr, out_ptr, V, N,
                        SIDE: tl.constexpr, ITERS: tl.constexpr,
                        BLOCK: tl.constexpr):
    """out[e] = first index i in [0, N] with a[i] >= v[e] (side='left') or
    a[i] > v[e] (side='right'); a sorted ascending. Per-lane binary search
    through MatOff gathers (ITERS = bit_length(N) + 1 always converges).
    The probe is masked to mid < N and converged lanes (lo == hi) stop
    updating, so out-of-bounds lanes never move the answer."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < V
    v = tl.load(v_ptr + offs, mask=m)
    lo = tl.zeros((BLOCK,), tl.int32)
    hi = tl.zeros((BLOCK,), tl.int32) + N
    for _ in range(ITERS):
        active = lo < hi
        mid = lo + (hi - lo) // 2
        am = tl.load(a_ptr + mid, mask=mid < N)
        if SIDE == "left":
            go_right = am < v
        else:
            go_right = am <= v
        lo = tl.where(active & go_right, mid + 1, lo)
        hi = tl.where(active & ~go_right, mid, hi)
    tl.store(out_ptr + offs, lo, mask=m)


def launch_searchsorted(a, v, out, V: int, N: int, side: str):
    if V == 0:
        return
    iters = max(1, N.bit_length() + 1)
    searchsorted_kernel[((V + 255) // 256,)](a._buffer_arg(), v._buffer_arg(),
                                             out._buffer_arg(), V, N,
                                             SIDE=side, ITERS=iters, BLOCK=256,
                                             num_warps=4)


@tl.kernel
def bitonic_pad_kernel(k_ptr, v_ptr, ks_ptr, vs_ptr, N, N2, BIG,
                       BLOCK: tl.constexpr):
    """ks[i] = k[i] (i < N) else BIG; vs[i] = v[i] (i < N) else -1."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    k = tl.load(k_ptr + offs, mask=m, other=BIG)
    val = tl.load(v_ptr + offs, mask=m, other=-1)
    # ks/vs hold N2 <= grid*BLOCK elements: mask the stores (N2 >= 256
    # makes this a no-op; N <= 128 writes (256-N2)*4B past each buffer
    # without it, corrupting whatever pool allocations follow)
    sm = offs < N2
    tl.store(ks_ptr + offs, k, mask=sm)
    tl.store(vs_ptr + offs, val, mask=sm)


@tl.kernel
def bitonic_step_kernel(k_ptr, v_ptr, id_ptr, N2, KK, JJ,
                        BP: tl.constexpr):
    """One (k, j) substep of a full bitonic sort over N2 (pow2) entries with
    an i32/f32 key and a payload that rides with the key. Pair-space threads:
    element index i = 2*p - p % j  (j pow2, so the j-bit of i is clear) and
    partner i ^ j = i + j. Direction: ascending iff ((i % (2k)) < k)."""
    pid = tl.program_id(0)
    offs = pid * BP + tl.arange(0, BP)
    pmask = offs < (N2 // 2)
    p = tl.load(id_ptr + offs, mask=pmask)
    i = 2 * p - p % JJ
    jpn = i + JJ
    ki = tl.load(k_ptr + i, mask=pmask)
    kj = tl.load(k_ptr + jpn, mask=pmask)
    ascend = (i % (2 * KK)) < KK
    swap = (ascend & (ki > kj)) | (~ascend & (ki < kj))
    tl.store(k_ptr + i, tl.where(swap, kj, ki), mask=pmask)
    tl.store(k_ptr + jpn, tl.where(swap, ki, kj), mask=pmask)
    vi = tl.load(v_ptr + i, mask=pmask)
    vj = tl.load(v_ptr + jpn, mask=pmask)
    tl.store(v_ptr + i, tl.where(swap, vj, vi), mask=pmask)
    tl.store(v_ptr + jpn, tl.where(swap, vi, vj), mask=pmask)


def launch_bitonic_sort(k_pad, v_pad, id_buf, N2: int):
    """In-place bitonic sort of k_pad/v_pad (both length N2, pow2 >= 2)."""
    pairs = N2 // 2
    grid = ((pairs + 255) // 256,)
    kk = 2
    while kk <= N2:
        jj = kk // 2
        while jj > 0:
            bitonic_step_kernel[grid](k_pad._buffer_arg(), v_pad._buffer_arg(),
                                      id_buf._buffer_arg(), N2, kk, jj,
                                      BP=256, num_warps=4)
            jj //= 2
        kk *= 2


def launch_bitonic_pad(k, v, ks, vs, N: int, BIG: int, N2: int):
    bitonic_pad_kernel[((N2 + 255) // 256,)](k._buffer_arg(), v._buffer_arg(),
                                             ks._buffer_arg(), vs._buffer_arg(),
                                             N, N2, BIG, BLOCK=256,
                                             num_warps=4)


__all__ = [
    "reduce_col_kernel",
    "launch_reduce_col_sum",
    "reduce_row_kernel",
    "reduce_full_stage1_kernel",
    "_neutral",
    "launch_reduce_row",
    "launch_reduce_full",
    "embedding_kernel",
    "launch_embedding",
    "argmax_row_kernel",
    "launch_argmax_row",
    "embedding_backward_kernel",
    "launch_embedding_backward",
    "embedding_backward_ds_kernel",
    "launch_embedding_backward_ds",
    "adamw_kernel",
    "launch_adamw",
    "clip_coef_kernel",
    "scale_dev_kernel",
    "adamw_dev_kernel",
    "launch_clip_coef",
    "launch_scale_dev",
    "launch_adamw_dev",
    "gather_flat_kernel",
    "launch_gather_flat",
    "scatter_flat_kernel",
    "launch_scatter_flat",
    "gather_cols_kernel",
    "launch_gather_cols",
    "gather_rc_kernel",
    "launch_gather_rc",
    "gather_cols_backward_kernel",
    "launch_gather_cols_backward",
    "gather_rc_backward_kernel",
    "launch_gather_rc_backward",
    "segment_reduce_kernel",
    "launch_segment_reduce",
    "segment_sum_backward_kernel",
    "segment_max_backward_kernel",
    "launch_segment_reduce_backward",
    "spmm_csr_kernel",
    "launch_spmm_csr",
    "spmm_csr_backward_val_kernel",
    "spmm_csr_backward_dense_kernel",
    "launch_spmm_csr_backward_val",
    "launch_spmm_csr_backward_dense",
    "searchsorted_kernel",
    "launch_searchsorted",
    "bitonic_pad_kernel",
    "bitonic_step_kernel",
    "launch_bitonic_sort",
    "launch_bitonic_pad",
]
