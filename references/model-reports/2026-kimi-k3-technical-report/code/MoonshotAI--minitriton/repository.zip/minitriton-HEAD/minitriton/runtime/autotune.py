"""Autotuning: ``@tl.autotune(configs, key)`` + ``do_bench`` timing.

``do_bench`` mirrors triton's: CUDA-event timing with warmup and an
L2-flushing memset between reps (the flush buffer is larger than the L2).
The autotuner measures every config with ``do_bench`` on first use of a
key tuple, keeps the best in memory, and persists choices to
``~/.minitriton/cache/autotune/``.
"""

from __future__ import annotations

import hashlib
import json
import statistics
from pathlib import Path

from .buffer import get_device
from .cache import cache_root, codegen_fingerprint
from .cuda_driver import CaptureError, Event

# Flush L2 with a buffer comfortably larger than the part's cache.
_FLUSH_BYTES = 128 * 1024 * 1024

_flush_ptr: int | None = None


def _flush_buffer() -> int:
    global _flush_ptr
    if _flush_ptr is None:
        _flush_ptr = get_device().alloc(_FLUSH_BYTES)
    return _flush_ptr


def do_bench(fn, warmup: int = 5, rep: int = 20, return_mode: str = "median") -> float:
    """Time fn() in milliseconds (CUDA events, L2 flushed before each rep).

    The same helper times minitriton kernels and torch callables in
    benchmarks/, so both sides share one measurement methodology.
    """
    from .streams import default_pool
    dev = get_device()
    flush = _flush_buffer()
    for _ in range(warmup):
        fn()
    dev.synchronize()
    pool = default_pool()
    times = []
    for _ in range(rep):
        dev.memset32(flush, 0, _FLUSH_BYTES // 4)
        # pooled events (record on acquisition), recycled after the read —
        # raw Event() handles here would leak by the thousands per
        # autotune sweep (Event has no cuEventDestroy)
        ev0 = pool.record(0)
        fn()
        ev1 = pool.record(0)
        dev.synchronize()
        times.append(Event.elapsed_ms(ev0, ev1))
        pool.recycle(ev0)
        pool.recycle(ev1)
    if return_mode == "mean":
        return statistics.mean(times)
    return statistics.median(times)


# Tuning-policy version: mixed into the disk-cache key so picks made by an
# older policy re-tune.
TUNE_VERSION = "3"


def _encode_cfg_value(v):
    """JSON has no tuple: mark tuple config values so _load can restore
    the exact in-memory types — a decoded list would never compare equal
    to the tuple inside cfg.key(), making every disk entry a permanent
    miss (full re-tune in every process)."""
    if isinstance(v, tuple):
        return {"__mt_tuple__": [_encode_cfg_value(x) for x in v]}
    if isinstance(v, list):
        return [_encode_cfg_value(x) for x in v]
    return v


def _decode_cfg_value(v):
    if isinstance(v, dict) and set(v) == {"__mt_tuple__"}:
        return tuple(_decode_cfg_value(x) for x in v["__mt_tuple__"])
    if isinstance(v, list):
        return [_decode_cfg_value(x) for x in v]
    return v


class Config:
    """One autotune candidate: constexpr overrides + num_warps."""

    def __init__(self, kwargs: dict, num_warps: int = 4):
        self.kwargs = dict(kwargs)
        self.num_warps = num_warps

    def key(self):
        return (tuple(sorted(self.kwargs.items())), self.num_warps)

    def __repr__(self):
        return f"Config({self.kwargs}, num_warps={self.num_warps})"


class Autotuner:
    def __init__(self, kernel, configs: list[Config], key: list[str],
                 extra_key: tuple = ()):
        if not configs:
            raise ValueError("autotune needs at least one config")
        self.kernel = kernel
        self.configs = configs
        self.key_names = list(key)
        # instance-scoped salt mixed into every kvals (mem/disk): the
        # launchers build one Autotuner per (strides, trans, dtypes)
        # variant, but the vanilla (M, N, K) key collapses those variants
        # onto one disk entry — a config valid for one variant (e.g.
        # bf16-staged smem) can be invalid for another (f32-staged
        # doubles the tile) or take a different staging path
        self._extra = tuple(extra_key)
        # positional indices of the key args, for dict-free kval extraction
        # on the launch fast path
        params = list(kernel.sig.parameters)
        self._key_idx = tuple(params.index(k) for k in self.key_names)
        self._mem: dict = {}
        self._fast: dict = {}
        self._disk_dir = cache_root() / "autotune"
        self._disk_dir.mkdir(parents=True, exist_ok=True)

    def _disk_path(self, kvals: tuple) -> Path:
        h = hashlib.sha256()
        h.update(codegen_fingerprint().encode())
        h.update(TUNE_VERSION.encode())
        h.update(self.kernel.src.encode())
        # the config space itself: extending a kernel's candidate list must
        # re-tune cached shapes (a cached best still present in the new
        # list would otherwise win without facing the new candidates)
        h.update(repr(sorted(c.key() for c in self.configs)).encode())
        h.update(repr(kvals).encode())
        return self._disk_dir / f"{h.hexdigest()[:24]}.json"

    def launch(self, kernel, grid, args, num_warps, launch_kwargs):
        # Fast path: after the first (tuned) launch for a given
        # (arg structure, launch kwargs, key values, RESOLVED grid,
        # captured globals), skip bind/compile/tune. Everything the
        # launch depends on must be IN the key — _args_key alone misses
        # three things: keyword constexprs (BIAS selects a different
        # cubin), the resolved grid (grid lambdas close over launch-site
        # state like bmm's batch count), and captured globals. So the
        # fast path first resolves the config (mem hit only — a miss
        # falls to the full path, which tunes/loads and then records the
        # fast entry) and computes g = grid(bound).
        from ..frontend.code_generator import (
            _args_key, _FastLaunch, _kw_key,
        )
        key = None
        cfg = None
        g = None
        try:
            akey = _args_key(args, kernel._ce_positions())
            kvals = tuple(
                args[i] if i < len(args) else launch_kwargs[nm]
                for i, nm in zip(self._key_idx, self.key_names))
            if self._extra:
                kvals = kvals + self._extra
            cfg = self._mem.get(kvals)
            if cfg is not None:
                bound = dict(zip(kernel.sig.parameters, args))
                bound.update(launch_kwargs)
                bound.update(cfg.kwargs)
                g = grid(bound) if callable(grid) else grid
                key = (akey, _kw_key(launch_kwargs), kvals, tuple(g),
                       kernel._sample_globals())
        except (TypeError, IndexError, KeyError, AttributeError):
            key = None
            cfg = None
        if key is not None:
            fl = self._fast.get(key)
            if fl is not None:
                fl(args)
                return
        if cfg is None:
            # full path: bind, resolve the config (mem/disk/tune), compile
            bound = dict(zip(kernel.sig.parameters, args))
            bound.update(launch_kwargs)
            kvals = tuple(bound.get(k) for k in self.key_names)
            if self._extra:
                kvals = kvals + self._extra
            cfg = self._mem.get(kvals)
            if cfg is None:
                cfg = self._load(kvals)
            if cfg is None:
                cfg = self._tune(grid, args, launch_kwargs, kvals)
            ck, values = kernel.compile_with(args, cfg.kwargs,
                                             cfg.num_warps, launch_kwargs)
            bound.update(cfg.kwargs)
            g = grid(bound) if callable(grid) else grid
            if key is None:
                try:
                    key = (_args_key(args, kernel._ce_positions()),
                           _kw_key(launch_kwargs), kvals, tuple(g),
                           kernel._sample_globals())
                except TypeError:
                    key = None
        else:
            ck, values = kernel.compile_with(args, cfg.kwargs,
                                             cfg.num_warps, launch_kwargs)
        if key is not None and all(
                b[0] == "constexpr" or i < len(args)
                for i, b in enumerate(ck.bindings)):
            fl = _FastLaunch(ck, tuple(g), ck.bindings, values)
            self._fast[key] = fl
            fl(args)
            return
        ck.launch(tuple(g), tuple(values))

    def _load(self, kvals: tuple):
        path = self._disk_path(kvals)
        if not path.is_file():
            return None
        try:
            d = json.loads(path.read_text())
            cfg = Config({k: _decode_cfg_value(v)
                          for k, v in d["kwargs"].items()}, d["num_warps"])
            if cfg.key() not in [c.key() for c in self.configs]:
                return None  # config list changed; re-tune
            self._mem[kvals] = cfg
            return cfg
        except Exception:
            return None

    def _save(self, kvals: tuple, cfg: Config):
        try:
            self._disk_path(kvals).write_text(json.dumps({
                "kernel": self.kernel.name,
                "key": repr(kvals),
                "kwargs": {k: _encode_cfg_value(v)
                           for k, v in cfg.kwargs.items()},
                "num_warps": cfg.num_warps,
            }))
        except Exception:
            pass

    def _tune(self, grid, args, launch_kwargs, kvals) -> Config:
        def measure(cfg):
            ck, values = self.kernel.compile_with(
                args, cfg.kwargs, cfg.num_warps, launch_kwargs)
            bound = dict(zip(self.kernel.sig.parameters, values))
            bound.update(cfg.kwargs)
            g = grid(bound) if callable(grid) else grid
            fn = lambda: ck.launch(tuple(g), tuple(values))
            return do_bench(fn)

        timings = []  # (ms_round1, cfg)
        for cfg in self.configs:
            try:
                ms = measure(cfg)
            except CaptureError:
                raise  # tuning during graph capture is illegal, not a
                # config problem — don't misreport "no valid config"
            except Exception as e:
                import os
                if os.environ.get("MT_AUTOTUNE_DEBUG"):
                    import traceback
                    traceback.print_exc()
                continue  # invalid config (smem overflow, bad tile, ...)
            timings.append((ms, cfg))
        if not timings:
            raise RuntimeError(
                f"autotune: no valid config for {self.kernel.name} "
                f"at key={kvals}")
        # A single timing round can crown a config that only won on a
        # clock/contention blip — the disk cache then pins the bad pick
        # for every later session.
        # Policy: round 1 (table order) + round 2 (descending round-1
        # time, so the second pass is ordered by what just ran hot, not
        # by table slot) SELECT the top-3 leaders by their best round;
        # the winner is then decided ONLY by interleaved round-robin
        # rounds among the leaders (min of 4). Mixing the sweep rounds
        # into the winner's score rewards early (cool-GPU) table slots —
        # the leader rounds are the only drift-fair measurements.
        timings.sort(key=lambda t: t[0])
        select_ms = {cfg.key(): ms for ms, cfg in timings}
        for _, cfg in reversed(timings):
            try:
                ms2 = measure(cfg)
            except Exception:
                continue
            if ms2 < select_ms[cfg.key()]:
                select_ms[cfg.key()] = ms2
        leaders = sorted(timings, key=lambda t: select_ms[t[1].key()])
        leaders = [cfg for _, cfg in leaders[:3]]
        score = {}
        for _ in range(4):
            for cfg in leaders:
                try:
                    ms2 = measure(cfg)
                except Exception:
                    continue
                k = cfg.key()
                score[k] = ms2 if k not in score else min(score[k], ms2)
        pool = [cfg for cfg in leaders if cfg.key() in score] or leaders
        best = min(pool, key=lambda cfg: score.get(cfg.key(),
                                                   select_ms[cfg.key()]))
        self._mem[kvals] = best
        self._save(kvals, best)
        return best


def autotune(configs: list[Config], key: list[str]):
    """``@tl.autotune(configs=[tl.Config({...}, num_warps=w), ...], key=[...])``

    Applied above ``@tl.kernel``; the kernel is launched with the fastest
    config for the runtime values of the ``key`` arguments.
    """
    def deco(kernel_obj):
        kernel_obj.autotuner = Autotuner(kernel_obj, configs, key)
        return kernel_obj
    return deco
