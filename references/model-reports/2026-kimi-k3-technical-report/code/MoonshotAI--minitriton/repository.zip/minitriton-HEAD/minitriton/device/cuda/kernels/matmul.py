"""matmul/bmm cores of the device/cuda kernels package:
v1 masked kernels, matmul_v2 (t2 thread tile + cp.async), the
fp64-quality double-single kernel (opt-in), the tensor-core mma
family (tf32/bf16, split-K, bmm) and all their autotune surfaces.

All kernels assume the *last* dim of every operand is unit-stride (the
eager layer calls .contiguous() when that is not the case); other strides
are runtime i32 arguments.

``import minitriton as tl`` here resolves against the partially initialized
package (frontend/runtime names are exported before the eager layer is
imported), which is what makes the decorators work at import time.

NOTE: no ``from __future__ import annotations`` here — kernel parameter
annotations (``tl.constexpr``) must stay real objects for the DSL binder.
"""

import minitriton as tl


_MM_TILES = [
    (32, 128, 32, 4), (32, 128, 64, 4), (64, 128, 32, 4), (64, 128, 64, 4),
    (32, 256, 32, 4), (32, 512, 16, 4), (64, 256, 32, 8), (32, 256, 64, 8),
    (128, 128, 32, 4), (64, 512, 16, 8),
]


@tl.kernel
def matmul_kernel(a_ptr, b_ptr, c_ptr, M, N, K, sam, sbk,
                  BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
                  EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
                  EVEN_MN: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    acc = tl.zeros((BM, BN), tl.float32)
    a_ptrs = a_ptr + offs_m[:, None] * sam + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * sbk + offs_n[None, :]
    for k in range(0, K, BK):
        if EVEN_MK:
            a = tl.load(a_ptrs)
        else:
            a = tl.load(a_ptrs,
                        mask=(offs_m[:, None] < M) & ((offs_k + k)[None, :] < K),
                        other=0.0)
        if EVEN_KN:
            b = tl.load(b_ptrs)
        else:
            b = tl.load(b_ptrs,
                        mask=((offs_k + k)[:, None] < K) & (offs_n[None, :] < N),
                        other=0.0)
        acc = tl.dot(a, b, acc)
        a_ptrs += BK
        b_ptrs += BK * sbk
    if EVEN_MN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc, mask=cm)


@tl.kernel
def bmm_kernel(a_ptr, b_ptr, c_ptr, M, N, K, sab, sam, sbb, sbk,
               BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
               EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
               EVEN_MN: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    pid_b = tl.program_id(2)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    acc = tl.zeros((BM, BN), tl.float32)
    a_ptrs = a_ptr + pid_b * sab + offs_m[:, None] * sam + offs_k[None, :]
    b_ptrs = b_ptr + pid_b * sbb + offs_k[:, None] * sbk + offs_n[None, :]
    for k in range(0, K, BK):
        if EVEN_MK:
            a = tl.load(a_ptrs)
        else:
            a = tl.load(a_ptrs,
                        mask=(offs_m[:, None] < M) & ((offs_k + k)[None, :] < K),
                        other=0.0)
        if EVEN_KN:
            b = tl.load(b_ptrs)
        else:
            b = tl.load(b_ptrs,
                        mask=((offs_k + k)[:, None] < K) & (offs_n[None, :] < N),
                        other=0.0)
        acc = tl.dot(a, b, acc)
        a_ptrs += BK
        b_ptrs += BK * sbk
    if EVEN_MN:
        tl.store(c_ptr + pid_b * (M * N) + offs_m[:, None] * N
                 + offs_n[None, :], acc)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + pid_b * (M * N) + offs_m[:, None] * N
                 + offs_n[None, :], acc, mask=cm)


# ---------------------------------------------------------------------------
# matmul / bmm v2: 2D thread tile + cp.async pipeline
# ---------------------------------------------------------------------------

@tl.kernel
def matmul_v2_kernel(a_ptr, b_ptr, c_ptr, M, N, K, sam, sbk,
                     bias_ptr,
                     BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
                     TM: tl.constexpr, TN: tl.constexpr,
                     STAGES: tl.constexpr, GROUP_M: tl.constexpr,
                     EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
                     EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr,
                     TRANS_A: tl.constexpr, TRANS_B: tl.constexpr,
                     BIAS: tl.constexpr = False,
                     ONE_BAR: tl.constexpr = False):
    pid = tl.program_id(0)
    num_pid_m = (M + BM - 1) // BM
    num_pid_n = (N + BN - 1) // BN
    num_in_group = GROUP_M * num_pid_n
    group_id = pid // num_in_group
    first_pid_m = group_id * GROUP_M
    group_size = tl.where(num_pid_m - first_pid_m < GROUP_M,
                          num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size)
    pid_n = (pid % num_in_group) // group_size
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    if TRANS_A:
        # a is a pure transpose view: element (m, k) at m + k*sam
        a_ptrs = a_ptr + offs_m[:, None] + offs_k[None, :] * sam
    else:
        a_ptrs = a_ptr + offs_m[:, None] * sam + offs_k[None, :]
    if TRANS_B:
        # b is a pure transpose view: element (k, n) at k + n*sbk
        b_ptrs = b_ptr + offs_k[:, None] + offs_n[None, :] * sbk
    else:
        b_ptrs = b_ptr + offs_k[:, None] * sbk + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                             TRANS_A=TRANS_A, TRANS_B=TRANS_B,
                             ONE_BAR=ONE_BAR)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                             EVEN_K=EVEN_K, VEC=False,
                             a_mask=am, b_mask=bn,
                             TRANS_A=TRANS_A, TRANS_B=TRANS_B,
                             ONE_BAR=ONE_BAR)
    if BIAS:
        bpt = bias_ptr + pid_n * BN + tl.arange(0, BN)
        if EVEN_MN:
            tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                     bias=bpt)
        else:
            cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
            tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                     mask=cm, bias=bpt)
    elif EVEN_MN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc, mask=cm)


@tl.kernel
def bmm_v2_kernel(a_ptr, b_ptr, c_ptr, M, N, K, sab, sam, sbb, sbk,
                  BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
                  TM: tl.constexpr, TN: tl.constexpr,
                  STAGES: tl.constexpr, GROUP_M: tl.constexpr,
                  EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
                  EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr):
    pid = tl.program_id(0)
    pid_b = tl.program_id(2)
    num_pid_m = (M + BM - 1) // BM
    num_pid_n = (N + BN - 1) // BN
    num_in_group = GROUP_M * num_pid_n
    group_id = pid // num_in_group
    first_pid_m = group_id * GROUP_M
    group_size = tl.where(num_pid_m - first_pid_m < GROUP_M,
                          num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size)
    pid_n = (pid % num_in_group) // group_size
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + pid_b * sab + offs_m[:, None] * sam + offs_k[None, :]
    b_ptrs = b_ptr + pid_b * sbb + offs_k[:, None] * sbk + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                             EVEN_K=EVEN_K, VEC=False,
                             a_mask=am, b_mask=bn)
    if EVEN_MN:
        tl.store(c_ptr + pid_b * (M * N) + offs_m[:, None] * N
                 + offs_n[None, :], acc)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + pid_b * (M * N) + offs_m[:, None] * N
                 + offs_n[None, :], acc, mask=cm)


# (BM, BN, BK, TM, TN, num_warps, STAGES); GROUP_M in {4, 8, 16}.
# smem budget: (BM*BK + BK*BN) * 4B * STAGES <= 48KB static limit;
# thread grid: (BM/TM) * (BN/TN) == num_warps*32 (wider space
# for the Linear training shapes — large-M fwd, transposed bwd).
_MM_V2_TILES = [
    (128, 64, 32, 8, 8, 4, 2),
    (128, 128, 16, 8, 8, 8, 2),
    (128, 128, 16, 8, 8, 8, 3),
    (64, 128, 32, 8, 8, 8, 2),
    (128, 64, 16, 8, 8, 4, 2),
    (128, 64, 16, 8, 8, 4, 3),
    (64, 64, 32, 4, 4, 8, 2),
    (64, 64, 32, 4, 4, 8, 3),
    (64, 32, 32, 4, 4, 4, 2),
    (32, 64, 32, 4, 4, 4, 2),
    (64, 64, 16, 4, 4, 8, 2),
    (32, 128, 32, 4, 8, 4, 2),
    (256, 64, 16, 8, 8, 8, 2),
    (256, 128, 16, 8, 8, 16, 2),
    (64, 256, 16, 8, 8, 8, 2),
    (64, 128, 16, 8, 8, 4, 2),
    (64, 64, 32, 8, 8, 2, 2),
    (128, 32, 32, 8, 4, 4, 2),
    (64, 32, 64, 4, 4, 4, 2),
    (32, 64, 64, 4, 4, 4, 2),
]

# ONE_BAR shortlist: the t2 single-barrier multistage schedule (one
# fewer block-wide sync per K tile; a per-shape autotune knob like the
# mma path's). Tiles are sweep winners across the fp32-shortk space.
_MM_V2_TILES_ONE_BAR = [
    (64, 128, 16, 8, 8, 4, 2),
    (128, 128, 16, 8, 8, 8, 2),
    (128, 64, 16, 8, 8, 4, 2),
    (64, 64, 32, 8, 8, 2, 2),
    (64, 256, 16, 8, 8, 8, 2),
]


def _tile_ok(bm, bn, bk, tm, tn, w, stages) -> bool:
    """Generation-time validity: thread grid == num_warps*32 and the
    staged smem fits the 48KB static limit (46KB margin)."""
    grid = (bm // tm) * (bn // tn)
    if grid != w * 32:
        return False
    smem = (bm * bk + bk * bn) * 4 * stages
    return smem <= 46 * 1024


def _mm_v2_config(bm, bn, bk, tm, tn, w, stages, gm, M, N, K, sam, sbk,
                  trans_a, trans_b, one_bar=False):
    return tl.Config(
        {"BM": bm, "BN": bn, "BK": bk, "TM": tm, "TN": tn,
         "STAGES": stages, "GROUP_M": gm,
         # the 16B cp.async path also needs the row strides 16B-aligned;
         # fold that into the EVEN flags. Transposed operands stage with
         # 4B copies instead, so the stride alignment requirement does not
         # apply to them.
         "EVEN_MK": M % bm == 0 and K % bk == 0
                    and (trans_a or sam % 4 == 0),
         "EVEN_KN": K % bk == 0 and N % bn == 0
                    and (trans_b or sbk % 4 == 0),
         "EVEN_MN": M % bm == 0 and N % bn == 0,
         "EVEN_K": K % bk == 0,
         "TRANS_A": trans_a, "TRANS_B": trans_b,
         "ONE_BAR": one_bar},
        num_warps=w)


def _mm_v2_configs(M: int, N: int, K: int, sam: int, sbk: int,
                   trans_a: bool = False, trans_b: bool = False,
                   with_one_bar: bool = True):
    cfgs = []
    for bm, bn, bk, tm, tn, w, stages in _MM_V2_TILES:
        if not _tile_ok(bm, bn, bk, tm, tn, w, stages):
            continue
        for gm in (4, 8, 16):
            cfgs.append(_mm_v2_config(bm, bn, bk, tm, tn, w, stages, gm,
                                      M, N, K, sam, sbk, trans_a, trans_b))
    if with_one_bar:
        for bm, bn, bk, tm, tn, w, stages in _MM_V2_TILES_ONE_BAR:
            if not _tile_ok(bm, bn, bk, tm, tn, w, stages):
                continue
            for gm in (4, 8, 16):
                cfgs.append(_mm_v2_config(bm, bn, bk, tm, tn, w, stages, gm,
                                          M, N, K, sam, sbk, trans_a,
                                          trans_b, one_bar=True))
    return cfgs


# Per-shape autotuners: the EVEN_* divisibility flags depend on both the
# shape and the config's tile sizes, so the config list is built per
# (M, N, K) instead of using the @tl.autotune decorator.
_tuners: dict = {}


def _mm_tuner(kernel_obj, M: int, N: int, K: int):
    """Tuner for the v1-style kernels (kept for compile.py's epilogue
    fusion path, which uses tl.dot v1)."""
    from ....runtime.autotune import Autotuner
    key = (kernel_obj.name, M, N, K)
    tuner = _tuners.get(key)
    if tuner is None:
        cfgs = []
        for bm, bn, bk, w in _MM_TILES:
            cfgs.append(tl.Config(
                {"BM": bm, "BN": bn, "BK": bk,
                 "EVEN_MK": M % bm == 0 and K % bk == 0,
                 "EVEN_KN": K % bk == 0 and N % bn == 0,
                 "EVEN_MN": M % bm == 0 and N % bn == 0},
                num_warps=w))
        tuner = Autotuner(kernel_obj, cfgs, ["M", "N", "K"])
        _tuners[key] = tuner
    return tuner


def _mm_v2_tuner(kernel_obj, M: int, N: int, K: int, sam: int, sbk: int,
                 trans_a: bool = False, trans_b: bool = False,
                 with_one_bar: bool = True):
    from ....runtime.autotune import Autotuner
    key = (kernel_obj.name, M, N, K, sam, sbk, trans_a, trans_b,
           with_one_bar)
    tuner = _tuners.get(key)
    if tuner is None:
        tuner = Autotuner(
            kernel_obj,
            _mm_v2_configs(M, N, K, sam, sbk, trans_a, trans_b,
                           with_one_bar),
            ["M", "N", "K"])
        _tuners[key] = tuner
    return tuner


_V2_KW = {"BM": 0, "BN": 0, "BK": 0, "TM": 0, "TN": 0, "STAGES": 0,
          "GROUP_M": 0, "EVEN_MK": False, "EVEN_KN": False,
          "EVEN_MN": False, "EVEN_K": False,
          "TRANS_A": False, "TRANS_B": False, "ONE_BAR": False}

_V2_KW_BMM = {"BM": 0, "BN": 0, "BK": 0, "TM": 0, "TN": 0, "STAGES": 0,
              "GROUP_M": 0, "EVEN_MK": False, "EVEN_KN": False,
              "EVEN_MN": False, "EVEN_K": False}


def _trans_kstride(t) -> int | None:
    """k-stride when t is a pure transpose view (strides (1, shape[0]):
    element (m, k) at m + k*shape[0]); None otherwise. Such views are fed
    to matmul_v2's transposed-staging path instead of being materialized
    by an eager contiguous() copy."""
    if t.ndim == 2 and t.strides[-1] != 1 and t.strides[0] == 1 \
            and t.strides[-1] == t.shape[0]:
        return t.strides[-1]
    return None


def launch_matmul(a, b, out, M: int, N: int, K: int, bias=None):
    """a (M, K) / b (K, N) / out (M, N); operands are unit-last-stride or
    pure transpose views (the transposed staging handles those). bias
    (optional (N,) f32): fused epilogue (added to the f32 accumulators
    before the store — bit-identical to the composed broadcast add)."""
    ta, tb = _trans_kstride(a), _trans_kstride(b)
    sam = ta if ta is not None else a.strides[0]
    sbk = tb if tb is not None else b.strides[0]
    tuner = _mm_v2_tuner(matmul_v2_kernel, M, N, K, sam, sbk,
                         ta is not None, tb is not None)
    grid = lambda args: (((args["M"] + args["BM"] - 1) // args["BM"])
                         * ((args["N"] + args["BN"] - 1) // args["BN"]),)
    args = (a._buffer_arg(), b._buffer_arg(), out._buffer_arg(),
            M, N, K, sam, sbk,
            (bias if bias is not None else out)._buffer_arg())
    tuner.launch(matmul_v2_kernel, grid, args, None,
                 dict(_V2_KW, BIAS=bias is not None))


def launch_bmm(a, b, out, B: int, M: int, N: int, K: int):
    tuner = _mm_v2_tuner(bmm_v2_kernel, M, N, K, a.strides[1], b.strides[1],
                         with_one_bar=False)
    grid = lambda args: (((args["M"] + args["BM"] - 1) // args["BM"])
                         * ((args["N"] + args["BN"] - 1) // args["BN"]), 1, B)
    args = (a._buffer_arg(), b._buffer_arg(), out._buffer_arg(),
            M, N, K, a.strides[0], a.strides[1], b.strides[0], b.strides[1])
    tuner.launch(bmm_v2_kernel, grid, args, None, dict(_V2_KW_BMM))



@tl.kernel
def matmul_v2_splitk_kernel(a_ptr, b_ptr, c_ptr, M, N, K, sam, sbk,
                            BM: tl.constexpr, BN: tl.constexpr,
                            BK: tl.constexpr, TM: tl.constexpr,
                            TN: tl.constexpr, STAGES: tl.constexpr,
                            GROUP_M: tl.constexpr, SPLIT_K: tl.constexpr,
                            EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
                            EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr,
                            TRANS_A: tl.constexpr, TRANS_B: tl.constexpr,
                            ONE_BAR: tl.constexpr = False):
    """Split-K fp32 matmul (t2 thread tile): each program computes one
    K-slice partial into the (SPLIT_K, M, N) f32 partials tensor (plain
    stores, deterministic; the caller reduces over the split axis with
    splitk_reduce). For K-heavy small-MN shapes (the fp32 training wgrad
    family, e.g. (640,1920,16384)) where the plain kernel's tile grid
    underfills the SMs — same launch-form trick as the bf16 mma splitk
    route."""
    pid = tl.program_id(0)
    pid_k = tl.program_id(2)
    num_pid_m = (M + BM - 1) // BM
    num_pid_n = (N + BN - 1) // BN
    num_in_group = GROUP_M * num_pid_n
    group_id = pid // num_in_group
    first_pid_m = group_id * GROUP_M
    group_size = tl.where(num_pid_m - first_pid_m < GROUP_M,
                          num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size)
    pid_n = (pid % num_in_group) // group_size
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    # per-split K window (multiple of BK); k_rem may be shorter on the
    # last split — masks / the EVEN_K guarantee cover the tail exactly
    # like the plain kernel (EVEN_K = K % BK == 0 implies per-split
    # remainders are BK-aligned as the window is BK-aligned)
    kspan = ((K + SPLIT_K * BK - 1) // (SPLIT_K * BK)) * BK
    k_lo = pid_k * kspan
    k_raw = K - k_lo
    k_rem = tl.where(k_raw < kspan, k_raw, kspan)
    if TRANS_A:
        a_ptrs = a_ptr + offs_m[:, None] + (offs_k[None, :] + k_lo) * sam
    else:
        a_ptrs = a_ptr + offs_m[:, None] * sam + offs_k[None, :] + k_lo
    if TRANS_B:
        b_ptrs = b_ptr + offs_k[:, None] + k_lo + offs_n[None, :] * sbk
    else:
        b_ptrs = b_ptr + (offs_k[:, None] + k_lo) * sbk + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.matmul_tile(a_ptrs, b_ptrs, k_rem, TM, TN, STAGES=STAGES,
                             TRANS_A=TRANS_A, TRANS_B=TRANS_B,
                             ONE_BAR=ONE_BAR)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.matmul_tile(a_ptrs, b_ptrs, k_rem, TM, TN, STAGES=STAGES,
                             EVEN_K=False, VEC=False,
                             a_mask=am, b_mask=bn,
                             TRANS_A=TRANS_A, TRANS_B=TRANS_B,
                             ONE_BAR=ONE_BAR)
    c_base = c_ptr + pid_k * (M * N)
    if EVEN_MN:
        tl.store(c_base + offs_m[:, None] * N + offs_n[None, :], acc)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_base + offs_m[:, None] * N + offs_n[None, :], acc,
                 mask=cm)


# (BM, BN, BK, TM, TN, num_warps, STAGES) x SPLIT_K — the fp32 wgrad-family
# incumbents (64x128 BK16 w4 the best plain config there).
# GROUP_M fixed at 8.
_MM_V2_TILES_SPLITK = [
    (64, 128, 16, 8, 8, 4, 2),
    (128, 128, 16, 8, 8, 8, 2),
    (64, 64, 32, 8, 8, 2, 2),
    (32, 128, 32, 4, 8, 4, 2),
]


def _mm_v2_splitk_configs(M: int, N: int, K: int, sam: int, sbk: int,
                          trans_a: bool = False, trans_b: bool = False):
    cfgs = []
    for bm, bn, bk, tm, tn, w, stages in _MM_V2_TILES_SPLITK:
        if not _tile_ok(bm, bn, bk, tm, tn, w, stages):
            continue
        for sk in (2, 4, 8, 16):
            # every split must hold at least one BK window
            kspan = ((K + sk * bk - 1) // (sk * bk)) * bk
            if (sk - 1) * kspan >= K:
                continue
            if sk * M * N > 12_000_000:   # f32 partials budget ~48MB
                continue
            for ob in (False, True):
                cfgs.append(tl.Config(
                    {"BM": bm, "BN": bn, "BK": bk, "TM": tm, "TN": tn,
                     "STAGES": stages, "GROUP_M": 8, "SPLIT_K": sk,
                     "EVEN_MK": M % bm == 0 and K % bk == 0
                                and (trans_a or sam % 4 == 0),
                     "EVEN_KN": K % bk == 0 and N % bn == 0
                                and (trans_b or sbk % 4 == 0),
                     "EVEN_MN": M % bm == 0 and N % bn == 0,
                     "EVEN_K": K % bk == 0,
                     "TRANS_A": trans_a, "TRANS_B": trans_b,
                     "ONE_BAR": ob},
                    num_warps=w))
    return cfgs


def _mm_v2_splitk_tuner(M: int, N: int, K: int, sam: int, sbk: int,
                        trans_a: bool = False, trans_b: bool = False):
    from ....runtime.autotune import Autotuner
    key = ("v2_splitk", M, N, K, sam, sbk, trans_a, trans_b)
    tuner = _tuners.get(key)
    if tuner is None:
        tuner = Autotuner(
            matmul_v2_splitk_kernel,
            _mm_v2_splitk_configs(M, N, K, sam, sbk, trans_a, trans_b),
            ["M", "N", "K"],
            extra_key=(sam, sbk, trans_a, trans_b))
        _tuners[key] = tuner
    return tuner


_V2_KW_SPLITK = dict(_V2_KW, SPLIT_K=0)


def launch_matmul_v2_splitk(a, b, partials, M: int, N: int, K: int):
    """Split-K fp32 launch into f32 partials (SPLIT_K, M, N); the caller
    reduces over axis 0. Same operand contract as launch_matmul."""
    ta, tb = _trans_kstride(a), _trans_kstride(b)
    sam = ta if ta is not None else a.strides[0]
    sbk = tb if tb is not None else b.strides[0]
    tuner = _mm_v2_splitk_tuner(M, N, K, sam, sbk,
                                ta is not None, tb is not None)
    grid = lambda args: (((args["M"] + args["BM"] - 1) // args["BM"])
                         * ((args["N"] + args["BN"] - 1) // args["BN"]),
                         1, args["SPLIT_K"])
    args = (a._buffer_arg(), b._buffer_arg(), partials._buffer_arg(),
            M, N, K, sam, sbk)
    tuner.launch(matmul_v2_splitk_kernel, grid, args, None,
                 dict(_V2_KW_SPLITK))
    return splitk_v2_pick(M, N, K, sam, sbk, ta is not None,
                          tb is not None)


def splitk_v2_pick(M: int, N: int, K: int, sam: int, sbk: int,
                   trans_a: bool = False, trans_b: bool = False) -> int:
    """The tuner's chosen SPLIT_K for this shape key (0 if untuned)."""
    tuner = _tuners.get(("v2_splitk", M, N, K, sam, sbk, trans_a, trans_b))
    if tuner is None:
        return 0
    cfg = tuner._mem.get((M, N, K) + tuner._extra)
    return cfg.kwargs["SPLIT_K"] if cfg is not None else 0




# ---------------------------------------------------------------------------
# matmul / bmm, fp64-quality (opt-in, MT_MATMUL_FP64): double-single
# compensated accumulation in fp32 (Dekker TwoProd + TwoSum per term), so
# the result is the correctly-rounded-to-fp32 exact dot product (error
# ~K*eps^2 ~ 1e-11 rel — fp64-accumulator class). GEMV-per-row: one
# program per output row, lanes cover N in BLOCK chunks. Slow by design;
# used for numerical equivalence studies, not throughput.
# ---------------------------------------------------------------------------

@tl.kernel
def matmul_ds_kernel(a_ptr, b_ptr, c_ptr, M, N, K, sab, sbb,
                     BLOCK: tl.constexpr):
    row = tl.program_id(0)
    nb = tl.program_id(1)
    bid = tl.program_id(2)
    offs = nb * BLOCK + tl.arange(0, BLOCK)
    nm = offs < N
    a_base = a_ptr + bid * sab + row * K
    b_base = b_ptr + bid * sbb
    hi = tl.zeros((BLOCK,), tl.float32)
    lo = tl.zeros((BLOCK,), tl.float32)
    for k in range(0, K):
        av = tl.load(a_base + k)
        bv = tl.load(b_base + k * N + offs, mask=nm, other=0.0)
        # TwoProd (Dekker split at 2^12+1, exact in fp32): p + e == av*bv
        ca = 4097.0 * av
        a_hi = ca - (ca - av)
        a_lo = av - a_hi
        cb = 4097.0 * bv
        b_hi = cb - (cb - bv)
        b_lo = bv - b_hi
        p = av * bv
        e = ((a_hi * b_hi - p) + a_hi * b_lo + a_lo * b_hi) + a_lo * b_lo
        # TwoSum(hi, p): s + err == hi + p exactly
        s = hi + p
        z = s - hi
        err = (hi - (s - z)) + (p - z)
        lo = lo + (e + err)
        hi = s
    tl.store(c_ptr + bid * (M * N) + row * N + offs, hi + lo, mask=nm)


def launch_matmul_ds(a, b, out, M: int, N: int, K: int, B: int = 1):
    """a (B, M, K) / b (B, K, N) contiguous, out (B, M, N); B=1 for 2D."""
    block = 1024
    grid = (M, (N + block - 1) // block, B)
    matmul_ds_kernel[grid](a._buffer_arg(), b._buffer_arg(),
                           out._buffer_arg(), M, N, K, M * K, K * N,
                           BLOCK=block, num_warps=4)


# ---------------------------------------------------------------------------
# matmul mma: tensor-core mma.sync (tf32 / bf16 / 3xTF32)
# ---------------------------------------------------------------------------

@tl.kernel
def matmul_mma_kernel(a_ptr, b_ptr, c_ptr, M, N, K, sam, sbk,
                      bias_ptr,
                      BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
                      ATOM: tl.constexpr, STAGES: tl.constexpr,
                      GROUP_M: tl.constexpr,
                      EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
                      EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr,
                      TRANS_A: tl.constexpr, TRANS_B: tl.constexpr,
                      TVEC_A: tl.constexpr, TVEC_B: tl.constexpr,
                      ONE_BAR: tl.constexpr,
                      BIAS: tl.constexpr = False,
                      F2F: tl.constexpr = False,
                      DYN_SMEM: tl.constexpr = False,
                      ONE_SHOT: tl.constexpr = False,
                      EPI: tl.constexpr = ""):
    pid = tl.program_id(0)
    num_pid_m = (M + BM - 1) // BM
    num_pid_n = (N + BN - 1) // BN
    num_in_group = GROUP_M * num_pid_n
    group_id = pid // num_in_group
    first_pid_m = group_id * GROUP_M
    group_size = tl.where(num_pid_m - first_pid_m < GROUP_M,
                          num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size)
    pid_n = (pid % num_in_group) // group_size
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    if TRANS_A:
        a_ptrs = a_ptr + offs_m[:, None] + offs_k[None, :] * sam
    else:
        a_ptrs = a_ptr + offs_m[:, None] * sam + offs_k[None, :]
    if TRANS_B:
        b_ptrs = b_ptr + offs_k[:, None] + offs_n[None, :] * sbk
    else:
        b_ptrs = b_ptr + offs_k[:, None] * sbk + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM=ATOM, STAGES=STAGES,
                          TRANS_A=TRANS_A, TRANS_B=TRANS_B,
                          TVEC_A=TVEC_A, TVEC_B=TVEC_B, ONE_BAR=ONE_BAR,
                          F2F=F2F, DYN_SMEM=DYN_SMEM, ONE_SHOT=ONE_SHOT)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM=ATOM, STAGES=STAGES,
                          EVEN_K=EVEN_K, VEC=False,
                          a_mask=am, b_mask=bn,
                          TRANS_A=TRANS_A, TRANS_B=TRANS_B, ONE_BAR=ONE_BAR,
                          DYN_SMEM=DYN_SMEM, ONE_SHOT=ONE_SHOT)
    if BIAS:
        bpt = bias_ptr + pid_n * BN + tl.arange(0, BN)
        if EVEN_MN:
            tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                     bias=bpt, EPI=EPI)
        else:
            cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
            tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                     mask=cm, bias=bpt, EPI=EPI)
    elif EVEN_MN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                 EPI=EPI)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                 mask=cm, EPI=EPI)


# (BM, BN, BK, num_warps, STAGES); GROUP_M in {4, 8, 16}.
# smem budget: (BM*BK + BK*BN) * elemsize * STAGES <= 48KB static limit —
# 4B elems (tf32/x3) cap BK at 32 for 64x128 tiles, at 16 for 128x128;
# 2B elems (bf16) double the BK. Warp grids are derived in the builder
# (most-square warp tile divisible by the 16x8 atom).
_MMA_TILES_TF32 = [
    (128, 64, 32, 4, 2),
    (128, 64, 16, 4, 3),
    (64, 128, 32, 4, 2),
    (64, 128, 16, 4, 3),
    (128, 128, 16, 8, 2),
    (128, 128, 16, 8, 3),
    (128, 128, 16, 4, 2),   # 64x64 warp tiles: max operand reuse
    (128, 128, 16, 4, 3),
    (256, 128, 16, 8, 2),
    (256, 128, 16, 16, 2),
    (128, 256, 16, 8, 2),
    (256, 64, 16, 4, 2),
    (256, 64, 16, 8, 2),
    (64, 64, 32, 4, 2),
    (64, 64, 32, 4, 3),
    (64, 64, 64, 4, 2),
    (64, 64, 32, 2, 2),     # 2 CTAs/SM (24KB)
    (64, 64, 16, 4, 2),
    (32, 128, 32, 4, 2),
    (128, 32, 32, 4, 2),
    # small shapes: many tiny CTAs fill the SMs
    (32, 32, 32, 1, 4),
    (32, 32, 32, 1, 3),
    (32, 64, 64, 2, 2),
    (64, 32, 64, 2, 2),
    (16, 64, 32, 1, 3),
    (64, 16, 32, 1, 3),
]

_MMA_TILES_BF16 = [
    (128, 128, 32, 8, 2),
    (128, 128, 32, 8, 3),
    (128, 128, 32, 4, 2),   # 64x64 warp tiles
    (128, 256, 32, 8, 2),
    (256, 128, 32, 8, 2),
    (256, 128, 32, 16, 2),
    (128, 64, 64, 8, 2),
    (128, 64, 64, 4, 2),
    (64, 128, 64, 4, 2),
    (64, 64, 64, 4, 2),
    (128, 128, 64, 8, 1),
    (64, 64, 32, 4, 2),
    (64, 64, 32, 4, 3),
    (64, 64, 32, 2, 2),
    (32, 128, 32, 4, 2),
    (128, 32, 32, 4, 2),
    (32, 32, 32, 1, 4),     # small shapes
    (32, 32, 32, 1, 3),
    (32, 64, 64, 2, 2),
    (64, 32, 64, 2, 2),
    # M-heavy thin-N (e2e fwd: M=16384, N in 640..2560)
    (256, 64, 32, 8, 2),
    (256, 64, 32, 4, 2),
    (256, 32, 32, 4, 2),
    (128, 32, 64, 4, 2),
    (64, 32, 64, 2, 3),
    (128, 128, 16, 4, 2),
    (64, 128, 32, 4, 3),
    # short-K deep pipelines (K<=2560: single-barrier multistage; the
    # 48KB static smem wall caps (BM+BN)*BK*2*STAGES at 49152B)
    (128, 64, 32, 4, 3),   # 36KB
    (128, 64, 32, 4, 4),   # 48KB
    (64, 64, 64, 4, 3),    # 48KB exact
    (128, 128, 32, 4, 3),  # 48KB exact
    (128, 128, 32, 8, 3),  # 48KB exact, 8 warps
    # K-heavy deep pipelines (e2e dW: K=16384, M in 640..2560)
    (64, 64, 32, 4, 4),
    (64, 64, 32, 4, 5),
    (64, 64, 16, 4, 4),
    (32, 64, 32, 2, 4),
    (64, 32, 32, 2, 4),
    (32, 32, 32, 2, 4),
    # thin-N tail (e2e head: N=96)
    (64, 96, 32, 4, 2),
    (32, 96, 32, 2, 2),
]

# bf16 ONE_BAR shortlist: these tiles are additionally tried with the
# single-barrier multistage schedule. It wins when the mma
# compute phase dominates staging (plain 16B cp.async, short K loops) and
# loses when staging itself is the slow phase (transposed/4B stagings keep
# the copy engine fed only in the issue-first default schedule) — so the
# schedule stays a per-shape autotune choice, not a global default. The
# deep-stage entries (STAGES >= 3) exist for the short-K family; they sit
# in the main table too (default-schedule variants) — only their ONE_BAR
# duplicates come from here.
_MMA_TILES_BF16_ONE_BAR = [
    (128, 64, 64, 4, 2),   # short-K fwd winners
    (128, 64, 64, 8, 2),
    (64, 64, 64, 4, 2),
    (64, 64, 32, 4, 2),
    (128, 64, 32, 4, 3),   # 36KB, deep
    (128, 64, 32, 4, 4),   # 48KB, deep
    (64, 64, 64, 4, 3),    # 48KB exact, deep
    (128, 128, 32, 8, 2),
    (128, 128, 32, 4, 2),
    (128, 128, 32, 8, 3),  # 48KB exact
    (128, 128, 32, 4, 3),  # 48KB exact
    (256, 64, 32, 8, 2),
    (64, 32, 64, 2, 3),
    (32, 64, 64, 2, 2),
]

# bf16 EPI ("smem" epilogue) shortlist: the C fragment is staged through a
# swizzled smem buffer and re-stored as row-contiguous 16B chunks (one
# STG.E.128 per lane) instead of the fragment-native 8B/lane pair stores
# (32B sectors). Per-shape autotune choice like ONE_BAR: it
# wins when the C write is a large f32/bf16 burst and loses the barrier +
# staging smem back when it is not. The epilogue buffer is static scratch
# while the 48KB budget holds, dynamic smem past it — so
# the list is gated on launch-validity for the F32-out worst case (the
# autotune key does not carry the out dtype: every config in the space
# must stay launchable for both). Tiles are the M-heavy/thin-N short-K
# family and the mid tiles that win the other M-heavy e2e shapes.
_MMA_TILES_BF16_EPI = [
    (64, 64, 32, 4, 2),    # head.dX incumbent family
    (64, 64, 32, 4, 3),
    (64, 64, 32, 4, 4),
    (64, 64, 32, 4, 5),
    (64, 64, 32, 2, 2),
    (64, 64, 64, 4, 2),
    (64, 64, 64, 4, 3),
    (128, 64, 64, 4, 2),
    (128, 64, 64, 8, 2),
    (128, 64, 32, 4, 2),
    (128, 64, 32, 4, 3),
    (64, 32, 64, 2, 2),    # head.fwd incumbent
    (64, 32, 64, 2, 3),
    (128, 32, 64, 4, 2),
    (32, 64, 64, 2, 2),
    (64, 128, 64, 4, 2),
    (128, 128, 32, 8, 2),
    (128, 128, 32, 4, 2),
]


def _epi_launchable(bm: int, bn: int, bk: int, stages: int) -> bool:
    """smem-epilogue config validity for the F32-out worst case (see the
    shortlist comment): bf16 staging + f32 epilogue buffer must fit one
    SM's 100KB shared budget (dyn region capped just under that, static
    part at 48KB). BN=96-class tiles are excluded: the epilogue swizzle
    needs a power-of-two chunk row (the mainloop loud-rejects those
    anyway)."""
    cpr = bn // 4
    if cpr & (cpr - 1):
        return False
    staging = (bm * bk + bk * bn) * 2 * stages
    epi = bm * bn * 4 + 16
    dyn = epi if staging + epi > 48 * 1024 else 0
    return staging + epi <= 100 * 1024 and dyn <= 99 * 1024


def _mm_mma_configs(atom, M: int, N: int, K: int, sam: int, sbk: int,
                    trans_a: bool = False, trans_b: bool = False,
                    a_dt=None, b_dt=None, epi: bool = True):
    tiles = _MMA_TILES_BF16 if atom == "bf16" else _MMA_TILES_TF32
    # 16B staging alignment, per operand (bf16: 8 elems, f32: 4); tvec
    # stays bf16-staged only (the transposed 16B upgrade path)
    from ....frontend import types as _t
    bf = _t.bfloat16
    align_a = 8 if (a_dt is None or a_dt == bf) else 4
    align_b = 8 if (b_dt is None or b_dt == bf) else 4
    # ONE_BAR (single-barrier multistage schedule) is a per-shape tuning
    # knob on the bf16 tier: it wins when the mma compute phase dominates
    # staging (plain 16B cp.async, short K loops) and loses when staging
    # itself is the slow phase (transposed 4B/TVEC stagings keep the copy
    # engine fed only in the issue-first default schedule). The main table
    # stays on the default schedule; the shortlist adds ONE_BAR
    # duplicates. tf32 keeps the default schedule only (unprobed tier).
    # EPI="smem" (smem-transpose epilogue) is the same kind of per-shape
    # knob for the C writeback: duplicates of the _MMA_TILES_BF16_EPI
    # shortlist (default schedule; ONE_BAR too for tiles on that
    # shortlist), gated by _epi_launchable for f32-out worst-case
    # validity.
    cfgs = []
    for bm, bn, bk, w, stages in tiles:
        for gm in (4, 8, 16):
            cfgs.append(tl.Config(
                {"BM": bm, "BN": bn, "BK": bk, "ATOM": atom,
                 "STAGES": stages, "GROUP_M": gm,
                 "EVEN_MK": M % bm == 0 and K % bk == 0
                            and (trans_a or sam % align_a == 0),
                 "EVEN_KN": K % bk == 0 and N % bn == 0
                            and (trans_b or sbk % align_b == 0),
                 "EVEN_MN": M % bm == 0 and N % bn == 0,
                 "EVEN_K": K % bk == 0,
                 "TRANS_A": trans_a, "TRANS_B": trans_b,
                 "TVEC_A": (a_dt is None or a_dt == bf)
                            and trans_a and sam % align_a == 0,
                 "TVEC_B": (b_dt is None or b_dt == bf)
                            and trans_b and sbk % align_b == 0,
                 "ONE_BAR": False, "EPI": ""},
                num_warps=w))
    if atom == "bf16":
        for bm, bn, bk, w, stages in _MMA_TILES_BF16_ONE_BAR:
            for gm in (4, 8, 16):
                cfgs.append(tl.Config(
                    {"BM": bm, "BN": bn, "BK": bk, "ATOM": atom,
                     "STAGES": stages, "GROUP_M": gm,
                     "EVEN_MK": M % bm == 0 and K % bk == 0
                                and (trans_a or sam % align_a == 0),
                     "EVEN_KN": K % bk == 0 and N % bn == 0
                                and (trans_b or sbk % align_b == 0),
                     "EVEN_MN": M % bm == 0 and N % bn == 0,
                     "EVEN_K": K % bk == 0,
                     "TRANS_A": trans_a, "TRANS_B": trans_b,
                     "TVEC_A": (a_dt is None or a_dt == bf)
                                and trans_a and sam % align_a == 0,
                     "TVEC_B": (b_dt is None or b_dt == bf)
                                and trans_b and sbk % align_b == 0,
                     "ONE_BAR": True, "EPI": ""},
                    num_warps=w))
        # epi=False for kernels without an EPI parameter (bmm_mma_kernel):
        # unknown config keys are ignored at bind, so EPI variants would
        # compile and measure the same cubins as their non-EPI twins
        if epi:
            one_bar_tiles = set(_MMA_TILES_BF16_ONE_BAR)
            for bm, bn, bk, w, stages in _MMA_TILES_BF16_EPI:
                if not _epi_launchable(bm, bn, bk, stages):
                    continue
                for ob in ((False, True)
                           if (bm, bn, bk, w, stages) in one_bar_tiles
                           else (False,)):
                    for gm in (4, 8, 16):
                        cfgs.append(tl.Config(
                            {"BM": bm, "BN": bn, "BK": bk, "ATOM": atom,
                             "STAGES": stages, "GROUP_M": gm,
                             "EVEN_MK": M % bm == 0 and K % bk == 0
                                        and (trans_a or sam % align_a == 0),
                             "EVEN_KN": K % bk == 0 and N % bn == 0
                                        and (trans_b or sbk % align_b == 0),
                             "EVEN_MN": M % bm == 0 and N % bn == 0,
                             "EVEN_K": K % bk == 0,
                             "TRANS_A": trans_a, "TRANS_B": trans_b,
                             "TVEC_A": (a_dt is None or a_dt == bf)
                                        and trans_a and sam % align_a == 0,
                             "TVEC_B": (b_dt is None or b_dt == bf)
                                        and trans_b and sbk % align_b == 0,
                             "ONE_BAR": ob, "EPI": "smem"},
                            num_warps=w))
    return cfgs


def _mm_mma_tuner(kernel_obj, atom, M: int, N: int, K: int, sam: int,
                  sbk: int, trans_a: bool = False, trans_b: bool = False,
                  a_dt=None, b_dt=None, epi: bool = True):
    from ....runtime.autotune import Autotuner
    key = (kernel_obj.name, atom, M, N, K, sam, sbk, trans_a, trans_b,
           a_dt, b_dt, epi)
    tuner = _tuners.get(key)
    if tuner is None:
        tuner = Autotuner(
            kernel_obj,
            _mm_mma_configs(atom, M, N, K, sam, sbk, trans_a, trans_b,
                            a_dt, b_dt, epi),
            ["M", "N", "K"],
            extra_key=(atom, sam, sbk, trans_a, trans_b,
                       getattr(a_dt, "name", a_dt),
                       getattr(b_dt, "name", b_dt)))
        _tuners[key] = tuner
    return tuner


_MMA_KW = {"BM": 0, "BN": 0, "BK": 0, "ATOM": "tf32", "STAGES": 0,
           "GROUP_M": 0, "EVEN_MK": False, "EVEN_KN": False,
           "EVEN_MN": False, "EVEN_K": False,
           "TRANS_A": False, "TRANS_B": False,
           "TVEC_A": False, "TVEC_B": False, "ONE_BAR": False,
           "DYN_SMEM": False, "ONE_SHOT": False, "EPI": ""}


@tl.kernel
def matmul_mma_splitk_kernel(a_ptr, b_ptr, c_ptr, M, N, K, sam, sbk,
                             BM: tl.constexpr, BN: tl.constexpr,
                             BK: tl.constexpr, ATOM: tl.constexpr,
                             STAGES: tl.constexpr, GROUP_M: tl.constexpr,
                             SPLIT_K: tl.constexpr,
                             EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
                             EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr,
                             TRANS_A: tl.constexpr, TRANS_B: tl.constexpr,
                             TVEC_A: tl.constexpr, TVEC_B: tl.constexpr,
                             ONE_BAR: tl.constexpr):
    """Split-K mma matmul: each program computes one K-slice partial into
    the (SPLIT_K, M, N) f32 partials tensor (plain stores, deterministic;
    the launcher reduces over the split axis). For K-heavy small-MN
    shapes (training weight grads) where the plain kernel's tile grid
    underfills the SMs."""
    pid = tl.program_id(0)
    pid_k = tl.program_id(2)
    num_pid_m = (M + BM - 1) // BM
    num_pid_n = (N + BN - 1) // BN
    num_in_group = GROUP_M * num_pid_n
    group_id = pid // num_in_group
    first_pid_m = group_id * GROUP_M
    group_size = tl.where(num_pid_m - first_pid_m < GROUP_M,
                          num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size)
    pid_n = (pid % num_in_group) // group_size
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    # per-split K window (multiple of BK); k_rem may be shorter on the
    # last split — masks / the EVEN_K guarantee cover the tail exactly
    # like the plain kernel (EVEN_K = K % BK == 0 implies per-split
    # remainders are BK-aligned as the window is BK-aligned)
    kspan = ((K + SPLIT_K * BK - 1) // (SPLIT_K * BK)) * BK
    k_lo = pid_k * kspan
    k_raw = K - k_lo
    k_rem = tl.where(k_raw < kspan, k_raw, kspan)
    if TRANS_A:
        a_ptrs = a_ptr + offs_m[:, None] + (offs_k[None, :] + k_lo) * sam
    else:
        a_ptrs = a_ptr + offs_m[:, None] * sam + offs_k[None, :] + k_lo
    if TRANS_B:
        b_ptrs = b_ptr + offs_k[:, None] + k_lo + offs_n[None, :] * sbk
    else:
        b_ptrs = b_ptr + (offs_k[:, None] + k_lo) * sbk + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.mma_tile(a_ptrs, b_ptrs, k_rem, ATOM=ATOM, STAGES=STAGES,
                          TRANS_A=TRANS_A, TRANS_B=TRANS_B,
                          TVEC_A=TVEC_A, TVEC_B=TVEC_B, ONE_BAR=ONE_BAR)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.mma_tile(a_ptrs, b_ptrs, k_rem, ATOM=ATOM, STAGES=STAGES,
                          EVEN_K=False, VEC=False,
                          a_mask=am, b_mask=bn,
                          TRANS_A=TRANS_A, TRANS_B=TRANS_B, ONE_BAR=ONE_BAR)
    c_base = c_ptr + pid_k * (M * N)
    if EVEN_MN:
        tl.store(c_base + offs_m[:, None] * N + offs_n[None, :], acc)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_base + offs_m[:, None] * N + offs_n[None, :], acc,
                 mask=cm)


# (BM, BN, BK, num_warps, STAGES) x SPLIT_K; probed on the e2e dW shape
# family (M in 640..2560, K=16384, trans-A): mid-size 64x128 tiles win
# (L2 reuse vs CTA count); a tiny-tile entry stays for the N=96 head.
# GROUP_M fixed at 8.
_MMA_TILES_SPLITK = [
    (64, 128, 32, 4, 2),
    (128, 64, 32, 4, 2),
    (128, 128, 32, 8, 2),
    (64, 64, 32, 2, 2),
    (64, 64, 32, 4, 2),
    (32, 64, 32, 2, 4),
]


def _mm_splitk_configs(atom, M: int, N: int, K: int, sam: int, sbk: int,
                       trans_a: bool, trans_b: bool, a_dt=None, b_dt=None):
    from ....frontend import types as _t
    bf = _t.bfloat16
    align_a = 8 if (a_dt is None or a_dt == bf) else 4
    align_b = 8 if (b_dt is None or b_dt == bf) else 4
    pipes = (False, True) if atom == "bf16" else (False,)
    cfgs = []
    for bm, bn, bk, w, stages in _MMA_TILES_SPLITK:
        for sk in (2, 4, 8, 16):
            # every split must hold at least one BK window
            kspan = ((K + sk * bk - 1) // (sk * bk)) * bk
            if (sk - 1) * kspan >= K:
                continue
            if sk * M * N > 12_000_000:   # f32 partials budget ~48MB
                continue
            for pipe in pipes:
                cfgs.append(tl.Config(
                    {"BM": bm, "BN": bn, "BK": bk, "ATOM": atom,
                     "STAGES": stages, "GROUP_M": 8, "SPLIT_K": sk,
                     "EVEN_MK": M % bm == 0 and K % bk == 0
                                and (trans_a or sam % align_a == 0),
                     "EVEN_KN": K % bk == 0 and N % bn == 0
                                and (trans_b or sbk % align_b == 0),
                     "EVEN_MN": M % bm == 0 and N % bn == 0,
                     "EVEN_K": K % bk == 0,
                     "TRANS_A": trans_a, "TRANS_B": trans_b,
                     "TVEC_A": (a_dt is None or a_dt == bf)
                                and trans_a and sam % align_a == 0,
                     "TVEC_B": (b_dt is None or b_dt == bf)
                                and trans_b and sbk % align_b == 0,
                     "ONE_BAR": pipe},
                    num_warps=w))
    return cfgs


def _mm_splitk_tuner(atom, M: int, N: int, K: int, sam: int, sbk: int,
                     trans_a: bool, trans_b: bool, a_dt=None, b_dt=None):
    from ....runtime.autotune import Autotuner
    key = ("mma_splitk", atom, M, N, K, sam, sbk, trans_a, trans_b,
           a_dt, b_dt)
    tuner = _tuners.get(key)
    if tuner is None:
        tuner = Autotuner(
            matmul_mma_splitk_kernel,
            _mm_splitk_configs(atom, M, N, K, sam, sbk, trans_a, trans_b,
                               a_dt, b_dt),
            ["M", "N", "K"],
            extra_key=(atom, sam, sbk, trans_a, trans_b,
                       getattr(a_dt, "name", a_dt),
                       getattr(b_dt, "name", b_dt)))
        _tuners[key] = tuner
    return tuner


# the splitk kernel has neither DYN_SMEM nor ONE_SHOT parameters (both are
# the plain mma kernel's spike features) nor EPI (the smem epilogue is a
# plain-route knob), so the template drops those keys
_MMA_KW_SPLITK = {k: v for k, v in dict(_MMA_KW, SPLIT_K=0).items()
                  if k not in ("DYN_SMEM", "ONE_SHOT", "EPI")}




def launch_matmul_mma_splitk(a, b, partials, M: int, N: int, K: int,
                             atom: str):
    """Split-K mma launch into f32 partials (SPLIT_K, M, N); the caller
    reduces over axis 0. Same operand contract as launch_matmul_mma."""
    ta, tb = _trans_kstride(a), _trans_kstride(b)
    sam = ta if ta is not None else a.strides[0]
    sbk = tb if tb is not None else b.strides[0]
    if not mma_strides_ok(atom, sam, sbk, a.dtype, b.dtype):
        raise RuntimeError(f"mma {atom} needs even row strides, got "
                           f"{sam}/{sbk}")
    tuner = _mm_splitk_tuner(atom, M, N, K, sam, sbk,
                             ta is not None, tb is not None,
                             a.dtype, b.dtype)
    grid = lambda args: (((args["M"] + args["BM"] - 1) // args["BM"])
                         * ((args["N"] + args["BN"] - 1) // args["BN"]),
                         1, args["SPLIT_K"])
    args = (a._buffer_arg(), b._buffer_arg(), partials._buffer_arg(),
            M, N, K, sam, sbk)
    tuner.launch(matmul_mma_splitk_kernel, grid, args, None,
                 dict(_MMA_KW_SPLITK))
    return splitk_pick(atom, M, N, K, sam, sbk, ta is not None,
                       tb is not None, a.dtype, b.dtype)


def splitk_pick(atom: str, M: int, N: int, K: int, sam: int, sbk: int,
                trans_a: bool, trans_b: bool, a_dt=None, b_dt=None) -> int:
    """The tuner's chosen SPLIT_K for this shape key (0 if untuned)."""
    tuner = _tuners.get(("mma_splitk", atom, M, N, K, sam, sbk,
                         trans_a, trans_b, a_dt, b_dt))
    if tuner is None:
        return 0
    # kvals carry the instance salt (atom, strides, trans, dtypes) — the
    # bare (M, N, K) lookup misses every salted entry and silently
    # disables the split-K route (0 = "untuned")
    cfg = tuner._mem.get((M, N, K) + tuner._extra)
    return cfg.kwargs["SPLIT_K"] if cfg is not None else 0


def mma_strides_ok(atom: str, sam: int, sbk: int, a_dt=None, b_dt=None):
    """Structural stride constraint for the mma staging: a bf16 operand
    needs even strides (staging quantum is one 4B pair); f32-staged
    operands (cast-in-kernel bf16 route) stage 4B per element, no
    constraint; tf32 none. Vec-path 16B alignment is a config-level
    (EVEN_*) performance matter, not a constraint."""
    if atom != "bf16":
        return True
    for dt, s in ((a_dt, sam), (b_dt, sbk)):
        if (dt is None or dt.name == "bf16") and s % 2:
            return False
    return True


def launch_matmul_mma(a, b, out, M: int, N: int, K: int, atom: str,
                      bias=None):
    """mma matmul launcher: a/b are unit-last-stride or pure transpose
    views (same contract as launch_matmul); out holds the f32-accumulated
    result — f32, or bf16 for the bf16 tier's direct store. bf16-atom
    operands may be f32 (staged f32, packed to bf16 in-register). bias
    (optional (N,) bf16/f32, bf16-out plain route only): fused Linear
    bias epilogue (added to the f32 accumulators before the bf16 pack —
    the cublasLt single-rounding semantics)."""
    ta, tb = _trans_kstride(a), _trans_kstride(b)
    sam = ta if ta is not None else a.strides[0]
    sbk = tb if tb is not None else b.strides[0]
    if not mma_strides_ok(atom, sam, sbk, a.dtype, b.dtype):
        raise RuntimeError(f"mma {atom} needs even row strides, got "
                           f"{sam}/{sbk}")
    tuner = _mm_mma_tuner(matmul_mma_kernel, atom, M, N, K, sam, sbk,
                          ta is not None, tb is not None,
                          a.dtype, b.dtype)
    grid = lambda args: (((args["M"] + args["BM"] - 1) // args["BM"])
                         * ((args["N"] + args["BN"] - 1) // args["BN"]),)
    args = (a._buffer_arg(), b._buffer_arg(), out._buffer_arg(),
            M, N, K, sam, sbk,
            (bias if bias is not None else out)._buffer_arg())
    kw = dict(_MMA_KW, BIAS=bias is not None, F2F=False)
    tuner.launch(matmul_mma_kernel, grid, args, None, kw)


@tl.kernel
def bmm_mma_kernel(a_ptr, b_ptr, c_ptr, M, N, K, sab, sam, sbb, sbk,
                   BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
                   ATOM: tl.constexpr, STAGES: tl.constexpr,
                   GROUP_M: tl.constexpr,
                   EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
                   EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr,
                   ONE_BAR: tl.constexpr):
    pid = tl.program_id(0)
    pid_b = tl.program_id(2)
    num_pid_m = (M + BM - 1) // BM
    num_pid_n = (N + BN - 1) // BN
    num_in_group = GROUP_M * num_pid_n
    group_id = pid // num_in_group
    first_pid_m = group_id * GROUP_M
    group_size = tl.where(num_pid_m - first_pid_m < GROUP_M,
                          num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size)
    pid_n = (pid % num_in_group) // group_size
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + pid_b * sab + offs_m[:, None] * sam + offs_k[None, :]
    b_ptrs = b_ptr + pid_b * sbb + offs_k[:, None] * sbk + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM=ATOM, STAGES=STAGES,
                          ONE_BAR=ONE_BAR)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM=ATOM, STAGES=STAGES,
                          EVEN_K=EVEN_K, VEC=False,
                          a_mask=am, b_mask=bn, ONE_BAR=ONE_BAR)
    if EVEN_MN:
        tl.store(c_ptr + pid_b * (M * N) + offs_m[:, None] * N
                 + offs_n[None, :], acc)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + pid_b * (M * N) + offs_m[:, None] * N
                 + offs_n[None, :], acc, mask=cm)


def launch_bmm_mma(a, b, out, B: int, M: int, N: int, K: int, atom: str):
    sam, sbk = a.strides[1], b.strides[1]
    if not mma_strides_ok(atom, sam, sbk):
        raise RuntimeError(f"mma {atom} needs even row strides, got "
                           f"{sam}/{sbk}")
    tuner = _mm_mma_tuner(bmm_mma_kernel, atom, M, N, K, sam, sbk,
                          epi=False)
    grid = lambda args: (((args["M"] + args["BM"] - 1) // args["BM"])
                         * ((args["N"] + args["BN"] - 1) // args["BN"]), 1, B)
    args = (a._buffer_arg(), b._buffer_arg(), out._buffer_arg(),
            M, N, K, a.strides[0], a.strides[1], b.strides[0], b.strides[1])
    tuner.launch(bmm_mma_kernel, grid, args, None, dict(_MMA_KW_BMM))


_MMA_KW_BMM = {"BM": 0, "BN": 0, "BK": 0, "ATOM": "tf32", "STAGES": 0,
               "GROUP_M": 0, "EVEN_MK": False, "EVEN_KN": False,
               "EVEN_MN": False, "EVEN_K": False, "ONE_BAR": False}




__all__ = [
    "_MM_TILES",
    "matmul_kernel",
    "bmm_kernel",
    "matmul_v2_kernel",
    "bmm_v2_kernel",
    "_MM_V2_TILES",
    "_tile_ok",
    "_mm_v2_configs",
    "_tuners",
    "_mm_tuner",
    "_mm_v2_tuner",
    "_V2_KW",
    "_V2_KW_BMM",
    "_trans_kstride",
    "launch_matmul",
    "launch_bmm",
    "matmul_v2_splitk_kernel",
    "_MM_V2_TILES_SPLITK",
    "_mm_v2_splitk_configs",
    "_mm_v2_splitk_tuner",
    "_V2_KW_SPLITK",
    "launch_matmul_v2_splitk",
    "splitk_v2_pick",
    "matmul_ds_kernel",
    "launch_matmul_ds",
    "matmul_mma_kernel",
    "_MMA_TILES_TF32",
    "_MMA_TILES_BF16",
    "_MMA_TILES_BF16_ONE_BAR",
    "_MMA_TILES_BF16_EPI",
    "_epi_launchable",
    "_mm_mma_configs",
    "_mm_mma_tuner",
    "_MMA_KW",
    "matmul_mma_splitk_kernel",
    "_MMA_TILES_SPLITK",
    "_mm_splitk_configs",
    "_mm_splitk_tuner",
    "_MMA_KW_SPLITK",
    "launch_matmul_mma_splitk",
    "splitk_pick",
    "mma_strides_ok",
    "launch_matmul_mma",
    "bmm_mma_kernel",
    "launch_bmm_mma",
    "_MMA_KW_BMM",
]
