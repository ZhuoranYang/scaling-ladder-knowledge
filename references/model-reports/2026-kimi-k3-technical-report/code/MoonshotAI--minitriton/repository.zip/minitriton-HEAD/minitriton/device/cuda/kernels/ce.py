"""Cross-entropy row kernels of the device/cuda kernels package:
single-block fwd, the wide-row split-reduction fwd (partials +
merge), and the backward rows (+ the lse apply variant).

All kernels assume the *last* dim of every operand is unit-stride (the
eager layer calls .contiguous() when that is not the case); other strides
are runtime i32 arguments.

``import minitriton as tl`` here resolves against the partially initialized
package (frontend/runtime names are exported before the eager layer is
imported), which is what makes the decorators work at import time.

NOTE: no ``from __future__ import annotations`` here — kernel parameter
annotations (``tl.constexpr``) must stay real objects for the DSL binder.
"""

import minitriton as tl
from ._common import _row_block

_I32_ELEM_BUDGET = 2**31 - 1


@tl.kernel
def cross_entropy_row_kernel(x_ptr, t_ptr, out_ptr, C,
                             CALC_F32: tl.constexpr, BLOCK: tl.constexpr):
    """out[row] = logsumexp(x[row]) - x[row, t[row]]  (NLL, reduction none)."""
    row = tl.program_id(0)
    t = tl.load(t_ptr + row)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=float("-inf"))
    if CALC_F32:
        # sub-f32 floats compute in f32 (CALC_F32 discipline); the
        # scalar store casts the result back to the out dtype
        x = tl.cast(x, tl.float32)
    x_max = tl.max(x)
    e = tl.exp(x - x_max)
    s = tl.sum(e)
    xt = tl.sum(tl.where(offs == t, x, 0.0))
    tl.store(out_ptr + row, (tl.log(s) + x_max) - xt)


def _ce_i32_row_budget(x, C: int) -> int:
    """Rows per launch: keep element offsets below 2**31 (i32 addressing)
    and the row-chunk view bases 16B-aligned (the vectorized load/store
    path assumes an aligned base; a row slice at an unaligned element
    offset would fault)."""
    align = 16 // x.dtype.itemsize
    budget = _I32_ELEM_BUDGET // C // align
    if budget == 0:
        raise NotImplementedError(
            f"row length {C} is too wide to chunk under i32 addressing")
    return budget * align


def launch_cross_entropy_rows(x, t, out, C: int):
    R = x.numel() // C if C else 0
    if R == 0:
        return
    budget = _ce_i32_row_budget(x, C)
    if R > budget:
        # i32 addressing: keep each launch's element offsets below 2**31.
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_cross_entropy_rows(x[r0:r1], t[r0:r1], out[r0:r1], C)
        return
    if C <= _CE_SINGLE_MAX:
        block = _row_block(C)
        cross_entropy_row_kernel[(R,)](x._buffer_arg(), t._buffer_arg(),
                                       out._buffer_arg(), C,
                                       CALC_F32=x.dtype.is_float
                                       and x.dtype.itemsize < 4,
                                       BLOCK=block, num_warps=4)
        return
    seg, s = _ce_split_plan(C)
    if s == 1:
        # one program per row, online loop == the single-pass shape but
        # with a bounded register footprint (BLOCK-wide chunks)
        cross_entropy_partials_kernel[(R,)](
            x._buffer_arg(), t._buffer_arg(), x._buffer_arg(),
            x._buffer_arg(), out._buffer_arg(), C, s, seg,
            SINGLE=True, BLOCK=_CE_BLOCK, num_warps=4)
        return
    from ....tensor import empty  # local import: avoid cycle
    mp = empty((R * s,), tl.float32, "cuda")
    sp = empty((R * s,), tl.float32, "cuda")
    cross_entropy_partials_kernel[(R * s,)](
        x._buffer_arg(), t._buffer_arg(), mp._buffer_arg(),
        sp._buffer_arg(), out._buffer_arg(), C, s, seg,
        SINGLE=False, BLOCK=_CE_BLOCK, num_warps=4)
    cross_entropy_merge_kernel[(R,)](
        mp._buffer_arg(), sp._buffer_arg(), x._buffer_arg(),
        t._buffer_arg(), out._buffer_arg(), C, s,
        LSE=False, SBLOCK=_ce_sblock(s), num_warps=4)



# ---------------------------------------------------------------------------
# cross_entropy split-reduction (wide rows): stage 1 reduces each row
# segment to an online (max, sum(exp(x - max))) pair; stage 2 merges the
# partials into the per-row NLL (or the lse that the backward apply kernel
# consumes). Rows up to _CE_SINGLE_MAX keep the single-pass kernels.
# ---------------------------------------------------------------------------

_CE_BLOCK = 1024        # chunk width of the online reduction loop
_CE_SEG = 8192          # nominal columns per segment (one program)
_CE_SEG_MAX = 1024      # cap on segments/row: the merge stays one block
# single-pass cutoff: wider rows go through the split/online path
_CE_SINGLE_MAX = 2048
_CE_BWD_SINGLE_MAX = 8192   # bwd: fused online single-program form up
                            # to the row-kernel cap (bit-equal to the
                            # split chain it replaces there)
_CE_BWD_FUSED_MIN_ELEMS = 1 << 24   # ...but only with enough rows: the
                            # serial two-pass per program needs ~3 CTA
                            # waves to hide (crossover 2^24)


def _ce_split_plan(C: int) -> tuple[int, int]:
    """(SEG, S) for a wide row: S segments of SEG = BLOCK-multiple columns
    (SEG must be a _CE_BLOCK multiple so chunks never straddle segments)."""
    s = min((C + _CE_SEG - 1) // _CE_SEG, _CE_SEG_MAX)
    seg = ((C + s - 1) // s + _CE_BLOCK - 1) // _CE_BLOCK * _CE_BLOCK
    return seg, (C + seg - 1) // seg


def _ce_sblock(s: int) -> int:
    return max(128, ((s + 127) // 128) * 128)


@tl.kernel
def cross_entropy_partials_kernel(x_ptr, t_ptr, mp_ptr, sp_ptr, out_ptr,
                                  C, S, SEG,
                                  SINGLE: tl.constexpr, BLOCK: tl.constexpr):
    """Grid (R*S,): program (row, seg) reduces x[row, seg*SEG:(seg+1)*SEG]
    to an online (max m, sum(exp(x - m)) s) pair, one BLOCK chunk per
    iteration. SINGLE (S == 1): finish the row in-program and store
    out[row] = logsumexp - x[row, t]; else store the partials."""
    pid = tl.program_id(0)
    row = pid // S
    seg = pid % S
    offs = tl.arange(0, BLOCK)
    m = float("-inf")
    s = 0.0
    for c0 in range(0, SEG, BLOCK):
        idx = seg * SEG + c0 + offs
        # f32 compute (the load cast is a no-op for f32 inputs): sub-f32
        # float rows reduce in f32 — the CALC_F32 discipline
        x = tl.cast(tl.load(x_ptr + row * C + idx, mask=idx < C,
                            other=float("-inf")), tl.float32)
        mx = tl.max(x)
        nm = tl.where(mx > m, mx, m)
        s = s * tl.exp(m - nm) + tl.sum(tl.exp(x - nm))
        m = nm
    if SINGLE:
        t = tl.load(t_ptr + row)
        xt = tl.load(x_ptr + row * C + t)
        tl.store(out_ptr + row, (m + tl.log(s)) - xt)
    else:
        tl.store(mp_ptr + pid, m)
        tl.store(sp_ptr + pid, s)


@tl.kernel
def cross_entropy_merge_kernel(mp_ptr, sp_ptr, x_ptr, t_ptr, out_ptr, C, S,
                               LSE: tl.constexpr, SBLOCK: tl.constexpr):
    """One program per row: merge the S segment partials into
    lse = logsumexp(x[row]); store lse (LSE=True, for the backward apply
    kernel) or the NLL lse - x[row, t[row]] (LSE=False)."""
    row = tl.program_id(0)
    offs = tl.arange(0, SBLOCK)
    msk = offs < S
    mp = tl.load(mp_ptr + row * S + offs, mask=msk, other=float("-inf"))
    sp = tl.load(sp_ptr + row * S + offs, mask=msk, other=0.0)
    m = tl.max(mp)
    s = tl.sum(sp * tl.exp(mp - m))
    lse = m + tl.log(s)
    if LSE:
        tl.store(out_ptr + row, lse)
    else:
        t = tl.load(t_ptr + row)
        xt = tl.load(x_ptr + row * C + t)
        tl.store(out_ptr + row, lse - xt)



@tl.kernel
def cross_entropy_backward_kernel(x_ptr, t_ptr, g_ptr, dx_ptr, C,
                                  CALC_F32: tl.constexpr,
                                  OUT_DT: tl.constexpr,
                                  BLOCK: tl.constexpr):
    """dx = (softmax(x) - onehot(t)) * g[row]  per row."""
    row = tl.program_id(0)
    t = tl.load(t_ptr + row)
    gr = tl.load(g_ptr + row)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=float("-inf"))
    if CALC_F32:
        x = tl.cast(x, tl.float32)
    x_max = tl.max(x)
    e = tl.exp(x - x_max)
    s = tl.sum(e)
    p = e / s
    onehot = tl.cast(offs == t, tl.float32)
    tl.store(dx_ptr + row * C + offs, tl.cast((p - onehot) * gr, OUT_DT),
             mask=m)


@tl.kernel
def cross_entropy_backward_online_kernel(x_ptr, t_ptr, g_ptr, dx_ptr, C,
                                         SEG, CALC_F32: tl.constexpr,
                                         OUT_DT: tl.constexpr,
                                         BLOCK: tl.constexpr):
    """dx = (exp(x - lse[row]) - onehot(t[row])) * g[row] for one wide row
    in ONE program. Pass 1 computes lse = m + log(s) with the same
    online (max, sum-exp) chunked loop as cross_entropy_partials_kernel
    (at s == 1 the merge stage is the exact identity), pass 2 applies —
    bit-identical to the partials + merge + apply chain it replaces at
    2048 < C <= 8192, with 1/3 of the kernels and no partial planes.
    Sub-f32 float rows take this route at any width (the split chain's
    apply kernel keeps its frozen f32 signature); CALC_F32 computes in
    f32 and OUT_DT packs back on store."""
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = float("-inf")
    s = 0.0
    for c0 in range(0, SEG, BLOCK):
        idx = c0 + offs
        x = tl.load(x_ptr + row * C + idx, mask=idx < C,
                    other=float("-inf"))
        if CALC_F32:
            x = tl.cast(x, tl.float32)
        mx = tl.max(x)
        nm = tl.where(mx > m, mx, m)
        s = s * tl.exp(m - nm) + tl.sum(tl.exp(x - nm))
        m = nm
    lse = m + tl.log(s)
    t = tl.load(t_ptr + row)
    gr = tl.load(g_ptr + row)
    for c0 in range(0, SEG, BLOCK):
        idx = c0 + offs
        msk = idx < C
        x = tl.load(x_ptr + row * C + idx, mask=msk, other=0.0)
        if CALC_F32:
            x = tl.cast(x, tl.float32)
        p = tl.exp(x - lse)
        onehot = tl.cast(idx == t, tl.float32)
        tl.store(dx_ptr + row * C + idx, tl.cast((p - onehot) * gr, OUT_DT),
                 mask=msk)



def launch_cross_entropy_backward(x, t, g, out, C: int):
    R = x.numel() // C if C else 0
    if R == 0:
        return
    budget = _ce_i32_row_budget(x, C)
    if R > budget:
        for r0 in range(0, R, budget):
            r1 = min(r0 + budget, R)
            launch_cross_entropy_backward(x[r0:r1], t[r0:r1], g[r0:r1],
                                          out[r0:r1], C)
        return
    calc_f32 = x.dtype.is_float and x.dtype.itemsize < 4
    if C <= _CE_SINGLE_MAX:
        block = _row_block(C)
        cross_entropy_backward_kernel[(R,)](x._buffer_arg(), t._buffer_arg(),
                                            g._buffer_arg(), out._buffer_arg(),
                                            C, CALC_F32=calc_f32,
                                            OUT_DT=out.dtype,
                                            BLOCK=block, num_warps=4)
        return
    if calc_f32 or (
            C <= _CE_BWD_SINGLE_MAX and R * C >= _CE_BWD_FUSED_MIN_ELEMS):
        # 2048 < C <= 8192 with enough rows: one fused online program
        # per row — bit-equal to the partials+merge+apply chain (s == 1)
        # (the rowfam pocket). Below the element
        # threshold the chain's parallel apply wins on occupancy, so it
        # stays. Sub-f32 float rows always take this route (any width):
        # the chain's apply kernel keeps its frozen f32-only signature
        # (direct-launch compat), the online form carries CALC_F32.
        seg = (C + _CE_BLOCK - 1) // _CE_BLOCK * _CE_BLOCK
        cross_entropy_backward_online_kernel[(R,)](
            x._buffer_arg(), t._buffer_arg(), g._buffer_arg(),
            out._buffer_arg(), C, seg, CALC_F32=calc_f32,
            OUT_DT=out.dtype, BLOCK=_CE_BLOCK, num_warps=4)
        return
    seg, s = _ce_split_plan(C)
    from ....tensor import empty  # local import: avoid cycle
    mp = empty((R * s,), tl.float32, "cuda")
    sp = empty((R * s,), tl.float32, "cuda")
    lse = empty((R,), tl.float32, "cuda")
    cross_entropy_partials_kernel[(R * s,)](
        x._buffer_arg(), t._buffer_arg(), mp._buffer_arg(),
        sp._buffer_arg(), out._buffer_arg(), C, s, seg,
        SINGLE=False, BLOCK=_CE_BLOCK, num_warps=4)
    cross_entropy_merge_kernel[(R,)](
        mp._buffer_arg(), sp._buffer_arg(), x._buffer_arg(),
        t._buffer_arg(), lse._buffer_arg(), C, s,
        LSE=True, SBLOCK=_ce_sblock(s), num_warps=4)
    sa = (C + _CE_BLOCK - 1) // _CE_BLOCK
    cross_entropy_backward_apply_kernel[(R * sa,)](
        x._buffer_arg(), t._buffer_arg(), g._buffer_arg(),
        lse._buffer_arg(), out._buffer_arg(), C, sa,
        BLOCK=_CE_BLOCK, num_warps=4)


@tl.kernel
def cross_entropy_backward_apply_kernel(x_ptr, t_ptr, g_ptr, lse_ptr, dx_ptr,
                                        C, SA, BLOCK: tl.constexpr):
    """Grid (R*SA,): one BLOCK chunk of dx per program,
    dx = (exp(x - lse[row]) - onehot(t[row])) * g[row]; lse comes from the
    partials + merge stages, so any row width works."""
    pid = tl.program_id(0)
    row = pid // SA
    offs = (pid % SA) * BLOCK + tl.arange(0, BLOCK)
    msk = offs < C
    lse = tl.load(lse_ptr + row)
    t = tl.load(t_ptr + row)
    gr = tl.load(g_ptr + row)
    x = tl.load(x_ptr + row * C + offs, mask=msk, other=0.0)
    p = tl.exp(x - lse)
    onehot = tl.cast(offs == t, tl.float32)
    tl.store(dx_ptr + row * C + offs, (p - onehot) * gr, mask=msk)




__all__ = [
    "cross_entropy_row_kernel",
    "cross_entropy_backward_online_kernel",
    "_ce_i32_row_budget",
    "_I32_ELEM_BUDGET",
    "launch_cross_entropy_rows",
    "_CE_BLOCK",
    "_CE_SEG",
    "_CE_SEG_MAX",
    "_CE_SINGLE_MAX",
    "_ce_split_plan",
    "_ce_sblock",
    "cross_entropy_partials_kernel",
    "cross_entropy_merge_kernel",
    "cross_entropy_backward_kernel",
    "launch_cross_entropy_backward",
    "cross_entropy_backward_apply_kernel",
]
