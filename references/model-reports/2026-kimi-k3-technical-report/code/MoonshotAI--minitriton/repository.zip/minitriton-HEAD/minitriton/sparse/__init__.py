"""Sparse / message-passing primitives.

GNN/sim message passing = gather -> transform -> scatter-reduce. These ops
are first-class tile kernels on CUDA (the MatOff materialized-index
addressing path lowers ``ptr + i32_block`` to per-lane gather loads /
``red.global.add.f32`` atomics) and numpy/scipy code on CPU (the numerical
oracle, ``np.add.at`` / ``scipy.sparse``).

Public ops (all autograd-aware; f32 values, i32/i64 indices):

- ``gather(x, idx, dim=0)`` — torch.gather semantics on 2D ``x``, plus the
  row-gather special case ``idx`` 1D + ``dim=0`` (``out[i] = x[idx[i]]``,
  embedding-style). dim=1: ``out[r, j] = x[r, idx[r, j]]`` with idx (R, E);
  dim=0 with idx (E, D): ``out[i, j] = x[idx[i, j], j]``. Backward =
  scatter-add.
- ``scatter_add(src, idx, out_shape)`` — index-add: ``out[idx[i]] += src[i]``
  for src (E,) or (E, D) with idx (E,). Backward = row/flat gather.
- ``segment_reduce(values, row_ptr, op="sum"|"max")`` — CSR variable-length
  row reduction: ``out[r] = reduce(values[rp[r]:rp[r+1]])``. Empty segments
  yield the neutral element (0 for sum, -inf for max).
- ``spmm_csr(row_ptr, col_idx, val, dense)`` — ``out = A @ dense`` with A
  (R, K) in CSR. Backward needs dense width <= 8192.

Limits: values f32; addressing is i32.

Cell-list building blocks:

- ``searchsorted(sorted_seq, values, side="left")`` — per-lane GPU binary
  search (MatOff gathers), out i32; matches np.searchsorted.
- ``coo_sort_by_key(keys, values=None)`` — full bitonic sort (pow2 pad),
  payload ``values`` defaults to the identity permutation. Keys i32 (any
  sign), values i32/f32. Not stable; grouping only.
- ``cell_list(keys, num_cells)`` — sort + boundary search pipeline:
  returns ``(row_ptr (num_cells+1,) i32, perm (N,) i32)`` with
  ``perm[row_ptr[c]:row_ptr[c+1]]`` = the original indices of the
  elements whose key is ``c``.
"""

from __future__ import annotations

from ..frontend import types as tl_types
from ..ops import _be, _tensor, _check_index_bounds
from ..tensor import Tensor
from ..autograd import engine
from ..autograd.engine import Context, Function

i32 = tl_types.int32


def _i32(t: Tensor) -> Tensor:
    return t if t.dtype == i32 else t.astype(i32)


def _contig(t: Tensor) -> Tensor:
    return t if t.is_contiguous() else t.contiguous()


# ---------------------------------------------------------------------------
# gather
# ---------------------------------------------------------------------------

def _gather_rows_raw(x2d: Tensor, idx1d: Tensor) -> Tensor:
    idx = _i32(_contig(idx1d.reshape((idx1d.numel(),))))
    if x2d.ndim == 1:
        return _be(x2d.device).gather_flat(_contig(x2d), idx)
    return _be(x2d.device).embedding_rows(
        _contig(x2d.reshape((x2d.shape[0], -1))), idx)


def _gather_raw(x: Tensor, idx: Tensor, dim: int) -> Tensor:
    if x.ndim == 2 and idx.ndim == 1 and dim == 0:
        _check_index_bounds(idx, x.shape[0], "gather")
        return _gather_rows_raw(x, idx)
    if x.ndim == 1 and dim in (0, -1):
        _check_index_bounds(idx, x.shape[0], "gather")
        return _gather_rows_raw(x, idx)
    if x.ndim != 2 or idx.ndim != 2:
        raise RuntimeError(
            f"gather currently expects 2D x and idx (or 1D idx for dim=0 row "
            f"gather / 1D x), got x{x.shape} idx{idx.shape}")
    dim %= 2
    if dim == 1:
        if idx.shape[0] != x.shape[0]:
            raise RuntimeError(
                f"gather dim=1: idx rows {idx.shape[0]} != x rows "
                f"{x.shape[0]}")
        _check_index_bounds(idx, x.shape[1], "gather")
        return _be(x.device).gather_cols(_contig(x), _i32(_contig(idx)))
    if idx.shape[1] != x.shape[1]:
        raise RuntimeError(
            f"gather dim=0: idx cols {idx.shape[1]} != x cols {x.shape[1]}")
    _check_index_bounds(idx, x.shape[0], "gather")
    return _be(x.device).gather_rc(_contig(x), _i32(_contig(idx)))


class _Gather(Function):
    @classmethod
    def forward(cls, ctx: Context, x: Tensor, idx: Tensor, dim: int):
        ctx.save_for_backward(idx)
        ctx.meta = {"dim": dim, "x_shape": x.shape, "x_ndim": x.ndim}
        return _gather_raw(x, idx, dim)

    @classmethod
    def backward(cls, ctx: Context, g: Tensor):
        (idx,) = ctx.saved
        dim, x_shape, x_ndim = (ctx.meta["dim"], ctx.meta["x_shape"],
                                ctx.meta["x_ndim"])
        if (idx.ndim == 1 and dim == 0) or x_ndim == 1:
            if x_ndim == 1:
                dx = _be(g.device).scatter_add_flat(
                    _contig(g.reshape((-1,))), _i32(_contig(idx.reshape((-1,)))),
                    x_shape[0])
            else:
                dx = _be(g.device).embedding_backward_rows(
                    _contig(g.reshape((g.shape[0], -1))),
                    _i32(_contig(idx.reshape((-1,)))), x_shape[0])
            return [dx.reshape(x_shape), None]
        if dim % 2 == 1:
            dx = _be(g.device).gather_cols_backward(
                _contig(g), _i32(_contig(idx)), x_shape[1])
        else:
            dx = _be(g.device).gather_rc_backward(
                _contig(g), _i32(_contig(idx)), x_shape[0])
        return [dx, None]


def gather(x, idx, dim: int = 0) -> Tensor:
    """Index x with idx along dim (see module docstring); idx gets no grad."""
    x = _tensor(x)
    idx = _tensor(idx, device=x.device)
    if idx.device != x.device:
        idx = idx.to(x.device)
    if idx.dtype.is_float:
        raise RuntimeError("gather indices must be integers")
    if engine.is_grad_enabled() and engine.any_requires_grad((x,), {}):
        return _Gather.apply(x, idx, dim)
    return _gather_raw(x, idx, dim)


# ---------------------------------------------------------------------------
# scatter_add
# ---------------------------------------------------------------------------

def _scatter_add_raw(src: Tensor, idx: Tensor, out_shape) -> Tensor:
    if idx.ndim != 1:
        raise RuntimeError(
            f"scatter_add currently expects 1D row indices, got idx{idx.shape}")
    if src.ndim not in (1, 2):
        raise RuntimeError(
            f"scatter_add currently expects 1D/2D src, got {src.shape}")
    if src.shape[0] != idx.numel():
        raise RuntimeError(
            f"scatter_add: src rows {src.shape[0]} != idx numel {idx.numel()}")
    out_shape = tuple(int(s) for s in out_shape)
    if len(out_shape) != src.ndim:
        raise RuntimeError(
            f"scatter_add: out_shape {out_shape} must have the same ndim "
            f"as src {src.shape}")
    if out_shape[1:] != src.shape[1:]:
        raise RuntimeError(
            f"scatter_add: out_shape {out_shape} trailing dims must match "
            f"src {src.shape}")
    _check_index_bounds(idx, out_shape[0], "scatter_add")
    idx = _i32(_contig(idx))
    if src.ndim == 1:
        return _be(src.device).scatter_add_flat(_contig(src), idx,
                                                out_shape[0])
    return _be(src.device).embedding_backward_rows(_contig(src), idx,
                                                   out_shape[0])


class _ScatterAdd(Function):
    @classmethod
    def forward(cls, ctx: Context, src: Tensor, idx: Tensor, out_shape):
        ctx.save_for_backward(idx)
        return _scatter_add_raw(src, idx, out_shape)

    @classmethod
    def backward(cls, ctx: Context, g: Tensor):
        (idx,) = ctx.saved
        idx = _i32(_contig(idx.reshape((-1,))))
        if g.ndim == 1:
            ds = _be(g.device).gather_flat(_contig(g), idx)
        else:
            ds = _be(g.device).embedding_rows(
                _contig(g.reshape((g.shape[0], -1))), idx)
        return [ds, None]


def scatter_add(src, idx, out_shape) -> Tensor:
    """out = zeros(out_shape); out[idx[i]] += src[i] (i32 atomic, f32)."""
    src = _tensor(src)
    idx = _tensor(idx, device=src.device)
    if idx.device != src.device:
        idx = idx.to(src.device)
    if idx.dtype.is_float:
        raise RuntimeError("scatter_add indices must be integers")
    if src.dtype.is_int:
        src = src.astype(tl_types.float32)
    if engine.is_grad_enabled() and engine.any_requires_grad((src,), {}):
        return _ScatterAdd.apply(src, idx, tuple(out_shape))
    return _scatter_add_raw(src, idx, out_shape)


# ---------------------------------------------------------------------------
# segment_reduce
# ---------------------------------------------------------------------------

def _segment_check(values: Tensor, row_ptr: Tensor, op: str):
    if values.ndim != 1:
        raise RuntimeError(
            f"segment_reduce currently expects 1D values, got {values.shape}")
    if row_ptr.ndim != 1 or row_ptr.numel() < 1:
        raise RuntimeError(
            f"segment_reduce expects 1D row_ptr of length R+1, got "
            f"{row_ptr.shape}")
    if row_ptr.dtype.is_float:
        raise RuntimeError("segment_reduce row_ptr must be integers")
    if op not in ("sum", "max"):
        raise ValueError(f"segment_reduce op must be 'sum' or 'max', got {op!r}")


def _segment_reduce_raw(values: Tensor, row_ptr: Tensor, op: str) -> Tensor:
    rp = _i32(_contig(row_ptr))
    return _be(values.device).segment_reduce_values(_contig(values), rp, op)


class _SegmentReduce(Function):
    @classmethod
    def forward(cls, ctx: Context, values: Tensor, row_ptr: Tensor, op: str):
        ctx.save_for_backward(values, row_ptr)
        ctx.meta["op"] = op
        return _segment_reduce_raw(values, row_ptr, op)

    @classmethod
    def backward(cls, ctx: Context, g: Tensor):
        values, row_ptr = ctx.saved
        gv = _be(g.device).segment_reduce_backward(
            _contig(g), _contig(values), _i32(_contig(row_ptr)),
            ctx.meta["op"])
        return [gv, None]


def segment_reduce(values, row_ptr, op: str = "sum") -> Tensor:
    """out[r] = reduce(values[row_ptr[r]:row_ptr[r+1]]) (CSR row reduce)."""
    values = _tensor(values)
    row_ptr = _tensor(row_ptr, device=values.device)
    if row_ptr.device != values.device:
        row_ptr = row_ptr.to(values.device)
    _segment_check(values, row_ptr, op)
    if engine.is_grad_enabled() and engine.any_requires_grad((values,), {}):
        return _SegmentReduce.apply(values, row_ptr, op)
    return _segment_reduce_raw(values, row_ptr, op)


# ---------------------------------------------------------------------------
# spmm_csr
# ---------------------------------------------------------------------------

def _spmm_check(rp: Tensor, col: Tensor, val: Tensor, dense: Tensor):
    if dense.ndim != 2:
        raise RuntimeError(f"spmm_csr expects a 2D dense, got {dense.shape}")
    if rp.ndim != 1 or col.ndim != 1 or val.ndim != 1:
        raise RuntimeError("spmm_csr expects 1D row_ptr/col_idx/val")
    if col.numel() != val.numel():
        raise RuntimeError(
            f"spmm_csr: col_idx numel {col.numel()} != val numel "
            f"{val.numel()}")
    if rp.dtype.is_float or col.dtype.is_float:
        raise RuntimeError("spmm_csr row_ptr/col_idx must be integers")


def _spmm_csr_raw(rp: Tensor, col: Tensor, val: Tensor,
                  dense: Tensor) -> Tensor:
    return _be(dense.device).spmm_csr_forward(
        _i32(_contig(rp)), _i32(_contig(col)), _contig(val), _contig(dense))


class _SpmmCsr(Function):
    @classmethod
    def forward(cls, ctx: Context, rp: Tensor, col: Tensor, val: Tensor,
                dense: Tensor):
        ctx.save_for_backward(rp, col, val, dense)
        return _spmm_csr_raw(rp, col, val, dense)

    @classmethod
    def backward(cls, ctx: Context, g: Tensor):
        rp, col, val, dense = ctx.saved
        be = _be(g.device)
        g = _contig(g)
        rpc, colc = _i32(_contig(rp)), _i32(_contig(col))
        dval = None
        if val.requires_grad:
            dval = be.spmm_csr_backward_val(g, rpc, colc, _contig(dense))
        ddense = None
        if dense.requires_grad:
            ddense = be.spmm_csr_backward_dense(g, rpc, colc, _contig(val),
                                                dense.shape[0])
        return [None, None, dval, ddense]


def spmm_csr(row_ptr, col_idx, val, dense) -> Tensor:
    """out = A @ dense with A (R, K) in CSR (val f32; row_ptr/col_idx int)."""
    dense = _tensor(dense)
    val = _tensor(val, device=dense.device)
    row_ptr = _tensor(row_ptr, device=dense.device)
    col_idx = _tensor(col_idx, device=dense.device)
    if val.device != dense.device:
        val = val.to(dense.device)
    if row_ptr.device != dense.device:
        row_ptr = row_ptr.to(dense.device)
    if col_idx.device != dense.device:
        col_idx = col_idx.to(dense.device)
    _spmm_check(row_ptr, col_idx, val, dense)
    if engine.is_grad_enabled() and \
            engine.any_requires_grad((val, dense), {}):
        return _SpmmCsr.apply(row_ptr, col_idx, val, dense)
    return _spmm_csr_raw(row_ptr, col_idx, val, dense)


# ---------------------------------------------------------------------------
# searchsorted / coo_sort_by_key / cell_list
# ---------------------------------------------------------------------------

def searchsorted(sorted_seq, values, side: str = "left") -> Tensor:
    """out[i] = insertion index of values[i] in sorted (ascending)
    sorted_seq (np.searchsorted semantics); out i32. 1D inputs, sorted_seq
    i32/f32, values same dtype family as sorted_seq."""
    a = _tensor(sorted_seq)
    v = _tensor(values, device=a.device)
    if v.device != a.device:
        v = v.to(a.device)
    if a.ndim != 1 or v.ndim != 1:
        raise RuntimeError(
            f"searchsorted expects 1D inputs, got a{a.shape} v{v.shape}")
    if side not in ("left", "right"):
        raise ValueError(f"side must be 'left' or 'right', got {side!r}")
    return _be(a.device).searchsorted(_contig(a), _contig(v), side)


def coo_sort_by_key(keys, values=None) -> tuple[Tensor, Tensor]:
    """(sorted_keys, sorted_values): keys sorted ascending in O(log^2 N)
    substep launches (bitonic network, pow2-padded, NOT stable). values
    defaults to the identity permutation (perm[rank] = original index).
    Keys i32 within (-2**31+1, 2**31-1); values i32/f32."""
    k = _tensor(keys)
    if k.dtype != i32:
        k = _i32(k)
    if k.ndim != 1:
        raise RuntimeError(f"coo_sort_by_key expects 1D keys, got {k.shape}")
    if values is None:
        from ..tensor import arange
        v = arange(0, k.numel(), dtype=i32, device=k.device)
    else:
        v = _tensor(values, device=k.device)
        if v.device != k.device:
            v = v.to(k.device)
        if v.ndim != 1 or v.numel() != k.numel():
            raise RuntimeError(
                f"coo_sort_by_key values must be 1D with keys numel, got "
                f"{v.shape} vs keys{k.shape}")
    N = k.numel()
    if N == 0:
        from ..tensor import empty
        return (empty((0,), i32, k.device),
                empty((0,), v.dtype, k.device))
    return _be(k.device).coo_sort_by_key(_contig(k), _contig(v))


def cell_list(keys, num_cells: int) -> tuple[Tensor, Tensor]:
    """Uniform-grid cell list from per-element cell ids:
    (row_ptr, perm) with perm[row_ptr[c]:row_ptr[c+1]] the original indices
    of cell c. Composed from coo_sort_by_key + searchsorted (all on GPU)."""
    k = _tensor(keys)
    if k.dtype != i32:
        k = _i32(k)
    if num_cells < 1 or num_cells > 2**31 - 2:
        raise ValueError(f"num_cells must be in [1, 2**31-2], got {num_cells}")
    from ..tensor import arange
    sk, perm = coo_sort_by_key(k)
    bounds = arange(0, num_cells + 1, dtype=i32, device=k.device)
    row_ptr = searchsorted(sk, bounds, side="left")
    return row_ptr, perm
