"""KDA (Kimi Delta Attention) forward CUDA kernels.

Five-kernel pipeline (v1) built around the
``tl.solve_tril`` warp primitive for the chunk UT
inverse (the 10-dot prod-of-squares stays in tests/test_kda.py as the
control):

  K1  kda_wy_kernel     grid (NC, BH), nw=2: consumes the precomputed
                        decay g/gt (cumsum is kda_decay_kernel's in v2);
                        decayed read keys delta/qhat, transposed write
                        keys wc/wt (scalar shift + +-80 clip /
                        tail-shifted), L = strict(delta @ wc) * emc
  K1s kda_solve_kernel  grid (NC, BH), nw=4: M = (I + L)^-1 via
                        tl.solve_tril on the l plane (H=1 dense layout,
                        padded T so every row of Ai is stored)
  K1b kda_mv_kernel     md = M @ delta, mv = M @ v (tl.mma_tile)
  K2  kda_state_kernel  grid (BH*SPLIT,), nw=2: sequential chunk scan,
                        S carried in registers: vt = mv - md @ S;
                        S = exp(gT)(.)S + wt @ vt; stores hc (chunk-start
                        state) and vt for K3
  K3  kda_out_kernel    grid (NC, BH*SPLIT), nw=2:
                        o = qh @ hc + (incl(qh @ wc) * emc) @ vt

The inverse is a standalone launch: tl.solve_tril needs num_warps=4
while the mma accumulator layout needs BN % num_threads == 0 (BN=64 ->
num_warps<=2), so it cannot run inside K1. K1b applies M via the md/mv
planes. FLOPs per (b,h,chunk) fall from ~10.7 MF (prod-of-squares
pipeline) to ~4.9 MF.

Register-pressure note: at num_warps=2 every (64,64) dist value costs 64
regs/thread, so >3 live values + a dot accumulator spills to stack. All
four tl.dot kernels (wy/mv/state/out) are written live-range-ordered:
const planes and operands are loaded as late as possible, results stored
as early as possible, and K1 reloads delta/wc from their planes for the
L dot instead of keeping them live across the write-key computation.

Pad rows (t >= T) are inert by construction: beta/loga/v loads return 0,
so delta/qh/wc/wt pad rows and cols are exactly zero and the ragged last
chunk needs no special casing. All planes fp32.

NOTE: no ``from __future__ import annotations`` here — kernel parameter
annotations (``tl.constexpr``) must stay real objects for the DSL binder.
"""

import numpy as np

import minitriton as tl
from ....frontend import types as tl_types
from ....tensor import empty

C64 = 64  # chunk size (constexpr in every kernel)

# ---------------------------------------------------------------------------
# constant planes: inclusive-lower ones (cumsum) / strict-lower ones (L
# mask) / inclusive-upper ones (transposed cumsum). Broadcast comparisons
# of two offset tensors are not expressible in the DSL, so these are
# built once on the host and loaded per program.
# ---------------------------------------------------------------------------

_CONST = None


def _const_planes():
    global _CONST
    if _CONST is None:
        ones = np.ones((C64, C64), dtype=np.float32)
        pl = np.stack([
            np.tril(ones),            # [0] inclusive lower (cumsum fwd)
            np.tril(ones, -1),        # [1] strict lower (L mask)
            np.triu(ones),            # [2] inclusive upper (cumsum trans)
            np.eye(C64, dtype=np.float32),  # [3] identity (v2 A diag)
        ])
        _CONST = tl.Buffer.from_numpy(np.ascontiguousarray(pl))
    return _CONST


# ---------------------------------------------------------------------------
# K1 — wy kernel: build decayed keys, transposed write keys, and L.
# Live-range ordered (see the register-pressure note above).
# ---------------------------------------------------------------------------

@tl.kernel
def kda_wy_kernel(kn_ptr, qn_ptr, beta_ptr, g_ptr, gt_ptr, c_ptr,
                  emc_ptr, const_ptr, l_ptr, delta_ptr, qh_ptr, wc_ptr,
                  wt_ptr, T, NC,
                  DK: tl.constexpr, C: tl.constexpr):
    pid = tl.program_id(0)
    bh = tl.program_id(1)
    offs = tl.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    base = bh * (T * DK)
    offs2 = offs[:, None] * DK + offs[None, :]          # (C, 64) plane-local
    offs2g = offs_t[:, None] * DK + offs[None, :]       # (C, 64) global rows
    offsC = offs[:, None] * C + offs[None, :]           # (C, C)
    offsG = slab * (C * DK) + offs2                     # g plane (C, DK)
    offsGT = slab * (C * DK) + offs[:, None] + offs[None, :] * DK  # g trans
    beta_r = tl.load(beta_ptr + bh * T + offs_t[None, :],
                     mask=tm[None, :], other=0.0)       # (1, C)
    c = tl.load(c_ptr + slab)                           # scalar shift
    emc = tl.load(emc_ptr + slab)                       # exp(-c)
    # ---- dk half 0: decayed read keys (stored, then dead) ----
    g0 = tl.load(g_ptr + offsG)
    kn0 = tl.load(kn_ptr + base + offs2g, mask=tm[:, None], other=0.0)
    qn0 = tl.load(qn_ptr + base + offs2g, mask=tm[:, None], other=0.0)
    eg0 = tl.exp(g0)
    tl.store(delta_ptr + slab * (C * DK) + offs2, eg0 * kn0)
    tl.store(qh_ptr + slab * (C * DK) + offs2, eg0 * qn0)
    # ---- half 0: transposed write keys (stored, then dead) ----
    gt2_0 = tl.load(g_ptr + offsGT)                     # g transposed (slow)
    gt0 = tl.load(gt_ptr + slab * DK + offs[:, None])   # (64, 1) gT
    knT0 = tl.load(kn_ptr + base + offs[:, None] + offs_t[None, :] * DK,
                   mask=tm[None, :], other=0.0)         # kn trans (slow)
    wtT0 = knT0 * beta_r * tl.exp(gt0 - gt2_0)          # tail-shifted
    tl.store(wt_ptr + slab * (DK * C) + offsC, wtT0)
    e0 = c - gt2_0
    e0 = tl.where(e0 > 80.0, 80.0, e0)
    e0 = tl.where(e0 < -80.0, -80.0, e0)
    wcT0 = knT0 * beta_r * tl.exp(e0)                   # write keys (64, C)
    tl.store(wc_ptr + slab * (DK * C) + offsC, wcT0)
    # ---- L = strict(delta @ wc) * emc (operands reloaded, short-lived) ----
    delta0 = tl.load(delta_ptr + slab * (C * DK) + offs2)
    L = tl.dot(delta0, wcT0)
    if DK == 128:
        # ---- dk half 1 (same order; L carried as the dot accumulator) ----
        g1 = tl.load(g_ptr + C + offsG)
        kn1 = tl.load(kn_ptr + base + C + offs2g, mask=tm[:, None],
                      other=0.0)
        qn1 = tl.load(qn_ptr + base + C + offs2g, mask=tm[:, None],
                      other=0.0)
        eg1 = tl.exp(g1)
        tl.store(delta_ptr + slab * (C * DK) + C + offs2, eg1 * kn1)
        tl.store(qh_ptr + slab * (C * DK) + C + offs2, eg1 * qn1)
        gt2_1 = tl.load(g_ptr + C + offsGT)
        gt1 = tl.load(gt_ptr + slab * DK + C + offs[:, None])
        knT1 = tl.load(kn_ptr + base + C + offs[:, None]
                       + offs_t[None, :] * DK, mask=tm[None, :], other=0.0)
        wtT1 = knT1 * beta_r * tl.exp(gt1 - gt2_1)
        tl.store(wt_ptr + slab * (DK * C) + C * C + offsC, wtT1)
        e1 = c - gt2_1
        e1 = tl.where(e1 > 80.0, 80.0, e1)
        e1 = tl.where(e1 < -80.0, -80.0, e1)
        wcT1 = knT1 * beta_r * tl.exp(e1)
        tl.store(wc_ptr + slab * (DK * C) + C * C + offsC, wcT1)
        delta1 = tl.load(delta_ptr + slab * (C * DK) + C + offs2)
        L = tl.dot(delta1, wcT1, L)
    # mask the strict lower triangle BEFORE the emc scaling so the
    # clipped garbage entries (j <= i) are zeroed while finite
    sl = tl.load(const_ptr + C * C + offsC)
    L = L * sl
    L = L * emc
    tl.store(l_ptr + slab * (C * C) + offsC, L)


# ---------------------------------------------------------------------------
# K1s — chunk UT inverse via the warp-level solve_tril primitive.
# The l plane is laid out as solve_tril's dense [B=BH, T=NC*C, H=1, BT=C]:
# block (bh, pid) starts at (bh*NC + pid) * C*C. T is passed padded so
# t_rem >= C always and every row of Ai is stored (pad rows of L are zero,
# so pad blocks of M come out as the identity — inert downstream).
# ---------------------------------------------------------------------------

@tl.kernel
def kda_solve_kernel(l_ptr, m_ptr, Tpad, H, BT: tl.constexpr):
    pid_t = tl.program_id(0)
    pid_bh = tl.program_id(1)
    tl.solve_tril(l_ptr, m_ptr, pid_t, pid_bh, Tpad, H, BT=BT)


# ---------------------------------------------------------------------------
# K1b — pseudo-value factors: Md = M @ delta and Mv = M @ v, parallel over
# (chunk, b*h). Precomputing them here shortens K2's serial chain to
# vt = Mv - Md @ S (one dot) + the state update (one dot).
# ---------------------------------------------------------------------------

@tl.kernel
def kda_mv_kernel(m_ptr, delta_ptr, v_ptr, md_ptr, mv_ptr, T, NC, SPLIT,
                  DK: tl.constexpr, DV: tl.constexpr, C: tl.constexpr):
    pid = tl.program_id(0)
    p2 = tl.program_id(1)
    bh = p2 // SPLIT
    sp = p2 % SPLIT
    offs = tl.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    offsC = offs[:, None] * C + offs[None, :]
    offs2 = offs[:, None] * DK + offs[None, :]
    offs_v = sp * C + tl.arange(0, C)
    Mm = tl.load(m_ptr + slab * (C * C) + offsC)
    d0 = tl.load(delta_ptr + slab * (C * DK) + offs2)
    md0 = tl.dot(Mm, d0)
    tl.store(md_ptr + slab * (C * DK) + offs2, md0)
    if DK == 128:
        d1 = tl.load(delta_ptr + slab * (C * DK) + C + offs2)
        md1 = tl.dot(Mm, d1)
        tl.store(md_ptr + slab * (C * DK) + C + offs2, md1)
    v = tl.load(v_ptr + bh * (T * DV) + offs_t[:, None] * DV
                + offs_v[None, :], mask=tm[:, None], other=0.0)
    mv = tl.dot(Mm, v)
    tl.store(mv_ptr + slab * (C * DV) + offs[:, None] * DV
             + offs_v[None, :], mv)


# ---------------------------------------------------------------------------
# K2 — state kernel: sequential chunked state recurrence.
# Live-range ordered: at most S + one operand + the dot accumulator are
# live at any point (see the register-pressure note above).
# ---------------------------------------------------------------------------

@tl.kernel
def kda_state_kernel(md_ptr, mv_ptr, wt_ptr, gt_ptr, s0_ptr,
                     hc_ptr, vt_ptr, s1_ptr, T, NC, SPLIT,
                     HAS_S0: tl.constexpr, DK: tl.constexpr,
                     DV: tl.constexpr, C: tl.constexpr):
    pid = tl.program_id(0)
    bh = pid // SPLIT
    sp = pid % SPLIT
    offs = tl.arange(0, C)
    offs_v = sp * C + tl.arange(0, C)                   # dv columns owned
    offsS = offs[:, None] * DV + offs_v[None, :]        # (64, 64) state
    offs2 = offs[:, None] * DK + offs[None, :]          # (C, 64)
    offsC = offs[:, None] * C + offs[None, :]           # (C, C)
    if HAS_S0:
        S0 = tl.load(s0_ptr + bh * (DK * DV) + offsS)
    else:
        S0 = tl.zeros((C, C), tl.float32)
    if DK == 128:
        if HAS_S0:
            S1 = tl.load(s0_ptr + bh * (DK * DV) + C * DV + offsS)
        else:
            S1 = tl.zeros((C, C), tl.float32)
    for cc in range(0, NC):
        slab = bh * NC + cc
        md0 = tl.load(md_ptr + slab * (C * DK) + offs2)
        e0 = tl.dot(md0, S0)                            # Md @ S
        if DK == 128:
            md1 = tl.load(md_ptr + slab * (C * DK) + C + offs2)
            e0 = tl.dot(md1, S1, e0)
        mv = tl.load(mv_ptr + slab * (C * DV) + offs[:, None] * DV
                     + offs_v[None, :])
        vt = mv - e0                                    # pseudo-values
        # chunk-start state + pseudo-values for K3 (both dk halves stored
        # before either is updated)
        tl.store(hc_ptr + slab * (DK * DV) + offsS, S0)
        tl.store(vt_ptr + slab * (C * DV) + offs[:, None] * DV
                 + offs_v[None, :], vt)
        if DK == 128:
            tl.store(hc_ptr + slab * (DK * DV) + C * DV + offsS, S1)
        # state update S = exp(gT)(.)S + wt @ vt (wt stored transposed)
        gt0 = tl.load(gt_ptr + slab * DK + offs[:, None])
        wt0 = tl.load(wt_ptr + slab * (DK * C) + offsC)
        S0 = tl.exp(gt0) * S0 + tl.dot(wt0, vt)
        if DK == 128:
            gt1 = tl.load(gt_ptr + slab * DK + C + offs[:, None])
            wt1 = tl.load(wt_ptr + slab * (DK * C) + C * C + offsC)
            S1 = tl.exp(gt1) * S1 + tl.dot(wt1, vt)
    tl.store(s1_ptr + bh * (DK * DV) + offsS, S0)
    if DK == 128:
        tl.store(s1_ptr + bh * (DK * DV) + C * DV + offsS, S1)


# ---------------------------------------------------------------------------
# K3 — out kernel: outputs from the K1/K2 planes (live-range ordered).
# ---------------------------------------------------------------------------

@tl.kernel
def kda_out_kernel(qh_ptr, wc_ptr, hc_ptr, vt_ptr, emc_ptr, const_ptr,
                   o_ptr, T, NC, SPLIT,
                   DK: tl.constexpr, DV: tl.constexpr, C: tl.constexpr):
    pid = tl.program_id(0)
    p2 = tl.program_id(1)
    bh = p2 // SPLIT
    sp = p2 % SPLIT
    offs = tl.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    offsC = offs[:, None] * C + offs[None, :]
    offs2 = offs[:, None] * DK + offs[None, :]
    offs_v = sp * C + tl.arange(0, C)
    emc = tl.load(emc_ptr + slab)
    qh0 = tl.load(qh_ptr + slab * (C * DK) + offs2)
    wcT0 = tl.load(wc_ptr + slab * (DK * C) + offsC)
    Aq = tl.dot(qh0, wcT0)
    hc0 = tl.load(hc_ptr + slab * (DK * DV) + offs[:, None] * DV
                  + offs_v[None, :])
    o = tl.dot(qh0, hc0)                                # read base
    if DK == 128:
        qh1 = tl.load(qh_ptr + slab * (C * DK) + C + offs2)
        wcT1 = tl.load(wc_ptr + slab * (DK * C) + C * C + offsC)
        Aq = tl.dot(qh1, wcT1, Aq)
        hc1 = tl.load(hc_ptr + slab * (DK * DV) + C * DV
                      + offs[:, None] * DV + offs_v[None, :])
        o = tl.dot(qh1, hc1, o)
    il = tl.load(const_ptr + offsC)                     # tril inclusive
    Aq = Aq * il                                        # within-chunk causal
    Aq = Aq * emc
    vt = tl.load(vt_ptr + slab * (C * DV) + offs[:, None] * DV
                 + offs_v[None, :])
    o = tl.dot(Aq, vt, o)
    tl.store(o_ptr + bh * (T * DV) + offs_t[:, None] * DV
             + offs_v[None, :], o, mask=tm[:, None])


# ---------------------------------------------------------------------------
# fused l2norm row kernel (eager K0 preprocessing): one pass, vs the
# mul/sum/sqrt/div four-launch composition through the generic ops
# ---------------------------------------------------------------------------

@tl.kernel
def kda_l2norm_kernel(x_ptr, o_ptr, C: tl.constexpr):
    row = tl.program_id(0)
    offs = tl.arange(0, C)
    x = tl.load(x_ptr + row * C + offs)
    n = tl.sum(x * x)
    tl.store(o_ptr + row * C + offs, x / tl.sqrt(n))


# ---------------------------------------------------------------------------
# host-side launchers (eager Tensors in/out; tests drive these directly
# for the stage-wise plane comparisons)
# ---------------------------------------------------------------------------

def _contig(t):
    return t if t.is_contiguous() else t.contiguous()


# ---------------------------------------------------------------------------
# v2/v3 fused pipeline. Same math as the
# v1 five-kernel pipeline above (the stage-wise entry points stay for the
# tests), restructured around three bottlenecks:
#
#   * K0 eager preprocessing collapses into two kernels: kda_qknorm (one
#     fused q+k l2norm launch) and kda_decay (log-sigmoid + the per-chunk
#     decay cumsum g + chunk totals gt straight from x_decay — the gt row
#     is a (1,C)@(C,DK) ones-row dot, no transposed load). This drops the
#     loga/loga_p/g eager materializations (~4 full-tensor passes) and ~9
#     launches; the scalar shift c/emc moves into K1 (one 1D min-reduce
#     over gt, stored for K3).
#   * The cross-chunk recurrence contracts to one serial dot per chunk:
#     with Aw = wt^T @ (M@delta) and b = wt^T @ (M@v) (the pseudo-value
#     factorization vt = mv - md @ S, reassociated),
#       S_end = Diag(exp(gT)) (.) S - Aw @ S + b.
#     mv3a computes md/mv and mv3b computes Aw/b — both as matmul_tile
#     calls at nw=8 (two kernels because the tile's cp.async staging
#     cannot see
#     the CTA's own in-kernel stores, and v1 dots cap at nw=2 while tiles
#     peak at nw=8). The diagonal decay is applied elementwise inside the
#     scan (t2 tiles take no epilogue).
#   * kda_scan is that one-dot scan; it does not store vt.
#     kda_out2 recomputes vt = mv - md @ hc in parallel (+1 dot, -1 plane
#     write+read). The vt plane is gone.
#
# Launches: 8 (qknorm, decay, wy2, solve, mv3a, mv3b, scan, out2) vs v1's
# ~16. Pad rows stay inert exactly as in v1: masked x_decay loads return 0
# and the log-sigmoid is re-masked to exact 0 (pad = no decay), masked
# x_beta loads are re-masked to beta=0 (no write), so pad chunks yield
# Aw = 0, b = 0, exp(gT) = 1.
# ---------------------------------------------------------------------------

# log-sigmoid, same stable form as the eager elementwise expr
# (device/cuda/elementwise.py _UNARY["log_sigmoid"]): min(x,0) - log(1+e^{-|x|})


@tl.kernel
def kda_qknorm_kernel(q_ptr, k_ptr, qn_ptr, kn_ptr, C: tl.constexpr):
    """Fused l2norm of one q row and one k row per program (one launch for
    both tensors; same math as kda_l2norm_kernel)."""
    row = tl.program_id(0)
    offs = tl.arange(0, C)
    q = tl.load(q_ptr + row * C + offs)
    k = tl.load(k_ptr + row * C + offs)
    tl.store(qn_ptr + row * C + offs, q / tl.sqrt(tl.sum(q * q)))
    tl.store(kn_ptr + row * C + offs, k / tl.sqrt(tl.sum(k * k)))


@tl.kernel
def kda_decay_kernel(xd_ptr, g_ptr, gt_ptr, const_ptr, T, NC,
                     DK: tl.constexpr, C: tl.constexpr):
    """Per-chunk decay preprocessing: g = inclusive cumsum of log-sigmoid
    (one tril-ones dot) and gt = chunk totals (one (1,C)@(C,DK) ones-row
    dot — no transposed load). Grid (NC, B*H)."""
    pid = tl.program_id(0)
    bh = tl.program_id(1)
    offs = tl.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    base = bh * (T * DK)
    offs2 = offs[:, None] * DK + offs[None, :]
    offs2g = offs_t[:, None] * DK + offs[None, :]
    il = tl.load(const_ptr + offs[:, None] * C + offs[None, :])  # tril incl
    ones = tl.zeros((1, C), tl.float32) + 1.0
    for h in range(0, DK // C):
        xd = tl.load(xd_ptr + base + h * C + offs2g, mask=tm[:, None],
                     other=0.0)
        ax = tl.where(xd < 0, -xd, xd)
        la = tl.where(xd > 0, 0.0, xd) - tl.log(tl.exp(-ax) + 1.0)
        # pad rows: no decay (exact 0; where cannot broadcast (R,1) conds)
        la = la * tl.cast(tm[:, None], tl.float32)
        g = tl.dot(il, la)
        tl.store(g_ptr + slab * (C * DK) + h * C + offs2, g)
        gt = tl.dot(ones, la)                       # (1, DK) chunk totals
        tl.store(gt_ptr + slab * DK + h * C + offs[None, :], gt)


@tl.kernel
def kda_wy2_kernel(kn_ptr, qn_ptr, xb_ptr, g_ptr, gt_ptr, const_ptr,
                   l_ptr, delta_ptr, qh_ptr, wc_ptr, wt_ptr,
                   c_ptr, emc_ptr, T, NC,
                   DK: tl.constexpr, C: tl.constexpr):
    """v2 wy kernel: same body as kda_wy_kernel plus in-kernel beta =
    sigmoid(x_beta) and the scalar shift c/emc derived from gt (one 1D
    min-reduce), which are stored for K3 (v1 loaded them eagerly)."""
    pid = tl.program_id(0)
    bh = tl.program_id(1)
    offs = tl.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    base = bh * (T * DK)
    offs2 = offs[:, None] * DK + offs[None, :]          # (C, 64) plane-local
    offs2g = offs_t[:, None] * DK + offs[None, :]       # (C, 64) global rows
    offsC = offs[:, None] * C + offs[None, :]           # (C, C)
    offsG = slab * (C * DK) + offs2                     # g plane (C, DK)
    offsGT = slab * (C * DK) + offs[:, None] + offs[None, :] * DK  # g trans
    xb_r = tl.load(xb_ptr + bh * T + offs_t[None, :],
                   mask=tm[None, :], other=0.0)         # (1, C)
    beta_r = tl.where(tm, 1.0 / (1.0 + tl.exp(-xb_r)), 0.0)
    # scalar shift c = max(min_d gT[d], -80), emc = exp(-c); stored for K3
    gt1 = tl.load(gt_ptr + slab * DK + tl.arange(0, DK))   # (DK,)
    gm = tl.min(gt1)
    c = tl.where(gm < -80.0, -80.0, gm)
    emc = tl.exp(-c)
    tl.store(c_ptr + slab, c)
    tl.store(emc_ptr + slab, emc)
    # ---- dk half 0: decayed read keys (stored, then dead) ----
    g0 = tl.load(g_ptr + offsG)
    kn0 = tl.load(kn_ptr + base + offs2g, mask=tm[:, None], other=0.0)
    qn0 = tl.load(qn_ptr + base + offs2g, mask=tm[:, None], other=0.0)
    eg0 = tl.exp(g0)
    tl.store(delta_ptr + slab * (C * DK) + offs2, eg0 * kn0)
    tl.store(qh_ptr + slab * (C * DK) + offs2, eg0 * qn0)
    # ---- half 0: transposed write keys (stored, then dead) ----
    gt2_0 = tl.load(g_ptr + offsGT)                     # g transposed (slow)
    gt0 = tl.load(gt_ptr + slab * DK + offs[:, None])   # (64, 1) gT
    knT0 = tl.load(kn_ptr + base + offs[:, None] + offs_t[None, :] * DK,
                   mask=tm[None, :], other=0.0)         # kn trans (slow)
    wtT0 = knT0 * beta_r * tl.exp(gt0 - gt2_0)          # tail-shifted
    tl.store(wt_ptr + slab * (DK * C) + offsC, wtT0)
    e0 = c - gt2_0
    e0 = tl.where(e0 > 80.0, 80.0, e0)
    e0 = tl.where(e0 < -80.0, -80.0, e0)
    wcT0 = knT0 * beta_r * tl.exp(e0)                   # write keys (64, C)
    tl.store(wc_ptr + slab * (DK * C) + offsC, wcT0)
    # ---- L = strict(delta @ wc) * emc (operands reloaded, short-lived) ----
    delta0 = tl.load(delta_ptr + slab * (C * DK) + offs2)
    L = tl.dot(delta0, wcT0)
    if DK == 128:
        # ---- dk half 1 (same order; L carried as the dot accumulator) ----
        g1 = tl.load(g_ptr + C + offsG)
        kn1 = tl.load(kn_ptr + base + C + offs2g, mask=tm[:, None],
                      other=0.0)
        qn1 = tl.load(qn_ptr + base + C + offs2g, mask=tm[:, None],
                      other=0.0)
        eg1 = tl.exp(g1)
        tl.store(delta_ptr + slab * (C * DK) + C + offs2, eg1 * kn1)
        tl.store(qh_ptr + slab * (C * DK) + C + offs2, eg1 * qn1)
        gt2_1 = tl.load(g_ptr + C + offsGT)
        gt1_ = tl.load(gt_ptr + slab * DK + C + offs[:, None])
        knT1 = tl.load(kn_ptr + base + C + offs[:, None]
                       + offs_t[None, :] * DK, mask=tm[None, :], other=0.0)
        wtT1 = knT1 * beta_r * tl.exp(gt1_ - gt2_1)
        tl.store(wt_ptr + slab * (DK * C) + C * C + offsC, wtT1)
        e1 = c - gt2_1
        e1 = tl.where(e1 > 80.0, 80.0, e1)
        e1 = tl.where(e1 < -80.0, -80.0, e1)
        wcT1 = knT1 * beta_r * tl.exp(e1)
        tl.store(wc_ptr + slab * (DK * C) + C * C + offsC, wcT1)
        delta1 = tl.load(delta_ptr + slab * (C * DK) + C + offs2)
        L = tl.dot(delta1, wcT1, L)
    # mask the strict lower triangle BEFORE the emc scaling so the
    # clipped garbage entries (j <= i) are zeroed while finite
    sl = tl.load(const_ptr + C * C + offsC)
    L = L * sl
    L = L * emc
    tl.store(l_ptr + slab * (C * C) + offsC, L)


@tl.kernel
def kda_mv3a_kernel(m_ptr, delta_ptr, v_ptr, md_ptr, mv_ptr, T, NC, SPLIT,
                    DK: tl.constexpr, DV: tl.constexpr, C: tl.constexpr,
                    TM: tl.constexpr, TN: tl.constexpr,
                    EVEN_T: tl.constexpr):
    """v3 pseudo-value factors: md = M @ delta / mv = M @ v as matmul_tile
    calls (nw=8-friendly: the v1 tl.dot's BN % num_threads == 0 layout caps
    these kernels at nw=2, the tile path has no such constraint). Operands
    all come from earlier kernels' planes (no in-kernel RAW — cp.async
    reads bypass the CTA's own stores, measured). mv's K covers the ragged
    last chunk (pad rows zero-filled): EVEN_T=False 4B masked staging with
    K clamped to the single tile unless T % C == 0."""
    pid = tl.program_id(0)
    p2 = tl.program_id(1)
    bh = p2 // SPLIT
    sp = p2 % SPLIT
    offs = tl.arange(0, C)
    offs_t = pid * C + offs
    slab = bh * NC + pid
    offsC = offs[:, None] * C + offs[None, :]
    offs2 = offs[:, None] * DK + offs[None, :]
    offs_v = sp * C + tl.arange(0, C)
    m_pt = m_ptr + slab * (C * C) + offsC
    d_pt = delta_ptr + slab * (C * DK) + offs2
    md = tl.matmul_tile(m_pt, d_pt, C, TM, TN, STAGES=1)
    tl.store(md_ptr + slab * (C * DK) + offs2, md)
    if DK == 128:
        d1_pt = delta_ptr + slab * (C * DK) + C + offs2
        md1 = tl.matmul_tile(m_pt, d1_pt, C, TM, TN, STAGES=1)
        tl.store(md_ptr + slab * (C * DK) + C + offs2, md1)
    v_pt = v_ptr + bh * (T * DV) + offs_t[:, None] * DV + offs_v[None, :]
    mv_pt = mv_ptr + slab * (C * DV) + offs[:, None] * DV + offs_v[None, :]
    if EVEN_T:
        mv = tl.matmul_tile(m_pt, v_pt, C, TM, TN, STAGES=1)
    else:
        # ragged K: zfill the pad rows (k >= T - t0); 4B masked staging.
        # K must be clamped to the single tile: the matmul_tile K loop is
        # ceil(K/BK) tiles, so an unclamped rem would run a second tile.
        rem = T - pid * C
        mv = tl.matmul_tile(m_pt, v_pt, tl.where(rem > C, C, rem),
                            TM, TN, STAGES=1, EVEN_K=False, VEC=False)
    tl.store(mv_pt, mv)


@tl.kernel
def kda_mv3b_kernel(wt_ptr, md_ptr, mv_ptr, ab_ptr, bb_ptr, NC, SPLIT,
                    DK: tl.constexpr, DV: tl.constexpr, C: tl.constexpr,
                    TM: tl.constexpr, TN: tl.constexpr):
    """v3 affine chunk maps for the one-dot scan, as matmul_tile calls:
      Aw = wt @ md   (DK, DK), stored RAW (no diagonal)
      b  = wt @ mv   (DK, DV)
    so S_end = Diag(exp(gT)) (.) S - Aw @ S + b — the diagonal decay is
    applied elementwise inside the scan kernel (t2 tiles take no
    elementwise epilogue). All operands come from earlier kernels' planes
    (wt from wy2, md/mv from mv3a)."""
    pid = tl.program_id(0)
    p2 = tl.program_id(1)
    bh = p2 // SPLIT
    sp = p2 % SPLIT
    offs = tl.arange(0, C)
    slab = bh * NC + pid
    offsC = offs[:, None] * C + offs[None, :]
    offsQ = offs[:, None] * DK + offs[None, :]          # (DK, DK) blocks
    offs2 = offs[:, None] * DK + offs[None, :]
    offs_v = sp * C + tl.arange(0, C)
    offsS = offs[:, None] * DV + offs_v[None, :]        # (DK, 64) dv slice
    wt0_pt = wt_ptr + slab * (DK * C) + offsC           # (DK, C)
    md0_pt = md_ptr + slab * (C * DK) + offs2           # (C, DK)
    aw = tl.matmul_tile(wt0_pt, md0_pt, C, TM, TN, STAGES=1)
    tl.store(ab_ptr + slab * (DK * DK) + offsQ, aw)
    mv_pt = mv_ptr + slab * (C * DV) + offsS
    b0 = tl.matmul_tile(wt0_pt, mv_pt, C, TM, TN, STAGES=1)
    tl.store(bb_ptr + slab * (DK * DV) + offsS, b0)
    if DK == 128:
        # (128,128) row-major quadrant bases: Aw[r,c] at r*C*DK + c*C
        md1_pt = md_ptr + slab * (C * DK) + C + offs2
        wt1_pt = wt_ptr + slab * (DK * C) + C * C + offsC
        aw01 = tl.matmul_tile(wt0_pt, md1_pt, C, TM, TN, STAGES=1)
        tl.store(ab_ptr + slab * (DK * DK) + C + offsQ, aw01)
        aw10 = tl.matmul_tile(wt1_pt, md0_pt, C, TM, TN, STAGES=1)
        tl.store(ab_ptr + slab * (DK * DK) + C * DK + offsQ, aw10)
        aw11 = tl.matmul_tile(wt1_pt, md1_pt, C, TM, TN, STAGES=1)
        tl.store(ab_ptr + slab * (DK * DK) + C * DK + C + offsQ, aw11)
        b1 = tl.matmul_tile(wt1_pt, mv_pt, C, TM, TN, STAGES=1)
        tl.store(bb_ptr + slab * (DK * DV) + C * DV + offsS, b1)


@tl.kernel
def kda_scan_kernel(ab_ptr, bb_ptr, gt_ptr, s0_ptr, hc_ptr, s1_ptr,
                    T, NC, SPLIT,
                    HAS_S0: tl.constexpr, DK: tl.constexpr,
                    DV: tl.constexpr, C: tl.constexpr,
                    DVT: tl.constexpr):
    """v3 state scan: ONE serial dot per chunk,
      S = Diag(exp(gT)) (.) S - Aw @ S + b,
    with hc = chunk-start state stored for K3 (vt is recomputed there, not
    stored). Grid (B*H*SPLIT,) with dv tiles of DVT columns (DVT=64 at
    nw=2; DVT=32 at nw=1 for extra programs on small B*H — the per-thread
    dot work is invariant, so DVT only changes the program count)."""
    pid = tl.program_id(0)
    bh = pid // SPLIT
    sp = pid % SPLIT
    offs = tl.arange(0, C)
    offs_v = sp * DVT + tl.arange(0, DVT)               # dv columns owned
    offsS = offs[:, None] * DV + offs_v[None, :]        # (DK, DVT) state
    offsQ = offs[:, None] * DK + offs[None, :]          # (DK, DK) blocks
    if HAS_S0:
        S0 = tl.load(s0_ptr + bh * (DK * DV) + offsS)
    else:
        S0 = tl.zeros((C, DVT), tl.float32)
    if DK == 128:
        if HAS_S0:
            S1 = tl.load(s0_ptr + bh * (DK * DV) + C * DV + offsS)
        else:
            S1 = tl.zeros((C, DVT), tl.float32)
    for cc in range(0, NC):
        slab = bh * NC + cc
        tl.store(hc_ptr + slab * (DK * DV) + offsS, S0)
        A00 = tl.load(ab_ptr + slab * (DK * DK) + offsQ)
        n0 = tl.dot(A00, S0)
        if DK == 128:
            tl.store(hc_ptr + slab * (DK * DV) + C * DV + offsS, S1)
            A01 = tl.load(ab_ptr + slab * (DK * DK) + C + offsQ)
            n0 = tl.dot(A01, S1, n0)
        gt0 = tl.load(gt_ptr + slab * DK + offs[:, None])
        b0 = tl.load(bb_ptr + slab * (DK * DV) + offsS)
        n0 = tl.exp(gt0) * S0 - n0 + b0
        if DK == 128:
            A10 = tl.load(ab_ptr + slab * (DK * DK) + C * DK + offsQ)
            n1 = tl.dot(A10, S0)
            A11 = tl.load(ab_ptr + slab * (DK * DK) + C * DK + C + offsQ)
            n1 = tl.dot(A11, S1, n1)
            gt1 = tl.load(gt_ptr + slab * DK + C + offs[:, None])
            b1 = tl.load(bb_ptr + slab * (DK * DV) + C * DV + offsS)
            n1 = tl.exp(gt1) * S1 - n1 + b1
            S1 = n1
        S0 = n0
    tl.store(s1_ptr + bh * (DK * DV) + offsS, S0)
    if DK == 128:
        tl.store(s1_ptr + bh * (DK * DV) + C * DV + offsS, S1)


# ---------------------------------------------------------------------------
# segmented scan (dk=64, long NC): the one-dot scan's serial chain is
# 2*L + NS + L ~ 3*sqrt(2*NC) dots instead of NC. Three phases:
#   S1 kda_seg_compose_kernel  grid (NS, BH*SPLIT): per-segment affine map
#                        (As, bs) = composition of the chunk maps over the
#                        segment (two independent one-dot loops: As product
#                        first, then the zero-init state bs)
#   S2 kda_seg_scan_kernel     grid (BH*SPLIT,): serial scan over the NS
#                        composed maps (one dot per segment), storing the
#                        segment-start states ss and the final state s1
#   S3 kda_seg_emit_kernel     grid (NS, BH*SPLIT): re-scan inside the
#                        segment from ss, storing hc per chunk
# The math is the same affine-map recurrence (exact reassociation of
# linear maps); dk=128 keeps the one-level scan (quadrant composition
# would be 8 dots/chunk).
# ---------------------------------------------------------------------------

@tl.kernel
def kda_seg_compose_kernel(ab_ptr, bb_ptr, gt_ptr, const_ptr, as_ptr,
                           bs_ptr, NC, NS, L, SPLIT,
                           DK: tl.constexpr, DV: tl.constexpr,
                           C: tl.constexpr):
    sg = tl.program_id(0)
    p2 = tl.program_id(1)
    bh = p2 // SPLIT
    sp = p2 % SPLIT
    offs = tl.arange(0, C)
    offs_v = sp * C + tl.arange(0, C)
    offsS = offs[:, None] * DV + offs_v[None, :]
    offsQ = offs[:, None] * DK + offs[None, :]
    offsC = offs[:, None] * C + offs[None, :]
    lo = sg * L
    hi = tl.where(lo + L > NC, NC, lo + L)
    # loop 1: As = product of the full chunk maps (Diag(gt) - Aw)
    Ac = tl.load(const_ptr + 3 * C * C + offsC)         # identity
    for cc in range(lo, hi):
        slab = bh * NC + cc
        Aw = tl.load(ab_ptr + slab * (DK * DK) + offsQ)
        gtc = tl.load(gt_ptr + slab * DK + offs[:, None])
        Ac = tl.exp(gtc) * Ac - tl.dot(Aw, Ac)
    tl.store(as_ptr + (bh * NS + sg) * (DK * DK) + offsQ, Ac)
    # loop 2: bs = the segment's zero-init state (same one-dot scan body)
    S0 = tl.zeros((C, C), tl.float32)
    for cc in range(lo, hi):
        slab = bh * NC + cc
        Aw = tl.load(ab_ptr + slab * (DK * DK) + offsQ)
        b0 = tl.load(bb_ptr + slab * (DK * DV) + offsS)
        gtc = tl.load(gt_ptr + slab * DK + offs[:, None])
        S0 = tl.exp(gtc) * S0 - tl.dot(Aw, S0) + b0
    tl.store(bs_ptr + (bh * NS + sg) * (DK * DV) + offsS, S0)


@tl.kernel
def kda_seg_scan_kernel(as_ptr, bs_ptr, s0_ptr, ss_ptr, s1_ptr,
                        NS, SPLIT, HAS_S0: tl.constexpr,
                        DK: tl.constexpr, DV: tl.constexpr,
                        C: tl.constexpr):
    pid = tl.program_id(0)
    bh = pid // SPLIT
    sp = pid % SPLIT
    offs = tl.arange(0, C)
    offs_v = sp * C + tl.arange(0, C)
    offsS = offs[:, None] * DV + offs_v[None, :]
    offsQ = offs[:, None] * DK + offs[None, :]
    if HAS_S0:
        S0 = tl.load(s0_ptr + bh * (DK * DV) + offsS)
    else:
        S0 = tl.zeros((C, C), tl.float32)
    for sg in range(0, NS):
        tl.store(ss_ptr + (bh * NS + sg) * (DK * DV) + offsS, S0)
        A = tl.load(as_ptr + (bh * NS + sg) * (DK * DK) + offsQ)
        b = tl.load(bs_ptr + (bh * NS + sg) * (DK * DV) + offsS)
        S0 = tl.dot(A, S0) + b
    tl.store(s1_ptr + bh * (DK * DV) + offsS, S0)


@tl.kernel
def kda_seg_emit_kernel(ab_ptr, bb_ptr, gt_ptr, ss_ptr, hc_ptr,
                        NC, NS, L, SPLIT,
                        DK: tl.constexpr, DV: tl.constexpr,
                        C: tl.constexpr):
    sg = tl.program_id(0)
    p2 = tl.program_id(1)
    bh = p2 // SPLIT
    sp = p2 % SPLIT
    offs = tl.arange(0, C)
    offs_v = sp * C + tl.arange(0, C)
    offsS = offs[:, None] * DV + offs_v[None, :]
    offsQ = offs[:, None] * DK + offs[None, :]
    lo = sg * L
    hi = tl.where(lo + L > NC, NC, lo + L)
    S0 = tl.load(ss_ptr + (bh * NS + sg) * (DK * DV) + offsS)
    for cc in range(lo, hi):
        slab = bh * NC + cc
        tl.store(hc_ptr + slab * (DK * DV) + offsS, S0)
        Aw = tl.load(ab_ptr + slab * (DK * DK) + offsQ)
        b0 = tl.load(bb_ptr + slab * (DK * DV) + offsS)
        gtc = tl.load(gt_ptr + slab * DK + offs[:, None])
        S0 = tl.exp(gtc) * S0 - tl.dot(Aw, S0) + b0


@tl.kernel
def kda_out2_kernel(qh_ptr, wc_ptr, md_ptr, mv_ptr, hc_ptr, emc_ptr,
                    const_ptr, o_ptr, T, NC, SPLIT,
                    DK: tl.constexpr, DV: tl.constexpr, C: tl.constexpr):
    """v2 out kernel: as kda_out_kernel but vt is recomputed
    (vt = mv - md @ hc, +1 dot) instead of read from the vt plane."""
    pid = tl.program_id(0)
    p2 = tl.program_id(1)
    bh = p2 // SPLIT
    sp = p2 % SPLIT
    offs = tl.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    offsC = offs[:, None] * C + offs[None, :]
    offs2 = offs[:, None] * DK + offs[None, :]
    offs_v = sp * C + tl.arange(0, C)
    offsS = offs[:, None] * DV + offs_v[None, :]        # (DK, 64)
    offsMV = offs[:, None] * DV + offs_v[None, :]       # (C, 64)
    emc = tl.load(emc_ptr + slab)
    qh0 = tl.load(qh_ptr + slab * (C * DK) + offs2)
    hc0 = tl.load(hc_ptr + slab * (DK * DV) + offsS)
    o = tl.dot(qh0, hc0)                                # read base
    md0 = tl.load(md_ptr + slab * (C * DK) + offs2)
    e0 = tl.dot(md0, hc0)
    if DK == 128:
        qh1 = tl.load(qh_ptr + slab * (C * DK) + C + offs2)
        hc1 = tl.load(hc_ptr + slab * (DK * DV) + C * DV + offsS)
        o = tl.dot(qh1, hc1, o)
        md1 = tl.load(md_ptr + slab * (C * DK) + C + offs2)
        e0 = tl.dot(md1, hc1, e0)
    mv = tl.load(mv_ptr + slab * (C * DV) + offsMV)
    vt = mv - e0                                        # pseudo-values
    wcT0 = tl.load(wc_ptr + slab * (DK * C) + offsC)
    Aq = tl.dot(qh0, wcT0)
    if DK == 128:
        wcT1 = tl.load(wc_ptr + slab * (DK * C) + C * C + offsC)
        qh1r = tl.load(qh_ptr + slab * (C * DK) + C + offs2)
        Aq = tl.dot(qh1r, wcT1, Aq)
    il = tl.load(const_ptr + offsC)                     # tril inclusive
    Aq = Aq * il                                        # within-chunk causal
    Aq = Aq * emc
    o = tl.dot(Aq, vt, o)
    tl.store(o_ptr + bh * (T * DV) + offs_t[:, None] * DV
             + offs_v[None, :], o, mask=tm[:, None])


def launch_kda_l2norm(x, out, R: int, C: int):
    """out[r] = x[r] / ||x[r]||_2 for R rows of length C (contiguous)."""
    kda_l2norm_kernel[(R,)](x._buffer_arg(), out._buffer_arg(), C=C,
                            num_warps=2)


def alloc_wy_planes(BH: int, NC: int, dk: int):
    f = tl_types.float32
    return {
        "l": empty((BH * NC, C64, C64), f, "cuda"),
        "m": empty((BH * NC, C64, C64), f, "cuda"),
        "delta": empty((BH * NC, C64, dk), f, "cuda"),
        "qh": empty((BH * NC, C64, dk), f, "cuda"),
        "wc": empty((BH * NC, dk, C64), f, "cuda"),
        "wt": empty((BH * NC, dk, C64), f, "cuda"),
    }


def alloc_mv_planes(BH: int, NC: int, dk: int, dv: int):
    f = tl_types.float32
    return {
        "md": empty((BH * NC, C64, dk), f, "cuda"),
        "mv": empty((BH * NC, C64, dv), f, "cuda"),
    }


def launch_kda_wy(kn, qn, beta, g, gt, c, emc, planes,
                  BH: int, T: int, NC: int, dk: int, num_warps: int = 2):
    kda_wy_kernel[(NC, BH)](
        kn._buffer_arg(), qn._buffer_arg(), beta._buffer_arg(),
        g._buffer_arg(), gt._buffer_arg(), c._buffer_arg(),
        emc._buffer_arg(), _const_planes(),
        planes["l"]._buffer_arg(), planes["delta"]._buffer_arg(),
        planes["qh"]._buffer_arg(), planes["wc"]._buffer_arg(),
        planes["wt"]._buffer_arg(), T, NC, DK=dk, C=C64,
        num_warps=num_warps)


def launch_kda_solve(planes, BH: int, NC: int):
    kda_solve_kernel[(NC, BH)](
        planes["l"]._buffer_arg(), planes["m"]._buffer_arg(),
        NC * C64, 1, BT=C64, num_warps=4)


def launch_kda_mv(planes, mv_planes, v, BH: int, T: int, NC: int,
                  dk: int, dv: int, num_warps: int = 2):
    split = dv // C64
    kda_mv_kernel[(NC, BH * split)](
        planes["m"]._buffer_arg(), planes["delta"]._buffer_arg(),
        v._buffer_arg(), mv_planes["md"]._buffer_arg(),
        mv_planes["mv"]._buffer_arg(), T, NC, split,
        DK=dk, DV=dv, C=C64, num_warps=num_warps)


def launch_kda_state(mv_planes, wt, gt, s0, hc, vt, s1,
                     BH: int, T: int, NC: int, dk: int, dv: int,
                     num_warps: int = 2):
    split = dv // C64
    kda_state_kernel[(BH * split,)](
        mv_planes["md"]._buffer_arg(), mv_planes["mv"]._buffer_arg(),
        wt._buffer_arg(), gt._buffer_arg(),
        (s0 if s0 is not None else mv_planes["md"])._buffer_arg(),
        hc._buffer_arg(), vt._buffer_arg(), s1._buffer_arg(),
        T, NC, split, HAS_S0=s0 is not None, DK=dk, DV=dv, C=C64,
        num_warps=num_warps)


def launch_kda_out(planes, hc, vt, emc, o,
                   BH: int, T: int, NC: int, dk: int, dv: int,
                   num_warps: int = 2):
    split = dv // C64
    kda_out_kernel[(NC, BH * split)](
        planes["qh"]._buffer_arg(), planes["wc"]._buffer_arg(),
        hc._buffer_arg(), vt._buffer_arg(), emc._buffer_arg(),
        _const_planes(), o._buffer_arg(),
        T, NC, split, DK=dk, DV=dv, C=C64, num_warps=num_warps)


def kda_forward(kn, qn, v, beta, g, gt, c, emc, s0,
                output_final_state: bool = False):
    """Full KDA forward on preprocessed inputs (ops/kda.py contract)."""
    B, H, T, dk = kn.shape
    dv = v.shape[-1]
    BH = B * H
    NC = (T + C64 - 1) // C64
    kn, qn, v = _contig(kn), _contig(qn), _contig(v)
    beta, g = _contig(beta), _contig(g)
    gt, c, emc = _contig(gt), _contig(c), _contig(emc)
    s0 = _contig(s0) if s0 is not None else None
    f = tl_types.float32
    planes = alloc_wy_planes(BH, NC, dk)
    mv_planes = alloc_mv_planes(BH, NC, dk, dv)
    hc = empty((BH * NC, dk, dv), f, "cuda")
    vt = empty((BH * NC, C64, dv), f, "cuda")
    s1 = empty((BH, dk, dv), f, "cuda")
    o = empty((B, H, T, dv), f, "cuda")
    launch_kda_wy(kn, qn, beta, g, gt, c, emc, planes, BH, T, NC, dk)
    launch_kda_solve(planes, BH, NC)
    launch_kda_mv(planes, mv_planes, v, BH, T, NC, dk, dv)
    launch_kda_state(mv_planes, planes["wt"], gt, s0, hc, vt, s1,
                     BH, T, NC, dk, dv)
    launch_kda_out(planes, hc, vt, emc, o, BH, T, NC, dk, dv)
    return (o, s1.reshape((B, H, dk, dv))) if output_final_state else o


# ---------------------------------------------------------------------------
# v2 host-side launchers
# ---------------------------------------------------------------------------

def alloc_scan_planes(BH: int, NC: int, dk: int, dv: int):
    """The affine chunk maps for the one-dot scan: ab (DK, DK), bb (DK, DV)
    per (b*h, chunk)."""
    f = tl_types.float32
    return {
        "ab": empty((BH * NC, dk, dk), f, "cuda"),
        "bb": empty((BH * NC, dk, dv), f, "cuda"),
    }


def launch_kda_qknorm(q, k, qn, kn, R: int, C: int):
    kda_qknorm_kernel[(R,)](q._buffer_arg(), k._buffer_arg(),
                            qn._buffer_arg(), kn._buffer_arg(), C=C,
                            num_warps=2)


def launch_kda_decay(xd, g, gt, BH: int, T: int, NC: int, dk: int,
                     num_warps: int = 2):
    kda_decay_kernel[(NC, BH)](
        xd._buffer_arg(), g._buffer_arg(), gt._buffer_arg(),
        _const_planes(), T, NC, DK=dk, C=C64, num_warps=num_warps)


def launch_kda_wy2(kn, qn, xb, g, gt, planes, c, emc,
                   BH: int, T: int, NC: int, dk: int, num_warps: int = 2):
    kda_wy2_kernel[(NC, BH)](
        kn._buffer_arg(), qn._buffer_arg(), xb._buffer_arg(),
        g._buffer_arg(), gt._buffer_arg(), _const_planes(),
        planes["l"]._buffer_arg(), planes["delta"]._buffer_arg(),
        planes["qh"]._buffer_arg(), planes["wc"]._buffer_arg(),
        planes["wt"]._buffer_arg(), c._buffer_arg(), emc._buffer_arg(),
        T, NC, DK=dk, C=C64, num_warps=num_warps)


def launch_kda_mv3a(planes, mv_planes, v,
                    BH: int, T: int, NC: int, dk: int, dv: int,
                    num_warps: int = 8, tm: int = 4, tn: int = 4):
    split = dv // C64
    kda_mv3a_kernel[(NC, BH * split)](
        planes["m"]._buffer_arg(), planes["delta"]._buffer_arg(),
        v._buffer_arg(), mv_planes["md"]._buffer_arg(),
        mv_planes["mv"]._buffer_arg(), T, NC, split,
        DK=dk, DV=dv, C=C64, TM=tm, TN=tn, EVEN_T=T % C64 == 0,
        num_warps=num_warps)


def launch_kda_mv3b(planes, mv_planes, scan_planes,
                    BH: int, NC: int, dk: int, dv: int,
                    num_warps: int = 8, tm: int = 4, tn: int = 4):
    split = dv // C64
    kda_mv3b_kernel[(NC, BH * split)](
        planes["wt"]._buffer_arg(), mv_planes["md"]._buffer_arg(),
        mv_planes["mv"]._buffer_arg(), scan_planes["ab"]._buffer_arg(),
        scan_planes["bb"]._buffer_arg(), NC, split,
        DK=dk, DV=dv, C=C64, TM=tm, TN=tn, num_warps=num_warps)


def launch_kda_scan(scan_planes, gt, s0, hc, s1,
                    BH: int, T: int, NC: int, dk: int, dv: int,
                    dvt: int = C64, num_warps: int | None = None,
                    seg_min_nc: int = 32):
    split = dv // dvt
    if num_warps is None:
        # BN=DVT must be a multiple of num_threads (v1 dot layout): 64->2
        # warps, 32->1 warp
        num_warps = 2 if dvt >= 64 else 1
    if dk == C64 and NC >= seg_min_nc and (BH <= 16
                                           or (BH <= 32 and NC >= 64)):
        # segmented scan (dk=64, latency-bound grids only): 2*L + NS + L
        # serial dots instead of NC — ~3x shorter chain at NC=128. It
        # does ~3x the dot WORK (compose+emit+scan), so it is dispatched
        # only where the one-level scan's B*H grid underfills the SMs;
        # throughput-bound shapes (B*H >= 64, or 32 at NC < 64)
        # keep the one-level scan.
        L = 4 if NC < 64 else 8
        NS = (NC + L - 1) // L
        f = tl_types.float32
        aseg = empty((BH * NS, dk, dk), f, "cuda")
        bseg = empty((BH * NS, dk, dv), f, "cuda")
        ss = empty((BH * NS, dk, dv), f, "cuda")
        split_dv = dv // C64
        kda_seg_compose_kernel[(NS, BH * split_dv)](
            scan_planes["ab"]._buffer_arg(),
            scan_planes["bb"]._buffer_arg(), gt._buffer_arg(),
            _const_planes(), aseg._buffer_arg(), bseg._buffer_arg(),
            NC, NS, L, split_dv, DK=dk, DV=dv, C=C64, num_warps=2)
        kda_seg_scan_kernel[(BH * split_dv,)](
            aseg._buffer_arg(), bseg._buffer_arg(),
            (s0 if s0 is not None else aseg)._buffer_arg(),
            ss._buffer_arg(), s1._buffer_arg(), NS, split_dv,
            HAS_S0=s0 is not None, DK=dk, DV=dv, C=C64, num_warps=2)
        kda_seg_emit_kernel[(NS, BH * split_dv)](
            scan_planes["ab"]._buffer_arg(),
            scan_planes["bb"]._buffer_arg(), gt._buffer_arg(),
            ss._buffer_arg(), hc._buffer_arg(), NC, NS, L, split_dv,
            DK=dk, DV=dv, C=C64, num_warps=2)
        return
    kda_scan_kernel[(BH * split,)](
        scan_planes["ab"]._buffer_arg(), scan_planes["bb"]._buffer_arg(),
        gt._buffer_arg(),
        (s0 if s0 is not None else scan_planes["ab"])._buffer_arg(),
        hc._buffer_arg(), s1._buffer_arg(),
        T, NC, split, HAS_S0=s0 is not None, DK=dk, DV=dv, C=C64, DVT=dvt,
        num_warps=num_warps)


def launch_kda_out2(planes, mv_planes, hc, emc, o,
                    BH: int, T: int, NC: int, dk: int, dv: int,
                    num_warps: int = 2):
    split = dv // C64
    kda_out2_kernel[(NC, BH * split)](
        planes["qh"]._buffer_arg(), planes["wc"]._buffer_arg(),
        mv_planes["md"]._buffer_arg(), mv_planes["mv"]._buffer_arg(),
        hc._buffer_arg(), emc._buffer_arg(), _const_planes(),
        o._buffer_arg(), T, NC, split, DK=dk, DV=dv, C=C64,
        num_warps=num_warps)


def kda_forward_fused(q, k, v, x_beta, x_decay, s0,
                      output_final_state: bool = False):
    """v2 fused KDA forward on RAW inputs (q, k, v, x_beta, x_decay — the
    ops/kda.py public contract before eager preprocessing). Numerically
    equivalent to the v1 pipeline (same kernel-form numerics; the state
    recurrence is reassociated into the affine-map scan)."""
    B, H, T, dk = k.shape
    dv = v.shape[-1]
    BH = B * H
    NC = (T + C64 - 1) // C64
    q, k, v = _contig(q), _contig(k), _contig(v)
    x_beta, x_decay = _contig(x_beta), _contig(x_decay)
    s0 = _contig(s0) if s0 is not None else None
    f = tl_types.float32
    kn = empty((B, H, T, dk), f, "cuda")
    qn = empty((B, H, T, dk), f, "cuda")
    g = empty((BH * NC, C64, dk), f, "cuda")
    gt = empty((BH * NC, dk), f, "cuda")
    c = empty((BH * NC,), f, "cuda")
    emc = empty((BH * NC,), f, "cuda")
    planes = alloc_wy_planes(BH, NC, dk)
    mv_planes = alloc_mv_planes(BH, NC, dk, dv)
    scan_planes = alloc_scan_planes(BH, NC, dk, dv)
    hc = empty((BH * NC, dk, dv), f, "cuda")
    s1 = empty((BH, dk, dv), f, "cuda")
    o = empty((B, H, T, dv), f, "cuda")
    launch_kda_qknorm(q, k, qn, kn, B * H * T, dk)
    launch_kda_decay(x_decay, g, gt, BH, T, NC, dk)
    launch_kda_wy2(kn, qn, x_beta, g, gt, planes, c, emc, BH, T, NC, dk)
    launch_kda_solve(planes, BH, NC)
    launch_kda_mv3a(planes, mv_planes, v, BH, T, NC, dk, dv)
    if BH >= 128:
        # throughput regime (BH >= 128 shapes): the affine-map
        # machinery (Aw/b planes, vt recompute)
        # is parallel work the grid does not need — the v1 two-dot scan +
        # vt plane + three-dot out is leaner here. md/mv still come from
        # the tiled mv3a.
        vt = empty((BH * NC, C64, dv), f, "cuda")
        launch_kda_state(mv_planes, planes["wt"], gt, s0, hc, vt, s1,
                         BH, T, NC, dk, dv)
        launch_kda_out(planes, hc, vt, emc, o, BH, T, NC, dk, dv)
        return (o, s1.reshape((B, H, dk, dv))) if output_final_state else o
    launch_kda_mv3b(planes, mv_planes, scan_planes, BH, NC, dk, dv)
    launch_kda_scan(scan_planes, gt, s0, hc, s1, BH, T, NC, dk, dv)
    launch_kda_out2(planes, mv_planes, hc, emc, o, BH, T, NC, dk, dv)
    return (o, s1.reshape((B, H, dk, dv))) if output_final_state else o

__all__ = [
    "C64",
    "_CONST",
    "_const_planes",
    "kda_wy_kernel",
    "kda_solve_kernel",
    "kda_mv_kernel",
    "kda_state_kernel",
    "kda_out_kernel",
    "kda_l2norm_kernel",
    "_contig",
    "kda_qknorm_kernel",
    "kda_decay_kernel",
    "kda_wy2_kernel",
    "kda_mv3a_kernel",
    "kda_mv3b_kernel",
    "kda_scan_kernel",
    "kda_seg_compose_kernel",
    "kda_seg_scan_kernel",
    "kda_seg_emit_kernel",
    "kda_out2_kernel",
    "launch_kda_l2norm",
    "alloc_wy_planes",
    "alloc_mv_planes",
    "launch_kda_wy",
    "launch_kda_solve",
    "launch_kda_mv",
    "launch_kda_state",
    "launch_kda_out",
    "kda_forward",
    "alloc_scan_planes",
    "launch_kda_qknorm",
    "launch_kda_decay",
    "launch_kda_wy2",
    "launch_kda_mv3a",
    "launch_kda_mv3b",
    "launch_kda_scan",
    "launch_kda_out2",
    "kda_forward_fused",
]
