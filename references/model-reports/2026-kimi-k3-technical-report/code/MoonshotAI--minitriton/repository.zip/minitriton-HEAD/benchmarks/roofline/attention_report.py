#!/usr/bin/env python
"""Attention benchmark: minitriton fused flash-attention forward
vs triton fp32 flash attention (input_precision="ieee") vs torch eager
unfused attention. Same do_bench (CUDA events + L2 flush) everywhere.

Gates (calibrated on L20): fwd geomean >= 0.75x Triton
same-semantics timing; bwd >= 0.9x on every T >= 1024 shape.

    CUDA_VISIBLE_DEVICES=1 python benchmarks/roofline/attention_report.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np

import minitriton as tl
from minitriton import do_bench, ops as tl_ops

import torch
import triton
import triton.language as tll

from accounting import flash_attn_fwd_flops

torch.backends.cuda.matmul.allow_tf32 = False

# gate thresholds calibrated on L20 (sm_89): fwd geomean measures ~0.79
# (small shapes drag it down), bwd T>=1024 shapes measure >= 0.96
_FWD_GEOMEAN_GATE = 0.75
_BWD_BIG_T_GATE = 0.90


# ---------------------------------------------------------------------------
# triton fp32 flash attention forward (causal), tutorial-style
# ---------------------------------------------------------------------------

@triton.jit
def _tri_flash_fwd(Q, K, V, O, T, scale,
                   HD: tll.constexpr, BM: tll.constexpr, BN: tll.constexpr):
    pid_m = tll.program_id(0)
    bh = tll.program_id(1)
    q0 = pid_m * BM
    offs_m = q0 + tll.arange(0, BM)
    offs_n = tll.arange(0, BN)
    offs_d = tll.arange(0, HD)
    q = tll.load(Q + bh * T * HD + offs_m[:, None] * HD + offs_d[None, :],
                 mask=offs_m[:, None] < T, other=0.0)
    m_i = tll.full((BM,), -float("inf"), tll.float32)
    l_i = tll.zeros((BM,), tll.float32)
    acc = tll.zeros((BM, HD), tll.float32)
    for k0 in range(0, q0 + BM, BN):
        kmask = (k0 + offs_n)[:, None] < T
        k = tll.load(K + bh * T * HD + (k0 + offs_n)[:, None] * HD
                     + offs_d[None, :], mask=kmask, other=0.0)
        s = tll.dot(q, tll.trans(k), input_precision="ieee") * scale
        s = tll.where(offs_m[:, None] >= (k0 + offs_n)[None, :], s, -1e9)
        m_new = tll.maximum(m_i, tll.max(s, 1))
        p = tll.exp(s - m_new[:, None])
        alpha = tll.exp(m_i - m_new)
        l_i = l_i * alpha + tll.sum(p, 1)
        acc = acc * alpha[:, None]
        v = tll.load(V + bh * T * HD + (k0 + offs_n)[:, None] * HD
                     + offs_d[None, :], mask=kmask, other=0.0)
        acc = tll.dot(p, v, acc, input_precision="ieee")
        m_i = m_new
    o = acc / l_i[:, None]
    tll.store(O + bh * T * HD + offs_m[:, None] * HD + offs_d[None, :], o,
              mask=offs_m[:, None] < T)


_TRI_CONFIGS = [
    (64, 64, 4, 2), (64, 64, 4, 3), (128, 64, 4, 3), (128, 64, 8, 2),
    (64, 32, 4, 2), (32, 64, 4, 2),
]


def tri_flash(q, k, v, scale, cfg):
    B, H, T, HD = q.shape
    BM, BN, warps, stages = cfg
    o = torch.empty_like(q)
    grid = (triton.cdiv(T, BM), B * H)
    _tri_flash_fwd[grid](q, k, v, o, T, scale, HD=HD, BM=BM, BN=BN,
                         num_warps=warps, num_stages=stages)
    return o


def tri_best(q, k, v, scale):
    """Mini autotune over the config space; returns (best_fn, ms, cfg)."""
    best = None
    for cfg in _TRI_CONFIGS:
        try:
            fn = lambda: tri_flash(q, k, v, scale, cfg)
            fn()
            torch.cuda.synchronize()
            ms = do_bench(fn)
        except Exception:
            continue
        if best is None or ms < best[1]:
            best = (cfg, ms)
    cfg, ms = best
    return (lambda: tri_flash(q, k, v, scale, cfg)), ms, cfg


# ---------------------------------------------------------------------------
# triton fp32 flash attention backward (causal), tutorial-style 3-kernel
# (preprocess delta + dkv over kv blocks + dq over q blocks), ieee dots
# ---------------------------------------------------------------------------

@triton.jit
def _tri_bwd_preprocess(O, DO, Delta, T, HD: tll.constexpr,
                        BLOCK: tll.constexpr):
    row = tll.program_id(0)
    offs = tll.arange(0, BLOCK)
    m = offs < HD
    o = tll.load(O + row * HD + offs, mask=m, other=0.0)
    do = tll.load(DO + row * HD + offs, mask=m, other=0.0)
    tll.store(Delta + row, tll.sum(o * do))


@triton.jit
def _tri_bwd_dkv(Q, K, V, DO, LSE, DELTA, DK, DV, T, scale,
                 HD: tll.constexpr, BM: tll.constexpr, BN: tll.constexpr):
    pid_kv = tll.program_id(0)
    bh = tll.program_id(1)
    k0 = pid_kv * BN
    offs_kv = k0 + tll.arange(0, BN)
    offs_d = tll.arange(0, HD)
    base = bh * T * HD
    kvm = offs_kv[:, None] < T
    k = tll.load(K + base + offs_kv[:, None] * HD + offs_d[None, :],
                 mask=kvm, other=0.0)
    v = tll.load(V + base + offs_kv[:, None] * HD + offs_d[None, :],
                 mask=kvm, other=0.0)
    dk = tll.zeros((BN, HD), tll.float32)
    dv = tll.zeros((BN, HD), tll.float32)
    for i0 in range((k0 // BM) * BM, T, BM):
        offs_i = i0 + tll.arange(0, BM)
        im = offs_i < T
        q = tll.load(Q + base + offs_i[:, None] * HD + offs_d[None, :],
                     mask=im[:, None], other=0.0)
        do = tll.load(DO + base + offs_i[:, None] * HD + offs_d[None, :],
                      mask=im[:, None], other=0.0)
        lse = tll.load(LSE + bh * T + offs_i, mask=im, other=0.0)
        delta = tll.load(DELTA + bh * T + offs_i, mask=im, other=0.0)
        sT = tll.dot(k, tll.trans(q), input_precision="ieee") * scale
        keep = (offs_i[None, :] >= offs_kv[:, None]) & im[None, :]
        pT = tll.where(keep, tll.exp(sT - lse[None, :]), 0.0)
        dv = tll.dot(pT, do, dv, input_precision="ieee")
        dpT = tll.dot(v, tll.trans(do), input_precision="ieee")
        dsT = pT * (dpT - delta[None, :])
        dk = tll.dot(dsT, q, dk, input_precision="ieee")
    tll.store(DV + base + offs_kv[:, None] * HD + offs_d[None, :], dv,
              mask=kvm)
    tll.store(DK + base + offs_kv[:, None] * HD + offs_d[None, :], dk * scale,
              mask=kvm)


@triton.jit
def _tri_bwd_dq(Q, K, V, DO, LSE, DELTA, DQ, T, scale,
                HD: tll.constexpr, BM: tll.constexpr, BN: tll.constexpr):
    pid_m = tll.program_id(0)
    bh = tll.program_id(1)
    q0 = pid_m * BM
    offs_m = q0 + tll.arange(0, BM)
    offs_d = tll.arange(0, HD)
    base = bh * T * HD
    qm = offs_m[:, None] < T
    q = tll.load(Q + base + offs_m[:, None] * HD + offs_d[None, :],
                 mask=qm, other=0.0)
    do = tll.load(DO + base + offs_m[:, None] * HD + offs_d[None, :],
                  mask=qm, other=0.0)
    lse = tll.load(LSE + bh * T + offs_m, mask=offs_m < T, other=0.0)
    delta = tll.load(DELTA + bh * T + offs_m, mask=offs_m < T, other=0.0)
    dq = tll.zeros((BM, HD), tll.float32)
    for j0 in range(0, q0 + BM, BN):
        offs_n = j0 + tll.arange(0, BN)
        nm = offs_n < T
        k = tll.load(K + base + offs_n[:, None] * HD + offs_d[None, :],
                     mask=nm[:, None], other=0.0)
        v = tll.load(V + base + offs_n[:, None] * HD + offs_d[None, :],
                     mask=nm[:, None], other=0.0)
        s = tll.dot(q, tll.trans(k), input_precision="ieee") * scale
        keep = (offs_m[:, None] >= offs_n[None, :]) & nm[None, :]
        p = tll.where(keep, tll.exp(s - lse[:, None]), 0.0)
        dp = tll.dot(do, tll.trans(v), input_precision="ieee")
        ds = p * (dp - delta[:, None])
        dq = tll.dot(ds, k, dq, input_precision="ieee")
    tll.store(DQ + base + offs_m[:, None] * HD + offs_d[None, :], dq * scale,
              mask=qm)


def tri_flash_bwd(q, k, v, o, do, lse, cfg):
    B, H, T, HD = q.shape
    BM, BN, warps, stages = cfg
    delta = torch.empty((B, H, T), device=q.device, dtype=torch.float32)
    dq = torch.empty_like(q)
    dk = torch.empty_like(q)
    dv = torch.empty_like(q)
    _tri_bwd_preprocess[(B * H * T,)](o, do, delta, T, HD=HD, BLOCK=128)
    _tri_bwd_dkv[(triton.cdiv(T, BN), B * H)](
        q, k, v, do, lse, delta, dk, dv, T, 1.0 / np.sqrt(HD),
        HD=HD, BM=BM, BN=BN, num_warps=warps, num_stages=stages)
    _tri_bwd_dq[(triton.cdiv(T, BM), B * H)](
        q, k, v, do, lse, delta, dq, T, 1.0 / np.sqrt(HD),
        HD=HD, BM=BM, BN=BN, num_warps=warps, num_stages=stages)
    return dq, dk, dv


def tri_bwd_best(q, k, v, o, do, lse):
    best = None
    for cfg in _TRI_CONFIGS:
        try:
            fn = lambda: tri_flash_bwd(q, k, v, o, do, lse, cfg)
            fn()
            torch.cuda.synchronize()
            ms = do_bench(fn)
        except Exception:
            continue
        if best is None or ms < best[1]:
            best = (cfg, ms)
    cfg, ms = best
    return (lambda: tri_flash_bwd(q, k, v, o, do, lse, cfg)), ms, cfg


# ---------------------------------------------------------------------------
# torch eager unfused reference
# ---------------------------------------------------------------------------

def torch_unfused(q, k, v, scale, mask):
    s = (q @ k.transpose(-2, -1)) * scale + mask
    return torch.softmax(s, dim=-1) @ v


# ---------------------------------------------------------------------------

def bench_shape(B, H, T, HD=64):
    rng = np.random.default_rng(0)
    qn, kn, vn, gn = (rng.standard_normal((B, H, T, HD)).astype(np.float32)
                      for _ in range(4))
    scale = 1.0 / np.sqrt(HD)
    # minitriton fused (includes the k transpose in the timed call)
    tq, tk, tv, tg = (tl.tensor(x) for x in (qn, kn, vn, gn))
    with tl.no_grad():
        out, lse = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                                  with_lse=True)
    tl_fn = lambda: tl_ops.flash_attention_forward(tq, tk, tv, scale)
    tl_fn()
    tl.synchronize()
    tl_ms = do_bench(tl_fn)
    # triton
    qq, kk, vv = (torch.from_numpy(x).cuda() for x in (qn, kn, vn))
    tri_fn, tri_ms, cfg = tri_best(qq, kk, vv, scale)
    out_tri = tri_fn()
    # correctness cross-check (fp32 exp approximations -> loose tol)
    err = float(np.max(np.abs(out.numpy() - out_tri.cpu().numpy())))
    # torch eager unfused
    mask = torch.triu(torch.full((T, T), -1e9, device="cuda"), 1)
    t_fn = lambda: torch_unfused(qq, kk, vv, scale, mask)
    t_fn()
    torch.cuda.synchronize()
    t_ms = do_bench(t_fn)
    flops = flash_attn_fwd_flops(B, H, T, HD)  # shared causal-fwd ledger

    # -- backward: tl fused delta/dq/dv/dk vs triton 3-kernel --
    gg = torch.from_numpy(gn).cuda()
    # lse for the triton bwd comes from the tl forward (same math)
    lse_t = torch.from_numpy(lse.numpy()).cuda()
    tl_bwd = lambda: tl_ops.flash_attention_backward(tq, tk, tv, out, tg,
                                                     lse, scale)
    tl_bwd()
    tl.synchronize()
    tl_bms = do_bench(tl_bwd)
    dq1, dk1, dv1 = tl_bwd()
    tri_bwd_fn, tri_bms, bcfg = tri_bwd_best(qq, kk, vv, out_tri, gg, lse_t)
    dq2, dk2, dv2 = tri_bwd_fn()
    # reference grads: torch autograd through the unfused graph
    qr, kr, vr = (torch.from_numpy(x).cuda().requires_grad_(True)
                  for x in (qn, kn, vn))
    o_ref = torch_unfused(qr, kr, vr, scale, mask)

    def torch_bwd():
        for t in (qr, kr, vr):
            t.grad = None
        o_ref.backward(gg, retain_graph=True)

    torch_bwd()
    torch.cuda.synchronize()
    tb_ms = do_bench(torch_bwd)
    ref = [t.grad.detach().clone() for t in (qr, kr, vr)]
    berr = max(float(np.max(np.abs(a.numpy() - b.cpu().numpy())))
               for a, b in ((dq1, ref[0]), (dk1, ref[1]), (dv1, ref[2])))
    berr_tri = max(float(np.max(np.abs(a.cpu().numpy() - b.cpu().numpy())))
                   for a, b in ((dq2, ref[0]), (dk2, ref[1]), (dv2, ref[2])))
    bflops = 2.0 * flops  # bwd = 2x fwd (standard flash convention; no
    # bwd entry in accounting.py)
    return {
        "shape": f"B{B} H{H} T{T} d{HD}",
        "T": T,
        "tl_ms": tl_ms, "tri_ms": tri_ms, "torch_ms": t_ms,
        "tl_tf": flops / tl_ms * 1e-9, "tri_tf": flops / tri_ms * 1e-9,
        "ratio": tri_ms / tl_ms, "cfg": cfg, "err": err,
        "tl_bms": tl_bms, "tri_bms": tri_bms, "torch_bms": tb_ms,
        "tl_btf": bflops / tl_bms * 1e-9, "tri_btf": bflops / tri_bms * 1e-9,
        "bratio": tri_bms / tl_bms, "bcfg": bcfg,
        "berr": berr, "berr_tri": berr_tri,
    }


def main():
    print("fp32 causal flash-attention FORWARD; triton with "
          "input_precision='ieee' (same do_bench, CUDA events + L2 flush)\n")
    print(f"{'shape':>18} | {'tl ms':>8} | {'triton ms':>9} | {'torch ms':>9}"
          f" | {'tl TF/s':>8} | {'tri TF/s':>9} | {'tl/tri':>7} | "
          f"{'triton cfg':>14} | {'fwd err':>9}")
    ratios = []
    worst_err = 0.0
    rows = []
    for B, H, T in [(8, 12, 256), (8, 12, 512), (8, 12, 1024), (4, 8, 2048)]:
        r = bench_shape(B, H, T)
        rows.append(r)
        ratios.append(r["ratio"])
        worst_err = max(worst_err, r["err"])
        cfg_s = f"BM{r['cfg'][0]} BN{r['cfg'][1]} w{r['cfg'][2]} s{r['cfg'][3]}"
        print(f"{r['shape']:>18} | {r['tl_ms']:8.3f} | {r['tri_ms']:9.3f} | "
              f"{r['torch_ms']:9.3f} | {r['tl_tf']:8.2f} | {r['tri_tf']:9.2f} | "
              f"{r['ratio']:7.2f} | {cfg_s:>14} | {r['err']:9.1e}")
    g = float(np.exp(np.mean(np.log(ratios))))
    print(f"\ngeomean tl/triton fwd: {g:.2f}  (gate >= "
          f"{_FWD_GEOMEAN_GATE:.2f}, calibrated on L20: "
          f"{'PASS' if g >= _FWD_GEOMEAN_GATE else 'FAIL'})")
    print(f"worst fwd |err| vs triton: {worst_err:.2e} (fp32 approx-exp "
          "semantics differ slightly)")

    print("\nfp32 causal flash-attention BACKWARD: tl fused "
          "delta/dq/dv/dk vs triton tutorial-style 3-kernel bwd (ieee)\n")
    print(f"{'shape':>18} | {'tl ms':>8} | {'triton ms':>9} | {'torch ms':>9}"
          f" | {'tl TF/s':>8} | {'tri TF/s':>9} | {'tl/tri':>7} | "
          f"{'triton cfg':>14} | {'tl err':>9} | {'tri err':>9}")
    bratios, big_ok = [], True
    for r in rows:
        bratios.append(r["bratio"])
        c = r["bcfg"]
        cfg_s = f"BM{c[0]} BN{c[1]} w{c[2]} s{c[3]}"
        print(f"{r['shape']:>18} | {r['tl_bms']:8.3f} | {r['tri_bms']:9.3f} | "
              f"{r['torch_bms']:9.3f} | {r['tl_btf']:8.2f} | "
              f"{r['tri_btf']:9.2f} | {r['bratio']:7.2f} | {cfg_s:>14} | "
              f"{r['berr']:9.1e} | {r['berr_tri']:9.1e}")
        if r["T"] >= 1024 and r["bratio"] < _BWD_BIG_T_GATE:
            big_ok = False
    gb = float(np.exp(np.mean(np.log(bratios))))
    print(f"\ngeomean tl/triton bwd: {gb:.2f}  (gate >= "
          f"{_BWD_BIG_T_GATE:.2f} on T>=1024, calibrated on L20: "
          f"{'PASS' if big_ok else 'FAIL'})")
    if g < _FWD_GEOMEAN_GATE or not big_ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
