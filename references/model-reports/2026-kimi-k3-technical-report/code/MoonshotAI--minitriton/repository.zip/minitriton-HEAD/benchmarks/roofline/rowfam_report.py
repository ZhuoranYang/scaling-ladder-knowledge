#!/usr/bin/env python
"""Row family head-to-head: composed reference forms
(minitriton/sched/rowfam) vs fused production kernels
(device/cuda/ops.py row ops) — do_bench per family per shape.

    CUDA_VISIBLE_DEVICES=3 python benchmarks/roofline/rowfam_report.py

Writes benchmarks/roofline/rowfam.csv and prints the table. The table is
quoted in minitriton/sched/rowfam.py's module docstring — keep all
three in sync.
"""

import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import do_bench
import minitriton.device.cuda.ops as tl_be
from minitriton.sched import rowfam

OUT_CSV = Path(__file__).resolve().parent / "rowfam.csv"

SHAPES = [
    (4096, 768),
    (16384, 640),
    (16384, 2560),
    (8192, 4096),
    (1024, 8192),
]
CE_WIDE = [
    (512, 16384),
    (256, 65536),
]


def bench_pair(name, R, C, composed, production, w=None, b=None, t=None,
               g=None):
    composed(); production(); tl.synchronize()
    ms_c = do_bench(composed)
    ms_p = do_bench(production)
    return {"family": name, "R": R, "C": C,
            "composed_ms": f"{ms_c:.4f}", "production_ms": f"{ms_p:.4f}",
            "ratio": f"{ms_c / ms_p:.3f}"}


def main():
    rng = np.random.default_rng(0)
    rows = []
    for (R, C) in SHAPES:
        x = rng.standard_normal((R, C)).astype(np.float32)
        g = rng.standard_normal((R, C)).astype(np.float32)
        w = rng.standard_normal(C).astype(np.float32)
        b = rng.standard_normal(C).astype(np.float32)
        tx, tg, tw, tb = (tl.tensor(a) for a in (x, g, w, b))
        y = tl_be.softmax_rows(tx, False)
        # softmax fwd/bwd
        rows.append(bench_pair("softmax_fwd", R, C,
                               lambda: rowfam.softmax(tx),
                               lambda: tl_be.softmax_rows(tx, False)))
        rows.append(bench_pair("softmax_bwd", R, C,
                               lambda: rowfam.softmax_backward(tg, y),
                               lambda: tl_be.softmax_backward_rows(tg, y)))
        # LN fwd
        rows.append(bench_pair("ln_fwd", R, C,
                               lambda: rowfam.layer_norm(tx, tw, tb, 1e-5),
                               lambda: tl_be.layer_norm_rows(tx, tw, tb,
                                                             1e-5)))
        # LN bwd
        rows.append(bench_pair(
            "ln_bwd", R, C,
            lambda: rowfam.layernorm_backward(tg, tx, tw, 1e-5),
            lambda: tl_be.layernorm_backward_fused(tg, tx, tw, 1e-5)))
        # rms fwd/bwd
        rows.append(bench_pair("rms_fwd", R, C,
                               lambda: rowfam.rms_norm(tx, tw, 1e-5),
                               lambda: tl_be.rms_norm_rows(tx, tw, 1e-5)))
        rows.append(bench_pair(
            "rms_bwd", R, C,
            lambda: rowfam.rmsnorm_backward(tg, tx, tw, 1e-5),
            lambda: tl_be.rmsnorm_backward_rows(tg, tx, tw, 1e-5)))
        # CE fwd/bwd
        t = rng.integers(0, C, R).astype(np.int32)
        gr = rng.standard_normal(R).astype(np.float32)
        tt, tgr = tl.tensor(t), tl.tensor(gr)
        rows.append(bench_pair("ce_fwd", R, C,
                               lambda: rowfam.cross_entropy(tx, tt),
                               lambda: tl_be.cross_entropy_rows(tx, tt)))
        rows.append(bench_pair(
            "ce_bwd", R, C,
            lambda: rowfam.cross_entropy_backward(tx, tt, tgr),
            lambda: tl_be.cross_entropy_backward_rows(tx, tt, tgr)))
    for (R, C) in CE_WIDE:
        x = rng.standard_normal((R, C)).astype(np.float32)
        t = rng.integers(0, C, R).astype(np.int32)
        gr = rng.standard_normal(R).astype(np.float32)
        tx, tt, tgr = tl.tensor(x), tl.tensor(t), tl.tensor(gr)
        rows.append(bench_pair("ce_fwd_wide", R, C,
                               lambda: rowfam.cross_entropy(tx, tt),
                               lambda: tl_be.cross_entropy_rows(tx, tt)))
        rows.append(bench_pair(
            "ce_bwd_wide", R, C,
            lambda: rowfam.cross_entropy_backward(tx, tt, tgr),
            lambda: tl_be.cross_entropy_backward_rows(tx, tt, tgr)))
    hdr = f"{'family':<12} {'R':>6} {'C':>6} {'composed':>10} {'fused':>10} {'c/f':>6}"
    print(hdr)
    print("-" * len(hdr))
    for r in rows:
        print(f"{r['family']:<12} {r['R']:>6} {r['C']:>6} "
              f"{r['composed_ms']:>10} {r['production_ms']:>10} "
              f"{r['ratio']:>6}")
    with open(OUT_CSV, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {OUT_CSV}")


if __name__ == "__main__":
    main()
