#!/usr/bin/env python
"""KDA tensor-core benchmark: minitriton KDA mma tiers
(tf32 / bf16) vs self-written triton SAME-TIER references vs the tl fp32
CUDA-core pipeline. Tiers are tabled separately (never mixed into one
geomean), like attention_mma_report.py; gate: >= 0.9x triton
same-tier timing on the big shapes (T >= 1024).

The triton references share the three-kernel structure of
benchmarks/roofline/kda_report.py (wy with prod-of-squares inverse, state
scan, out; eager preprocessing inside the timed call on both sides):
- tf32 tier: fp32 operands, every tl.dot at input_precision="tf32".
- bf16 tier: the decayed-key planes (delta/qh/wc/wt), state operands
  (md/hc/vt) and the Aq/vt dots are bf16 with f32 accumulation; the
  cumsum + prod-of-squares inverse stay fp32-ieee — i.e. the SAME cast
  points as the tl bf16 pipeline (whose solve_tril also stays fp32).

    CUDA_VISIBLE_DEVICES=2 python benchmarks/roofline/kda_mma_report.py
"""

import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import do_bench, ops as tl_ops
from minitriton.device.cpu import _kda_chunk_np

import torch
import triton
import triton.language as tll

torch.backends.cuda.matmul.allow_tf32 = False

C = 64  # chunk size


# ---------------------------------------------------------------------------
# triton references: three kernels per tier (dot precision parameterized)
# ---------------------------------------------------------------------------

@triton.jit
def _dot2(a, b, PREC: tll.constexpr, BF16: tll.constexpr):
    # input_precision only applies to fp32 dots; bf16 operands use the
    # native bf16 mma path
    if BF16:
        return tll.dot(a, b)
    else:
        return tll.dot(a, b, input_precision=PREC)


@triton.jit
def _dot3(a, b, acc, PREC: tll.constexpr, BF16: tll.constexpr):
    if BF16:
        return tll.dot(a, b, acc)
    else:
        return tll.dot(a, b, acc, input_precision=PREC)


@triton.jit
def _tri_wy(KN, QN, BETA, LOGA, GT, CSH, EMC,
            M, DELTA, QH, WC, WT, T, NC,
            DK: tll.constexpr, C: tll.constexpr,
            PREC: tll.constexpr, BF16: tll.constexpr):
    pid = tll.program_id(0)
    bh = tll.program_id(1)
    offs = tll.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    base = bh * T * DK
    offs2 = offs_t[:, None] * DK + offs[None, :]
    offsC = offs[:, None] * C + offs[None, :]
    il = tll.where(offs[:, None] >= offs[None, :], 1.0, 0.0)
    sl = tll.where(offs[:, None] > offs[None, :], 1.0, 0.0)
    eye = tll.where(offs[:, None] == offs[None, :], 1.0, 0.0)
    la = tll.load(LOGA + base + offs2, mask=tm[:, None], other=0.0)
    kn = tll.load(KN + base + offs2, mask=tm[:, None], other=0.0)
    qn = tll.load(QN + base + offs2, mask=tm[:, None], other=0.0)
    beta = tll.load(BETA + bh * T + offs_t, mask=tm, other=0.0)
    gt = tll.load(GT + slab * DK + offs)
    c = tll.load(CSH + slab)
    emc = tll.load(EMC + slab)
    g = tll.dot(il, la, input_precision="ieee")           # cumsum stays fp32
    eg = tll.exp(g)
    delta = eg * kn
    qh = eg * qn
    gt2 = tll.trans(g)
    e = tll.minimum(tll.maximum(c - gt2, -80.0), 80.0)
    knT = tll.trans(kn)
    wcT = knT * beta[None, :] * tll.exp(e)
    wtT = knT * beta[None, :] * tll.exp(gt[:, None] - gt2)
    if BF16:
        delta = delta.to(tll.bfloat16)
        qh = qh.to(tll.bfloat16)
        wcT = wcT.to(tll.bfloat16)
        wtT = wtT.to(tll.bfloat16)
    L = _dot2(delta, wcT, PREC, BF16) * sl * emc
    # in both tiers (mirrors the tl pipeline's fp32 tl.solve_tril)
    P = -L
    W = eye + P
    for _ in tll.static_range(5):
        P = tll.dot(P, P, input_precision="ieee")
        W += tll.dot(P, W, input_precision="ieee")
    tll.store(M + slab * C * C + offsC, W)
    tll.store(DELTA + slab * C * DK + offs[:, None] * DK + offs[None, :],
              delta.to(DELTA.dtype.element_ty))
    tll.store(QH + slab * C * DK + offs[:, None] * DK + offs[None, :],
              qh.to(QH.dtype.element_ty))
    tll.store(WC + slab * DK * C + offsC, wcT.to(WC.dtype.element_ty))
    tll.store(WT + slab * DK * C + offsC, wtT.to(WT.dtype.element_ty))


@triton.jit
def _tri_state(M, DELTA, WT, GT, V, HC, VT, S1, T, NC,
               DK: tll.constexpr, DV: tll.constexpr, C: tll.constexpr,
               PREC: tll.constexpr, BF16: tll.constexpr):
    # same 3-dot serial structure as the kda_report fp32 reference (the
    # reference's own best form: vt = M @ (v - delta @ S)); bf16 casts at
    # the points the two pipelines share (S/vt quantization for the mma)
    bh = tll.program_id(0)
    offs = tll.arange(0, C)
    offs_v = tll.arange(0, DV)
    offsC = offs[:, None] * C + offs[None, :]
    S = tll.zeros((C, DV), tll.float32)
    for cc in range(0, NC):
        slab = bh * NC + cc
        offs_t = cc * C + offs
        vm = offs_t < T
        v = tll.load(V + bh * T * DV + offs_t[:, None] * DV
                     + offs_v[None, :], mask=vm[:, None], other=0.0)
        m = tll.load(M + slab * C * C + offsC)
        d = tll.load(DELTA + slab * C * DK + offs[:, None] * DK
                     + offs[None, :])
        if BF16:
            m = m.to(tll.bfloat16)
            s16 = S.to(tll.bfloat16)
        else:
            s16 = S
        tll.store(HC + slab * DK * DV + offs[:, None] * DV
                  + offs_v[None, :], s16.to(HC.dtype.element_ty))
        x = v - _dot2(d, s16, PREC, BF16)
        if BF16:
            x = x.to(tll.bfloat16)
        vt = _dot2(m, x, PREC, BF16)
        if BF16:
            vt = vt.to(tll.bfloat16)
        tll.store(VT + slab * C * DV + offs[:, None] * DV + offs_v[None, :],
                  vt.to(VT.dtype.element_ty))
        gt = tll.load(GT + slab * DK + offs)
        wt = tll.load(WT + slab * DK * C + offsC)
        S = tll.exp(gt)[:, None] * S + _dot2(wt, vt, PREC, BF16)
    tll.store(S1 + bh * DK * DV + offs[:, None] * DV + offs_v[None, :], S)


@triton.jit
def _tri_out(QH, WC, HC, VT, EMC, O, T, NC,
             DK: tll.constexpr, DV: tll.constexpr, C: tll.constexpr,
             PREC: tll.constexpr, BF16: tll.constexpr):
    pid = tll.program_id(0)
    bh = tll.program_id(1)
    offs = tll.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    offsC = offs[:, None] * C + offs[None, :]
    offs_v = tll.arange(0, DV)
    il = tll.where(offs[:, None] >= offs[None, :], 1.0, 0.0)
    emc = tll.load(EMC + slab)
    qh = tll.load(QH + slab * C * DK + offs[:, None] * DK + offs[None, :])
    wcT = tll.load(WC + slab * DK * C + offsC)
    Aq = _dot2(qh, wcT, PREC, BF16) * il * emc
    hc = tll.load(HC + slab * DK * DV + offs[:, None] * DV
                  + offs_v[None, :])
    vt = tll.load(VT + slab * C * DV + offs[:, None] * DV
                  + offs_v[None, :])
    if BF16:
        Aq = Aq.to(tll.bfloat16)
    o = _dot2(qh, hc, PREC, BF16)
    o = _dot3(Aq, vt, o, PREC, BF16)
    tll.store(O + bh * T * DV + offs_t[:, None] * DV + offs_v[None, :], o,
              mask=tm[:, None])


def tri_kda(q, k, v, xb, xd, cfg, tier):
    """torch eager preprocessing (same math as ops/kda.py) + 3 kernels."""
    wy_w, st_w, out_w = cfg
    bf16 = tier == "bf16"
    B, H, T, dk = k.shape
    dv = v.shape[-1]
    NC = (T + C - 1) // C
    kn = k / torch.sqrt((k * k).sum(-1, keepdim=True))
    qn = q / torch.sqrt((q * q).sum(-1, keepdim=True))
    beta = torch.sigmoid(xb)
    loga = torch.nn.functional.logsigmoid(xd)
    pad = NC * C - T
    loga_p = torch.nn.functional.pad(loga, (0, 0, 0, pad))
    gt = loga_p.reshape(B, H, NC, C, dk).sum(3)
    c = gt.min(-1).values.clamp(min=-80.0)
    emc = torch.exp(-c)
    BH = B * H
    dev = q.device
    f = torch.float32
    pdt = torch.bfloat16 if bf16 else torch.float32
    M = torch.empty((BH * NC, C, C), dtype=f, device=dev)
    delta = torch.empty((BH * NC, C, dk), dtype=pdt, device=dev)
    qh = torch.empty((BH * NC, C, dk), dtype=pdt, device=dev)
    wc = torch.empty((BH * NC, dk, C), dtype=pdt, device=dev)
    wt = torch.empty((BH * NC, dk, C), dtype=pdt, device=dev)
    hc = torch.empty((BH * NC, dk, dv), dtype=pdt, device=dev)
    vt = torch.empty((BH * NC, C, dv), dtype=pdt, device=dev)
    s1 = torch.empty((BH, dk, dv), dtype=f, device=dev)
    o = torch.empty((B, H, T, dv), dtype=f, device=dev)
    vo = v.bfloat16() if bf16 else v
    _tri_wy[(NC, BH)](kn, qn, beta, loga, gt, c, emc,
                      M, delta, qh, wc, wt, T, NC, DK=dk, C=C,
                      PREC="ieee" if tier == "fp32" else "tf32",
                      BF16=(tier == "bf16"), num_warps=wy_w,
                      num_stages=1)
    _tri_state[(BH,)](M, delta, wt, gt, vo, hc, vt, s1, T, NC,
                      DK=dk, DV=dv, C=C,
                      PREC="ieee" if tier == "fp32" else "tf32",
                      BF16=bf16, num_warps=st_w, num_stages=1)
    _tri_out[(NC, BH)](qh, wc, hc, vt, emc, o, T, NC,
                       DK=dk, DV=dv, C=C,
                       PREC="ieee" if tier == "fp32" else "tf32",
                       BF16=bf16, num_warps=out_w, num_stages=1)
    return o


_TRI_CONFIGS = [(4, 2, 4), (4, 4, 4), (8, 4, 8)]


def tri_best(q, k, v, xb, xd, tier):
    best = None
    for cfg in _TRI_CONFIGS:
        try:
            fn = lambda: tri_kda(q, k, v, xb, xd, cfg, tier)
            fn()
            torch.cuda.synchronize()
            ms = do_bench(fn)
        except Exception:
            continue
        if best is None or ms < best[1]:
            best = (cfg, ms)
    cfg, ms = best
    return (lambda: tri_kda(q, k, v, xb, xd, cfg, tier)), ms, cfg


# ---------------------------------------------------------------------------
# FLOP / traffic accounting (per (b,h,chunk), dk=dv=C=64): 10.7 MF /
# ~290 KB analytic model for the mma pipeline. Different accounting from
# the CUDA-core kda rows (benchmarks/roofline/kda_report.py: 5.9 MF /
# ~426 KB per (b,h,chunk) for the v2/v3 fused pipeline) -- the two
# roofline figures place the KDA points differently.
# ---------------------------------------------------------------------------

FLOPS = 10.7e6
BYTES = 290.0e3


def bench_shape(B, H, T, dk=64, check=True):
    rng = np.random.default_rng(0)
    qn, kn, vn = (rng.standard_normal((B, H, T, dk)).astype(np.float32)
                  for _ in range(3))
    xbn = rng.standard_normal((B, H, T)).astype(np.float32)
    loga = rng.uniform(-0.7, 0.0, (B, H, T, dk))
    a = np.exp(loga)
    xdn = np.log(a / (1.0 - a)).astype(np.float32)
    NC = (T + C - 1) // C
    tq, tk, tv, txb, txd = (tl.tensor(x) for x in (qn, kn, vn, xbn, xdn))
    qq, kk, vv, qxb, qxd = (torch.from_numpy(x).cuda()
                            for x in (qn, kn, vn, xbn, xdn))
    res = {"shape": f"B{B}H{H}T{T}d{dk}", "T": T,
           "flops": FLOPS * B * H * NC, "bytes": BYTES * B * H * NC}
    outs = {}
    for tier in ("tf32", "bf16", "fp32"):
        if tier == "fp32":
            tl_fn = lambda: tl_ops.kda_forward(tq, tk, tv, txb, txd)
        else:
            tl_fn = lambda: tl_ops.kda_forward(tq, tk, tv, txb, txd,
                                               precision=tier)
        outs[("tl", tier)] = tl_fn()
        tl.synchronize()
        res[f"tl_{tier}_ms"] = do_bench(tl_fn)
        tri_fn, tri_ms, cfg = tri_best(qq, kk, vv, qxb, qxd, tier)
        outs[("tri", tier)] = tri_fn()
        res[f"tri_{tier}_ms"] = tri_ms
        res[f"tri_{tier}_cfg"] = cfg
    if check:
        kp = kn / np.sqrt((kn * kn).sum(-1, keepdims=True))
        qp = qn / np.sqrt((qn * qn).sum(-1, keepdims=True))
        bp = 1.0 / (1.0 + np.exp(-xbn))
        lp = np.where(xdn > 0, 0.0, xdn) - np.log(np.exp(-np.abs(xdn)) + 1.0)
        o_ref, _ = _kda_chunk_np(kp, qp, vn, bp, lp)
        for (side, tier), out in outs.items():
            on = out.numpy() if side == "tl" else out.cpu().numpy()
            res[f"err_{side}_{tier}"] = float(np.max(np.abs(on - o_ref)))
    return res


def collect_results():
    """roofline hook: rows for roofline_tensor_core.csv, kernel
    kda_tf32/kda_bf16, impl minitriton/triton. Accounting is the mma
    model above (10.7 MF / 290 KB per (b,h,chunk)); the CUDA-core kda
    rows use the v2/v3 pipeline's own 5.9 MF / 426 KB model
    (kda_report.py), so the two figures' KDA points are not directly
    comparable."""
    rows = []
    for B, H, T in [(4, 8, 512), (4, 8, 1024), (4, 8, 2048), (4, 8, 4096)]:
        r = bench_shape(B, H, T, check=False)
        for tier in ("tf32", "bf16"):
            for impl, ms in (("minitriton", r[f"tl_{tier}_ms"]),
                             ("triton", r[f"tri_{tier}_ms"])):
                rows.append({
                    "kernel": f"kda_{tier}", "shape": r["shape"],
                    "impl": impl, "ms": ms,
                    "flops": r["flops"], "bytes": r["bytes"],
                    "note": ("KDA fwd mma tier (C=64); flops=10.7 MF/"
                             "(b,h,chunk) analytic model for the "
                             "mma pipeline (accounting block above); "
                             "bytes=290 KB "
                             "traffic model; triton=self-written same-"
                             "tier reference (cast points mirrored)"),
                })
        print(f"  kda T{T}: tl tf32 {r['tl_tf32_ms']:.3f} / tri "
              f"{r['tri_tf32_ms']:.3f} ms; tl bf16 {r['tl_bf16_ms']:.3f} / "
              f"tri {r['tri_bf16_ms']:.3f} ms")
    return rows


def main():
    print("KDA tensor-core forward: tl mma tiers vs triton "
          "SAME-TIER references (same do_bench, CUDA events + L2 flush)")
    print("tier discipline: tf32 = f32 operands + tf32 mma; bf16 = bf16 "
          "operand planes + f32 accumulate (inverse stays fp32 both "
          "sides); tl fp32 = the CUDA-core pipeline\n")
    rows = []
    for B, H, T in [(4, 8, 512), (4, 8, 1024), (4, 8, 2048), (4, 8, 4096)]:
        rows.append(bench_shape(B, H, T))
    hdr = (f"{'shape':>16} | {'impl':>10} | {'ms':>8} | {'TF/s':>7} | "
           f"{'vs triton':>9}")
    gates = {}
    for tier in ("tf32", "bf16"):
        print(f"== {tier} tier ==")
        print(hdr)
        ratios = []
        big_ok = True
        for r in rows:
            tl_ms, tri_ms = r[f"tl_{tier}_ms"], r[f"tri_{tier}_ms"]
            ratio = tri_ms / tl_ms
            ratios.append(ratio)
            if r["T"] >= 1024 and ratio < 0.9:
                big_ok = False
            print(f"{r['shape']:>16} | {'tl ' + tier:>10} | {tl_ms:8.3f} | "
                  f"{r['flops'] / tl_ms * 1e-9:7.2f} | {ratio:9.2f}")
            print(f"{'':>16} | {'triton':>10} | {tri_ms:8.3f} | "
                  f"{r['flops'] / tri_ms * 1e-9:7.2f} | "
                  f"cfg {r[f'tri_{tier}_cfg']}")
            print(f"{'':>16} | {'tl fp32':>10} | {r['tl_fp32_ms']:8.3f} | "
                  f"{r['flops'] / r['tl_fp32_ms'] * 1e-9:7.2f} |")
            print(f"{'':>16} | {'tr fp32':>10} | {r['tri_fp32_ms']:8.3f} |")
        g = float(np.exp(np.mean(np.log(ratios))))
        gates[tier] = big_ok
        print(f"geomean tl/triton {tier}: {g:.2f}  (gate >= 0.90 on "
              f"T>=1024: {'PASS' if big_ok else 'FAIL'})\n")
    print("accuracy vs fp64 oracle (max abs err; realistic decay "
          "loga in (-0.7, 0)):")
    for r in rows:
        print(f"  {r['shape']:>14}: tl tf32 {r['err_tl_tf32']:.2e} | "
              f"tri tf32 {r['err_tri_tf32']:.2e} | tl bf16 "
              f"{r['err_tl_bf16']:.2e} | tri bf16 {r['err_tri_bf16']:.2e} "
              f"| tl fp32 {r['err_tl_fp32']:.2e}")

    csv_path = Path(__file__).with_name("kda_mma.csv")
    fields = sorted({k for r in rows for k in r})
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"\nwrote {csv_path}")
    if not all(gates.values()):
        sys.exit(1)


if __name__ == "__main__":
    main()
