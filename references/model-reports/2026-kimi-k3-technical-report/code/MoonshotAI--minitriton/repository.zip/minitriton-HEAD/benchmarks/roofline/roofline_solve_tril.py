#!/usr/bin/env python
"""solve_tril roofline data (benchmarks/roofline/roofline_solve_tril.csv).

Puts solve_tril on the CUDA-core roofline: Ai = (I + A)^-1 per BTxBT
strictly-lower block, A ~ [B, T, H, BT] (delta-rule / GDN chunk
UT-transform), measured on this machine. Same shape grid
and the same do_bench timing protocol as the rest of benchmarks/.

Implementations:
- minitriton: the hand-written warp-level tl.solve_tril primitive (the
  naive W-IR + generic-passes variant is measured and printed too, but
  stays out of the CSV -- hand-vs-wir is a compiler-pass story,
  not a minitriton-vs-baseline comparison). Works directly on the
  original strided [B,T,H,BT] layout.
- torch_eager: torch.linalg.solve_triangular on the repacked contiguous
  [n_blocks, BT, BT] layout (batched trsm, unit diagonal). The repack
  and the eye construction are NOT timed -- the baseline receives the
  contiguous layout for free.
- triton: naive forward-substitution reference written for this script
  (one program per block, BT sequential row steps) on the same untimed
  repacked layout. This is a simple in-repo reference point, not fla.

Arithmetic-intensity convention (per BTxBT block, fp32 in/out):
  flops ~= BT^3/3            (forward substitution on the unit diagonal)
  bytes = BT^2 * 4 * 1.625   (A lower-triangle read = 10/16 sub-blocks
                             0.625x + Ai full write 1.0x, same effective-
                             traffic model as solve_tril_bench.py;
                             rhs = I is implicit, no traffic)
  => AI = BT / 19.5 = 0.82 / 1.64 / 3.28 for BT = 16 / 32 / 64
All shapes are far left of the fp32 knee (AI ~ 57), i.e. bandwidth-bound.

The CSV uses the roofline_data.csv schema so benchmarks/
roofline_cuda_core.py can merge it directly.

    CUDA_VISIBLE_DEVICES=2 python benchmarks/roofline/roofline_solve_tril.py
"""

import csv
import sys
from datetime import datetime, timezone
from pathlib import Path

BENCH_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BENCH_DIR.parent.parent))
sys.path.insert(0, str(BENCH_DIR.parent))
sys.path.insert(0, str(BENCH_DIR))

import numpy as np
import torch
import triton
import triton.language as tt

import minitriton as tl
from minitriton import do_bench

import solve_tril_bench as stb
from roofline import measure_dram_bw, measure_fp32_peak

CSV_PATH = BENCH_DIR / "roofline_solve_tril.csv"

SHAPES = stb.SHAPES  # (B, T, H, BT) grid, shared with solve_tril_bench.py

NOTE_BASE = ("unit lower-tri inverse Ai=(I+A)^-1 per BTxBT block "
             "(delta-rule UT transform); flops~=BT^3/3 per block "
             "(forward substitution); bytes=nblocks*BT^2*4*(0.625 A "
             "lower-tri read + 1.0 Ai write), rhs=I implicit")
NOTE_IMPL = {
    "minitriton": "hand warp-level tl.solve_tril primitive (works on "
                  "the original strided [B,T,H,BT] layout)",
    "torch_eager": "torch.linalg.solve_triangular (batched trsm, "
                   "unit diagonal) on repacked contiguous blocks; the "
                   "repack is NOT timed",
    "triton": "naive forward-substitution reference written in this "
              "script (NOT fla; runs on the same untimed repacked "
              "layout as torch)",
}


@triton.jit
def tri_fs_naive(a_ptr, x_ptr, BT: tt.constexpr):
    """Naive triton reference: one program per block, forward substitution
    row by row (BT sequential steps). Correct but deliberately unsophisti-
    cated -- no tiling/merge, no cross-row parallelism."""
    pid = tt.program_id(0)
    offs = tt.arange(0, BT)
    a = tt.load(a_ptr + pid * BT * BT + offs[:, None] * BT + offs[None, :])
    x = tt.where(offs[:, None] == offs[None, :], 1.0, 0.0)
    for i in range(BT):
        a_row = tt.sum(tt.where(offs[:, None] == i, a, 0.0), axis=0)
        dot = tt.sum(a_row[:, None] * tt.where(offs[:, None] < i, x, 0.0),
                     axis=0)
        new_row = tt.where(offs == i, 1.0, 0.0) - dot
        x = tt.where(offs[:, None] == i, new_row[None, :], x)
    tt.store(x_ptr + pid * BT * BT + offs[:, None] * BT + offs[None, :], x)


def repack_blocks(A, B, T, H, BT):
    """(B,T,H,BT) strictly-lower A -> contiguous [n_blocks, BT, BT] (torch)."""
    NT = T // BT
    return (torch.from_numpy(A).cuda()
            .reshape(B, NT, BT, H, BT).permute(0, 1, 3, 2, 4)
            .reshape(-1, BT, BT).contiguous())


def flops_bytes(B, T, H, BT):
    n_blocks = B * H * (T // BT)
    flops = n_blocks * BT**3 / 3.0
    bts = n_blocks * BT * BT * 4 * 1.625
    return flops, bts


def bench_shape(B, T, H, BT, check=False):
    """Median ms per impl for one shape -> dict impl -> ms."""
    A = stb.gen_input(B, T, H, BT)
    NT = T // BT
    n_blocks = B * H * NT

    # minitriton (hand primitive + naive W-IR), original strided layout
    a_buf = tl.Buffer.from_numpy(A)
    ai_buf = tl.Buffer(A.size, tl.float32)
    tl_ms = do_bench(lambda: stb.solve_tril_bench_kernel[(NT, B * H)](
        a_buf, ai_buf, T, H, BT=BT))
    wir_ms = do_bench(lambda: stb.solve_tril_wir_bench_kernel[(NT, B * H)](
        a_buf, ai_buf, T, H, BT=BT))

    # torch / triton on the repacked contiguous block layout
    t = repack_blocks(A, B, T, H, BT)
    eye = torch.eye(BT, device="cuda").expand(n_blocks, BT, BT).contiguous()
    L = eye + t
    torch_ms = do_bench(lambda: torch.linalg.solve_triangular(
        L, eye, upper=False, unitriangular=True))
    x = torch.empty_like(t)
    tri_ms = do_bench(lambda: tri_fs_naive[(n_blocks,)](t, x, BT=BT))

    if check:
        # tl hand vs torch vs triton-naive vs fp64 oracle (first 8 blocks)
        stb.solve_tril_bench_kernel[(NT, B * H)](a_buf, ai_buf, T, H, BT=BT)
        tl.synchronize()
        ai_tl = (ai_buf.to_numpy().reshape(A.shape)
                 .reshape(B, NT, BT, H, BT).transpose(0, 1, 3, 2, 4)
                 .reshape(-1, BT, BT))
        ref64 = torch.linalg.inv(eye.double() + t.double())
        ref = torch.linalg.solve_triangular(L, eye, upper=False,
                                            unitriangular=True)
        tri_fs_naive[(n_blocks,)](t, x, BT=BT)
        torch.cuda.synchronize()
        ai_tl_t = torch.from_numpy(ai_tl).cuda()
        for name, got in (("tl", ai_tl_t), ("torch", ref), ("triton", x)):
            err = (got.double() - ref64).abs().max().item()
            print(f"  correctness {name:>7}: max|err| vs fp64 inv = "
                  f"{err:.2e}")
            assert err < 1e-4, f"{name} solve_tril mismatch: {err}"

    del a_buf, ai_buf, t, eye, L, x
    return {"minitriton": tl_ms, "torch_eager": torch_ms, "triton": tri_ms,
            "_wir": wir_ms}


def write_csv(rows, bw_gbs, peak_gflops):
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    gpu = torch.cuda.get_device_name(0)
    cap = torch.cuda.get_device_capability(0)
    meta = [
        "MiniTriton solve_tril roofline data "
        "(benchmarks/roofline/roofline_solve_tril.py)",
        f"generated_utc: {ts}",
        f"gpu: {gpu} (sm_{cap[0]}{cap[1]}), CUDA_VISIBLE_DEVICES=2",
        "machine calibration (measured, same routines as "
        "benchmarks/roofline/roofline.py):",
        f"  dram_bw_gbs: {bw_gbs:.1f}  (torch.add 2^28 fp32, 3 streams, "
        "do_bench)",
        f"  fp32_peak_gflops: {peak_gflops:.1f}  (cuBLAS SGEMM 8192^3, "
        "allow_tf32=False)",
        "roofline model: roof(ai)=min(fp32_peak_gflops, dram_bw_gbs*ai); "
        "pct_of_roofline=100*gflops/roof(ai)",
        "timing: minitriton do_bench (CUDA events + L2 flush, warmup=5, "
        "rep=20, median), same protocol as the rest of benchmarks/",
        "op: Ai=(I+A)^-1 per BTxBT strictly-lower block, A~[B,T,H,BT] "
        "(delta-rule / GDN chunk UT-transform); shape grid shared with "
        "solve_tril_bench.py",
        "arithmetic-intensity convention:",
        "  flops ~= nblocks * BT^3/3  (forward substitution, unit diag)",
        "  bytes = nblocks * BT^2 * 4 * 1.625  (A lower-tri read 0.625x "
        "= 10/16 sub-blocks + Ai full write 1.0x; rhs=I implicit, no "
        "traffic) -- same effective-traffic model as solve_tril_bench.py",
        "  => AI = BT/19.5 = 0.82/1.64/3.28 for BT=16/32/64 "
        "(bandwidth-bound: fp32 knee at AI~57)",
        "impls: minitriton = hand warp-level tl.solve_tril primitive "
        "(naive W-IR + generic passes measured alongside, printed to "
        "stdout, kept out of the CSV -- that comparison is out of scope "
        "here) / torch_eager = torch.linalg."
        "solve_triangular batched trsm on repacked contiguous blocks / "
        "triton = naive forward-substitution reference written in this "
        "script (not fla). Fairness note: the baselines run on the "
        "repacked contiguous [n_blocks,BT,BT] layout and the repack "
        "(plus eye construction) is NOT timed; minitriton solves on "
        "the original strided [B,T,H,BT] layout with no repack",
        "columns: ms=median milliseconds; gflops=flops/ms*1e-6; "
        "ai=flops/bytes",
    ]
    with CSV_PATH.open("w", newline="") as f:
        for line in meta:
            f.write(f"# {line}\n")
        w = csv.DictWriter(f, fieldnames=["kernel", "shape", "impl", "ms",
                                          "flops", "bytes", "ai", "gflops",
                                          "pct_of_roofline", "note"])
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {CSV_PATH} ({len(rows)} rows)")


def main():
    print("calibrating roofline (measured, not spec) ...")
    bw_gbs = measure_dram_bw()
    print(f"  DRAM bandwidth (torch add 2^28, 3 streams): {bw_gbs:.1f} GB/s")
    peak_gflops = measure_fp32_peak()
    print(f"  fp32 peak (cuBLAS SGEMM 8192^3):          "
          f"{peak_gflops:.1f} GFLOP/s")

    hdr = (f"{'B x T x H x BT':>20} | {'tl (us)':>8} | {'wir (us)':>8}"
           f" | {'torch (us)':>10} | {'triton (us)':>11} | {'GB/s(tl)':>8}"
           f" | {'%roof(tl)':>9}")
    print(hdr)
    print("-" * len(hdr))
    rows = []
    ratios_w, ratios_t, ratios_tri = [], [], []
    for i, (B, T, H, BT) in enumerate(SHAPES):
        got = bench_shape(B, T, H, BT, check=(i == 0))
        flops, bts = flops_bytes(B, T, H, BT)
        ai = flops / bts
        roof = min(peak_gflops, bw_gbs * ai)
        tl_ms, wir_ms = got["minitriton"], got["_wir"]
        gbps = bts / (tl_ms * 1e-3) / 1e9
        pct = 100.0 * (flops / tl_ms * 1e-6) / roof
        print(f"{B:>2} x {T:<5} x {H:<2} x {BT:<2} | {tl_ms*1e3:8.1f}"
              f" | {wir_ms*1e3:8.1f} | {got['torch_eager']*1e3:10.1f}"
              f" | {got['triton']*1e3:11.1f} | {gbps:8.0f} | {pct:8.1f}%",
              flush=True)
        ratios_w.append(tl_ms / wir_ms)
        ratios_t.append(got["torch_eager"] / tl_ms)
        ratios_tri.append(got["triton"] / tl_ms)
        for impl in ("minitriton", "torch_eager", "triton"):
            ms = got[impl]
            gflops = flops / ms * 1e-6
            rows.append({
                "kernel": "solve_tril", "shape": f"{B}x{T}x{H}x{BT}",
                "impl": impl, "ms": f"{ms:.6f}",
                "flops": int(round(flops)), "bytes": int(round(bts)),
                "ai": f"{ai:.4f}", "gflops": f"{gflops:.2f}",
                "pct_of_roofline": f"{100.0 * gflops / roof:.2f}",
                "note": f"{NOTE_BASE}; {NOTE_IMPL[impl]}; bandwidth-bound",
            })
    geo = lambda r: float(np.exp(np.mean(np.log(r))))
    print(f"geomean hand/wir: {geo(ratios_w):.2f}x  "
          f"torch/tl: {geo(ratios_t):.2f}x  triton-naive/tl: "
          f"{geo(ratios_tri):.2f}x")

    write_csv(rows, bw_gbs, peak_gflops)


if __name__ == "__main__":
    main()
