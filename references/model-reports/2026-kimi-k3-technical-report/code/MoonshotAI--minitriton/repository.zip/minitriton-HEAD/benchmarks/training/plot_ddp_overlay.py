#!/usr/bin/env python
"""DDP acceptance figure: overlaid loss trajectories of single-GPU vs
2-GPU DDP (NCCL) at the same init / global batch / lr schedule, plus the
per-step signed difference. Dark plot_style; the output PNG is
allowlist-tracked in git (assets/train_gpt_ddp_overlay.png).

Reproduce (the README's DDP demo, 120 steps, default batch):

    CUDA_VISIBLE_DEVICES=0   python examples/train_gpt.py --steps 120 \
        --loss-csv benchmarks/training/ddp_pub_single.csv
    CUDA_VISIBLE_DEVICES=0,1 python examples/train_gpt.py --ddp --steps 120 \
        --loss-csv benchmarks/training/ddp_pub_ddp.csv
    python benchmarks/training/plot_ddp_overlay.py \
        benchmarks/training/ddp_pub_single.csv benchmarks/training/ddp_pub_ddp.csv
"""

import csv
import sys
from pathlib import Path

import numpy as np

TRAIN = Path(__file__).resolve().parent
ROOT = TRAIN.parents[1]

SINGLE_CSV = Path(sys.argv[1]) if len(sys.argv) > 1 else \
    TRAIN / "ddp_pub_single.csv"
DDP_CSV = Path(sys.argv[2]) if len(sys.argv) > 2 else TRAIN / "ddp_pub_ddp.csv"
OUT = Path(sys.argv[3]) if len(sys.argv) > 3 else \
    ROOT / "assets" / "train_gpt_ddp_overlay.png"


def load(path: Path) -> np.ndarray:
    rows = [r for r in csv.reader(open(path)) if r and r[0] != "step"]
    return np.array([float(r[1]) for r in rows])


def main():
    single, ddp = load(SINGLE_CSV), load(DDP_CSV)
    n = min(len(single), len(ddp))
    single, ddp = single[:n], ddp[:n]
    d = ddp - single
    assert not np.isnan(single).any() and not np.isnan(ddp).any(), "NaN loss"

    sys.path.insert(0, str(ROOT / "benchmarks" / "roofline"))
    import plot_style as ps

    mad, meand = np.abs(d).max(), np.abs(d).mean()

    # legend device tag: the measured GPU when torch/CUDA is available;
    # generic tags otherwise (this script only plots CSVs, no GPU work)
    try:
        import torch
        gpu = torch.cuda.get_device_name(0)
        single_tag, ddp_tag = f"1x {gpu}", f"2x {gpu}"
    except Exception:
        single_tag, ddp_tag = "1 GPU", "2 GPUs"

    def fig_fn():
        import matplotlib.pyplot as plt
        fig, (ax, ax2) = plt.subplots(
            2, 1, figsize=(9.5, 6.4), sharex=True,
            gridspec_kw={"height_ratios": [3, 1]}, facecolor=ps.BG)
        for a in (ax, ax2):
            a.set_facecolor(ps.BG)
        ax.plot(single, lw=1.0, color=ps.IMPL_COLORS["torch_eager"],
                alpha=0.9,
                label=f"single GPU ({single_tag}), final {single[-1]:.4f}")
        ax.plot(ddp, lw=1.2, color=ps.IMPL_COLORS["minitriton"],
                alpha=0.9, ls="--",
                label=f"DDP {ddp_tag} (NCCL), final {ddp[-1]:.4f}")
        ax.set_ylabel("cross entropy")
        ax.set_title(f"train_gpt fp32: single GPU vs DDP x2 "
                     f"(same init / batch / lr, {len(single)} steps)",
                     color=ps.TXT)
        ax.legend(facecolor=ps.PANEL, edgecolor=ps.EDGE)
        ps.style_ax(ax)
        ax2.plot(d, lw=0.9, color=ps.MUT)
        ax2.axhline(0.0, lw=0.7, color=ps.MUT, alpha=0.6)
        ax2.set_xlabel("step")
        ax2.set_ylabel("ddp - single")
        ax2.set_ylim(-max(0.05, mad * 1.2), max(0.05, mad * 1.2))
        ps.style_ax(ax2)
        ax2.text(0.01, 0.85,
                 f"max |diff| {mad:.4f}, mean |diff| {meand:.4f}",
                 transform=ax2.transAxes, fontsize=9, color=ps.SUB)
        fig.tight_layout()
        return fig

    base = OUT.with_suffix("")
    ps.render_themes(fig_fn, base, dpi=130)
    print(f"max |diff| {mad:.4f}, mean |diff| {meand:.4f}, {n} steps")


if __name__ == "__main__":
    main()
