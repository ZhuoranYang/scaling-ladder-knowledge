#!/usr/bin/env python
"""solve_tril benchmark: hand-written primitive vs naive W-IR + generic
passes vs fla triton (optional).

Ai = (I + A)^-1 per BTxBT strictly-lower block, A ~ [B, T, H, BT].
All sides timed with the same do_bench (CUDA events + L2 flush).

fla comparison is optional: set FLA_PATH to a flash-linear-attention
checkout (or install fla-core); skipped with a note when unavailable.

Effective traffic model (fp32 in/out): read the lower 10 of 16 blocks
(0.625x) + write the full block (1x); fla additionally zero-fills the
output first (extra 1x write) since its kernels only store the lower
triangle.

Re-run to regenerate the result tables (fp32, L2-flushed) on the local machine.
"""

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton.runtime.autotune import do_bench

SHAPES = [
    (8, 4096, 16, 64),
    (8, 8192, 16, 64),
    (16, 8192, 16, 64),
    (8, 16384, 32, 64),
    (1, 1024, 4, 64),
    (2, 2048, 8, 64),
    (8, 8192, 16, 32),
    (8, 8192, 16, 16),
]


@tl.kernel
def solve_tril_bench_kernel(a_ptr, ai_ptr, T, H, BT: tl.constexpr):
    pid_t = tl.program_id(0)
    pid_bh = tl.program_id(1)
    tl.solve_tril(a_ptr, ai_ptr, pid_t, pid_bh, T, H, BT=BT)


@tl.kernel
def solve_tril_wir_bench_kernel(a_ptr, ai_ptr, T, H, BT: tl.constexpr):
    pid_t = tl.program_id(0)
    pid_bh = tl.program_id(1)
    tl._wir_solve_tril(a_ptr, ai_ptr, pid_t, pid_bh, T, H, BT=BT)


def gen_input(B, T, H, BT, seed=0):
    rng = np.random.default_rng(seed)
    k = rng.standard_normal((B, H, T, 64)).astype(np.float32)
    k /= np.linalg.norm(k, axis=-1, keepdims=True)
    pad = (BT - T % BT) % BT
    k = np.pad(k, ((0, 0), (0, 0), (0, pad), (0, 0)))
    k = k.reshape(B, H, -1, BT, 64)
    A = np.matmul(k, k.transpose(0, 1, 2, 4, 3))
    A = np.tril(A, -1)
    return np.ascontiguousarray(
        A.reshape(B, H, -1, BT)[:, :, :T, :].transpose(0, 2, 1, 3))


def bench_tl(B, T, H, BT, kernel=solve_tril_bench_kernel):
    A = gen_input(B, T, H, BT)
    a_buf = tl.Buffer.from_numpy(A)
    ai_buf = tl.Buffer(A.size, tl.float32)
    NT = (T + BT - 1) // BT

    def fn():
        kernel[(NT, B * H)](a_buf, ai_buf, T, H, BT=BT)

    return do_bench(fn)


def try_fla():
    fla_path = os.environ.get("FLA_PATH")
    if fla_path:
        sys.path.insert(0, fla_path)
    try:
        import torch  # noqa: F401
        from fla.ops.utils.solve_tril import solve_tril as fla_solve_tril
        return fla_solve_tril
    except Exception as e:
        print(f"[note] fla unavailable ({type(e).__name__}), "
              f"skipping triton comparison; set FLA_PATH to enable")
        return None


def bench_fla(fla_solve_tril, B, T, H, BT):
    import torch
    A = torch.from_numpy(gen_input(B, T, H, BT)).cuda()
    return do_bench(lambda: fla_solve_tril(A))


def main():
    fla_solve_tril = try_fla()
    hdr = (f"{'B x T x H x BT':>20} | {'hand (us)':>9} | {'wir (us)':>9}"
           f" | {'wir/hand':>8} | {'GB/s':>6}"
           + (f" | {'fla (us)':>9} | {'wir/fla':>7}" if fla_solve_tril else ""))
    print(hdr)
    print("-" * len(hdr))
    ratios, ratios_fla = [], []
    for B, T, H, BT in SHAPES:
        ms = bench_tl(B, T, H, BT)
        ms_w = bench_tl(B, T, H, BT, kernel=solve_tril_wir_bench_kernel)
        nbytes = B * T * H * BT * 4 * (0.625 + 1.0)
        gbps = nbytes / (ms_w * 1e-3) / 1e9
        ratios.append(ms / ms_w)
        line = (f"{B:>2} x {T:<5} x {H:<2} x {BT:<2} | {ms*1e3:9.1f}"
                f" | {ms_w*1e3:9.1f} | {ms/ms_w:7.2f}x | {gbps:6.0f}")
        if fla_solve_tril:
            ms_fla = bench_fla(fla_solve_tril, B, T, H, BT)
            ratios_fla.append(ms_fla / ms_w)
            line += f" | {ms_fla*1e3:9.1f} | {ms_fla/ms_w:6.2f}x"
        print(line, flush=True)
    print(f"geomean wir/hand: {float(np.exp(np.mean(np.log(ratios)))):.2f}x")
    if ratios_fla:
        print(f"geomean wir vs fla triton: "
              f"{float(np.exp(np.mean(np.log(ratios_fla)))):.2f}x")


if __name__ == "__main__":
    main()
