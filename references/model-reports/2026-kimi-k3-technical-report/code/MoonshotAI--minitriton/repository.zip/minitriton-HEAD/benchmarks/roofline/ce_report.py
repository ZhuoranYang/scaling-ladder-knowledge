#!/usr/bin/env python
"""Cross-entropy split-reduction report.

The CE row kernel is single-pass for rows <= 2048 cols and routes wider
rows through a split reduction (per-segment online max/sum-exp partials +
one-block merge; SINGLE mode when the row is one segment), so any vocab
width works (tested to 262144 cols).

For each shape we time three implementations with the same do_bench
(CUDA events + L2 flush, warmup=5, rep=20, median):
- minitriton eager (tl.cross_entropy, mean reduction)
- the fused triton reference (inlined below; online
  max/sum loop, atomic mean; i64 row base so >2**31-element shapes are
  addressed correctly)
- torch eager (F.cross_entropy)

Acceptance: tl >= 0.95x triton-fused speed per shape
(tl_ms/triton_ms <= 1/0.95). Every implementation is numerically
verified against the torch eager reference before timing.

Memory scheduling for 65536x131072 (32.0 GiB per fp32 copy, most of the
card's HBM): the tl input copy is freed and the tl allocator pool drained
before the torch copy is made, and torch eager (which materializes the
full log-probs, 2x data) is timed through row-chunked F.cross_entropy
calls for that one shape (noted in the CSV).

Outputs: benchmarks/roofline/ce_report.csv (long format) + benchmarks/
roofline/ce_report.png/.svg (dark style) + console report with the verdict.

    CUDA_VISIBLE_DEVICES=1 python benchmarks/roofline/ce_report.py
"""

import csv
import gc
import sys
from datetime import datetime, timezone
from pathlib import Path

BENCH_DIR = Path(__file__).resolve().parent
REPO_ROOT = BENCH_DIR.parents[1]
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(BENCH_DIR))

import numpy as np

import minitriton as tl
from minitriton import do_bench

import torch
import torch.nn.functional as F
import triton
import triton.language as tll

sys.path.insert(0, str(Path(__file__).resolve().parent))
import plot_style as ps

torch.backends.cuda.matmul.allow_tf32 = False

CSV_PATH = BENCH_DIR / "ce_report.csv"
OUT_PATH = BENCH_DIR / "ce_report.png"
SVG_PATH = BENCH_DIR / "ce_report.svg"

SHAPES = [(r, c) for r in (4096, 65536)
          for c in (1024, 8192, 32000, 50257, 131072)]
# torch eager peak is ~2x the input (log_softmax materializes (N, C));
# above this many bytes per fp32 copy, time torch through row chunks.
_TORCH_CHUNK_BYTES = 24 * 2**30


def geomean(vals):
    return float(np.exp(np.mean(np.log(vals))))


def _tl_time(fn):
    fn()
    tl.synchronize()
    return do_bench(fn)


def _dev_time(fn):
    fn()
    torch.cuda.synchronize()
    return do_bench(fn)


def _tl_drain_pool():
    """Return every pooled free buffer to the driver (benchmark-only:
    lets the 32 GiB giant shape alternate between tl and torch copies)."""
    from minitriton.runtime import allocator as al
    pool = al._ALLOCATOR
    for lst in pool._free.values():
        for buf in lst:
            pool.reserved -= buf.nbytes
            buf.device.free(buf.ptr)
        lst.clear()


# ---------------------------------------------------------------------------
# triton fused reference (inlined; i64 row base so
# the >2**31-element shapes address correctly)
# ---------------------------------------------------------------------------

@triton.jit
def _tri_ce(X, T, OUT, rows, cols, BLOCK: tll.constexpr):
    row = tll.program_id(0)
    x_row = X + row.to(tll.int64) * cols
    m = -float("inf")
    s = 0.0
    for off in range(0, cols, BLOCK):
        idx = off + tll.arange(0, BLOCK)
        x = tll.load(x_row + idx, mask=idx < cols, other=-float("inf"))
        new_m = tll.maximum(m, tll.max(x, 0))
        s = s * tll.exp(m - new_m) + tll.sum(tll.exp(x - new_m), 0)
        m = new_m
    t = tll.load(T + row)
    xt = tll.load(x_row + t)
    tll.atomic_add(OUT, (m + tll.log(s) - xt) / rows)


def _torch_ce_chunked(xa, xt, chunk):
    """Mean F.cross_entropy over row chunks (same eager kernels; the full
    log-probs materialization does not fit for the 32 GiB shape)."""
    n = xa.shape[0]
    acc = torch.zeros((), device="cuda")
    for r0 in range(0, n, chunk):
        acc += F.cross_entropy(xa[r0:r0 + chunk], xt[r0:r0 + chunk],
                               reduction="sum")
    return acc / n


def bench_ce():
    rows = []
    for n, c in SHAPES:
        rng = np.random.default_rng(0)
        a = rng.standard_normal((n, c)).astype(np.float32)
        t = rng.integers(0, c, n)
        gib = a.nbytes / 2**30

        ta, tt = tl.tensor(a), tl.tensor(t)
        tl_ms = _tl_time(lambda: tl.cross_entropy(ta, tt))
        tl_val = float(tl.cross_entropy(ta, tt))
        del ta, tt
        gc.collect()
        _tl_drain_pool()

        xa = torch.from_numpy(a).cuda()
        xt = torch.from_numpy(t).cuda()
        out = torch.zeros((), device="cuda")

        def tri():
            out.zero_()
            _tri_ce[(n,)](xa, xt, out, n, c, BLOCK=1024, num_warps=4)
        tri_ms = _dev_time(tri)
        chunked = a.nbytes > _TORCH_CHUNK_BYTES
        if chunked:
            chunk = max(1, _TORCH_CHUNK_BYTES // (c * 4 * 2))
            tt_ms = _dev_time(lambda: _torch_ce_chunked(xa, xt, chunk))
            ref = float(_torch_ce_chunked(xa, xt, chunk))
        else:
            tt_ms = _dev_time(lambda: F.cross_entropy(xa, xt))
            ref = float(F.cross_entropy(xa, xt))
        assert abs(float(out) - ref) < 1e-3, \
            f"triton ce mismatch: {float(out)} vs {ref}"
        assert abs(tl_val - ref) < 1e-3, f"tl ce mismatch: {tl_val} vs {ref}"
        del xa, xt, out, a
        torch.cuda.empty_cache()

        bts = 4.0 * n * c + 8.0 * n
        note = ("split-reduction fwd; bytes=4*rows*cols+8*rows (minimal "
                "fused traffic)")
        if chunked:
            note += "; torch eager timed row-chunked (log-probs "
            note += "materialization exceeds the card's HBM)"
        rows.append(("cross_entropy", f"{n}x{c}", tl_ms, tri_ms, tt_ms,
                     bts, note))
        print(f"  {n}x{c} ({gib:.1f} GiB): tl {tl_ms:8.4f} ms | triton "
              f"{tri_ms:8.4f} | torch {tt_ms:8.4f} | tl/triton "
              f"{tl_ms / tri_ms:5.3f}x | tl/torch {tl_ms / tt_ms:5.3f}x")
    return rows


def main():
    ps.apply()
    print("== cross_entropy (split-reduction) ==")
    all_rows = bench_ce()

    # ---- CSV (long format, one row per case/shape/impl) ----
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    gpu = torch.cuda.get_device_name(0)
    cap = torch.cuda.get_device_capability(0)
    meta = [
        "MiniTriton cross_entropy split-reduction report "
        "(benchmarks/roofline/ce_report.py) -- split-reduction headroom case",
        f"generated_utc: {ts}",
        f"gpu: {gpu} (sm_{cap[0]}{cap[1]}), CUDA_VISIBLE_DEVICES=1",
        "timing: minitriton do_bench (CUDA events + L2 flush, warmup=5, "
        "rep=20, median) for all three impls",
        "impls: minitriton (tl.cross_entropy mean; single-pass <=2048 "
        "cols, split-reduction beyond) / triton (fused "
        "reference, i64 row base) / torch_eager (F.cross_entropy)",
        "acceptance: tl >= 0.95x triton speed per shape "
        "(tl_ms/triton_ms <= 1.0526)",
        "gbs = bytes/ms*1e-6 with bytes = 4*rows*cols+8*rows (minimal "
        "fused traffic, same for all impls)",
    ]
    with CSV_PATH.open("w", newline="") as f:
        for line in meta:
            f.write(f"# {line}\n")
        w = csv.writer(f)
        w.writerow(["case", "shape", "impl", "ms", "bytes", "gbs", "note"])
        for case, shape, tl_ms, tri_ms, tt_ms, bts, note in all_rows:
            for impl, ms in (("minitriton", tl_ms), ("triton", tri_ms),
                             ("torch_eager", tt_ms)):
                w.writerow([case, shape, impl, f"{ms:.6f}",
                            int(round(bts)), f"{bts / ms * 1e-6:.2f}", note])
    print(f"wrote {CSV_PATH} ({len(all_rows) * 3} rows)")

    # ---- summary + acceptance verdict ----
    ratios = [r[2] / r[3] for r in all_rows]  # tl_ms / triton_ms
    t_ratios = [r[2] / r[4] for r in all_rows]
    print("\nsummary:")
    for (case, shape, tl_ms, tri_ms, tt_ms, bts, note), r in \
            zip(all_rows, ratios):
        ok = r <= 1.0 / 0.95
        print(f"  {shape:>14}: tl/triton {r:5.3f}x time "
              f"({'OK' if ok else 'MISS'})")
    g = geomean(ratios)
    ok_all = all(r <= 1.0 / 0.95 for r in ratios)
    print(f"  geomean tl/triton {g:5.3f}x | geomean tl/torch "
          f"{geomean(t_ratios):5.3f}x")
    print(f"acceptance (every shape >= 0.95x triton speed): "
          f"{'ALL OK' if ok_all else 'MISS — see above'}")

    # ---- plot: left = ms per impl (log), right = speedup over tl ----
    import matplotlib.pyplot as plt
    labels = [r[1] for r in all_rows]
    x = np.arange(len(all_rows))
    tl_v = [r[2] for r in all_rows]
    tri_v = [r[3] for r in all_rows]
    tt_v = [r[4] for r in all_rows]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.5, 5.9),
                                   facecolor=ps.BG,
                                   gridspec_kw={"width_ratios": [1.35, 1.0]})
    for ax in (ax1, ax2):
        ax.set_facecolor(ps.BG)

    for ys, key, name, mk, lw, alpha, z in (
            (tt_v, "torch_eager", "torch eager", "s", 1.2, 0.75, 2),
            (tri_v, "triton", "triton fused ref", "^", 1.2, 0.85, 3),
            (tl_v, "minitriton", "minitriton (split-reduction)", "o", 2.5,
             1.0, 5)):
        color = ps.IMPL_COLORS[key]
        if key == ps.HERO:
            ax1.plot(x, ys, color=color, lw=lw * 3.0, alpha=0.15,
                     solid_capstyle="round", zorder=z - 1)
        ax1.plot(x, ys, color=color, lw=lw, alpha=alpha, marker=mk,
                 markersize=5.5, label=name, zorder=z,
                 markeredgecolor=ps.ROOF if key == ps.HERO else "none",
                 markeredgewidth=0.9)
    ax1.set_yscale("log")
    ax1.set_xticks(x)
    ax1.set_xticklabels(labels, rotation=38, ha="right", fontsize=9)
    ax1.set_ylabel("time (ms, median of do_bench, log)", fontsize=11)
    ps.style_ax(ax1)
    ax1.legend(loc="upper left", fontsize=9, facecolor=ps.PANEL,
               edgecolor=ps.EDGE, framealpha=1.0)

    tri_speed = [r[3] / r[2] for r in all_rows]  # triton_ms / tl_ms
    tt_speed = [r[4] / r[2] for r in all_rows]
    w = 0.38
    ax2.bar(x - w / 2, tri_speed, width=w, color=ps.IMPL_COLORS["triton"],
            alpha=0.85, label="triton fused ref / tl", zorder=3)
    ax2.bar(x + w / 2, tt_speed, width=w, color=ps.IMPL_COLORS["torch_eager"],
            alpha=0.75, label="torch eager / tl", zorder=3)
    for xi, v in zip(x - w / 2, tri_speed):
        ax2.text(xi, v + 0.04, f"{v:.2f}", ha="center", fontsize=8,
                 color=ps.SUB, zorder=4)
    ax2.axhline(1.0, color=ps.SUB, lw=1.0, ls="--", alpha=0.6, zorder=2)
    ax2.text(len(x) - 0.15, 1.03, "parity", fontsize=8, color=ps.MUT,
             ha="left")
    ax2.axhline(0.95, color=ps.IMPL_COLORS["minitriton"], lw=1.0, ls=":",
                alpha=0.8, zorder=2)
    ax2.text(len(x) - 0.15, 0.88, "0.95x acceptance", fontsize=8,
             color=ps.IMPL_COLORS["minitriton"], ha="left")
    ax2.set_xlim(-0.6, len(x) + 1.3)
    ax2.set_xticks(x)
    ax2.set_xticklabels(labels, rotation=38, ha="right", fontsize=9)
    ax2.set_ylabel("speedup over tl (higher = tl faster)", fontsize=11)
    ax2.set_ylim(0, max(tt_speed) * 1.14)
    ps.style_ax(ax2, minor=False)
    ax2.legend(loc="upper left", fontsize=9, facecolor=ps.PANEL,
               edgecolor=ps.EDGE, framealpha=1.0)

    ps.title_block(
        ax1, "cross_entropy split-reduction — tl vs triton vs torch",
        "cross-entropy · rows x cols (vocab) · same do_bench · "
        f"{gpu}")
    fig.tight_layout()
    ps.footnote(
        fig, "data: benchmarks/roofline/ce_report.csv · acceptance: tl >= 0.95x "
        "triton fused-ref speed every shape · tl: single-pass <=2048 "
        "cols, split-reduction (online segment max/sum + merge) beyond; "
        "torch at 65536x131072 timed row-chunked (card HBM limit)")
    ps.save(fig, OUT_PATH)
    ps.save(fig, SVG_PATH)


if __name__ == "__main__":
    main()
