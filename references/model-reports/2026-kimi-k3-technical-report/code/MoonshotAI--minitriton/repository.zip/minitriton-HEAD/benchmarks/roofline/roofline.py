#!/usr/bin/env python
"""Shared measurement/calibration library for the roofline generators.

Exports:
- measure_dram_bw(): torch big-tensor add (3 streams, n = 2^28 fp32),
  timed with the same do_bench as everything else
- measure_fp32_peak(): torch.mm 8192^3 (cuBLAS SGEMM) as the practical
  fp32 compute peak
- collect_attention(): fused causal flash-attention forward points
  (minitriton / torch eager / torch.compile / triton), extended from
  attention_report.py pieces

Imported by roofline_export.py, roofline_tensor_core.py and
roofline_solve_tril.py. The figures themselves are produced by
benchmarks/roofline/roofline_cuda_core.py (fp32) and
benchmarks/roofline/roofline_tensor_core.py (tf32/bf16); the legacy
single-figure plot that used to live here was superseded and removed.

Flash-attention arithmetic intensity: flops = 2*B*H*T^2*d (causal fwd,
halved from the full 4x -- pinned in accounting.py),
bytes = 16*B*H*T*d fp32 (Q,K,V,O)  =>  AI = T/8.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np

import minitriton as tl
from minitriton import do_bench, ops as tl_ops

import torch

from accounting import flash_attn_fwd_bytes, flash_attn_fwd_flops
from attention_report import tri_best, torch_unfused

torch.backends.cuda.matmul.allow_tf32 = False


def measure_dram_bw() -> float:
    """GB/s, measured with a 3-stream fp32 add on 2^28 elements (torch)."""
    n = 1 << 28
    x = torch.randn(n, device="cuda")
    y = torch.randn(n, device="cuda")
    fn = lambda: torch.add(x, y)
    fn()
    torch.cuda.synchronize()
    ms = do_bench(fn, warmup=3, rep=10)
    return 12.0 * n / ms * 1e-6


def measure_fp32_peak() -> float:
    """GFLOP/s, measured with cuBLAS SGEMM at 8192^3."""
    n = 8192
    a = torch.randn(n, n, device="cuda")
    b = torch.randn(n, n, device="cuda")
    fn = lambda: torch.mm(a, b)
    fn()
    torch.cuda.synchronize()
    ms = do_bench(fn, warmup=3, rep=10)
    return 2.0 * n**3 / ms * 1e-6


def collect_attention():
    """Flash-attention fwd points for the roofline (4 implementations).

    Returns dicts with the same keys as report.collect_results() entries.
    """
    results = []
    for B, H, T in [(8, 12, 256), (8, 12, 512), (8, 12, 1024), (4, 8, 2048)]:
        HD = 64
        rng = np.random.default_rng(0)
        qn, kn, vn = (rng.standard_normal((B, H, T, HD)).astype(np.float32)
                      for _ in range(3))
        scale = 1.0 / np.sqrt(HD)
        # minitriton fused
        tq, tk, tv = (tl.tensor(x) for x in (qn, kn, vn))
        with tl.no_grad():
            tl_ops.flash_attention_forward(tq, tk, tv, scale)
        tl_fn = lambda: tl_ops.flash_attention_forward(tq, tk, tv, scale)
        tl_fn()
        tl.synchronize()
        tl_ms = do_bench(tl_fn)
        # triton (mini-autotuned)
        qq, kk, vv = (torch.from_numpy(x).cuda() for x in (qn, kn, vn))
        tri_fn, tri_ms, _ = tri_best(qq, kk, vv, scale)
        # torch eager unfused
        mask = torch.triu(torch.full((T, T), -1e9, device="cuda"), 1)
        e_fn = lambda: torch_unfused(qq, kk, vv, scale, mask)
        e_fn()
        torch.cuda.synchronize()
        eager_ms = do_bench(e_fn)
        # torch.compile unfused (extra warmup for compilation)
        c_fn = torch.compile(torch_unfused)
        for _ in range(3):
            c_fn(qq, kk, vv, scale, mask)
        torch.cuda.synchronize()
        compile_ms = do_bench(lambda: c_fn(qq, kk, vv, scale, mask))
        flops = flash_attn_fwd_flops(B, H, T, HD)  # causal-halved
        bts = flash_attn_fwd_bytes(B, H, T, HD)    # Q,K,V,O fp32
        results.append({
            "kernel": "flash_attn", "shape": f"B{B}H{H}T{T}d{HD}",
            "flops": flops, "bytes": bts,
            "tl_ms": tl_ms, "eager_ms": eager_ms,
            "compile_ms": compile_ms, "triton_ms": tri_ms,
        })
        print(f"  flash_attn B{B}H{H}T{T}d{HD}: tl {tl_ms:.3f} ms, "
              f"eager {eager_ms:.3f}, compile {compile_ms:.3f}, "
              f"triton {tri_ms:.3f}")
    return results
