#!/usr/bin/env python
"""train_gpt convergence comparison: minitriton vs torch eager loss curves.

Same char-level GPT (same corpus/config/init/batch order/lr schedule),
both fp32 with allow_tf32=False. Trains both for --steps and overlays
the two loss curves; if the implementations are numerically equivalent,
the curves should track each other closely (not bit-identical: different
kernel orders, but same trend and endpoint band).

    CUDA_VISIBLE_DEVICES=2 python benchmarks/training/train_gpt_convergence.py \
        --steps 500

Outputs: assets/train_gpt_convergence.png/.svg +
assets/train_gpt_convergence{,.tl,.torch}.csv.
"""

import argparse
import importlib.util
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np

import minitriton as tl
from minitriton import nn
from minitriton import precision as _prec

import torch

from train_gpt_bench import ThGPT  # torch twin (mirrored init)

spec = importlib.util.spec_from_file_location(
    "train_gpt", Path(__file__).resolve().parents[2] / "examples"
    / "train_gpt.py")
tg = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tg)

OUT = Path(__file__).resolve().parents[2] / "assets" / "train_gpt_convergence"


def sync_init(tl_model, th_model):
    """Copy minitriton GPT weights into the torch twin (identical init).

    Mapping (both are nanoGPT-style, tied lm_head=wte on both sides):
    wte/wpe, per-block ln1, attn.c_attn->qkv, attn.c_proj->proj, ln2,
    fc->fc, proj->mlp_proj, ln_f.
    """
    def npw(p):
        return p.numpy()

    with torch.no_grad():
        th_model.wte.weight.copy_(torch.from_numpy(npw(tl_model.wte.weight)))
        th_model.wpe.weight.copy_(torch.from_numpy(npw(tl_model.wpe.weight)))
        for i, blk in enumerate(tl_model.blocks):
            tb = th_model.blocks[i]
            tb.ln1.weight.copy_(torch.from_numpy(npw(blk.ln1.weight)))
            tb.ln1.bias.copy_(torch.from_numpy(npw(blk.ln1.bias)))
            tb.qkv.weight.copy_(
                torch.from_numpy(npw(blk.attn.c_attn.weight)))
            tb.qkv.bias.copy_(torch.from_numpy(npw(blk.attn.c_attn.bias)))
            tb.proj.weight.copy_(
                torch.from_numpy(npw(blk.attn.c_proj.weight)))
            tb.proj.bias.copy_(torch.from_numpy(npw(blk.attn.c_proj.bias)))
            tb.ln2.weight.copy_(torch.from_numpy(npw(blk.ln2.weight)))
            tb.ln2.bias.copy_(torch.from_numpy(npw(blk.ln2.bias)))
            tb.fc.weight.copy_(torch.from_numpy(npw(blk.fc.weight)))
            tb.fc.bias.copy_(torch.from_numpy(npw(blk.fc.bias)))
            tb.mlp_proj.weight.copy_(torch.from_numpy(npw(blk.proj.weight)))
            tb.mlp_proj.bias.copy_(torch.from_numpy(npw(blk.proj.bias)))
        th_model.ln_f.weight.copy_(torch.from_numpy(npw(tl_model.ln_f.weight)))
        th_model.ln_f.bias.copy_(torch.from_numpy(npw(tl_model.ln_f.bias)))


def run_tl(cfg, data, steps, batch, lr, seed, model=None):
    rng = np.random.default_rng(seed)
    model = model or tg.GPT(cfg)
    opt = nn.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                   weight_decay=0.1)
    losses = []
    for step in range(steps):
        opt.lr = tg.lr_at(step, steps, lr)
        x, y = tg.get_batch(data, batch, cfg.block_size, rng)
        loss = model(tl.tensor(x), tl.tensor(y))
        model.zero_grad()
        loss.backward()
        nn.clip_grad_norm(model.parameters(), 1.0)
        opt.step()
        losses.append(loss.item())
    return losses


def run_torch(cfg, data, steps, batch, lr, seed, model=None):
    torch.backends.cuda.matmul.allow_tf32 = False
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    model = (model or ThGPT(cfg)).cuda()
    opt = torch.optim.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                            weight_decay=0.1, foreach=False)
    losses = []
    for step in range(steps):
        lr_t = tg.lr_at(step, steps, lr)
        for g in opt.param_groups:
            g["lr"] = lr_t
        x, y = tg.get_batch(data, batch, cfg.block_size, rng)
        xb = torch.from_numpy(x.astype(np.int64)).cuda()
        yb = torch.from_numpy(y.astype(np.int64)).cuda()
        loss = model(xb, yb)
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        losses.append(loss.item())
    return losses


def main():
    import os
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=100)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--block-size", type=int, default=256)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--n-layer", type=int, default=12)
    ap.add_argument("--n-head", type=int, default=12)
    ap.add_argument("--n-embd", type=int, default=768)
    ap.add_argument("--seed", type=int, default=1337)
    ap.add_argument("--tl-unfused-attn", action="store_true",
                    help="ablation: minitriton side uses unfused attention "
                         "(precise exp instead of fused ex2.approx)")
    ap.add_argument("--torch-tanh-gelu", action="store_true",
                    help="ablation: torch side uses tanh-approx gelu "
                         "(minitriton semantics) instead of exact erf")
    ap.add_argument("--side", choices=["both", "tl", "torch"],
                    default="both",
                    help="run one side only (for two-GPU parallel runs); "
                         "writes a per-side CSV that the combine step reads")
    args = ap.parse_args()

    if os.environ.get("REPLOT"):  # redraw from CSV, no training
        import csv as csvmod
        rows = [r for r in csvmod.reader(open(OUT.with_suffix(".csv")))
                if r and not r[0].startswith("#") and r[0] != "step"]
        tl_losses = [float(r[1]) for r in rows]
        th_losses = [float(r[2]) for r in rows]
        args.steps = len(rows)
        data, vocab, _ = tg.load_corpus(
            Path(__file__).resolve().parents[2] / "minitriton")
        plot_curves(tl_losses, th_losses, vocab, args.steps)
        return

    data, vocab, _ = tg.load_corpus(
        Path(__file__).resolve().parents[2] / "minitriton")
    cfg = tg.Cfg()
    cfg.vocab_size = vocab
    cfg.block_size = args.block_size
    cfg.n_layer = args.n_layer
    cfg.n_head = args.n_head
    cfg.n_embd = args.n_embd
    print(f"corpus {len(data)} chars, vocab {vocab}, "
          f"ln(vocab)={np.log(vocab):.2f}; steps={args.steps}")

    if args.side in ("both", "tl"):
        tl_model = tg.GPT(cfg)
        if args.tl_unfused_attn:
            for blk in tl_model.blocks:
                blk.attn.fused = False
            print("ablation: minitriton attention = unfused composite")
        th_model = ThGPT(cfg)
        sync_init(tl_model, th_model)  # identical init
        # persist torch-side init for a parallel --side torch process
        torch.save(th_model.state_dict(),
                   OUT.with_suffix(".init.pt"))
        t0 = time.perf_counter()
        tl_losses = run_tl(cfg, data, args.steps, args.batch_size, args.lr,
                           args.seed, model=tl_model)
        print(f"minitriton done in {time.perf_counter() - t0:.0f}s: "
              f"loss {tl_losses[0]:.3f} -> {tl_losses[-1]:.3f}")
        with OUT.with_suffix(".tl.csv").open("w") as f:
            f.write(f"# tl precision levers: "
                    f"{','.join(_prec.active()) or 'none (default path)'}\n")
            f.write("step,minitriton_loss\n")
            for i, a in enumerate(tl_losses):
                f.write(f"{i},{a:.6f}\n")
        print(f"wrote {OUT.with_suffix('.tl.csv')}")

    if args.torch_tanh_gelu:
        import torch.nn.functional as tF
        _orig_gelu = tF.gelu
        tF.gelu = lambda x: _orig_gelu(x, approximate="tanh")
        print("ablation: torch side gelu = tanh approximation")
    if args.side in ("both", "torch"):
        if args.side == "torch":
            # wait for the tl-side process to dump the shared init
            init_pt = OUT.with_suffix(".init.pt")
            for _ in range(120):
                if init_pt.exists():
                    break
                time.sleep(1)
            th_model = ThGPT(cfg)
            th_model.load_state_dict(torch.load(init_pt))
        t0 = time.perf_counter()
        th_losses = run_torch(cfg, data, args.steps, args.batch_size,
                              args.lr, args.seed, model=th_model)
        print(f"torch      done in {time.perf_counter() - t0:.0f}s: "
              f"loss {th_losses[0]:.3f} -> {th_losses[-1]:.3f}")
        with OUT.with_suffix(".torch.csv").open("w") as f:
            f.write("step,torch_loss\n")
            for i, b in enumerate(th_losses):
                f.write(f"{i},{b:.6f}\n")
        print(f"wrote {OUT.with_suffix('.torch.csv')}")

    # combine (only possible when both sides' CSVs exist)
    import csv as csvmod
    tl_csv, th_csv = (OUT.with_suffix(".tl.csv"),
                      OUT.with_suffix(".torch.csv"))
    if not (tl_csv.exists() and th_csv.exists()):
        print("one side done; run the other side (or REPLOT=1 once both "
              "CSVs exist) to combine + plot")
        return
    tl_rows = [r for r in csvmod.reader(open(tl_csv)) if r
               and not r[0].startswith("#") and r[0] != "step"]
    th_rows = [r for r in csvmod.reader(open(th_csv)) if r
               and not r[0].startswith("#") and r[0] != "step"]
    tl_losses = [float(r[1]) for r in tl_rows]
    th_losses = [float(r[1]) for r in th_rows]
    csv_path = OUT.with_suffix(".csv")
    with csv_path.open("w") as f:
        f.write("# train_gpt convergence: minitriton vs torch eager "
                "(identical init/batches/lr schedule, fp32)\n")
        f.write(f"# config: {args.n_layer}L/{args.n_head}H/{args.n_embd}d, "
                f"block {args.block_size}, batch {args.batch_size}, "
                f"lr {args.lr}, seed {args.seed}\n")
        f.write(f"# tl precision levers: "
                f"{','.join(_prec.active()) or 'none (default path)'}\n")
        f.write("step,minitriton_loss,torch_loss\n")
        for i, (a, b) in enumerate(zip(tl_losses, th_losses)):
            f.write(f"{i},{a:.6f},{b:.6f}\n")
    print(f"wrote {csv_path}")
    plot_curves(tl_losses, th_losses, vocab, len(tl_losses))


def plot_curves(tl_losses, th_losses, vocab, nsteps):
    import matplotlib
    matplotlib.use("Agg")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "roofline"))
    import plot_style as ps

    def fig_fn():
        fig, ax = ps.new_fig((10.5, 6.0))
        steps = np.arange(nsteps)
        ax.plot(steps, th_losses, color=ps.IMPL_COLORS["torch_eager"],
                lw=1.4, alpha=0.85, label="torch eager", zorder=3)
        ax.plot(steps, tl_losses, color=ps.IMPL_COLORS["minitriton"],
                lw=1.8, alpha=0.95, label="minitriton", zorder=4)
        ax.axhline(np.log(vocab), color=ps.MUT, lw=1.0, ls="--", alpha=0.7,
                   zorder=2)
        ax.annotate(f"ln(vocab) = {np.log(vocab):.2f}",
                    (nsteps * 0.02, np.log(vocab) * 1.02),
                    fontsize=8.5, color=ps.MUT)
        ax.set_xlabel("step", fontsize=11.5)
        ax.set_ylabel("training loss", fontsize=11.5)
        ps.title_block(ax,
                       "train_gpt convergence — minitriton vs torch eager")
        ps.style_ax(ax, minor=False)
        ax.legend(fontsize=9, loc="upper right", framealpha=0.9)
        fig.tight_layout()
        return fig

    ps.render_themes(fig_fn, OUT.with_suffix(""))

    tail = slice(-100, None)
    gap = float(np.mean(tl_losses[tail]) - np.mean(th_losses[tail]))
    print(f"final-100-step mean loss: minitriton "
          f"{np.mean(tl_losses[tail]):.4f} vs torch "
          f"{np.mean(th_losses[tail]):.4f} (gap {gap:+.4f})")


if __name__ == "__main__":
    main()
