#!/usr/bin/env python
"""Benchmark report: minitriton vs torch eager vs torch.compile
vs triton.

matmul / fused softmax / vecadd, several shapes each, all implementations
timed with the same do_bench (CUDA events + L2 flush). Prints per-shape
tables and geometric-mean ratios (minitriton vs torch eager, vs
torch.compile, vs triton).

The triton matmul column uses a tutorial-style tl.dot kernel with
input_precision="ieee" (same fp32 semantics; a tf32 row is printed
separately as relaxed-precision reference only).

torch.compile uses the default mode (torch + CUDA required).

Arithmetic-intensity conventions (also used by benchmarks/roofline/roofline.py):
- matmul:  FLOPs = 2*M*N*K;            bytes = 4*(M*K + K*N + M*N)
- softmax: FLOPs ~ 5*rows*cols         (max-cmp, sub, exp, sum-add, div per
           element, exp counted as 1); bytes = 2*4*rows*cols (read + write)
- vecadd:  FLOPs = n;                  bytes = 3*4*n
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import do_bench

try:
    import torch
    HAS_TORCH_CUDA = torch.cuda.is_available()
except ImportError:
    torch = None
    HAS_TORCH_CUDA = False

try:
    import triton
    import triton.language as tlx
    HAS_TRITON = HAS_TORCH_CUDA
except ImportError:
    triton = None
    tlx = None
    HAS_TRITON = False


# ---------------------------------------------------------------------------
# kernels (autotuned)
# ---------------------------------------------------------------------------

# (BM, BN, BK, TM, TN, num_warps, STAGES) candidates for the
# pipelined 2D-thread-tile matmul; per-shape EVEN_* flags and GROUP_M are
# filled in below. Invalid combos (thread-grid mismatch, smem overflow,
# staging-chunk indivisibility) fail fast in tl.matmul_tile and the
# autotuner skips them.
_MM_TILES = [
    (128, 64, 32, 8, 8, 4, 2),
    (128, 128, 16, 8, 8, 8, 2),
    (64, 128, 32, 8, 8, 8, 2),
    (128, 64, 16, 8, 8, 4, 2),
    (64, 64, 32, 4, 4, 8, 2),
    (64, 64, 32, 4, 4, 8, 3),
    (64, 64, 16, 4, 4, 8, 2),
    (32, 128, 32, 4, 8, 4, 2),
]


def _mm_configs(M: int, N: int, K: int) -> list:
    cfgs = []
    for bm, bn, bk, tm, tn, w, stages in _MM_TILES:
        for gm in (4, 8, 16):
            cfgs.append(tl.Config(
                {"BM": bm, "BN": bn, "BK": bk, "TM": tm, "TN": tn,
                 "STAGES": stages, "GROUP_M": gm,
                 "EVEN_MK": M % bm == 0 and K % bk == 0,
                 "EVEN_KN": K % bk == 0 and N % bn == 0,
                 "EVEN_MN": M % bm == 0 and N % bn == 0,
                 "EVEN_K": K % bk == 0},
                num_warps=w))
    return cfgs


@tl.kernel
def mm_kernel(a_ptr, b_ptr, c_ptr, M, N, K,
              BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
              TM: tl.constexpr, TN: tl.constexpr,
              STAGES: tl.constexpr, GROUP_M: tl.constexpr,
              EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
              EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr):
    # 1D grid + grouped rasterization (triton-style super-grouping)
    pid = tl.program_id(0)
    num_pid_m = (M + BM - 1) // BM
    num_pid_n = (N + BN - 1) // BN
    num_in_group = GROUP_M * num_pid_n
    group_id = pid // num_in_group
    first_pid_m = group_id * GROUP_M
    group_size = tl.where(num_pid_m - first_pid_m < GROUP_M,
                          num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size)
    pid_n = (pid % num_in_group) // group_size
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * N + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                             EVEN_K=EVEN_K, VEC=False,
                             a_mask=am, b_mask=bn)
    if EVEN_MN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc, mask=cm)


# Per-shape autotuners: the EVEN_* divisibility flags depend on both the
# shape and the tile sizes, so the config list is built per (M, N, K).
_mm_tuners: dict = {}


def _mm_tuner(M: int, N: int, K: int):
    from minitriton.runtime.autotune import Autotuner
    key = (M, N, K)
    tuner = _mm_tuners.get(key)
    if tuner is None:
        tuner = Autotuner(mm_kernel, _mm_configs(M, N, K), ["M", "N", "K"])
        _mm_tuners[key] = tuner
    return tuner


@tl.autotune(
    configs=[tl.Config({}, num_warps=w) for w in (2, 4, 8, 16)],
    key=["n_cols"],
)
@tl.kernel
def sm_kernel(x_ptr, out_ptr, n_cols, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    mask = offs < n_cols
    x = tl.load(x_ptr + row * n_cols + offs, mask=mask, other=float("-inf"))
    x_max = tl.max(x)
    e = tl.exp(x - x_max)
    s = tl.sum(e)
    tl.store(out_ptr + row * n_cols + offs, e / s, mask=mask)


@tl.autotune(
    configs=[
        tl.Config({"BLOCK": 512}, num_warps=4),
        tl.Config({"BLOCK": 1024}, num_warps=4),
        tl.Config({"BLOCK": 1024}, num_warps=8),
        tl.Config({"BLOCK": 2048}, num_warps=8),
    ],
    key=["N"],
)
@tl.kernel
def va_kernel(x_ptr, y_ptr, out_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < N
    x = tl.load(x_ptr + offs, mask=mask)
    y = tl.load(y_ptr + offs, mask=mask)
    tl.store(out_ptr + offs, x + y, mask=mask)


def sm_block(n_cols: int) -> int:
    # multiple of 512 (max num_threads) and >= n_cols
    return max(512, ((n_cols + 511) // 512) * 512)


# ---------------------------------------------------------------------------
# triton baselines (same shapes, timed with the same do_bench)
# ---------------------------------------------------------------------------

if HAS_TRITON:
    @triton.jit
    def tri_mm_kernel(a_ptr, b_ptr, c_ptr, M, N, K,
                      BM: tlx.constexpr, BN: tlx.constexpr, BK: tlx.constexpr,
                      PRECISION: tlx.constexpr):
        pid_m = tlx.program_id(0)
        pid_n = tlx.program_id(1)
        offs_m = pid_m * BM + tlx.arange(0, BM)
        offs_n = pid_n * BN + tlx.arange(0, BN)
        offs_k = tlx.arange(0, BK)
        acc = tlx.zeros((BM, BN), dtype=tlx.float32)
        a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
        b_ptrs = b_ptr + offs_k[:, None] * N + offs_n[None, :]
        for k in range(0, K, BK):
            a = tlx.load(a_ptrs)
            b = tlx.load(b_ptrs)
            acc = tlx.dot(a, b, acc, input_precision=PRECISION)
            a_ptrs += BK
            b_ptrs += BK * N
        tlx.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)

    @triton.jit
    def tri_sm_kernel(x_ptr, out_ptr, n_cols, BLOCK: tlx.constexpr):
        row = tlx.program_id(0)
        offs = tlx.arange(0, BLOCK)
        mask = offs < n_cols
        x = tlx.load(x_ptr + row * n_cols + offs, mask=mask,
                     other=float("-inf"))
        x_max = tlx.max(x, axis=0)
        e = tlx.exp(x - x_max)
        s = tlx.sum(e, axis=0)
        tlx.store(out_ptr + row * n_cols + offs, e / s, mask=mask)

    @triton.jit
    def tri_va_kernel(x_ptr, y_ptr, out_ptr, N, BLOCK: tlx.constexpr):
        pid = tlx.program_id(0)
        offs = pid * BLOCK + tlx.arange(0, BLOCK)
        mask = offs < N
        x = tlx.load(x_ptr + offs, mask=mask)
        y = tlx.load(y_ptr + offs, mask=mask)
        tlx.store(out_ptr + offs, x + y, mask=mask)


# (BM, BN, BK, num_warps) sweep for the triton matmul baseline; tuned per
# shape with our do_bench (same timing as everything else).
_TRI_MM_CONFIGS = [
    (64, 64, 32, 4), (32, 128, 32, 4), (128, 64, 32, 4), (64, 128, 32, 4),
    (128, 128, 32, 8), (64, 64, 64, 4), (128, 128, 16, 8),
]


def _triton_time(fn) -> float:
    fn()
    torch.cuda.synchronize()
    return do_bench(fn)


def tri_matmul(ta, tb, tc, M, N, K, precision: str) -> float:
    """Best-of-sweep triton matmul time (ms). Shapes must be divisible."""
    best = float("inf")
    for BM, BN, BK, w in _TRI_MM_CONFIGS:
        if M % BM or N % BN or K % BK:
            continue
        grid = (M // BM, N // BN)
        fn = lambda: tri_mm_kernel[grid](ta, tb, tc, M, N, K, BM=BM, BN=BN,
                                         BK=BK, PRECISION=precision,
                                         num_warps=w)
        try:
            best = min(best, _triton_time(fn))
        except Exception:
            continue  # config out of resources
    return best


def tri_softmax(tx, tout, rows, cols) -> float:
    block = triton.next_power_of_2(cols)
    best = float("inf")
    for w in (1, 2, 4, 8, 16):
        if w * 32 > block:
            continue
        fn = lambda: tri_sm_kernel[(rows,)](tx, tout, cols, BLOCK=block,
                                            num_warps=w)
        best = min(best, _triton_time(fn))
    return best


def tri_vecadd(tx, ty, tout, n) -> float:
    best = float("inf")
    for block, w in ((512, 4), (1024, 4), (1024, 8), (2048, 8)):
        grid = ((n + block - 1) // block,)
        fn = lambda: tri_va_kernel[grid](tx, ty, tout, n, BLOCK=block,
                                         num_warps=w)
        best = min(best, _triton_time(fn))
    return best


# ---------------------------------------------------------------------------
# measurements
# ---------------------------------------------------------------------------

def _torch_baselines(make_fn):
    """(eager_ms, compile_ms) for a zero-arg torch callable factory."""
    fn = make_fn()
    fn()
    torch.cuda.synchronize()
    e_ms = do_bench(fn)
    cfn = torch.compile(make_fn())
    cfn()
    torch.cuda.synchronize()
    c_ms = do_bench(cfn)
    return e_ms, c_ms


def bench_matmul(n: int):
    M = N = K = n
    rng = np.random.default_rng(0)
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)
    da, db = tl.Buffer.from_numpy(a), tl.Buffer.from_numpy(b)
    dc = tl.Buffer(M * N, tl.float32)
    grid = lambda args: (((args["M"] + args["BM"] - 1) // args["BM"])
                         * ((args["N"] + args["BN"] - 1) // args["BN"]),)

    def tl_fn():
        tuner = _mm_tuner(M, N, K)
        tuner.launch(mm_kernel, grid, (da, db, dc, M, N, K), None,
                     {"BM": 0, "BN": 0, "BK": 0, "TM": 0, "TN": 0,
                      "STAGES": 0, "GROUP_M": 0, "EVEN_MK": False,
                      "EVEN_KN": False, "EVEN_MN": False, "EVEN_K": False})

    tl_fn()  # trigger autotune + compile
    tl.synchronize()
    ref = a @ b
    err = float(np.max(np.abs(dc.to_numpy().reshape(M, N) - ref)) / np.sqrt(K))
    assert err < 1e-4, f"matmul wrong: {err}"
    tl_ms = do_bench(tl_fn)

    ta = torch.from_numpy(a).cuda()
    tb = torch.from_numpy(b).cuda()
    torch.backends.cuda.matmul.allow_tf32 = False
    e_ms, c_ms = _torch_baselines(lambda: (lambda: torch.mm(ta, tb)))

    tr_ms = tf32_ms = float("nan")
    if HAS_TRITON:
        tc = torch.empty(M, N, device="cuda")
        tr_ms = tri_matmul(ta, tb, tc, M, N, K, "ieee")
        err_t = float((tc - ta @ tb).abs().max() / np.sqrt(K))
        assert err_t < 1e-4, f"triton matmul wrong: {err_t}"
        tf32_ms = tri_matmul(ta, tb, tc, M, N, K, "tf32")

    return {
        "kernel": "matmul", "shape": f"{n}^3",
        "tl_ms": tl_ms, "eager_ms": e_ms, "compile_ms": c_ms,
        "triton_ms": tr_ms, "triton_tf32_ms": tf32_ms,
        "flops": 2.0 * M * N * K,
        "bytes": 4.0 * (M * K + K * N + M * N),
    }


def bench_softmax(rows: int, cols: int):
    rng = np.random.default_rng(0)
    x = rng.standard_normal((rows, cols)).astype(np.float32)
    dx = tl.Buffer.from_numpy(x)
    dout = tl.Buffer(rows * cols, tl.float32)
    block = sm_block(cols)

    def tl_fn():
        sm_kernel[(rows,)](dx, dout, cols, BLOCK=block)

    tl_fn()
    tl.synchronize()
    z = x - x.max(axis=1, keepdims=True)
    ref = np.exp(z) / np.exp(z).sum(axis=1, keepdims=True)
    err = float(np.max(np.abs(dout.to_numpy().reshape(rows, cols) - ref)))
    assert err < 1e-5, f"softmax wrong: {err}"
    tl_ms = do_bench(tl_fn)

    tx = torch.from_numpy(x).cuda()
    e_ms, c_ms = _torch_baselines(lambda: (lambda: torch.softmax(tx, dim=1)))

    tr_ms = float("nan")
    if HAS_TRITON:
        tout = torch.empty_like(tx)
        tr_ms = tri_softmax(tx, tout, rows, cols)

    return {
        "kernel": "softmax", "shape": f"{rows}x{cols}",
        "tl_ms": tl_ms, "eager_ms": e_ms, "compile_ms": c_ms,
        "triton_ms": tr_ms,
        "flops": 5.0 * rows * cols,
        "bytes": 8.0 * rows * cols,
    }


def bench_vecadd(n: int):
    rng = np.random.default_rng(0)
    x = rng.random(n, dtype=np.float32)
    y = rng.random(n, dtype=np.float32)
    dx, dy = tl.Buffer.from_numpy(x), tl.Buffer.from_numpy(y)
    dout = tl.Buffer(n, tl.float32)
    grid = lambda args: ((args["N"] + args["BLOCK"] - 1) // args["BLOCK"],)

    def tl_fn():
        va_kernel[grid](dx, dy, dout, n, BLOCK=0)

    tl_fn()
    tl.synchronize()
    err = float(np.max(np.abs(dout.to_numpy() - (x + y))))
    assert err < 1e-6, f"vecadd wrong: {err}"
    tl_ms = do_bench(tl_fn)

    tx = torch.from_numpy(x).cuda()
    ty = torch.from_numpy(y).cuda()
    e_ms, c_ms = _torch_baselines(lambda: (lambda: tx + ty))

    tr_ms = float("nan")
    if HAS_TRITON:
        tout = torch.empty_like(tx)
        tr_ms = tri_vecadd(tx, ty, tout, n)

    return {
        "kernel": "vecadd", "shape": f"n={n >> 20}M",
        "tl_ms": tl_ms, "eager_ms": e_ms, "compile_ms": c_ms,
        "triton_ms": tr_ms,
        "flops": float(n),
        "bytes": 12.0 * n,
    }


def geomean(vals):
    return float(np.exp(np.mean(np.log(vals))))


def collect_results() -> list[dict]:
    results = []
    for n in (512, 1024, 2048, 4096):
        results.append(bench_matmul(n))
    for rows, cols in ((1024, 1024), (65536, 1024), (1048576, 1024),
                       (4096, 4096)):
        results.append(bench_softmax(rows, cols))
    for n in (1 << 20, 1 << 24, 1 << 27):
        results.append(bench_vecadd(n))
    return results


def _print_table(title: str, rows: list[dict], unit: str):
    print(f"== {title} ==")
    print(f"{'shape':>14} | {'tl ms':>9} | {'eager ms':>9} | {'compile ms':>10} | "
          f"{'triton ms':>9} | "
          f"{'tl ' + unit:>11} | {'eager ' + unit:>11} | {'compile ' + unit:>13} | "
          f"{'triton ' + unit:>12} | "
          f"{'r(eager)':>8} | {'r(compile)':>10} | {'r(triton)':>9}")
    re_, rc, rt = [], [], []
    for r in rows:
        tl_tp = r["tl_tp"]
        e_tp = r["e_tp"]
        c_tp = r["c_tp"]
        t_tp = r["t_tp"]
        re_.append(r["eager_ms"] / r["tl_ms"])
        rc.append(r["compile_ms"] / r["tl_ms"])
        rt.append(r["triton_ms"] / r["tl_ms"])
        print(f"{r['shape']:>14} | {r['tl_ms']:9.3f} | {r['eager_ms']:9.3f} | "
              f"{r['compile_ms']:10.3f} | {r['triton_ms']:9.3f} | "
              f"{tl_tp:11.2f} | {e_tp:11.2f} | "
              f"{c_tp:13.2f} | {t_tp:12.2f} | "
              f"{re_[-1]:8.2f} | {rc[-1]:10.2f} | {rt[-1]:9.2f}")
    print(f"{'geomean':>14} | {'':>9} | {'':>9} | {'':>10} | {'':>9} | "
          f"{'':>11} | {'':>11} | {'':>13} | {'':>12} | "
          f"{geomean(re_):8.2f} | {geomean(rc):10.2f} | {geomean(rt):9.2f}")
    print()


def _print_tf32_ref(rows: list[dict]):
    """One-line-per-shape triton tf32 reference (relaxed precision; not part
    of the same-precision comparison)."""
    if not HAS_TRITON:
        return
    print("== triton matmul with input_precision='tf32' "
          "(reference only, relaxed precision) ==")
    for r in rows:
        tf32_tp = r["flops"] / r["triton_tf32_ms"] * 1e-9
        print(f"{r['shape']:>14} | {r['triton_tf32_ms']:9.3f} ms | "
              f"{tf32_tp:8.2f} TF/s | vs cuBLAS fp32 eager: "
              f"{r['eager_ms'] / r['triton_tf32_ms']:5.2f}x")
    print()


def _with_tp(rows: list[dict], fn) -> list[dict]:
    out = []
    for r in rows:
        tr_ms = r.get("triton_ms", float("nan"))
        out.append({**r,
                    "tl_tp": fn(r, r["tl_ms"]),
                    "e_tp": fn(r, r["eager_ms"]),
                    "c_tp": fn(r, r["compile_ms"]),
                    "t_tp": fn(r, tr_ms)})
    return out


def main():
    if HAS_TORCH_CUDA:
        cap = torch.cuda.get_device_capability(0)
        device = f"{torch.cuda.get_device_name(0)} (sm_{cap[0]}{cap[1]})"
    else:
        device = "cuda"
    print(f"device: {device}, fp32; torch baseline: "
          f"{'CUDA ' + torch.__version__ if HAS_TORCH_CUDA else 'numpy (torch.cuda unavailable)'}")
    print()
    results = collect_results()
    mm_rows = [r for r in results if r["kernel"] == "matmul"]
    _print_table("matmul (C = A @ B, fp32), throughput in TFLOP/s",
                 _with_tp(mm_rows,
                          lambda r, ms: r["flops"] / ms * 1e-9), "TF/s")
    _print_tf32_ref(mm_rows)
    _print_table("fused softmax (row-wise, fp32), bandwidth in GB/s",
                 _with_tp([r for r in results if r["kernel"] == "softmax"],
                          lambda r, ms: r["bytes"] / ms * 1e-6), "GB/s")
    _print_table("vecadd (fp32), bandwidth in GB/s",
                 _with_tp([r for r in results if r["kernel"] == "vecadd"],
                          lambda r, ms: r["bytes"] / ms * 1e-6), "GB/s")


if __name__ == "__main__":
    main()
