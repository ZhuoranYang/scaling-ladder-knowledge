"""Shared FLOPs/bytes accounting for the roofline benchmark scripts.

Pure python (no torch, no numpy) so the test gate can import it
(tests/test_benchmark_accounting.py) and pin the conventions: any drift
between what the scripts measure and what they claim to count fails CI.

Conventions (identical to the figure scripts' headers and CSV notes):

- matmul (fwd):     flops = 2*M*N*K;             bytes = 4*(M*K + K*N + M*N)
- softmax (fwd):    flops ~= 5*rows*cols;        bytes = 8*rows*cols
- vecadd:           flops = n;                   bytes = 12*n
- flash_attn (causal fwd): flops = 2*B*H*T^2*d (halved from the full 4x
  for causal masking); bytes = 16*B*H*T*d (Q,K,V,O fp32) => AI = T/8
- gpt50m e2e train step (fwd+bwd):
      flops = 6*n_params*(B*T) + 6*n_layer*B*T^2*n_embd
    6ND: matmul fwd + dgrad + wgrad. Attention QK^T/PV per layer: causal
    fwd 2*B*T^2*n_embd (halved from 4, same convention as the flash
    rows), x3 for fwd+bwd = 6*B*T^2*n_embd per layer. NOTE the layer
    factor is n_layer, NOT n_head -- the two coincide (10) for gpt50m,
    which let an H-for-L substitution pass unnoticed.
      bytes = 3*n_params*4 (weights: fwd read + bwd read + grad write)
            + ACT_COEF*n_layer*B*T*n_embd*4 (activation heuristic;
              ACT_COEF=7 = midpoint of the empirical 6..8 tensor
              move-sets per layer per step; understates the exact
              op-level minimal sum -- every consumer shares the same
              ledger, so relative positions are unaffected)
"""

ACT_COEF = 7.0


def flash_attn_fwd_flops(B: int, H: int, T: int, d: int) -> float:
    """Causal forward FLOPs (halved from the full 4*B*H*T^2*d)."""
    return 2.0 * B * H * T * T * d


def flash_attn_fwd_bytes(B: int, H: int, T: int, d: int,
                         dtype_bytes: int = 4) -> float:
    """Q,K,V,O traffic."""
    return 4.0 * dtype_bytes * B * H * T * d


def gpt_step_flops(n_params: float, n_layer: int, batch: int, block: int,
                   n_embd: int) -> float:
    """fwd+bwd step FLOPs: 6ND matmul rule + causal attention term."""
    return (6.0 * n_params * batch * block
            + 6.0 * n_layer * batch * block * block * n_embd)


def gpt_step_bytes(n_params: float, n_layer: int, batch: int, block: int,
                   n_embd: int) -> float:
    """3 weight passes + ACT_COEF activation heuristic."""
    return (3.0 * n_params * 4
            + ACT_COEF * n_layer * batch * block * n_embd * 4)
