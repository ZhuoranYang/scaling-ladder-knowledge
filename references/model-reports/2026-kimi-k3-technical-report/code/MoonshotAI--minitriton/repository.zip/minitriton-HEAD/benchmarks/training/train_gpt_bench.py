#!/usr/bin/env python
"""train_gpt throughput comparison: minitriton eager vs torch
eager on the SAME char-level GPT (same corpus/config/batch), same
machine, same steps. The acceptance gate is >= 70% of torch
eager tokens/s.

    CUDA_VISIBLE_DEVICES=1 python benchmarks/training/train_gpt_bench.py --steps 300

torch runs with fp32 + allow_tf32=False (same precision semantics). The
torch model mirrors the minitriton one layer-for-layer with the same
init distribution (same seeds and stds; the draws themselves differ);
attention is explicit eager math (optionally SDPA via --torch-sdpa for
a stronger torch baseline).
"""

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import nn

import torch
import torch.nn.functional as tF

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "examples"))
import importlib.util

spec = importlib.util.spec_from_file_location(
    "train_gpt", Path(__file__).resolve().parents[2] / "examples"
    / "train_gpt.py")
tg = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tg)


# ---------------------------------------------------------------------------
# torch twin of examples/train_gpt.py's GPT
# ---------------------------------------------------------------------------

class ThBlock(torch.nn.Module):
    def __init__(self, d, h, sdpa=False):
        super().__init__()
        self.ln1 = torch.nn.LayerNorm(d)
        self.qkv = torch.nn.Linear(d, 3 * d)
        self.proj = torch.nn.Linear(d, d)
        self.ln2 = torch.nn.LayerNorm(d)
        self.fc = torch.nn.Linear(d, 4 * d)
        self.mlp_proj = torch.nn.Linear(4 * d, d)
        self.h = h
        self.sdpa = sdpa

    def forward(self, x):
        b, t, d = x.shape
        hd = d // self.h
        ln = self.ln1(x)
        q, k, v = self.qkv(ln).chunk(3, dim=-1)
        q = q.reshape(b, t, self.h, hd).transpose(1, 2)
        k = k.reshape(b, t, self.h, hd).transpose(1, 2)
        v = v.reshape(b, t, self.h, hd).transpose(1, 2)
        if self.sdpa:
            y = tF.scaled_dot_product_attention(q, k, v, is_causal=True)
        else:
            s = (q @ k.transpose(-2, -1)) * (1.0 / np.sqrt(hd))
            s = s + torch.triu(torch.full((t, t), -1e9, device=x.device), 1)
            y = torch.softmax(s, dim=-1) @ v
        x = x + self.proj(y.transpose(1, 2).reshape(b, t, d))
        return x + self.mlp_proj(tF.gelu(self.fc(self.ln2(x))))


class ThGPT(torch.nn.Module):
    def __init__(self, cfg, sdpa=False):
        super().__init__()
        self.wte = torch.nn.Embedding(cfg.vocab_size, cfg.n_embd)
        self.wpe = torch.nn.Embedding(cfg.block_size, cfg.n_embd)
        self.blocks = torch.nn.ModuleList(
            [ThBlock(cfg.n_embd, cfg.n_head, sdpa)
             for _ in range(cfg.n_layer)])
        self.ln_f = torch.nn.LayerNorm(cfg.n_embd)
        self.cfg = cfg
        # mirror the minitriton init (N(0, 0.02); scaled projections) so
        # the two sides train identically, not just run at the same speed
        with torch.no_grad():
            for m in self.modules():
                if isinstance(m, torch.nn.Linear):
                    m.weight.normal_(0.0, 0.02)
                    if m.bias is not None:
                        m.bias.zero_()
                if isinstance(m, torch.nn.Embedding):
                    m.weight.normal_(0.0, 0.02)
            for blk in self.blocks:
                blk.proj.weight.normal_(
                    0.0, 0.02 / (2 * cfg.n_layer) ** 0.5)
                blk.mlp_proj.weight.normal_(
                    0.0, 0.02 / (2 * cfg.n_layer) ** 0.5)

    def forward(self, idx, targets):
        t = idx.shape[1]
        pos = torch.arange(t, device=idx.device)
        x = self.wte(idx) + self.wpe(pos)
        for blk in self.blocks:
            x = blk(x)
        logits = self.ln_f(x) @ self.wte.weight.t()
        return tF.cross_entropy(
            logits.reshape(-1, logits.shape[-1]), targets.reshape(-1))


def run_tl(cfg, data, steps, batch, lr, seed):
    rng = np.random.default_rng(seed)
    model = tg.GPT(cfg)
    opt = nn.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                   weight_decay=0.1)
    tokens = 0
    t0 = time.perf_counter()
    for step in range(steps):
        opt.lr = tg.lr_at(step, steps, lr)
        x, y = tg.get_batch(data, batch, cfg.block_size, rng)
        loss = model(tl.tensor(x), tl.tensor(y))
        model.zero_grad()
        loss.backward()
        nn.clip_grad_norm(model.parameters(), 1.0)
        opt.step()
        if step == steps // 3:  # steady-state window: last 2/3
            t0 = time.perf_counter()
            tokens = 0
        tokens += batch * cfg.block_size
    tl.synchronize()
    dt = time.perf_counter() - t0
    return tokens / dt, loss.item()


def run_torch(cfg, data, steps, batch, lr, seed, sdpa):
    torch.backends.cuda.matmul.allow_tf32 = False
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    model = ThGPT(cfg, sdpa=sdpa).cuda()
    opt = torch.optim.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                            weight_decay=0.1, foreach=False)
    dev = "cuda"
    tokens = 0
    t0 = time.perf_counter()
    for step in range(steps):
        lr_t = tg.lr_at(step, steps, lr)
        for g in opt.param_groups:
            g["lr"] = lr_t
        x, y = tg.get_batch(data, batch, cfg.block_size, rng)
        xb = torch.from_numpy(x.astype(np.int64)).to(dev)
        yb = torch.from_numpy(y.astype(np.int64)).to(dev)
        loss = model(xb, yb)
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        if step == steps // 3:
            t0 = time.perf_counter()
            tokens = 0
        tokens += batch * cfg.block_size
    torch.cuda.synchronize()
    dt = time.perf_counter() - t0
    return tokens / dt, loss.item()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--block-size", type=int, default=256)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=1337)
    ap.add_argument("--torch-sdpa", action="store_true",
                    help="use fused SDPA on the torch side (stronger "
                         "torch baseline)")
    args = ap.parse_args()

    cfg = tg.Cfg()
    cfg.block_size = args.block_size
    data, vocab, _ = tg.load_corpus(Path(__file__).resolve().parents[2]
                                    / "minitriton")
    cfg.vocab_size = vocab

    print(f"config: 85.3M params, block {cfg.block_size}, batch "
          f"{args.batch_size}, {args.steps} steps, fp32 "
          f"(allow_tf32=False), steady-state = last 2/3 steps\n")

    tl_tps, tl_loss = run_tl(cfg, data, args.steps, args.batch_size,
                             args.lr, args.seed)
    th_tps, th_loss = run_torch(cfg, data, args.steps, args.batch_size,
                                args.lr, args.seed, args.torch_sdpa)

    ratio = tl_tps / th_tps
    print(f"minitriton: {tl_tps / 1e3:7.1f}K tok/s (final loss {tl_loss:.4f})")
    print(f"torch eager{'(SDPA)' if args.torch_sdpa else '      '}: "
          f"{th_tps / 1e3:7.1f}K tok/s (final loss {th_loss:.4f})")
    print(f"ratio tl/torch: {ratio:.2f}  (acceptance gate >= 0.70: "
          f"{'PASS' if ratio >= 0.70 else 'FAIL'})")
    if ratio < 0.70:
        sys.exit(1)


if __name__ == "__main__":
    main()
