#!/usr/bin/env python
"""CUDA-core roofline (assets/roofline_cuda_core.png).

The fp32/CUDA-core half of the dual roofline story:
- roofs: measured fp32 FMA peak (cuBLAS SGEMM 8192^3) + measured DRAM
  bandwidth slope
- series: one line per (kernel, impl) through its shape sequence (sorted
  by AI; small node markers) -- matmul / softmax / flash_attn / kda /
  solve_tril x {minitriton, torch eager, torch.compile, triton} -- plus
  the end-to-end gpt50m_step training-step point. Bandwidth-bound kernels
  (softmax, one AI for all shapes) collapse to a vertical span
  at their AI; solve_tril shows one vertical span per BT (AI = BT/19.5)
  linked into a line.

This script is CSV-driven: it reads benchmarks/roofline/roofline_data.csv (written
by benchmarks/roofline/roofline_export.py; machine calibration lives in the `#`
header) plus benchmarks/roofline/roofline_solve_tril.csv (written by
benchmarks/roofline/roofline_solve_tril.py) and does NO GPU work, so the figure
and the CSVs can never drift apart. Re-run the exporters first to refresh
the data.

Tensor-core (tf32/bf16) series live in roofline_tensor_core.py.

    python benchmarks/roofline/roofline_cuda_core.py
"""

import csv
import re
import sys
from pathlib import Path

BENCH_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BENCH_DIR))

import numpy as np

import plot_style as ps

CSV_PATH = BENCH_DIR / "roofline_data.csv"
CSV_SOLVE_TRIL = BENCH_DIR / "roofline_solve_tril.csv"
ASSETS = BENCH_DIR.parents[1] / "assets"
OUT_PATH = ASSETS / "roofline_cuda_core.png"
OUT_BASE = ASSETS / "roofline_cuda_core"
OUT_SVG = ASSETS / "roofline_cuda_core.svg"

MARKERS = {"matmul": "o", "softmax": "s", "flash_attn": "D", "kda": "P",
           "solve_tril": "v", "gpt50m_step": "*"}


def read_csv(path, need_calib=True):
    """Parse a roofline CSV -> (bw_gbs, peak_gflops, gpu, rows).

    Calibration comes from the `#` header lines; rows are the long-format
    (kernel, shape, impl, ...) records. `need_calib=False` for merge-only
    files whose calibration is informational (the roof always comes from
    roofline_data.csv). `gpu` is the measuring machine's `# gpu:` header
    tag (None when absent) -- the figure labels the data's machine, not
    the plotting one, since this script does no GPU work.
    """
    bw = peak = gpu = None
    rows = []
    if not path.exists():
        raise SystemExit(
            f"{path} not found -- generate it first with "
            f"benchmarks/roofline/roofline_export.py")
    with path.open() as f:
        for line in f:
            if line.startswith("#"):
                m = re.search(r"dram_bw_gbs:\s*([\d.]+)", line)
                if m:
                    bw = float(m.group(1))
                m = re.search(r"fp32_peak_gflops:\s*([\d.]+)", line)
                if m:
                    peak = float(m.group(1))
                m = re.search(r"gpu:\s*([^,]+)", line)
                if m:
                    gpu = m.group(1)
                continue
            rows.append(line)
    if need_calib and (bw is None or peak is None):
        raise ValueError(f"calibration not found in {path} header")
    recs = list(csv.DictReader(rows))
    for r in recs:
        for k in ("ms", "flops", "bytes", "ai", "gflops"):
            r[k] = float(r[k])
    return bw, peak, gpu, recs


def main():
    ps.apply()
    bw_gbs, peak_gflops, gpu, recs = read_csv(CSV_PATH)
    print(f"{CSV_PATH.name}: {len(recs)} rows, "
          f"DRAM {bw_gbs:.1f} GB/s, fp32 peak {peak_gflops:.1f} GFLOP/s")
    if CSV_SOLVE_TRIL.exists():
        _, _, _, st_recs = read_csv(CSV_SOLVE_TRIL, need_calib=False)
        recs += st_recs
        print(f"{CSV_SOLVE_TRIL.name}: {len(st_recs)} rows merged "
              f"(solve_tril series)")
    else:
        print(f"[note] {CSV_SOLVE_TRIL.name} not found -- run "
              f"benchmarks/roofline/roofline_solve_tril.py to add the solve_tril "
              f"series")

    def pts(kernel, impl):
        return [r for r in recs
                if r["kernel"] == kernel and r["impl"] == impl]

    def make_fig():
        fig, ax = ps.new_fig((11.5, 7.2))
        ai = np.logspace(-2, 4, 400)
        roof = np.minimum(peak_gflops, bw_gbs * ai)
        ax.fill_between(ai, 1, roof, color=ps.ROOF_FILL, alpha=0.035, zorder=0)
        ax.plot(ai, roof, color=ps.ROOF, lw=2.0, zorder=1)
        # spec-sheet roof (boost clock, not sustainable) for reference
        spec = np.minimum(59.8e3, 864.0 * ai)
        ax.plot(ai, spec, color=ps.MUT, lw=1.1, ls=(0, (5, 4)), alpha=0.75,
                zorder=1)
        ax.text(2.5e3, 59.8e3 * 1.25,
                "spec sheet (theoretical): 864 GB/s, 59.8 TFLOP/s (boost)",
                ha="center", fontsize=8, color=ps.MUT, zorder=6)

        # one line per (kernel, impl) through its shapes, sorted by AI;
        # same-AI shapes (softmax/vecadd, solve_tril per BT) form a vertical
        # span -- sorted by gflops so the span draws bottom-up
        for name, key, dodge, size, alpha, zorder, lw in ps.ROOFLINE_IMPLS:
            for kern, marker in MARKERS.items():
                p = sorted(pts(kern, key),
                           key=lambda r: (r["ai"], r["gflops"]))
                if not p:
                    continue
                xs = [r["ai"] * dodge for r in p]
                ys = [r["gflops"] for r in p]
                ps.hero_series(ax, xs, ys, key, marker, size, alpha, zorder,
                               lw)

        def tl_xy(kernel, shape):
            r = next(r for r in recs if r["kernel"] == kernel
                     and r["shape"] == shape and r["impl"] == "minitriton")
            return r["ai"], r["gflops"]

        # shape labels for the minitriton lines (endpoints / key points only;
        # full config in the CSVs)
        solo = [  # (kernel, shape, text, (dx, dy), ha, va)
            ("matmul", "512^3", "$512^3$", (0, 10), "center", "bottom"),
            ("matmul", "1024^3", "$1024^3$", (0, 10), "center", "bottom"),
            ("matmul", "2048^3", "$2048^3$", (9, -13), "left", "top"),
            ("matmul", "4096^3", "$4096^3$", (-14, -2), "right", "top"),
            ("flash_attn", "B8H12T256d64", "T=256", (0, -14), "center", "top"),
            ("flash_attn", "B8H12T512d64", "T=512", (0, -14), "center", "top"),
            ("flash_attn", "B8H12T1024d64", "T=1024", (0, -14), "center", "top"),
            ("flash_attn", "B4H8T2048d64", "T=2048", (10, -4), "left", "center"),
            ("solve_tril", "8x8192x16x16", "BT=16", (9, -4), "left", "center"),
            ("solve_tril", "8x8192x16x32", "BT=32", (0, -14), "center", "top"),
            ("solve_tril", "8x8192x16x64", "BT=64", (10, -3), "left", "center"),
            ("kda", "B4H8T512d64", "kda T=512", (-14, -14), "right", "top"),
            ("kda", "B4H8T4096d64", "kda T=4096", (22, 10), "center", "bottom"),
            ("softmax", "1024x1024", "1024×1024", (-26, -4), "right", "center"),
        ]
        for kern, shape, text, dxy, ha, va in solo:
            ax.annotate(text, tl_xy(kern, shape), textcoords="offset points",
                        xytext=dxy, ha=ha, va=va, fontsize=8.5, color=ps.TXT,
                        zorder=7)

        # near-coincident stacks get one callout each (softmax trio)
        callouts = [
            (tl_xy("softmax", "1048576x1024"),
             "65536×1024\n1048576×1024\n4096×4096\n(almost coincide)",
             (-14, 48)),
        ]
        for xy, text, dxy in callouts:
            ax.annotate(text, xy, textcoords="offset points", xytext=dxy,
                        ha="right", va="top" if dxy[1] < 0 else "bottom",
                        fontsize=8, color=ps.SUB, linespacing=1.5, zorder=7,
                        arrowprops=dict(arrowstyle="-", color=ps.MUT, lw=0.7,
                                        shrinkA=3, shrinkB=5, alpha=0.8))

        # gpt50m_step: end-to-end training step (minitriton + torch eager)
        gpt = [r for r in recs if r["kernel"] == "gpt50m_step"]
        if gpt:
            tl_g = next(r for r in gpt if r["impl"] == "minitriton")
            ax.annotate("gpt50m step (fwd+bwd, e2e)",
                        (tl_g["ai"], tl_g["gflops"]),
                        textcoords="offset points", xytext=(0, -16),
                        ha="center", va="top", fontsize=8.5, color=ps.TXT,
                        zorder=7,
                        arrowprops=dict(arrowstyle="-", color=ps.MUT, lw=0.7,
                                        shrinkA=2, shrinkB=6, alpha=0.8))
        # NOTE: no bf16 step annotation here — the bf16 e2e series lives
        # complete (3 impls) on the tensor-core figure beside this one

        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlim(8e-3, 2.2e4)
        ax.set_ylim(4, 1.3e5)
        ax.set_xlabel("arithmetic intensity (FLOP/byte)", fontsize=11.5)
        ax.set_ylabel("achieved performance (GFLOP/s)", fontsize=11.5)
        ps.title_block(ax,
                       "MiniTriton CUDA-core roofline"
                       + (f" — {gpu}" if gpu else "") + ", fp32")
        ps.style_ax(ax)
        ps.split_legend(fig, ax, ps.ROOFLINE_IMPLS, MARKERS,
                        loc_impl="lower right",
                        loc_marker="center right")

        # roofline segments labeled directly on the lines (not in the legend)
        fig.tight_layout()
        fig.canvas.draw()  # fix limits/transforms before measuring the slope
        p0 = ax.transData.transform((1.0, bw_gbs))
        p1 = ax.transData.transform((10.0, 10.0 * bw_gbs))
        ang = np.degrees(np.arctan2(p1[1] - p0[1], p1[0] - p0[0]))
        ax.text(26.0, bw_gbs * 26.0, f"DRAM {bw_gbs:.0f} GB/s (measured)",
                rotation=ang, rotation_mode="anchor", ha="center", va="center",
                fontsize=9, color=ps.SUB, zorder=6,
                bbox=dict(facecolor=ps.BG, edgecolor="none", pad=2.0))
        ax.text(250, peak_gflops * 1.15,
                f"measured: fp32 peak {peak_gflops / 1000:.1f} TFLOP/s "
                f"(cuBLAS SGEMM 8192³)",
                ha="center", va="bottom", fontsize=9, color=ps.SUB, zorder=6)
        ps.footnote(fig, "x = algorithmic accounting (same ledger every "
                         "impl) · y = measured (do_bench, L2 flushed) · "
                         "solid roof = measured roofline · dashed = vendor "
                         "spec sheet (boost)")

        return fig

    ps.render_themes(make_fig, OUT_BASE)

    # console summary: distance to roofline per minitriton point
    print("\nroofline analysis (minitriton points):")
    for r in recs:
        if r["impl"] != "minitriton":
            continue
        roof_r = min(peak_gflops, bw_gbs * r["ai"])
        region = ("compute-bound" if bw_gbs * r["ai"] > peak_gflops
                  else "bandwidth-bound")
        print(f"  {r['kernel']:>12} {r['shape']:>22}: AI={r['ai']:8.2f}  "
              f"{r['gflops']:10.1f} GFLOP/s = "
              f"{100 * r['gflops'] / roof_r:5.1f}% of roofline ({region})")


if __name__ == "__main__":
    main()
