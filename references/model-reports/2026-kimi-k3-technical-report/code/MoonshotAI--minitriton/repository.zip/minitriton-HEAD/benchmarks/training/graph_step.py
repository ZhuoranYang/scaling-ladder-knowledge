#!/usr/bin/env python
"""CUDA-graphed gpt50m train step (runtime/graph.py applied to the
benchmark training loop), two graphs per (config, loss scale):

- graph1 (region): forward + backward + GradScaler unscale + clip-norm
  partial sums (shape-stable; loss scale is a baked host scalar, so a
  scale change re-captures graph1);
- graph2 (tail): on-device clip coefficient + finite gate
  (clip_coef_kernel), the clip pass (scale_dev), the gated AdamW update
  (adamw_dev, lr/wd read from a device scalar buffer uploaded per step)
  and the fp32-master -> bf16-param copy-backs.

After the input H2D the whole step is two cuGraphLaunch calls plus one
async 16-byte lr upload; the total norm is then read back once per
step for GradScaler bookkeeping — a blocking D2H, i.e. one host sync
per step (the parameter update itself stays on-device either way). The
device clip factor is f32-computed (host computes in f64 eagerly), so
graphed and eager trajectories can differ by ~1 ulp on the clip pass —
numerically equivalent, asserted by the validate probe.

Capture discipline (``prime``): warmup + recording are bracketed by a
full snapshot/restore of params, fp32 masters, AdamW moments, step
counter and scaler state, so priming consumes NO training step — every
``step()`` is exactly one optimizer update on the given batch.

Usage::

    gs = GraphedStep(model, opt, scaler, clip_norm=1.0)
    gs.prime(x0, y0)               # warmup + capture, no training
    for step in range(steps):
        opt.lr = lr_at(step, steps, lr)
        x, y = get_batch(...)
        loss_t = gs.step(x, y)     # fixed loss buffer; .item() per step
"""

import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import ops
from minitriton.device.cuda import kernels as K
from minitriton.runtime import graph as mt_graph
from minitriton.tensor import empty
from minitriton.frontend import types as tl_types


def _zero_(t):
    st = t._storage
    st.device.memset32(st.ptr, 0, (t.numel() * t.dtype.itemsize + 3) // 4)


class GraphedStep:
    def __init__(self, model, opt, scaler=None, clip_norm: float = 1.0,
                 eps: float = 1e-6):
        self.model = model
        self.opt = opt
        self.scaler = scaler
        self.clip_norm = clip_norm
        self.eps = eps
        self.params = list(model.parameters())
        # BF16AdamW updates fp32 masters through an inner AdamW; plain
        # AdamW updates the params themselves
        self._masters = getattr(opt, "_master", None)
        self._inner = getattr(opt, "_inner", opt)
        self.graph1: mt_graph.Graph | None = None
        self.graph2: mt_graph.Graph | None = None
        self.scale_key = None
        self._x_buf = None
        self._y_buf = None
        self._loss = None      # captured loss tensor (fixed address)
        self._grads = None     # captured post-unscale p.grad tensors
        self._sc = empty((5,), tl_types.float32, "cuda")  # lr, wd, clip, gate, s2
        self._lr_host = np.zeros(2, dtype=np.float32)
        self._s2_host = np.zeros(1, dtype=np.float32)

    # -- graph1 region: fwd + bwd + unscale + norm partials ----------------
    def _region(self):
        loss = self.model(self._x_buf, self._y_buf)
        self.model.zero_grad()
        scaled = self.scaler.scale_loss(loss) if self.scaler else loss
        scaled.backward()
        if self.scaler is not None:
            self.scaler.unscale_(self.params)
        total = None
        for p in self.params:
            if p.grad is None:
                continue
            s = ops.sum(ops.mul(p.grad, p.grad))
            total = s if total is None else ops.add(total, s)
        return loss, total

    # -- graph2 region: clip coef + clip + gated AdamW + copy-backs --------
    def _tail(self):
        K.launch_clip_coef(self._total_t, self._sc, self.clip_norm,
                           self.eps)
        clipped = []
        for p, g in zip(self.params, self._grads):
            if g is None:
                clipped.append(None)
                continue
            out = empty(g.shape, g.dtype, "cuda")
            K.launch_scale_dev(g, out, self._sc, 2)
            clipped.append(out)
        inner = self._inner
        lr_t, wd_lr = 0.0, 0.0  # (device scalars carry the real values)
        updated = self._masters if self._masters is not None else self.params
        from minitriton import precision as _prec
        torch_eps = _prec.adamw_eps()
        for i, (u, g) in enumerate(zip(updated, clipped)):
            if g is None:
                continue
            m, v = inner._state[id(u)]
            # torch-eps form: s2 rides sc[4] (it changes every step, so it
            # cannot be a frozen launch arg in the captured graph)
            K.launch_adamw_dev(u, g, m, v, u.numel(), self._sc,
                               inner.b1, inner.b2, inner.eps,
                               torch_eps=torch_eps, s2_dev=True)
        if self._masters is not None:
            for p, m in zip(self.params, self._masters):
                ops._copy_into_view(p, m)
        self._clipped = clipped

    def _h2d(self, buf, arr):
        arr = np.ascontiguousarray(arr)
        buf._storage.device.memcpy_h2d(buf._storage.ptr, arr,
                                       buf._storage.nbytes)

    # -- snapshot/restore: priming must not consume training steps -------
    def _train_state(self):
        st = {
            "params": [ops.mul(p.detach(), 1.0) for p in self.params],
            "t": self._inner.t,
            "scale": self.scaler.scale if self.scaler else None,
            "good": self.scaler._good if self.scaler else None,
        }
        if self._masters is not None:
            st["masters"] = [ops.mul(m.detach(), 1.0) for m in self._masters]
        st["mv"] = [(m, v, ops.mul(m.detach(), 1.0),
                     ops.mul(v.detach(), 1.0))
                    for m, v in self._inner._state.values()]
        return st

    def _restore_state(self, st):
        with tl.no_grad():
            for p, s in zip(self.params, st["params"]):
                ops._copy_into_view(p, s)
            if self._masters is not None:
                for m, s in zip(self._masters, st["masters"]):
                    ops._copy_into_view(m, s)
            for m, v, ms, vs in st["mv"]:
                ops._copy_into_view(m, ms)
                ops._copy_into_view(v, vs)
        self._inner.t = st["t"]
        if self.scaler is not None:
            self.scaler.scale = st["scale"]
            self.scaler._good = st["good"]

    def _zero_new_moments(self, had_mv):
        if not had_mv:
            with tl.no_grad():
                for m, v in self._inner._state.values():
                    _zero_(m)
                    _zero_(v)
            self._inner.t = 0

    def _recapture(self):
        for g in (self.graph1, self.graph2):
            if g is not None:
                g.teardown()
        self.graph1 = self.graph2 = None
        st = self._train_state()
        had_mv = bool(st["mv"])
        # warm every lazy path (opt state, plans, autotune, pool) with
        # two full eager steps before recording
        for _ in range(2):
            _, total_t = self._region()
            self._eager_tail_reference(total_t)
            self.model.zero_grad()
        # and once through the graph2 path itself (its buffers/plans must
        # exist in the pool before recording)
        _, self._total_t = self._region()
        self._grads = [p.grad for p in self.params]
        self._tail()
        self.model.zero_grad()
        self._restore_state(st)
        self._zero_new_moments(had_mv)
        tl.synchronize()
        last_err = None
        for _attempt in range(4):
            try:
                self.graph1 = mt_graph.capture(self._region)
                self._loss, self._total_t = self.graph1.out
                self._grads = [p.grad for p in self.params]
                self.graph2 = mt_graph.capture(self._tail)
                break
            except mt_graph.CaptureError as e:
                last_err = e
                for g in (self.graph1, self.graph2):
                    if g is not None:
                        g.teardown()
                self.graph1 = self.graph2 = None
                self.model.zero_grad()
                tl.synchronize()
                self._region()
                self.model.zero_grad()
                tl.synchronize()
        if self.graph1 is None or self.graph2 is None:
            raise RuntimeError(f"graph capture failed after retries: "
                               f"{last_err}")
        self.scale_key = self.scaler.scale if self.scaler else None
        self._restore_state(st)
        self._zero_new_moments(had_mv)
        self.model.zero_grad()

    def _eager_tail_reference(self, total_t):
        """The eager tail (used only for warmup steps): host clip + plain
        AdamW + scaler bookkeeping — identical to the eager loop."""
        total = float(total_t) ** 0.5 if total_t is not None else 0.0
        clip = self.clip_norm / (total + self.eps)
        finite = math.isfinite(total)
        if clip < 1.0:
            with tl.no_grad():
                for p in self.params:
                    if p.grad is not None:
                        p.grad = ops.mul(p.grad, clip)
        if finite:
            self.opt.step()
        else:
            self.model.zero_grad()
        if self.scaler is not None:
            self.scaler.update(not finite)

    def prime(self, x: np.ndarray, y: np.ndarray):
        """Warm up and capture the step graphs; consumes no training."""
        self._x_buf = tl.tensor(x)
        self._y_buf = tl.tensor(y)
        self._recapture()

    def step(self, x: np.ndarray, y: np.ndarray):
        """One train step; returns the step's loss tensor (a fixed
        buffer — read it before the next step)."""
        self._h2d(self._x_buf, x)
        self._h2d(self._y_buf, y)
        if self.graph1 is None or (self.scaler is not None
                                   and self.scaler.scale != self.scale_key):
            self._recapture()
        # lr_t / wd_lr for this step (host math identical to AdamW.step;
        # BF16AdamW syncs inner.lr only inside its eager step(), which the
        # graphed path never calls — sync it here)
        from minitriton import precision as _prec
        inner = self._inner
        inner.lr = self.opt.lr
        t = inner.t + 1
        if _prec.adamw_eps():
            lr_t = inner.lr / (1.0 - inner.b1 ** t)
            s2 = math.sqrt(1.0 - inner.b2 ** t)
        else:
            lr_t = inner.lr * math.sqrt(1.0 - inner.b2 ** t) / \
                (1.0 - inner.b1 ** t)
            s2 = 1.0
        wd_lr = inner.lr * inner.weight_decay
        self._lr_host[0] = lr_t
        self._lr_host[1] = wd_lr
        self._s2_host[0] = s2
        dev = self._sc._storage.device
        dev.memcpy_h2d(self._sc._storage.ptr, self._lr_host,
                       self._lr_host.nbytes)
        dev.memcpy_h2d(self._sc._storage.ptr + 4 * 4, self._s2_host,
                       self._s2_host.nbytes)
        self.graph1.launch()
        self.graph2.launch()
        inner.t = t
        # blocking D2H (one host sync per step): the total for scaler
        # bookkeeping and the skip report (non-finite -> next step
        # re-captures graph1 on the scale change; this step's update
        # was gated off on-device)
        total = float(self._total_t) ** 0.5
        if self.scaler is not None:
            self.scaler.update(not math.isfinite(total))
        return self._loss
