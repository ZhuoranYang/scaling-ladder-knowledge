#!/usr/bin/env python
"""Tensor-core roofline (assets/roofline_tensor_core.png + .csv).

The tensor-core half of the dual roofline story, two tiers kept strictly
separate (never mixed, same rule as benchmarks/roofline/mma_report.py):
- tf32 tier: f32 operands, tensor-core tf32 compute. Flat roof = measured
  cuBLAS tf32 peak (torch allow_tf32=True, 8192^3).
- bf16 tier: bf16 operands, f32 accumulate. Flat roof = measured cuBLAS
  bf16 peak (torch bf16 mm, 8192^3).
Both panels share the measured DRAM bandwidth slope (same routine as
benchmarks/roofline/roofline.py).

Series: one line per (tier, impl) through matmul 512..4096^3 (sorted by
AI, small node markers) x {minitriton, cublas (torch), triton} per tier,
reusing the exact kernels/timing of benchmarks/roofline/mma_report.py (same
do_bench: CUDA events + L2 flush, warmup=5, rep=20, median).

flash_attn runs tf32/bf16 mma tiers here (from attention_mma.csv);
the fp32 FMA tier stays on the CUDA-core figure.

Data lands in benchmarks/roofline/roofline_tensor_core.csv with the same columns
as roofline_data.csv; calibration is in the `#` header. The figure is
drawn FROM the CSV (read back even right after benchmarking), so plot
and data can never drift apart. REPLOT=1 skips all GPU work and redraws
from the existing CSV:

    CUDA_VISIBLE_DEVICES=2 python benchmarks/roofline/roofline_tensor_core.py
    REPLOT=1 python benchmarks/roofline/roofline_tensor_core.py   # no GPU work
"""

import csv
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

BENCH_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BENCH_DIR.parents[1]))
sys.path.insert(0, str(BENCH_DIR))

import numpy as np

import matplotlib.pyplot as plt

import minitriton as tl
from minitriton import do_bench
import minitriton.device.cuda.ops as tl_be

import torch

import plot_style as ps
from roofline import measure_dram_bw
from accounting import (flash_attn_fwd_flops, gpt_step_bytes,
                        gpt_step_flops)
from mma_report import tri_mm, tri_mm_bf16

CSV_PATH = BENCH_DIR / "roofline_tensor_core.csv"
ASSETS = BENCH_DIR.parents[1] / "assets"
OUT_PATH = ASSETS / "roofline_tensor_core.png"
OUT_BASE = ASSETS / "roofline_tensor_core"

SHAPES = [512, 1024, 2048, 4096]
PEAK_N = 8192

TIER_NOTE = {
    "tf32": ("tf32 tier: f32 operands, tensor-core tf32 compute "
             "(tl set_allow_tf32(True) / torch allow_tf32=True / triton "
             "input_precision='tf32'); flops=2*s^3; bytes=12*s^2"),
    "bf16": ("bf16 tier: bf16 operands, f32 accumulate; flops=2*s^3; "
             "bytes=6*s^2 (bf16 in/out)"),
}


def measure_tf32_peak() -> float:
    """GFLOP/s, cuBLAS tf32 (torch allow_tf32=True) at 8192^3."""
    torch.backends.cuda.matmul.allow_tf32 = True
    a = torch.randn(PEAK_N, PEAK_N, device="cuda")
    b = torch.randn(PEAK_N, PEAK_N, device="cuda")
    fn = lambda: torch.mm(a, b)
    fn()
    torch.cuda.synchronize()
    ms = do_bench(fn, warmup=3, rep=10)
    torch.backends.cuda.matmul.allow_tf32 = False
    del a, b
    return 2.0 * PEAK_N**3 / ms * 1e-6


def measure_bf16_peak() -> float:
    """GFLOP/s, cuBLAS bf16 (f32 accumulate) at 8192^3."""
    a = torch.randn(PEAK_N, PEAK_N, device="cuda").bfloat16()
    b = torch.randn(PEAK_N, PEAK_N, device="cuda").bfloat16()
    fn = lambda: torch.mm(a, b)
    fn()
    torch.cuda.synchronize()
    ms = do_bench(fn, warmup=3, rep=10)
    del a, b
    return 2.0 * PEAK_N**3 / ms * 1e-6


def bench_tier(tier: str) -> list:
    """One row-dict per (shape, impl) for the given tier."""
    rows = []
    for s in SHAPES:
        a = np.random.default_rng(0).standard_normal((s, s)).astype(
            np.float32)
        b = np.random.default_rng(1).standard_normal((s, s)).astype(
            np.float32)
        flops = 2.0 * s**3
        if tier == "tf32":
            bts = 12.0 * s * s  # f32 in/out
            tl_be.set_allow_tf32(True)
            ta, tb = tl.tensor(a), tl.tensor(b)
            tl.matmul(ta, tb)
            tl.synchronize()
            tl_ms = do_bench(lambda: tl.matmul(ta, tb))
            tl_be.set_allow_tf32(False)
            torch.backends.cuda.matmul.allow_tf32 = True
            qa, qb = torch.from_numpy(a).cuda(), torch.from_numpy(b).cuda()
            cb_ms = do_bench(lambda: qa @ qb)
            mm_c = torch.compile(lambda x, y: x @ y)
            mm_c(qa, qb)
            torch.cuda.synchronize()
            cm_ms = do_bench(lambda: mm_c(qa, qb))
            torch.backends.cuda.matmul.allow_tf32 = False
            tri_ms = do_bench(lambda: tri_mm(qa, qb, "tf32"))
        else:
            bts = 6.0 * s * s  # bf16 in/out
            ta = tl.tensor(a).astype(tl.bfloat16)
            tb = tl.tensor(b).astype(tl.bfloat16)
            tl.matmul(ta, tb)
            tl.synchronize()
            tl_ms = do_bench(lambda: tl.matmul(ta, tb))
            qa = torch.from_numpy(a).cuda().bfloat16()
            qb = torch.from_numpy(b).cuda().bfloat16()
            cb_ms = do_bench(lambda: qa @ qb)
            mm_c = torch.compile(lambda x, y: x @ y)
            mm_c(qa, qb)
            torch.cuda.synchronize()
            cm_ms = do_bench(lambda: mm_c(qa, qb))
            tri_ms = do_bench(lambda: tri_mm_bf16(qa, qb))
        for impl, ms in (("minitriton", tl_ms), ("cublas", cb_ms),
                         ("torch_compile", cm_ms), ("triton", tri_ms)):
            rows.append({"kernel": f"matmul_{tier}", "shape": f"{s}^3",
                         "impl": impl, "ms": ms, "flops": flops,
                         "bytes": bts})
        print(f"  {tier} {s}^3: tl {tl_ms:.3f} ms, cublas {cb_ms:.3f}, "
              f"compile {cm_ms:.3f}, triton {tri_ms:.3f}  (tl/cublas "
              f"{tl_ms / cb_ms:.2f}x time)")
        del ta, tb, qa, qb
    return rows


def collect_flash() -> list:
    """flash_attn_{tf32,bf16} rows from benchmarks/roofline/
    attention_mma.csv (the regenerable intermediate produced by
    attention_mma_report.py): tl/tri/sdpa ms per tier + shape, flops and
    bytes recomputed here with the standing conventions (causal fwd:
    flops = 2*B*H*d*T^2; bytes = 16*B*H*T*d f32 / 8x bf16)."""
    csv_path = BENCH_DIR / "attention_mma.csv"
    if not csv_path.exists():
        print(f"  {csv_path.name} not found -- skipping flash_attn rows "
              "(run benchmarks/roofline/attention_mma_report.py first)")
        return []
    rows = []
    with csv_path.open() as f:
        for r in csv.DictReader(f):
            m = re.match(r"B(\d+) H(\d+) T(\d+) d(\d+)", r["shape"])
            B, H, T, d = (int(x) for x in m.groups())
            flops = flash_attn_fwd_flops(B, H, T, d)  # causal-halved
            for tier, bts in (("tf32", 16.0 * B * H * T * d),
                              ("bf16", 8.0 * B * H * T * d)):
                for impl, col in (("minitriton", "tl"),
                                  ("cublas", "sdpa"), ("triton", "tri"),
                                  ("torch_compile", "sdpac")):
                    ms = float(r[f"{col}_{tier}_ms"])
                    if ms != ms:  # unavailable on this host (nan)
                        continue
                    rows.append({
                        "kernel": f"flash_attn_{tier}",
                        "shape": f"T{T}d{d}", "impl": impl,
                        "ms": ms,
                        "flops": flops, "bytes": bts,
                        "note": "causal fwd; flops=2*B*H*d*T^2 (halved "
                                "from 4x)"})
    print(f"  attached {len(rows)} flash_attn rows from "
          f"{csv_path.name}")
    return rows


def collect_kda() -> list:
    """kda_{tf32,bf16} rows from benchmarks/roofline/kda_mma_report.py
    (collect_results(); benches on import-time demand)."""
    try:
        import kda_mma_report
    except ImportError as exc:
        print(f"  kda_mma_report.py import failed ({exc!r}) -- skipping "
              "KDA rows")
        return []
    rows = kda_mma_report.collect_results()
    print(f"  attached {len(rows)} kda_mma rows")
    return rows


def _gpt50m_step_fb(ref: dict, blk: int, batch: int):
    """Analytic (shape, flops, bytes) for the gpt50m e2e step at
    (blk, batch), calibrated to the nearest real fp32 sweep row.
    Same formula as accounting.py / roofline_export.py:
        flops = 6*Np*(B*T) + 6*L*B*T^2*D   (6ND + causal attention;
                                            L = n_layer, NOT n_head)
        bytes = 12*Np + 7*L*B*T*D*4        (3 weight passes + ACT_COEF=7)
    n_params is solved from the reference row's own flops so derived
    rows share its calibration; the attention T^2 term is kept, so
    derived blocks do NOT land on the reference block's exact x (a
    plain linear scaling would collapse T768 onto T512's x)."""
    b0 = min(ref, key=lambda b: abs(b - blk))
    s0, f0, _y0 = ref[b0]
    m = re.search(r"L(\d+)D(\d+)H(\d+)", s0)
    L, D, H = (int(m.group(i)) for i in (1, 2, 3))
    n_params = ((f0 - 6.0 * L * 32 * b0 * b0 * D) / (6.0 * 32 * b0))
    flops = gpt_step_flops(n_params, L, batch, blk, D)
    bts = gpt_step_bytes(n_params, L, batch, blk, D)
    shape = (f"{n_params / 1e6:.1f}M_L{L}D{D}H{H}_B{batch}T{blk}")
    return shape, flops, bts


def collect_gpt50m_step() -> list:
    """gpt50m_step_bf16 rows: e2e bf16 mixed-precision train step
    (tl_bf16_graph) vs torch AMP, steady ms/step from benchmarks/
    training/train_gpt_precision_bench.csv. Real fp32 reference rows
    are reused as-is at batch 32; missing blocks / capped batches are
    derived with the analytic formula (_gpt50m_step_fb)."""
    bench_csv = BENCH_DIR.parent / "training" / \
        "train_gpt_precision_bench.csv"
    fp32_csv = BENCH_DIR / "roofline_data.csv"
    if not bench_csv.exists() or not fp32_csv.exists():
        print(f"  {bench_csv.name} / {fp32_csv.name} missing -- skipping "
              "gpt50m_step rows (run train_gpt_precision_bench.py + "
              "gpt50m_sweep.py first)")
        return []
    bench = {}
    with bench_csv.open() as f:
        for r in csv.reader(f):
            if r and not r[0].startswith("#") and r[0] != "impl":
                bench[(r[0], int(r[1]))] = (int(r[2]), float(r[4]))
    ref = {}
    for ln in fp32_csv.read_text().splitlines():
        if ln.startswith("gpt50m_step,"):
            c = next(csv.reader([ln]))
            blk = int(c[1].rsplit("T", 1)[1])
            ref[blk] = c[1], float(c[4]), float(c[5])
    rows = []
    blocks = sorted({b for (impl, b) in bench
                     if impl in ("tl_bf16_graph", "torch_amp",
                                 "torch_compile_amp")})
    for blk in blocks:
        ent = (bench.get(("tl_bf16_graph", blk))
               or bench.get(("torch_amp", blk))
               or bench.get(("torch_compile_amp", blk)))
        if ent is None:  # partial bench coverage: skip, don't KeyError
            continue
        bch = ent[0]
        if blk in ref and bch == 32:
            shape, flops, bts = ref[blk]
        else:
            # missing block (T768) or capped batch (16 at T1024):
            # analytic formula calibrated to the nearest real row
            shape, flops, bts = _gpt50m_step_fb(ref, blk, bch)
        for impl_b, impl in (("tl_bf16_graph", "minitriton"),
                             ("torch_amp", "torch_eager"),
                             ("torch_compile_amp", "torch_compile")):
            if (impl_b, blk) not in bench:
                continue
            note = ("bf16 AMP + torch.compile e2e step"
                    if impl == "torch_compile" else
                    "bf16 mixed-precision e2e step (train-amp)")
            rows.append({"kernel": "gpt50m_step_bf16", "shape": shape,
                         "impl": impl, "ms": bench[(impl_b, blk)][1],
                         "flops": flops, "bytes": bts,
                         "note": note + "; steady ms/step from "
                                 "train_gpt_precision_bench.csv; "
                                 "flops/bytes identical to the fp32 "
                                 "gpt50m_step rows"
                                 + (" (batch16, mem-bound)"
                                    if bch != 32 else "")})
    print(f"  attached {len(rows)} gpt50m_step_bf16 rows")
    return rows


def collect_gpt50m_step_tf32() -> list:
    """gpt50m_step_tf32 rows: e2e tf32 train step (tl_tf32 vs torch
    allow_tf32=True), steady ms/step from benchmarks/training/
    train_gpt_precision_bench.csv. Real fp32 reference rows are reused
    as-is at batch 32; missing blocks / capped batches are derived with
    the analytic formula (_gpt50m_step_fb)."""
    bench_csv = BENCH_DIR.parent / "training" / \
        "train_gpt_precision_bench.csv"
    fp32_csv = BENCH_DIR / "roofline_data.csv"
    if not bench_csv.exists() or not fp32_csv.exists():
        print(f"  {bench_csv.name} / {fp32_csv.name} missing -- skipping "
              "gpt50m_step_tf32 rows (run train_gpt_precision_bench.py + "
              "gpt50m_sweep.py first)")
        return []
    bench = {}
    with bench_csv.open() as f:
        for r in csv.reader(f):
            if r and not r[0].startswith("#") and r[0] != "impl":
                bench[(r[0], int(r[1]))] = (int(r[2]), float(r[4]))
    ref = {}
    for ln in fp32_csv.read_text().splitlines():
        if ln.startswith("gpt50m_step,"):
            c = next(csv.reader([ln]))
            blk = int(c[1].rsplit("T", 1)[1])
            ref[blk] = c[1], float(c[4]), float(c[5])
    rows = []
    blocks = sorted({b for (impl, b) in bench
                     if impl in ("tl_tf32", "torch_tf32",
                                 "torch_compile_tf32")})
    for blk in blocks:
        ent = (bench.get(("tl_tf32", blk))
               or bench.get(("torch_tf32", blk))
               or bench.get(("torch_compile_tf32", blk)))
        if ent is None:  # partial bench coverage: skip, don't KeyError
            continue
        bch = ent[0]
        if blk in ref and bch == 32:
            shape, flops, bts = ref[blk]
        else:
            # missing block (T768) or capped batch (16 at T1024):
            # analytic formula calibrated to the nearest real row
            shape, flops, bts = _gpt50m_step_fb(ref, blk, bch)
        for impl_b, impl in (("tl_tf32", "minitriton"),
                             ("torch_tf32", "torch_eager"),
                             ("torch_compile_tf32", "torch_compile")):
            if (impl_b, blk) not in bench:
                continue
            note = ("tf32 + torch.compile e2e step"
                    if impl == "torch_compile" else
                    "tf32 e2e train step (allow_tf32 matmuls)")
            rows.append({"kernel": "gpt50m_step_tf32", "shape": shape,
                         "impl": impl, "ms": bench[(impl_b, blk)][1],
                         "flops": flops, "bytes": bts,
                         "note": note + "; steady ms/step from "
                                 "train_gpt_precision_bench.csv; "
                                 "flops/bytes identical to the fp32 "
                                 "gpt50m_step rows"
                                 + (" (batch16, mem-bound)"
                                    if bch != 32 else "")})
    print(f"  attached {len(rows)} gpt50m_step_tf32 rows")
    return rows


def write_csv(rows, bw_gbs, peaks, bw_src):
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    gpu = torch.cuda.get_device_name(0)
    cap = torch.cuda.get_device_capability(0)
    meta = [
        "MiniTriton tensor-core roofline data "
        "(benchmarks/roofline_tensor_core.py)",
        f"generated_utc: {ts}",
        f"gpu: {gpu} (sm_{cap[0]}{cap[1]}), CUDA_VISIBLE_DEVICES="
        f"{os.environ.get('CUDA_VISIBLE_DEVICES', '')}",
        "machine calibration (measured, same do_bench as everything else):",
        f"  dram_bw_gbs: {bw_gbs:.1f}  ({bw_src})",
        f"  tf32_peak_gflops: {peaks['tf32']:.1f}  (cuBLAS tf32 "
        f"{PEAK_N}^3, torch allow_tf32=True)",
        f"  bf16_peak_gflops: {peaks['bf16']:.1f}  (cuBLAS bf16 "
        f"{PEAK_N}^3, f32 accumulate)",
        "roofline model per tier: roof(ai)=min(tier_peak_gflops, "
        "dram_bw_gbs*ai); pct_of_roofline=100*gflops/roof(ai)",
        "timing: minitriton do_bench (CUDA events + L2 flush, warmup=5, "
        "rep=20, median), identical to benchmarks/roofline/mma_report.py",
        "arithmetic-intensity conventions (see note column per row):",
        "  matmul_tf32: flops=2*s^3; bytes=12*s^2 (f32 operands)",
        "  matmul_bf16: flops=2*s^3; bytes=6*s^2 (bf16 operands, f32 acc)",
        "impls: minitriton (mma_tile ldmatrix) / cublas (torch mm same "
        "tier) / triton (tutorial tl.dot same tier, BM=BN=64 BK=32)",
        "flash_attn rows: from benchmarks/roofline/attention_mma.csv "
        "(attention_mma_report.py intermediate)",
        "kda rows: from benchmarks/roofline/kda_mma_report.py "
        "collect_results(); flops/bytes = 10.7 MF / 290 KB analytic "
        "model per (b,h,chunk) for the mma pipeline (the CUDA-core kda "
        "rows use the v2/v3 pipeline's own 5.9 MF model)",
        "gpt50m_step_bf16 rows: e2e bf16 mixed-precision train step "
        "(tl_bf16_graph vs torch AMP), steady ms/step from benchmarks/"
        "training/train_gpt_precision_bench.csv; flops/bytes identical "
        "to the CUDA-core gpt50m_step rows",
        "gpt50m_step_tf32 rows: e2e tf32 train step (tl_tf32 vs torch "
        "allow_tf32=True), steady ms/step from benchmarks/training/"
        "train_gpt_precision_bench.csv; flops/bytes identical to the "
        "CUDA-core gpt50m_step rows",
        "columns: ms=median milliseconds; gflops=flops/ms*1e-6; "
        "ai=flops/bytes",
    ]
    with CSV_PATH.open("w", newline="") as f:
        for line in meta:
            f.write(f"# {line}\n")
        w = csv.DictWriter(f, fieldnames=["kernel", "shape", "impl", "ms",
                                          "flops", "bytes", "ai", "gflops",
                                          "pct_of_roofline", "note"])
        w.writeheader()
        for r in rows:
            tier = r["kernel"].rsplit("_", 1)[1]
            ai = r["flops"] / r["bytes"]
            roof = min(peaks[tier], bw_gbs * ai)
            region = ("compute-bound" if bw_gbs * ai > peaks[tier]
                      else "bandwidth-bound")
            gflops = r["flops"] / r["ms"] * 1e-6
            w.writerow({
                "kernel": r["kernel"], "shape": r["shape"],
                "impl": r["impl"], "ms": f"{r['ms']:.6f}",
                "flops": int(round(r["flops"])),
                "bytes": int(round(r["bytes"])), "ai": f"{ai:.4f}",
                "gflops": f"{gflops:.2f}",
                "pct_of_roofline": f"{100.0 * gflops / roof:.2f}",
                "note": r.get("note")
                or f"{TIER_NOTE[tier]}; {region}",
            })
    print(f"wrote {CSV_PATH} ({len(rows)} rows)")


def read_csv(path):
    """Parse roofline_tensor_core.csv -> (bw_gbs, peaks, gpu, rows).

    Calibration (dram_bw_gbs, tf32/bf16 peaks) comes from the `#` header
    lines; rows are the long-format (kernel, shape, impl, ...) records
    with ai/gflops already materialized. `gpu` is the measuring machine's
    `# gpu:` header tag (None when absent) -- the figure labels the data's
    machine, not the plotting one (REPLOT=1 does no GPU work).
    """
    bw = gpu = None
    peaks = {}
    rows = []
    with path.open() as f:
        for line in f:
            if line.startswith("#"):
                m = re.search(r"dram_bw_gbs:\s*([\d.]+)", line)
                if m:
                    bw = float(m.group(1))
                for tier in ("tf32", "bf16"):
                    m = re.search(rf"{tier}_peak_gflops:\s*([\d.]+)", line)
                    if m:
                        peaks[tier] = float(m.group(1))
                m = re.search(r"gpu:\s*([^,]+)", line)
                if m:
                    gpu = m.group(1)
                continue
            rows.append(line)
    if bw is None or len(peaks) != 2:
        raise ValueError(f"calibration not found in {path} header")
    recs = list(csv.DictReader(rows))
    for r in recs:
        for k in ("ms", "flops", "bytes", "ai", "gflops"):
            r[k] = float(r[k])
    return bw, peaks, gpu, recs


def plot(rows, bw_gbs, peaks, gpu):
    fig, axes = plt.subplots(1, 2, figsize=(14.5, 6.8),
                             facecolor=ps.BG, sharex=True)
    for ax, tier in zip(axes, ("tf32", "bf16")):
        ax.set_facecolor(ps.BG)
        peak = peaks[tier]
        ai = np.logspace(0, 5, 300)
        roof = np.minimum(peak, bw_gbs * ai)
        ax.fill_between(ai, 10, roof, color=ps.ROOF_FILL, alpha=0.035,
                        zorder=0)
        ax.plot(ai, roof, color=ps.ROOF, lw=2.0, zorder=1)
        # spec-sheet roof (boost clock, throttles under sustained load)
        spec_peak = {"tf32": 59.8e3, "bf16": 119.5e3}[tier]
        ax.plot(ai, np.minimum(spec_peak, 864.0 * ai), color=ps.MUT,
                lw=1.1, ls=(0, (5, 4)), alpha=0.75, zorder=1)
        ax.set_ylim(8e3, 3e5)
        # one line per impl through the shape sequence (sorted by AI)
        for name, key, dodge, size, alpha, zorder, lw in \
                ps.TENSOR_CORE_IMPLS:
            for kern, marker in (("matmul", "o"), ("flash_attn", "D"),
                                 ("kda", "s"), ("gpt50m_step", "*")):
                p = sorted((r for r in rows
                            if r["kernel"] == f"{kern}_{tier}"
                            and r["impl"] == key),
                           key=lambda r: r["ai"])
                if not p:
                    continue
                xs = [r["ai"] * dodge for r in p]
                ys = [r["gflops"] for r in p]
                ps.hero_series(ax, xs, ys, key, marker, size, alpha,
                               zorder, lw)
        # shape labels on the minitriton line (endpoints + key points)
        MATMUL_LABEL = {  # (tier, shape): (xytext, ha, va) overrides
            ("tf32", "512^3"): ((-10, -2), "right", "center"),
            ("tf32", "1024^3"): ((10, -8), "left", "top"),
            ("bf16", "512^3"): ((-10, -2), "right", "center"),
            ("bf16", "4096^3"): ((-12, -16), "right", "top"),
        }
        for r in rows:
            if r["kernel"] != f"matmul_{tier}" or r["impl"] != "minitriton":
                continue
            s = r["shape"].split("^")[0]
            dxy, ha, va = MATMUL_LABEL.get(
                (tier, r["shape"]),
                ((0, 11), "center", "bottom") if r["shape"] == "1024^3"
                else ((0, -17), "center", "top"))
            ax.annotate(f"${s}^3$", (r["ai"], r["gflops"]),
                        textcoords="offset points", xytext=dxy,
                        ha=ha, va=va, fontsize=8.5, color=ps.TXT,
                        zorder=7)
        # kda callouts next to their own minitriton squares (all impls
        # share ai=36.9 here, so each label goes right of the column at
        # its square's own height -- not at the stack top/bottom)
        for t in ("512", "4096"):
            tl_r = next((r for r in rows
                         if r["kernel"] == f"kda_{tier}"
                         and r["impl"] == "minitriton"
                         and r["shape"].split("T")[1].split("d")[0] == t),
                        None)
            if tl_r is None:
                continue
            ax.annotate(f"kda T{t}", (tl_r["ai"], tl_r["gflops"]),
                        textcoords="offset points", xytext=(10, 0),
                        ha="left", va="center", fontsize=8.5, color=ps.TXT,
                        zorder=7)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlim(28, 5e3)
        ax.set_ylim(6.5e3, 4e5 if tier == "tf32" else 8e5)
        ax.set_xlabel("arithmetic intensity (FLOP/byte)", fontsize=11.5)
        ps.style_ax(ax)
        # flat-segment labels hug their own lines: spec (dashed) label
        # just above the dashed flat, measured (solid) label just below
        # the solid flat; both clear of the rotated slope labels on the
        # left and of the matmul shape labels (zorder 7)
        _bbox = dict(facecolor=ps.BG, edgecolor="none", pad=1.5)
        ax.text(2600, peak * 0.90,
                f"measured: {peak / 1000:.1f} TFLOP/s\n"
                f"(cuBLAS {PEAK_N}³)",
                ha="center", va="top", fontsize=8.5, color=ps.SUB,
                zorder=6, bbox=_bbox)
        ax.text(300, spec_peak * 1.06,
                f"spec sheet (theoretical boost): "
                f"{spec_peak / 1000:.1f} TFLOP/s",
                ha="center", va="bottom", fontsize=8.5, color=ps.MUT,
                zorder=6, bbox=_bbox)
        ax.set_title(f"{tier} tier", fontsize=13, fontweight="bold",
                     color=ps.TXT, loc="left", pad=10)

    axes[0].set_ylabel("achieved performance (GFLOP/s)", fontsize=11.5)
    ps.split_legend(fig, axes[0], ps.TENSOR_CORE_IMPLS, {},
                    loc_impl="lower right")
    ps.split_legend(fig, axes[1], [],
                    {"matmul": "o", "flash_attn": "D", "kda": "s",
                     "gpt50m_step": "*"},
                    loc_marker="lower right")
    fig.suptitle("MiniTriton tensor-core roofline"
                 + (f" — {gpu}" if gpu else ""),
                 fontsize=15.5, fontweight="bold", color=ps.TXT, x=0.008,
                 ha="left", y=0.985)
    ps.footnote(fig, "x = algorithmic accounting (same ledger every "
                     "impl) · y = measured (do_bench, L2 flushed) · "
                     "solid roof = measured roofline · dashed = vendor "
                     "spec sheet (boost)")
    fig.tight_layout(rect=(0, 0.045, 1, 0.94))
    # rotated slope labels must be measured AFTER tight_layout: the
    # layout changes the axes transform, so a slope angle measured
    # before it leaves the labels visibly off-parallel
    fig.canvas.draw()
    for ax, tier in zip(axes, ("tf32", "bf16")):
        spec_peak = {"tf32": 59.8e3, "bf16": 119.5e3}[tier]
        p0 = ax.transData.transform((45.0, bw_gbs * 45.0))
        p1 = ax.transData.transform((65.0, bw_gbs * 65.0))
        ang = np.degrees(np.arctan2(p1[1] - p0[1], p1[0] - p0[0]))
        ax.text(30, bw_gbs * 30 * 1.14, f"{bw_gbs:.0f} GB/s (measured)",
                rotation=ang, rotation_mode="anchor", ha="center",
                va="center", fontsize=8.5, color=ps.SUB, zorder=6)
        spec_xy = {"tf32": (0.62 * spec_peak / 864.0, spec_peak * 0.65),
                   "bf16": (0.50 * spec_peak / 864.0, spec_peak * 0.53)}[tier]
        ax.text(spec_xy[0], spec_xy[1],
                "864 GB/s (spec)", rotation=ang, rotation_mode="anchor",
                ha="center", va="center", fontsize=8.5, color=ps.MUT,
                zorder=6)
    return fig


def _dram_bw() -> tuple:
    """(bw_gbs, source). Reuse the CUDA-core CSV's measured DRAM
    bandwidth when present — one machine, one calibration number across
    both headline figures; measure only when it is missing."""
    data_csv = BENCH_DIR / "roofline_data.csv"
    if data_csv.exists():
        for ln in data_csv.read_text().splitlines():
            m = re.search(r"dram_bw_gbs:\s*([\d.]+)", ln)
            if m:
                return float(m.group(1)), f"reused from {data_csv.name}"
    return measure_dram_bw(), "measured (torch add 2^28, 3 streams)"


def main():
    if os.environ.get("REPLOT") and CSV_PATH.exists():
        print(f"replotting from {CSV_PATH} (REPLOT=1, no GPU work)")
    else:
        ps.apply()
        print("calibrating tensor-core roofline (measured, not spec) ...")
        bw_gbs, bw_src = _dram_bw()
        print(f"  DRAM bandwidth: {bw_gbs:.1f} GB/s ({bw_src})")
        peaks = {"tf32": measure_tf32_peak(), "bf16": measure_bf16_peak()}
        print(f"  tf32 peak (cuBLAS {PEAK_N}^3, allow_tf32):  "
              f"{peaks['tf32']:.1f} GFLOP/s")
        print(f"  bf16 peak (cuBLAS {PEAK_N}^3):              "
              f"{peaks['bf16']:.1f} GFLOP/s")

        print("benchmarking tf32 tier (tl vs cublas vs triton) ...")
        rows = bench_tier("tf32")
        print("benchmarking bf16 tier (tl vs cublas vs triton) ...")
        rows += bench_tier("bf16")
        print("collecting flash-attention mma tiers (attention_mma.csv) ...")
        rows += collect_flash()
        print("collecting KDA mma tiers (kda_mma_report) ...")
        rows += collect_kda()
        print("collecting gpt50m bf16 e2e step (precision_bench) ...")
        rows += collect_gpt50m_step()
        print("collecting gpt50m tf32 e2e step (precision_bench) ...")
        rows += collect_gpt50m_step_tf32()

        write_csv(rows, bw_gbs, peaks, bw_src)

        # sanity summary: tl time / cublas time per tier (mma_report ratio)
        print("\nsanity (tl ms / cublas ms; mma_report reports the "
              "inverse):")
        for tier in ("tf32", "bf16"):
            ratios = []
            for s in SHAPES:
                tl_r = next(r for r in rows
                            if r["kernel"] == f"matmul_{tier}"
                            and r["shape"] == f"{s}^3"
                            and r["impl"] == "minitriton")
                cb_r = next(r for r in rows
                            if r["kernel"] == f"matmul_{tier}"
                            and r["shape"] == f"{s}^3"
                            and r["impl"] == "cublas")
                ratios.append(cb_r["ms"] / tl_r["ms"])
            g = float(np.exp(np.mean(np.log(ratios))))
            print(f"  {tier}: per-shape cublas/tl speed ratios "
                  f"{['%.2f' % r for r in ratios]}, geomean {g:.2f} "
                  f"(expect ~0.85-1.0)")

    # the figure is always drawn from the CSV (never from in-memory bench
    # rows), so plot and data cannot drift apart
    bw_gbs, peaks, gpu, recs = read_csv(CSV_PATH)
    print(f"{CSV_PATH.name}: {len(recs)} rows, DRAM {bw_gbs:.1f} GB/s, "
          f"tf32 peak {peaks['tf32']:.1f} / bf16 peak {peaks['bf16']:.1f} "
          f"GFLOP/s")
    ps.render_themes(lambda: plot(recs, bw_gbs, peaks, gpu), OUT_BASE)


if __name__ == "__main__":
    main()
