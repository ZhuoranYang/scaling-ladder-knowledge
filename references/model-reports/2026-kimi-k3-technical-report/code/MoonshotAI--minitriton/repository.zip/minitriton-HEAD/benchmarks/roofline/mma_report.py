#!/usr/bin/env python
"""mma benchmark: minitriton tensor-core mma (tf32 / bf16)
vs cuBLAS (same precision tier) vs triton tutorial tl.dot (same tier).

Tiers are benchmarked separately (never mixed into one geomean):
- tf32: tl `set_allow_tf32(True)` matmul vs torch allow_tf32=True vs
  triton input_precision="tf32"
- bf16: tl bf16-dtype matmul (f32 accumulate) vs torch bf16 mm vs
  triton bf16 tl.dot

fp32-FMA numbers stay in report.py (regression gate: no fallback here).

    CUDA_VISIBLE_DEVICES=1 python benchmarks/roofline/mma_report.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import do_bench
import minitriton.device.cuda.ops as tl_be

import torch
import triton
import triton.language as tll


@triton.jit
def _tri_mm(A, B, C, M, N, K,
            BM: tll.constexpr, BN: tll.constexpr, BK: tll.constexpr,
            PREC: tll.constexpr):
    pid_m = tll.program_id(0)
    pid_n = tll.program_id(1)
    om = pid_m * BM + tll.arange(0, BM)
    on = pid_n * BN + tll.arange(0, BN)
    ok = tll.arange(0, BK)
    a_ptrs = A + om[:, None] * K + ok[None, :]
    b_ptrs = B + ok[:, None] * N + on[None, :]
    acc = tll.zeros((BM, BN), tll.float32)
    for _ in range(0, K, BK):
        a = tll.load(a_ptrs)
        b = tll.load(b_ptrs)
        acc = tll.dot(a, b, acc, input_precision=PREC)
        a_ptrs += BK
        b_ptrs += BK * N
    c_ptrs = C + om[:, None] * N + on[None, :]
    tll.store(c_ptrs, acc)


def tri_mm(a, b, prec, BM=64, BN=64, BK=32):
    M, K = a.shape
    K2, N = b.shape
    c = torch.empty((M, N), device=a.device, dtype=torch.float32)
    grid = (M // BM, N // BN)
    _tri_mm[grid](a, b, c, M, N, K, BM=BM, BN=BN, BK=BK, PREC=prec,
                  num_warps=4, num_stages=2)
    return c


def main():
    print("mma benchmark: minitriton mma_tile (ldmatrix) vs cuBLAS vs triton"
          " | same do_bench (CUDA events + L2 flush)\n")
    shapes = [512, 1024, 2048, 4096]

    # ------------------------------------------------------------------ tf32
    print("== tf32 tier (f32 operands, tensor-core tf32 compute) ==")
    print(f"{'shape':>10} | {'tl ms':>8} | {'cublas ms':>9} | {'triton ms':>9}"
          f" | {'tl TF/s':>8} | {'cublas':>7} | {'triton':>7}"
          f" | {'r(cublas)':>9} | {'r(triton)':>9}")
    ratios_cb, ratios_tri = [], []
    for s in shapes:
        a = np.random.default_rng(0).standard_normal((s, s)).astype(np.float32)
        b = np.random.default_rng(1).standard_normal((s, s)).astype(np.float32)
        # tl tf32 (opt-in flag; f32 in/out)
        tl_be.set_allow_tf32(True)
        ta, tb = tl.tensor(a), tl.tensor(b)
        out = tl.matmul(ta, tb)
        tl.synchronize()
        tl_ms = do_bench(lambda: tl.matmul(ta, tb))
        err = float(np.max(np.abs(out.numpy() - a @ b))
                    / (np.max(np.abs(a @ b)) + 1e-9))
        # cublas tf32
        torch.backends.cuda.matmul.allow_tf32 = True
        qa, qb = torch.from_numpy(a).cuda(), torch.from_numpy(b).cuda()
        ms_cb = do_bench(lambda: qa @ qb)
        # triton tf32
        ms_tri = do_bench(lambda: tri_mm(qa, qb, "tf32"))
        tf = lambda ms: 2.0 * s**3 / ms * 1e-9
        ratios_cb.append(ms_cb / tl_ms)
        ratios_tri.append(ms_tri / tl_ms)
        print(f"{s:>10} | {tl_ms:8.3f} | {ms_cb:9.3f} | {ms_tri:9.3f}"
              f" | {tf(tl_ms):8.2f} | {tf(ms_cb):7.2f} | {tf(ms_tri):7.2f}"
              f" | {ms_cb / tl_ms:9.2f} | {ms_tri / tl_ms:9.2f}   "
              f"(rel err {err:.1e})")
    g = lambda r: float(np.exp(np.mean(np.log(r))))
    print(f"{'geomean':>10} | {'':>8} | {'':>9} | {'':>9} | {'':>8} |"
          f" {'':>7} | {'':>7} | {g(ratios_cb):9.2f} | {g(ratios_tri):9.2f}")
    tl_be.set_allow_tf32(False)

    # ------------------------------------------------------------------ bf16
    print("\n== bf16 tier (bf16 operands, f32 accumulate) ==")
    print(f"{'shape':>10} | {'tl ms':>8} | {'cublas ms':>9} | {'triton ms':>9}"
          f" | {'tl TF/s':>8} | {'cublas':>7} | {'triton':>7}"
          f" | {'r(cublas)':>9} | {'r(triton)':>9}")
    ratios_cb, ratios_tri = [], []
    for s in shapes:
        a = np.random.default_rng(0).standard_normal((s, s)).astype(np.float32)
        b = np.random.default_rng(1).standard_normal((s, s)).astype(np.float32)
        ta, tb = tl.tensor(a).astype(tl.bfloat16), tl.tensor(b).astype(
            tl.bfloat16)
        out = tl.matmul(ta, tb)
        tl.synchronize()
        tl_ms = do_bench(lambda: tl.matmul(ta, tb))
        qa = torch.from_numpy(a).cuda().bfloat16()
        qb = torch.from_numpy(b).cuda().bfloat16()
        ms_cb = do_bench(lambda: qa @ qb)
        ms_tri = do_bench(lambda: tri_mm_bf16(qa, qb))
        ref = (qa.float() @ qb.float()).cpu().numpy()
        err = float(np.max(np.abs(out.astype(tl.float32).numpy() - ref))
                    / (np.max(np.abs(ref)) + 1e-9))
        tf = lambda ms: 2.0 * s**3 / ms * 1e-9
        ratios_cb.append(ms_cb / tl_ms)
        ratios_tri.append(ms_tri / tl_ms)
        print(f"{s:>10} | {tl_ms:8.3f} | {ms_cb:9.3f} | {ms_tri:9.3f}"
              f" | {tf(tl_ms):8.2f} | {tf(ms_cb):7.2f} | {tf(ms_tri):7.2f}"
              f" | {ms_cb / tl_ms:9.2f} | {ms_tri / tl_ms:9.2f}   "
              f"(rel err {err:.1e})")
    g = lambda r: float(np.exp(np.mean(np.log(r))))
    print(f"{'geomean':>10} | {'':>8} | {'':>9} | {'':>9} | {'':>8} |"
          f" {'':>7} | {'':>7} | {g(ratios_cb):9.2f} | {g(ratios_tri):9.2f}")
    torch.backends.cuda.matmul.allow_tf32 = False


@triton.jit
def _tri_mm_bf16(A, B, C, M, N, K,
                 BM: tll.constexpr, BN: tll.constexpr, BK: tll.constexpr):
    pid_m = tll.program_id(0)
    pid_n = tll.program_id(1)
    om = pid_m * BM + tll.arange(0, BM)
    on = pid_n * BN + tll.arange(0, BN)
    ok = tll.arange(0, BK)
    a_ptrs = A + om[:, None] * K + ok[None, :]
    b_ptrs = B + ok[:, None] * N + on[None, :]
    acc = tll.zeros((BM, BN), tll.float32)
    for _ in range(0, K, BK):
        a = tll.load(a_ptrs)
        b = tll.load(b_ptrs)
        acc = tll.dot(a, b, acc)
        a_ptrs += BK
        b_ptrs += BK * N
    tll.store(C + om[:, None] * N + on[None, :], acc.to(tll.bfloat16))


def tri_mm_bf16(a, b, BM=64, BN=64, BK=32):
    M, K = a.shape
    K2, N = b.shape
    c = torch.empty((M, N), device=a.device, dtype=torch.bfloat16)
    grid = (M // BM, N // BN)
    _tri_mm_bf16[grid](a, b, c, M, N, K, BM=BM, BN=BN, BK=BK,
                       num_warps=4, num_stages=2)
    return c


if __name__ == "__main__":
    main()
