#!/usr/bin/env python
"""Shared dark plot style for all MiniTriton benchmark figures.

One visual system (GitHub-dark palette) for every PNG under benchmarks/:
near-black background, high-contrast accents, thin low-alpha grids, one
font/marker vocabulary. minitriton is always the hero series: brightest
color, largest marker, soft glow, drawn last (on top).

Usage:
    import plot_style as ps
    ps.apply()
    fig, ax = ps.new_fig((11.5, 7.0))
    ...
    ps.save(fig, out_path)

Backend is Agg everywhere (headless); apply() is idempotent.
"""

import itertools

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

# ---------------------------------------------------------------------------
# palette (dark default; light theme via MT_PLOT_THEME=light)
# ---------------------------------------------------------------------------
import os as _os

_DARK = dict(
    BG="#0d1117", PANEL="#161b22", EDGE="#30363d", TXT="#e6edf3",
    SUB="#c9d1d9", MUT="#8b949e", GRID_MAJOR="#222a35",
    GRID_MINOR="#1a212c", ROOF="#f0f6fc", ROOF_FILL="#ffffff",
    IMPL_COLORS={
        "minitriton": "#ff453a",    # hero: bright red
        "torch_eager": "#58a6ff",   # blue
        "torch_compile": "#3fb950", # green
        "triton": "#d2a8ff",        # purple
        "cublas": "#58a6ff",
    },
)
_LIGHT = dict(
    BG="#ffffff", PANEL="#f6f8fa", EDGE="#d0d7de", TXT="#1f2328",
    SUB="#444c56", MUT="#6e7781", GRID_MAJOR="#e3e8ee",
    GRID_MINOR="#f0f3f6", ROOF="#1f2328", ROOF_FILL="#000000",
    IMPL_COLORS={
        "minitriton": "#d7263d",    # hero: deeper red for light bg
        "torch_eager": "#0969da",
        "torch_compile": "#1a7f37",
        "triton": "#8250df",
        "cublas": "#0969da",
    },
)

THEME = _os.environ.get("MT_PLOT_THEME", "dark")
_p = _DARK if THEME == "dark" else _LIGHT
BG = _p["BG"]
PANEL = _p["PANEL"]
EDGE = _p["EDGE"]
TXT = _p["TXT"]
SUB = _p["SUB"]
MUT = _p["MUT"]
GRID_MAJOR = _p["GRID_MAJOR"]
GRID_MINOR = _p["GRID_MINOR"]
ROOF = _p["ROOF"]
ROOF_FILL = _p["ROOF_FILL"]
IMPL_COLORS = _p["IMPL_COLORS"]


def set_theme(name: str) -> None:
    """Switch palette at runtime ("dark" | "light")."""
    global THEME, BG, PANEL, EDGE, TXT, SUB, MUT, GRID_MAJOR, GRID_MINOR
    global ROOF, ROOF_FILL, IMPL_COLORS
    assert name in ("dark", "light")
    THEME = name
    p = _DARK if name == "dark" else _LIGHT
    BG, PANEL, EDGE = p["BG"], p["PANEL"], p["EDGE"]
    TXT, SUB, MUT = p["TXT"], p["SUB"], p["MUT"]
    GRID_MAJOR, GRID_MINOR = p["GRID_MAJOR"], p["GRID_MINOR"]
    ROOF, ROOF_FILL = p["ROOF"], p["ROOF_FILL"]
    IMPL_COLORS = p["IMPL_COLORS"]


class theme:
    """Context manager: `with ps.theme("light"): ...` (restores after)."""

    def __init__(self, name: str):
        self.name = name

    def __enter__(self):
        self.prev = THEME
        set_theme(self.name)

    def __exit__(self, *exc):
        set_theme(self.prev)


def render_themes(fig_fn, out_base, dpi=220):
    """Render one figure in all 6 forms: (dark, light) × (png, svg, pdf).

    `fig_fn()` must build and return a fresh matplotlib Figure using only
    ps.* constants (called twice). dark keeps the plain name; light gets a
    `_light` suffix. PDFs are vector (for LaTeX: the light variants are
    the print-appropriate ones); PNGs are the raster fallback; SVGs for
    the web. Prints the written paths.
    """
    from pathlib import Path
    base = Path(out_base)
    for name in ("dark", "light"):
        set_theme(name)
        apply()
        fig = fig_fn()
        stem = base if name == "dark" else base.with_name(
            base.stem + "_light")
        fig.savefig(str(stem) + ".png", dpi=dpi)
        fig.savefig(str(stem) + ".svg")
        fig.savefig(str(stem) + ".pdf")
        import matplotlib.pyplot as _plt
        _plt.close(fig)
        print(f"wrote {stem}.png\nwrote {stem}.svg\nwrote {stem}.pdf")


def themed_out(path):
    """Output path with a _light suffix when the light theme is active."""
    if THEME == "dark":
        return path
    from pathlib import Path
    p = Path(path)
    return p.with_name(p.stem + "_light" + p.suffix)

# display name -> (impl key, color, x-dodge, marker size, alpha, zorder,
#                  line width)
# x-dodge is PINNED TO 1.0: points sit at their true
# arithmetic-intensity coordinates — no multiplicative fan-out on the
# log AI axis. To keep genuine overlaps legible, baseline series get
# LARGER, lighter markers and the hero series is slightly translucent:
# a coincident baseline shows through as a faint halo around the hero
# point (the tuple slot is kept so call sites stay unchanged).
# Series are drawn as lines through their shape sequence (hero_series):
# markers stay small (node flags only), minitriton is the bright thick
# line, baselines are thin and translucent.
ROOFLINE_IMPLS = [
    ("torch eager", "torch_eager", 1.00, 46, 0.50, 2, 1.2),
    ("torch.compile", "torch_compile", 1.00, 46, 0.50, 2, 1.2),
    ("triton", "triton", 1.00, 48, 0.55, 3, 1.2),
    ("minitriton", "minitriton", 1.00, 38, 0.75, 5, 2.5),
]

TENSOR_CORE_IMPLS = [
    ("torch eager", "cublas", 1.00, 46, 0.50, 2, 1.2),
    ("torch.compile", "torch_compile", 1.00, 46, 0.50, 2, 1.2),
    ("triton", "triton", 1.00, 48, 0.55, 3, 1.2),
    ("torch eager", "torch_eager", 1.00, 46, 0.50, 2, 1.2),
    ("minitriton", "minitriton", 1.00, 40, 0.75, 5, 2.5),
]

HERO = "minitriton"


def apply() -> None:
    """Set the global rcParams for the dark benchmark theme."""
    matplotlib.rcParams.update({
        "text.color": TXT,
        "axes.edgecolor": EDGE,
        "axes.labelcolor": SUB,
        "xtick.color": MUT,
        "ytick.color": MUT,
        "font.size": 10.5,
        "figure.facecolor": BG,
        "axes.facecolor": BG,
        "savefig.facecolor": BG,
    })


def new_fig(figsize=(11.5, 7.0)):
    """(fig, ax) with the dark background applied."""
    fig, ax = plt.subplots(figsize=figsize, facecolor=BG)
    ax.set_facecolor(BG)
    return fig, ax


def style_ax(ax, minor=True) -> None:
    """Thin low-alpha grids below the data; call after log scales are set."""
    ax.grid(True, which="major", color=GRID_MAJOR, lw=0.8)
    if minor:
        ax.grid(True, which="minor", color=GRID_MINOR, lw=0.45)
    ax.set_axisbelow(True)


def hero_scatter(ax, xs, ys, impl_key, marker, size, alpha, zorder):
    """Scatter one series; minitriton gets a soft glow + bright edge."""
    color = IMPL_COLORS[impl_key]
    if impl_key == HERO:
        ax.scatter(xs, ys, c=color, marker=marker, s=size * 2.6, alpha=0.22,
                   edgecolors="none", zorder=zorder - 1, label="_nolegend_")
    edge = ROOF if impl_key == HERO else "none"
    lw = 1.1 if impl_key == HERO else 0.0
    ax.scatter(xs, ys, c=color, marker=marker, s=size, alpha=alpha,
               edgecolors=edge, linewidths=lw, zorder=zorder,
               label="_nolegend_")


def hero_series(ax, xs, ys, impl_key, marker, size, alpha, zorder, lw):
    """Draw one (kernel, impl) roofline series as a line through its shapes.

    The caller passes the points ordered along the series (sorted by AI);
    markers only flag the shape nodes. minitriton (HERO) gets a bright
    thick line with a soft glow; baselines get thin translucent lines.
    Series whose shapes share one AI (bandwidth-bound kernels) collapse to
    a vertical span at that AI -- the same code path, since the x's are
    (nearly) equal. A single-point series (e.g. gpt50m_step) draws just
    the marker.
    """
    color = IMPL_COLORS[impl_key]
    hero = impl_key == HERO
    if len(xs) > 1:
        if hero:
            ax.plot(xs, ys, color=color, lw=lw * 3.2, alpha=0.15,
                    solid_capstyle="round", zorder=zorder - 1,
                    label="_nolegend_")
        ax.plot(xs, ys, color=color, lw=lw, alpha=alpha, zorder=zorder,
                label="_nolegend_")
    edge = ROOF if hero else "none"
    ax.scatter(xs, ys, c=color, marker=marker, s=size, alpha=alpha,
               edgecolors=edge, linewidths=0.9 if hero else 0.0,
               zorder=zorder + 0.1, label="_nolegend_")


def impl_marker_legend(ax, impls, markers, loc="lower right", ncol=2,
                       title="color = implementation · marker = kernel"):
    """Compact two-part legend: colors = implementation, markers = kernel.

    `impls`: list of (display_name, impl_key, ...) tuples; when a 7th
    tuple item is present it is the series line width, so impl entries
    render as line+marker samples matching hero_series. `markers`: dict
    kernel -> marker. Duplicate display names (e.g. two torch flavors)
    collapse to one legend row.
    """
    impl_handles = []
    seen = set()
    for entry in impls:
        name, key = entry[0], entry[1]
        if name in seen:
            continue
        seen.add(name)
        lw = entry[6] if len(entry) > 6 else 1.5
        impl_handles.append(
            Line2D([], [], marker="o", ls="-", lw=lw, markersize=5,
                   color=IMPL_COLORS[key], markerfacecolor=IMPL_COLORS[key],
                   markeredgecolor=ROOF if key == HERO else "none",
                   markeredgewidth=0.9, label=name))
    kern_handles = [
        Line2D([], [], marker=m, ls="none", markersize=7, color=MUT,
               label=k)
        for k, m in markers.items()]
    handles = [h for pair in itertools.zip_longest(impl_handles, kern_handles)
               for h in pair if h is not None]
    leg = ax.legend(handles=handles, ncol=ncol, loc=loc, title=title,
                    fontsize=9, title_fontsize=9, labelspacing=0.7,
                    borderpad=0.9, facecolor=PANEL, edgecolor=EDGE,
                    framealpha=1.0)
    leg.get_title().set_color(MUT)
    return leg


def split_legend(fig, ax, impls, markers, loc_impl="lower right",
                 loc_marker="upper right"):
    """Two independent legends: impl colors in one, kernel markers in the
    other (never mixed into a shared grid).

    `impls`: (display_name, impl_key, ...) tuples (7th item = line width).
    `markers`: dict kernel -> marker. Returns (leg_impl, leg_marker).
    """
    from matplotlib.lines import Line2D as _L
    impl_handles = []
    seen = set()
    for entry in impls:
        name, key = entry[0], entry[1]
        if name in seen:  # two flavors of one impl (e.g. torch) → one row
            continue
        seen.add(name)
        lw = entry[6] if len(entry) > 6 else 1.5
        impl_handles.append(
            _L([], [], marker="o", ls="-", lw=lw, markersize=5,
               color=IMPL_COLORS[key], markerfacecolor=IMPL_COLORS[key],
               markeredgecolor=ROOF if key == HERO else "none",
               markeredgewidth=0.9, label=name))
    leg1 = None
    if impl_handles:
        leg1 = ax.legend(handles=impl_handles, loc=loc_impl, title="method",
                         fontsize=8.5, title_fontsize=8.5, facecolor=PANEL,
                         edgecolor=EDGE, framealpha=1.0)
        leg1.get_title().set_color(MUT)
        ax.add_artist(leg1)
    kern_handles = [
        _L([], [], marker=m, ls="none", markersize=7, color=MUT, label=k)
        for k, m in markers.items()]
    leg2 = None
    if kern_handles:
        leg2 = ax.legend(handles=kern_handles, loc=loc_marker,
                         title="kernel", fontsize=8.5, title_fontsize=8.5,
                         facecolor=PANEL, edgecolor=EDGE, framealpha=1.0)
        leg2.get_title().set_color(MUT)
    return leg1, leg2


def title_block(ax, title, subtitle=None):
    """Left-aligned bold title above the axes; optional muted subtitle.

    The subtitle is excluded from tight_layout accounting (in_layout=False):
    it is allowed to be wider than the axes and must not squeeze them.
    """
    ax.set_title(title, fontsize=15.5, fontweight="bold", color=TXT,
                 loc="left", pad=30 if subtitle else 12)
    if subtitle:
        t = ax.text(0, 1.035, subtitle, transform=ax.transAxes,
                    fontsize=10.5, color=MUT)
        t.set_in_layout(False)


def footnote(fig, text):
    fig.text(0.008, 0.012, text, fontsize=8, color=MUT, va="bottom")


def better_arrow(ax, mem=((0.46, 0.26), (0.38, 0.40)),
                 comp=((0.82, 0.60), (0.82, 0.74)),
                 text="better", text_xy=(0.55, 0.30)):
    """Two 'better' direction arrows on a roofline figure (axes coords).

    One perpendicular to the memory wall (DRAM slope, pointing outward
    toward the roof), one perpendicular to the compute wall (flat peak,
    pointing straight up), plus a single 'better' label. Hugging the
    roofline is best.
    """
    for (x0, y0), (x1, y1) in (mem, comp):
        ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                    xycoords="axes fraction",
                    arrowprops=dict(arrowstyle="-|>", color=SUB, lw=1.6,
                                    mutation_scale=15, shrinkA=0,
                                    shrinkB=0),
                    zorder=8)
    ax.text(text_xy[0], text_xy[1], text, transform=ax.transAxes,
            color=SUB, fontsize=10, ha="center", va="top",
            fontstyle="italic", zorder=8)


def save(fig, out, dpi=150):
    fig.savefig(out, dpi=dpi, facecolor=fig.get_facecolor())
    print(f"wrote {out}")
