#!/usr/bin/env python
"""KDA (Kimi Delta Attention) forward benchmark: minitriton
pipeline (five-kernel v1: K1 wy / K1s solve_tril / K1b factors / K2
state / K3 out, or the default v2/v3 fused pipeline; eager K0
preprocessing included in the timed call) vs a self-written triton
fp32 reference (all dots input_precision="ieee").

The triton reference is written in this repo (no external fla
dependency): same chunked algorithm, three triton kernels
(wy with the exact all-matmul prod-of-squares UT inverse, state scan,
out) + torch eager preprocessing. Same do_bench (CUDA events + L2 flush)
on both sides, per benchmarks/roofline/attention_report.py conventions.

    CUDA_VISIBLE_DEVICES=0 python benchmarks/roofline/kda_report.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import do_bench, ops as tl_ops
from minitriton.device.cpu import _kda_chunk_np

import torch
import triton
import triton.language as tll

torch.backends.cuda.matmul.allow_tf32 = False

C = 64  # chunk size


# ---------------------------------------------------------------------------
# triton fp32-ieee reference (three kernels; prod-of-squares inverse)
# ---------------------------------------------------------------------------

@triton.jit
def _tri_kda_wy(KN, QN, BETA, LOGA, GT, CSH, EMC,
                M, DELTA, QH, WC, WT, T, NC,
                DK: tll.constexpr, C: tll.constexpr):
    pid = tll.program_id(0)
    bh = tll.program_id(1)
    offs = tll.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    base = bh * T * DK
    offs2 = offs_t[:, None] * DK + offs[None, :]
    offsC = offs[:, None] * C + offs[None, :]
    il = tll.where(offs[:, None] >= offs[None, :], 1.0, 0.0)
    sl = tll.where(offs[:, None] > offs[None, :], 1.0, 0.0)
    eye = tll.where(offs[:, None] == offs[None, :], 1.0, 0.0)
    la = tll.load(LOGA + base + offs2, mask=tm[:, None], other=0.0)
    kn = tll.load(KN + base + offs2, mask=tm[:, None], other=0.0)
    qn = tll.load(QN + base + offs2, mask=tm[:, None], other=0.0)
    beta = tll.load(BETA + bh * T + offs_t, mask=tm, other=0.0)
    gt = tll.load(GT + slab * DK + offs)                  # (C,) chunk decay
    c = tll.load(CSH + slab)                              # scalar shift
    emc = tll.load(EMC + slab)                            # exp(-c)
    g = tll.dot(il, la, input_precision="ieee")           # inclusive cumsum
    eg = tll.exp(g)
    delta = eg * kn
    qh = eg * qn
    gt2 = tll.trans(g)                                    # (DK, C)
    e = tll.minimum(tll.maximum(c - gt2, -80.0), 80.0)
    knT = tll.trans(kn)
    wcT = knT * beta[None, :] * tll.exp(e)                # write keys
    wtT = knT * beta[None, :] * tll.exp(gt[:, None] - gt2)  # tail-shifted
    L = tll.dot(delta, wcT, input_precision="ieee") * sl * emc
    # (I + L)^-1 = (I - L)(I + L^2)(I + L^4)...(I + L^32), exact (L^64 = 0)
    P = -L
    W = eye + P
    for _ in tll.static_range(5):
        P = tll.dot(P, P, input_precision="ieee")
        W += tll.dot(P, W, input_precision="ieee")
    tll.store(M + slab * C * C + offsC, W)
    tll.store(DELTA + slab * C * DK + offs[:, None] * DK + offs[None, :],
              delta)
    tll.store(QH + slab * C * DK + offs[:, None] * DK + offs[None, :], qh)
    tll.store(WC + slab * DK * C + offsC, wcT)
    tll.store(WT + slab * DK * C + offsC, wtT)


@triton.jit
def _tri_kda_state(M, DELTA, WT, GT, V, HC, VT, S1, T, NC,
                   DK: tll.constexpr, DV: tll.constexpr, C: tll.constexpr):
    bh = tll.program_id(0)
    offs = tll.arange(0, C)
    offs_v = tll.arange(0, DV)
    offsC = offs[:, None] * C + offs[None, :]
    S = tll.zeros((C, DV), tll.float32)
    for cc in range(0, NC):
        slab = bh * NC + cc
        offs_t = cc * C + offs
        vm = offs_t < T
        v = tll.load(V + bh * T * DV + offs_t[:, None] * DV
                     + offs_v[None, :], mask=vm[:, None], other=0.0)
        m = tll.load(M + slab * C * C + offsC)
        d = tll.load(DELTA + slab * C * DK + offs[:, None] * DK
                     + offs[None, :])
        vt = tll.dot(m, v - tll.dot(d, S, input_precision="ieee"),
                     input_precision="ieee")
        tll.store(HC + slab * DK * DV + offs[:, None] * DV + offs_v[None, :],
                  S)
        tll.store(VT + slab * C * DV + offs[:, None] * DV + offs_v[None, :],
                  vt)
        gt = tll.load(GT + slab * DK + offs)
        wt = tll.load(WT + slab * DK * C + offsC)
        S = tll.exp(gt)[:, None] * S + tll.dot(wt, vt, input_precision="ieee")
    tll.store(S1 + bh * DK * DV + offs[:, None] * DV + offs_v[None, :], S)


@triton.jit
def _tri_kda_out(QH, WC, HC, VT, EMC, O, T, NC,
                 DK: tll.constexpr, DV: tll.constexpr, C: tll.constexpr):
    pid = tll.program_id(0)
    bh = tll.program_id(1)
    offs = tll.arange(0, C)
    offs_t = pid * C + offs
    tm = offs_t < T
    slab = bh * NC + pid
    offsC = offs[:, None] * C + offs[None, :]
    il = tll.where(offs[:, None] >= offs[None, :], 1.0, 0.0)
    emc = tll.load(EMC + slab)
    qh = tll.load(QH + slab * C * DK + offs[:, None] * DK + offs[None, :])
    wcT = tll.load(WC + slab * DK * C + offsC)
    Aq = tll.dot(qh, wcT, input_precision="ieee") * il * emc
    hc = tll.load(HC + slab * DK * DV + offs[:, None] * DV + offs[None, :])
    vt = tll.load(VT + slab * C * DV + offs[:, None] * DV + offs[None, :])
    o = tll.dot(qh, hc, input_precision="ieee")
    o = tll.dot(Aq, vt, o, input_precision="ieee")
    tll.store(O + bh * T * DV + offs_t[:, None] * DV + offs[None, :], o,
              mask=tm[:, None])


def tri_kda(q, k, v, xb, xd, cfg):
    """torch eager preprocessing (same math as ops/kda.py) + 3 kernels."""
    wy_w, st_w, out_w = cfg
    B, H, T, dk = k.shape
    dv = v.shape[-1]
    NC = (T + C - 1) // C
    kn = k / torch.sqrt((k * k).sum(-1, keepdim=True))
    qn = q / torch.sqrt((q * q).sum(-1, keepdim=True))
    beta = torch.sigmoid(xb)
    loga = torch.nn.functional.logsigmoid(xd)
    pad = NC * C - T
    loga_p = torch.nn.functional.pad(loga, (0, 0, 0, pad))
    gt = loga_p.reshape(B, H, NC, C, dk).sum(3)
    c = gt.min(-1).values.clamp(min=-80.0)
    emc = torch.exp(-c)
    BH = B * H
    dev = q.device
    f = torch.float32
    M = torch.empty((BH * NC, C, C), dtype=f, device=dev)
    delta = torch.empty((BH * NC, C, dk), dtype=f, device=dev)
    qh = torch.empty((BH * NC, C, dk), dtype=f, device=dev)
    wc = torch.empty((BH * NC, dk, C), dtype=f, device=dev)
    wt = torch.empty((BH * NC, dk, C), dtype=f, device=dev)
    hc = torch.empty((BH * NC, dk, dv), dtype=f, device=dev)
    vt = torch.empty((BH * NC, C, dv), dtype=f, device=dev)
    s1 = torch.empty((BH, dk, dv), dtype=f, device=dev)
    o = torch.empty((B, H, T, dv), dtype=f, device=dev)
    _tri_kda_wy[(NC, BH)](kn, qn, beta, loga, gt, c, emc,
                          M, delta, qh, wc, wt, T, NC, DK=dk, C=C,
                          num_warps=wy_w, num_stages=1)
    _tri_kda_state[(BH,)](M, delta, wt, gt, v, hc, vt, s1, T, NC,
                          DK=dk, DV=dv, C=C, num_warps=st_w, num_stages=1)
    _tri_kda_out[(NC, BH)](qh, wc, hc, vt, emc, o, T, NC,
                           DK=dk, DV=dv, C=C, num_warps=out_w, num_stages=1)
    return o


_TRI_CONFIGS = [(4, 2, 4), (4, 4, 4), (8, 4, 8)]


def tri_best(q, k, v, xb, xd):
    best = None
    for cfg in _TRI_CONFIGS:
        try:
            fn = lambda: tri_kda(q, k, v, xb, xd, cfg)
            fn()
            torch.cuda.synchronize()
            ms = do_bench(fn)
        except Exception:
            continue
        if best is None or ms < best[1]:
            best = (cfg, ms)
    cfg, ms = best
    return (lambda: tri_kda(q, k, v, xb, xd, cfg)), ms, cfg


# ---------------------------------------------------------------------------
# FLOP / traffic accounting (per (b,h,chunk), dk=dv=C=64)
# ---------------------------------------------------------------------------

# tl v2/v3 fused pipeline: 11 dots (decay g/gt-row, wy2 L,
# mv3a md/mv, mv3b Aw/b, scan one-dot, out2 vt/o-readbase/Aq/o) +
# solve_tril; the gt-row and qknorm are ~1/64 dots each, folded into the
# 150 KFLOP constant
FLOPS_CHUNK_TL = 11 * 2 * C**3 + 150e3
# triton reference: 9 dots + 10-dot prod-of-squares inverse
FLOPS_CHUNK_TRI = 19 * 2 * C**3
# DRAM traffic estimate: inputs q/k/xd read by dcy/wy2 + qknorm 4P +
# wy2 writes 5P + K1s 2P + mv3a/b 6P + scan 3P + out2 6P + o (P = 16KB
# plane), ~26P per (b,h,chunk); eager preprocessing traffic excluded on
# the triton side (torch eager)
BYTES_CHUNK = 26 * C * C * 4

# acceptance shape grid: B x H x T, dk=dv=64
_FULL_GRID = ([1, 2, 4, 8], [8, 16, 32], [512, 1024, 2048, 4096, 8192])
_CI_GRID = ([4], [8], [512, 1024, 2048, 4096])
# gates calibrated on L20 (sm_89): CI grid geomean measures ~1.47;
# full-grid T>=2048 geomean ~1.55 with per-shape min ~1.27
_CI_GEOMEAN_GATE = 1.20
_FULL_GEOMEAN_GATE = 1.30
_FULL_MIN_GATE = 1.20


def bench_shape(B, H, T, dk=64, check=True):
    rng = np.random.default_rng(0)
    qn, kn, vn = (rng.standard_normal((B, H, T, dk)).astype(np.float32)
                  for _ in range(3))
    xbn = rng.standard_normal((B, H, T)).astype(np.float32)
    loga = rng.uniform(-0.7, 0.0, (B, H, T, dk))
    a = np.exp(loga)
    xdn = np.log(a / (1.0 - a)).astype(np.float32)
    NC = (T + C - 1) // C
    # minitriton (eager K0 preprocessing inside the timed call)
    tq, tk, tv, txb, txd = (tl.tensor(x) for x in (qn, kn, vn, xbn, xdn))
    with tl.no_grad():
        out = tl_ops.kda_forward(tq, tk, tv, txb, txd)
    tl_fn = lambda: tl_ops.kda_forward(tq, tk, tv, txb, txd)
    tl_fn()
    tl.synchronize()
    tl_ms = do_bench(tl_fn)
    # triton reference
    qq, kk, vv, qxb, qxd = (torch.from_numpy(x).cuda()
                            for x in (qn, kn, vn, xbn, xdn))
    tri_fn, tri_ms, cfg = tri_best(qq, kk, vv, qxb, qxd)
    out_tri = tri_fn()
    err_tl = err_tri = float("nan")
    if check:
        # fp64 oracle (numpy chunk closed form, = the CPU backend)
        kp = kn / np.sqrt((kn * kn).sum(-1, keepdims=True))
        qp = qn / np.sqrt((qn * qn).sum(-1, keepdims=True))
        bp = 1.0 / (1.0 + np.exp(-xbn))
        lp = np.where(xdn > 0, 0.0, xdn) - np.log(np.exp(-np.abs(xdn)) + 1.0)
        o_ref, _ = _kda_chunk_np(kp, qp, vn, bp, lp)
        err_tl = float(np.max(np.abs(out.numpy() - o_ref)))
        err_tri = float(np.max(np.abs(out_tri.cpu().numpy() - o_ref)))
    flops_tl = FLOPS_CHUNK_TL * B * H * NC
    flops_tri = FLOPS_CHUNK_TRI * B * H * NC
    return {
        "shape": f"B{B}H{H}T{T}d{dk}", "T": T,
        "tl_ms": tl_ms, "tri_ms": tri_ms,
        "tl_tf": flops_tl / tl_ms * 1e-9,
        "tri_tf": flops_tri / tri_ms * 1e-9,
        "ratio": tri_ms / tl_ms, "cfg": cfg,
        "err_tl": err_tl, "err_tri": err_tri,
        "flops": flops_tl, "bytes": BYTES_CHUNK * B * H * NC,
    }


def collect_results():
    """roofline_export.py hook schema: kernel/shape/flops/bytes + tl_ms /
    triton_ms (fp32-ieee reference; eager K0 preprocessing included in
    both timings)."""
    rows = []
    for B, H, T in [(4, 8, 512), (4, 8, 1024), (4, 8, 2048), (4, 8, 4096)]:
        r = bench_shape(B, H, T, check=False)
        rows.append({
            "kernel": "kda", "shape": r["shape"],
            "flops": r["flops"], "bytes": r["bytes"],
            "tl_ms": r["tl_ms"], "triton_ms": r["tri_ms"],
            "note": ("KDA fwd v2/v3 fused pipeline (C=64); flops=analytic "
                     "(11 dots+solve_tril per chunk); bytes=plane-traffic "
                     "estimate 26x16KB/(b,h,chunk); triton=self-written "
                     "fp32-ieee reference (prod-of-squares inverse)"),
        })
        print(f"  kda {r['shape']}: tl {r['tl_ms']:.3f} ms, "
              f"triton {r['tri_ms']:.3f} ms")
    return rows


def main():
    full = "--full" in sys.argv
    grid = _FULL_GRID if full else _CI_GRID
    print("KDA (Kimi Delta Attention) FORWARD, fp32; triton reference with "
          "input_precision='ieee' (same do_bench, CUDA events + L2 flush)")
    print("triton reference is self-written in-repo (3 kernels, "
          "prod-of-squares inverse)")
    print("tl runs the v2/v3 fused pipeline (qknorm+decay K0, "
          "one-dot affine scan, matmul_tile factors); both timings "
          "include the K0 preprocessing")
    if full:
        print("grid: full acceptance grid "
              "B{1,2,4,8}xH{8,16,32}xT{512..8192}\n")
    print(f"{'shape':>16} | {'tl ms':>8} | {'triton ms':>9} | "
          f"{'tl TF/s':>8} | {'tri TF/s':>9} | {'tl/tri':>7} | "
          f"{'triton cfg':>12} | {'tl err':>9} | {'tri err':>9}")
    ratios = []
    rows = []
    for B in grid[0]:
        for H in grid[1]:
            for T in grid[2]:
                r = bench_shape(B, H, T)
                ratios.append(r["ratio"])
                rows.append(r)
                cfg = r["cfg"]
                cfg_s = f"w{cfg[0]}/{cfg[1]}/{cfg[2]}"
                print(f"{r['shape']:>16} | {r['tl_ms']:8.3f} | "
                      f"{r['tri_ms']:9.3f} | {r['tl_tf']:8.2f} | "
                      f"{r['tri_tf']:9.2f} | {r['ratio']:7.2f} | "
                      f"{cfg_s:>12} | {r['err_tl']:9.1e} | "
                      f"{r['err_tri']:9.1e}", flush=True)
    g = float(np.exp(np.mean(np.log(ratios))))
    print(f"\ngeomean tl/triton: {g:.2f}")
    if full:
        t2k = [r["ratio"] for r in rows if r["T"] >= 2048]
        g2 = float(np.exp(np.mean(np.log(t2k))))
        m2 = min(t2k)
        geo_ok = g2 >= _FULL_GEOMEAN_GATE
        min_ok = m2 >= _FULL_MIN_GATE
        print(f"geomean T>=2048: {g2:.2f}  (gate >= "
              f"{_FULL_GEOMEAN_GATE:.2f}, calibrated on L20: "
              f"{'PASS' if geo_ok else 'FAIL'})")
        print(f"min T>=2048: {m2:.2f}  (gate >= {_FULL_MIN_GATE:.2f}, "
              f"calibrated on L20: {'PASS' if min_ok else 'FAIL'})")
        ok = geo_ok and min_ok
    else:
        ok = g >= _CI_GEOMEAN_GATE
        print(f"gate: geomean >= {_CI_GEOMEAN_GATE:.2f}, calibrated on "
              f"L20: {'PASS' if ok else 'FAIL'}")
    print("(tl TF/s uses the tl pipeline's analytic FLOPs — 11 dots + "
          "solve_tril per chunk; the triton reference does 8 extra dots "
          "for its prod-of-squares inverse, its TF/s column counts them)")
    if not ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
