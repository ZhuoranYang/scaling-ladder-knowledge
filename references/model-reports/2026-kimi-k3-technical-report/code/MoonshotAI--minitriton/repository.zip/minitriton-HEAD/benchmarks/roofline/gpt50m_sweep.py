#!/usr/bin/env python
"""Regenerate ONLY the gpt50m_step rows (T sweep) in roofline_data.csv.

    CUDA_VISIBLE_DEVICES=3 python benchmarks/roofline/gpt50m_sweep.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import roofline_export as rx

CSV = Path(__file__).resolve().parent / "roofline_data.csv"


def _drain():
    import gc
    gc.collect()


def main():
    results = []
    for blk in rx.GPT_BLOCKS:
        _drain()
        rx._collect_gpt50m_one(results, blk)

    lines = CSV.read_text().splitlines()
    hdr = [l for l in lines if l.startswith("#")]
    rows = [l for l in lines if l and not l.startswith("#")]
    header, body = rows[0], [r for r in rows[1:]
                             if not r.startswith("gpt50m_step,")]
    for r in results:
        ai = r["flops"] / r["bytes"]
        for impl, key in (("minitriton", "tl_ms"), ("torch_eager", "eager_ms")):
            gf = r["flops"] / r[key] * 1e-6
            body.append(f"gpt50m_step,{r['shape']},{impl},{r[key]:.6f},"
                        f"{r['flops']:.0f},{r['bytes']:.0f},{ai:.4f},"
                        f"{gf:.2f},,\"{r['note']}\"")
    CSV.write_text("\n".join(hdr) + "\n" + header + "\n"
                   + "\n".join(body) + "\n")
    print(f"merged {len(results)} sweep rows -> {CSV}")


if __name__ == "__main__":
    main()
