#!/usr/bin/env python
"""gpt50m e2e train-step throughput by precision tier.

Same 49.5M char-GPT (L10 D640 H10, vocab from the corpus) on minitriton
(fp32 / tf32 / bf16) and torch (fp32 eager / bf16 AMP autocast), block
sweep T in {256, 512, 768, 1024}, steady-state tok/s = tokens / wall
over the last 2/3 of steps (same protocol as train_gpt_bench.py and the
roofline export's gpt50m_step rows).

    CUDA_VISIBLE_DEVICES=1 python benchmarks/training/train_gpt_precision_bench.py --steps 60

Precision tiers
---------------
- tl fp32:   default path (fp32 FMA matmul, fused fp32 flash attention)
- tl tf32:   allow_tf32 matmul + tf32 flash (fwd mma, fused fp32 bwd)
- tl bf16:   bf16 params + fp32 master weights + dynamic loss scaling;
             bf16 mma matmul + bf16 flash fwd; the attention backward is
             native bf16 mma (MT_ATTN_BWD_F32=1 opts into the fused f32
             flash kernels on f32 upcasts); fp32 residual stream, fp32
             LN/CE
- torch fp32: allow_tf32=False, explicit eager attention at T<=256
             (SDPA at T>=512 — the explicit (T,T) scores OOM there, same
             convention as benchmarks/roofline/roofline_export.py)
- torch tf32: same as torch fp32 but allow_tf32=True matmuls (the global
             is restored to False when the run returns)
- torch amp: torch.autocast(bf16) over forward+bwd (cuBLAS bf16 mma,
             fp32 LN/CE), SDPA fused attention, no GradScaler (standard
             for bf16)

Writes benchmarks/training/train_gpt_precision_bench.csv (one row per
impl x T) and prints the same table.
"""

import argparse
import importlib.util
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import nn

import torch

spec = importlib.util.spec_from_file_location(
    "train_gpt", Path(__file__).resolve().parents[2] / "examples"
    / "train_gpt.py")
tg = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tg)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from train_gpt_bench import ThGPT  # torch twin (same init semantics)

GPT = dict(n_layer=10, n_head=10, n_embd=640)  # 49.5M params (gpt50m)

OUT_CSV = Path(__file__).resolve().parent / "train_gpt_precision_bench.csv"


def _cfg(vocab, block):
    cfg = tg.Cfg()
    cfg.vocab_size = vocab
    cfg.block_size = block
    cfg.n_layer, cfg.n_head, cfg.n_embd = (GPT["n_layer"], GPT["n_head"],
                                           GPT["n_embd"])
    return cfg


def run_tl(cfg, data, steps, batch, lr, seed, mode):
    """mode: 'fp32' | 'tf32' | 'bf16'. Returns (tok/s, final loss)."""
    import minitriton.device.cuda.ops as _be
    _be.set_allow_tf32(mode == "tf32")  # bf16 keeps its fp32 seams exact
    cfg.bf16 = mode == "bf16"
    rng = np.random.default_rng(seed)
    model = tg.GPT(cfg)
    if cfg.bf16:
        fp32_orig = tg._convert_bf16_(model)
        opt = nn.BF16AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                           weight_decay=0.1, masters=fp32_orig)
        scaler = nn.GradScaler()
    else:
        opt = nn.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                       weight_decay=0.1)
        scaler = None
    w = steps // 3  # steady-state window: last 2/3 of steps
    tokens, t0 = 0, time.perf_counter()
    loss = None
    import math
    for step in range(steps):
        opt.lr = tg.lr_at(step, steps, lr)
        x, y = tg.get_batch(data, batch, cfg.block_size, rng)
        loss = model(tl.tensor(x), tl.tensor(y))
        model.zero_grad()
        (scaler.scale_loss(loss) if scaler else loss).backward()
        if scaler is not None:
            scaler.unscale_(model.parameters())
            total = nn.clip_grad_norm(model.parameters(), 1.0)
            if math.isfinite(total):
                opt.step()
            else:
                model.zero_grad()
            scaler.update(not math.isfinite(total))
        else:
            nn.clip_grad_norm(model.parameters(), 1.0)
            opt.step()
        if step == w:
            t0 = time.perf_counter()
            tokens = 0
        tokens += batch * cfg.block_size
    tl.synchronize()
    dt = time.perf_counter() - t0
    _be.set_allow_tf32(False)
    del model, opt
    return tokens / dt, float(loss.item())


def run_tl_graph(cfg, data, steps, batch, lr, seed, mode="bf16"):
    """'bf16' or 'fp32' through the CUDA-graphed train step
    (graph_step.GraphedStep): fwd+bwd(+unscale)+norm partials captured
    as graph1, on-device clip + gated device-scalar AdamW as graph2;
    same numerics and protocol as run_tl(mode). fp32 has no
    GradScaler/unscale/found_inf path — lr/wd ride the same 16B
    per-step device-scalar upload (no rebaking, no recapture churn)."""
    import minitriton.device.cuda.ops as _be
    _be.set_allow_tf32(False)
    cfg.bf16 = mode == "bf16"
    rng = np.random.default_rng(seed)
    model = tg.GPT(cfg)
    if cfg.bf16:
        fp32_orig = tg._convert_bf16_(model)
        opt = nn.BF16AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                           weight_decay=0.1, masters=fp32_orig)
        scaler = nn.GradScaler()
    else:
        opt = nn.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                       weight_decay=0.1)
        scaler = None
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from graph_step import GraphedStep
    gs = GraphedStep(model, opt, scaler, clip_norm=1.0)
    x0, y0 = tg.get_batch(data, batch, cfg.block_size, rng)
    gs.prime(x0, y0)  # warmup + capture; consumes no training step
    w = steps // 3  # steady-state window: last 2/3 of steps
    tokens, t0 = 0, time.perf_counter()
    loss = None
    for step in range(steps):
        opt.lr = tg.lr_at(step, steps, lr)
        x, y = (x0, y0) if step == 0 else \
            tg.get_batch(data, batch, cfg.block_size, rng)
        loss = gs.step(x, y)
        if step == w:
            t0 = time.perf_counter()
            tokens = 0
        tokens += batch * cfg.block_size
    tl.synchronize()
    dt = time.perf_counter() - t0
    _be.set_allow_tf32(False)
    del model, opt
    return tokens / dt, float(loss.item())


def run_torch(cfg, data, steps, batch, lr, seed, amp, tf32=False,
              compile_model=False):
    """amp=False -> fp32 eager baseline; amp=True -> bf16 autocast.
    tf32=True -> allow_tf32 matmuls; the global is restored to False
    before returning so it cannot leak into a later torch_fp32 /
    torch_amp run regardless of the --impls order. compile_model=True
    wraps the model in torch.compile (AMP+compile recipe: compiled
    forward, eager autograd/optimizer)."""
    torch.backends.cuda.matmul.allow_tf32 = tf32
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    model = ThGPT(cfg, sdpa=(cfg.block_size >= 512)).cuda()
    if compile_model:
        model = torch.compile(model)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                            weight_decay=0.1, foreach=False)
    w = steps // 3  # steady-state window: last 2/3 of steps
    tokens, t0 = 0, time.perf_counter()
    loss = None
    for step in range(steps):
        lr_t = tg.lr_at(step, steps, lr)
        for g in opt.param_groups:
            g["lr"] = lr_t
        x, y = tg.get_batch(data, batch, cfg.block_size, rng)
        xb = torch.from_numpy(x.astype(np.int64)).cuda()
        yb = torch.from_numpy(y.astype(np.int64)).cuda()
        if amp:
            with torch.autocast("cuda", dtype=torch.bfloat16):
                loss = model(xb, yb)
        else:
            loss = model(xb, yb)
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        if step == w:
            t0 = time.perf_counter()
            tokens = 0
        tokens += batch * cfg.block_size
    torch.cuda.synchronize()
    dt = time.perf_counter() - t0
    torch.backends.cuda.matmul.allow_tf32 = False
    del model, opt
    torch.cuda.empty_cache()
    return tokens / dt, float(loss.item())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=60)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--blocks", type=int, nargs="+",
                    default=[256, 512, 768, 1024])
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=1337)
    ap.add_argument("--impls", type=str, nargs="+",
                    default=["tl_fp32", "tl_tf32", "tl_bf16",
                             "torch_fp32", "torch_tf32", "torch_amp"])
    args = ap.parse_args()

    repo = Path(__file__).resolve().parents[2]
    data, vocab, _ = tg.load_corpus(repo / "minitriton")

    print(f"gpt50m ({GPT['n_layer']}L {GPT['n_embd']}d {GPT['n_head']}H, "
          f"vocab {vocab}), batch {args.batch_size} "
          f"(B16 at T1024), {args.steps} steps, steady = last 2/3; "
          f"GPU: {torch.cuda.get_device_name(0)}\n")

    rows = []
    hdr = (f"{'impl':<12} {'T':>5} {'batch':>5} {'tok/s':>10} "
           f"{'ms/step':>9} {'loss':>8} {'vs torch_fp32':>14}")
    print(hdr)
    print("-" * len(hdr))
    for blk in args.blocks:
        batch = args.batch_size if blk <= 768 else min(16, args.batch_size)
        cfg = _cfg(vocab, blk)
        res = {}
        for impl in args.impls:
            if impl == "tl_fp32":
                tps, loss = run_tl(cfg, data, args.steps, batch, args.lr,
                                   args.seed, "fp32")
            elif impl == "tl_tf32":
                tps, loss = run_tl(cfg, data, args.steps, batch, args.lr,
                                   args.seed, "tf32")
            elif impl == "tl_bf16":
                tps, loss = run_tl(cfg, data, args.steps, batch, args.lr,
                                   args.seed, "bf16")
            elif impl == "tl_bf16_graph":
                tps, loss = run_tl_graph(cfg, data, args.steps, batch,
                                         args.lr, args.seed, "bf16")
            elif impl == "tl_fp32_graph":
                tps, loss = run_tl_graph(cfg, data, args.steps, batch,
                                         args.lr, args.seed, "fp32")
            elif impl == "torch_fp32":
                tps, loss = run_torch(cfg, data, args.steps, batch,
                                      args.lr, args.seed, amp=False)
            elif impl == "torch_tf32":
                tps, loss = run_torch(cfg, data, args.steps, batch,
                                      args.lr, args.seed, amp=False,
                                      tf32=True)
            elif impl == "torch_amp":
                tps, loss = run_torch(cfg, data, args.steps, batch,
                                      args.lr, args.seed, amp=True)
            elif impl == "torch_compile_amp":
                tps, loss = run_torch(cfg, data, args.steps, batch,
                                      args.lr, args.seed, amp=True,
                                      compile_model=True)
            elif impl == "torch_compile_tf32":
                tps, loss = run_torch(cfg, data, args.steps, batch,
                                      args.lr, args.seed, amp=False,
                                      tf32=True, compile_model=True)
            else:
                raise ValueError(f"unknown impl {impl}")
            # between-model memory hygiene: the pooled allocator's
            # per-class retention otherwise accumulates every transient
            # size seen across the impl×block matrix and OOMs the tail
            # blocks; pinned graph buffers are not in the free lists
            from minitriton.runtime import allocator as _mt_alloc
            _mt_alloc.release_all_free()
            if impl.startswith("torch"):
                torch.cuda.empty_cache()
            res[impl] = tps
            rows.append((impl, blk, batch, tps, loss))
            print(f"{impl:<12} {blk:>5} {batch:>5} {tps / 1e3:>9.1f}K "
                  f"{batch * blk / tps * 1e3:>8.1f} {loss:>8.4f} "
                  f"{res[impl] / res.get('torch_fp32', res[impl]):>13.2f}x")

    # merge with the previous run's rows (dedupe by impl x block) BEFORE
    # opening for write (which truncates)
    existing = {}
    if OUT_CSV.exists():
        import csv as csvmod
        for r in csvmod.reader(OUT_CSV.open()):
            if r and not r[0].startswith("#") and r[0] != "impl":
                existing[(r[0], int(r[1]))] = r
    for impl, blk, batch, tps, loss in rows:
        existing[(impl, blk)] = (impl, f"{blk}", f"{batch}",
                                 f"{tps:.1f}",
                                 f"{batch * blk / tps * 1e3:.3f}",
                                 f"{loss:.6f}")

    with OUT_CSV.open("w") as f:
        f.write("# gpt50m precision-tier train-step throughput, "
                "steady-state (last 2/3 steps)\n")
        f.write(f"# config L{GPT['n_layer']}D{GPT['n_embd']}H{GPT['n_head']}"
                f" vocab {vocab}, steps {args.steps}, lr {args.lr}, "
                f"seed {args.seed}\n")
        f.write("impl,block,batch,tok_per_s,ms_per_step,final_loss\n")
        for (impl, blk), r in sorted(existing.items(),
                                     key=lambda kv: (kv[0][1], kv[0][0])):
            f.write(",".join(r) + "\n")
    print(f"\nwrote {OUT_CSV}")


if __name__ == "__main__":
    main()
