#!/usr/bin/env python
"""Gradient check: minitriton autograd vs torch autograd.

Runs a suite of forward+backward scenarios through both frameworks on
identical inputs and compares forward outputs and every leaf gradient
per tensor (atol 1e-4, fp32, CUDA). torch is used here ONLY as the
reference oracle (tests/ stays torch-free).

    CUDA_VISIBLE_DEVICES=1 python benchmarks/training/grad_check.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import nn

import torch
import torch.nn.functional as tF

assert torch.cuda.is_available(), "grad_check needs a CUDA GPU"

rng = np.random.default_rng(0)
DEV = "cuda"
ATOL = 1e-4

RESULTS = []


def rn(*shape, std=1.0):
    return (rng.standard_normal(shape) * std).astype(np.float32)


def check(label, tl_t, torch_t, atol=ATOL):
    a = tl_t.numpy() if isinstance(tl_t, tl.Tensor) else np.asarray(tl_t)
    b = torch_t.detach().cpu().numpy()
    assert a.shape == b.shape, f"{label}: shape {a.shape} vs {b.shape}"
    diff = float(np.max(np.abs(a - b))) if a.size else 0.0
    ok = diff < atol
    RESULTS.append((label, diff, ok))
    return ok


def pair(arr, requires_grad=True):
    """Same numpy array as (tl tensor, torch tensor) leaf pair."""
    return (tl.tensor(arr, device=DEV, requires_grad=requires_grad),
            torch.from_numpy(arr).to(DEV).requires_grad_(requires_grad))


# ---------------------------------------------------------------------------
# op-level scenarios
# ---------------------------------------------------------------------------

def s_binary():
    a1, a2 = pair(rn(4, 8, std=0.5))
    b1, b2 = pair(rn(8, std=0.5))
    g1, g2 = pair(rn(4, 8), requires_grad=False)
    x = (a1 * b1 + 1.5) / tl.exp(tl.abs(a1 - b1))
    y = (a2 * b2 + 1.5) / (a2 - b2).abs().exp()
    x.backward(g1)
    y.backward(g2)
    check("binary.fwd", x, y)
    check("binary.da", a1.grad, a2.grad)
    check("binary.db", b1.grad, b2.grad)


def s_unary():
    a1, a2 = pair(rn(4, 16, std=0.7))
    g1, g2 = pair(rn(4, 16), requires_grad=False)
    # our gelu is the tanh approximation — compare against torch's tanh mode
    x = tl.silu(tl.gelu(tl.tanh(a1 * 0.5))) + tl.sigmoid(a1)
    y = tF.silu(tF.gelu(torch.tanh(a2 * 0.5), approximate="tanh")) \
        + torch.sigmoid(a2)
    x.backward(g1)
    y.backward(g2)
    check("unary.fwd", x, y)
    check("unary.da", a1.grad, a2.grad)


def s_matmul():
    a1, a2 = pair(rn(8, 32, std=0.5))
    w1, w2 = pair(rn(32, 24, std=0.3))
    b1, b2 = pair(rn(24, std=0.3))
    g1, g2 = pair(rn(8, 24), requires_grad=False)
    x = tl.matmul(a1, w1) + b1
    y = a2 @ w2 + b2
    x.backward(g1)
    y.backward(g2)
    check("matmul.fwd", x, y)
    check("matmul.da", a1.grad, a2.grad)
    check("matmul.dw", w1.grad, w2.grad)
    check("matmul.db", b1.grad, b2.grad)


def s_bmm():
    a1, a2 = pair(rn(4, 8, 16, std=0.4))
    b1, b2 = pair(rn(4, 16, 8, std=0.4))
    g1, g2 = pair(rn(4, 8, 8), requires_grad=False)
    tl.bmm(a1, b1).backward(g1)
    torch.bmm(a2, b2).backward(g2)
    check("bmm.da", a1.grad, a2.grad)
    check("bmm.db", b1.grad, b2.grad)


def s_matmul_fold():
    """(B,T,K) @ (K,N): the 2D-fold path used by Linear on sequences."""
    a1, a2 = pair(rn(2, 8, 16, std=0.4))
    w1, w2 = pair(rn(16, 24, std=0.3))
    g1, g2 = pair(rn(2, 8, 24), requires_grad=False)
    tl.matmul(a1, w1).backward(g1)
    (a2 @ w2).backward(g2)
    check("mmfold.fwd", tl.matmul(a1, w1), a2 @ w2)
    check("mmfold.da", a1.grad, a2.grad)
    check("mmfold.dw", w1.grad, w2.grad)


def s_reductions():
    a1, a2 = pair(rn(4, 8, std=0.8))
    g = rn(4)
    x, y = a1.sum(dim=1), a2.sum(dim=1)
    x.backward(tl.tensor(g, device=DEV))
    y.backward(torch.from_numpy(g).to(DEV))
    check("sum.da", a1.grad, a2.grad)
    a1.grad = a2.grad = None
    x, y = a1.mean(), a2.mean()
    x.backward()
    y.backward()
    check("mean.da", a1.grad, a2.grad)
    a1.grad = a2.grad = None
    g0 = rn(8)
    x, y = a1.max(dim=0), a2.max(dim=0).values
    x.backward(tl.tensor(g0, device=DEV))
    y.backward(torch.from_numpy(g0).to(DEV))
    check("max.da", a1.grad, a2.grad)


def s_softmax():
    a1, a2 = pair(rn(8, 32, std=1.2))
    g1, g2 = pair(rn(8, 32), requires_grad=False)
    x = tl.softmax(a1 * 1.3, dim=-1)
    y = torch.softmax(a2 * 1.3, dim=-1)
    x.backward(g1)
    y.backward(g2)
    check("softmax.fwd", x, y)
    check("softmax.da", a1.grad, a2.grad)
    a1.grad = a2.grad = None
    x = tl.log_softmax(a1, dim=-1)
    y = torch.log_softmax(a2, dim=-1)
    x.backward(g1)
    y.backward(g2)
    check("log_softmax.fwd", x, y)
    check("log_softmax.da", a1.grad, a2.grad)


def s_norms():
    a1, a2 = pair(rn(8, 32, std=1.5))
    w1, w2 = pair(rn(32, std=0.5))
    b1, b2 = pair(rn(32, std=0.5))
    g1, g2 = pair(rn(8, 32), requires_grad=False)
    x = tl.layer_norm(a1, (32,), w1, b1, 1e-5)
    y = tF.layer_norm(a2, (32,), w2, b2, 1e-5)
    x.backward(g1)
    y.backward(g2)
    check("layernorm.fwd", x, y)
    check("layernorm.da", a1.grad, a2.grad)
    check("layernorm.dw", w1.grad, w2.grad)
    check("layernorm.db", b1.grad, b2.grad)
    a1.grad = a2.grad = w1.grad = w2.grad = None
    x = tl.rms_norm(a1, (32,), w1, 1e-6)
    yr = a2 * torch.rsqrt(a2.pow(2).mean(-1, keepdim=True) + 1e-6) * w2
    x.backward(g1)
    yr.backward(g2)
    check("rmsnorm.fwd", x, yr)
    check("rmsnorm.da", a1.grad, a2.grad)
    check("rmsnorm.dw", w1.grad, w2.grad)


def s_embedding():
    w1, w2 = pair(rn(16, 8, std=0.5))
    idx_np = np.array([1, 4, 4, 9, 1, 15, 4], dtype=np.int64)
    i1 = tl.tensor(idx_np, device=DEV)
    i2 = torch.from_numpy(idx_np).to(DEV)
    g1, g2 = pair(rn(7, 8), requires_grad=False)
    x = tl.embedding(w1, i1)
    y = tF.embedding(i2, w2)
    x.backward(g1)
    y.backward(g2)
    check("embedding.fwd", x, y)
    check("embedding.dw", w1.grad, w2.grad)


def s_cross_entropy():
    a1, a2 = pair(rn(8, 24, std=1.5))
    t_np = np.array([0, 3, 5, 2, 23, 11, 7, 1], dtype=np.int64)
    t1 = tl.tensor(t_np, device=DEV)
    t2 = torch.from_numpy(t_np).to(DEV)
    x = tl.cross_entropy(a1, t1)
    y = tF.cross_entropy(a2, t2)
    x.backward()
    y.backward()
    check("ce.fwd", x, y)
    check("ce.da", a1.grad, a2.grad)
    a1.grad = a2.grad = None
    x = tl.cross_entropy(a1, t1, reduction="sum")
    y = tF.cross_entropy(a2, t2, reduction="sum")
    x.backward()
    y.backward()
    check("ce_sum.da", a1.grad, a2.grad)


def s_views():
    a1, a2 = pair(rn(2, 4, 8, std=0.7))
    b1, b2 = pair(rn(2, 4, 8, std=0.7))
    g1, g2 = pair(rn(2, 8, 3, 2), requires_grad=False)
    x = tl.cat([a1.permute(0, 2, 1), b1[:, ::2].permute(0, 2, 1)], dim=2) \
        .reshape(2, 8, 3, 2)
    y = torch.cat([a2.permute(0, 2, 1), b2[:, ::2].permute(0, 2, 1)], dim=2) \
        .reshape(2, 8, 3, 2)
    x.backward(g1)
    y.backward(g2)
    check("views.fwd", x, y)
    check("views.da", a1.grad, a2.grad)
    check("views.db", b1.grad, b2.grad)


# ---------------------------------------------------------------------------
# nn-level scenarios
# ---------------------------------------------------------------------------

def _copy_params(tl_mod, torch_mod, seed=0):
    """Init torch module with tl module's numpy weights (same values)."""
    with torch.no_grad():
        for p_tl, p_th in zip(tl_mod.parameters(), torch_mod.parameters()):
            p_th.copy_(torch.from_numpy(p_tl.numpy()))


def s_gpt_block():
    d, h = 32, 4

    class TlBlock(nn.Module):
        def __init__(self):
            super().__init__()
            self.ln1 = nn.LayerNorm(d, device=DEV)
            self.attn = nn.CausalSelfAttention(d, h, fused=False,
                                               device=DEV, seed=1)
            self.ln2 = nn.LayerNorm(d, device=DEV)
            self.fc1 = nn.Linear(d, 4 * d, device=DEV, seed=2)
            self.fc2 = nn.Linear(4 * d, d, device=DEV, seed=3)

        def forward(self, x):
            x = x + self.attn(self.ln1(x))
            return x + self.fc2(tl.gelu(self.fc1(self.ln2(x))))

    class ThBlock(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.ln1 = torch.nn.LayerNorm(d, device=DEV)
            self.attn = torch.nn.MultiheadAttention(
                d, h, batch_first=True, device=DEV)
            self.ln2 = torch.nn.LayerNorm(d, device=DEV)
            self.fc1 = torch.nn.Linear(d, 4 * d, device=DEV)
            self.fc2 = torch.nn.Linear(4 * d, d, device=DEV)

        def forward(self, x):
            t = x.shape[1]
            mask = torch.triu(torch.full((t, t), -1e9, device=DEV), 1)
            a, _ = self.attn(self.ln1(x), self.ln1(x), self.ln1(x),
                             attn_mask=mask, need_weights=False)
            x = x + a
            return x + self.fc2(tF.gelu(self.fc1(self.ln2(x))))

    tl_mod, th_mod = TlBlock(), ThBlock()
    # map weights manually (MultiheadAttention packs qkv)
    with torch.no_grad():
        p = tl_mod
        th_mod.ln1.weight.copy_(torch.from_numpy(p.ln1.weight.numpy()))
        th_mod.ln1.bias.copy_(torch.from_numpy(p.ln1.bias.numpy()))
        th_mod.ln2.weight.copy_(torch.from_numpy(p.ln2.weight.numpy()))
        th_mod.ln2.bias.copy_(torch.from_numpy(p.ln2.bias.numpy()))
        qkv_w = p.attn.c_attn.weight.numpy()
        qkv_b = p.attn.c_attn.bias.numpy()
        th_mod.attn.in_proj_weight.copy_(torch.from_numpy(qkv_w))
        th_mod.attn.in_proj_bias.copy_(torch.from_numpy(qkv_b))
        th_mod.attn.out_proj.weight.copy_(
            torch.from_numpy(p.attn.c_proj.weight.numpy()))
        th_mod.attn.out_proj.bias.copy_(
            torch.from_numpy(p.attn.c_proj.bias.numpy()))
        th_mod.fc1.weight.copy_(torch.from_numpy(p.fc1.weight.numpy()))
        th_mod.fc1.bias.copy_(torch.from_numpy(p.fc1.bias.numpy()))
        th_mod.fc2.weight.copy_(torch.from_numpy(p.fc2.weight.numpy()))
        th_mod.fc2.bias.copy_(torch.from_numpy(p.fc2.bias.numpy()))

    x_np = rn(2, 8, d, std=0.8)
    x1, x2 = pair(x_np)
    y1 = tl_mod(x1)
    y2 = th_mod(x2)
    check("gptblock.fwd_out", y1, y2)
    loss1 = (y1 * y1).mean()
    loss2 = (y2 * y2).mean()
    loss1.backward()
    loss2.backward()
    check("gptblock.fwd", loss1, loss2)
    check("gptblock.dx", x1.grad, x2.grad)
    found = dict(_named_th(th_mod))
    for name, p_tl in _named(tl_mod):
        p_th = found[name]
        if p_tl.grad is None:
            RESULTS.append((f"gptblock.d[{name}]", float("nan"), False))
            continue
        check(f"gptblock.d[{name}]", p_tl.grad, p_th.grad)


def _named(mod, prefix=""):
    for name, p in mod._parameters.items():
        yield prefix + name, p
    for name, m in mod._modules.items():
        yield from _named(m, prefix + name + ".")


def _named_th(mod):
    for name, p in mod.named_parameters():
        tr = {"ln1.weight": "ln1.weight", "ln1.bias": "ln1.bias",
              "ln2.weight": "ln2.weight", "ln2.bias": "ln2.bias",
              "attn.in_proj_weight": "attn.c_attn.weight",
              "attn.in_proj_bias": "attn.c_attn.bias",
              "attn.out_proj.weight": "attn.c_proj.weight",
              "attn.out_proj.bias": "attn.c_proj.bias",
              "fc1.weight": "fc1.weight", "fc1.bias": "fc1.bias",
              "fc2.weight": "fc2.weight", "fc2.bias": "fc2.bias"}
        yield tr.get(name, name), p


def s_flash_attention():
    """Fused fwd + composite bwd vs torch explicit attention."""
    B, H, T, hd = 2, 3, 128, 64
    scale = 1.0 / np.sqrt(hd)
    q1, q2 = pair(rn(B, H, T, hd, std=0.8))
    k1, k2 = pair(rn(B, H, T, hd, std=0.8))
    v1, v2 = pair(rn(B, H, T, hd, std=0.8))
    g1, g2 = pair(rn(B, H, T, hd), requires_grad=False)
    out1 = nn.causal_attention(q1, k1, v1, scale=scale, fused=True)
    mask = torch.triu(torch.full((T, T), -1e9, device=DEV), 1)
    s = (q2 @ k2.transpose(-2, -1)) * scale + mask
    out2 = torch.softmax(s, dim=-1) @ v2
    out1.backward(g1)
    out2.backward(g2)
    check("flash.fwd", out1, out2)
    check("flash.dq", q1.grad, q2.grad)
    check("flash.dk", k1.grad, k2.grad)
    check("flash.dv", v1.grad, v2.grad)


def s_adamw():
    p_np = rn(4, 8, std=0.5)
    p1 = nn.Parameter(p_np, device=DEV)
    p2 = torch.from_numpy(p_np).to(DEV).requires_grad_(True)
    o1 = nn.AdamW([p1], lr=0.05, betas=(0.9, 0.95), eps=1e-8,
                  weight_decay=0.1)
    o2 = torch.optim.AdamW([p2], lr=0.05, betas=(0.9, 0.95), eps=1e-8,
                           weight_decay=0.1, foreach=False)
    for _ in range(3):
        g = rn(4, 8)
        p1.grad = tl.tensor(g, device=DEV)
        p2.grad = torch.from_numpy(g).to(DEV)
        o1.step()
        o2.step()
    check("adamw.p", p1, p2)


def main():
    torch.backends.cuda.matmul.allow_tf32 = False
    scenarios = [
        ("binary elementwise", s_binary),
        ("unary chain", s_unary),
        ("matmul+bias", s_matmul),
        ("bmm", s_bmm),
        ("matmul (B,T,K)@(K,N) fold", s_matmul_fold),
        ("reductions", s_reductions),
        ("softmax/log_softmax", s_softmax),
        ("layer/rms norm", s_norms),
        ("embedding", s_embedding),
        ("cross_entropy", s_cross_entropy),
        ("views (permute/slice/cat)", s_views),
        ("GPT block e2e", s_gpt_block),
        ("flash attention", s_flash_attention),
        ("AdamW 3 steps", s_adamw),
    ]
    print(f"device: cuda ({torch.cuda.get_device_name(0)}), fp32, "
          f"atol={ATOL}; torch {torch.__version__}\n")
    for name, fn in scenarios:
        before = len(RESULTS)
        fn()
        worst = max((d for _, d, _ in RESULTS[before:]), default=0.0)
        ok = all(o for _, _, o in RESULTS[before:])
        print(f"{'PASS' if ok else 'FAIL'}  {name:<28} "
              f"(worst |diff| {worst:.2e})")
    n_bad = sum(1 for _, _, o in RESULTS if not o)
    print(f"\n{len(RESULTS) - n_bad}/{len(RESULTS)} tensor checks within "
          f"atol={ATOL}")
    if n_bad:
        print("\nfailing checks:")
        for label, d, o in RESULTS:
            if not o:
                print(f"  {label}: |diff| {d:.3e}")
        sys.exit(1)
    print("ALL GRAD CHECKS PASS")


if __name__ == "__main__":
    main()
