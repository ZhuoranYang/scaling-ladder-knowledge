#!/usr/bin/env python
"""flash-attention mma benchmark: minitriton tensor-core flash
forward (tf32 / bf16) vs the tl fp32-FMA flash kernel vs triton same-tier
flash (input_precision="tf32" / bf16 operands) vs torch sdpa (reference).
Same do_bench (CUDA events + L2 flush) everywhere.

Tiers are benchmarked separately (never mixed into one geomean), like
mma_report.py. Gate (calibrated on L20): >= 0.85x Triton same-tier
timing on the big shapes (T >= 1024).

    CUDA_VISIBLE_DEVICES=1 python benchmarks/roofline/attention_mma_report.py
"""

import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import do_bench, ops as tl_ops

import torch
import triton
import triton.language as tll

sys.path.insert(0, str(Path(__file__).resolve().parent))
import plot_style as ps

torch.backends.cuda.matmul.allow_tf32 = False

# gate threshold calibrated on L20 (sm_89): T>=1024 shapes measure
# ~0.88-0.95 across runs (bf16 T1024 is the worst); 0.85 leaves a
# small margin under the worst observed shape
_BIG_T_GATE = 0.85


# ---------------------------------------------------------------------------
# triton flash attention forward (causal), one kernel per tier
# ---------------------------------------------------------------------------

@triton.jit
def _tri_flash_fwd(Q, K, V, O, T, scale,
                   HD: tll.constexpr, BM: tll.constexpr, BN: tll.constexpr,
                   PREC: tll.constexpr):
    pid_m = tll.program_id(0)
    bh = tll.program_id(1)
    q0 = pid_m * BM
    offs_m = q0 + tll.arange(0, BM)
    offs_n = tll.arange(0, BN)
    offs_d = tll.arange(0, HD)
    q = tll.load(Q + bh * T * HD + offs_m[:, None] * HD + offs_d[None, :],
                 mask=offs_m[:, None] < T, other=0.0)
    m_i = tll.full((BM,), -float("inf"), tll.float32)
    l_i = tll.zeros((BM,), tll.float32)
    acc = tll.zeros((BM, HD), tll.float32)
    for k0 in range(0, q0 + BM, BN):
        kmask = (k0 + offs_n)[:, None] < T
        k = tll.load(K + bh * T * HD + (k0 + offs_n)[:, None] * HD
                     + offs_d[None, :], mask=kmask, other=0.0)
        s = tll.dot(q, tll.trans(k), input_precision=PREC) * scale
        s = tll.where(offs_m[:, None] >= (k0 + offs_n)[None, :], s, -1e9)
        m_new = tll.maximum(m_i, tll.max(s, 1))
        p = tll.exp(s - m_new[:, None])
        alpha = tll.exp(m_i - m_new)
        l_i = l_i * alpha + tll.sum(p, 1)
        acc = acc * alpha[:, None]
        v = tll.load(V + bh * T * HD + (k0 + offs_n)[:, None] * HD
                     + offs_d[None, :], mask=kmask, other=0.0)
        acc = tll.dot(p.to(v.dtype), v, acc)
        m_i = m_new
    o = acc / l_i[:, None]
    tll.store(O + bh * T * HD + offs_m[:, None] * HD + offs_d[None, :],
              o.to(O.dtype.element_ty), mask=offs_m[:, None] < T)


_TRI_CONFIGS = [
    (64, 64, 4, 2), (64, 64, 4, 3), (128, 64, 4, 3), (128, 64, 8, 2),
    (64, 32, 4, 2), (32, 64, 4, 2), (128, 64, 8, 3), (128, 128, 8, 2),
]


def tri_flash(q, k, v, scale, prec, cfg):
    B, H, T, HD = q.shape
    BM, BN, warps, stages = cfg
    o = torch.empty_like(q)
    grid = (triton.cdiv(T, BM), B * H)
    _tri_flash_fwd[grid](q, k, v, o, T, scale, HD=HD, BM=BM, BN=BN, PREC=prec,
                         num_warps=warps, num_stages=stages)
    return o


def tri_best(q, k, v, scale, prec):
    best = None
    for cfg in _TRI_CONFIGS:
        try:
            fn = lambda: tri_flash(q, k, v, scale, prec, cfg)
            fn()
            torch.cuda.synchronize()
            ms = do_bench(fn)
        except Exception:
            continue
        if best is None or ms < best[1]:
            best = (cfg, ms)
    cfg, ms = best
    return (lambda: tri_flash(q, k, v, scale, prec, cfg)), ms, cfg


# ---------------------------------------------------------------------------

def bench_shape(B, H, T, HD=64):
    rng = np.random.default_rng(0)
    qn, kn, vn = (rng.standard_normal((B, H, T, HD)).astype(np.float32)
                  for _ in range(3))
    scale = 1.0 / np.sqrt(HD)
    flops = 2.0 * B * H * T * T * HD  # causal fwd (halved from the full 4x)
    tf = lambda ms: flops / ms * 1e-9
    row = {"shape": f"B{B} H{H} T{T} d{HD}", "T": T}

    # -- tl fp32 FMA (same for both tiers) ----------------
    tq, tk, tv = (tl.tensor(x) for x in (qn, kn, vn))
    with tl.no_grad():
        tl_ops.flash_attention_forward(tq, tk, tv, scale, precision="fp32")
    tl_f32 = lambda: tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                                    precision="fp32")
    tl_f32()
    tl.synchronize()
    row["tl_f32_ms"] = do_bench(tl_f32)

    # -- tl tf32 ------------------------------------------------------------
    with tl.no_grad():
        out_tf32 = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                                  precision="tf32")
    tl_tf32 = lambda: tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                                     precision="tf32")
    tl_tf32()
    tl.synchronize()
    row["tl_tf32_ms"] = do_bench(tl_tf32)

    # -- tl bf16 ------------------------------------------------------------
    bq, bk, bv = (tl.tensor(x).astype(tl.bfloat16) for x in (qn, kn, vn))
    with tl.no_grad():
        out_bf16 = tl_ops.flash_attention_forward(bq, bk, bv, scale)
    tl_bf16 = lambda: tl_ops.flash_attention_forward(bq, bk, bv, scale)
    tl_bf16()
    tl.synchronize()
    row["tl_bf16_ms"] = do_bench(tl_bf16)

    # -- triton tf32 (f32 tensors, input_precision="tf32") ------------------
    qq, kk, vv = (torch.from_numpy(x).cuda() for x in (qn, kn, vn))
    tri_tf32_fn, row["tri_tf32_ms"], row["tri_tf32_cfg"] = tri_best(
        qq, kk, vv, scale, "tf32")
    out_tri_tf32 = tri_tf32_fn()
    row["err_tf32"] = float(np.max(np.abs(
        out_tf32.numpy() - out_tri_tf32.cpu().numpy())))

    # -- triton bf16 (bf16 tensors) ------------------------------------------
    qb, kb, vb = (x.bfloat16() for x in (qq, kk, vv))
    tri_bf16_fn, row["tri_bf16_ms"], row["tri_bf16_cfg"] = tri_best(
        qb, kb, vb, scale, "tf32")  # PREC unused for bf16 operands
    out_tri_bf16 = tri_bf16_fn()
    row["err_bf16"] = float(np.max(np.abs(
        out_bf16.astype(tl.float32).numpy()
        - out_tri_bf16.float().cpu().numpy())))

    # -- torch sdpa (reference column) ---------------------------------------
    row["sdpa_tf32_ms"] = float("nan")
    row["sdpa_bf16_ms"] = float("nan")
    row["sdpac_tf32_ms"] = float("nan")
    row["sdpac_bf16_ms"] = float("nan")
    try:
        torch.backends.cuda.matmul.allow_tf32 = True
        sdpa_tf32 = lambda: torch.nn.functional.scaled_dot_product_attention(
            qq, kk, vv, is_causal=True)
        sdpa_tf32()
        torch.cuda.synchronize()
        row["sdpa_tf32_ms"] = do_bench(sdpa_tf32)
        sdpa_c = torch.compile(
            lambda q, k, v:
            torch.nn.functional.scaled_dot_product_attention(q, k, v,
                                                             is_causal=True))
        sdpa_c(qq, kk, vv)
        torch.cuda.synchronize()
        row["sdpac_tf32_ms"] = do_bench(lambda: sdpa_c(qq, kk, vv))
        torch.backends.cuda.matmul.allow_tf32 = False
        sdpa_bf16 = lambda: torch.nn.functional.scaled_dot_product_attention(
            qb, kb, vb, is_causal=True)
        sdpa_bf16()
        torch.cuda.synchronize()
        row["sdpa_bf16_ms"] = do_bench(sdpa_bf16)
        sdpa_c(qb, kb, vb)  # recompiles for the bf16 dtype
        torch.cuda.synchronize()
        row["sdpac_bf16_ms"] = do_bench(lambda: sdpa_c(qb, kb, vb))
    except Exception as e:
        print(f"  (torch sdpa unavailable: {e})")
    finally:
        torch.backends.cuda.matmul.allow_tf32 = False

    for k_ in list(row):
        if k_.endswith("_ms") and row[k_] == row[k_]:
            row[k_.replace("_ms", "_tf")] = tf(row[k_])
    return row


def fmt_cfg(cfg):
    return f"BM{cfg[0]} BN{cfg[1]} w{cfg[2]} s{cfg[3]}"


def main():
    shapes = [(8, 12, 256), (8, 12, 512), (8, 12, 1024), (4, 8, 2048)]
    rows = [bench_shape(B, H, T) for B, H, T in shapes]

    print("causal flash-attention FORWARD, tensor-core tiers; triton same-tier"
          " (tf32: input_precision='tf32'; bf16: bf16 operands), same "
          "do_bench\n")
    hdr = (f"{'shape':>18} | {'impl':>12} | {'ms':>8} | {'TF/s':>8} | "
           f"{'vs triton':>9}")
    tier_ok = {}
    for tier, tl_ms, tri_ms, sdpa_ms, err in (
            ("tf32", "tl_tf32_ms", "tri_tf32_ms", "sdpa_tf32_ms", "err_tf32"),
            ("bf16", "tl_bf16_ms", "tri_bf16_ms", "sdpa_bf16_ms", "err_bf16")):
        print(f"== {tier} tier ==")
        print(hdr)
        ratios = []
        big_ok = True
        for r in rows:
            line = (f"{r['shape']:>18} | {'tl ' + tier:>12} | {r[tl_ms]:8.3f}"
                    f" | {r[tl_ms.replace('_ms', '_tf')]:8.2f} | "
                    f"{r[tri_ms] / r[tl_ms]:9.2f}")
            print(line)
            print(f"{'':>18} | {'triton':>12} | {r[tri_ms]:8.3f} | "
                  f"{r[tri_ms.replace('_ms', '_tf')]:8.2f} | {'':>9} "
                  f"cfg {fmt_cfg(r[tri_ms.replace('ms', 'cfg')])}")
            if r[sdpa_ms] == r[sdpa_ms]:
                print(f"{'':>18} | {'torch sdpa':>12} | {r[sdpa_ms]:8.3f} | "
                      f"{r[sdpa_ms.replace('_ms', '_tf')]:8.2f} |")
            print(f"{'':>18} | {'tl fp32-FMA':>12} | {r['tl_f32_ms']:8.3f} | "
                  f"{r['tl_f32_tf']:8.2f} |")
            ratios.append(r[tri_ms] / r[tl_ms])
            if r["T"] >= 1024 and ratios[-1] < _BIG_T_GATE:
                big_ok = False
        tier_ok[tier] = big_ok
        g = float(np.exp(np.mean(np.log(ratios))))
        worst = max(r[err] for r in rows)
        print(f"geomean tl/triton {tier}: {g:.2f}  (gate >= "
              f"{_BIG_T_GATE:.2f} on T>=1024, calibrated on L20: "
              f"{'PASS' if big_ok else 'FAIL'}; worst fwd |err| vs "
              f"triton {worst:.2e})\n")

    # -- CSV ------------------------------------------------------------------
    csv_path = Path(__file__).with_name("attention_mma.csv")
    fields = ["shape", "T", "tl_f32_ms", "tl_f32_tf",
              "tl_tf32_ms", "tl_tf32_tf", "tri_tf32_ms", "tri_tf32_tf",
              "sdpa_tf32_ms", "sdpa_tf32_tf", "sdpac_tf32_ms",
              "sdpac_tf32_tf", "err_tf32",
              "tl_bf16_ms", "tl_bf16_tf", "tri_bf16_ms", "tri_bf16_tf",
              "sdpa_bf16_ms", "sdpa_bf16_tf", "sdpac_bf16_ms",
              "sdpac_bf16_tf", "err_bf16"]
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields,
                           extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"wrote {csv_path}")

    # -- figure: x = T, y = TF/s, one line per impl (two tier panels) --------
    import matplotlib.pyplot as plt
    ps.apply()
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.6), facecolor=ps.BG)
    fig.subplots_adjust(wspace=0.22, top=0.78)
    for ax in axes:
        ax.set_facecolor(ps.BG)
    ts = [r["T"] for r in rows]
    series = {
        "tf32": [("tl tf32", "minitriton", "tl_tf32_tf", "o"),
                 ("triton tf32", "triton", "tri_tf32_tf", "s"),
                 ("torch sdpa (tf32)", "torch_eager", "sdpa_tf32_tf", "^")],
        "bf16": [("tl bf16", "minitriton", "tl_bf16_tf", "o"),
                 ("triton bf16", "triton", "tri_bf16_tf", "s"),
                 ("torch sdpa (bf16)", "torch_eager", "sdpa_bf16_tf", "^")],
    }
    for ax, (tier, lines) in zip(axes, series.items()):
        for name, key, col, marker in lines:
            ys = [r.get(col, float("nan")) for r in rows]
            color = ps.IMPL_COLORS[key]
            lw = 2.6 if key == ps.HERO else 1.6
            ms_ = 8 if key == ps.HERO else 5.5
            ax.plot(ts, ys, color=color, lw=lw, marker=marker, ms=ms_,
                    label=name, zorder=5 if key == ps.HERO else 3,
                    alpha=1.0 if key == ps.HERO else 0.85)
        ax.set_xscale("log", base=2)
        ax.set_xticks(ts, [str(t) for t in ts])
        ax.set_xlabel("sequence length T")
        ax.set_ylabel("TFLOP/s")
        ps.style_ax(ax, minor=False)
        ax.legend(fontsize=9, facecolor=ps.PANEL, edgecolor=ps.EDGE,
                  loc="lower right")
        ax.set_title(f"{tier} tier", fontsize=12, color=ps.TXT, loc="left",
                     pad=8)
    gpu = torch.cuda.get_device_name(0)
    cap = torch.cuda.get_device_capability(0)
    fig.text(0.008, 0.965, "flash attention forward — tensor-core mma tiers",
             fontsize=15.5, fontweight="bold", color=ps.TXT, va="top")
    fig.text(0.008, 0.885,
             "minitriton tl.flash_attention_fwd_mma vs triton same-tier vs "
             "torch sdpa · causal, head dim 64 · B8 H12 (T2048: B4 H8) · "
             f"{gpu} sm_{cap[0]}{cap[1]}",
             fontsize=10.5, color=ps.MUT, va="top")
    ps.footnote(fig, "FLOPs = 2·B·H·T²·d (causal fwd, halved)"
                     " · same do_bench (CUDA events + L2 flush)")
    png_path = Path(__file__).with_name("attention_mma.png")
    ps.save(fig, png_path)

    # the report artifacts (csv/png) are written either way; the exit code
    # carries the gate verdict
    if not all(tier_ok.values()):
        sys.exit(1)


if __name__ == "__main__":
    main()
