#!/usr/bin/env python
"""Export roofline benchmark data to benchmarks/roofline/roofline_data.csv.

The CUDA-core roofline figure (benchmarks/roofline/roofline_cuda_core.py)
consumes this CSV; this script is the data source. It re-measures everything
with the exact same routines/conventions and writes one CSV row per
(kernel, shape, implementation) point, plus machine-calibration metadata
as `#` comment lines at the top of the file.

Rows
----
- matmul / softmax / vecadd: from report.collect_results() (read-only
  import; same shapes, same do_bench timing as benchmarks/roofline/report.py).
- flash_attn (causal fwd): from roofline.collect_attention() (imported
  from benchmarks/roofline/roofline.py; if that import breaks, inlined
  byte-for-byte copies below are used
  instead -- see _ROOFLINE_SOURCE in the CSV header).
- gpt50m_step: end-to-end fwd+bwd training step of a ~50M-param char-GPT
  (model definition from examples/train_gpt.py, torch twin from
  benchmarks/training/train_gpt_bench.py). See "gpt50m_step accounting" below.
- kda (optional): if benchmarks/roofline/kda_report.py exists, it is imported and
  its results are appended (see collect_kda()).

Timing
------
- Kernel rows: minitriton do_bench (CUDA events, L2 flush via memset
  before each rep, warmup=5, rep=20, median) -- the same helper as
  benchmarks/roofline/report.py and benchmarks/roofline/attention_report.py.
- gpt50m_step rows: wall-clock per training step (host perf_counter
  bracketing one full step + one device sync per step), median over the
  steady-state window = last 2/3 of steps. Protocol otherwise identical
  to benchmarks/training/train_gpt_bench.py (same corpus, model, AdamW settings,
  grad clip, lr schedule, batch). Per-step timing includes the per-step
  H2D batch transfer, matching train_gpt_bench's windowed average.

Machine roofline (measured, not spec-sheet)
-------------------------------------------
- DRAM bandwidth: torch.add on 2^28 fp32 elements (3 data streams),
  timed with do_bench  -> GB/s.
- fp32 compute peak: torch.mm 8192^3 (cuBLAS SGEMM, allow_tf32=False)
  -> GFLOP/s.
- roof(ai) = min(fp32_peak, dram_bw * ai); pct_of_roofline = 100 *
  achieved_gflops / roof(ai).

Arithmetic-intensity conventions (identical to report.py / roofline.py
file headers)
------------------------------------------------------------------------------
- matmul:     flops = 2*M*N*K;             bytes = 4*(M*K + K*N + M*N)
- softmax:    flops ~ 5*rows*cols;         bytes = 2*4*rows*cols
- vecadd:     flops = n;                   bytes = 3*4*n
- flash_attn: flops = 2*B*H*d*T^2 (causal fwd);   bytes = 16*B*H*T*d  => AI = T/8

gpt50m_step accounting
----------------------
Config: n_layer=10, n_head=10, n_embd=640, vocab from the runtime
corpus (char-level, load_corpus(minitriton/*.py) — the value moves
with the source tree), block=256, batch=32, fp32 (allow_tf32=False).
num_params() ~= 49.5M (tied wte/lm_head counted once; the exact count
moves with the runtime vocab).

FLOPs (fwd+bwd), analytic:
    flops = 6 * n_params * (batch*block)           # 6ND: matmul fwd + dgrad + wgrad
          + 6 * n_layer * batch * block^2 * n_embd # causal attention QK^T/PV:
                                                     # per layer 2*B*T^2*n_embd fwd
                                                     # (halved for causal, same
                                                     # convention as the flash
                                                     # rows), x3 for fwd+bwd.
                                                     # n_layer, NOT n_head -- the
                                                     # two coincide (10) for
                                                     # gpt50m, which let an H-for-L
                                                     # substitution pass unnoticed.
Bytes: static exact enumeration of one step's op graph is impractical, so
a documented approximation is used (see CSV note column):
    bytes = 3 * n_params * 4            # weights: fwd read + bwd read + grad
                                        # write ~= 3 passes over the parameters
          + ACT_COEF * n_layer * batch * block * n_embd * 4
                                        # activation traffic heuristic,
                                        # ACT_COEF = 7 = midpoint of the
                                        # empirical 6..8 full B*T*D-sized
                                        # tensor move-sets per layer per step
This UNDERSTATES the exact per-op minimal-DRAM-traffic sum (every
intermediate written+read at least once in fwd and again in bwd would be
~4-5x the activation term); it is a heuristic roofline x-position for the
e2e point, not an op-level count. Both impls share the same flops/bytes,
so their relative position is unaffected.

Usage:
    CUDA_VISIBLE_DEVICES=0 python benchmarks/roofline/roofline_export.py
"""

import csv
import importlib.util
import statistics
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

BENCH_DIR = Path(__file__).resolve().parent
REPO_ROOT = BENCH_DIR.parents[1]
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(BENCH_DIR))

import numpy as np
import torch

from minitriton import do_bench  # noqa: F401  (re-exported for the copies)

# ---------------------------------------------------------------------------
# roofline calibration + flash-attention collection: import from
# benchmarks/roofline/roofline.py; fall back to inlined byte-for-byte
# copies if the import breaks.
# ---------------------------------------------------------------------------

_ROOFLINE_SOURCE = "imported from benchmarks/roofline/roofline.py"
try:
    from roofline import (collect_attention, measure_dram_bw,
                          measure_fp32_peak)
except Exception as exc:  # pragma: no cover - defensive fallback
    _ROOFLINE_SOURCE = (f"inlined copies of roofline.py functions "
                        f"(import roofline failed: {exc!r})")
    import minitriton as tl
    from minitriton import ops as tl_ops
    from attention_report import torch_unfused, tri_best

    def measure_dram_bw() -> float:
        """GB/s, measured with a 3-stream fp32 add on 2^28 elements (torch)."""
        n = 1 << 28
        x = torch.randn(n, device="cuda")
        y = torch.randn(n, device="cuda")
        fn = lambda: torch.add(x, y)
        fn()
        torch.cuda.synchronize()
        ms = do_bench(fn, warmup=3, rep=10)
        return 12.0 * n / ms * 1e-6

    def measure_fp32_peak() -> float:
        """GFLOP/s, measured with cuBLAS SGEMM at 8192^3."""
        n = 8192
        a = torch.randn(n, n, device="cuda")
        b = torch.randn(n, n, device="cuda")
        fn = lambda: torch.mm(a, b)
        fn()
        torch.cuda.synchronize()
        ms = do_bench(fn, warmup=3, rep=10)
        return 2.0 * n**3 / ms * 1e-6

    def collect_attention():
        """Flash-attention fwd points for the roofline (4 implementations)."""
        results = []
        for B, H, T in [(8, 12, 256), (8, 12, 512), (8, 12, 1024),
                        (4, 8, 2048)]:
            HD = 64
            rng = np.random.default_rng(0)
            qn, kn, vn = (rng.standard_normal((B, H, T, HD)).astype(np.float32)
                          for _ in range(3))
            scale = 1.0 / np.sqrt(HD)
            tq, tk, tv = (tl.tensor(x) for x in (qn, kn, vn))
            with tl.no_grad():
                tl_ops.flash_attention_forward(tq, tk, tv, scale)
            tl_fn = lambda: tl_ops.flash_attention_forward(tq, tk, tv, scale)
            tl_fn()
            tl.synchronize()
            tl_ms = do_bench(tl_fn)
            qq, kk, vv = (torch.from_numpy(x).cuda() for x in (qn, kn, vn))
            tri_fn, tri_ms, _ = tri_best(qq, kk, vv, scale)
            mask = torch.triu(torch.full((T, T), -1e9, device="cuda"), 1)
            e_fn = lambda: torch_unfused(qq, kk, vv, scale, mask)
            e_fn()
            torch.cuda.synchronize()
            eager_ms = do_bench(e_fn)
            c_fn = torch.compile(torch_unfused)
            for _ in range(3):
                c_fn(qq, kk, vv, scale, mask)
            torch.cuda.synchronize()
            compile_ms = do_bench(lambda: c_fn(qq, kk, vv, scale, mask))
            flops = 2.0 * B * H * T * T * HD  # causal effective (halved)
            bts = 16.0 * B * H * T * HD  # Q,K,V,O fp32
            results.append({
                "kernel": "flash_attn", "shape": f"B{B}H{H}T{T}d{HD}",
                "flops": flops, "bytes": bts,
                "tl_ms": tl_ms, "eager_ms": eager_ms,
                "compile_ms": compile_ms, "triton_ms": tri_ms,
            })
            print(f"  flash_attn B{B}H{H}T{T}d{HD}: tl {tl_ms:.3f} ms, "
                  f"eager {eager_ms:.3f}, compile {compile_ms:.3f}, "
                  f"triton {tri_ms:.3f}")
        return results

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "training"))
from report import collect_results  # matmul/softmax/vecadd suite
from accounting import ACT_COEF, gpt_step_bytes, gpt_step_flops
import train_gpt_bench as tgb  # ThGPT torch twin + tg (examples/train_gpt.py)

tg = tgb.tg

torch.backends.cuda.matmul.allow_tf32 = False

# ---------------------------------------------------------------------------
# gpt50m_step: end-to-end fwd+bwd training step
# ---------------------------------------------------------------------------

GPT_N_LAYER, GPT_N_HEAD, GPT_N_EMBD = 10, 10, 640  # ~49.5M params (runtime vocab)
GPT_BLOCK, GPT_BATCH = 256, 32
GPT_STEPS, GPT_LR, GPT_SEED = 60, 1e-3, 1337
# ACT_COEF comes from accounting.py (single source for the byte heuristic)

KERNEL_NOTES = {
    "matmul": "fwd only; flops=2*M*N*K; bytes=4*(M*K+K*N+M*N)",
    "softmax": "fwd only; flops~=5*rows*cols (exp=1); bytes=8*rows*cols",
    "vecadd": "fwd only; flops=n; bytes=12*n",
    "flash_attn": "causal fwd only; flops=2*B*H*d*T^2; bytes=16*B*H*T*d",
}


def measure_tl_step_ms(cfg, data):
    """Median steady-state wall time (ms) of one minitriton training step.

    Mirrors train_gpt_bench.run_tl (same model/optimizer/clip/lr/batch);
    the difference is per-step host timing with a device sync per step and
    a median over the last 2/3 of steps instead of one windowed average.
    Returns (ms, n_params, final_loss).
    """
    import minitriton as tl
    from minitriton import nn
    rng = np.random.default_rng(GPT_SEED)
    model = tg.GPT(cfg)
    n_params = model.num_params()
    opt = nn.AdamW(model.parameters(), lr=GPT_LR, betas=(0.9, 0.95),
                   weight_decay=0.1)
    times = []
    loss = None
    for step in range(GPT_STEPS):
        opt.lr = tg.lr_at(step, GPT_STEPS, GPT_LR)
        x, y = tg.get_batch(data, GPT_BATCH, cfg.block_size, rng)
        t0 = time.perf_counter()
        loss = model(tl.tensor(x), tl.tensor(y))
        model.zero_grad()
        loss.backward()
        nn.clip_grad_norm(model.parameters(), 1.0)
        opt.step()
        tl.synchronize()
        times.append(time.perf_counter() - t0)
    steady = times[GPT_STEPS // 3:]
    ms = statistics.median(steady) * 1e3
    del model, opt
    return ms, n_params, float(loss.item())


def measure_torch_step_ms(cfg, data):
    """Same as measure_tl_step_ms for the torch eager twin (ThGPT);
    attention is explicit-eager below block 512 and SDPA at block >= 512
    (the explicit (T,T) scores matrix OOMs there)."""
    torch.backends.cuda.matmul.allow_tf32 = False
    rng = np.random.default_rng(GPT_SEED)
    torch.manual_seed(GPT_SEED)
    # the explicit (T,T) scores attention OOMs at T>=512; use SDPA
    # (torch's fused attention) as the baseline there
    model = tgb.ThGPT(cfg, sdpa=(cfg.block_size >= 512)).cuda()
    opt = torch.optim.AdamW(model.parameters(), lr=GPT_LR, betas=(0.9, 0.95),
                            weight_decay=0.1, foreach=False)
    times = []
    loss = None
    for step in range(GPT_STEPS):
        lr_t = tg.lr_at(step, GPT_STEPS, GPT_LR)
        for g in opt.param_groups:
            g["lr"] = lr_t
        x, y = tg.get_batch(data, GPT_BATCH, cfg.block_size, rng)
        t0 = time.perf_counter()
        xb = torch.from_numpy(x.astype(np.int64)).to("cuda")
        yb = torch.from_numpy(y.astype(np.int64)).to("cuda")
        loss = model(xb, yb)
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        torch.cuda.synchronize()
        times.append(time.perf_counter() - t0)
    steady = times[GPT_STEPS // 3:]
    ms = statistics.median(steady) * 1e3
    final_loss = float(loss.item())
    del model, opt
    torch.cuda.empty_cache()
    return ms, final_loss


GPT_BLOCKS = (128, 256, 512, 1024)


def gpt50m_flops_bytes(n_params: int, block: int):
    """Analytic step FLOPs + approximated DRAM bytes (see module docstring
    and benchmarks/roofline/accounting.py for the pinned conventions)."""
    return (gpt_step_flops(n_params, GPT_N_LAYER, GPT_BATCH, block,
                           GPT_N_EMBD),
            gpt_step_bytes(n_params, GPT_N_LAYER, GPT_BATCH, block,
                           GPT_N_EMBD))


def collect_gpt50m(results: list, blocks=GPT_BLOCKS) -> None:
    """Measure both impls at several sequence lengths; append rows."""
    for blk in blocks:
        _collect_gpt50m_one(results, blk)


def _collect_gpt50m_one(results: list, blk: int) -> None:
    cfg = tg.Cfg()
    cfg.block_size = blk
    cfg.n_layer, cfg.n_head, cfg.n_embd = GPT_N_LAYER, GPT_N_HEAD, GPT_N_EMBD
    data, vocab, _ = tg.load_corpus(REPO_ROOT / "minitriton")
    cfg.vocab_size = vocab

    tl_ms, n_params, tl_loss = measure_tl_step_ms(cfg, data)
    print(f"  gpt50m_step T{blk} minitriton: {tl_ms:.2f} ms/step "
          f"({GPT_BATCH * blk / tl_ms / 1e3:.1f}K tok/s, "
          f"final loss {tl_loss:.3f})")
    th_ms, th_loss = measure_torch_step_ms(cfg, data)
    print(f"  gpt50m_step T{blk} torch_eager: {th_ms:.2f} ms/step "
          f"({GPT_BATCH * blk / th_ms / 1e3:.1f}K tok/s, "
          f"final loss {th_loss:.3f})")

    flops, bts = gpt50m_flops_bytes(n_params, blk)
    shape = (f"{n_params / 1e6:.1f}M_L{GPT_N_LAYER}D{GPT_N_EMBD}"
             f"H{GPT_N_HEAD}_B{GPT_BATCH}T{blk}")
    step_note = ("fwd+bwd train step (AdamW+clip incl.; per-step wall, "
                 "steady-state median; torch baseline: explicit-eager "
                 "attention below block 512, SDPA at block >= 512); "
                 "flops=6*Nparams*tokens"
                 "+6*n_layer*B*T^2*n_embd (causal attention term); "
                 "bytes=approx: 3*Nparams*4B weights"
                 f"+{ACT_COEF:.0f}*n_layer*B*T*n_embd*4B activations "
                 "(documented heuristic, understates exact op-level sum)")
    results.append({
        "kernel": "gpt50m_step", "shape": shape,
        "flops": flops, "bytes": bts,
        "tl_ms": tl_ms, "eager_ms": th_ms,
        "compile_ms": float("nan"), "triton_ms": float("nan"),
        "note": step_note,
    })
    print(f"  gpt50m_step accounting: n_params={n_params / 1e6:.2f}M, "
          f"flops={flops / 1e12:.3f} TFLOP, bytes={bts / 1e9:.3f} GB, "
          f"AI={flops / bts:.1f}")


# ---------------------------------------------------------------------------
# KDA rows (attached from benchmarks/roofline/kda_report.py when present)
# ---------------------------------------------------------------------------

def collect_kda() -> list:
    """Append kda rows if benchmarks/roofline/kda_report.py exists.

    Expected interface (whichever is present): kda_report.collect_results()
    or kda_report.collect_kda_results() -> list of dicts with keys
    kernel/shape/flops/bytes and any of tl_ms/eager_ms/compile_ms/
    triton_ms (i.e. the report.collect_results() schema).
    """
    if importlib.util.find_spec("kda_report") is None:
        print("  kda_report.py not found -- skipping KDA rows "
              "(hook ready; implement benchmarks/roofline/kda_report.py with a "
              "collect_results() to enable)")
        return []
    try:
        import kda_report
        fn = getattr(kda_report, "collect_results", None) or \
            getattr(kda_report, "collect_kda_results", None)
        if fn is None:
            print("  kda_report.py found but has no collect_results() / "
                  "collect_kda_results() -- skipping KDA rows")
            return []
        rows = fn()
        for r in rows:
            r.setdefault("note", "from kda_report (auto-attached)")
        print(f"  attached {len(rows)} KDA point(s) from kda_report")
        return rows
    except Exception as exc:
        print(f"  kda_report import/collect failed ({exc!r}) -- "
              f"skipping KDA rows")
        return []


# ---------------------------------------------------------------------------
# CSV assembly
# ---------------------------------------------------------------------------

IMPLS = [("minitriton", "tl_ms"), ("torch_eager", "eager_ms"),
         ("torch_compile", "compile_ms"), ("triton", "triton_ms")]

CSV_PATH = BENCH_DIR / "roofline_data.csv"


def expand_rows(results: list, bw_gbs: float, peak_gflops: float) -> list:
    """Turn report-style dicts into flat CSV rows (one per impl)."""
    rows = []
    for r in results:
        flops, bts = float(r["flops"]), float(r["bytes"])
        ai = flops / bts
        roof = min(peak_gflops, bw_gbs * ai)
        region = ("compute-bound" if bw_gbs * ai > peak_gflops
                  else "bandwidth-bound")
        base_note = r.get("note") or KERNEL_NOTES.get(r["kernel"], "")
        for impl, key in IMPLS:
            ms = float(r.get(key, float("nan")))
            if not np.isfinite(ms):
                continue
            gflops = flops / ms * 1e-6
            note = f"{base_note}; {region}".strip("; ")
            rows.append({
                "kernel": r["kernel"], "shape": r["shape"], "impl": impl,
                "ms": f"{ms:.6f}", "flops": int(round(flops)),
                "bytes": int(round(bts)), "ai": f"{ai:.4f}",
                "gflops": f"{gflops:.2f}",
                "pct_of_roofline": f"{100.0 * gflops / roof:.2f}",
                "note": note,
            })
    return rows


def write_csv(rows: list, bw_gbs: float, peak_gflops: float,
              gpt_meta: str) -> None:
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    gpu = torch.cuda.get_device_name(0)
    cap = torch.cuda.get_device_capability(0)
    meta = [
        "MiniTriton roofline data export (benchmarks/roofline/roofline_export.py)",
        f"generated_utc: {ts}",
        f"gpu: {gpu} (sm_{cap[0]}{cap[1]}), CUDA_VISIBLE_DEVICES=0",
        "machine calibration (measured, same routines as "
        "benchmarks/roofline/roofline.py):",
        f"  dram_bw_gbs: {bw_gbs:.1f}  (torch.add 2^28 fp32, 3 streams, "
        "do_bench)",
        f"  fp32_peak_gflops: {peak_gflops:.1f}  (cuBLAS SGEMM 8192^3, "
        "allow_tf32=False)",
        "roofline model: roof(ai)=min(fp32_peak_gflops, dram_bw_gbs*ai); "
        "pct_of_roofline=100*gflops/roof(ai)",
        "timing: kernel rows = minitriton do_bench (CUDA events + L2 "
        "flush, warmup=5, rep=20, median), same as report.py / "
        "attention_report.py; gpt50m_step rows = per-step wall clock "
        "(host timer + device sync/step, median over last 2/3 of "
        f"{GPT_STEPS} steps)",
        "arithmetic-intensity conventions (see note column per row):",
        "  matmul: flops=2*M*N*K; bytes=4*(M*K+K*N+M*N)",
        "  softmax: flops~=5*rows*cols (exp counted as 1); "
        "bytes=8*rows*cols",
        "  vecadd: flops=n; bytes=12*n",
        "  flash_attn: flops=2*B*H*T^2*d (causal fwd, halved from 4x); "
        "bytes=16*B*H*T*d => AI=T/8",
        "  gpt50m_step: flops=6*n_params*(B*T)+6*n_layer*B*T^2*n_embd "
        "(fwd+bwd, attention causal-halved); bytes=3*n_params*4B "
        "(weights: fwd+bwd reads + grad "
        f"write) + {ACT_COEF:.0f}*n_layer*B*T*n_embd*4B (activation "
        "heuristic, midpoint of 6..8; understates exact op-level sum -- "
        "see script docstring)",
        f"  gpt50m config: {gpt_meta}",
        f"calibration/attention source: {_ROOFLINE_SOURCE}",
        "columns: ms=median milliseconds; gflops=flops/ms*1e-6; "
        "ai=flops/bytes",
    ]
    with CSV_PATH.open("w", newline="") as f:
        for line in meta:
            f.write(f"# {line}\n")
        w = csv.DictWriter(f, fieldnames=["kernel", "shape", "impl", "ms",
                                          "flops", "bytes", "ai", "gflops",
                                          "pct_of_roofline", "note"])
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {CSV_PATH} ({len(rows)} rows)")


def main():
    print("calibrating roofline (measured, not spec) ...")
    bw_gbs = measure_dram_bw()
    print(f"  DRAM bandwidth (torch add 2^28, 3 streams): {bw_gbs:.1f} GB/s")
    peak_gflops = measure_fp32_peak()
    print(f"  fp32 peak (cuBLAS SGEMM 8192^3):          "
          f"{peak_gflops:.1f} GFLOP/s")

    print("collecting kernel benchmarks (report.py suite) ...")
    results = collect_results()
    print("collecting flash-attention benchmarks (via roofline.py) ...")
    results += collect_attention()
    print("KDA hook:")
    results += collect_kda()
    print("measuring gpt50m_step (fwd+bwd training step) ...")
    collect_gpt50m(results)

    gpt_meta = (f"n_layer={GPT_N_LAYER} n_head={GPT_N_HEAD} "
                f"n_embd={GPT_N_EMBD} "
                f"vocab={tg.load_corpus(REPO_ROOT / 'minitriton')[1]} "
                f"(runtime corpus) block={GPT_BLOCK} "
                f"batch={GPT_BATCH} fp32 steps={GPT_STEPS} lr={GPT_LR} "
                f"seed={GPT_SEED}")
    rows = expand_rows(results, bw_gbs, peak_gflops)
    write_csv(rows, bw_gbs, peak_gflops, gpt_meta)

    # console sanity summary: distance to roofline per (kernel, shape) for
    # the minitriton impl, same analysis as roofline.py prints.
    print("\nroofline analysis (minitriton points):")
    for row in rows:
        if row["impl"] != "minitriton":
            continue
        print(f"  {row['kernel']:>12} {row['shape']:>22}: AI={row['ai']:>9}  "
              f"{float(row['gflops']):10.1f} GFLOP/s = "
              f"{row['pct_of_roofline']:>6}% of roofline")


if __name__ == "__main__":
    main()
