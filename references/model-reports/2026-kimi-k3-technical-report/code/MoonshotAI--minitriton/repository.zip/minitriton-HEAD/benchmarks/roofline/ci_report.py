#!/usr/bin/env python
"""MiniTriton CI performance gate — single command:

    CUDA_VISIBLE_DEVICES=1 python benchmarks/roofline/ci_report.py

Core suite: matmul / fused softmax / flash-attention fwd / gpt50m train
step / spmm_csr, 2-3 shapes each. Every shape is timed for minitriton
(production eager API), torch eager and torch.compile (default mode)
with the shared do_bench (CUDA events + L2 flush). Ratios printed are
baseline_ms / tl_ms (>= 1.0 = minitriton faster). Exits nonzero when
either geometric mean drops below its gate.

Gates (acceptance floors):
    GEOMEAN_GATE_EAGER   = 1.15
    GEOMEAN_GATE_COMPILE = 1.00

The eager gate keeps ~6% noise margin below the measured baseline; the
compile gate sits at its acceptance floor with a similar margin. Re-measure
the baseline by running this script (it prints the before/after geomeans).
"""

import importlib.util
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

import minitriton as tl
from minitriton import do_bench, ops as tl_ops, sparse

import torch

GEOMEAN_GATE_EAGER = 1.15
GEOMEAN_GATE_COMPILE = 1.00

ROWS = []  # (kernel, shape, tl_ms, eager_ms, compile_ms)


def _tl_time(fn):
    fn()
    tl.synchronize()
    return do_bench(fn)


def _torch_time(fn):
    fn()
    torch.cuda.synchronize()
    return do_bench(fn)


def _compiled(fn, *args):
    cfn = torch.compile(fn)
    cfn(*args)
    torch.cuda.synchronize()
    return cfn


def row(kernel, shape, tl_ms, eager_ms, compile_ms):
    ROWS.append((kernel, shape, tl_ms, eager_ms, compile_ms))
    print(f"{kernel:>12} | {shape:>18} | {tl_ms:9.3f} | {eager_ms:9.3f} | "
          f"{compile_ms:10.3f} | {eager_ms / tl_ms:8.2f} | "
          f"{compile_ms / tl_ms:10.2f}")


# ---------------------------------------------------------------------------
# matmul / softmax (fp32, production eager API)
# ---------------------------------------------------------------------------

def bench_matmul():
    torch.backends.cuda.matmul.allow_tf32 = False
    for n in (1024, 2048, 4096):
        rng = np.random.default_rng(0)
        a = rng.standard_normal((n, n)).astype(np.float32)
        b = rng.standard_normal((n, n)).astype(np.float32)
        ta, tb = tl.tensor(a), tl.tensor(b)
        out = ta @ tb
        assert np.max(np.abs(out.numpy() - a @ b)) / np.sqrt(n) < 1e-4
        tl_ms = _tl_time(lambda: ta @ tb)
        xa, xb = torch.from_numpy(a).cuda(), torch.from_numpy(b).cuda()
        e_ms = _torch_time(lambda: xa @ xb)
        cfn = _compiled(lambda p, q: p @ q, xa, xb)
        c_ms = _torch_time(lambda: cfn(xa, xb))
        row("matmul", f"{n}^3", tl_ms, e_ms, c_ms)


def bench_softmax():
    for rows, cols in ((65536, 1024), (4096, 4096)):
        rng = np.random.default_rng(0)
        a = rng.standard_normal((rows, cols)).astype(np.float32)
        ta = tl.tensor(a)
        out = ta.softmax(dim=1)
        z = a - a.max(1, keepdims=True)
        ref = np.exp(z) / np.exp(z).sum(1, keepdims=True)
        assert np.allclose(out.numpy(), ref, rtol=1e-4, atol=1e-5)
        tl_ms = _tl_time(lambda: ta.softmax(dim=1))
        xa = torch.from_numpy(a).cuda()
        e_ms = _torch_time(lambda: torch.softmax(xa, dim=1))
        cfn = _compiled(lambda x: torch.softmax(x, dim=1), xa)
        c_ms = _torch_time(lambda: cfn(xa))
        row("softmax", f"{rows}x{cols}", tl_ms, e_ms, c_ms)


# ---------------------------------------------------------------------------
# flash attention forward (fp32, causal)
# ---------------------------------------------------------------------------

def _torch_unfused(q, k, v, scale, mask):
    s = (q @ k.transpose(-2, -1)) * scale + mask
    return torch.softmax(s, dim=-1) @ v


def bench_attention():
    torch.backends.cuda.matmul.allow_tf32 = False
    for B, H, T, HD in ((8, 12, 512, 64), (8, 12, 1024, 64)):
        rng = np.random.default_rng(0)
        qn, kn, vn = (rng.standard_normal((B, H, T, HD)).astype(np.float32)
                      for _ in range(3))
        scale = 1.0 / np.sqrt(HD)
        tq, tk, tv = (tl.tensor(x) for x in (qn, kn, vn))
        with tl.no_grad():
            out, _ = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                                    with_lse=True)
        tl_fn = lambda: tl_ops.flash_attention_forward(tq, tk, tv, scale)
        tl_ms = _tl_time(tl_fn)
        qq, kk, vv = (torch.from_numpy(x).cuda() for x in (qn, kn, vn))
        mask = torch.triu(torch.full((T, T), -1e9, device="cuda"), 1)
        ref = _torch_unfused(qq, kk, vv, scale, mask)
        err = float(np.max(np.abs(out.numpy() - ref.cpu().numpy())))
        assert err < 1e-4, f"attention wrong: {err}"
        e_ms = _torch_time(lambda: _torch_unfused(qq, kk, vv, scale, mask))
        cfn = _compiled(_torch_unfused, qq, kk, vv, scale, mask)
        c_ms = _torch_time(lambda: cfn(qq, kk, vv, scale, mask))
        row("attention", f"B{B}H{H}T{T}", tl_ms, e_ms, c_ms)


# ---------------------------------------------------------------------------
# spmm_csr (fp32)
# ---------------------------------------------------------------------------

def bench_spmm():
    Rm, Km, Nm, avg_nnz = 8192, 8192, 64, 64
    rng = np.random.default_rng(0)
    lens = np.full(Rm, avg_nnz, dtype=np.int64)
    rp_np = np.concatenate([[0], np.cumsum(lens)])
    nnz = int(rp_np[-1])
    col_np = rng.integers(0, Km, nnz).astype(np.int32)
    val_np = rng.standard_normal(nnz).astype(np.float32)
    b_np = rng.standard_normal((Km, Nm)).astype(np.float32)
    ag = (tl.from_numpy(rp_np.astype(np.int32)), tl.from_numpy(col_np),
          tl.from_numpy(val_np), tl.from_numpy(b_np))
    out = sparse.spmm_csr(*ag)
    tl_ms = _tl_time(lambda: sparse.spmm_csr(*ag))
    # torch eager cuSPARSE baseline (same CSR)
    crow = torch.from_numpy(rp_np.astype(np.int64)).cuda()
    col = torch.from_numpy(col_np.astype(np.int64)).cuda()
    val = torch.from_numpy(val_np).cuda()
    sp = torch.sparse_csr_tensor(crow, col, val, size=(Rm, Km))
    xb = torch.from_numpy(b_np).cuda()
    ref = torch.sparse.mm(sp, xb).cpu().numpy()
    err = float(np.max(np.abs(out.numpy() - ref)))
    assert err < 1e-4, f"spmm wrong: {err}"
    e_ms = _torch_time(lambda: torch.sparse.mm(sp, xb))
    try:
        cfn = _compiled(lambda s, x: torch.sparse.mm(s, x), sp, xb)
        c_ms = _torch_time(lambda: cfn(sp, xb))
    except Exception:
        c_ms = e_ms  # inductor has no sparse mm lowering; eager stands in
    row("spmm_csr", f"{Rm}x{Km}x{Nm}", tl_ms, e_ms, c_ms)


# ---------------------------------------------------------------------------
# gpt50m train step (fp32): tl vs torch eager vs torch.compile
# ---------------------------------------------------------------------------

def bench_gpt_step(steps=24, batch=32, block=512, lr=1e-3, seed=1337):
    repo = Path(__file__).resolve().parents[2]
    spec = importlib.util.spec_from_file_location(
        "train_gpt", repo / "examples" / "train_gpt.py")
    tg = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tg)
    sys.path.insert(0, str(repo / "benchmarks" / "training"))
    from train_gpt_bench import ThGPT
    from train_gpt_precision_bench import run_tl, run_torch, GPT, _cfg

    data, vocab, _ = tg.load_corpus(repo / "minitriton")
    cfg = _cfg(vocab, block)
    tl_tps, _ = run_tl(cfg, data, steps, batch, lr, seed, "fp32")
    e_tps, _ = run_torch(cfg, data, steps, batch, lr, seed, amp=False)

    # torch.compile twin: same model/init/step loop, compiled fwd+bwd
    torch.backends.cuda.matmul.allow_tf32 = False
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    model = torch.compile(ThGPT(cfg, sdpa=True).cuda())
    opt = torch.optim.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                            weight_decay=0.1, foreach=False)
    import time
    w = steps // 3
    tokens, t0 = 0, time.perf_counter()
    for step in range(steps):
        lr_t = tg.lr_at(step, steps, lr)
        for g in opt.param_groups:
            g["lr"] = lr_t
        x, y = tg.get_batch(data, batch, cfg.block_size, rng)
        xb = torch.from_numpy(x.astype(np.int64)).cuda()
        yb = torch.from_numpy(y.astype(np.int64)).cuda()
        loss = model(xb, yb)
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        if step == w:
            t0 = time.perf_counter()
            tokens = 0
        tokens += batch * cfg.block_size
    torch.cuda.synchronize()
    c_tps = tokens / (time.perf_counter() - t0)
    ms = lambda tps: batch * block / tps * 1e3
    row("gpt50m_step", f"T{block} fp32", ms(tl_tps), ms(e_tps), ms(c_tps))


# ---------------------------------------------------------------------------

def main():
    print(f"MiniTriton CI performance gate — device: "
          f"{torch.cuda.get_device_name(0)}, torch {torch.__version__}, "
          "fp32 tier; ratio = baseline_ms / tl_ms (>= 1.0 = faster)\n")
    print(f"{'kernel':>12} | {'shape':>18} | {'tl ms':>9} | "
          f"{'eager ms':>9} | {'compile ms':>10} | "
          f"{'r(eager)':>8} | {'r(compile)':>10}")
    bench_matmul()
    bench_softmax()
    bench_attention()
    bench_spmm()
    bench_gpt_step()

    geo = lambda v: float(np.exp(np.mean(np.log(v))))
    print()
    per_kernel = {}
    for kernel, shape, tl_ms, e_ms, c_ms in ROWS:
        per_kernel.setdefault(kernel, []).append((e_ms / tl_ms,
                                                  c_ms / tl_ms))
    all_e, all_c = [], []
    print("per-kernel geomean:")
    for kernel, ratios in per_kernel.items():
        ge, gc = geo([r[0] for r in ratios]), geo([r[1] for r in ratios])
        all_e += [r[0] for r in ratios]
        all_c += [r[1] for r in ratios]
        print(f"  {kernel:>12}: vs eager {ge:.2f} | vs compile {gc:.2f}")
    ge, gc = geo(all_e), geo(all_c)
    print(f"\nGEOMEAN vs torch eager   : {ge:.3f}  "
          f"(gate {GEOMEAN_GATE_EAGER:.2f}: "
          f"{'PASS' if ge >= GEOMEAN_GATE_EAGER else 'FAIL'})")
    print(f"GEOMEAN vs torch compile : {gc:.3f}  "
          f"(gate {GEOMEAN_GATE_COMPILE:.2f}: "
          f"{'PASS' if gc >= GEOMEAN_GATE_COMPILE else 'FAIL'})")
    if ge < GEOMEAN_GATE_EAGER or gc < GEOMEAN_GATE_COMPILE:
        sys.exit(1)


if __name__ == "__main__":
    main()
