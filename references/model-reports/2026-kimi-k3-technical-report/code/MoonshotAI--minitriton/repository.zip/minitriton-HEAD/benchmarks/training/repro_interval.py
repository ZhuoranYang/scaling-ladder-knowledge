#!/usr/bin/env python
"""Reproducibility interval figure: per-step run-to-run spread bands for
four training modes over N identical runs (same seed/config):

  1. tl fp32            (examples/train_gpt.py default path)
  2. tl bf16            (--bf16, atomic embedding backward)
  3. tl bf16 + ds       (--bf16 with MT_EMBED_FP64=1, deterministic
                         TwoSum embedding backward)
  4. torch AMP + SDPA   (F.scaled_dot_product_attention backward is
                         nondeterministic by design)

Top panel: loss trajectories with min-max bands over N runs.
Bottom panel: per-step spread (log scale) with credibility thresholds
(1e-6 / 1e-3 / 1e-2). Bit-identical series are floored at 1e-9 and
annotated as such.

Usage:
  CUDA_VISIBLE_DEVICES=1 python benchmarks/training/repro_interval.py [--runs 5]
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
TRAIN = ROOT / "benchmarks" / "training"
OUT = TRAIN / "train_gpt_repro_interval"
STEPS = 60
BATCH = 32
SEED = 1337


def _run_tl(mode: str, idx: int) -> np.ndarray:
    env = dict(os.environ)
    args = [sys.executable, str(ROOT / "examples" / "train_gpt.py"),
            "--steps", str(STEPS), "--batch-size", str(BATCH),
            "--seed", str(SEED), "--loss-csv",
            f"/tmp/repro_{mode}_{idx}.csv"]
    if mode in ("bf16", "bf16ds"):
        args.append("--bf16")
    if mode == "bf16ds":
        env["MT_EMBED_FP64"] = "1"
    for attempt in range(2):
        try:
            subprocess.run(args, check=True, env=env, cwd=ROOT,
                           capture_output=True, text=True)
            break
        except subprocess.CalledProcessError as e:
            tail = (e.stderr or "")[-600:] if e.stderr else str(e)
            if attempt == 1:
                raise RuntimeError(f"run {mode}/{idx} failed twice:\n{tail}")
            print(f"  [{mode}/{idx}] transient failure, retrying once:\n"
                  f"{tail[-200:]}")
    rows = [r.split(",") for r in open(f"/tmp/repro_{mode}_{idx}.csv")
            if r.strip() and not r.startswith("step")]
    return np.array([float(r[1]) for r in rows])


def _run_torch_sdpa(idx: int) -> np.ndarray:
    import torch
    import train_gpt as tg
    from train_gpt_bench import ThGPT
    from train_gpt_convergence import sync_init
    data, vocab, _ = tg.load_corpus(ROOT / "minitriton")
    cfg = tg.Cfg()
    cfg.vocab_size = vocab
    # identical init as the tl side (tg.GPT's init is seed-fixed): build
    # the tl model and mirror its weights — a fresh torch.manual_seed
    # init would be a DIFFERENT model and the cross-mode loss gap would
    # dwarf the run-to-run spreads this figure exists to show
    tl_model = tg.GPT(cfg)
    model = ThGPT(cfg, sdpa=True)
    sync_init(tl_model, model)
    del tl_model
    model = model.cuda()
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3,
                            betas=(0.9, 0.95), weight_decay=0.1,
                            foreach=False)
    rng = np.random.default_rng(SEED)
    losses = []
    for step in range(STEPS):
        lr_t = tg.lr_at(step, STEPS, 1e-3)
        for g in opt.param_groups:
            g["lr"] = lr_t
        x, y = tg.get_batch(data, BATCH, cfg.block_size, rng)
        xb = torch.from_numpy(x.astype(np.int64)).cuda()
        yb = torch.from_numpy(y.astype(np.int64)).cuda()
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            loss = model(xb, yb)
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        losses.append(loss.item())
    return np.array(losses)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=5)
    ap.add_argument("--from-cache", action="store_true",
                    help="skip the runs, render from the saved npz")
    args = ap.parse_args()
    n = args.runs
    sys.path.insert(0, str(TRAIN))
    sys.path.insert(0, str(ROOT / "examples"))
    sys.path.insert(0, str(ROOT / "benchmarks" / "roofline"))
    import plot_style as ps

    cache = TRAIN / "train_gpt_repro_interval_data.npz"
    if args.from_cache:
        z = np.load(cache)
        series = [(m, z[m]) for m in ("fp32", "bf16", "bf16ds", "sdpa")]
    else:
        series = []
        for mode in ("fp32", "bf16", "bf16ds", "sdpa"):
            print(f"[{mode}] {n} runs ...", flush=True)
            if mode == "sdpa":
                trajs = [_run_torch_sdpa(i) for i in range(n)]
            else:
                trajs = [_run_tl(mode, i) for i in range(n)]
            a = np.array(trajs)
            series.append((mode, a))
            spread = a.max(0) - a.min(0)
            print(f"  spread step10 {spread[10]:.2e}  step30 {spread[30]:.2e}"
                  f"  step59 {spread[59]:.2e}")
        np.savez(cache, **{m: a for m, a in series})
        print(f"cached raw trajectories -> {cache}")

    def make_fig():
        import matplotlib.pyplot as plt
        fig = plt.figure(figsize=(10.5, 7.5))
        gs = fig.add_gridspec(2, 1, height_ratios=[2.2, 1.2], hspace=0.12)
        ax = fig.add_subplot(gs[0])
        ax2 = fig.add_subplot(gs[1], sharex=ax)
        labels = {"fp32": "tl fp32", "bf16": "tl bf16 (atomic emb-bwd)",
                  "bf16ds": "tl bf16 + MT_EMBED_FP64 (deterministic)",
                  "sdpa": "torch AMP + SDPA"}
        colors = {"fp32": ps.IMPL_COLORS["minitriton"],
                  "bf16": ps.IMPL_COLORS["torch_compile"],
                  "bf16ds": ps.IMPL_COLORS["torch_eager"],
                  "sdpa": ps.IMPL_COLORS["triton"]}
        for mode, a in series:
            mu = a.mean(0)
            lo = a.min(0)
            hi = a.max(0)
            c = colors[mode]
            ax.plot(mu, color=c, lw=1.6, label=labels[mode], zorder=3)
            ax.fill_between(np.arange(STEPS), lo, hi, color=c, alpha=0.25,
                            lw=0, zorder=2)
            spread = (a.max(0) - a.min(0))
            ax2.semilogy(np.maximum(spread, 1e-9), color=c, lw=1.4)
        ax.set_ylabel("training loss")
        ax.legend(loc="upper right", fontsize=8.5, framealpha=0.9)
        ax.set_title(
            f"train_gpt reproducibility interval — {n} identical runs per mode"
            f" (same seed/config, {STEPS} steps)")
        for t, name in ((1e-6, "1e-6"), (1e-3, "1e-3"), (1e-2, "1e-2")):
            ax2.axhline(t, color=ps.TXT, lw=0.7, ls="--", alpha=0.5)
            ax2.text(STEPS - 1, t * 1.1, f" {name}", color=ps.TXT,
                     fontsize=8, ha="right", va="bottom")
        ax2.text(1, 2e-9, "bit-identical (floor 1e-9)", color=ps.TXT,
                 fontsize=8, va="bottom", alpha=0.8)
        ax2.set_ylabel("per-step spread")
        ax2.set_xlabel("step")
        ax2.set_ylim(1e-9, 1e-1)
        return fig

    ps.render_themes(make_fig, str(OUT))
    print(f"wrote {OUT}.png/.svg (+light)")


if __name__ == "__main__":
    main()
