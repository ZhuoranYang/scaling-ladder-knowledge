#!/usr/bin/env python
"""bf16 convergence: minitriton bf16 vs torch bf16 (AMP) with run-to-run
bands.

Same gpt50m char-GPT (L10 D640 H10), identical init / batch order / lr
schedule, N identical runs per side. Both bf16 recipes are
nondeterministic at kernel level — torch AMP uses SDPA (atomic split
backward, nondeterministic by design); minitriton's bf16 embedding
backward is an atomic scatter-add unless MT_EMBED_FP64=1 — so a single
curve per side is meaningless: the figure shows each side's run-to-run
min-max band over N runs, and the acceptance is that minitriton's mean
curve stays inside torch's band.

- minitriton bf16: bf16 params + fp32 masters + dynamic loss scaling;
  bf16 flash fwd, native bf16 mma attention bwd, fp32 residual
  stream/LN/CE
- torch bf16: bf16 autocast (fp32 weights/grads, bf16 matmuls) + SDPA

    CUDA_VISIBLE_DEVICES=1 python benchmarks/training/train_gpt_bf16_convergence.py --steps 200

Outputs: train_gpt_bf16_convergence.csv (means + torch band) +
_data.npz (all trajectories) + .png/.svg (dark+light via plot_style).
REPLOT=1 redraws from the npz (no GPU).
"""

import argparse
import csv as csvmod  # noqa: F401  (kept for the csv writer below)
import importlib.util
import os
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np

import minitriton as tl
from minitriton import nn

import torch

from train_gpt_convergence import sync_init  # tl GPT -> ThGPT mapping
from train_gpt_bench import ThGPT

spec = importlib.util.spec_from_file_location(
    "train_gpt", Path(__file__).resolve().parents[2] / "examples"
    / "train_gpt.py")
tg = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tg)

OUT = Path(__file__).resolve().parent / "train_gpt_bf16_convergence"
NPZ = Path(str(OUT) + "_data.npz")

GPT = dict(n_layer=10, n_head=10, n_embd=640)


def _cfg(vocab, block):
    cfg = tg.Cfg()
    cfg.vocab_size = vocab
    cfg.block_size = block
    cfg.n_layer, cfg.n_head, cfg.n_embd = (GPT["n_layer"], GPT["n_head"],
                                           GPT["n_embd"])
    return cfg


def run_tl_bf16(cfg, data, steps, batch, lr, seed):
    """One minitriton bf16 run (identical init/batches for a given seed)."""
    import math
    import minitriton.device.cuda.ops as _be
    _be.set_allow_tf32(False)  # fp32 seams (tied lm_head) stay exact
    cfg.bf16 = True
    rng = np.random.default_rng(seed)
    model = tg.GPT(cfg)  # init is seed-fixed: identical across runs
    fp32_orig = tg._convert_bf16_(model)
    opt = nn.BF16AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                       weight_decay=0.1, masters=fp32_orig)
    scaler = nn.GradScaler()
    losses = []
    skipped = 0
    for step in range(steps):
        opt.lr = tg.lr_at(step, steps, lr)
        x, y = tg.get_batch(data, batch, cfg.block_size, rng)
        loss = model(tl.tensor(x), tl.tensor(y))
        model.zero_grad()
        scaler.scale_loss(loss).backward()
        scaler.unscale_(model.parameters())
        total = nn.clip_grad_norm(model.parameters(), 1.0)
        if math.isfinite(total):
            opt.step()
        else:
            model.zero_grad()
            skipped += 1
        scaler.update(not math.isfinite(total))
        losses.append(loss.item())
    del model, opt
    return losses, skipped, scaler.scale


def run_torch_bf16(cfg, data, steps, batch, lr, seed, state):
    """One torch bf16-AMP run; `state` = the synced init state_dict."""
    torch.backends.cuda.matmul.allow_tf32 = False
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    model = ThGPT(cfg)
    model.load_state_dict(state)
    model = model.cuda()
    for blk in model.blocks:  # T>=512 OOMs the explicit (T,T) scores
        blk.sdpa = True
    opt = torch.optim.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95),
                            weight_decay=0.1, foreach=False)
    losses = []
    for step in range(steps):
        lr_t = tg.lr_at(step, steps, lr)
        for g in opt.param_groups:
            g["lr"] = lr_t
        x, y = tg.get_batch(data, batch, cfg.block_size, rng)
        xb = torch.from_numpy(x.astype(np.int64)).cuda()
        yb = torch.from_numpy(y.astype(np.int64)).cuda()
        with torch.autocast("cuda", dtype=torch.bfloat16):
            loss = model(xb, yb)
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        losses.append(loss.item())
    del model, opt
    return losses


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--runs", type=int, default=5,
                    help="identical runs per side (band width)")
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--block-size", type=int, default=512)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=1337)
    ap.add_argument("--tol", type=float, default=0.01,
                    help="acceptance bound on how far tl's mean may poke "
                         "outside torch's run-to-run band (nats)")
    args = ap.parse_args()

    if os.environ.get("REPLOT"):
        z = np.load(NPZ)
        _, vocab, _ = tg.load_corpus(
            Path(__file__).resolve().parents[2] / "minitriton")
        plot(z["tl"], z["torch"], vocab)
        return

    repo = Path(__file__).resolve().parents[2]
    data, vocab, _ = tg.load_corpus(repo / "minitriton")
    cfg = _cfg(vocab, args.block_size)
    print(f"gpt50m {GPT['n_layer']}L/{GPT['n_head']}H/{GPT['n_embd']}d "
          f"vocab {vocab}, block {args.block_size}, batch "
          f"{args.batch_size}, {args.steps} steps x {args.runs} runs, "
          f"lr {args.lr}, seed {args.seed}")

    # synced torch init (tl GPT init is seed-fixed; go through the
    # canonical mapping anyway, like train_gpt_convergence)
    tl_ref = tg.GPT(cfg)
    th_ref = ThGPT(cfg)
    sync_init(tl_ref, th_ref)
    state = th_ref.state_dict()
    del tl_ref, th_ref

    tl_runs, th_runs = [], []
    for i in range(args.runs):
        t0 = time.perf_counter()
        losses, skipped, scale = run_tl_bf16(cfg, data, args.steps,
                                             args.batch_size, args.lr,
                                             args.seed)
        tl_runs.append(losses)
        print(f"tl bf16 run {i} ({time.perf_counter() - t0:.0f}s): "
              f"loss {losses[0]:.3f} -> {losses[-1]:.3f}, "
              f"skipped {skipped}, final scale {scale:g}", flush=True)
    for i in range(args.runs):
        t0 = time.perf_counter()
        losses = run_torch_bf16(cfg, data, args.steps, args.batch_size,
                                args.lr, args.seed, state)
        th_runs.append(losses)
        print(f"torch bf16 run {i} ({time.perf_counter() - t0:.0f}s): "
              f"loss {losses[0]:.3f} -> {losses[-1]:.3f}", flush=True)

    tl_a = np.array(tl_runs)
    th_a = np.array(th_runs)
    np.savez(NPZ, tl=tl_a, torch=th_a)

    tl_mu, th_mu = tl_a.mean(0), th_a.mean(0)
    th_lo, th_hi = th_a.min(0), th_a.max(0)
    csv_path = OUT.with_suffix(".csv")
    with csv_path.open("w") as f:
        f.write("# train_gpt bf16 convergence: minitriton bf16 vs torch "
                "bf16-AMP, run-to-run bands (identical init/batches/lr)\n")
        f.write(f"# config L{GPT['n_layer']}D{GPT['n_embd']}H{GPT['n_head']}"
                f" vocab {vocab} block {args.block_size} batch "
                f"{args.batch_size} lr {args.lr} seed {args.seed} "
                f"runs {args.runs}\n")
        f.write("step,tl_bf16_mean,torch_bf16_mean,torch_min,torch_max\n")
        for i in range(args.steps):
            f.write(f"{i},{tl_mu[i]:.6f},{th_mu[i]:.6f},"
                    f"{th_lo[i]:.6f},{th_hi[i]:.6f}\n")
    print(f"wrote {csv_path}\nwrote {NPZ}")

    tl_spread = (tl_a.max(0) - tl_a.min(0))
    th_spread = (th_a.max(0) - th_a.min(0))
    print(f"run-to-run spread: tl bf16 max {tl_spread.max():.4f} "
          f"(tail50 mean {tl_spread[-50:].mean():.4f}) | torch bf16 max "
          f"{th_spread.max():.4f} (tail50 mean {th_spread[-50:].mean():.4f})")

    # acceptance: tl mean inside torch's band (allowing --tol of slack)
    above = np.maximum(tl_mu - th_hi, 0.0)
    below = np.maximum(th_lo - tl_mu, 0.0)
    viol = np.maximum(above, below)
    tail_viol = viol[-50:].max()
    n_out = int((viol > 1e-4).sum())
    gap = statistics.mean(tl_mu[-50:]) - statistics.mean(th_mu[-50:])
    tl_fin, th_fin = tl_a[:, -1], th_a[:, -1]
    interleave = int(((tl_fin >= th_fin.min()) &
                      (tl_fin <= th_fin.max())).sum())
    print(f"last-50 mean: tl bf16 {statistics.mean(tl_mu[-50:]):.4f} vs "
          f"torch bf16 {statistics.mean(th_mu[-50:]):.4f} "
          f"(gap {gap:+.4f} nats)\n"
          f"tl mean outside torch band: {n_out}/{len(viol)} steps "
          f"(>1e-4), max {viol.max():.4f} @step {int(viol.argmax())}, "
          f"tail-50 max {tail_viol:.4f} (tol {args.tol}: "
          f"{'PASS' if tail_viol <= args.tol else 'FAIL'})\n"
          f"terminal losses: tl {tl_fin.min():.3f}..{tl_fin.max():.3f} vs "
          f"torch {th_fin.min():.3f}..{th_fin.max():.3f} — "
          f"{interleave}/{len(tl_fin)} tl finals inside torch's range")
    plot(tl_a, th_a, vocab)
    if tail_viol > args.tol:
        sys.exit(1)


def plot(tl_a, th_a, vocab):
    import matplotlib
    matplotlib.use("Agg")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "roofline"))
    import plot_style as ps

    n_runs, nsteps = tl_a.shape
    steps = np.arange(nsteps)
    tl_mu, tl_lo, tl_hi = tl_a.mean(0), tl_a.min(0), tl_a.max(0)
    th_mu, th_lo, th_hi = th_a.mean(0), th_a.min(0), th_a.max(0)
    gap = float(np.mean(tl_mu[-50:]) - np.mean(th_mu[-50:]))
    viol_a = np.maximum(np.maximum(tl_mu - th_hi, 0.0),
                        np.maximum(th_lo - tl_mu, 0.0))
    viol = float(viol_a[-50:].max())
    n_out = int((viol_a > 1e-4).sum())
    tl_fin, th_fin = tl_a[:, -1], th_a[:, -1]
    interleave = int(((tl_fin >= th_fin.min()) &
                      (tl_fin <= th_fin.max())).sum())

    def fig_fn():
        import matplotlib.pyplot as plt
        fig = plt.figure(figsize=(10.5, 7.2), facecolor=ps.BG)
        gs = fig.add_gridspec(2, 1, height_ratios=[2.0, 1.3], hspace=0.14)
        ax = fig.add_subplot(gs[0])
        ax2 = fig.add_subplot(gs[1], sharex=ax)
        for a in (ax, ax2):
            a.set_facecolor(ps.BG)
        c_th = ps.IMPL_COLORS["torch_eager"]
        c_tl = ps.IMPL_COLORS["minitriton"]
        # top: absolute loss curves (means only — the sides coincide)
        ax.plot(steps, th_mu, color=c_th, lw=1.6, alpha=0.9,
                label="torch bf16 mean (AMP + SDPA)", zorder=3)
        ax.plot(steps, tl_mu, color=c_tl, lw=1.4, alpha=0.85,
                label="minitriton bf16 mean", zorder=4,
                linestyle=(0, (4, 2)))
        ax.set_ylabel("training loss", fontsize=11.5)
        ax.legend(fontsize=9, loc="upper right", framealpha=0.9)
        ps.title_block(
            ax, "train_gpt bf16 convergence — minitriton vs torch bf16",
            subtitle=f"{n_runs} identical runs/side (same seed/init/"
                     f"batches), last-50 mean gap {gap:+.4f} nats")
        ps.style_ax(ax, minor=False)
        # bottom: deviation from torch mean, bands centered on 0 — this
        # is where "tl inside torch's run-to-run band" is checkable
        ax2.fill_between(steps, th_lo - th_mu, th_hi - th_mu, color=c_th,
                         alpha=0.30, lw=0, zorder=2,
                         label=f"torch bf16 run-to-run band (n={n_runs})")
        ax2.fill_between(steps, tl_lo - th_mu, tl_hi - th_mu, color=c_tl,
                         alpha=0.20, lw=0, zorder=3,
                         label="minitriton bf16 run-to-run band")
        ax2.axhline(0.0, color=c_th, lw=1.0, alpha=0.7, zorder=3)
        ax2.plot(steps, tl_mu - th_mu, color=c_tl, lw=1.6, alpha=0.95,
                 label="minitriton bf16 mean − torch mean", zorder=5)
        # optional ablation overlay: same runs with tanh gelu
        # (MT_GELU_TANH=1) — shows the loss offset from that variant
        tanh_npz = NPZ.with_name(NPZ.stem.replace("_data", "")
                                 + "_tanh.npz")
        if tanh_npz.is_file():
            tl_tanh = np.load(tanh_npz)["tl"].mean(0)
            ax2.plot(steps, tl_tanh - th_mu,
                     color=ps.IMPL_COLORS["triton"], lw=1.2, alpha=0.8,
                     zorder=5,
                     label="minitriton bf16 + tanh-gelu "
                           "mean − torch mean")
        ax2.set_xlabel("step", fontsize=11.5)
        ax2.set_ylabel("loss − torch mean (nats)", fontsize=10)
        ax2.legend(fontsize=8.5, loc="upper right", framealpha=0.9)
        ax2.annotate(f"tl mean outside torch band: {n_out}/{nsteps} steps"
                     f", max {viol_a.max():.4f} nats @step "
                     f"{int(viol_a.argmax())} (tail-50: {viol:.4f}); "
                     f"finals interleave {interleave}/{n_runs}",
                     (0.015, 0.06), xycoords="axes fraction",
                     fontsize=9, color=ps.SUB)
        ps.style_ax(ax2, minor=False)
        fig.tight_layout()
        return fig

    ps.render_themes(fig_fn, OUT.with_suffix(""))


if __name__ == "__main__":
    main()
