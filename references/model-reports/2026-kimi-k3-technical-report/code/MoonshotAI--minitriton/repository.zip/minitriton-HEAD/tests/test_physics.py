"""Physics demo numeric-health tests (not physical-exactness
tests): the demos must stay finite, keep their conserved quantities sane
and not explode. numpy reference physics is intentionally NOT duplicated
here — kernel-level neighbor sums are covered by the sparse primitive
tests; this file watches bulk invariants over a real run.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "examples"))

import numpy as np

from sph_demo import PBDFluid


def test_sph_density_stable_and_no_explosion():
    """PBD pool settle: density mean within 15% of calibration, KE bounded
    (nothing near explosion), all positions inside the domain."""
    f = PBDFluid(n=2048, seed=0, vmax=1.0)
    f.dx_clamp = 0.5 * f.h
    ke_first = None
    for s in range(120):
        f.step()
        if s == 0:
            ke_first = f.kinetic_energy()
    assert f.finite()
    ratio = f.rho_mean() / f.rho0
    assert 0.85 < ratio < 1.35, f"rho_mean/rho0 = {ratio:.3f}"
    ke = f.kinetic_energy()
    assert ke < 0.6 * f.n, f"KE {ke:.3f} near the vmax cap (explosion?)"
    assert ke < 10.0 * (ke_first + 1e-9), "KE grew by >10x (explosion?)"
    x, y = f.x.numpy(), f.y.numpy()
    assert (x >= 0).all() and (x <= f.dom_w).all()
    assert (y >= 0).all() and (y <= f.dom_h).all()


from rigid_demo import RigidWorld


def test_rigid_energy_decays_and_no_sink():
    """Disc drop: linear and rotational KE must decay after the pile
    settles; hard wall clamp keeps sink at zero; nothing explodes."""
    w = RigidWorld(n=768, seed=0)
    kes = []
    for s in range(250):
        w.step()
        if s in (50, 249):
            kes.append(w.kinetic_energy())
    assert w.finite()
    early, late = kes
    assert late < 0.3 * early, f"KE did not decay: {early:.3f} -> {late:.3f}"
    assert w.rot_kinetic_energy() < 1.0, "rotational KE exploded"
    assert w.sink_violation() <= 1e-6, f"floor penetration {w.sink_violation()}"
    x = w.x.numpy()
    assert (x >= -1e-6).all() and (x <= w.dom_w + 1e-6).all()


from mpm_demo import MPMWorld


def test_mpm_mass_conservation_and_stability():
    """MLS-MPM blob drop: grid mass conserved to f32-atomic rounding
    (<1e-4 rel — spec is 1%), finite deformation, blob inside the box."""
    w = MPMWorld(n=4096, seed=0)
    w.step()
    mass0 = w.grid_mass()
    for _ in range(100):
        w.step()
    assert mass0 > 0
    assert w.finite()
    gm = w.grid_mass()
    drift = abs(gm - mass0) / mass0
    assert drift < 1e-4, f"mass drift {drift:.2e}"
    j = w.mean_j()
    assert 0.85 < j < 1.15, f"mean det(F) = {j:.3f} (torn/imploded)"
    x = w.x.numpy()
    assert (x >= 0.0).all() and (x <= 1.0).all()
