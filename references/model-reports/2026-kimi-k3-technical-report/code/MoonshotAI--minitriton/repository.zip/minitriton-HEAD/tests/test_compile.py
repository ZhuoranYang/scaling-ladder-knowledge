"""@tl.compile v1: elementwise chain fusion + matmul epilogue fusion,
checked against the eager path (which the tests in test_ops.py validate
against numpy). MT_COMPILE=0 must give identical results.
"""

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


def test_ew_chain_fusion():
    @tl.compile
    def f(x, y):
        return tl.sigmoid(tl.tanh(x * y + 2.0) * 0.5 + tl.exp(x))

    x, y = rn(64, 96), rn(64, 96)
    tx, ty = tl.tensor(x), tl.tensor(y)
    out = f(tx, ty)
    ref = 1 / (1 + np.exp(-(np.tanh(x * y + 2.0) * 0.5 + np.exp(x))))
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-4, atol=1e-5)
    # one fused group covering the whole chain (7 ew nodes)
    exe = list(f._cache.values())[0]
    assert len(exe.fused) == 1
    spec = list(exe.fused.values())[0]
    assert spec["type"] == "ew_chain" and len(spec["members"]) == 7


def test_ew_chain_with_broadcast_falls_back_but_correct():
    @tl.compile
    def f(x, y):
        return tl.relu(x + y) * 2.0

    x, y = rn(32, 48), rn(48)
    out = f(tl.tensor(x), tl.tensor(y))
    ref = np.maximum(x + y, 0) * 2.0
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-5, atol=1e-6)


def _gelu_np(z):
    """gelu oracle: erf-exact (default) or tanh (MT_GELU_TANH=1)."""
    from minitriton import precision as _prec
    if _prec.gelu_erf():
        import math
        return 0.5 * z * (1 + np.vectorize(math.erf)(
            z * 0.7071067811865476))
    return 0.5 * z * (1 + np.tanh(0.7978845608028654
                                  * (z + 0.044715 * z**3)))


def test_matmul_epilogue_fusion():
    @tl.compile
    def f(x, w, b):
        return tl.gelu(tl.matmul(x, w) + b)

    x, w, b = rn(128, 64), rn(64, 96), rn(96)
    out = f(tl.tensor(x), tl.tensor(w), tl.tensor(b))
    z = x @ w + b
    ref = _gelu_np(z)
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-3, atol=1e-4)
    exe = list(f._cache.values())[0]
    assert len(exe.fused) == 1
    spec = list(exe.fused.values())[0]
    # r2v (fp32 store_t2 epilogue) supersedes r2's v1 dot on this graph
    # (matmul+bias fused, the gelu replaying eagerly)
    assert spec["type"] == "mm_v2_epilogue"
    # odd sizes: masked path of the epilogue kernel
    x2, w2, b2 = rn(100, 77), rn(77, 55), rn(55)
    out2 = f(tl.tensor(x2), tl.tensor(w2), tl.tensor(b2))
    z2 = x2 @ w2 + b2
    ref2 = _gelu_np(z2)
    np.testing.assert_allclose(out2.numpy(), ref2, rtol=1e-3, atol=1e-4)


def test_matmul_bias_only():
    @tl.compile
    def f(x, w, b):
        return tl.matmul(x, w) + b

    x, w, b = rn(64, 48), rn(48, 32), rn(32)
    out = f(tl.tensor(x), tl.tensor(w), tl.tensor(b))
    np.testing.assert_allclose(out.numpy(), x @ w + b, rtol=1e-4, atol=1e-4)


def test_compile_mlp_matches_eager():
    def mlp(x, w1, b1, w2, b2):
        h = tl.relu(tl.matmul(x, w1) + b1)
        return tl.sigmoid(tl.matmul(h, w2) + b2)

    cf = tl.compile(mlp)
    x, w1, b1 = rn(64, 32), rn(32, 64), rn(64)
    w2, b2 = rn(64, 16), rn(16)
    args = [tl.tensor(v) for v in (x, w1, b1, w2, b2)]
    out = cf(*args)
    ref = mlp(*args)  # plain eager
    np.testing.assert_allclose(out.numpy(), ref.numpy(), rtol=1e-4,
                               atol=1e-5)


def test_compile_env_fallback(monkeypatch):
    @tl.compile
    def f(x):
        return tl.relu(x + 1.0)

    x = rn(32, 32)
    monkeypatch.setenv("MT_COMPILE", "0")
    out = f(tl.tensor(x))
    assert len(f._cache) == 0  # no tracing happened
    np.testing.assert_allclose(out.numpy(), np.maximum(x + 1.0, 0))
    monkeypatch.delenv("MT_COMPILE")
    out2 = f(tl.tensor(x))
    assert len(f._cache) == 1
    np.testing.assert_allclose(out2.numpy(), np.maximum(x + 1.0, 0))


def test_compile_cache_keyed_on_shape():
    @tl.compile
    def f(x):
        return tl.sigmoid(x * 2.0)

    f(tl.tensor(rn(8, 8)))
    f(tl.tensor(rn(16, 16)))
    assert len(f._cache) == 2


def test_fused_kernel_names_are_deterministic():
    """Regression: fused-kernel names must not depend on str hash
    randomization (PYTHONHASHSEED) — a process-salted name made every
    disk cubin / autotune pick miss across processes."""
    import hashlib
    from minitriton.compile import _ew_kernel, _mm_epi_kernel, \
        _mma_epi_kernel

    for prefix, key, fn in [
        ("fused_ew", ("fused_ew", "x0 * 2.0", 1, (), (False,)),
         lambda: _ew_kernel("x0 * 2.0", 1, [], [False])),
        ("fused_mm", ("fused_mm", "tl.exp(v)"),
         lambda: _mm_epi_kernel("tl.exp(v)")),
        ("fused_mma_epi", ("fused_mma_epi", "tl.exp(v)"),
         lambda: _mma_epi_kernel("tl.exp(v)")),
    ]:
        k = fn()
        expected = int.from_bytes(
            hashlib.sha256(repr(key).encode()).digest()[:4],
            "big") % 10**8
        assert k.name == f"{prefix}_{expected}", (k.name, prefix)
        assert fn() is k  # in-process cache hit



# ---------------------------------------------------------------------------
# captured tensors: module globals / closure cells raise an actionable
# error at trace time (plain scalar captures keep the snapshot + warning)
# ---------------------------------------------------------------------------

_GLOBAL_W = None  # set to a real tensor inside the test (lazy CUDA init)


def test_compile_global_tensor_capture_raises():
    global _GLOBAL_W
    _GLOBAL_W = tl.tensor(rn(32, 32))

    @tl.compile
    def f(x):
        return x @ _GLOBAL_W

    with pytest.raises(RuntimeError) as ei:
        f(tl.tensor(rn(32, 32)))
    msg = str(ei.value)
    assert "captured tensor" in msg and "_GLOBAL_W" in msg
    assert "argument" in msg


def test_compile_closure_tensor_capture_raises():
    w = tl.tensor(rn(32, 32))

    @tl.compile
    def f(x):
        return x @ w

    with pytest.raises(RuntimeError) as ei:
        f(tl.tensor(rn(32, 32)))
    msg = str(ei.value)
    assert "captured tensor" in msg and "'w'" in msg


def test_compile_scalar_closure_capture_still_works():
    scale = 2.0

    @tl.compile
    def f(x):
        return x * scale

    x = rn(32, 32)
    with pytest.warns(UserWarning, match="captured state"):
        out = f(tl.tensor(x))
    np.testing.assert_allclose(out.numpy(), x * 2.0, rtol=1e-6)


# a module global sharing a Tensor method name must not be mistaken for
# a capture when the fn only uses it as an attribute (set lazily inside
# the tests to keep CUDA init out of import)
reshape = None


def test_compile_attr_name_colliding_global_not_flagged():
    global reshape
    reshape = tl.tensor(rn(4, 4))
    try:
        @tl.compile
        def f(x):
            return x.reshape((8, 8)) * 2.0  # attribute, not the global

        x = rn(8, 8)
        np.testing.assert_allclose(f(tl.tensor(x)).numpy(), x * 2.0,
                                   rtol=1e-6)
    finally:
        reshape = None


def test_compile_method_named_global_capture_raises():
    global reshape
    reshape = tl.tensor(rn(8, 8))
    try:
        @tl.compile
        def f(x):
            return x + reshape  # LOAD_GLOBAL: a real capture

        with pytest.raises(RuntimeError, match="captured tensor"):
            f(tl.tensor(rn(8, 8)))
    finally:
        reshape = None


# ---------------------------------------------------------------------------
# embedding / cross_entropy inside a compiled fn: the trace backend records
# their row nodes explicitly; the eager bounds check must not kill tracing
# ---------------------------------------------------------------------------

def test_compile_embedding_rows():
    @tl.compile
    def f(w, idx):
        return tl.embedding(w, idx)

    w = rn(16, 8)
    idx = np.array([0, 3, 3, 15], dtype=np.int64)
    out = f(tl.tensor(w), tl.tensor(idx))
    np.testing.assert_allclose(out.numpy(), w[idx], rtol=1e-6, atol=1e-7)


def test_compile_cross_entropy_rows():
    @tl.compile
    def f(x, tgt):
        return tl.cross_entropy(x, tgt)

    x = rn(8, 12)
    tgt = np.array([0, 3, 11, 5, 7, 1, 2, 9])
    out = f(tl.tensor(x), tl.tensor(tgt))
    z = x - x.max(1, keepdims=True)
    nll = np.log(np.exp(z).sum(1)) + x.max(1) - x[np.arange(8), tgt]
    np.testing.assert_allclose(out.numpy(), nll.mean(), rtol=1e-4,
                               atol=1e-6)
