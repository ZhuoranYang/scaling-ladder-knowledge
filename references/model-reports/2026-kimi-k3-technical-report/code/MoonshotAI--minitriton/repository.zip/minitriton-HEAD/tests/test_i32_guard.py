"""i32 addressing backstop guards: a single tensor at/over the
limit (2**31 elements) must raise loudly instead of wrapping kernel
addresses (nondeterministic CUDA_ERROR_ILLEGAL_ADDRESS or, worse, silent
reads/writes of other allocations).

The real limit needs an 8.6 GiB allocation, so the tests monkeypatch
minitriton.device.cuda.elementwise._I32_ELEM_LIMIT down to 1<<12 — the
exact same guard code paths then fire at toy sizes. Coverage:

- elementwise flat path (contiguous add) and nd path (transposed add)
- every dispatch-level guard: matmul/bmm (f32 + bf16 routes), flash
  forward/backward (+ qkv variants), kda_forward (all three variants)
- strided-view operand spans at the matmul/bmm entries (numel under
  the limit, max reachable offset over it — the prep-passthrough case)
- NO false positive on the row-chunking row-kernel family: layer_norm over an
  over-threshold tensor row-chunks and must keep working
- the unpatched small-size fast paths are unaffected
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.device.cuda import elementwise as ew
from minitriton.device.cuda import ops as tl_be

LIMIT = 1 << 12


@pytest.fixture(autouse=True)
def _clear_plans():
    # the plan cache replays resolved fast-launch handles, bypassing the
    # Python launchers (and their guards) — clear it so every test really
    # goes through the guarded launch logic.
    tl_be._PLANS.clear()
    yield
    tl_be._PLANS.clear()


@pytest.fixture
def tiny_limit(monkeypatch):
    monkeypatch.setattr(ew, "_I32_ELEM_LIMIT", LIMIT)
    return LIMIT


def T(x):
    return tl.tensor(np.ascontiguousarray(x, dtype=np.float32))


def rn(*shape):
    return np.random.default_rng(0).standard_normal(shape).astype(np.float32)


def assert_i32_raise(fn, label):
    with pytest.raises(RuntimeError) as ei:
        fn()
    msg = str(ei.value)
    assert "i32" in msg, msg
    assert "2^31" in msg, msg
    assert label in msg, msg


# ---------------------------------------------------------------------------
# elementwise launch entries (launch_flat / launch_nd)
# ---------------------------------------------------------------------------

def test_flat_add_raises(tiny_limit):
    x, y = T(rn(100, 100)), T(rn(100, 100))  # 10000 >= 4096, contiguous
    assert_i32_raise(lambda: x + y, "elementwise flat kernel")


def test_nd_add_raises(tiny_limit):
    xt = T(rn(100, 50)).t()  # (50, 100) non-contiguous -> nd path
    y = T(rn(50, 100))
    assert xt.shape == y.shape and not xt.is_contiguous()
    assert_i32_raise(lambda: xt + y, "elementwise nd kernel")


def test_nd_operand_span_raises(tiny_limit):
    # out is UNDER the limit, but a strided operand's max reachable offset
    # is not: x[::3] of a 6144-element base wraps its i32 stride product
    # even though the view itself is only 2048 elements
    x = T(rn(LIMIT + LIMIT // 2))[::3]
    assert not x.is_contiguous() and x.numel() == LIMIT // 2
    assert_i32_raise(lambda: x + T(rn(LIMIT // 2)),
                     "elementwise nd kernel operand")


def test_below_threshold_still_works(tiny_limit):
    x, y = rn(64, 32), rn(64, 32)  # 2048 < 4096
    np.testing.assert_allclose((T(x) + T(y)).numpy(), x + y,
                               rtol=1e-5, atol=1e-6)


# ---------------------------------------------------------------------------
# dispatch-level guards (device/cuda/ops.py)
# ---------------------------------------------------------------------------

def test_matmul_raises(tiny_limit):
    assert_i32_raise(lambda: tl_be.matmul(T(rn(100, 100)), T(rn(100, 100))),
                     "matmul")


def test_flash_attention_forward_raises(tiny_limit):
    q, k, v = (T(rn(1, 8, 64, 64)) for _ in range(3))  # 32768 >= 4096
    assert_i32_raise(lambda: tl_be.flash_attention_forward(q, k, v, 1.0),
                     "flash_attention_forward")


def _small():
    return tl.zeros((4,))


def _big():
    return tl.zeros((LIMIT + 8,))


# one over-limit input per call; the guards run before any shape/dtype
# logic, so the remaining arguments can be tiny dummies
DISPATCH_CASES = [
    ("bmm", lambda: tl_be.bmm(_big(), _small())),
    ("matmul_bf16", lambda: tl_be.matmul_bf16(_big(), _small())),
    ("bmm_bf16", lambda: tl_be.bmm_bf16(_small(), _big())),
    ("flash_attention_backward",
     lambda: tl_be.flash_attention_backward(_small(), _small(), _small(),
                                            _small(), _big(), _small(), 1.0)),
    ("flash_attention_forward_qkv",
     lambda: tl_be.flash_attention_forward_qkv(_big(), 1, 1.0)),
    ("flash_attention_backward_qkv",
     lambda: tl_be.flash_attention_backward_qkv(_small(), _big(), _small(),
                                                _small(), 1, 1.0)),
    ("kda_forward",
     lambda: tl_be.kda_forward(_small(), _small(), _small(), _small(),
                               _small(), _big(), _small(), _small(),
                               _small(), None)),
    ("kda_forward_fused",
     lambda: tl_be.kda_forward_fused(_small(), _small(), _small(),
                                     _small(), _big(), None)),
    ("kda_forward_mma",
     lambda: tl_be.kda_forward_mma(_small(), _small(), _big(), _small(),
                                   _small(), _small(), _small(), _small(),
                                   _small(), None)),
]


@pytest.mark.parametrize("label,fn", DISPATCH_CASES,
                         ids=[c[0] for c in DISPATCH_CASES])
def test_dispatch_guards_raise(tiny_limit, label, fn):
    assert_i32_raise(fn, label)


# ---------------------------------------------------------------------------
# strided-view span guards at the matmul/bmm entries: a unit-last-stride
# view whose numel is under the limit but whose max reachable offset is
# over it must be rejected loudly — _mm_prep* passes such views through
# to the i32 kernel address algebra unchanged
# ---------------------------------------------------------------------------

def _strided_2d():
    # (32, 96) view, row stride 192: numel 3072 < LIMIT, max offset
    # 31*192 + 95 = 6047 >= LIMIT; unit last stride -> prep passthrough
    v = T(rn(64, 96))[::2]
    assert v.numel() < LIMIT and v.strides[-1] == 1
    return v


def _strided_3d():
    # (2, 32, 32) view, batch stride 4096: numel 2048 < LIMIT, max
    # offset 4096 + 31*32 + 31 = 5119 >= LIMIT
    v = T(rn(8, 32, 32))[::4]
    assert v.numel() < LIMIT and v.strides[-1] == 1
    return v


MM_SPAN_CASES = [
    ("matmul", lambda: tl_be.matmul(_strided_2d(), T(rn(96, 16)))),
    ("matmul_bf16", lambda: tl_be.matmul_bf16(_strided_2d(), T(rn(96, 16)))),
    ("bmm", lambda: tl_be.bmm(_strided_3d(), T(rn(2, 32, 16)))),
    ("bmm_bf16", lambda: tl_be.bmm_bf16(_strided_3d(), T(rn(2, 32, 16)))),
]


@pytest.mark.parametrize("label,fn", MM_SPAN_CASES,
                         ids=[c[0] for c in MM_SPAN_CASES])
def test_mm_operand_span_raises(tiny_limit, label, fn):
    assert_i32_raise(fn, label)


def test_mm_strided_view_below_threshold_works(tiny_limit):
    # same prep-passthrough path with the span under the limit: no
    # false positive on legitimate strided operands
    base = rn(64, 32)
    av = T(base)[::2]  # (32, 32), row stride 64, max offset 2015 < LIMIT
    b = rn(32, 16)
    np.testing.assert_allclose(tl_be.matmul(av, T(b)).numpy(),
                               base[::2] @ b, rtol=1e-4, atol=1e-5)


# ---------------------------------------------------------------------------
# no false positive on the row-chunked family; normal paths unaffected
# ---------------------------------------------------------------------------

def test_layer_norm_not_guarded(tiny_limit):
    # 8192 elements >= the patched limit: the norm row kernels row-chunk
    # over-budget inputs (kernels/norm.py _I32_ELEM_BUDGET) and must NOT
    # be rejected by the backstop
    x = rn(128, 64)
    got = tl.layer_norm(T(x), (64,)).numpy()
    xf = x.astype(np.float64)
    ref = (xf - xf.mean(-1, keepdims=True)) / \
        np.sqrt(xf.var(-1, keepdims=True) + 1e-5)
    np.testing.assert_allclose(got, ref, rtol=1e-4, atol=1e-5)


def test_small_ops_unaffected():
    # real (unpatched) limit: the everyday fast paths must be inert
    x, y = rn(64, 64), rn(64, 64)
    np.testing.assert_allclose((T(x) + T(y)).numpy(), x + y,
                               rtol=1e-5, atol=1e-6)
    xt = T(rn(64, 32)).t()
    yt = rn(32, 64)
    np.testing.assert_allclose((xt + T(yt)).numpy(), xt.numpy() + yt,
                               rtol=1e-5, atol=1e-6)
    a, b = rn(32, 48), rn(48, 16)
    np.testing.assert_allclose(tl_be.matmul(T(a), T(b)).numpy(), a @ b,
                               rtol=1e-4, atol=1e-5)
    got = tl.layer_norm(T(x), (64,)).numpy()
    xf = x.astype(np.float64)
    ref = (xf - xf.mean(-1, keepdims=True)) / \
        np.sqrt(xf.var(-1, keepdims=True) + 1e-5)
    np.testing.assert_allclose(got, ref, rtol=1e-4, atol=1e-5)
