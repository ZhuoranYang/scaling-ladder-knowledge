"""Frontend Tensor<->scalar dtype rules: a float scalar
against an int tensor must compute in f32 — guards against compare
truncating the scalar to int (x < 1.5 becoming x < 1), binop's
runtime-Scalar branch doing the same via fptosi, and tl.where emitting
an i32 value for an f32 store (invalid MLIR). numpy oracle; CUDA only
(DSL kernels).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl

BLOCK = 8


@tl.kernel
def cmp_k(x_ptr, out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    x = tl.load(x_ptr + offs)
    m = x < 1.5
    tl.store(out_ptr + offs, tl.cast(m, tl.float32))


@tl.kernel
def cmp_flip_k(x_ptr, out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    x = tl.load(x_ptr + offs)
    m = 1.5 > x  # scalar on the lhs hits the mirrored compare branch
    tl.store(out_ptr + offs, tl.cast(m, tl.float32))


@tl.kernel
def add_arg_k(x_ptr, c, out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    x = tl.load(x_ptr + offs)
    tl.store(out_ptr + offs, x + c)  # c: runtime f32 Scalar kernel arg


@tl.kernel
def radd_arg_k(x_ptr, c, out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    x = tl.load(x_ptr + offs)
    tl.store(out_ptr + offs, c + x)  # mirrored binop branch


@tl.kernel
def add_const_k(x_ptr, out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    x = tl.load(x_ptr + offs)
    tl.store(out_ptr + offs, x + 1.5)  # CExpr float (always promoted)


@tl.kernel
def add_int_k(x_ptr, out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    x = tl.load(x_ptr + offs)
    tl.store(out_ptr + offs, x + 2)  # int scalar: stays i32 arithmetic


@tl.kernel
def where_k(x_ptr, out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    x = tl.load(x_ptr + offs)
    m = x > 0
    tl.store(out_ptr + offs, tl.where(m, 2.9, x))


@tl.kernel
def where_flip_k(x_ptr, out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    x = tl.load(x_ptr + offs)
    m = x > 0
    tl.store(out_ptr + offs, tl.where(m, x, 2.9))


def _run(kernel, x, *extra, out_dtype=tl.float32):
    xb = tl.Buffer.from_numpy(np.ascontiguousarray(x))
    ob = tl.Buffer(x.shape[0], out_dtype)
    kernel[(1,)](xb, *extra, ob, BLOCK=x.shape[0])
    tl.synchronize()
    return ob.to_numpy()


def test_compare_int_tensor_float_const():
    x = np.arange(BLOCK, dtype=np.int32)
    np.testing.assert_array_equal(_run(cmp_k, x), (x < 1.5).astype(np.float32))


def test_compare_int_tensor_float_const_flipped():
    x = np.arange(BLOCK, dtype=np.int32)
    np.testing.assert_array_equal(_run(cmp_flip_k, x),
                                  (1.5 > x).astype(np.float32))


def test_binop_int_tensor_float_runtime_arg():
    # runtime f32 Scalar (kernel arg) against an i32 block: promotes to
    # f32 instead of fptosi-truncating the argument
    x = np.arange(BLOCK, dtype=np.int32)
    np.testing.assert_allclose(_run(add_arg_k, x, 1.5), x + 1.5, rtol=1e-6)
    np.testing.assert_allclose(_run(radd_arg_k, x, 1.5), 1.5 + x, rtol=1e-6)


def test_binop_int_tensor_float_const():
    x = np.arange(BLOCK, dtype=np.int32)
    np.testing.assert_allclose(_run(add_const_k, x), x + 1.5, rtol=1e-6)


def test_binop_int_tensor_int_const_unchanged():
    # control: int scalar keeps integer arithmetic (no promotion) — the
    # result stays i32 (tl.store does not implicitly cast, so an i32 out)
    x = np.arange(BLOCK, dtype=np.int32)
    np.testing.assert_array_equal(
        _run(add_int_k, x, out_dtype=tl.int32), x + 2)


def test_where_float_scalar_int_tensor():
    x = np.arange(BLOCK, dtype=np.int32)
    np.testing.assert_allclose(_run(where_k, x),
                               np.where(x > 0, 2.9, x.astype(np.float32)),
                               rtol=1e-6)
    np.testing.assert_allclose(_run(where_flip_k, x),
                               np.where(x > 0, x.astype(np.float32), 2.9),
                               rtol=1e-6)
