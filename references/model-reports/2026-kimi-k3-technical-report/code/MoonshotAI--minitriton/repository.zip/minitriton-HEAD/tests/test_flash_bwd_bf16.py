"""Native bf16 flash-attention backward tests: the pure-DSL
bf16 mma kernels (general tile-level primitives, no builder intrinsics)
against an fp64 numpy backward reference and against the fused fp32
flash backward on the same operand values, plus the ops precision
routing and the autograd contract. No torch.

Numerics discipline (mirrors test_flash_mma.py bf16 tier): the operands
are the exact bf16 values (RNE-rounded host-side); dq/dk/dv are computed
with bf16 mma products off bf16-rounded P/dP (packed for the accumulate
mmas), so bf16 rtol 2e-2 applies to both references.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import nn, ops as tl_ops

from test_flash_mma import bf16_round, rn


def np_attention_bwd(q, k, v, g, scale):
    """fp64 causal flash backward reference of the given (already
    bf16-rounded) operand values; returns (dq, dk, dv, out)."""
    qf, kf, vf, gf = (x.astype(np.float64) for x in (q, k, v, g))
    T = q.shape[-2]
    s = np.einsum("bhtd,bhsd->bhts", qf, kf) * scale
    mask = np.triu(np.ones((T, T), dtype=bool), 1)
    s = np.where(mask, -np.inf, s)
    m = s.max(-1)
    e = np.exp(s - m[..., None])
    p = e / e.sum(-1)[..., None]
    o = np.einsum("bhts,bhsd->bhtd", p, vf)
    dp = np.einsum("bhtd,bhsd->bhts", gf, vf)
    ds = p * (dp - np.einsum("bhtd,bhtd->bht", gf, o)[..., None])
    dq = np.einsum("bhts,bhsd->bhtd", ds, kf) * scale
    dk = np.einsum("bhts,bhtd->bhsd", ds, qf) * scale
    dv = np.einsum("bhts,bhtd->bhsd", p, gf)
    return dq, dk, dv, o


def check_case(B, H, T, seeds=(0, 1, 2, 3)):
    hd = 64
    q, k, v, g = (bf16_round(rn(B, H, T, hd, seed=s)) for s in seeds)
    scale = 1.0 / np.sqrt(hd)
    tq, tk, tv, tg = (tl.tensor(x).astype(tl.bfloat16) for x in (q, k, v, g))
    out, lse = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                              with_lse=True)
    assert lse.dtype == tl.float32
    dq, dk, dv = tl_ops.flash_attention_backward(tq, tk, tv, out, tg, lse,
                                                 scale)
    assert dq.dtype == tl.bfloat16 and dk.dtype == tl.bfloat16 \
        and dv.dtype == tl.bfloat16
    rdq, rdk, rdv, ro = np_attention_bwd(q, k, v, g, scale)
    # fp64 reference of the exact bf16 inputs
    np.testing.assert_allclose(out.astype(tl.float32).numpy(), ro,
                               rtol=2e-2, atol=2e-2, err_msg="out")
    got = {"dq": dq, "dk": dk, "dv": dv}
    for name, ref in (("dq", rdq), ("dk", rdk), ("dv", rdv)):
        np.testing.assert_allclose(got[name].astype(tl.float32).numpy(),
                                   ref, rtol=2e-2, atol=2e-2, err_msg=name)
    # fused fp32 flash backward on the same operand values (the
    # mixed-precision route)
    fq, fk, fv, fo, fg = (tl.tensor(x.astype(np.float32))
                          for x in (q, k, v, ro, g))
    fdq, fdk, fdv = tl_ops.flash_attention_backward(fq, fk, fv, fo, fg, lse,
                                                    scale, precision="fp32")
    for name, ref in (("dq", fdq), ("dk", fdk), ("dv", fdv)):
        np.testing.assert_allclose(got[name].astype(tl.float32).numpy(),
                                   ref.numpy(), rtol=2e-2, atol=2e-2,
                                   err_msg=f"{name} vs fused f32 bwd")


@pytest.mark.parametrize("B,H,T", [(2, 3, 128), (1, 2, 512), (4, 4, 256),
                                   (2, 3, 63), (2, 3, 65), (1, 2, 100),
                                   (1, 2, 200), (2, 3, 127)])
def test_flash_bwd_bf16(B, H, T):
    """bf16 native flash bwd vs fp64 + fused-f32 references; ragged T
    exercises the predicated 4B staging and the T-boundary masks."""
    check_case(B, H, T)


def test_flash_bwd_bf16_minimum():
    """degenerate T=1 (causal attention reduces to identity on one row):
    grads must still be finite and correct."""
    check_case(1, 2, 1, seeds=(0, 1, 2, 3))


def test_flash_bwd_bf16_large_values():
    """larger-magnitude activations: errors track the bf16 scale of the
    tensors themselves (normalized check); no blowup/inf anywhere."""
    B, H, T, hd = 1, 2, 256, 64
    q, k, v, g = (bf16_round(rn(B, H, T, hd, seed=s) * 4.0)
                  for s in (0, 1, 2, 3))
    scale = 1.0 / np.sqrt(hd)
    tq, tk, tv, tg = (tl.tensor(x).astype(tl.bfloat16) for x in (q, k, v, g))
    out, lse = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                              with_lse=True)
    dq, dk, dv = tl_ops.flash_attention_backward(tq, tk, tv, out, tg, lse,
                                                 scale)
    rdq, rdk, rdv, _ = np_attention_bwd(q, k, v, g, scale)
    for name, got, ref in (("dq", dq, rdq), ("dk", dk, rdk), ("dv", dv, rdv)):
        gn = got.astype(tl.float32).numpy()
        assert np.isfinite(gn).all(), name
        assert np.abs(gn - ref).max() <= 2e-2 * (np.abs(ref).max() + 1e-9), \
            name


def test_flash_bwd_bf16_noncontig_do():
    """a non-contiguous upstream grad (transpose view) feeds the same
    native kernels through the ops-level contiguous() normalization."""
    B, H, T, hd = 2, 2, 128, 64
    q, k, v, g = (bf16_round(rn(B, H, T, hd, seed=s)) for s in (0, 1, 2, 3))
    scale = 1.0 / np.sqrt(hd)
    tq, tk, tv = (tl.tensor(x).astype(tl.bfloat16) for x in (q, k, v))
    th = tl.tensor(np.ascontiguousarray(g.transpose(0, 2, 1, 3)))
    tg = th.astype(tl.bfloat16).transpose(1, 2)  # (B, H, T, hd) non-contig
    assert not tg.is_contiguous()
    out, lse = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                              with_lse=True)
    dq, dk, _ = tl_ops.flash_attention_backward(tq, tk, tv, out, tg, lse,
                                                scale)
    rdq, _, _, _ = np_attention_bwd(q, k, v, g, scale)
    np.testing.assert_allclose(dq.astype(tl.float32).numpy(), rdq,
                               rtol=2e-2, atol=2e-2)


def test_flash_bwd_bf16_autograd_matches_unfused():
    """autograd route: bf16 fused fwd + native mma bwd vs the unfused f32
    composition grads (same operand values), the nn-level contract."""
    B, H, T, hd = 1, 2, 128, 64
    q, k, v, g = (bf16_round(rn(B, H, T, hd, seed=s)) for s in (0, 1, 2, 3))
    scale = 1.0 / np.sqrt(hd)
    tq, tk, tv = (tl.tensor(x).astype(tl.bfloat16) for x in (q, k, v))
    for t in (tq, tk, tv):
        t.requires_grad = True
    out = nn.causal_attention(tq, tk, tv, scale=scale)
    out.backward(tl.tensor(bf16_round(g)).astype(tl.bfloat16))
    uq, uk, uv = (tl.tensor(x) for x in (q, k, v))
    for t in (uq, uk, uv):
        t.requires_grad = True
    out2 = nn.attention.unfused_causal_attention(uq, uk, uv, scale)
    out2.backward(tl.tensor(g))
    for name, a, b in (("dq", tq.grad, uq.grad), ("dk", tk.grad, uk.grad),
                       ("dv", tv.grad, uv.grad)):
        np.testing.assert_allclose(a.astype(tl.float32).numpy(), b.numpy(),
                                   rtol=2e-2, atol=2e-2, err_msg=name)
