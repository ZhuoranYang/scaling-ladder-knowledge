"""mma (tensor-core) matmul tests: tl.mma_tile against numpy
references, in escalating order — per-lane single-atom fragments first
(one warp, one 16x8 atom, every lane's 4+2 operand elements exercised),
then multi-atom warp tiles, multi-warp blocks, masked/ragged shapes,
arbitrary strides, and transposed operand views. No torch.

Numerics discipline:
- tf32: reference = numpy(f64) matmul of the inputs rounded to 10-bit
  mantissa (round-half-away, mirroring cvt.rna.tf32.f32): rtol 1e-2.
- bf16: reference = numpy(f64) matmul of the exact bf16 inputs (RNE
  rounded host-side): rtol 1e-2.
- tf32x3: hi/lo split approximating fp32: reference = numpy f64 matmul of
  the raw f32 inputs; rtol 1e-5 at K <= 1024.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl


# ---------------------------------------------------------------------------
# host-side dtype helpers (numpy has no tf32/bf16)
# ---------------------------------------------------------------------------

def tf32_round(x: np.ndarray) -> np.ndarray:
    """f32 -> f32 with a tf32 mantissa (10 bits), round-to-nearest-away —
    bit-identical to cvt.rna.tf32.f32 for finite x."""
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    r = (b + np.uint32(0x1000)) & np.uint32(0xFFFFE000)
    return r.view(np.float32).reshape(x.shape)


def f32_to_bf16_bits(x: np.ndarray) -> np.ndarray:
    """f32 -> bf16 bit pattern (round-to-nearest-even), as uint16."""
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    r = (b + np.uint32(0x7FFF) + ((b >> 16) & 1)) >> 16
    return r.astype(np.uint16).reshape(x.shape)


def bf16_bits_to_f32(u: np.ndarray) -> np.ndarray:
    return (np.ascontiguousarray(u, dtype=np.uint16).astype(np.uint32)
            << 16).view(np.float32).reshape(u.shape)


def bf16_buffer(x_bits: np.ndarray) -> "tl.Buffer":
    buf = tl.Buffer(x_bits.size, tl.bfloat16)
    u = np.ascontiguousarray(x_bits, dtype=np.uint16)
    buf.device.memcpy_h2d(buf.ptr, u, buf.nbytes)
    return buf


# ---------------------------------------------------------------------------
# the test kernel: same EVEN_* protocol as the matmul_tile tests
# ---------------------------------------------------------------------------

@tl.kernel
def mma_kernel(a_ptr, b_ptr, c_ptr, M, N, K, lda, ldb,
               BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
               ATOM: tl.constexpr, STAGES: tl.constexpr,
               EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
               EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr,
               TRANS_A: tl.constexpr, TRANS_B: tl.constexpr,
               ONE_BAR: tl.constexpr, F2F: tl.constexpr,
               DYN_SMEM: tl.constexpr, ONE_SHOT: tl.constexpr,
               EPI: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    if TRANS_A:
        a_ptrs = a_ptr + offs_m[:, None] + offs_k[None, :] * lda
    else:
        a_ptrs = a_ptr + offs_m[:, None] * lda + offs_k[None, :]
    if TRANS_B:
        b_ptrs = b_ptr + offs_k[:, None] + offs_n[None, :] * ldb
    else:
        b_ptrs = b_ptr + offs_k[:, None] * ldb + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM=ATOM, STAGES=STAGES,
                          TRANS_A=TRANS_A, TRANS_B=TRANS_B, ONE_BAR=ONE_BAR,
                          F2F=F2F, DYN_SMEM=DYN_SMEM, ONE_SHOT=ONE_SHOT)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM=ATOM, STAGES=STAGES,
                          EVEN_K=EVEN_K, VEC=False,
                          a_mask=am, b_mask=bn,
                          TRANS_A=TRANS_A, TRANS_B=TRANS_B, ONE_BAR=ONE_BAR,
                          DYN_SMEM=DYN_SMEM, ONE_SHOT=ONE_SHOT)
    if EVEN_MN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                 EPI=EPI)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                 mask=cm, EPI=EPI)


def run_mma(M, N, K, bm, bn, bk, warps, stages, atom="tf32", lda=None,
            ldb=None, trans_a=False, trans_b=False, seed=0, one_bar=False,
            f2f=False, dyn=False, one_shot=False, epi=""):
    """Returns (out_f32, ref_f64): out is always the f32 accumulator; ref
    is the numpy f64 product of the *quantized* inputs (tf32 rn / exact
    bf16), so both compare with rtol 1e-2."""
    rng = np.random.default_rng(seed)
    lda = K if lda is None else lda
    ldb = N if ldb is None else ldb
    if atom == "bf16":
        # bf16 stage granularity is one 4B pair (cp.async needs 4B-aligned
        # src/dst): every element address must stay even, i.e. both strides
        # must be even (any K/M/N still works through pair-granular zfill).
        if lda % 2 or ldb % 2:
            raise ValueError("bf16 mma needs even lda/ldb")
    # A storage: plain (M, lda) row-major, or a transposed view over a
    # physical (K, lda) buffer (element (m, k) at m + k*lda, lda >= M).
    if trans_a:
        phys = rng.standard_normal((K, lda), dtype=np.float32)
        a_np = phys[:, :M].T.copy()          # logical (M, K)
        a_flat = phys.reshape(-1)
    else:
        phys = rng.standard_normal((M, lda), dtype=np.float32)
        a_np = phys[:, :K].copy() if lda != K else phys.copy()
        a_flat = phys.reshape(-1)
    if trans_b:
        # logical B (K, N): element (k, n) at k + n*ldb, ldb >= K
        physb = rng.standard_normal((N, ldb), dtype=np.float32)
        b_np = physb[:, :K].T.copy()         # logical (K, N)
        b_flat = physb.reshape(-1)
    else:
        physb = rng.standard_normal((K, ldb), dtype=np.float32)
        b_np = physb[:, :N].copy() if ldb != N else physb.copy()
        b_flat = physb.reshape(-1)
    if atom in ("tf32", "tf32x3"):
        da = tl.Buffer.from_numpy(a_flat)
        db = tl.Buffer.from_numpy(b_flat)
        a_q, b_q = a_np, b_np
        if atom == "tf32":
            a_q, b_q = tf32_round(a_np), tf32_round(b_np)
    else:
        a_bits, b_bits = f32_to_bf16_bits(a_flat), f32_to_bf16_bits(b_flat)
        da = bf16_buffer(a_bits)
        db = bf16_buffer(b_bits)
        # back through the same physical storage to the logical matrix
        if trans_a:
            a_q = bf16_bits_to_f32(a_bits).reshape(K, lda)[:, :M].T
        else:
            a_q = bf16_bits_to_f32(a_bits).reshape(M, lda)[:, :K]
        if trans_b:
            b_q = bf16_bits_to_f32(b_bits).reshape(N, ldb)[:, :K].T
        else:
            b_q = bf16_bits_to_f32(b_bits).reshape(K, ldb)[:, :N]
    dc = tl.Buffer(M * N, tl.float32)
    align = 8 if atom == "bf16" else 4
    kw = dict(BM=bm, BN=bn, BK=bk, ATOM=atom, STAGES=stages,
              EVEN_MK=M % bm == 0 and K % bk == 0
              and (trans_a or lda % align == 0),
              EVEN_KN=K % bk == 0 and N % bn == 0
              and (trans_b or ldb % align == 0),
              EVEN_MN=M % bm == 0 and N % bn == 0,
              EVEN_K=K % bk == 0,
              TRANS_A=trans_a, TRANS_B=trans_b, ONE_BAR=one_bar, F2F=f2f,
              DYN_SMEM=dyn, ONE_SHOT=one_shot, EPI=epi)
    grid = ((M + bm - 1) // bm, (N + bn - 1) // bn)
    mma_kernel[grid](da, db, dc, M, N, K, lda, ldb, num_warps=warps, **kw)
    tl.synchronize()
    ref = a_q.astype(np.float64) @ b_q.astype(np.float64)
    return dc.to_numpy().reshape(M, N), ref


# ---------------------------------------------------------------------------
# tf32: per-lane fragment progression
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages", [
    (16, 8, 8, 16, 8, 8, 1, 2),        # single atom, 1 warp
    (16, 8, 32, 16, 8, 8, 1, 2),       # k pipelining, 4 atoms deep
    (32, 16, 16, 32, 16, 16, 1, 2),    # multi-atom warp tile (2m x 2n)
    (32, 32, 64, 32, 32, 16, 1, 3),    # 3 stages
    (64, 64, 32, 64, 64, 16, 4, 2),    # 4 warps, 32x32 warp tiles
    (128, 128, 64, 128, 128, 16, 8, 2),  # 8 warps, BK16 (32KB smem)
    (128, 64, 64, 128, 64, 32, 4, 2),  # BK32, 48KB smem (static limit)
])
def test_mma_tf32_even(M, N, K, bm, bn, bk, warps, stages):
    out, ref = run_mma(M, N, K, bm, bn, bk, warps, stages)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages", [
    (100, 100, 100, 32, 32, 16, 4, 2),    # ragged everywhere
    (33, 65, 129, 32, 64, 16, 4, 2),
    (17, 9, 9, 32, 32, 16, 4, 2),         # M/N smaller than the tile
    (7, 5, 3, 32, 32, 16, 4, 2),          # tiny odd
    (1, 1, 1, 32, 32, 16, 4, 2),          # degenerate
    (129, 65, 4096, 64, 64, 32, 4, 2),    # long K, ragged M/N
    (512, 512, 520, 128, 64, 32, 4, 2),  # K % 8 == 0 but ragged tiles
])
def test_mma_tf32_masked(M, N, K, bm, bn, bk, warps, stages):
    out, ref = run_mma(M, N, K, bm, bn, bk, warps, stages)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


def test_mma_tf32_strides():
    # row strides beyond the minimum (padded): vec path still allowed
    out, ref = run_mma(64, 64, 64, 64, 64, 32, 4, 2, lda=68, ldb=68)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)
    # strides not 16B-aligned force the masked path (flag drop)
    out, ref = run_mma(64, 64, 64, 64, 64, 32, 4, 2, lda=66, ldb=66)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


@pytest.mark.parametrize("trans_a,trans_b", [
    (True, False), (False, True), (True, True),
])
def test_mma_tf32_trans(trans_a, trans_b):
    out, ref = run_mma(64, 64, 64, 64, 64, 32, 4, 2,
                       lda=80 if not trans_a else 72,
                       ldb=80 if not trans_b else 72,
                       trans_a=trans_a, trans_b=trans_b)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


# ---------------------------------------------------------------------------
# tf32x3: hi/lo split approximating fp32
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps", [
    (64, 64, 512, 64, 64, 32, 4),
    (128, 128, 1024, 128, 128, 16, 8),
    (96, 48, 1000, 32, 64, 32, 4),
])
def test_mma_tf32x3(M, N, K, bm, bn, bk, warps):
    rng = np.random.default_rng(0)
    a = rng.standard_normal((M, K), dtype=np.float32)
    b = rng.standard_normal((K, N), dtype=np.float32)
    out, _ = run_mma(M, N, K, bm, bn, bk, warps, 2, atom="tf32x3")
    ref32 = a @ b
    # split accumulation keeps the cross terms on a small running sum;
    # the fp32 reference itself deviates from exact by ~sqrt(K)*2^-24, so
    # near-zero elements get an atol floor at the fp32 rounding scale.
    np.testing.assert_allclose(out, ref32, rtol=1e-5,
                               atol=1e-5 * np.sqrt(K))


# ---------------------------------------------------------------------------
# bf16: m16n8k16
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages", [
    (16, 8, 16, 16, 8, 16, 1, 2),        # single atom
    (16, 8, 64, 16, 8, 16, 1, 2),
    (32, 16, 16, 32, 16, 16, 1, 2),
    (64, 64, 32, 64, 64, 16, 4, 2),
    (64, 64, 64, 64, 64, 32, 4, 2),
    (128, 128, 64, 128, 128, 32, 8, 2),
])
def test_mma_bf16_even(M, N, K, bm, bn, bk, warps, stages):
    out, ref = run_mma(M, N, K, bm, bn, bk, warps, stages, atom="bf16")
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages,lda,ldb", [
    (100, 100, 100, 32, 32, 32, 4, 2, None, None),
    (33, 65, 129, 32, 64, 16, 4, 2, 130, 66),   # ragged, even strides
    (7, 5, 3, 32, 32, 16, 4, 2, 4, 6),          # tiny odd, even strides
    (129, 65, 4096, 64, 64, 32, 4, 2, None, 66),  # long K, ragged M/N
])
def test_mma_bf16_masked(M, N, K, bm, bn, bk, warps, stages, lda, ldb):
    out, ref = run_mma(M, N, K, bm, bn, bk, warps, stages, atom="bf16",
                       lda=lda, ldb=ldb)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


@pytest.mark.parametrize("trans_a,trans_b", [
    (True, False), (False, True), (True, True),
])
def test_mma_bf16_trans(trans_a, trans_b):
    out, ref = run_mma(64, 64, 64, 64, 64, 32, 4, 2, atom="bf16",
                       lda=72, ldb=72,
                       trans_a=trans_a, trans_b=trans_b)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


# ---------------------------------------------------------------------------
# ONE_BAR: the single-barrier multistage schedule — same numerics
# contract, exercised across stage depths / trans views / masked shapes.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages", [
    (64, 64, 128, 64, 64, 32, 4, 2),     # T=4 > stages
    (64, 64, 64, 64, 64, 32, 4, 3),      # T=2 < stages (clamped prefetch)
    (128, 64, 320, 64, 64, 32, 4, 4),    # 4 stages, T=10
    (16, 8, 32, 16, 8, 16, 1, 2),        # single atom, one warp
    (96, 48, 1000, 32, 64, 32, 4, 2),    # ragged K through the vec path
])
def test_mma_bf16_one_bar(M, N, K, bm, bn, bk, warps, stages):
    out, ref = run_mma(M, N, K, bm, bn, bk, warps, stages, atom="bf16",
                       one_bar=True)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


@pytest.mark.parametrize("trans_a,trans_b", [
    (True, False), (False, True), (True, True),
])
def test_mma_bf16_one_bar_trans(trans_a, trans_b):
    # transposed views need lda/ldb >= K (the k-extent of a storage row)
    out, ref = run_mma(64, 64, 128, 64, 64, 32, 4, 3, atom="bf16",
                       lda=136, ldb=136, trans_a=trans_a, trans_b=trans_b,
                       one_bar=True)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


def test_mma_bf16_one_bar_masked():
    out, ref = run_mma(100, 100, 200, 32, 32, 32, 4, 3, atom="bf16",
                       one_bar=True)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


def test_mma_tf32_one_bar():
    # the x3 split-accumulator loop carries the token alongside both accs
    out, ref = run_mma(64, 64, 256, 64, 64, 32, 4, 3, atom="tf32x3",
                       one_bar=True)
    np.testing.assert_allclose(out, ref, rtol=1e-5,
                               atol=1e-5 * np.sqrt(256))
    out, ref = run_mma(64, 64, 128, 64, 64, 32, 4, 2, one_bar=True)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


# F2F (the LDG.128 -> register-tile -> STS staging path, kept behind
# the flag): same numerics discipline as the cp.async schedules.
@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages", [
    (64, 64, 64, 64, 64, 32, 4, 2),     # single stage pair
    (64, 64, 128, 64, 64, 32, 4, 3),    # 3 stages, 4 K tiles
    (128, 64, 640, 128, 64, 32, 4, 3),  # the qkv.fwd tile
    (128, 128, 2048, 128, 128, 32, 8, 2),
    (64, 64, 96, 64, 64, 64, 4, 2),     # BK64, odd-ish K count
    (32, 32, 320, 32, 32, 32, 1, 4),    # 1 warp, deep stages, 10 tiles
])
def test_mma_bf16_f2f(M, N, K, bm, bn, bk, warps, stages):
    out, ref = run_mma(M, N, K, bm, bn, bk, warps, stages, atom="bf16",
                       f2f=True)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)
    # and bit-identical to the two-barrier schedule
    out2, _ = run_mma(M, N, K, bm, bn, bk, warps, stages, atom="bf16")
    assert np.array_equal(out, out2)


# DYN_SMEM (dynamic smem staging): bf16 vec/plain/even-K
# tiles staged in the >48KB dynamic region (llvm extern global + inline-PTX
# cp.async/ldmatrix). Configs below are all over the 48KB static wall —
# (BM*BK + BK*BN) * 2B * STAGES bytes — so they cannot even compile on the
# static path. Same numerics contract as the other schedules.
@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages,one_bar", [
    (128, 128, 640, 128, 128, 64, 8, 3, False),  # 96KB, the registered cfg
    (128, 128, 640, 128, 128, 64, 8, 3, True),   # same, ONE_BAR
    (256, 128, 320, 128, 128, 64, 8, 3, False),  # T=5, ragged tile count
    (128, 128, 128, 128, 128, 64, 8, 3, False),  # T=2 < stages (clamped)
    (128, 64, 640, 128, 64, 32, 4, 6, False),    # 72KB, deep s6
    (128, 64, 640, 128, 64, 32, 4, 6, True),
    (64, 64, 256, 64, 64, 64, 4, 4, False),      # 64KB
    (64, 64, 256, 64, 64, 64, 4, 4, True),
    (128, 128, 512, 128, 128, 32, 8, 6, True),   # 96KB, BK32 deep
])
def test_mma_bf16_dyn_smem(M, N, K, bm, bn, bk, warps, stages, one_bar):
    smem = (bm * bk + bk * bn) * 2 * stages
    assert smem > 48 * 1024  # these cases only exist past the static wall
    out, ref = run_mma(M, N, K, bm, bn, bk, warps, stages, atom="bf16",
                       one_bar=one_bar, dyn=True)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


def test_mma_bf16_dyn_smem_below_wall():
    # dyn is not limited to >48KB: a 32KB config staged dynamically must
    # give bit-identical results to its static twin
    kw = dict(M=128, N=128, K=256, bm=128, bn=128, bk=32, warps=8, stages=2)
    out_d, _ = run_mma(atom="bf16", dyn=True, **kw)
    out_s, _ = run_mma(atom="bf16", dyn=False, **kw)
    assert np.array_equal(out_d, out_s)


def test_mma_dyn_smem_rejects_unsupported():
    # tf32 operands, transposed views, masks and f2f are unsupported
    from minitriton.compiler.builder import TileConfigError
    with pytest.raises(TileConfigError):
        run_mma(64, 64, 64, 64, 64, 32, 4, 2, atom="tf32", dyn=True)
    with pytest.raises(TileConfigError):
        run_mma(64, 64, 64, 64, 64, 32, 4, 2, atom="bf16", lda=72,
                trans_a=True, dyn=True)
    with pytest.raises(TileConfigError):
        run_mma(100, 100, 100, 32, 32, 32, 4, 2, atom="bf16", dyn=True)
    with pytest.raises(TileConfigError):
        run_mma(64, 64, 64, 64, 64, 32, 4, 2, atom="bf16", f2f=True,
                dyn=True)


# ONE_SHOT (short-K single-buffer whole-K schedule, the other registered
# a2 leftover direction): the prologue stages every K tile, one wait-all +
# one barrier, sync-free compute loop. Requires STAGES * BK >= K.
@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages,atom,trans_b,ldb", [
    (128, 128, 96, 128, 128, 32, 8, 3, "bf16", False, None),   # head.dX geo
    (128, 128, 96, 128, 128, 32, 8, 3, "bf16", True, 104),     # ^Tb variant
    (64, 64, 96, 64, 64, 32, 4, 3, "bf16", False, None),
    (64, 64, 192, 64, 64, 64, 4, 3, "bf16", False, None),
    (64, 64, 64, 64, 64, 32, 4, 4, "bf16", False, None),  # stages > n_tiles
    (64, 64, 96, 64, 64, 32, 4, 3, "tf32x3", False, None),    # x3 iter_args
    (64, 64, 96, 64, 64, 32, 4, 3, "tf32", False, None),
])
def test_mma_one_shot(M, N, K, bm, bn, bk, warps, stages, atom, trans_b,
                      ldb):
    assert stages * bk >= K  # the one_shot caller contract
    out, ref = run_mma(M, N, K, bm, bn, bk, warps, stages, atom=atom,
                       trans_b=trans_b, ldb=ldb, one_shot=True)
    if atom == "tf32x3":
        np.testing.assert_allclose(out, ref, rtol=1e-5,
                                   atol=1e-5 * np.sqrt(K))
    else:
        np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


def test_mma_one_shot_masked():
    # ragged shape through the masked path (zfilled tail slots unread)
    out, ref = run_mma(100, 100, 100, 32, 32, 32, 4, 4, atom="bf16",
                       one_shot=True)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


def test_mma_one_shot_dyn_smem():
    # one_shot over the dynamic region: K=640 whole-K staging needs 80KB
    # at the (32,32,64) tile — impossible on the static 48KB path
    out, ref = run_mma(64, 64, 640, 32, 32, 64, 2, 10, atom="bf16",
                       dyn=True, one_shot=True)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


def test_mma_one_shot_rejects_other_schedules():
    from minitriton.compiler.builder import TileConfigError
    with pytest.raises(TileConfigError):
        run_mma(64, 64, 64, 64, 64, 32, 4, 2, atom="bf16", one_bar=True,
                one_shot=True)
    with pytest.raises(TileConfigError):
        run_mma(64, 64, 64, 64, 64, 32, 4, 2, atom="bf16", f2f=True,
                one_shot=True)


# ---------------------------------------------------------------------------
# smem-transpose epilogue (store_m4 epi="smem", used by head.dX/head.fwd):
# the C fragment is staged through a swizzled smem
# buffer and re-stored as row-contiguous 16B chunks. Same numerics as the
# default store — every case also asserts BIT-IDENTITY against epi="" on
# the same tile (same bias add, same bf16 pack, same f32 values).
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages,atom", [
    (64, 64, 64, 64, 64, 32, 4, 2, "bf16"),      # static epi (32KB total)
    (64, 64, 64, 64, 64, 64, 4, 2, "bf16"),      # epi pushed past 48KB (dyn)
    (128, 64, 64, 128, 64, 32, 4, 2, "bf16"),    # 32KB f32 epi, dyn
    (64, 32, 64, 64, 32, 64, 2, 2, "bf16"),      # 2 warps (head.fwd tile)
    (128, 128, 64, 128, 128, 32, 8, 2, "bf16"),  # 64KB f32 epi, dyn
    (16, 8, 16, 16, 8, 16, 1, 2, "bf16"),        # single atom, 1 warp
    (64, 64, 64, 64, 64, 32, 4, 2, "tf32"),      # tf32 atom, f32 out
])
def test_mma_f32_smem_epi(M, N, K, bm, bn, bk, warps, stages, atom):
    out, ref = run_mma(M, N, K, bm, bn, bk, warps, stages, atom=atom,
                       epi="smem")
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)
    out2, _ = run_mma(M, N, K, bm, bn, bk, warps, stages, atom=atom)
    assert np.array_equal(out, out2)  # bit-identical to the epi="" store


@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages,lda,ldb", [
    (100, 100, 100, 32, 32, 16, 4, 2, None, None),  # ragged everywhere
    (17, 9, 9, 32, 32, 16, 4, 2, 10, 10),  # M/N smaller than the tile
    (65, 99, 37, 32, 32, 16, 4, 2, 38, 100),  # odd C rows (N=99, f32
                                              # 4B-misaligned) -> the
                                              # scalar fallback per chunk
    (129, 64, 64, 64, 64, 32, 4, 2, None, None),  # ragged M, 2x2 warps
])
def test_mma_f32_smem_epi_masked(M, N, K, bm, bn, bk, warps, stages, lda,
                                 ldb):
    out, ref = run_mma(M, N, K, bm, bn, bk, warps, stages, atom="bf16",
                       lda=lda, ldb=ldb, epi="smem")
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)
    out2, _ = run_mma(M, N, K, bm, bn, bk, warps, stages, atom="bf16",
                      lda=lda, ldb=ldb)
    assert np.array_equal(out, out2)


def test_mma_f32_smem_epi_schedules():
    # the epilogue composes with the ONE_BAR schedule, and with DYN_SMEM
    # staging — the latter forces the aliased-dyn-region pre-barrier (a
    # 64KB f32 epi cannot fit the static remainder next to 32KB of dyn
    # staging, so it lands in the dyn region above it)
    out, ref = run_mma(64, 64, 64, 64, 64, 32, 4, 2, atom="bf16",
                       one_bar=True, epi="smem")
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)
    out, ref = run_mma(128, 128, 64, 128, 128, 32, 8, 2, atom="bf16",
                       dyn=True, epi="smem")
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)
    out2, _ = run_mma(128, 128, 64, 128, 128, 32, 8, 2, atom="bf16",
                      dyn=True)
    assert np.array_equal(out, out2)


def test_mma_smem_epi_rejects_bad_args():
    from minitriton.compiler.builder import TileConfigError
    from minitriton.frontend.code_generator import DSLCompileError
    with pytest.raises(DSLCompileError):  # unknown EPI spelling (frontend)
        run_mma(64, 64, 64, 64, 64, 32, 4, 2, atom="bf16", epi="bogus")
    with pytest.raises(TileConfigError):  # non-pow2 chunk row (BN=48)
        run_mma(64, 48, 64, 64, 48, 32, 4, 2, atom="bf16", epi="smem")


@tl.kernel
def mma_epi_bf16_kernel(a_ptr, b_ptr, c_ptr, bias_ptr, M, N, K, lda, ldb,
                        BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
                        STAGES: tl.constexpr, EVEN: tl.constexpr,
                        BIAS: tl.constexpr, EPI: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * lda + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * ldb + offs_n[None, :]
    if EVEN:
        acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM="bf16", STAGES=STAGES)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM="bf16", STAGES=STAGES,
                          EVEN_K=False, VEC=False, a_mask=am, b_mask=bn)
    if BIAS:
        bpt = bias_ptr + pid_n * BN + tl.arange(0, BN)
        if EVEN:
            tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                     bias=bpt, EPI=EPI)
        else:
            cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
            tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                     mask=cm, bias=bpt, EPI=EPI)
    elif EVEN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                 EPI=EPI)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
                 mask=cm, EPI=EPI)


def run_mma_epi_bf16(M, N, K, bm, bn, bk, warps, stages, bias=False,
                     bias_f32=False, epi="smem", seed=0, lda=None,
                     ldb=None):
    """bf16-out smem-epilogue runner; returns (out_u16_bits, ref_f64).
    lda/ldb are the (bf16-must-be-even) operand row strides; the C row
    stride is N itself so odd N exercises the misaligned-store fallback."""
    lda = K if lda is None else lda
    ldb = N if ldb is None else ldb
    rng = np.random.default_rng(seed)
    a_phys = rng.standard_normal((M, lda)).astype(np.float32)
    b_phys = rng.standard_normal((K, ldb)).astype(np.float32)
    a_bits, b_bits = f32_to_bf16_bits(a_phys), f32_to_bf16_bits(b_phys)
    da, db = bf16_buffer(a_bits), bf16_buffer(b_bits)
    ref = bf16_bits_to_f32(a_bits)[:, :K].astype(np.float64) @ \
        bf16_bits_to_f32(b_bits)[:, :N].astype(np.float64)
    b32 = rng.standard_normal((N,)).astype(np.float32)
    if bias:
        ref = ref + b32
        dbias = tl.Buffer.from_numpy(b32) if bias_f32 else \
            bf16_buffer(f32_to_bf16_bits(b32))
    else:
        dbias = da  # unused slot filler (same trick as the launcher)
    dc = tl.Buffer(M * N, tl.bfloat16)
    even = M % bm == 0 and N % bn == 0 and K % bk == 0
    grid = ((M + bm - 1) // bm, (N + bn - 1) // bn)
    mma_epi_bf16_kernel[grid](da, db, dc, dbias, M, N, K, lda, ldb,
                              BM=bm, BN=bn, BK=bk, STAGES=stages,
                              EVEN=even, BIAS=bias, EPI=epi,
                              num_warps=warps)
    tl.synchronize()
    u = np.empty(dc.nelem, dtype=np.uint16)
    dc.device.memcpy_d2h(u, dc.ptr, dc.nbytes)
    return u.reshape(M, N), ref


@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,stages,bias,bias_f32,lda,ldb", [
    (64, 64, 64, 64, 64, 32, 4, 2, False, False, None, None),
    (64, 64, 64, 64, 64, 32, 4, 2, True, False, None, None),  # bf16 bias
    (64, 64, 64, 64, 64, 32, 4, 2, True, True, None, None),   # f32 bias
    (128, 128, 64, 128, 128, 32, 8, 2, True, False, None, None),  # 8 warps
    (64, 32, 640, 64, 32, 64, 2, 2, True, False, None, None),  # head.fwd
    (100, 100, 100, 32, 32, 16, 4, 2, True, False, None, None),  # ragged
    (65, 99, 37, 32, 32, 16, 4, 2, True, False, 38, 100),  # odd C rows
])
def test_mma_bf16_smem_epi(M, N, K, bm, bn, bk, warps, stages, bias,
                           bias_f32, lda, ldb):
    out, ref = run_mma_epi_bf16(M, N, K, bm, bn, bk, warps, stages,
                                bias=bias, bias_f32=bias_f32, epi="smem",
                                lda=lda, ldb=ldb)
    got = bf16_bits_to_f32(out).astype(np.float64)
    np.testing.assert_allclose(got, ref, rtol=2e-2, atol=1e-2)
    # bit-identical to the epi="" epilogue on the same tile (bias
    # included: same f32 add before the same bf16 pack)
    out2, _ = run_mma_epi_bf16(M, N, K, bm, bn, bk, warps, stages,
                               bias=bias, bias_f32=bias_f32, epi="",
                               lda=lda, ldb=ldb)
    assert np.array_equal(out, out2)




# ---------------------------------------------------------------------------
# eager wiring: allow_tf32 opt-in and the dtype=bf16 route
# ---------------------------------------------------------------------------

def test_eager_allow_tf32_roundtrip():
    """allow_tf32 off -> exact fp32; on -> tf32-rounded operands; off again
    -> exact fp32 restored (torch allow_tf32 semantics, default off)."""
    from minitriton.device.cuda import ops as cuda_ops
    rng = np.random.default_rng(0)
    M = N = K = 192
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)
    ea, eb = tl.from_numpy(a), tl.from_numpy(b)
    assert not cuda_ops.get_allow_tf32()
    out0 = tl.ops.matmul(ea, eb).numpy()
    np.testing.assert_allclose(out0, a @ b, rtol=1e-4, atol=1e-3)
    try:
        cuda_ops.set_allow_tf32(True)
        out1 = tl.ops.matmul(ea, eb).numpy()
        ref = tf32_round(a).astype(np.float64) @ tf32_round(b).astype(np.float64)
        d = np.abs(out1 - ref) - 1e-2 * np.abs(ref)
        assert d.max() < 2e-2 * np.sqrt(K)
        ob = tl.ops.bmm(ea.reshape((1, M, K)), eb.reshape((1, K, N))).numpy()[0]
        d = np.abs(ob - ref) - 1e-2 * np.abs(ref)
        assert d.max() < 2e-2 * np.sqrt(K)
    finally:
        cuda_ops.set_allow_tf32(False)
    out2 = tl.ops.matmul(ea, eb).numpy()
    assert np.array_equal(out0, out2)


def test_eager_matmul_bf16():
    """matmul(bf16, bf16) -> bf16 through the mma route; odd strides (odd
    K rows) fall back to an exact f32 compute."""
    rng = np.random.default_rng(0)
    M, N, K = 256, 192, 320
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)
    o16 = tl.ops.matmul(tl.from_numpy(a).astype(tl.bfloat16),
                        tl.from_numpy(b).astype(tl.bfloat16))
    assert o16.dtype == tl.bfloat16
    qa = bf16_bits_to_f32(f32_to_bf16_bits(a))
    qb = bf16_bits_to_f32(f32_to_bf16_bits(b))
    ref = qa.astype(np.float64) @ qb.astype(np.float64)
    d = np.abs(o16.numpy().astype(np.float64) - ref)
    assert d.max() < 1.0
    # mma-ineligible strides (odd K): still correct via the f32 fallback
    o3 = tl.ops.matmul(tl.from_numpy(a[:, :319]).astype(tl.bfloat16),
                       tl.from_numpy(b[:319, :]).astype(tl.bfloat16))
    ref3 = (bf16_bits_to_f32(f32_to_bf16_bits(a[:, :319])).astype(np.float64)
            @ bf16_bits_to_f32(f32_to_bf16_bits(b[:319, :])).astype(np.float64))
    d3 = np.abs(o3.numpy().astype(np.float64) - ref3)
    assert d3.max() < 1.0
    # batched: bmm(bf16) route
    ab = rng.standard_normal((2, 64, 96)).astype(np.float32)
    bb = rng.standard_normal((2, 96, 80)).astype(np.float32)
    ob = tl.ops.bmm(tl.from_numpy(ab).astype(tl.bfloat16),
                    tl.from_numpy(bb).astype(tl.bfloat16))
    assert ob.dtype == tl.bfloat16
    refb = (bf16_bits_to_f32(f32_to_bf16_bits(ab)).astype(np.float64)
            @ bf16_bits_to_f32(f32_to_bf16_bits(bb)).astype(np.float64))
    db = np.abs(ob.numpy().astype(np.float64) - refb)
    assert db.max() < 1.0


@pytest.mark.parametrize("a_dt,b_dt", [("f32", "bf16"), ("bf16", "f32"),
                                       ("f32", "f32")])
@pytest.mark.parametrize("M,N,K", [(256, 192, 320), (255, 192, 320),
                                   (64, 640, 16384)])
def test_eager_matmul_bf16_f32_in(a_dt, b_dt, M, N, K):
    """matmul_bf16 with f32 operand(s): no materialized cast — the f32
    operand is staged as f32 and packed to bf16 in-register (RN), so the
    result must equal cast-then-matmul. Covers plain/even tiles, masked
    (odd M), K-heavy (the dW family, split-K judgement) and transposed
    operands. Shapes keep bf16 operands mma-eligible (odd M only masks
    out rows); the odd-stride fallback contract is covered by
    test_eager_matmul_bf16."""
    rng = np.random.default_rng(1)
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)

    def mk(x, dt):
        return tl.from_numpy(x).astype(tl.bfloat16) if dt == "bf16" \
            else tl.from_numpy(x)

    # fp64 oracle on bf16-rounded operands (what the mma computes)
    qa = bf16_bits_to_f32(f32_to_bf16_bits(a))
    qb = bf16_bits_to_f32(f32_to_bf16_bits(b))
    ref = qa.astype(np.float64) @ qb.astype(np.float64)
    out32 = tl.ops.matmul_bf16(mk(a, a_dt), mk(b, b_dt),
                               out_dtype=tl.float32)
    d = np.abs(out32.numpy().astype(np.float64) - ref)
    # K-heavy shapes are split-K judged: the judged route flips between
    # split-K (short accumulation chains, ~1e-3) and the plain kernel
    # (one ascending f32 chain over K=16384, up to ~4.5e-3 on this
    # oracle) with autotune timing — both are legitimate bf16-family
    # accumulation noise (semantic breakage shows >=1e-2; the e2e family
    # band is <=5e-3)
    tol32 = 6e-3 if K >= 4096 else 3e-3
    assert (d / (1.0 + np.abs(ref))).max() < tol32
    out = tl.ops.matmul_bf16(mk(a, a_dt), mk(b, b_dt))
    assert out.dtype == tl.bfloat16
    if K < 4096 or K < 4 * M:
        # plain (non-split-K) route: bf16-out is exactly the same
        # accumulator rounded on store
        assert np.array_equal(out.numpy(),
                              bf16_bits_to_f32(f32_to_bf16_bits(
                                  out32.numpy())))
    else:
        # K-heavy: split-K and plain vary in accumulation order; bf16-out
        # stays within storage-rounding + accumulation noise of the oracle
        d2 = np.abs(out.numpy().astype(np.float64) - ref)
        assert (d2 / (1.0 + np.abs(ref))).max() < 1e-2
    # the transposed-operand layout (the dW route: g.T @ x); the bf16
    # staging needs even K strides on transposed views, so an even
    # transposed M is used here (the odd-stride fallback contract is
    # covered by test_eager_matmul_bf16)
    mt = M - (M % 2)
    g = rng.standard_normal((K, mt)).astype(np.float32)
    x = rng.standard_normal((K, N)).astype(np.float32)
    out_t = tl.ops.matmul_bf16(mk(g, a_dt).t(), mk(x, b_dt),
                               out_dtype=tl.float32)
    qg = bf16_bits_to_f32(f32_to_bf16_bits(g))
    qx = bf16_bits_to_f32(f32_to_bf16_bits(x))
    ref_t = qg.T.astype(np.float64) @ qx.astype(np.float64)
    dt = np.abs(out_t.numpy().astype(np.float64) - ref_t)
    assert (dt / (1.0 + np.abs(ref_t))).max() < tol32


def test_eager_matmul_bf16_f32_in_odd_k():
    """f32 operands have no even-stride constraint: odd K stays on the
    mma (masked + zfill staging), value = rounded-operands product."""
    rng = np.random.default_rng(2)
    M, N, K = 256, 192, 319
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)
    out = tl.ops.matmul_bf16(tl.from_numpy(a), tl.from_numpy(b),
                             out_dtype=tl.float32)
    qa = bf16_bits_to_f32(f32_to_bf16_bits(a))
    qb = bf16_bits_to_f32(f32_to_bf16_bits(b))
    ref = qa.astype(np.float64) @ qb.astype(np.float64)
    d = np.abs(out.numpy().astype(np.float64) - ref)
    assert (d / (1.0 + np.abs(ref))).max() < 3e-3


def test_splitk_route_correct_and_pick_consistent():
    """Regression: splitk_pick must return the tuner's SPLIT_K.
    Guarded failure mode: looking up the bare (M, N, K) in a dict keyed
    with the kvals salt returns 0, silently disabling the split-K route
    (and would run the reduce with S=0, i.e. partials[0] unsummed, if a
    stale pick ever engaged). Here the route is exercised directly:
    tune + launch + reduce, then check the pick and the numerics."""
    from minitriton.device.cuda import kernels as K_
    from minitriton.tensor import empty
    M, N, K = 640, 640, 16384
    rng = np.random.default_rng(0)
    g = rng.standard_normal((K, M)).astype(np.float32)
    x = rng.standard_normal((K, N)).astype(np.float32)
    a = tl.tensor(g).astype(tl.bfloat16).t()
    b = tl.tensor(x).astype(tl.bfloat16)
    partials = empty((16, M, N), tl.float32, "cuda")
    out = empty((M, N), tl.float32, "cuda")
    sk = K_.launch_matmul_mma_splitk(a, b, partials, M, N, K, "bf16")
    assert sk >= 2  # every splitk config has SPLIT_K in (2, 4, 8, 16)
    K_.launch_splitk_reduce(partials, sk, out, M * N)
    qg = bf16_bits_to_f32(f32_to_bf16_bits(g))
    qx = bf16_bits_to_f32(f32_to_bf16_bits(x))
    ref = qg.T.astype(np.float64) @ qx.astype(np.float64)
    d = np.abs(out.numpy().astype(np.float64) - ref)
    assert (d / (1.0 + np.abs(ref))).max() < 6e-3
