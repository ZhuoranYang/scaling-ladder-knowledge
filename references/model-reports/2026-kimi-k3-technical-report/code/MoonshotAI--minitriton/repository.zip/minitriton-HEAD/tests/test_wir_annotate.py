"""W-IR annotation surface tests (IR-2, MINITRITON_WIR_ANNOTATE):
opt-in exact offset forms on the main builder kernel paths
(matmul_tile/mma_tile mainloops, the DSL smem/staging constructs),
zero emission when off, exact per-thread form evaluation, passes +
verifier staying sound on the annotated production kernels.
"""

import os
import sys

from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.compiler.builder import Builder, SepOff, Affine
from minitriton.compiler.lowering import lower_device_module


def _mm_probe(env_on, atom="tf32", tm=4, tn=16, nt=64):
    """One (64, 32) @ (32, 64) matmul_tile kernel (t2 path)."""
    if env_on:
        os.environ["MINITRITON_WIR_ANNOTATE"] = "1"
    else:
        os.environ.pop("MINITRITON_WIR_ANNOTATE", None)
    try:
        with Builder("t2probe", nt) as b:
            args = b.begin([("a", ("ptr", tl.float32)),
                            ("bb", ("ptr", tl.float32)),
                            ("c", ("ptr", tl.float32)), ("K", tl.int32)])
            a_pt = type(args["a"])(args["a"].arg, SepOff(
                (64, 32), Affine(0, 32, 64), Affine(0, 1, 32)))
            bb_pt = type(args["bb"])(args["bb"].arg, SepOff(
                (32, 64), Affine(0, 64, 32), Affine(0, 1, 64)))
            c_pt = type(args["c"])(args["c"].arg, SepOff(
                (64, 64), Affine(0, 64, 64), Affine(0, 1, 64)))
            acc = b.matmul_tile(a_pt, bb_pt, args["K"], tm=tm, tn=tn,
                                stages=2)
            b.store(c_pt, acc)
            return b.finish()
    finally:
        os.environ.pop("MINITRITON_WIR_ANNOTATE", None)


def _mma_probe(env_on, atom="tf32", a_trans=False, b_trans=False, nt=128):
    if env_on:
        os.environ["MINITRITON_WIR_ANNOTATE"] = "1"
    else:
        os.environ.pop("MINITRITON_WIR_ANNOTATE", None)
    try:
        with Builder("m4probe", nt) as b:
            args = b.begin([("a", ("ptr", tl.float32)),
                            ("bb", ("ptr", tl.float32)),
                            ("c", ("ptr", tl.float32)), ("K", tl.int32)])
            if a_trans:
                a_pt = type(args["a"])(args["a"].arg, SepOff(
                    (64, 32), Affine(0, 1, 64), Affine(0, 64, 32)))
            else:
                a_pt = type(args["a"])(args["a"].arg, SepOff(
                    (64, 32), Affine(0, 32, 64), Affine(0, 1, 32)))
            if b_trans:
                bb_pt = type(args["bb"])(args["bb"].arg, SepOff(
                    (32, 64), Affine(0, 1, 32), Affine(0, 32, 64)))
            else:
                bb_pt = type(args["bb"])(args["bb"].arg, SepOff(
                    (32, 64), Affine(0, 64, 32), Affine(0, 1, 64)))
            c_pt = type(args["c"])(args["c"].arg, SepOff(
                (64, 64), Affine(0, 64, 64), Affine(0, 1, 64)))
            acc = b.mma_tile(a_pt, bb_pt, args["K"], atom=atom, stages=2,
                             a_trans=a_trans, b_trans=b_trans)
            b.store(c_pt, acc)
            return b.finish(), acc.layout
    finally:
        os.environ.pop("MINITRITON_WIR_ANNOTATE", None)


def _dsl_probe(env_on):
    """The DSL smem constructs (async_copy + load_smem/store_smem)."""
    if env_on:
        os.environ["MINITRITON_WIR_ANNOTATE"] = "1"
    else:
        os.environ.pop("MINITRITON_WIR_ANNOTATE", None)
    try:
        with Builder("dslprobe", 128) as b:
            args = b.begin([("x", ("ptr", tl.float32)),
                            ("o", ("ptr", tl.float32))])
            x_pt = type(args["x"])(args["x"].arg, SepOff(
                (64, 64), Affine(0, 64, 64), Affine(0, 1, 64)))
            o_pt = type(args["o"])(args["o"].arg, SepOff(
                (64, 64), Affine(0, 64, 64), Affine(0, 1, 64)))
            buf = b.smem_alloc((64, 64), tl.float32)
            tok = b.async_copy(buf, x_pt, even=True)
            b.async_wait(tok, 0)
            b.barrier()
            v = b.load_smem(buf)
            b.store(o_pt, v)
            return b.finish()
    finally:
        os.environ.pop("MINITRITON_WIR_ANNOTATE", None)


def _accesses(text, role=None):
    from mlir import ir
    from minitriton.compiler.passes import _walk_accesses, _opname
    with ir.Context() as ctx, ir.Location.unknown(ctx):
        mod = ir.Module.parse(text, ctx)
        gm = [op for op in mod.body.operations
              if _opname(op) == "gpu.module"][0]
        accs = _walk_accesses(gm)
        if role is not None:
            accs = [a for a in accs if a.role == role]
        return accs


# ---------------------------------------------------------------------------
# zero emission when off
# ---------------------------------------------------------------------------

def test_off_emits_nothing():
    for text in (_mm_probe(False), _mma_probe(False)[0], _dsl_probe(False)):
        assert "wir.off" not in text
        assert "wir.nt" not in text
        assert "wir.lid" not in text


def test_on_emits_annotations_and_verifier_passes():
    text2 = _mm_probe(True)
    text4, _ = _mma_probe(True)
    textd = _dsl_probe(True)
    for text in (text2, text4, textd):
        assert 'wir.off' in text
        assert 'wir.nt' in text
        # the full pass pipeline (P1/P2 + verify_sync) must stay sound
        lower_device_module(text)


def test_dsl_async_copy_exact_forms():
    text = _dsl_probe(True)
    accs = _accesses(text, "smem_userbuf0")
    stores = [a for a in accs if a.is_store]
    assert stores, "async_copy dsts must be annotated"
    # (64, 64) tile, 16 f32/16B chunk, nt=128: cc = tid + j*128;
    # row = cc // 16, jc = cc % 16; dst = row*64 + jc*4
    for a in stores:
        for tid in range(128):
            ok = False
            for j in range(8):
                cc = tid + j * 128
                want = cc // 16 * 64 + cc % 16 * 4
                if list(a.offsets(tid)) == list(range(want, want + 4)):
                    ok = True
            assert ok, (a.form, tid)


def test_matmul_tile_b_compute_exact_forms():
    text = _mm_probe(True)
    accs = _accesses(text, "smem_mm_b")
    loads = [a for a in accs if not a.is_store]
    assert loads
    # grid (nt_m, nt_n) = (16, 4): ty = tid // 4, tx = tid % 4;
    # compute b load: base_b = stage*(32*64), col = (tx + j4*4)*4 ^? no
    # b_swz (plain B, vec): idx = base_b + kk*64 + col, kk = g*4 + w
    bad = 0
    for a in loads:
        for tid in range(64):
            tx = tid % 4
            ok = False
            for g in range(8):
                for w in range(4):
                    for j4 in range(4):
                        for iv in range(2):
                            kk = g * 4 + w
                            stage = iv % 2
                            want = stage * 2048 + kk * 64 + (tx + j4 * 4) * 4
                            if a.offsets(tid, iv).start == want:
                                ok = True
            if not ok:
                bad += 1
    assert bad == 0


def test_mma_tile_b_frag_exact_forms():
    text, lay = _mma_probe(True)
    wn_m, wn_n = lay.warps
    wa_m, wa_n = 64 // wn_m, 64 // wn_n
    accs = _accesses(text, "smem_mma_b")
    loads = [a for a in accs if not a.is_store]
    assert loads
    for a in loads:
        for tid in range(128):
            lane = tid % 32
            warp = tid // 32
            g, t = lane // 4, lane % 4
            wy, wx = warp // wn_n, warp % wn_n
            ok = False
            for h in range(4):
                for in_ in range(2):
                    for j in range(2):
                        for iv in range(2):
                            kk = h * 8 + j * 4 + t
                            stage = iv % 2
                            n_base = wx * wa_n + in_ * 8
                            ca = n_base // 4
                            chunk = ca + g // 4
                            sw = chunk ^ (kk & 15)
                            want = stage * 2048 + kk * 64 + sw * 4 + (g & 3)
                            got = a.offsets(tid, iv)
                            if got.start == want and len(got) == 1:
                                ok = True
            assert ok, (a.form, tid)


def test_mma_tile_a_ldsm_exact_forms():
    text, lay = _mma_probe(True)
    wn_m, wn_n = lay.warps
    wa_m = 64 // wn_m
    accs = _accesses(text, "smem_mma_a")
    loads = [a for a in accs if not a.is_store]
    assert loads
    for a in loads:
        for tid in range(128):
            lane = tid % 32
            warp = tid // 32
            wy = warp // wn_n
            ok = False
            for h in range(4):
                for im in range(4):
                    for iv in range(2):
                        stage = iv % 2
                        j8 = lane // 8
                        m = wy * wa_m + im * 16 + (j8 & 1) * 8 + lane % 8
                        chunk = h * 2 + lane // 16
                        sw = chunk ^ (m & 7)
                        want = stage * 2048 + m * 32 + sw * 4
                        got = a.offsets(tid, iv)
                        if got.start == want and len(got) == 16 // 4:
                            ok = True
            assert ok, (a.form, tid)


def test_mma_tile_a_stage_exact_forms():
    text, lay = _mma_probe(True)
    accs = _accesses(text, "smem_mma_a")
    stores = [a for a in accs if a.is_store]
    assert stores, "staging cp.async dsts must be annotated"
    # plain A vec staging: cc = tid + j*128; row = cc // 8, jc = cc % 8;
    # sw = jc ^ (row & 7); dst = stage*2048 + row*32 + sw*4 (prologue
    # stages are constants; the loop issue stages tile i+1 at (i+1)%2)
    for a in stores:
        for tid in range(128):
            ok = False
            for j in range(4):
                for iv in range(2):
                    cc = tid + j * 128
                    row = cc // 8
                    jc = cc % 8
                    sw = jc ^ (row & 7)
                    for stage in (0, 1, iv % 2, (iv + 1) % 2):
                        want = stage * 2048 + row * 32 + sw * 4
                        if list(a.offsets(tid, iv)) == list(range(want,
                                                                  want + 4)):
                            ok = True
            assert ok, (a.form, tid)


# ---------------------------------------------------------------------------
# env-on numerics: annotation is metadata-only
# ---------------------------------------------------------------------------

def test_env_on_numerics_unchanged():
    """An mma_tile matmul compiled+launched with annotations on must
    produce the same numbers as numpy (attrs never change semantics)."""
    os.environ["MINITRITON_WIR_ANNOTATE"] = "1"
    try:
        import ctypes

        from minitriton.compiler.lowering import compile_to_cubin
        from minitriton.runtime.cuda_driver import Device, memref1d_params

        M, N, K = 64, 64, 32
        rng = np.random.default_rng(0)
        a_np = rng.standard_normal((M, K)).astype(np.float32)
        b_np = rng.standard_normal((K, N)).astype(np.float32)
        out_np = np.zeros((M, N), dtype=np.float32)
        with Builder("m4num", 128) as b:
            args = b.begin([("a", ("ptr", tl.float32)),
                            ("bb", ("ptr", tl.float32)),
                            ("c", ("ptr", tl.float32)), ("K", tl.int32)])
            a_pt = type(args["a"])(args["a"].arg, SepOff(
                (M, K), Affine(0, K, M), Affine(0, 1, K)))
            bb_pt = type(args["bb"])(args["bb"].arg, SepOff(
                (K, N), Affine(0, N, K), Affine(0, 1, N)))
            c_pt = type(args["c"])(args["c"].arg, SepOff(
                (M, N), Affine(0, N, M), Affine(0, 1, N)))
            acc = b.mma_tile(a_pt, bb_pt, args["K"], atom="tf32", stages=2)
            b.store(c_pt, acc)
            text = b.finish()
        dev = Device(0)
        cubin = compile_to_cubin(text, name="m4num",
                                 build_dir=Path(os.environ.get(
                                     "TMPDIR", "/tmp")))
        kernel = dev.load_module(cubin).function("m4num")
        da = dev.alloc(a_np.nbytes)
        db = dev.alloc(b_np.nbytes)
        do = dev.alloc(out_np.nbytes)
        try:
            dev.memcpy_h2d(da, np.ascontiguousarray(a_np), a_np.nbytes)
            dev.memcpy_h2d(db, np.ascontiguousarray(b_np), b_np.nbytes)
            vl = 4
            params = (memref1d_params(da, a_np.size)
                      + memref1d_params(da, a_np.size // vl)
                      + memref1d_params(db, b_np.size)
                      + memref1d_params(db, b_np.size // vl)
                      + memref1d_params(do, out_np.size)
                      + memref1d_params(do, out_np.size // vl)
                      + [ctypes.c_int32(K)])
            kernel.launch((1, 1, 1), (128, 1, 1), params)
            dev.synchronize()
            dev.memcpy_d2h(out_np, do, out_np.nbytes)
        finally:
            dev.free(da)
            dev.free(db)
            dev.free(do)
        # tf32-rounded fp64 oracle (test_mma discipline)
        def tf32r(x):
            u = np.ascontiguousarray(x, np.float32).view(np.uint32)
            return ((u + 0x1000) & 0xFFFFE000).view(np.float32)
        ref = tf32r(a_np).astype(np.float64) @ tf32r(b_np).astype(np.float64)
        np.testing.assert_allclose(out_np, ref, rtol=1e-2, atol=1e-2)
    finally:
        os.environ.pop("MINITRITON_WIR_ANNOTATE", None)
