"""Row-per-thread (t3) tiles + the CUDA-core FMA dot + raw async_copy
TRANS — general scheduling-construct tests (numpy/fp64 oracles, no
torch). These are the constructs the fp32 (CUDA-core) flash bwd DSL
kernels are built from.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl


def rn(*shape, seed):
    rng = np.random.default_rng(seed)
    return rng.standard_normal(shape).astype(np.float32)


@tl.kernel
def _t3_roundtrip_kernel(x_ptr, y_ptr, T,
                         BM: tl.constexpr, HD: tl.constexpr):
    """t3 load (row-guarded) -> scale -> t3 store roundtrip."""
    offs_m = tl.arange(0, BM)
    offs_d = tl.arange(0, HD)
    lay = tl.t3_layout((BM, HD))
    x_pt = x_ptr + offs_m[:, None] * HD + offs_d[None, :]
    y_pt = y_ptr + offs_m[:, None] * HD + offs_d[None, :]
    v = tl.load(x_pt, LAYOUT=lay, mask=(offs_m < T)[:, None])
    tl.store(y_pt, v * 2.0, mask=(offs_m < T)[:, None])


def test_t3_load_store():
    BM, HD, T = 128, 64, 100
    x = rn(BM, HD, seed=0)
    tx, ty = tl.tensor(x), tl.zeros((BM, HD), tl.float32)
    _t3_roundtrip_kernel[(1,)](tx._buffer_arg(), ty._buffer_arg(), T,
                               BM=BM, HD=HD, num_warps=4)
    ref = np.where((np.arange(BM) < T)[:, None], x * 2.0, 0.0)
    np.testing.assert_array_equal(ty.numpy(), ref)


@tl.kernel
def _dot_t3_kernel(a_ptr, b_ptr, c_ptr, TRANS: tl.constexpr,
                   BM: tl.constexpr, K: tl.constexpr, N: tl.constexpr):
    """out = a @ b (a row-per-thread in registers, b staged through smem
    — natural or TRANS)."""
    offs_m = tl.arange(0, BM)
    offs_k = tl.arange(0, K)
    offs_n = tl.arange(0, N)
    a = tl.load(a_ptr + offs_m[:, None] * K + offs_k[None, :],
                LAYOUT=tl.t3_layout((BM, K)))
    if TRANS:
        buf = tl.smem((K, N), tl.float32)
        tok = tl.async_copy(buf, b_ptr + offs_n[:, None] * K +
                            offs_k[None, :], TRANS=True)
    else:
        buf = tl.smem((K, N), tl.float32)
        tok = tl.async_copy(buf, b_ptr + offs_k[:, None] * N +
                            offs_n[None, :], EVEN=True)
    tl.async_wait(tok, 0)
    tl.barrier()
    acc = tl.dot_t3(a, buf)
    tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)


@pytest.mark.parametrize("trans", [False, True])
def test_dot_t3_oracle(trans):
    """row-per-thread A x smem B FMA dot vs fp64, both staging forms."""
    BM, K, N = 128, 64, 64
    a = rn(BM, K, seed=0)
    b = rn(K, N, seed=1)
    ta, tb = tl.tensor(a), tl.tensor(b if not trans else b.T.copy())
    # TRANS form stages b as its (N, K) transpose
    tb2 = tl.tensor(b.T.copy()) if trans else tl.tensor(b)
    tc = tl.empty((BM, N), tl.float32)
    _dot_t3_kernel[(1,)](ta._buffer_arg(), tb2._buffer_arg(),
                         tc._buffer_arg(), TRANS=trans,
                         BM=BM, K=K, N=N, num_warps=4)
    ref = a.astype(np.float64) @ b.astype(np.float64)
    np.testing.assert_allclose(tc.numpy(), ref, rtol=1e-5, atol=1e-5)


@tl.kernel
def _dot_t3_pipe_kernel(a_ptr, b_ptr, c_ptr, K,
                        BM: tl.constexpr, BK: tl.constexpr,
                        N: tl.constexpr):
    """whole-K matmul, row-per-thread A, B streamed through one SmemBuf
    via tl.pipelined (raw async_copy sites + dot_t3 promise)."""
    pid_m = tl.program_id(0)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_k = tl.arange(0, BK)
    offs_n = tl.arange(0, N)
    lay = tl.t3_layout((BM, BK))
    buf = tl.smem((BK, N), tl.float32)
    acc = tl.zeros((BM, N), tl.float32, LAYOUT=tl.t3_layout((BM, N)))
    for k0 in tl.pipelined(range(0, K, BK), stages=2):
        a = tl.load(a_ptr + offs_m[:, None] * K + (k0 + offs_k)[None, :],
                    LAYOUT=lay)
        acc = tl.dot_t3(a, p_b, acc)
        p_b = tl.stage(buf, b_ptr + (k0 + offs_k)[:, None] * N +
                       offs_n[None, :], EVEN=True)
    tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)


def test_dot_t3_pipelined():
    BM, BK, N, K = 128, 64, 64, 256
    a = rn(BM, K, seed=0)
    b = rn(K, N, seed=1)
    ta, tb = tl.tensor(a), tl.tensor(b)
    tc = tl.empty((BM, N), tl.float32)
    _dot_t3_pipe_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                              tc._buffer_arg(), K,
                              BM=BM, BK=BK, N=N, num_warps=4)
    ref = a.astype(np.float64) @ b.astype(np.float64)
    np.testing.assert_allclose(tc.numpy(), ref, rtol=1e-5, atol=1e-5)


@tl.kernel
def _t3_bcast_kernel(x_ptr, y_ptr, o_ptr, BM: tl.constexpr,
                     N: tl.constexpr):
    """t3 tile + (N,) rep row vector + where with a rep cond:
    o[i, j] = x[i, j] > y[j] ? x[i, j] - y[j] : 0."""
    offs_m = tl.arange(0, BM)
    offs_n = tl.arange(0, N)
    lay = tl.t3_layout((BM, N))
    x = tl.load(x_ptr + offs_m[:, None] * N + offs_n[None, :], LAYOUT=lay)
    y = tl.load(y_ptr + tl.arange(0, N))          # (N,) rep
    keep = x > y
    v = tl.where(keep, x - y, 0.0)
    tl.store(o_ptr + offs_m[:, None] * N + offs_n[None, :], v)


def test_t3_rep_broadcast():
    BM, N = 128, 64
    x = rn(BM, N, seed=0)
    y = rn(N, seed=1)
    tx, ty, to = tl.tensor(x), tl.tensor(y), tl.empty((BM, N), tl.float32)
    _t3_bcast_kernel[(1,)](tx._buffer_arg(), ty._buffer_arg(),
                           to._buffer_arg(), BM=BM, N=N, num_warps=4)
    ref = np.where(x > y[None, :], x - y[None, :], 0.0)
    np.testing.assert_allclose(to.numpy(), ref, rtol=1e-6)


@tl.kernel
def _t3_roundtrip_f16_kernel(x_ptr, y_ptr, T,
                             BM: tl.constexpr, HD: tl.constexpr):
    offs_m = tl.arange(0, BM)
    offs_d = tl.arange(0, HD)
    lay = tl.t3_layout((BM, HD))
    x_pt = x_ptr + offs_m[:, None] * HD + offs_d[None, :]
    y_pt = y_ptr + offs_m[:, None] * HD + offs_d[None, :]
    v = tl.load(x_pt, LAYOUT=lay, mask=(offs_m < T)[:, None])
    tl.store(y_pt, v, mask=(offs_m < T)[:, None])


def test_t3_load_store_f16():
    """f16/bf16 t3 stores: vl is 8 for 16-bit dtypes, but the store
    chunk was hardcoded to 4 elements — every 16-bit t3 store died in
    the MLIR verifier."""
    BM, HD, T = 128, 64, 100
    x = rn(BM, HD, seed=1)
    for dt, tol in ((tl.float16, 2e-3), (tl.bfloat16, 2e-2)):
        tx = tl.tensor(x).astype(dt)
        ty = tl.zeros((BM, HD), dt)
        _t3_roundtrip_f16_kernel[(1,)](tx._buffer_arg(), ty._buffer_arg(),
                                       T, BM=BM, HD=HD, num_warps=4)
        tl.synchronize()
        ref = np.where((np.arange(BM) < T)[:, None], x, 0.0)
        np.testing.assert_allclose(ty.numpy(), ref, rtol=tol, atol=tol)


@tl.kernel
def _t3_rt_stride_load_kernel(x_ptr, y_ptr, S,
                              BM: tl.constexpr, HD: tl.constexpr):
    """t3 load through a runtime row stride S: row bases are vl-aligned
    only when S % vl == 0."""
    offs_m = tl.arange(0, BM)
    offs_d = tl.arange(0, HD)
    lay = tl.t3_layout((BM, HD))
    x_pt = x_ptr + offs_m[:, None] * S + offs_d[None, :]
    y_pt = y_ptr + offs_m[:, None] * HD + offs_d[None, :]
    v = tl.load(x_pt, LAYOUT=lay)
    tl.store(y_pt, v)


@tl.kernel
def _t3_rt_stride_store_kernel(x_ptr, y_ptr, S,
                               BM: tl.constexpr, HD: tl.constexpr):
    """t3 store through a runtime row stride S (same alignment caveat)."""
    offs_m = tl.arange(0, BM)
    offs_d = tl.arange(0, HD)
    lay = tl.t3_layout((BM, HD))
    x_pt = x_ptr + offs_m[:, None] * HD + offs_d[None, :]
    y_pt = y_ptr + offs_m[:, None] * S + offs_d[None, :]
    v = tl.load(x_pt, LAYOUT=lay)
    tl.store(y_pt, v)


@pytest.mark.parametrize("S", [64, 65])
def test_t3_load_runtime_row_stride(S):
    """S=65 leaves the t3 row bases vl-misaligned: the vector-chunk load
    must fall back to scalar loads instead of reading shifted chunks
    (S=64 is the aligned control)."""
    BM, HD = 128, 64
    x = rn(BM, S, seed=2)
    tx, ty = tl.tensor(x), tl.zeros((BM, HD), tl.float32)
    _t3_rt_stride_load_kernel[(1,)](tx._buffer_arg(), ty._buffer_arg(), S,
                                    BM=BM, HD=HD, num_warps=4)
    tl.synchronize()
    np.testing.assert_array_equal(ty.numpy(), x[:, :HD])


@pytest.mark.parametrize("S", [64, 65])
def test_t3_store_runtime_row_stride(S):
    """Misaligned t3 vector stores used to floor the chunk address and
    corrupt neighboring elements; the padding column must stay untouched."""
    BM, HD = 128, 64
    x = rn(BM, HD, seed=3)
    y = np.full((BM, S), 777.0, dtype=np.float32)
    tx, ty = tl.tensor(x), tl.tensor(y)
    _t3_rt_stride_store_kernel[(1,)](tx._buffer_arg(), ty._buffer_arg(), S,
                                     BM=BM, HD=HD, num_warps=4)
    tl.synchronize()
    np.testing.assert_array_equal(ty.numpy()[:, :HD], x)
    np.testing.assert_array_equal(ty.numpy()[:, HD:],
                                  np.full((BM, S - HD), 777.0, np.float32))
