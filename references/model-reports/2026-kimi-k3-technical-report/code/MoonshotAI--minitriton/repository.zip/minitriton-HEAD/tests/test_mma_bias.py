"""Fused Linear bias epilogue (store_m4 bias_pt): the mma kernel adds
the bias to the f32 accumulators before the bf16 pack (single-rounding,
torch cublasLt semantics). Diff-tested against the fp64 numpy reference
and bounded-ulp against the composed matmul+bias route; also covers the
autograd Linear contract (bias grad still flows through _unbroadcast).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import nn, ops


def _bf16_round(x):
    return tl.tensor(x).astype(tl.bfloat16).astype(tl.float32).numpy()


@pytest.mark.parametrize("M,N,K", [(128, 640, 640), (1024, 1920, 640),
                                   (512, 2560, 640), (256, 96, 640)])
def test_matmul_bf16_bias_epilogue(M, N, K):
    rng = np.random.default_rng(0)
    a32 = (rng.standard_normal((M, K)) * 0.3).astype(np.float32)
    w32 = (rng.standard_normal((N, K)) * 0.3).astype(np.float32)
    b32 = rng.standard_normal((N,)).astype(np.float32)
    a = tl.tensor(a32).astype(tl.bfloat16)
    w = tl.tensor(w32).astype(tl.bfloat16)
    bias = tl.tensor(b32).astype(tl.bfloat16)
    y = ops.matmul_bf16(a, w.t(), bias=bias)
    ref = _bf16_round(a32) @ _bf16_round(w32).T + b32
    got = y.numpy().astype(np.float64)
    assert np.allclose(got, ref, rtol=2e-2, atol=1e-1)
    # single rounding: the epilogue result stays within a bf16 rounding
    # of the composed round-then-add route, and is not systematically
    # further from the fp64 reference
    y2 = ops.matmul_bf16(a, w.t()) + bias
    got2 = y2.numpy().astype(np.float64)
    assert np.allclose(got, got2, rtol=2e-2, atol=5e-2)
    e1 = np.abs(got - ref)
    e2 = np.abs(got2 - ref)
    assert e1.mean() <= e2.mean() * 1.2
    # f32 bias vector also accepted
    y3 = ops.matmul_bf16(a, w.t(), bias=tl.tensor(b32))
    assert np.allclose(y3.numpy().astype(np.float64), ref,
                       rtol=2e-2, atol=1e-1)


def test_linear_bias_epilogue_backward():
    """The fused forward must not change the backward contract: da/dw/db
    match the composed-route grads (and the fp64 reference)."""
    rng = np.random.default_rng(1)
    B, T, C, F = 4, 64, 320, 640
    x32 = rng.standard_normal((B, T, C)).astype(np.float32)
    w32 = (rng.standard_normal((F, C)) * 0.1).astype(np.float32)
    b32 = rng.standard_normal((F,)).astype(np.float32)
    g32 = rng.standard_normal((B, T, F)).astype(np.float32)
    x = tl.tensor(x32).astype(tl.bfloat16)
    x.requires_grad = True
    w = tl.tensor(w32).astype(tl.bfloat16)
    w.requires_grad = True
    bias = tl.tensor(b32).astype(tl.bfloat16)
    bias.requires_grad = True
    lin = nn.Linear(C, F, device="cuda")
    lin.weight = nn.Parameter(w)
    lin.bias = nn.Parameter(bias)
    y = lin(x)
    y.backward(tl.tensor(g32))
    xr = _bf16_round(x32)
    wr = _bf16_round(w32)
    gr = _bf16_round(g32)  # the bf16 bwd route rounds g inside the kernel
    g64 = gr.astype(np.float64)
    ref_dw = np.einsum("btf,btc->fc", g64, xr.astype(np.float64))
    ref_db = g32.reshape((-1, F)).sum(0)
    ref_dx = np.einsum("btf,fc->btc", g64, wr.astype(np.float64))
    assert np.allclose(x.grad.numpy().astype(np.float64), ref_dx,
                       rtol=2e-2, atol=1e-1)
    assert np.allclose(lin.weight.grad.numpy().astype(np.float64), ref_dw,
                       rtol=2e-2, atol=1e-1)
    assert np.allclose(lin.bias.grad.numpy().astype(np.float64), ref_db,
                       rtol=2e-2, atol=1e-1)


@pytest.mark.parametrize("M,N,K", [(128, 640, 640), (1024, 1920, 640),
                                   (512, 2560, 640), (256, 96, 640)])
def test_matmul_f32_bias_epilogue(M, N, K):
    """fp32 store_t2 bias epilogue: bit-identical to the composed
    matmul+bias route (the same f32 add, one less pass)."""
    rng = np.random.default_rng(2)
    a32 = (rng.standard_normal((M, K)) * 0.3).astype(np.float32)
    w32 = (rng.standard_normal((N, K)) * 0.3).astype(np.float32)
    b32 = rng.standard_normal((N,)).astype(np.float32)
    a = tl.tensor(a32)
    w = tl.tensor(w32)
    y1 = ops.matmul(a, w.t(), bias=tl.tensor(b32))
    y2 = ops.matmul(a, w.t()) + tl.tensor(b32)
    assert np.array_equal(y1.numpy(), y2.numpy())
