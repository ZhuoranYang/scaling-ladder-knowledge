"""bitonic_pad_kernel stores are masked by N2.

The pad kernel launches ceil(N2/256) 256-lane blocks; its loads were
masked by N but its stores were unmasked, so for N <= 128 (N2 < 256) the
single block's lanes [N2, 256) wrote (256-N2)*4 bytes past each padded
buffer — sentinel 0x7fffffff / -1 values landing in whatever pool
allocations followed (corrupting unrelated live tensors, and the padded
buffers themselves through block adjacency). numpy oracle only, no torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.device.cuda.ops import coo_sort_by_key


def _check_sort(n, seed):
    rng = np.random.default_rng(seed)
    # unique keys: the sort is documented stable-is-not-guaranteed, so
    # duplicate keys would leave the payload order among equals free
    knp = rng.permutation(100003)[:n].astype(np.int32)
    vnp = rng.integers(0, 1000, size=n).astype(np.int32)
    keys, vals = tl.tensor(knp), tl.tensor(vnp)
    ks, vs = coo_sort_by_key(keys, vals)
    tl.synchronize()
    order = np.argsort(knp, kind="stable")
    np.testing.assert_array_equal(ks.numpy(), knp[order])
    np.testing.assert_array_equal(vs.numpy(), vnp[order])
    # inputs untouched
    np.testing.assert_array_equal(keys.numpy(), knp)
    np.testing.assert_array_equal(vals.numpy(), vnp)


@pytest.mark.parametrize("n", [1, 2, 3, 7, 127, 128, 129, 256, 300])
def test_coo_sort_by_key_sizes(n):
    # N <= 128 exercises the masked (N2 < 256) pad path; 129/256/300 are
    # the N2 >= 256 no-op controls
    _check_sort(n, seed=n)


def test_coo_sort_by_key_small_n_no_oob_corruption():
    # N=2: 512B-size-class guards held across the sort must survive; the
    # padded ks/vs buffers are pooled between trials, so repeat to vary
    # adjacency. Guards against unmasked stores corrupting live
    # allocations (sorted output itself stomped by sentinel writes).
    for t in range(8):
        guards = [tl.tensor(np.full(128, 777.0, np.float32))
                  for _ in range(8)]
        _check_sort(2, seed=100 + t)
        for g in guards:
            np.testing.assert_array_equal(
                g.numpy(), np.full(128, 777.0, np.float32))
