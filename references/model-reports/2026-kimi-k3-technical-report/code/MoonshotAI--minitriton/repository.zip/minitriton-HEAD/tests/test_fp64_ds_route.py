"""MT_MATMUL_FP64 double-single route: view operands whose last dim is
unit-stride but whose row stride != K/N must not be silently misread.

matmul_ds_kernel hardcodes the operand row strides to K/N, so the fp64
route forces full contiguity (`_mm_prep_ds`); the default fp32 route
passes real strides and handles these views correctly. The ds kernel
is the fp64-quality reference (error ~1e-11 rel class), so tolerances are
tight.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
import minitriton.precision as _prec


@pytest.fixture
def fp64_route(monkeypatch):
    monkeypatch.setattr(_prec, "_MATMUL_FP64", True)
    yield


def colslice(rng, shape, k, pad):
    """(…, K+pad) contiguous base sliced to (…, K): last-dim unit
    stride, row stride != K."""
    full = rng.standard_normal((*shape, k + pad)).astype(np.float32)
    return full, full[..., :k]


def test_matmul_colslice_a(fp64_route):
    rng = np.random.default_rng(0)
    M, K, N, pad = 33, 129, 65, 16
    full, a_np = colslice(rng, (M,), K, pad)
    assert a_np.strides[-1] == 4 and a_np.strides[0] != K * 4
    b_np = rng.standard_normal((K, N)).astype(np.float32)
    a = tl.from_numpy(full, device="cuda")[:, :K]
    got = (a @ tl.tensor(b_np)).numpy()
    ref = a_np.astype(np.float64) @ b_np.astype(np.float64)
    np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-5)


def test_matmul_colslice_b(fp64_route):
    rng = np.random.default_rng(1)
    M, K, N, pad = 33, 129, 65, 16
    a_np = rng.standard_normal((M, K)).astype(np.float32)
    full, b_np = colslice(rng, (K,), N, pad)
    b = tl.from_numpy(full, device="cuda")[:, :N]
    got = (tl.tensor(a_np) @ b).numpy()
    ref = a_np.astype(np.float64) @ b_np.astype(np.float64)
    np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-5)


def test_bmm_colslice_a(fp64_route):
    rng = np.random.default_rng(2)
    B, M, K, N, pad = 4, 17, 23, 31, 8
    full, a_np = colslice(rng, (B, M), K, pad)
    b_np = rng.standard_normal((B, K, N)).astype(np.float32)
    a = tl.from_numpy(full, device="cuda")[:, :, :K]
    got = tl.bmm(a, tl.tensor(b_np)).numpy()
    ref = a_np.astype(np.float64) @ b_np.astype(np.float64)
    np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-5)


def test_bmm_colslice_b(fp64_route):
    rng = np.random.default_rng(3)
    B, M, K, N, pad = 3, 19, 29, 37, 5
    a_np = rng.standard_normal((B, M, K)).astype(np.float32)
    full, b_np = colslice(rng, (B, K), N, pad)
    b = tl.from_numpy(full, device="cuda")[:, :, :N]
    got = tl.bmm(tl.tensor(a_np), b).numpy()
    ref = a_np.astype(np.float64) @ b_np.astype(np.float64)
    np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-5)


def test_matmul_transposed_view(fp64_route):
    # strides[-1] != 1: already contiguous-ified by _mm_prep; make sure
    # the fp64 route keeps that behavior exact.
    rng = np.random.default_rng(4)
    M, K, N = 24, 40, 56
    b_np = rng.standard_normal((K, N)).astype(np.float32)
    a = tl.tensor(rng.standard_normal((K, M)).astype(np.float32)).t()
    a_np = a.numpy()
    got = (a @ tl.tensor(b_np)).numpy()
    ref = a_np.astype(np.float64) @ b_np.astype(np.float64)
    np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-5)


def test_matmul_contiguous_control(fp64_route):
    rng = np.random.default_rng(5)
    M, K, N = 33, 129, 65
    a_np = rng.standard_normal((M, K)).astype(np.float32)
    b_np = rng.standard_normal((K, N)).astype(np.float32)
    got = (tl.tensor(a_np) @ tl.tensor(b_np)).numpy()
    ref = a_np.astype(np.float64) @ b_np.astype(np.float64)
    assert np.abs(got - ref).max() < 1e-4  # ds: fp64-accumulator class


def test_matmul_odd_shapes_and_empty(fp64_route):
    rng = np.random.default_rng(6)
    for M, K, N in [(1, 1, 1), (1, 129, 1), (7, 3, 5), (0, 4, 6)]:
        a_np = rng.standard_normal((max(M, 1), K)).astype(np.float32)[:M]
        b_np = rng.standard_normal((K, N)).astype(np.float32)
        got = (tl.tensor(a_np) @ tl.tensor(b_np)).numpy()
        ref = a_np.astype(np.float64) @ b_np.astype(np.float64)
        np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-5)


def test_fp32_route_unaffected_by_views():
    # default route (no fp64): real strides are passed; always correct.
    rng = np.random.default_rng(7)
    M, K, N, pad = 33, 129, 65, 16
    full, a_np = colslice(rng, (M,), K, pad)
    b_np = rng.standard_normal((K, N)).astype(np.float32)
    a = tl.from_numpy(full, device="cuda")[:, :K]
    got = (a @ tl.tensor(b_np)).numpy()
    ref = a_np.astype(np.float64) @ b_np.astype(np.float64)
    np.testing.assert_allclose(got, ref, rtol=1e-4, atol=1e-4)


def test_matmul_bias_added_on_ds_route(fp64_route):
    """The ds kernel has no bias epilogue; the fp64 branch used to drop
    the bias kwarg entirely (the fp32/tf32 routes add it)."""
    from minitriton import ops as tl_ops
    rng = np.random.default_rng(4)
    M, K, N = 33, 129, 65
    a_np = rng.standard_normal((M, K)).astype(np.float32)
    b_np = rng.standard_normal((K, N)).astype(np.float32)
    bias_np = np.full(N, 5.0, dtype=np.float32)
    got = tl_ops.matmul(tl.tensor(a_np), tl.tensor(b_np),
                        bias=tl.tensor(bias_np)).numpy()
    ref = a_np.astype(np.float64) @ b_np.astype(np.float64) + bias_np
    np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-5)
