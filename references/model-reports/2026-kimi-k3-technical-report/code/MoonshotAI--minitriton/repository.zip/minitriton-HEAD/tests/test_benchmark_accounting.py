#!/usr/bin/env python
"""Pin the roofline FLOPs/bytes accounting conventions.

Pure CPU, no torch: benchmarks/roofline/accounting.py is the single
source both figure scripts import; this suite fails if the conventions
drift (guarded drift modes: flash 4x-vs-2x between scripts, and an
H-for-L substitution in the gpt50m attention term that only gpt50m's
L==H==10 config makes invisible).
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]
                     / "benchmarks" / "roofline"))
import accounting as acc  # noqa: E402


def test_flash_causal_fwd_is_halved():
    # 2*B*H*T^2*d (halved from 4x), bytes 16*B*H*T*d => AI = T/8
    f = acc.flash_attn_fwd_flops(8, 12, 256, 64)
    b = acc.flash_attn_fwd_bytes(8, 12, 256, 64)
    assert f == 2.0 * 8 * 12 * 256 * 256 * 64
    assert b == 16.0 * 8 * 12 * 256 * 64
    assert f / b == pytest.approx(256 / 8)


def test_gpt_attention_term_uses_n_layer_not_n_head():
    # L != H: the attention coefficient must follow n_layer (gpt50m's
    # L==H==10 hid an H-for-L substitution)
    f = acc.gpt_step_flops(n_params=50e6, n_layer=4, batch=32, block=256,
                           n_embd=640)
    base = 6.0 * 50e6 * 32 * 256
    attn = 6.0 * 4 * 32 * 256 * 256 * 640
    assert f == pytest.approx(base + attn)


def test_gpt_step_bytes_convention():
    b = acc.gpt_step_bytes(n_params=50e6, n_layer=10, batch=32, block=256,
                           n_embd=640)
    assert b == pytest.approx(3.0 * 50e6 * 4
                              + 7.0 * 10 * 32 * 256 * 640 * 4)


def test_gpt50m_reference_values_stable():
    # the published gpt50m_step rows (fp32 sweep, B32): changing these
    # numbers moves published figures -- do it deliberately. n_params is
    # the sweep's own num_params() = 49.53M (the scripts' docstring
    # rounds it to 49.47M)
    f256 = acc.gpt_step_flops(49.53e6, 10, 32, 256, 640)
    b256 = acc.gpt_step_bytes(49.53e6, 10, 32, 256, 640)
    assert f256 == pytest.approx(2515072450560, rel=1e-3)
    assert b256 == pytest.approx(2062376960, rel=1e-3)
    # attention term grows the intensity with block size
    f512 = acc.gpt_step_flops(49.63e6, 10, 32, 512, 640)
    b512 = acc.gpt_step_bytes(49.63e6, 10, 32, 512, 640)
    assert f512 / b512 > f256 / b256
