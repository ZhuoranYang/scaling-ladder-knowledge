"""Rendezvous hygiene tests: stale file:// artifacts must fail LOUD at
entry, before any NCCL work.

A leftover ``<base>.uid`` makes a non-zero rank read the OLD unique id and
hang the warmup allreduce on a communicator rank 0 no longer owns; a
leftover ``<base>.ready.<rank>`` defeats the post-init barrier. The
entry checks raise before ``get_device()``/NCCL, so these tests need no
GPU and no NCCL library. No torch anywhere (tests rule).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from minitriton import distributed as dist


@pytest.fixture(autouse=True)
def _no_pg_leak():
    yield
    # the checks raise before a process group is created; belt-and-braces
    # in case a future code path constructs one
    if dist.is_initialized():
        dist.destroy_process_group()


def test_stale_uid_fails_loud_rank0(tmp_path):
    base = tmp_path / "init"
    (tmp_path / "init.uid").write_bytes(b"x" * 128)  # leftover from run N-1
    with pytest.raises(RuntimeError, match="stale rendezvous file"):
        dist.init_process_group(rank=0, world_size=2,
                                init_method=f"file://{base}")


def test_stale_ready_fails_loud_any_rank(tmp_path):
    base = tmp_path / "init"
    (tmp_path / "init.ready.1").touch()
    with pytest.raises(RuntimeError, match="stale ready file"):
        dist.init_process_group(rank=1, world_size=2,
                                init_method=f"file://{base}")


def test_stale_ready_fails_loud_rank0(tmp_path):
    base = tmp_path / "init"
    (tmp_path / "init.ready.0").touch()  # no .uid: own-ready still caught
    with pytest.raises(RuntimeError, match="stale ready file"):
        dist.init_process_group(rank=0, world_size=2,
                                init_method=f"file://{base}")


def test_suffixed_base_path_glob_hint(tmp_path):
    """The error message's delete-hint matches the real artifact names for
    a base path that already has a suffix (with_suffix semantics)."""
    base = tmp_path / "run.init"
    (tmp_path / "run.init.uid").write_bytes(b"x" * 128)
    with pytest.raises(RuntimeError, match=r"run\.init\.ready\.\*"):
        dist.init_process_group(rank=0, world_size=2,
                                init_method=f"file://{base}")
