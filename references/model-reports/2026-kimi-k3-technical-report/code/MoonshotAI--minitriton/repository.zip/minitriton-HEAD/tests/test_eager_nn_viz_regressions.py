"""Eager autograd / nn / viz regression tests:

- backward through a consumed tape raises loudly — second backward
  on the same root, two roots over a shared subgraph, and backward from a
  root with requires_grad=False all used to be silent (torch raises);
  direct backward on a requires-grad leaf keeps accumulating .grad.
- GradScaler scale is floored at the smallest normal double —
  ~1090 consecutive found_inf steps can no longer underflow it to 0.0
  (the next unscale_ crashed with ZeroDivisionError).
- Module.to(device) moves grads along with the parameters
  (the docstring always promised it; the implementation dropped them).
- viz.particles / viz.heatmap materialize non-contiguous inputs —
  strided views (pos[:, 0], f.T) rendered silently wrong pixels.
- viz.mesh normalizes edges to i32 — numpy integer arrays default
  to i64 and crashed the compiler (offsets must be i32 blocks).
- particles_kernel's store mask includes the lane mask — masked
  lanes (N not a multiple of BLOCK) loaded other=-1.0 and, with
  radius >= frame size, painted ghost pixels.

Autograd/nn tests run on {cpu, cuda}; viz tests are CUDA-only (DSL render
kernels). numpy oracles only, no torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import nn, viz

DEVS = pytest.mark.parametrize("dev", ["cpu", "cuda"])

rng = np.random.default_rng(0)


def T(x, dev, requires_grad=True):
    return tl.tensor(np.ascontiguousarray(x), device=dev,
                     requires_grad=requires_grad)


# ---------------------------------------------------------------------------
# consumed-tape backward raises
# ---------------------------------------------------------------------------

@DEVS
def test_second_backward_same_root_raises(dev):
    x = T(np.ones(4, np.float32), dev)
    loss = (x * 2.0).sum()
    loss.backward()
    np.testing.assert_array_equal(x.grad.numpy(),
                                  np.full(4, 2.0, np.float32))
    with pytest.raises(RuntimeError, match="second time"):
        loss.backward()
    # the rejected call must not have written anything: no doubled grad,
    # no leaf-ified seed grad on the root (the old silent behavior)
    np.testing.assert_array_equal(x.grad.numpy(),
                                  np.full(4, 2.0, np.float32))
    assert loss.grad is None


@DEVS
def test_shared_subgraph_sequential_backward_raises(dev):
    x = T(np.ones(4, np.float32), dev)
    a = x * 2.0
    l1 = (a * 1.0).sum()
    l2 = (a * 3.0).sum()
    l1.backward()
    np.testing.assert_array_equal(x.grad.numpy(),
                                  np.full(4, 2.0, np.float32))
    with pytest.raises(RuntimeError, match="second time"):
        l2.backward()
    # the old bug leaf-ified `a` (a.grad = [3]*4) and starved x of l2's
    # contribution; the rejected call must leave both untouched
    assert a.grad is None
    np.testing.assert_array_equal(x.grad.numpy(),
                                  np.full(4, 2.0, np.float32))


@DEVS
def test_backward_through_severed_intermediate_raises(dev):
    # new graph built on top of a consumed intermediate: torch raises too
    x = T(np.ones(4, np.float32), dev)
    y = x * 2.0
    y.sum().backward()
    z = (y * 3.0).sum()
    with pytest.raises(RuntimeError, match="second time"):
        z.backward()


@DEVS
def test_backward_root_without_requires_grad_raises(dev):
    t = T(np.ones(4, np.float32), dev, requires_grad=False)
    with pytest.raises(RuntimeError, match="does not require grad"):
        t.sum().backward()
    # same with an explicitly passed grad
    with pytest.raises(RuntimeError, match="does not require grad"):
        t.backward(tl.tensor(np.ones(4, np.float32), device=dev))


@DEVS
def test_leaf_backward_still_accumulates(dev):
    # a requires-grad leaf has no tape to sever: repeated backward keeps
    # accumulating into .grad (torch AccumulateGrad semantics)
    x = T(np.ones(4, np.float32), dev)
    g = tl.tensor(np.full(4, 3.0, np.float32), device=dev)
    x.backward(g)
    x.backward(g)
    np.testing.assert_array_equal(x.grad.numpy(),
                                  np.full(4, 6.0, np.float32))


# ---------------------------------------------------------------------------
# GradScaler scale floor
# ---------------------------------------------------------------------------

@DEVS
def test_grad_scaler_scale_floored_after_underflow(dev):
    sc = nn.GradScaler(init_scale=1.0)
    for _ in range(1100):  # 0.5**1074 already underflows a double
        sc.update(found_inf=True)
    assert sc.scale > 0.0
    p = tl.tensor(np.ones(4, np.float32), device=dev, requires_grad=True)
    (p * 2.0).sum().backward()
    sc.unscale_([p])  # must not raise ZeroDivisionError
    # 1/tiny overflows f32: grads come out non-finite, which the training
    # loop's finite-check treats as a skip-step (no crash, no zero grads)
    assert not np.isfinite(p.grad.numpy()).all()


def test_grad_scaler_normal_halving_unaffected():
    sc = nn.GradScaler(init_scale=2.0 ** 15)
    sc.update(found_inf=True)
    assert sc.scale == 2.0 ** 14
    for _ in range(sc.growth_interval):
        sc.update(found_inf=False)
    assert sc.scale == 2.0 ** 15


# ---------------------------------------------------------------------------
# Module.to() moves grads
# ---------------------------------------------------------------------------

def test_module_to_moves_grads():
    lin = nn.Linear(4, 4)  # cuda by default
    x = tl.tensor(np.ones((2, 4), np.float32), device="cuda")
    lin(x).sum().backward()
    before = {id(p): p.grad.numpy().copy() for p in lin.parameters()}
    lin.to("cpu")
    for p in lin.parameters():
        assert p.device == "cpu"
        assert p.grad is not None and p.grad.device == "cpu"
        np.testing.assert_array_equal(p.grad.numpy(), before[id(p)])
    lin.to("cuda")
    for p in lin.parameters():
        assert p.device == "cuda"
        assert p.grad is not None and p.grad.device == "cuda"
        np.testing.assert_array_equal(p.grad.numpy(), before[id(p)])


def test_module_to_gradless_params_stay_gradless():
    lin = nn.Linear(4, 4)
    lin.to("cpu")
    for p in lin.parameters():
        assert p.device == "cpu" and p.grad is None


# ---------------------------------------------------------------------------
# viz.particles / viz.heatmap materialize strided views
# ---------------------------------------------------------------------------

def test_particles_noncontiguous_xy_match_contiguous():
    pos = tl.tensor(np.array([[0.25, 0.25], [0.75, 0.25]], np.float32),
                    device="cuda")
    assert not pos[:, 0].is_contiguous()
    b_view = viz.PixelBuffer(8, 8)
    viz.clear(b_view)
    viz.particles(b_view, pos[:, 0], pos[:, 1], color=(1, 1, 1), radius=0,
                  y_up=False)
    b_ref = viz.PixelBuffer(8, 8)
    viz.clear(b_ref)
    viz.particles(b_ref, pos[:, 0].contiguous(), pos[:, 1].contiguous(),
                  color=(1, 1, 1), radius=0, y_up=False)
    np.testing.assert_array_equal(b_view.resolve(), b_ref.resolve())
    lit = np.argwhere(b_view.resolve()[..., 0] > 0)
    assert lit.tolist() == [[2, 2], [2, 6]]


def test_heatmap_noncontiguous_field_matches_contiguous():
    f = rng.standard_normal((6, 8)).astype(np.float32)
    b_view = viz.PixelBuffer(8, 6)
    viz.heatmap(b_view, tl.tensor(f, device="cuda").t(), cmap="viridis")
    b_ref = viz.PixelBuffer(8, 6)
    viz.heatmap(b_ref, tl.tensor(np.ascontiguousarray(f.T), device="cuda"),
                cmap="viridis")
    np.testing.assert_array_equal(b_view.resolve(), b_ref.resolve())


# ---------------------------------------------------------------------------
# viz.mesh normalizes edges to i32
# ---------------------------------------------------------------------------

def test_mesh_accepts_i64_edges():
    verts = tl.tensor(np.array([[0.25, 0.5], [0.75, 0.5]], np.float32),
                      device="cuda")
    e64 = tl.tensor(np.array([[0, 1]]), device="cuda")  # numpy default: i64
    assert e64.dtype == tl.int64
    b64 = viz.PixelBuffer(16, 16)
    viz.clear(b64)
    viz.mesh(b64, verts, e64)
    b32 = viz.PixelBuffer(16, 16)
    viz.clear(b32)
    viz.mesh(b32, verts, tl.tensor(np.array([[0, 1]], np.int32),
                                   device="cuda"))
    np.testing.assert_array_equal(b64.resolve(), b32.resolve())
    # two endpoint dots + the edge midpoint
    assert int((b64.resolve()[..., 0] > 0).sum()) == 3


# ---------------------------------------------------------------------------
# particles_kernel store mask includes the lane mask
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("R,y_up", [(8, False), (15, False), (9, True)])
def test_particles_masked_lanes_paint_no_ghosts(R, y_up):
    # N=1 << BLOCK=256 -> 255 masked lanes load other=-1.0; the sole real
    # particle is fully out of frame, so the oracle image is all black
    buf = viz.PixelBuffer(8, 8)
    viz.clear(buf)
    viz.particles(buf,
                  tl.tensor(np.array([10.0], np.float32), device="cuda"),
                  tl.tensor(np.array([10.0], np.float32), device="cuda"),
                  color=(1, 1, 1), radius=R, y_up=y_up)
    assert not (buf.resolve() > 0).any()
