#!/usr/bin/env python
"""Causal vs full (non-causal) attention semantics, tested separately.

The fused kernels are causal-only (hard-coded mask); full attention uses
the unfused composition. These tests pin the two semantics apart so a
silent causal leak can never ship.

Oracle: fp64 numpy. torch is NOT used (repo rule: tests are torch-free).
"""

import numpy as np
import pytest

import minitriton as tl
from minitriton import nn, ops


def ref_attention(q, k, v, scale, causal):
    """fp64 reference; q/k/v (B, H, T, hd)."""
    q, k, v = (x.astype(np.float64) for x in (q, k, v))
    s = np.matmul(q, k.transpose(0, 1, 3, 2)) * scale
    if causal:
        t = s.shape[-2]
        s = s + np.triu(np.full((t, t), -1e9), k=1)
    s = s - s.max(axis=-1, keepdims=True)
    e = np.exp(s)
    p = e / e.sum(axis=-1, keepdims=True)
    return np.matmul(p, v)


def case_data(B=2, H=3, T=64, hd=64, seed=0):
    rng = np.random.default_rng(seed)
    q, k, v = (rng.standard_normal((B, H, T, hd)).astype(np.float32)
               for _ in range(3))
    return q, k, v, 1.0 / np.sqrt(hd)


@pytest.mark.parametrize("device", ["cpu", "cuda"])
@pytest.mark.parametrize("T", [1, 7, 64, 100])
def test_full_attention_fwd(device, T):
    q, k, v, scale = case_data(T=T)
    out = nn.unfused_attention(tl.tensor(q, device=device),
                               tl.tensor(k, device=device),
                               tl.tensor(v, device=device),
                               scale=scale)
    ref = ref_attention(q, k, v, scale, causal=False)
    np.testing.assert_allclose(out.numpy(), ref, rtol=2e-5, atol=2e-5)


def test_full_attention_bwd():
    q, k, v, scale = case_data()
    qq = tl.tensor(q, requires_grad=True)
    kk = tl.tensor(k, requires_grad=True)
    vv = tl.tensor(v, requires_grad=True)
    loss = nn.unfused_attention(qq, kk, vv, scale=scale).sum()
    loss.backward()
    # numerical grads via fp64
    eps = 1e-3
    for name, t, arr in (("q", qq, q), ("k", kk, k), ("v", vv, v)):
        g = t.grad.numpy().ravel()
        src = arr.astype(np.float64).ravel()
        idx = np.arange(0, src.size, max(1, src.size // 64))
        num = np.zeros(idx.size, dtype=np.float64)
        for j, i in enumerate(idx):
            old = src[i]
            src[i] = old + eps
            lp = ref_attention(q if name != "q" else src.reshape(arr.shape),
                               k if name != "k" else src.reshape(arr.shape),
                               v if name != "v" else src.reshape(arr.shape),
                               scale, False).sum()
            src[i] = old - eps
            lm = ref_attention(q if name != "q" else src.reshape(arr.shape),
                               k if name != "k" else src.reshape(arr.shape),
                               v if name != "v" else src.reshape(arr.shape),
                               scale, False).sum()
            src[i] = old
            num[j] = (lp - lm) / (2 * eps)
        np.testing.assert_allclose(g[idx], num, rtol=3e-2, atol=3e-2)


@pytest.mark.parametrize("device", ["cpu", "cuda"])
def test_causal_masked_triangle(device):
    """Causal path must zero the upper-triangle probability mass."""
    q, k, v, scale = case_data()
    out = nn.causal_attention(tl.tensor(q, device=device),
                              tl.tensor(k, device=device),
                              tl.tensor(v, device=device), scale=scale,
                              fused=(device == "cuda"))
    ref = ref_attention(q, k, v, scale, causal=True)
    np.testing.assert_allclose(out.numpy(), ref, rtol=2e-5, atol=2e-5)
    # and it must differ from the full (unmasked) result off-diagonal
    full = ref_attention(q, k, v, scale, causal=False)
    assert np.abs(out.numpy() - full).max() > 1e-3, \
        "causal == full: mask semantics missing"


def test_full_differs_from_causal():
    q, k, v, scale = case_data()
    a_full = nn.unfused_attention(tl.tensor(q), tl.tensor(k),
                                  tl.tensor(v), scale=scale)
    a_causal = nn.causal_attention(tl.tensor(q), tl.tensor(k),
                                   tl.tensor(v), scale=scale, fused=False)
    assert np.abs(a_full.numpy() - a_causal.numpy()).max() > 1e-3


def test_fused_rejects_noncausal():
    q, k, v, scale = case_data()
    try:
        tl.tensor(q, device="cuda")
    except Exception:
        pytest.skip("no cuda device")
    with pytest.raises(NotImplementedError):
        ops.flash_attention_forward(tl.tensor(q), tl.tensor(k),
                                    tl.tensor(v), scale=scale, causal=False)


def test_router_fused_matches_composition():
    """fused causal kernel and unfused composition agree (same semantics)."""
    q, k, v, scale = case_data()
    a = nn.causal_attention(tl.tensor(q), tl.tensor(k), tl.tensor(v),
                            scale=scale, fused=True)
    b = nn.causal_attention(tl.tensor(q), tl.tensor(k), tl.tensor(v),
                            scale=scale, fused=False)
    np.testing.assert_allclose(a.numpy(), b.numpy(), rtol=2e-4,
                               atol=2e-4)
