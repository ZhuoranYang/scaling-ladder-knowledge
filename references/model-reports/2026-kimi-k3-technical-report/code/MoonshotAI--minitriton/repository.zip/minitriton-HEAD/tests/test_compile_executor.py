"""@tl.compile executor regressions:

- fused binary_scalar pow reuses _pow_scalar_expr (int exponents
  multiply out; float integral exponents don't go through exp/log -> no
  NaN on negative bases)
- np.floating scalars take the float branch (no int() truncation)
- fused ew/mm groups early-out on 0-element outputs (no grid-0
  launches)
- R2' bias-only (empty chain) exec-time degrade returns the
  eagerly computed matmul
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl
import minitriton.ops as _ops

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


def _only_spec(cf):
    exe = list(cf._cache.values())[0]
    assert len(exe.fused) == 1
    return list(exe.fused.values())[0]


# ---------------------------------------------------------------------------
# pow through the fused elementwise build
# ---------------------------------------------------------------------------

def test_fused_pow_int_exponent():
    """x ** 2 in a fused chain: pre-fix KeyError('pow') in the int-bake
    branch (_EW_EXPR has no 'pow' key)."""

    @tl.compile
    def f(x):
        return tl.relu(x ** 2 + 1.0)

    x_np = rn(4, 32)
    out = f(tl.tensor(x_np)).numpy()
    ref = np.maximum(x_np ** 2 + 1.0, 0)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-5)
    assert _only_spec(f)["type"] == "ew_chain"  # fused, not replayed


def test_fused_pow_float_integral_exponent_negative_base():
    """x ** 2.0: pre-fix the fused build emitted exp(2.0*log(x)) -> NaN
    on negative bases; eager computes x*x via _pow_scalar_expr."""

    @tl.compile
    def f(x):
        return (x ** 2.0) * 1.0 + 0.0

    x_np = np.array([[-1.5, -0.99, -2.0, 0.5, 3.0]], dtype=np.float32)
    out = f(tl.tensor(x_np)).numpy()
    ref = x_np ** 2.0
    assert not np.isnan(out).any()
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-5)


def test_fused_pow_variants_match_eager():
    """pow scalar specialization parity with the eager table: 0.5 -> sqrt,
    -1 -> reciprocal, 3 -> triple product, non-integer -> exp/log."""

    @tl.compile
    def f(x):
        return (x ** 0.5 + x ** -1.0) * 1.0 + x ** 3

    x_np = np.abs(rn(8, 16)) + 0.5
    out = f(tl.tensor(x_np)).numpy()
    ref = (np.sqrt(x_np) + 1.0 / x_np) + x_np ** 3
    np.testing.assert_allclose(out, ref, rtol=1e-4, atol=1e-4)


# ---------------------------------------------------------------------------
# np.floating scalars in fused builds
# ---------------------------------------------------------------------------

def test_fused_np_float32_scalar_not_truncated():
    """np.float32 is not a Python float: pre-fix it fell into the int
    bake branch and int(2.5) truncated the literal."""

    @tl.compile
    def f(x):
        return tl.relu(x * np.float32(2.5) + 1.0)

    x_np = np.array([[1.0, -1.0, 3.0]], dtype=np.float32)
    out = f(tl.tensor(x_np)).numpy()
    ref = np.maximum(x_np * 2.5 + 1.0, 0)
    np.testing.assert_allclose(out, ref, rtol=1e-6, atol=1e-6)
    assert _only_spec(f)["type"] == "ew_chain"


# ---------------------------------------------------------------------------
# 0-element tensors never launch grid-0 kernels
# ---------------------------------------------------------------------------

def test_fused_ew_zero_elements():
    """(0, 16) chain: pre-fix the fused kernel launched with grid=(0,)
    -> CUDA_ERROR_INVALID_VALUE; eager early-outs."""

    @tl.compile
    def f(x, y):
        return tl.relu(x * y + 1.0)

    x = tl.tensor(np.zeros((0, 16), dtype=np.float32))
    y = tl.tensor(np.zeros((0, 16), dtype=np.float32))
    out = f(x, y)
    tl.synchronize()
    assert out.shape == (0, 16) and out.numel() == 0
    assert _only_spec(f)["type"] == "ew_chain"


def test_fused_mm_zero_rows():
    """M == 0 matmul epilogue group: guards the grid-0 crash class —
    must early-return the empty output (eager matmul does the same)."""

    @tl.compile
    def g(a, b, bias):
        return tl.gelu(_ops.matmul(a, b) + bias)

    a = tl.tensor(np.zeros((0, 32), dtype=np.float32))
    b = tl.tensor(rn(32, 64))
    bias = tl.tensor(np.zeros((64,), dtype=np.float32))
    out = g(a, b, bias)
    tl.synchronize()
    assert out.shape == (0, 64)


# ---------------------------------------------------------------------------
# R2' bias-only (empty chain) exec-time degrade
# ---------------------------------------------------------------------------

def test_r2p_baked_bias_stride_degrade_empty_chain():
    """bf16 matmul_bf16 with a baked bias and no epilogue chain matches
    R2' with chain=[]; when the real operand's strides fail the mma
    staging rules at exec time, degrade() must return the eagerly
    computed matmul (pre-fix IndexError on chain[-1])."""

    @tl.compile
    def lin(a, b, bias):
        return _ops.matmul_bf16(a, b, bias=bias)

    a_full = rn(32, 64)
    a_np = a_full[:, ::2]                    # (32, 32) strides (64, 2)
    b_np, bias_np = rn(32, 48), rn(48)
    ta = tl.tensor(a_full).astype(tl.bfloat16)[:, ::2]
    tb = tl.tensor(b_np).astype(tl.bfloat16)
    tbias = tl.tensor(bias_np).astype(tl.bfloat16)

    out = lin(ta, tb, tbias)
    spec = _only_spec(lin)
    assert spec["type"] == "mma_epilogue" and spec["chain"] == []
    # the degraded exec is the eager replay, bit-identical to eager
    eager = _ops.matmul_bf16(ta, tb, bias=tbias)
    np.testing.assert_array_equal(out.astype(tl.float32).numpy(),
                                  eager.astype(tl.float32).numpy())
    ref = a_np.astype(np.float64) @ b_np.astype(np.float64) + bias_np
    np.testing.assert_allclose(out.astype(tl.float32).numpy(), ref,
                               rtol=1e-1, atol=1e-1)


def test_compile_swiglu():
    """tl.swiglu is a public fused op; the trace backend used to lack
    the method entirely (AttributeError at trace time)."""

    @tl.compile
    def f(x, y):
        return tl.swiglu(x, y)

    x_np, y_np = rn(64, 32), rn(64, 32)
    got = f(tl.tensor(x_np), tl.tensor(y_np)).numpy()
    xf, yf = x_np.astype(np.float64), y_np.astype(np.float64)
    ref = (xf / (1.0 + np.exp(-xf))) * yf
    np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-6)


def test_compile_add_layernorm():
    """tl.add_layernorm traces through add_layernorm_rows, which returns
    (out, s|None) — the tuple needs pick nodes so downstream ops see
    plain single-tensor nodes."""

    @tl.compile
    def f(x, r, w, b):
        return tl.add_layernorm(x, r, (x.shape[-1],), weight=w, bias=b)

    @tl.compile
    def g(x, r, w, b):
        y, s = tl.add_layernorm(x, r, (x.shape[-1],), weight=w, bias=b,
                                return_residual=True)
        return y + s * 0.0  # consume both tuple outputs

    x_np, r_np = rn(16, 32), rn(16, 32)
    w_np, b_np = rn(32), rn(32)
    tx, tr = tl.tensor(x_np), tl.tensor(r_np)
    tw, tb = tl.tensor(w_np), tl.tensor(b_np)
    s = x_np.astype(np.float64) + r_np.astype(np.float64)
    mu = s.mean(-1, keepdims=True)
    var = ((s - mu) ** 2).mean(-1, keepdims=True)
    ref = (s - mu) / np.sqrt(var + 1e-5) * w_np + b_np
    np.testing.assert_allclose(f(tx, tr, tw, tb).numpy(), ref,
                               rtol=1e-5, atol=1e-6)
    np.testing.assert_allclose(g(tx, tr, tw, tb).numpy(), ref,
                               rtol=1e-5, atol=1e-6)
