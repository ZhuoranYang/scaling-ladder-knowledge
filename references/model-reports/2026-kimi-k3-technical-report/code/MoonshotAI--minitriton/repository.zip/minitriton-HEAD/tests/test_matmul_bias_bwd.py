"""Regression tests: matmul bias autograd + 1-D matmul backward.

- ``Matmul.forward`` accepts ``bias``; backward returns the bias grad
  (g summed over the broadcast-away dims, f32 — the Linear dbias rule).
- the bf16 mixed-precision backward (``_mm_backward_bf16``) handles
  1-D operands (1D@2D, 2D@1D, 1D@1D) instead of IndexError.
- ``@tl.compile``'s traced ``matmul_bf16`` forwards ``bias`` through
  the 1-D reshape routes (it was silently dropped); a wrong-shaped bias
  fails loudly at trace time.

numpy oracle only (no torch). Tolerances: fp32 grads rtol/atol 1e-4 (as
test_autograd.py's matmul rule); bf16 mma-route grads vs the bf16-rounded
f64 oracle rtol 2e-2 / atol 5e-2 (the bf16 mma rounding-noise band);
compiled-vs-eager
is bit-identical (same kernels, measured maxdiff 0.0).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import ops

DEVS = pytest.mark.parametrize("dev", ["cpu", "cuda"])

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


def T(x, dev, requires_grad=True):
    return tl.tensor(np.ascontiguousarray(x), device=dev,
                     requires_grad=requires_grad)


def close(out, ref, rtol=1e-4, atol=1e-4):
    arr = out.numpy() if isinstance(out, tl.Tensor) else out
    ref = np.asarray(ref)
    assert arr.shape == ref.shape, f"shape {arr.shape} != ref {ref.shape}"
    np.testing.assert_allclose(arr, ref, rtol=rtol, atol=atol)


def _bf16_round(x):
    return tl.tensor(x).astype(tl.bfloat16).astype(tl.float32).numpy()


def _bf16_t(x, requires_grad=True):
    t = tl.tensor(np.ascontiguousarray(x)).astype(tl.bfloat16)
    t.requires_grad = requires_grad
    return t


# ---------------------------------------------------------------------------
# matmul(bias=...) forward + backward
# ---------------------------------------------------------------------------

@DEVS
def test_matmul_bias_backward_2d(dev):
    a, b, bias, g = rn(5, 7), rn(7, 3), rn(3), rn(5, 3)
    ta, tb, tbias = T(a, dev), T(b, dev), T(bias, dev)
    out = tl.matmul(ta, tb, bias=tbias)
    close(out, a @ b + bias)
    out.backward(T(g, dev, False))
    close(ta.grad, g @ b.T)
    close(tb.grad, a.T @ g)
    close(tbias.grad, g.sum(0))


@DEVS
def test_matmul_bias_backward_leading_dims(dev):
    """(B, T, K) @ (K, N) + bias: dbias sums over both leading dims."""
    a, b, bias, g = rn(2, 3, 7), rn(7, 5), rn(5), rn(2, 3, 5)
    ta, tb, tbias = T(a, dev), T(b, dev), T(bias, dev)
    out = tl.matmul(ta, tb, bias=tbias)
    close(out, a @ b + bias)
    out.backward(T(g, dev, False))
    close(ta.grad, g @ b.T)
    close(tb.grad, a.reshape(-1, 7).T @ g.reshape(-1, 5))
    close(tbias.grad, g.reshape(-1, 5).sum(0))


@DEVS
def test_matmul_no_bias_unchanged(dev):
    """No-bias control: plain and explicit bias=None both record (a, b)
    only and still return exactly two grads."""
    a, b, g = rn(5, 7), rn(7, 3), rn(5, 3)
    for kwargs in ({}, {"bias": None}):
        ta, tb = T(a, dev), T(b, dev)
        out = tl.matmul(ta, tb, **kwargs)
        close(out, a @ b)
        out.backward(T(g, dev, False))
        close(ta.grad, g @ b.T)
        close(tb.grad, a.T @ g)


def test_matmul_bias_backward_bf16_cuda():
    """bf16 fused-bias-epilogue forward; backward through the bf16 mma
    route (grads rounded to bf16 in-kernel, f32 out); dbias f32."""
    M, K, N = 6, 7, 4
    a32, b32, bias32, g32 = rn(M, K), rn(K, N), rn(N), rn(M, N)
    ta, tb, tbias = _bf16_t(a32), _bf16_t(b32), _bf16_t(bias32)
    out = tl.matmul(ta, tb, bias=tbias)
    assert out.dtype == tl.bfloat16
    ar, br = _bf16_round(a32), _bf16_round(b32)
    ref = ar.astype(np.float64) @ br.astype(np.float64) + bias32
    np.testing.assert_allclose(out.numpy().astype(np.float64), ref,
                               rtol=2e-2, atol=5e-2)
    out.backward(tl.tensor(g32))
    gr = _bf16_round(g32).astype(np.float64)  # g rounds to bf16 in-kernel
    assert ta.grad.dtype == tl.float32
    assert tb.grad.dtype == tl.float32
    np.testing.assert_allclose(ta.grad.numpy().astype(np.float64),
                               gr @ br.astype(np.float64).T,
                               rtol=2e-2, atol=5e-2)
    np.testing.assert_allclose(tb.grad.numpy().astype(np.float64),
                               ar.astype(np.float64).T @ gr,
                               rtol=2e-2, atol=5e-2)
    # f32 seed: the dbias colsum is exact f32 (fp32 master contract)
    assert tbias.grad.dtype == tl.float32
    close(tbias.grad, g32.sum(0))


# ---------------------------------------------------------------------------
# bf16 1-D matmul backward
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("combo", ["1D@2D", "2D@1D", "1D@1D"])
def test_matmul_bf16_1d_backward(combo):
    M, K, N = 6, 7, 4
    if combo == "1D@2D":
        a32, b32 = rn(K), rn(K, N)
    elif combo == "2D@1D":
        a32, b32 = rn(M, K), rn(K)
    else:
        a32, b32 = rn(K), rn(K)
    ta, tb = _bf16_t(a32), _bf16_t(b32)
    out = tl.matmul(ta, tb)
    g32 = rn(*out.shape) if out.shape else rn()
    out.backward(tl.tensor(g32))
    ar = _bf16_round(a32).astype(np.float64)
    br = _bf16_round(b32).astype(np.float64)
    gr = _bf16_round(g32).astype(np.float64)
    if combo == "1D@2D":
        ref_da, ref_db = gr @ br.T, np.outer(ar, gr)
    elif combo == "2D@1D":
        ref_da, ref_db = np.outer(gr, br), ar.T @ gr
    else:  # dot: elementwise backward, f32 g unrounded (no mma)
        ref_da = ref_db = None
        close(ta.grad, g32 * _bf16_round(b32), rtol=1e-5, atol=1e-6)
        close(tb.grad, g32 * _bf16_round(a32), rtol=1e-5, atol=1e-6)
    if ref_da is not None:
        assert ta.grad.dtype == tl.float32
        assert tb.grad.dtype == tl.float32
        np.testing.assert_allclose(ta.grad.numpy().astype(np.float64),
                                   ref_da, rtol=2e-2, atol=5e-2)
        np.testing.assert_allclose(tb.grad.numpy().astype(np.float64),
                                   ref_db, rtol=2e-2, atol=5e-2)
    assert ta.grad.shape == a32.shape
    assert tb.grad.shape == b32.shape


# ---------------------------------------------------------------------------
# @tl.compile bf16 1-D matmul_bf16 bias forwarding
# ---------------------------------------------------------------------------

def _bf16(x):
    return tl.tensor(np.ascontiguousarray(x)).astype(tl.bfloat16)


@pytest.mark.parametrize("combo", ["1D@2D", "2D@1D", "1D@1D", "2D@2D"])
def test_compile_matmul_bf16_1d_bias_matches_eager(combo):
    """compiled == eager (bit-identical: same kernels/configs) and both
    match the bf16-rounded numpy oracle — the bias is not dropped."""
    M, K, N = 8, 16, 4
    # bias shape per the eager 1-D contract: (N,) of the reshaped 2D out
    if combo == "1D@2D":
        a32, b32, bias32 = rn(K), rn(K, N), rn(N)
    elif combo == "2D@1D":
        a32, b32, bias32 = rn(M, K), rn(K), rn(1)
    elif combo == "1D@1D":
        a32, b32, bias32 = rn(K), rn(K), rn(1)
    else:
        a32, b32, bias32 = rn(M, K), rn(K, N), rn(N)

    @tl.compile
    def f(x, y, z):
        return ops.matmul_bf16(x, y, bias=z)

    compiled = f(_bf16(a32), _bf16(b32), _bf16(bias32))
    eager = ops.matmul_bf16(_bf16(a32), _bf16(b32), bias=_bf16(bias32))
    assert compiled.shape == eager.shape
    np.testing.assert_array_equal(compiled.numpy(), eager.numpy())
    ref = (_bf16_round(a32).astype(np.float64)
           @ _bf16_round(b32).astype(np.float64) + bias32)
    np.testing.assert_allclose(compiled.numpy().astype(np.float64), ref,
                               rtol=2e-2, atol=5e-2)


def test_compile_matmul_bf16_bad_bias_shape_raises():
    """A wrong-shaped bias must fail loudly at trace time (mirroring the
    eager _mm_bf16_2d check), never silently dropped or mis-reshaped."""
    K, N = 16, 4

    @tl.compile
    def f(x, y, z):
        return ops.matmul_bf16(x, y, bias=z)

    with pytest.raises(RuntimeError, match="matmul_bf16 bias must be"):
        f(_bf16(rn(K)), _bf16(rn(K, N)), _bf16(rn(K)))  # want (N,)=(4,)
