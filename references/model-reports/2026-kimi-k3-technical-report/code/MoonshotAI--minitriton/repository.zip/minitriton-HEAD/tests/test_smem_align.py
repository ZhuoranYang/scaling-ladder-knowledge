"""Static smem globals are 16B-aligned.

Without an alignment on memref.GlobalOp, llc emits
``.extern .shared .align 4 .b8 name[N]`` and ptxas packs the buffers in
PTX declaration order. Since ``_smem_global`` inserts each new global at
the gpu.module block head, a small scratch buffer allocated AFTER the
matmul staging buffers (e.g. the cross-warp tl.sum reduce scratch, 8B at
num_warps=2) precedes them in PTX and pushes the 16KB cp.async buffers
to offset 8 — every 16B cp.async/ldmatrix then faults with
CUDA_ERROR_MISALIGNED_ADDRESS. The GlobalOp therefore pins alignment=16
(LLVM global align 16 -> .align 16 -> ptxas pads). numpy oracle only,
no torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl


@tl.kernel
def _mm_then_crosswarp_sum_kernel(a_ptr, b_ptr, c_ptr, x_ptr, s_ptr,
                                  M, N, K,
                                  BM: tl.constexpr, BN: tl.constexpr,
                                  BK: tl.constexpr, TM: tl.constexpr,
                                  TN: tl.constexpr, STAGES: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * N + offs_n[None, :]
    acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES)
    tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)
    # cross-warp reduction: allocates the small smem_reduce scratch AFTER
    # the two 16KB matmul staging buffers (inserted at the block head, so
    # it precedes them in PTX order)
    x = tl.load(x_ptr + tl.arange(0, BM))
    s = tl.sum(x)
    tl.store(s_ptr, s)


def test_matmul_then_crosswarp_reduce_not_misaligned():
    # stages=2, BM=64/BK=32 f32: two 16384B staging buffers; num_warps=2
    # gives an 8B smem_reduce that pre-fix pushed them to offset 8 and the
    # kernel faulted with CUDA_ERROR_MISALIGNED_ADDRESS
    M = N = K = 64
    rng = np.random.default_rng(0)
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)
    x = rng.standard_normal(M).astype(np.float32)
    da, db = tl.Buffer.from_numpy(a), tl.Buffer.from_numpy(b)
    dx = tl.Buffer.from_numpy(x)
    dc = tl.Buffer(M * N, tl.float32)
    ds = tl.Buffer(1, tl.float32)
    _mm_then_crosswarp_sum_kernel[(1, 1)](
        da, db, dc, dx, ds, M, N, K,
        BM=64, BN=64, BK=32, TM=8, TN=8, STAGES=2, num_warps=2)
    tl.synchronize()
    np.testing.assert_allclose(dc.to_numpy().reshape(M, N), a @ b,
                               rtol=1e-4, atol=1e-4 * np.sqrt(K))
    np.testing.assert_allclose(ds.to_numpy(), x.sum(),
                               rtol=1e-5, atol=1e-5)


def test_smem_global_declares_16B_alignment():
    # every static smem global (scratch or staging) must carry the pinned
    # 16B alignment in its memref.global declaration
    from minitriton.compiler.builder import Builder

    with Builder("align_decl_probe", 128) as b:
        b.begin([("x", ("ptr", tl.float32))])
        b._scratch_smem("probe_big", 4096, tl.float32)
        b._scratch_smem("probe_tiny", 2, tl.float32)
        text = b.finish()
    decls = [ln.strip() for ln in text.splitlines()
             if "memref.global" in ln and "smem_probe" in ln]
    assert len(decls) == 2, decls
    for ln in decls:
        assert "alignment = 16" in ln, ln
