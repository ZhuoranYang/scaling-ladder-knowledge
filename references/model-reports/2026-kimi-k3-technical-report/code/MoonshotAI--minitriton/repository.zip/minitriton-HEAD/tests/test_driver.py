"""Driver-wrapper tests: alloc / copy / launch against numpy."""

import ctypes
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

from minitriton.compiler.lowering import compile_to_cubin
from minitriton.runtime.cuda_driver import Device, memref1d_params

VECADD_MLIR = """
module {
  gpu.module @vecadd_module {
    gpu.func @vecadd(%x: memref<?xf32>, %y: memref<?xf32>,
                     %out: memref<?xf32>, %n: i32) kernel {
      %bid = gpu.block_id x
      %bdim = gpu.block_dim x
      %tid = gpu.thread_id x
      %tmp = arith.muli %bid, %bdim : index
      %i = arith.addi %tmp, %tid : index
      %n_idx = arith.index_cast %n : i32 to index
      %inb = arith.cmpi ult, %i, %n_idx : index
      scf.if %inb {
        %a = memref.load %x[%i] : memref<?xf32>
        %b = memref.load %y[%i] : memref<?xf32>
        %c = arith.addf %a, %b : f32
        memref.store %c, %out[%i] : memref<?xf32>
      }
      gpu.return
    }
  }
}
"""


@pytest.fixture(scope="module")
def device():
    return Device(0)


def test_alloc_copy_roundtrip(device):
    n = 1024
    x = np.arange(n, dtype=np.float32)
    out = np.zeros_like(x)
    ptr = device.alloc(n * 4)
    try:
        device.memcpy_h2d(ptr, x, n * 4)
        device.memcpy_d2h(out, ptr, n * 4)
    finally:
        device.free(ptr)
    np.testing.assert_array_equal(out, x)


def test_vecadd_launch(device, tmp_path):
    n = 100_003  # odd size on purpose: exercises the bounds check
    rng = np.random.default_rng(42)
    x = rng.random(n, dtype=np.float32)
    y = rng.random(n, dtype=np.float32)
    out = np.empty(n, dtype=np.float32)

    cubin = compile_to_cubin(VECADD_MLIR, name="vecadd_test", build_dir=tmp_path)
    kernel = device.load_module(cubin).function("vecadd")

    nbytes = n * 4
    dx, dy, dout = device.alloc(nbytes), device.alloc(nbytes), device.alloc(nbytes)
    try:
        device.memcpy_h2d(dx, x, nbytes)
        device.memcpy_h2d(dy, y, nbytes)
        block = 128
        params = (
            memref1d_params(dx, n)
            + memref1d_params(dy, n)
            + memref1d_params(dout, n)
            + [ctypes.c_int32(n)]
        )
        kernel.launch(((n + block - 1) // block, 1, 1), (block, 1, 1), params)
        device.synchronize()
        device.memcpy_d2h(out, dout, nbytes)
    finally:
        device.free(dx)
        device.free(dy)
        device.free(dout)

    np.testing.assert_allclose(out, x + y, rtol=0, atol=1e-6)
