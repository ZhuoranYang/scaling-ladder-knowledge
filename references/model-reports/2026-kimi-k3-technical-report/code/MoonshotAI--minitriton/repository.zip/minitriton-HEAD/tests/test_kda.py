"""KDA (Kimi Delta Attention) forward tests.

Three oracle levels:
  L1  naive double loop       — semantic ground truth, fp64
  L2  numpy chunk closed form — fp64; IS the CPU backend implementation
                                (device.cpu._kda_chunk_np)
  L3  kernel-form simulation  — fp32 numpy with the exact numerical actions
                                of the GPU pipeline: fp32 preprocessing,
                                scalar shift + +-80 clip, tail-shifted write
                                keys, prod-of-squares inversion (kept as the
                                control for the solve_tril path the kernels
                                actually use — both approximate (I+L)^-1 to
                                ~1e-6, far inside the e2e tolerance)
GPU results are compared against L2 and L3; tolerances:
rtol=2e-4, atol=5e-4 for regular decay; pathological excursion zones only
assert finiteness + agreement with L3. No torch in tests/.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import ops as tl_ops
from minitriton.device.cpu import _kda_chunk_np

C = 64
RTOL, ATOL = 2e-4, 5e-4


# ---------------------------------------------------------------------------
# input generation + fp64/fp32 preprocessing (mirrors ops/kda.py)
# ---------------------------------------------------------------------------

def _log_sigmoid_np(x):
    return np.where(x > 0, 0.0, x) - np.log(np.exp(-np.abs(x)) + 1.0)


def _sigmoid_np(x):
    return 1.0 / (1.0 + np.exp(-x))


def gen(B, H, T, dk, dv, seed=0, loga_lo=-0.7, with_s0=False):
    """Random inputs on the raw contract (x_beta/x_decay are logits).
    x_decay = logit(exp(loga)) with loga ~ U(loga_lo, 0) so the recovered
    decay gates cover (exp(loga_lo), 1) uniformly in log space."""
    rng = np.random.default_rng(seed)
    q = rng.standard_normal((B, H, T, dk)).astype(np.float32)
    k = rng.standard_normal((B, H, T, dk)).astype(np.float32)
    v = rng.standard_normal((B, H, T, dv)).astype(np.float32)
    xb = rng.standard_normal((B, H, T)).astype(np.float32)
    loga = rng.uniform(loga_lo, 0.0, (B, H, T, dk))
    a = np.exp(loga)
    xd = np.log(a / (1.0 - a)).astype(np.float32)
    s0 = rng.standard_normal((B, H, dk, dv)).astype(np.float32) \
        if with_s0 else None
    return q, k, v, xb, xd, s0


def preprocess_np(q, k, v, xb, xd, dt):
    """The ops/kda.py preprocessing, in numpy at precision dt."""
    kn = k / np.sqrt((k * k).sum(-1, keepdims=True))
    qn = q / np.sqrt((q * q).sum(-1, keepdims=True))
    beta = _sigmoid_np(xb)
    loga = _log_sigmoid_np(xd)
    return (kn.astype(dt), qn.astype(dt), v.astype(dt),
            beta.astype(dt), loga.astype(dt))


# ---------------------------------------------------------------------------
# L1 — naive recurrence (fp64): S_t = Diag(a) S + beta k (v - (a k)^T S)^T
# ---------------------------------------------------------------------------

def kda_naive(q, k, v, xb, xd, s0=None):
    kn, qn, vv, beta, loga = preprocess_np(q, k, v, xb, xd, np.float64)
    B, H, T, dk = kn.shape
    dv = vv.shape[-1]
    S = np.zeros((B, H, dk, dv)) if s0 is None \
        else np.asarray(s0, np.float64).copy()
    o = np.zeros((B, H, T, dv))
    for b in range(B):
        for h in range(H):
            s = S[b, h]
            for t in range(T):
                a = np.exp(loga[b, h, t])              # (dk,)
                kk = kn[b, h, t]
                e = (a * kk) @ s                       # read-out (dv,)
                s = a[:, None] * s \
                    + beta[b, h, t] * np.outer(kk, vv[b, h, t] - e)
                o[b, h, t] = s.T @ qn[b, h, t]
            S[b, h] = s
    return o, S


# ---------------------------------------------------------------------------
# L3 — kernel-form simulation (fp32): the exact numerical actions of the
# GPU pipeline (fp32 preprocessing, c/emc shift, +-80 clip, tail-shifted
# write keys, prod-of-squares inversion as the solve_tril control)
# ---------------------------------------------------------------------------

def _prod_of_squares_inv(L):
    """(I + L)^-1 = (I - L)(I + L^2)(I + L^4)...(I + L^32) for nilpotent
    strictly-lower L (L^64 = 0); exact, all-matmul."""
    dt = L.dtype
    P = -L
    W = np.eye(L.shape[-1], dtype=dt) + P
    for _ in range(5):
        P = P @ P
        W = W + P @ W
    return W


def kda_kernel_sim(q, k, v, xb, xd, s0=None, planes=False):
    f = np.float32
    kn, qn, vv, beta, loga = preprocess_np(q, k, v, xb, xd, f)
    B, H, T, dk = kn.shape
    dv = vv.shape[-1]
    NC = (T + C - 1) // C

    def _pad(x):
        n = NC * C - x.shape[2]
        if n == 0:
            return x
        pad = [(0, 0)] * x.ndim
        pad[2] = (0, n)
        return np.pad(x, pad)

    kn, qn, vv, loga, beta = (_pad(x) for x in (kn, qn, vv, loga, beta))
    # eager per-chunk decay totals + scalar shift (fp32, ops/kda.py math)
    gt = loga.reshape(B, H, NC, C, dk).sum(axis=3)          # (B,H,NC,dk)
    csh = np.maximum(gt.min(axis=-1), -80.0)                # (B,H,NC)
    emc = np.exp(-csh)
    o = np.zeros((B, H, NC * C, dv), dtype=f)
    S = np.zeros((B, H, dk, dv), dtype=f) if s0 is None \
        else np.asarray(s0, f).copy()
    strict = np.tril(np.ones((C, C), dtype=f), -1)
    incl = np.tril(np.ones((C, C), dtype=f))
    il = np.tril(np.ones((C, C), dtype=f))
    pl = None
    if planes:
        pl = {nm: np.zeros((B * H, NC, C, C), dtype=f)
              for nm in ("l", "m")}
        pl.update({
            "delta": np.zeros((B * H, NC, C, dk), dtype=f),
            "qh": np.zeros((B * H, NC, C, dk), dtype=f),
            "wc": np.zeros((B * H, NC, dk, C), dtype=f),
            "wt": np.zeros((B * H, NC, dk, C), dtype=f),
            "md": np.zeros((B * H, NC, C, dk), dtype=f),
            "mv": np.zeros((B * H, NC, C, dv), dtype=f),
            "hc": np.zeros((B * H, NC, dk, dv), dtype=f),
            "vt": np.zeros((B * H, NC, C, dv), dtype=f),
        })
    for b in range(B):
        for h in range(H):
            s = S[b, h]
            for c in range(NC):
                lo = c * C
                loga_c = loga[b, h, lo:lo + C]
                g = (il @ loga_c).astype(f)                 # cumsum via dot
                gT = gt[b, h, c]
                d = np.exp(g)
                kn_c = kn[b, h, lo:lo + C]
                delta = (d * kn_c).astype(f)
                qhat = (d * qn[b, h, lo:lo + C]).astype(f)
                e = np.clip(csh[b, h, c] - g, -80.0, 80.0)
                wc = (beta[b, h, lo:lo + C][:, None] * kn_c
                      * np.exp(e)).astype(f)                # write keys
                L = ((delta @ wc.T) * strict
                     * emc[b, h, c]).astype(f)
                W = _prod_of_squares_inv(L)                 # solve_tril control
                # pseudo-values in the kernels' factored form:
                # vt = Mv - Md @ S with Md = W @ delta, Mv = W @ v
                Md = (W @ delta).astype(f)
                Mv = (W @ vv[b, h, lo:lo + C]).astype(f)
                vt = (Mv - Md @ s).astype(f)
                Aq = ((qhat @ wc.T) * incl * emc[b, h, c]).astype(f)
                o[b, h, lo:lo + C] = qhat @ s + Aq @ vt
                wt = (beta[b, h, lo:lo + C][:, None] * kn_c
                      * np.exp(gT[None, :] - g)).astype(f)  # tail-shifted
                if planes:
                    bh, sl = b * H + h, c
                    pl["l"][bh, sl] = L
                    pl["m"][bh, sl] = W
                    pl["delta"][bh, sl] = delta
                    pl["qh"][bh, sl] = qhat
                    pl["wc"][bh, sl] = wc.T
                    pl["wt"][bh, sl] = wt.T
                    pl["md"][bh, sl] = Md
                    pl["mv"][bh, sl] = Mv
                    pl["hc"][bh, sl] = s
                    pl["vt"][bh, sl] = vt
                s = (np.exp(gT)[:, None] * s + wt.T @ vt).astype(f)
            S[b, h] = s
    if planes:
        pl["s1"] = S
        pl["o"] = o[:, :, :T]
        return pl
    return o[:, :, :T], S


# ---------------------------------------------------------------------------
# L1 vs L2 (fp64 oracle cross-validation) + prod-of-squares control
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("T", [1, 63, 64, 65, 100, 300])
@pytest.mark.parametrize("dk,dv", [(64, 64), (128, 128), (64, 128)])
@pytest.mark.parametrize("with_s0", [False, True])
def test_l1_vs_l2(T, dk, dv, with_s0):
    q, k, v, xb, xd, s0 = gen(2, 2, T, dk, dv, seed=T + dk,
                              with_s0=with_s0)
    o1, s1 = kda_naive(q, k, v, xb, xd, s0)
    kn, qn, vv, beta, loga = preprocess_np(q, k, v, xb, xd, np.float64)
    o2, s2 = _kda_chunk_np(kn, qn, vv, beta, loga, s0)
    np.testing.assert_allclose(o2, o1, rtol=1e-10, atol=1e-10)
    np.testing.assert_allclose(s2, s1, rtol=1e-10, atol=1e-10)


@pytest.mark.parametrize("loga_lo", [-0.7, -6.0, -12.0])
def test_l1_vs_l2_decay_regimes(loga_lo):
    q, k, v, xb, xd, s0 = gen(1, 2, 200, 64, 64, seed=7, loga_lo=loga_lo,
                              with_s0=True)
    o1, s1 = kda_naive(q, k, v, xb, xd, s0)
    kn, qn, vv, beta, loga = preprocess_np(q, k, v, xb, xd, np.float64)
    o2, s2 = _kda_chunk_np(kn, qn, vv, beta, loga, s0)
    np.testing.assert_allclose(o2, o1, rtol=1e-10, atol=1e-10)
    np.testing.assert_allclose(s2, s1, rtol=1e-10, atol=1e-10)


def test_prod_of_squares_control():
    """The design-report inversion (kept as the control for the kernels'
    tl.solve_tril path): exact for nilpotent strict-lower L."""
    rng = np.random.default_rng(3)
    worst = 0.0
    for _ in range(20):
        kk = rng.standard_normal((C, C))
        kk /= np.linalg.norm(kk, axis=-1, keepdims=True)
        L = np.tril(kk @ kk.T, -1)
        W = _prod_of_squares_inv(L)
        ref = np.linalg.inv(np.eye(C) + L)
        worst = max(worst, float(np.abs(W - ref).max()))
    assert worst < 1e-12, f"prod-of-squares vs exact inv: {worst:.2e}"


# ---------------------------------------------------------------------------
# L3 vs L1 (fp32 kernel-form simulation sanity)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("T", [1, 63, 64, 65, 100, 300])
@pytest.mark.parametrize("with_s0", [False, True])
def test_l3_vs_l1(T, with_s0):
    q, k, v, xb, xd, s0 = gen(1, 2, T, 64, 64, seed=T * 3 + 1,
                              with_s0=with_s0)
    o1, s1 = kda_naive(q, k, v, xb, xd, s0)
    o3, s3 = kda_kernel_sim(q, k, v, xb, xd, s0)
    np.testing.assert_allclose(o3, o1, rtol=RTOL, atol=ATOL)
    np.testing.assert_allclose(s3, s1, rtol=RTOL, atol=ATOL)


# ---------------------------------------------------------------------------
# CPU backend e2e (ops.kda_forward on cpu tensors) vs L1
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("T", [1, 63, 64, 65, 100])
@pytest.mark.parametrize("with_s0", [False, True])
def test_cpu_backend_e2e(T, with_s0):
    q, k, v, xb, xd, s0 = gen(1, 2, T, 64, 64, seed=T * 5 + 2,
                              with_s0=with_s0)
    o1, s1 = kda_naive(q, k, v, xb, xd, s0)
    args = [tl.tensor(x, device="cpu") for x in (q, k, v, xb, xd)]
    s0t = tl.tensor(s0, device="cpu") if s0 is not None else None
    o2, s2 = tl_ops.kda_forward(*args, initial_state=s0t,
                                output_final_state=True)
    np.testing.assert_allclose(o2.numpy(), o1, rtol=RTOL, atol=ATOL)
    np.testing.assert_allclose(s2.numpy(), s1, rtol=RTOL, atol=ATOL)


def test_log_sigmoid_stable():
    """log_sigmoid must stay finite and exact-looking far below the fp32
    sigmoid underflow point (naive log(sigmoid(x)) dies at x ~ -87)."""
    x = np.array([30.0, 1.0, 0.0, -1.0, -20.0, -80.0, -100.0],
                 dtype=np.float32)
    for dev in ("cpu", "cuda"):
        y = tl_ops.log_sigmoid(tl.tensor(x, device=dev)).numpy()
        ref = _log_sigmoid_np(x.astype(np.float64))
        assert np.all(np.isfinite(y))
        np.testing.assert_allclose(y, ref, rtol=1e-5, atol=1e-6)


# ---------------------------------------------------------------------------
# GPU stage-wise tests (cuda): K1 planes -> K1s inverse -> K2 state -> e2e.
# References: L2 (_kda_chunk_np, fp64) and L3 (kda_kernel_sim, fp32) — both
# cross-validated against L1 above; L1's python double loop is too slow for
# the big-T matrix — hence this oracle hierarchy.
# ---------------------------------------------------------------------------

def _cuda_run_k1(q, k, v, xb, xd):
    """ops/kda.py preprocessing on cuda + K1 (+K1s); returns
    (planes, preprocessed tensors)."""
    from minitriton.device.cuda.kernels import kda as kda_k
    from minitriton.ops.kda import kda_preprocess
    ts = [tl.tensor(x, device="cuda") for x in (q, k, v, xb, xd)]
    kn, qn, beta, loga, g, gt, c, emc = kda_preprocess(*ts)
    B, H, T, dk = k.shape
    NC = (T + C - 1) // C
    planes = kda_k.alloc_wy_planes(B * H, NC, dk)
    kda_k.launch_kda_wy(kn, qn, beta, g, gt, c, emc, planes,
                        B * H, T, NC, dk)
    kda_k.launch_kda_solve(planes, B * H, NC)
    tl.synchronize()
    return planes, (kn, qn, beta, loga, g, gt, c, emc)


@pytest.mark.parametrize("T", [1, 63, 64, 65, 100, 300])
@pytest.mark.parametrize("dk", [64, 128])
def test_k1_planes(T, dk):
    q, k, v, xb, xd, _ = gen(2, 2, T, dk, dk, seed=T + dk)
    planes, _ = _cuda_run_k1(q, k, v, xb, xd)
    ref = kda_kernel_sim(q, k, v, xb, xd, planes=True)
    for nm, rtol, atol in (("delta", 1e-3, 1e-4), ("qh", 1e-3, 1e-4),
                           ("l", 1e-3, 1e-4), ("wt", 1e-3, 1e-4),
                           ("wc", 1e-2, 1e-30)):  # wc: exp(+-80) range
        got = planes[nm].numpy()
        np.testing.assert_allclose(got, ref[nm].reshape(got.shape),
                                   rtol=rtol, atol=atol,
                                   err_msg=f"K1 plane {nm}")


@pytest.mark.parametrize("T", [63, 64, 65, 300])
def test_k1s_solve_tril(T):
    """M plane vs the fp64 exact inverse of the GPU's own L (isolates the
    solve_tril error from everything upstream)."""
    q, k, v, xb, xd, _ = gen(2, 2, T, 64, 64, seed=T)
    planes, _ = _cuda_run_k1(q, k, v, xb, xd)
    L = planes["l"].numpy().astype(np.float64)
    M = planes["m"].numpy()
    ref = np.linalg.inv(np.eye(C) + L)
    np.testing.assert_allclose(M, ref, rtol=RTOL, atol=ATOL)


@pytest.mark.parametrize("T", [1, 63, 64, 65, 100, 300])
@pytest.mark.parametrize("dk,dv", [(64, 64), (128, 128), (64, 128)])
@pytest.mark.parametrize("with_s0", [False, True])
def test_k2_state(T, dk, dv, with_s0):
    from minitriton.device.cuda.kernels import kda as kda_k
    q, k, v, xb, xd, s0 = gen(2, 2, T, dk, dv, seed=T * 7 + dk,
                              with_s0=with_s0)
    planes, (_, _, _, _, _, gt, _, _) = _cuda_run_k1(q, k, v, xb, xd)
    B, H = q.shape[:2]
    NC = (T + C - 1) // C
    mv_planes = kda_k.alloc_mv_planes(B * H, NC, dk, dv)
    tv = tl.tensor(v, device="cuda")
    kda_k.launch_kda_mv(planes, mv_planes, tv, B * H, T, NC, dk, dv)
    hc = tl.empty((B * H * NC, dk, dv), tl.float32, "cuda")
    vt = tl.empty((B * H * NC, C, dv), tl.float32, "cuda")
    s1 = tl.empty((B * H, dk, dv), tl.float32, "cuda")
    ts0 = tl.tensor(s0, device="cuda") if s0 is not None else None
    kda_k.launch_kda_state(mv_planes, planes["wt"], gt, ts0, hc, vt, s1,
                           B * H, T, NC, dk, dv)
    tl.synchronize()
    ref = kda_kernel_sim(q, k, v, xb, xd, s0, planes=True)
    np.testing.assert_allclose(mv_planes["md"].numpy(),
                               ref["md"].reshape(B * H * NC, C, dk),
                               rtol=1e-3, atol=1e-4, err_msg="K1b md")
    np.testing.assert_allclose(mv_planes["mv"].numpy(),
                               ref["mv"].reshape(B * H * NC, C, dv),
                               rtol=1e-3, atol=1e-4, err_msg="K1b mv")
    np.testing.assert_allclose(hc.numpy(), ref["hc"].reshape(hc.shape),
                               rtol=1e-3, atol=1e-4, err_msg="K2 hc")
    np.testing.assert_allclose(vt.numpy(), ref["vt"].reshape(vt.shape),
                               rtol=1e-3, atol=1e-4, err_msg="K2 vt")
    np.testing.assert_allclose(s1.numpy(), ref["s1"].reshape(s1.shape),
                               rtol=1e-3, atol=1e-4, err_msg="K2 s1")


# ---------------------------------------------------------------------------
# e2e matrix (cuda): GPU pipeline vs L2 (fp64) and L3 (fp32 sim)
# ---------------------------------------------------------------------------

def _e2e(q, k, v, xb, xd, s0, rtol=RTOL, atol=ATOL, check_l2=True):
    args = [tl.tensor(x, device="cuda") for x in (q, k, v, xb, xd)]
    s0t = tl.tensor(s0, device="cuda") if s0 is not None else None
    o_g, s_g = tl_ops.kda_forward(*args, initial_state=s0t,
                                  output_final_state=True)
    tl.synchronize()
    o_g, s_g = o_g.numpy(), s_g.numpy()
    assert np.all(np.isfinite(o_g)) and np.all(np.isfinite(s_g))
    o3, s3 = kda_kernel_sim(q, k, v, xb, xd, s0)
    np.testing.assert_allclose(o_g, o3, rtol=rtol, atol=atol, err_msg="o vs L3")
    np.testing.assert_allclose(s_g, s3, rtol=rtol, atol=atol, err_msg="S vs L3")
    if check_l2:
        kn, qn, vv, beta, loga = preprocess_np(q, k, v, xb, xd, np.float64)
        o2, s2 = _kda_chunk_np(kn, qn, vv, beta, loga, s0)
        np.testing.assert_allclose(o_g, o2, rtol=rtol, atol=atol,
                                   err_msg="o vs L2")
        np.testing.assert_allclose(s_g, s2, rtol=rtol, atol=atol,
                                   err_msg="S vs L2")


@pytest.mark.parametrize("T", [1, 63, 64, 65, 100, 1024, 2048])
@pytest.mark.parametrize("B,H", [(1, 1), (4, 4)])
@pytest.mark.parametrize("with_s0", [False, True])
def test_kda_e2e_64(T, B, H, with_s0):
    q, k, v, xb, xd, s0 = gen(B, H, T, 64, 64, seed=T + B * 10 + H,
                              with_s0=with_s0)
    _e2e(q, k, v, xb, xd, s0)


@pytest.mark.parametrize("T", [1, 64, 65, 1024])
@pytest.mark.parametrize("B,H", [(1, 1), (4, 4)])
@pytest.mark.parametrize("with_s0", [False, True])
def test_kda_e2e_128(T, B, H, with_s0):
    q, k, v, xb, xd, s0 = gen(B, H, T, 128, 128, seed=T + B * 10 + H + 1,
                              with_s0=with_s0)
    _e2e(q, k, v, xb, xd, s0)


@pytest.mark.parametrize("B,H", [(1, 4), (4, 1)])
@pytest.mark.parametrize("T", [63, 1024])
@pytest.mark.parametrize("with_s0", [False, True])
def test_kda_e2e_mixed_bh(T, B, H, with_s0):
    q, k, v, xb, xd, s0 = gen(B, H, T, 64, 64, seed=T + B + H * 7,
                              with_s0=with_s0)
    _e2e(q, k, v, xb, xd, s0)


# ---------------------------------------------------------------------------
# numerical boundary cases
# ---------------------------------------------------------------------------

def _edge_case(xb_val=None, xd_val=None, dead_channel=False,
               repeat_k=False, s0_scale=None, T=200, seed=11):
    q, k, v, xb, xd, s0 = gen(2, 2, T, 64, 64, seed=seed)
    if xb_val is not None:
        xb = np.full((2, 2, T), xb_val, dtype=np.float32)
    if xd_val is not None:
        xd = np.full((2, 2, T, 64), xd_val, dtype=np.float32)
    if dead_channel:
        xd = xd.copy()
        xd[:, :, :, 7] = -20.0                      # one channel dies
    if repeat_k:
        k = np.repeat(k[:, :, :1], T, axis=2)       # L ill-conditioned
    if s0_scale is not None:
        s0 = (s0_scale * np.ones((2, 2, 64, 64), dtype=np.float32))
    return q, k, v, xb, xd, s0


def test_edge_beta_hi():
    _e2e(*_edge_case(xb_val=4.6))                   # beta -> 0.99


def test_edge_beta_lo():
    _e2e(*_edge_case(xb_val=-4.6))                  # beta -> 0.01


def test_edge_loga_zero():
    _e2e(*_edge_case(xd_val=20.0))                  # log alpha -> 0 (no decay)


def test_edge_dead_channel():
    """One channel at log alpha ~ -20 (excursion ~1280 in that channel):
    the fp64 L2 oracle materializes w~ = beta*k/exp(g) -> inf (exactly the
    materialization the kernels avoid), so only finiteness +
    tight agreement with the L3 simulation (same shift/clip numerics) is
    asserted here. The bounded clip-zone residual vs the true math (~0.15
    in o, channel 'should be dead') is the documented clip behavior."""
    _e2e(*_edge_case(dead_channel=True), rtol=1e-3, atol=1e-4,
         check_l2=False)


def test_edge_repeat_k():
    _e2e(*_edge_case(repeat_k=True))


def test_edge_s0_large():
    _e2e(*_edge_case(s0_scale=100.0))


def test_edge_loga_neg20_clip_zone():
    """log alpha ~ -20: within-chunk excursion ~1280 >> 2*CL — the clip
    zone. Only finiteness + agreement with the L3 simulation (which
    replicates the clip); the unclipped fp64 oracle diverges by design
    (bounded 'should-be-dead' residuals)."""
    _e2e(*_edge_case(xd_val=-20.0), rtol=5e-2, atol=5e-2, check_l2=False)


def test_edge_strong_decay_clip_zone():
    """log alpha = -6 const: excursion ~384 > 2*CL — clip active."""
    _e2e(*_edge_case(xd_val=-6.0), rtol=5e-2, atol=5e-2, check_l2=False)


def test_edge_t1_s0():
    q, k, v, xb, xd, s0 = gen(1, 1, 1, 64, 64, seed=3, with_s0=True)
    _e2e(q, k, v, xb, xd, s0)
