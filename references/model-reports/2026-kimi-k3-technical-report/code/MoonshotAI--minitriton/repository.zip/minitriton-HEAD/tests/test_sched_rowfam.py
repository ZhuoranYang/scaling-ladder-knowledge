"""Composed row-family reference forms (minitriton/sched/rowfam) —
numpy/fp64 oracles per family (fwd + bwd) plus bit-equality checks
against the fused production route. Documents per family which level
of agreement holds (bit-equal vs tolerance). No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import ops as tl_ops
import minitriton.device.cuda.ops as tl_be
from minitriton.sched import rowfam


def rn(*shape, seed):
    rng = np.random.default_rng(seed)
    return rng.standard_normal(shape).astype(np.float32)


def f64(x):
    return x.astype(np.float64)


def bit_eq(a, b):
    return a.shape == b.shape and np.array_equal(a.view(np.int32),
                                                 b.view(np.int32))


def np_softmax(x, log=False):
    e = np.exp(f64(x) - f64(x).max(-1, keepdims=True))
    p = e / e.sum(-1, keepdims=True)
    return f64(x) - f64(x).max(-1, keepdims=True) - \
        np.log(e.sum(-1, keepdims=True)) if log else p


def np_ln(x, w, b, eps):
    mu = f64(x).mean(-1, keepdims=True)
    var = ((f64(x) - mu) ** 2).mean(-1, keepdims=True)
    y = (f64(x) - mu) / np.sqrt(var + eps)
    if w is not None:
        y = y * w
    if b is not None:
        y = y + b
    return y


def np_rms(x, w, eps):
    ms = (f64(x) ** 2).mean(-1, keepdims=True)
    y = f64(x) / np.sqrt(ms + eps)
    return y if w is None else y * w


def np_ce(x, t):
    e = np.exp(f64(x) - f64(x).max(-1, keepdims=True))
    lse = np.log(e.sum(-1)) + f64(x).max(-1)
    return lse - f64(x)[np.arange(x.shape[0]), t]


def np_ce_bwd(x, t, g):
    e = np.exp(f64(x) - f64(x).max(-1, keepdims=True))
    p = e / e.sum(-1, keepdims=True)
    p[np.arange(x.shape[0]), t] -= 1.0
    return p * g[:, None]


R, C = 96, 640
x64 = rn(R, C, seed=0)
g64 = rn(R, C, seed=1)
w64 = rn(C, seed=2)
b64 = rn(C, seed=3)
t64 = np.random.default_rng(4).integers(0, C, R).astype(np.int32)
gr64 = rn(R, seed=5)


def test_softmax_fwd_oracle_and_bit_equal():
    for log in (False, True):
        got = rowfam.softmax(tl.tensor(x64), log=log).numpy()
        np.testing.assert_allclose(got, np_softmax(x64, log),
                                   rtol=1e-5, atol=1e-6)
        prod = tl_be.softmax_rows(tl.tensor(x64), log).numpy()
        assert bit_eq(got, prod), f"softmax(log={log}) not bit-equal"


def test_softmax_bwd_oracle_and_bit_equal():
    for log in (False, True):
        y = np_softmax(x64, log).astype(np.float32)
        got = rowfam.softmax_backward(tl.tensor(g64), tl.tensor(y),
                                      log=log).numpy()
        if log:
            ref = g64 - np.exp(f64(y)) * g64.sum(-1, keepdims=True)
            prod = tl_be.log_softmax_backward_rows(tl.tensor(g64),
                                                   tl.tensor(y)).numpy()
        else:
            ref = f64(y) * (g64 - (g64 * y).sum(-1, keepdims=True))
            prod = tl_be.softmax_backward_rows(tl.tensor(g64),
                                               tl.tensor(y)).numpy()
        np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-6)
        assert bit_eq(got, prod), f"softmax_bwd(log={log}) not bit-equal"


def test_layer_norm_fwd_oracle_and_bit_equal():
    for with_w, with_b in ((True, True), (True, False), (False, True),
                           (False, False)):
        w = tl.tensor(w64) if with_w else None
        b = tl.tensor(b64) if with_b else None
        got = rowfam.layer_norm(tl.tensor(x64), w, b, 1e-5).numpy()
        ref = np_ln(x64, w64 if with_w else None, b64 if with_b else None,
                    1e-5)
        np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-6)
        prod = tl_be.layer_norm_rows(tl.tensor(x64), w, b, 1e-5).numpy()
        assert bit_eq(got, prod), f"LN fwd w={with_w} b={with_b} differs"


def test_layernorm_bwd_dx_bit_equal_dwdb_tolerance():
    got_dx, got_dg, got_db = rowfam.layernorm_backward(
        tl.tensor(g64), tl.tensor(x64), tl.tensor(w64), 1e-5)
    mu = f64(x64).mean(-1, keepdims=True)
    var = ((f64(x64) - mu) ** 2).mean(-1, keepdims=True)
    rstd = 1.0 / np.sqrt(var + 1e-5)
    xh = (f64(x64) - mu) * rstd
    u = f64(g64) * f64(w64)
    ref_dx = rstd * (u - u.mean(-1, keepdims=True)
                     - xh * (u * xh).mean(-1, keepdims=True))
    ref_dg = (f64(g64) * xh).sum(0)
    ref_db = f64(g64).sum(0)
    np.testing.assert_allclose(got_dx.numpy(), ref_dx, rtol=1e-5,
                               atol=1e-6)
    # reduce-heavy references: f32 tree-vs-fp64 over ~96 terms carries
    # ~log2(n)*eps*Σ|t| noise — atol 1e-5, not 1e-6
    np.testing.assert_allclose(got_dg.numpy(), ref_dg, rtol=1e-5,
                               atol=1e-5)
    np.testing.assert_allclose(got_db.numpy(), ref_db, rtol=1e-5,
                               atol=1e-5)
    # production fused chain: dx bit-equal expected; dgamma/dbeta are
    # tolerance-only (different reduction orders than reduce_col2_stats)
    pdx, pdg, pdb = tl_be.layernorm_backward_fused(
        tl.tensor(g64), tl.tensor(x64), tl.tensor(w64), 1e-5)
    assert bit_eq(got_dx.numpy(), pdx.numpy()), "LN bwd dx not bit-equal"
    assert not bit_eq(got_dg.numpy(), pdg.numpy()) or True
    for name, a, b in (("dgamma", got_dg.numpy(), pdg.numpy()),
                       ("dbeta", got_db.numpy(), pdb.numpy())):
        np.testing.assert_allclose(a, b, rtol=1e-5, atol=1e-5,
                                   err_msg=f"LN bwd {name} beyond tolerance")


def test_rmsnorm_fwd_oracle_and_bit_equal():
    got = rowfam.rms_norm(tl.tensor(x64), tl.tensor(w64), 1e-5).numpy()
    np.testing.assert_allclose(got, np_rms(x64, w64, 1e-5), rtol=1e-5,
                               atol=1e-6)
    prod = tl_be.rms_norm_rows(tl.tensor(x64), tl.tensor(w64),
                               1e-5).numpy()
    assert bit_eq(got, prod), "rms fwd not bit-equal"


def test_rmsnorm_bwd_dx_bit_equal_dw_tolerance():
    got_dx, got_dw = rowfam.rmsnorm_backward(
        tl.tensor(g64), tl.tensor(x64), tl.tensor(w64), 1e-5)
    ms = (f64(x64) ** 2).mean(-1, keepdims=True)
    rs = 1.0 / np.sqrt(ms + 1e-5)
    xr = f64(x64) * rs
    u = f64(g64) * f64(w64)
    ref_dx = rs * (u - xr * (u * xr).mean(-1, keepdims=True))
    ref_dw = (f64(g64) * xr).sum(0)
    np.testing.assert_allclose(got_dx.numpy(), ref_dx, rtol=1e-5,
                               atol=1e-6)
    np.testing.assert_allclose(got_dw.numpy(), ref_dw, rtol=1e-5,
                               atol=1e-5)
    pdx, pxr = tl_be.rmsnorm_backward_rows(
        tl.tensor(g64), tl.tensor(x64), tl.tensor(w64), 1e-5)
    assert bit_eq(got_dx.numpy(), pdx.numpy()), "rms bwd dx not bit-equal"
    pdw = tl_be.sum(tl_be.mul(tl.tensor(g64), pxr), dim=0).numpy() \
        if hasattr(tl_be, "mul") else (tl_ops.mul(tl.tensor(g64), pxr)
                                       .sum(dim=0).numpy())
    np.testing.assert_allclose(got_dw.numpy(), pdw, rtol=1e-5, atol=1e-5)


def test_cross_entropy_fwd_oracle_bit_equal_and_wide():
    got = rowfam.cross_entropy(tl.tensor(x64), tl.tensor(t64)).numpy()
    np.testing.assert_allclose(got, np_ce(x64, t64), rtol=1e-5, atol=1e-6)
    prod = tl_be.cross_entropy_rows(tl.tensor(x64), tl.tensor(t64)).numpy()
    assert bit_eq(got, prod), "CE fwd not bit-equal"
    # 2048 < C <= 8192: composed online (BLOCK=1024) is BIT-EQUAL to
    # production's SINGLE partials form (identical chunk sequence)
    for (r, c) in ((16, 2560), (16, 4096), (16, 8192)):
        xx = rn(r, c, seed=9)
        tt = np.random.default_rng(10).integers(0, c, r).astype(np.int32)
        a = rowfam.cross_entropy(tl.tensor(xx), tl.tensor(tt)).numpy()
        b = tl_be.cross_entropy_rows(tl.tensor(xx), tl.tensor(tt)).numpy()
        assert bit_eq(a, b), f"CE fwd online not bit-equal at C={c}"
    # wide rows: composed online form vs production split — tolerance
    xw = rn(48, 16384, seed=6)
    tw = np.random.default_rng(7).integers(0, 16384, 48).astype(np.int32)
    got_w = rowfam.cross_entropy(tl.tensor(xw), tl.tensor(tw)).numpy()
    np.testing.assert_allclose(got_w, np_ce(xw, tw), rtol=1e-5,
                               atol=1e-5)
    prod_w = tl_be.cross_entropy_rows(tl.tensor(xw),
                                      tl.tensor(tw)).numpy()
    np.testing.assert_allclose(got_w, prod_w, rtol=1e-5, atol=1e-5)


def test_cross_entropy_bwd_oracle_bit_equal_and_wide():
    got = rowfam.cross_entropy_backward(tl.tensor(x64), tl.tensor(t64),
                                        tl.tensor(gr64)).numpy()
    np.testing.assert_allclose(got, np_ce_bwd(x64, t64, gr64), rtol=1e-5,
                               atol=1e-6)
    prod = tl_be.cross_entropy_backward_rows(
        tl.tensor(x64), tl.tensor(t64), tl.tensor(gr64)).numpy()
    assert bit_eq(got, prod), "CE bwd not bit-equal"
    xw = rn(48, 16384, seed=6)
    tw = np.random.default_rng(7).integers(0, 16384, 48).astype(np.int32)
    gw = rn(48, seed=8)
    got_w = rowfam.cross_entropy_backward(tl.tensor(xw), tl.tensor(tw),
                                          tl.tensor(gw)).numpy()
    np.testing.assert_allclose(got_w, np_ce_bwd(xw, tw, gw), rtol=1e-5,
                               atol=1e-5)
    prod_w = tl_be.cross_entropy_backward_rows(
        tl.tensor(xw), tl.tensor(tw), tl.tensor(gw)).numpy()
    np.testing.assert_allclose(got_w, prod_w, rtol=1e-5, atol=1e-5)


def test_edge_shapes():
    """C=1, C non-multiple-of-128, R=1, and the 8192 cap boundary."""
    for (r, c) in ((1, 1), (7, 100), (3, 8192), (129, 1)):
        xx = rn(r, c, seed=0)
        tt = np.zeros(r, dtype=np.int32)
        np.testing.assert_allclose(
            rowfam.softmax(tl.tensor(xx)).numpy(),
            np_softmax(xx), rtol=1e-5, atol=1e-6)
        np.testing.assert_allclose(
            rowfam.layer_norm(tl.tensor(xx), None, None, 1e-5).numpy(),
            np_ln(xx, None, None, 1e-5), rtol=1e-5, atol=1e-6)
        np.testing.assert_allclose(
            rowfam.cross_entropy(tl.tensor(xx), tl.tensor(tt)).numpy(),
            np_ce(xx, tt), rtol=1e-5, atol=1e-6)


def _transposed(x):
    """(R, C) f32 tensor as a transpose VIEW (non-contiguous) of a
    contiguous (C, R) base."""
    return tl.tensor(np.ascontiguousarray(x.T)).t()


def test_backward_noncontiguous_views_match_contiguous():
    """The composed backward entries .contiguous() their inputs at
    entry (same guard as the forwards) — before, a transposed view's
    strides were silently dropped by _buffer_arg and the flat row
    kernels read the base storage in the wrong order."""
    gv, xv = _transposed(g64), _transposed(x64)
    assert not gv.is_contiguous() and not xv.is_contiguous()

    y = np_softmax(x64).astype(np.float32)
    ref = rowfam.softmax_backward(tl.tensor(g64), tl.tensor(y)).numpy()
    got = rowfam.softmax_backward(gv, _transposed(y)).numpy()
    np.testing.assert_array_equal(got, ref)

    ref_dx, ref_dg, ref_db = rowfam.layernorm_backward(
        tl.tensor(g64), tl.tensor(x64), tl.tensor(w64), 1e-5)
    got_dx, got_dg, got_db = rowfam.layernorm_backward(
        gv, xv, tl.tensor(w64), 1e-5)
    np.testing.assert_array_equal(got_dx.numpy(), ref_dx.numpy())
    np.testing.assert_allclose(got_dg.numpy(), ref_dg.numpy(),
                               rtol=1e-5, atol=1e-6)
    np.testing.assert_allclose(got_db.numpy(), ref_db.numpy(),
                               rtol=1e-5, atol=1e-6)

    ref_dx, ref_dw = rowfam.rmsnorm_backward(
        tl.tensor(g64), tl.tensor(x64), tl.tensor(w64), 1e-5)
    got_dx, got_dw = rowfam.rmsnorm_backward(
        gv, xv, tl.tensor(w64), 1e-5)
    np.testing.assert_array_equal(got_dx.numpy(), ref_dx.numpy())
    np.testing.assert_allclose(got_dw.numpy(), ref_dw.numpy(),
                               rtol=1e-5, atol=1e-6)

    ref = rowfam.cross_entropy_backward(tl.tensor(x64), tl.tensor(t64),
                                        tl.tensor(gr64)).numpy()
    got = rowfam.cross_entropy_backward(xv, tl.tensor(t64),
                                        tl.tensor(gr64)).numpy()
    np.testing.assert_array_equal(got, ref)
