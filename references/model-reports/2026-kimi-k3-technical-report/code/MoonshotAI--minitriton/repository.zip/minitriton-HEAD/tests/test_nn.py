"""nn package tests: Module/Parameter machinery, layers, fused
AdamW, clip_grad_norm, causal attention (fused flash on cuda vs unfused
composition; unfused everywhere vs numpy). No torch."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import nn

DEVS = pytest.mark.parametrize("dev", ["cpu", "cuda"])

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


def T(x, dev, requires_grad=False):
    return tl.tensor(np.ascontiguousarray(x), device=dev,
                     requires_grad=requires_grad)


def close(out, ref, rtol=1e-5, atol=1e-6):
    arr = out.numpy() if isinstance(out, tl.Tensor) else out
    ref = ref.numpy() if isinstance(ref, tl.Tensor) else np.asarray(ref)
    assert arr.shape == ref.shape, f"shape {arr.shape} != ref {ref.shape}"
    np.testing.assert_allclose(arr, ref, rtol=rtol, atol=atol)


# ---------------------------------------------------------------------------
# Module / Parameter machinery
# ---------------------------------------------------------------------------

def test_parameter_registration_and_dedup():
    lin = nn.Linear(4, 3)
    names = [n for n, _ in _named(lin)]
    assert set(names) == {"weight", "bias"}
    # tied weights appear once
    class Tied(nn.Module):
        def __init__(self):
            super().__init__()
            self.emb = nn.Embedding(5, 4)
            self.head = nn.Linear(4, 5, bias=False)
            self.head.weight = self.emb.weight  # re-register same Parameter
    m = Tied()
    assert len(list(m.parameters())) == 1


def _named(mod, prefix=""):
    for name, p in mod._parameters.items():
        yield prefix + name, p
    for name, m in mod._modules.items():
        yield from _named(m, prefix + name + ".")


def test_zero_grad():
    lin = nn.Linear(4, 3, device="cpu")
    x = T(rn(2, 4), "cpu")
    lin(x).sum().backward()
    assert lin.weight.grad is not None
    lin.zero_grad()
    assert lin.weight.grad is None


# ---------------------------------------------------------------------------
# layers
# ---------------------------------------------------------------------------

@DEVS
def test_linear_fwdbwd(dev):
    lin = nn.Linear(6, 3, device=dev, seed=0)
    x, g = rn(2, 6), rn(2, 3)
    tx = T(x, dev, True)
    out = lin(tx)
    out.backward(T(g, dev))
    w, b = lin.weight.numpy(), lin.bias.numpy()
    close(out, x @ w.T + b, rtol=1e-5)
    close(tx.grad, g @ w, rtol=1e-4, atol=1e-5)
    close(lin.weight.grad, g.T @ x, rtol=1e-4, atol=1e-5)
    close(lin.bias.grad, g.sum(0), rtol=1e-4, atol=1e-5)


@DEVS
def test_embedding_module(dev):
    emb = nn.Embedding(10, 4, device=dev, seed=0)
    idx = T(np.array([1, 2, 2, 5], dtype=np.int64), dev)
    g = rn(4, 4)
    out = emb(idx)
    out.backward(T(g, dev))
    close(out, emb.weight.numpy()[idx.numpy()])
    ref = np.zeros((10, 4), dtype=np.float32)
    np.add.at(ref, idx.numpy(), g)
    close(emb.weight.grad, ref, rtol=1e-5)


@DEVS
def test_layernorm_module(dev):
    ln = nn.LayerNorm(8, device=dev)
    x, g = rn(4, 8), rn(4, 8)
    tx = T(x, dev, True)
    ln(tx).backward(T(g, dev))
    mu, var = x.mean(1, keepdims=True), x.var(1, keepdims=True)
    rstd = 1.0 / np.sqrt(var + 1e-5)
    xh = (x - mu) * rstd
    close(tx.grad, rstd * (g - g.mean(1, keepdims=True)
                           - xh * (g * xh).mean(1, keepdims=True)),
          rtol=1e-4, atol=1e-5)


def _bf16rnd(x: np.ndarray) -> np.ndarray:
    """Host bf16 round-to-nearest-even (no numpy bf16)."""
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    lsb = (b >> np.uint32(16)) & np.uint32(1)
    b = b + np.uint32(0x7FFF) + lsb
    return (b & np.uint32(0xFFFF0000)).view(np.float32)


@DEVS
def test_layernorm_out_dtype(dev):
    """layer_norm(out_dtype=bf16): f32 compute, bf16 pack on store. The
    forward must equal the f32 LN output rounded to bf16 (the producer
    seam that replaces a materialized astype); the backward chain gets
    the upstream grad in x's dtype as before."""
    if dev != "cuda":
        pytest.skip("bf16 has no numpy dtype (CUDA-only producer seam)")
    ln = nn.LayerNorm(8, device=dev)
    x, g = rn(4, 8), rn(4, 8)
    tx = T(x, dev, True)
    out = ln(tx, out_dtype=tl.bfloat16)
    assert out.dtype == tl.bfloat16
    mu, var = x.mean(1, keepdims=True), x.var(1, keepdims=True)
    xh = (x - mu) / np.sqrt(var + 1e-5)
    y_ref = xh * ln.weight.numpy() + ln.bias.numpy()
    np.testing.assert_allclose(out.numpy(), _bf16rnd(y_ref),
                               rtol=2e-2, atol=1e-3)
    out.backward(T(g, dev))
    rstd = 1.0 / np.sqrt(var + 1e-5)
    # g arrives as f32; identical to the fp32-mode backward values
    close(tx.grad, rstd * (g - g.mean(1, keepdims=True)
                           - xh * (g * xh).mean(1, keepdims=True)),
          rtol=1e-4, atol=1e-5)


@DEVS
def test_cross_entropy_loss_module(dev):
    """nn.CrossEntropyLoss fwd+bwd vs numpy at a real vocab width (50257,
    GPT-2 scale): on cuda this exercises the split-reduction CE path, and
    peak memory stays at the x + dx scale (no materialized softmax)."""
    R, V = 128, 50257
    x, t = rn(R, V), rng.integers(0, V, R).astype(np.int64)
    ce = nn.CrossEntropyLoss()
    tx = T(x, dev, True)
    tl.reset_peak_stats()
    loss = ce(tx, T(t, dev))
    loss.backward()
    z = x - x.max(1, keepdims=True)
    nll = np.log(np.exp(z).sum(1)) + x.max(1) - x[np.arange(R), t]
    close(loss, nll.mean(), rtol=1e-4)
    p = np.exp(z) / np.exp(z).sum(1, keepdims=True)
    p[np.arange(R), t] -= 1.0
    close(tx.grad, p / R, rtol=1e-4, atol=1e-6)
    if dev == "cuda":
        peak = tl.memory_stats()["peak_allocated_bytes"]
        assert peak < 4 * x.nbytes, f"peak {peak / 2**20:.0f} MiB"


# ---------------------------------------------------------------------------
# AdamW / clip_grad_norm
# ---------------------------------------------------------------------------

@DEVS
def test_adamw_matches_reference(dev):
    p0 = rn(4, 5)
    tp = nn.Parameter(p0, device=dev)
    opt = nn.AdamW([tp], lr=0.05, betas=(0.9, 0.95), eps=1e-8,
                   weight_decay=0.1)
    m_ref = np.zeros_like(p0)
    v_ref = np.zeros_like(p0)
    p_ref = p0.copy()
    from minitriton import precision as _prec
    torch_eps = _prec.adamw_eps()  # default: torch-exact eps placement
    for t in range(1, 4):
        g = rn(4, 5)
        tp.grad = T(g, dev)
        opt.step()
        m_ref = 0.9 * m_ref + 0.1 * g
        v_ref = 0.95 * v_ref + 0.05 * g * g
        if torch_eps:
            lr_t = 0.05 / (1 - 0.9**t)
            denom = np.sqrt(v_ref) / np.sqrt(1 - 0.95**t) + 1e-8
        else:
            lr_t = 0.05 * np.sqrt(1 - 0.95**t) / (1 - 0.9**t)
            denom = np.sqrt(v_ref) + 1e-8
        p_ref = p_ref - 0.05 * 0.1 * p_ref - lr_t * m_ref / denom
        close(tp, p_ref, rtol=1e-5, atol=1e-6)


@DEVS
def test_clip_grad_norm(dev):
    p1 = nn.Parameter(rn(3, 3), device=dev)
    p2 = nn.Parameter(rn(5), device=dev)
    p1.grad = T(np.full((3, 3), 2.0, dtype=np.float32), dev)
    p2.grad = T(np.full((5,), -1.0, dtype=np.float32), dev)
    total = nn.clip_grad_norm([p1, p2], max_norm=1.0)
    assert abs(total - np.sqrt(36 + 5)) < 1e-5
    norms = np.sqrt((p1.grad.numpy()**2).sum() + (p2.grad.numpy()**2).sum())
    assert norms <= 1.0 + 1e-4


# ---------------------------------------------------------------------------
# causal attention
# ---------------------------------------------------------------------------

def _np_attention(q, k, v, scale):
    t = q.shape[-2]
    s = q @ k.transpose(0, 1, 3, 2) * scale
    s = s + np.triu(np.full((t, t), -1e9, dtype=np.float32), k=1)
    e = np.exp(s - s.max(-1, keepdims=True))
    return (e / e.sum(-1, keepdims=True)) @ v


@DEVS
def test_unfused_attention_vs_numpy(dev):
    q, k, v = rn(2, 3, 33, 8), rn(2, 3, 33, 8), rn(2, 3, 33, 8)
    scale = 1.0 / np.sqrt(8)
    out = nn.attention.unfused_causal_attention(
        T(q, dev), T(k, dev), T(v, dev), scale)
    close(out, _np_attention(q, k, v, scale), rtol=1e-4, atol=1e-4)


@pytest.mark.parametrize("B,H,Tt", [(1, 1, 64), (2, 3, 128), (2, 4, 200),
                                    (1, 2, 512)])
def test_flash_attention_cuda(B, H, Tt):
    """Fused flash fwd vs numpy; backward vs the unfused tape path."""
    hd = 64
    q, k, v = rn(B, H, Tt, hd), rn(B, H, Tt, hd), rn(B, H, Tt, hd)
    g = rn(B, H, Tt, hd)
    scale = 1.0 / np.sqrt(hd)
    tq, tk, tv = T(q, "cuda", True), T(k, "cuda", True), T(v, "cuda", True)
    out = nn.causal_attention(tq, tk, tv, scale=scale, fused=True)
    close(out, _np_attention(q, k, v, scale), rtol=1e-3, atol=1e-4)
    out.backward(T(g, "cuda"))
    uq, uk, uv = T(q, "cuda", True), T(k, "cuda", True), T(v, "cuda", True)
    out2 = nn.attention.unfused_causal_attention(uq, uk, uv, scale)
    out2.backward(T(g, "cuda"))
    for name, a, b in (("dq", tq.grad, uq.grad), ("dk", tk.grad, uk.grad),
                       ("dv", tv.grad, uv.grad)):
        close(a, b, rtol=1e-3, atol=1e-3)


def test_flash_vs_unfused_forward_only():
    """no_grad inference path: fused and unfused agree."""
    q, k, v = rn(1, 2, 100, 64), rn(1, 2, 100, 64), rn(1, 2, 100, 64)
    scale = 0.125
    with tl.no_grad():
        a = nn.causal_attention(T(q, "cuda"), T(k, "cuda"), T(v, "cuda"),
                                scale=scale, fused=True)
        b = nn.causal_attention(T(q, "cuda"), T(k, "cuda"), T(v, "cuda"),
                                scale=scale, fused=False)
    close(a, b, rtol=1e-3, atol=1e-4)


# ---------------------------------------------------------------------------
# mini GPT block e2e
# ---------------------------------------------------------------------------

@DEVS
def test_gpt_block_step(dev):
    """One LN->attn->LN->MLP block: forward finite, backward nonzero grads."""
    d, h = 32, 4
    ln1, attn = nn.LayerNorm(d, device=dev), \
        nn.CausalSelfAttention(d, h, fused=(dev == "cuda"), device=dev,
                               seed=0)
    ln2 = nn.LayerNorm(d, device=dev)
    w1, w2 = nn.Linear(d, 4 * d, device=dev, seed=1), \
        nn.Linear(4 * d, d, device=dev, seed=2)
    mods = [ln1, attn, ln2, w1, w2]
    x = T(rn(2, 8, d), dev, True)
    h1 = x + attn(ln1(x))
    h2 = h1 + w2(tl.gelu(w1(ln2(h1))))
    loss = (h2 * h2).mean()
    loss.backward()
    assert np.isfinite(loss.item())
    assert x.grad is not None and np.isfinite(x.grad.numpy()).all()
    n_checked = 0
    for m in mods:
        for p in m.parameters():
            assert p.grad is not None, f"missing grad for {p.shape}"
            gn = p.grad.numpy()
            assert np.isfinite(gn).all() and np.abs(gn).max() > 0
            n_checked += 1
    assert n_checked > 0


@DEVS
def test_module_list_submodules_register(dev):
    """A bare list of submodules registers its elements (parameters()
    walks them — regression for swallowed list-submodule params)."""
    class Net(nn.Module):
        def __init__(self):
            super().__init__()
            self.linears = [nn.Linear(4, 4, device=dev),
                            nn.Linear(4, 4, device=dev)]
    m = Net()
    params = list(m.parameters())
    assert len(params) == 4  # 2 x (weight + bias), not 0


@DEVS
def test_same_named_parameter_in_parent_and_child(dev):
    """Assigning a Parameter named `weight` to the parent must NOT
    deregister a submodule's own `weight` (pop by identity, not name);
    same object re-registered upward is de-duplicated."""
    class Net(nn.Module):
        def __init__(self):
            super().__init__()
            self.lin = nn.Linear(4, 4, device=dev)
    m = Net()
    m.weight = nn.Parameter(rn(4, 4), device=dev)
    params = list(m.parameters())
    # parent's weight AND lin.weight/bias all present (child's not popped)
    assert len(params) == 3
    # identity move: re-register the child's weight on the parent — the
    # child's stale entry is removed, no double counting either way
    m.weight2 = m.lin.weight
    assert len(list(m.parameters())) == 3
    assert m.lin.weight is m.weight2


def test_attention_seeded_projections_are_independent():
    """CausalSelfAttention(seed=s) must not give c_attn and c_proj the
    same stream: Parameter.normal re-seeds per call, so seed=s twice
    made c_proj.weight an exact prefix copy of c_attn.weight."""
    a = nn.CausalSelfAttention(8, 2, fused=False, device="cpu", seed=42)
    wa = a.c_attn.weight.numpy()
    wp = a.c_proj.weight.numpy()
    assert not np.array_equal(wa[:8], wp)
    # determinism kept: same seed, same weights
    b = nn.CausalSelfAttention(8, 2, fused=False, device="cpu", seed=42)
    assert np.array_equal(b.c_attn.weight.numpy(), wa)
    assert np.array_equal(b.c_proj.weight.numpy(), wp)
