"""qkv-packed strided flash attention (bf16): the (B, T, 3C) / (B, T, C)
layout kernels must reproduce the contiguous (B, H, T, hd) path
bit-for-bit (same builder entries, only address algebra differs) and
match the fp64 numpy backward reference within bf16 tolerance. Also
covers the nn.CausalSelfAttention fused routing. No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import nn, ops as tl_ops

from test_flash_mma import bf16_round, rn
from test_flash_bwd_bf16 import np_attention_bwd


def _pack(q, k, v):
    """(B, H, T, hd) x3 -> (B, T, 3C) packed."""
    B, H, T, hd = q.shape
    C = H * hd
    out = np.zeros((B, T, 3 * C), dtype=q.dtype)
    out[:, :, 0 * C:1 * C] = q.transpose(0, 2, 1, 3).reshape(B, T, C)
    out[:, :, 1 * C:2 * C] = k.transpose(0, 2, 1, 3).reshape(B, T, C)
    out[:, :, 2 * C:3 * C] = v.transpose(0, 2, 1, 3).reshape(B, T, C)
    return out


@pytest.mark.parametrize("B,H,T", [(2, 4, 128), (4, 10, 128), (2, 4, 96),
                                   (1, 2, 64)])
def test_flash_qkv_bit_equal(B, H, T):
    hd = 64
    q, k, v, g = (bf16_round(rn(B, H, T, hd, seed=s)) for s in (0, 1, 2, 3))
    scale = 1.0 / np.sqrt(hd)
    qkv_np = _pack(q, k, v)
    qkv = tl.tensor(qkv_np).astype(tl.bfloat16)
    out, lse = tl_ops.flash_attention_forward_qkv(qkv, H, scale, "bf16")
    tq, tk, tv = (tl.tensor(x).astype(tl.bfloat16) for x in (q, k, v))
    out2, lse2 = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                                with_lse=True,
                                                precision="bf16")
    o_ref = out2.transpose(1, 2).reshape((B, T, H * hd)).numpy()
    assert np.array_equal(out.numpy(), o_ref)
    assert np.array_equal(lse.numpy(), lse2.numpy().reshape(-1, T))
    tg = tl.tensor(g).astype(tl.bfloat16)
    g_packed = tl.tensor(g.transpose(0, 2, 1, 3)
                         .reshape((B, T, H * hd))).astype(tl.bfloat16)
    dqkv = tl_ops.flash_attention_backward_qkv(qkv, out, g_packed, lse,
                                               H, scale, "bf16")
    dq, dk, dv = tl_ops.flash_attention_backward(tq, tk, tv, out2, tg,
                                                 lse2, scale,
                                                 precision="bf16")
    C = H * hd
    dqkv4 = dqkv.numpy().reshape((B, T, 3, H, hd))
    assert np.array_equal(dqkv4[:, :, 0], dq.transpose(1, 2).reshape((B, T, H, hd)).numpy())
    assert np.array_equal(dqkv4[:, :, 1], dk.transpose(1, 2).reshape((B, T, H, hd)).numpy())
    assert np.array_equal(dqkv4[:, :, 2], dv.transpose(1, 2).reshape((B, T, H, hd)).numpy())


def test_flash_qkv_numpy_ref():
    """fp64 numpy reference on the exact bf16 operand values (bf16
    tolerance), the tests/ oracle discipline."""
    B, H, T, hd = 2, 4, 128, 64
    q, k, v, g = (bf16_round(rn(B, H, T, hd, seed=s)) for s in (4, 5, 6, 7))
    scale = 1.0 / np.sqrt(hd)
    qkv = tl.tensor(_pack(q, k, v)).astype(tl.bfloat16)
    out, lse = tl_ops.flash_attention_forward_qkv(qkv, H, scale, "bf16")
    g_packed = tl.tensor(g.transpose(0, 2, 1, 3)
                         .reshape((B, T, H * hd))).astype(tl.bfloat16)
    dqkv = tl_ops.flash_attention_backward_qkv(qkv, out, g_packed, lse,
                                               H, scale, "bf16")
    rdq, rdk, rdv, ro = np_attention_bwd(q, k, v, g, scale)
    C = H * hd
    o = out.numpy().reshape((B, T, H, hd)).transpose(0, 2, 1, 3)
    dqkv5 = dqkv.numpy().reshape((B, T, 3, H, hd))
    assert np.allclose(o, ro, rtol=2e-2, atol=1e-2)
    assert np.allclose(dqkv5[:, :, 0].transpose(0, 2, 1, 3), rdq,
                       rtol=2e-2, atol=1e-2)
    assert np.allclose(dqkv5[:, :, 1].transpose(0, 2, 1, 3), rdk,
                       rtol=2e-2, atol=1e-2)
    assert np.allclose(dqkv5[:, :, 2].transpose(0, 2, 1, 3), rdv,
                       rtol=2e-2, atol=1e-2)


def test_causal_attention_module_qkv_route():
    """nn.CausalSelfAttention bf16 takes the qkv-packed node; the forward
    matches the unfused numpy composition on the module's own projection,
    and the backward reaches the qkv projection's weight."""
    from minitriton.nn.attention import unfused_causal_attention
    B, T, C, H = 2, 128, 256, 4
    attn = nn.CausalSelfAttention(C, H, precision="bf16", seed=3)
    with tl.no_grad():
        for p in attn.parameters():
            p._steal(p.astype(tl.bfloat16))
            p.requires_grad = True
    x = tl.tensor(rn(B, T, C, seed=11)).astype(tl.bfloat16)
    x.requires_grad = True
    y = attn(x)
    # reference: same projection through the unfused composition
    qkv = attn.c_attn(x)
    q, k, v = tl_ops.split(qkv, C, dim=-1)

    def heads(u):
        return u.reshape(B, T, H, C // H).transpose(1, 2)
    y_ref = unfused_causal_attention(heads(q), heads(k), heads(v),
                                     1.0 / np.sqrt(C // H))
    y_ref = y_ref.transpose(1, 2).reshape(B, T, C)
    y_ref = attn.c_proj(y_ref)
    assert np.allclose(y.numpy(), y_ref.numpy(), rtol=2e-2, atol=1e-2)
    g = tl.tensor(rn(B, T, C, seed=12))
    y.backward(g)
    assert attn.c_attn.weight.grad is not None
    assert np.isfinite(attn.c_attn.weight.grad.numpy()).all()
    assert x.grad is not None and np.isfinite(x.grad.numpy()).all()


@pytest.mark.parametrize("B,H,T", [(2, 4, 128), (4, 10, 128), (2, 4, 96)])
def test_flash_qkv_fp32_bit_equal(B, H, T):
    """fp32 qkv-packed flash (exact-FMA kernels): bit-identical to the
    contiguous fp32 path (same builder entries, address algebra only)."""
    hd = 64
    rng = np.random.default_rng(0)
    q, k, v, g = (rng.standard_normal((B, H, T, hd)).astype(np.float32)
                  for _ in range(4))
    scale = 1.0 / np.sqrt(hd)
    qkv_np = _pack(q, k, v)
    qkv = tl.tensor(qkv_np)
    out, lse = tl_ops.flash_attention_forward_qkv(qkv, H, scale, "fp32")
    tq, tk, tv = tl.tensor(q), tl.tensor(k), tl.tensor(v)
    out2, lse2 = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                                with_lse=True,
                                                precision="fp32")
    assert np.array_equal(
        out.numpy(), out2.transpose(1, 2).reshape((B, T, H * hd)).numpy())
    assert np.array_equal(lse.numpy(), lse2.numpy().reshape(-1, T))
    g_packed = tl.tensor(g.transpose(0, 2, 1, 3)
                         .reshape((B, T, H * hd)))
    dqkv = tl_ops.flash_attention_backward_qkv(qkv, out, g_packed, lse,
                                               H, scale, "fp32")
    tg = tl.tensor(g)
    dq, dk, dv = tl_ops.flash_attention_backward(tq, tk, tv, out2, tg,
                                                 lse2, scale,
                                                 precision="fp32")
    dqkv4 = dqkv.numpy().reshape((B, T, 3, H, hd))
    assert np.array_equal(dqkv4[:, :, 0],
                          dq.transpose(1, 2).reshape((B, T, H, hd)).numpy())
    assert np.array_equal(dqkv4[:, :, 1],
                          dk.transpose(1, 2).reshape((B, T, H, hd)).numpy())
    assert np.array_equal(dqkv4[:, :, 2],
                          dv.transpose(1, 2).reshape((B, T, H, hd)).numpy())


def test_flash_qkv_attn_bwd_f32_lever(monkeypatch):
    """MT_ATTN_BWD_F32 must reroute the qkv-packed bf16 backward to the
    fused f32 kernels on f32 upcasts — it used to cover only the
    contiguous FlashAttentionFn path, a silent no-op on this one.
    Route proof: dqkv is bit-equal to running the fp32 qkv backward on
    f32 upcasts by hand and casting back."""
    from minitriton import precision as _prec
    from minitriton.nn.attention import FlashAttentionQkvFn
    monkeypatch.setattr(_prec, "_ATTN_BWD_F32", True)
    B, H, T, hd = 2, 4, 128, 64
    q, k, v, g = (bf16_round(rn(B, H, T, hd, seed=s))
                  for s in (20, 21, 22, 23))
    scale = 1.0 / np.sqrt(hd)
    C = H * hd
    qkv = tl.tensor(_pack(q, k, v)).astype(tl.bfloat16)
    qkv.requires_grad = True
    out = FlashAttentionQkvFn.apply(qkv, H, scale, "bf16")
    g_packed = tl.tensor(g.transpose(0, 2, 1, 3)
                         .reshape((B, T, C))).astype(tl.bfloat16)
    out.backward(g_packed)
    got = qkv.grad
    assert got is not None and got.dtype == tl.bfloat16
    # manual f32 route on the same (deterministic) forward artifacts
    out2, lse = tl_ops.flash_attention_forward_qkv(qkv, H, scale, "bf16")
    want = tl_ops.flash_attention_backward_qkv(
        qkv.astype(tl.float32), out2.astype(tl.float32),
        g_packed.astype(tl.float32), lse, H, scale, "fp32")
    want = want.astype(tl.bfloat16)
    assert np.array_equal(got.numpy(), want.numpy())
    assert np.isfinite(got.numpy()).all()


def test_flash_qkv_fp32_numpy_ref():
    """fp32 qkv backward vs the fp64 numpy reference (rtol 1e-4 — the
    exact-FMA tier's discipline)."""
    B, H, T, hd = 2, 4, 128, 64
    rng = np.random.default_rng(4)
    q, k, v, g = (rng.standard_normal((B, H, T, hd)).astype(np.float32)
                  for _ in range(4))
    scale = 1.0 / np.sqrt(hd)
    qkv = tl.tensor(_pack(q, k, v))
    out, lse = tl_ops.flash_attention_forward_qkv(qkv, H, scale, "fp32")
    g_packed = tl.tensor(g.transpose(0, 2, 1, 3).reshape((B, T, H * hd)))
    dqkv = tl_ops.flash_attention_backward_qkv(qkv, out, g_packed, lse,
                                               H, scale, "fp32")
    rdq, rdk, rdv, ro = np_attention_bwd(q, k, v, g, scale)
    o = out.numpy().reshape((B, T, H, hd)).transpose(0, 2, 1, 3)
    d5 = dqkv.numpy().reshape((B, T, 3, H, hd))
    assert np.allclose(o, ro, rtol=1e-4, atol=1e-3)
    assert np.allclose(d5[:, :, 0].transpose(0, 2, 1, 3), rdq,
                       rtol=1e-4, atol=1e-3)
    assert np.allclose(d5[:, :, 1].transpose(0, 2, 1, 3), rdk,
                       rtol=1e-4, atol=1e-3)
    assert np.allclose(d5[:, :, 2].transpose(0, 2, 1, 3), rdv,
                       rtol=1e-4, atol=1e-3)
