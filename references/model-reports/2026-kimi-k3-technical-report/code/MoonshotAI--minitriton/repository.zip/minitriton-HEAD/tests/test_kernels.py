"""Kernel correctness tests: DSL kernels against numpy references."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl


@tl.kernel
def vecadd_kernel(x_ptr, y_ptr, out_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < N
    x = tl.load(x_ptr + offs, mask=mask)
    y = tl.load(y_ptr + offs, mask=mask)
    tl.store(out_ptr + offs, x + y, mask=mask)


def run_vecadd(n: int, block: int, num_warps: int = 4):
    rng = np.random.default_rng(0)
    x = rng.random(n, dtype=np.float32)
    y = rng.random(n, dtype=np.float32)
    dx = tl.Buffer.from_numpy(x)
    dy = tl.Buffer.from_numpy(y)
    dout = tl.Buffer(n, tl.float32)
    vecadd_kernel[((n + block - 1) // block,)](dx, dy, dout, n, BLOCK=block,
                                               num_warps=num_warps)
    tl.synchronize()
    return dout.to_numpy(), x + y


@pytest.mark.parametrize("n,block", [
    (1 << 20, 512),      # aligned, vectorized path (ept == 4)
    (1 << 20, 1024),     # ept == 8
    (100_003, 512),      # odd size, masked boundary
    (100_003, 256),      # ept == 2, scalar path
])
def test_vecadd(n, block):
    out, ref = run_vecadd(n, block)
    np.testing.assert_allclose(out, ref, rtol=1e-6, atol=1e-7)


def test_vecadd_num_warps_8():
    out, ref = run_vecadd(1 << 20, 1024, num_warps=8)
    np.testing.assert_allclose(out, ref, rtol=1e-6, atol=1e-7)


@tl.kernel
def softmax_kernel(x_ptr, out_ptr, n_cols, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    mask = offs < n_cols
    x = tl.load(x_ptr + row * n_cols + offs, mask=mask, other=float("-inf"))
    x_max = tl.max(x)
    e = tl.exp(x - x_max)
    s = tl.sum(e)
    tl.store(out_ptr + row * n_cols + offs, e / s, mask=mask)


def run_softmax(rows: int, cols: int, num_warps: int):
    rng = np.random.default_rng(0)
    x = rng.standard_normal((rows, cols)).astype(np.float32) * 3
    dx = tl.Buffer.from_numpy(x)
    dout = tl.Buffer(rows * cols, tl.float32)
    nt = num_warps * 32
    block = ((cols + nt - 1) // nt) * nt
    softmax_kernel[(rows,)](dx, dout, cols, BLOCK=block, num_warps=num_warps)
    tl.synchronize()
    out = dout.to_numpy().reshape(rows, cols)
    z = x - x.max(axis=1, keepdims=True)
    e = np.exp(z)
    return out, e / e.sum(axis=1, keepdims=True)


@pytest.mark.parametrize("rows,cols,warps", [
    (128, 1024, 4),     # aligned rows, vectorized loads
    (37, 1024, 4),      # odd row count
    (128, 4096, 8),     # wide rows, 256 threads
    (17, 100, 4),       # ragged: BLOCK > n_cols, masked lanes
])
def test_softmax(rows, cols, warps):
    out, ref = run_softmax(rows, cols, warps)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-6)


@tl.kernel
def matmul_kernel(a_ptr, b_ptr, c_ptr, M, N, K,
                  BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    acc = tl.zeros((BM, BN), tl.float32)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * N + offs_n[None, :]
    for k in range(0, K, BK):
        a = tl.load(a_ptrs)
        b = tl.load(b_ptrs)
        acc = tl.dot(a, b, acc)
        a_ptrs += BK
        b_ptrs += BK * N
    tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)


@tl.kernel
def matmul_masked_kernel(a_ptr, b_ptr, c_ptr, M, N, K,
                         BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    acc = tl.zeros((BM, BN), tl.float32)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * N + offs_n[None, :]
    for k in range(0, K, BK):
        ka = tl.load(a_ptrs,
                     mask=(offs_m < M)[:, None] & (offs_k < K - k)[None, :])
        kb = tl.load(b_ptrs,
                     mask=(offs_k < K - k)[:, None] & (offs_n < N)[None, :])
        acc = tl.dot(ka, kb, acc)
        a_ptrs += BK
        b_ptrs += BK * N
    tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc,
             mask=(offs_m < M)[:, None] & (offs_n < N)[None, :])


def run_matmul(M, N, K, bm, bn, bk, warps, masked=False):
    rng = np.random.default_rng(0)
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)
    da = tl.Buffer.from_numpy(a)
    db = tl.Buffer.from_numpy(b)
    dc = tl.Buffer(M * N, tl.float32)
    kern = matmul_masked_kernel if masked else matmul_kernel
    kern[((M + bm - 1) // bm, (N + bn - 1) // bn)](
        da, db, dc, M, N, K, BM=bm, BN=bn, BK=bk, num_warps=warps)
    tl.synchronize()
    return dc.to_numpy().reshape(M, N), a @ b


@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps", [
    (128, 128, 128, 32, 128, 32, 4),
    (512, 512, 512, 32, 128, 32, 4),
    (512, 512, 512, 32, 256, 32, 4),   # VEC_N = 2
    (512, 512, 512, 64, 128, 16, 4),   # BM = 64
    (512, 512, 512, 32, 128, 64, 4),   # deeper K chunk
])
def test_matmul(M, N, K, bm, bn, bk, warps):
    out, ref = run_matmul(M, N, K, bm, bn, bk, warps)
    np.testing.assert_allclose(out, ref, rtol=1e-4, atol=1e-4 * np.sqrt(K))


@pytest.mark.parametrize("M,N,K", [(100, 100, 100), (333, 257, 129)])
def test_matmul_masked(M, N, K):
    out, ref = run_matmul(M, N, K, 32, 128, 32, 4, masked=True)
    np.testing.assert_allclose(out, ref, rtol=1e-4, atol=1e-4 * np.sqrt(K))


# ---------------------------------------------------------------------------
# tl.matmul_tile (2D thread tile + cp.async pipeline)
# ---------------------------------------------------------------------------

@tl.kernel
def matmul_tile_kernel(a_ptr, b_ptr, c_ptr, M, N, K,
                       BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
                       TM: tl.constexpr, TN: tl.constexpr,
                       STAGES: tl.constexpr,
                       EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
                       EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * N + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                             EVEN_K=EVEN_K, VEC=False,
                             a_mask=am, b_mask=bn)
    if EVEN_MN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc, mask=cm)


@tl.kernel
def matmul_tile_grouped_kernel(a_ptr, b_ptr, c_ptr, M, N, K,
                               BM: tl.constexpr, BN: tl.constexpr,
                               BK: tl.constexpr,
                               TM: tl.constexpr, TN: tl.constexpr,
                               STAGES: tl.constexpr, GROUP_M: tl.constexpr,
                               EVEN_MK: tl.constexpr, EVEN_KN: tl.constexpr,
                               EVEN_MN: tl.constexpr, EVEN_K: tl.constexpr,
                               ONE_BAR: tl.constexpr = False):
    pid = tl.program_id(0)
    num_pid_m = (M + BM - 1) // BM
    num_pid_n = (N + BN - 1) // BN
    num_in_group = GROUP_M * num_pid_n
    group_id = pid // num_in_group
    first_pid_m = group_id * GROUP_M
    group_size = tl.where(num_pid_m - first_pid_m < GROUP_M,
                          num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size)
    pid_n = (pid % num_in_group) // group_size
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * N + offs_n[None, :]
    if EVEN_MK and EVEN_KN:
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                             ONE_BAR=ONE_BAR)
    else:
        am = (offs_m < M)[:, None]
        bn = (offs_n < N)[None, :]
        acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                             EVEN_K=EVEN_K, VEC=False,
                             a_mask=am, b_mask=bn, ONE_BAR=ONE_BAR)
    if EVEN_MN:
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)
    else:
        cm = (offs_m[:, None] < M) & (offs_n[None, :] < N)
        tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc, mask=cm)


def run_matmul_tile(M, N, K, bm, bn, bk, tm, tn, warps, stages,
                    grouped=False, one_bar=False):
    rng = np.random.default_rng(0)
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)
    da = tl.Buffer.from_numpy(a)
    db = tl.Buffer.from_numpy(b)
    dc = tl.Buffer(M * N, tl.float32)
    kw = dict(BM=bm, BN=bn, BK=bk, TM=tm, TN=tn, STAGES=stages,
              EVEN_MK=M % bm == 0 and K % bk == 0,
              EVEN_KN=K % bk == 0 and N % bn == 0,
              EVEN_MN=M % bm == 0 and N % bn == 0,
              EVEN_K=K % bk == 0)
    if grouped:
        grid = (((M + bm - 1) // bm) * ((N + bn - 1) // bn),)
        matmul_tile_grouped_kernel[grid](da, db, dc, M, N, K, GROUP_M=4,
                                         ONE_BAR=one_bar, num_warps=warps,
                                         **kw)
    else:
        grid = ((M + bm - 1) // bm, (N + bn - 1) // bn)
        matmul_tile_kernel[grid](da, db, dc, M, N, K, num_warps=warps, **kw)
    tl.synchronize()
    return dc.to_numpy().reshape(M, N), a @ b


@pytest.mark.parametrize("M,N,K,bm,bn,bk,tm,tn,warps,stages", [
    (512, 512, 512, 64, 64, 32, 4, 4, 8, 2),
    (512, 512, 512, 128, 64, 32, 8, 8, 4, 2),     # main perf config
    (512, 512, 512, 128, 128, 16, 8, 8, 8, 3),   # 3 stages, 48KB smem
    (512, 512, 512, 128, 64, 32, 8, 4, 8, 2),    # TN=4
    (512, 512, 512, 64, 128, 32, 8, 8, 4, 2),
    (256, 256, 256, 64, 64, 16, 4, 4, 8, 4),     # 4 stages
])
def test_matmul_tile_even(M, N, K, bm, bn, bk, tm, tn, warps, stages):
    out, ref = run_matmul_tile(M, N, K, bm, bn, bk, tm, tn, warps, stages)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-4 * np.sqrt(K))


@pytest.mark.parametrize("M,N,K,bm,bn,bk,tm,tn,warps,stages", [
    (100, 100, 100, 32, 128, 32, 4, 4, 8, 2),     # ragged everywhere
    (333, 257, 129, 64, 64, 16, 4, 4, 8, 2),
    (1000, 999, 1004, 64, 128, 32, 4, 4, 16, 2),
    (64, 64, 130, 64, 64, 32, 4, 4, 8, 2),       # K % 4 != 0
    (16, 8, 64, 32, 64, 32, 4, 4, 4, 2),         # M/N smaller than the tile
    (7, 5, 3, 32, 64, 32, 4, 4, 4, 2),           # tiny odd
    (1, 1, 1, 32, 64, 32, 4, 4, 4, 2),           # degenerate
    (129, 65, 4096, 64, 64, 32, 4, 4, 8, 2),     # long K, ragged M/N
])
def test_matmul_tile_masked(M, N, K, bm, bn, bk, tm, tn, warps, stages):
    out, ref = run_matmul_tile(M, N, K, bm, bn, bk, tm, tn, warps, stages)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-4 * np.sqrt(K))


@pytest.mark.parametrize("M,N,K", [
    (512, 512, 512),       # even path through the grouped kernel
    (768, 512, 1024),      # even, GROUP_M boundary (num_pid_m=12)
    (300, 200, 100),       # ragged through grouped rasterization
])
def test_matmul_tile_grouped(M, N, K):
    out, ref = run_matmul_tile(M, N, K, 64, 64, 32, 4, 4, 8, 2, grouped=True)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-4 * np.sqrt(K))


# ONE_BAR single-barrier multistage schedule (ported from the mma path's
# ONE_BAR): same numerics contract across stage depths / trans views /
# masked shapes, plus bit-identity with the two-barrier schedule.
@pytest.mark.parametrize("M,N,K,bm,bn,bk,tm,tn,warps,stages", [
    (512, 512, 512, 64, 64, 32, 4, 4, 8, 2),
    (512, 512, 512, 128, 64, 32, 8, 8, 4, 2),
    (512, 512, 512, 128, 128, 16, 8, 8, 8, 3),   # 3 stages
    (256, 256, 256, 64, 64, 16, 4, 4, 8, 4),     # 4 stages
    (128, 128, 128, 64, 128, 16, 8, 8, 4, 2),    # T=2 == stages
    (64, 64, 64, 64, 64, 32, 4, 4, 8, 3),        # T=1 < stages
])
def test_matmul_tile_one_bar(M, N, K, bm, bn, bk, tm, tn, warps, stages):
    out, ref = run_matmul_tile(M, N, K, bm, bn, bk, tm, tn, warps, stages,
                               grouped=True, one_bar=True)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-4 * np.sqrt(K))
    # bit-identical to the two-barrier schedule (same FMA order)
    out2, _ = run_matmul_tile(M, N, K, bm, bn, bk, tm, tn, warps, stages,
                              grouped=True)
    assert np.array_equal(out, out2)


def test_matmul_tile_one_bar_masked():
    out, ref = run_matmul_tile(100, 100, 200, 32, 64, 32, 4, 4, 4, 3,
                               grouped=True, one_bar=True)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-4 * np.sqrt(200))


def test_matmul_tile_one_bar_needs_stages():
    from minitriton.compiler.builder import TileConfigError
    with pytest.raises(TileConfigError):
        run_matmul_tile(64, 64, 64, 64, 64, 32, 4, 4, 8, 1, grouped=True,
                        one_bar=True)



# ---------------------------------------------------------------------------
# tl.atomic_add (scalar + block values) and axis-1 row reduce
# ---------------------------------------------------------------------------

@tl.kernel
def atomic_add_kernel(x_ptr, out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    x = tl.load(x_ptr + offs)
    tl.atomic_add(out_ptr + tl.arange(0, 1) * 0, tl.sum(x))
    tl.atomic_add(out_ptr + 1, 2.5)


def test_atomic_add_scalar_and_block():
    x = np.arange(128, dtype=np.float32)
    dx = tl.Buffer.from_numpy(x)
    dout = tl.Buffer(4, tl.float32)
    dout.device.memset32(dout.ptr, 0, 4)
    atomic_add_kernel[(1,)](dx, dout, BLOCK=128, num_warps=4)
    tl.synchronize()
    out = dout.to_numpy()
    assert out[0] == float(127 * 128 // 2)
    assert out[1] == 2.5


@tl.kernel
def atomic_add_scalar_masked_kernel(out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    tl.atomic_add(out_ptr + 0, 1.0, mask=offs < 0)  # all-false tile mask


def test_atomic_add_scalar_honors_mask():
    """The scalar path used to ignore the mask argument entirely."""
    dout = tl.Buffer(4, tl.float32)
    dout.device.memset32(dout.ptr, 0, 4)
    atomic_add_scalar_masked_kernel[(1,)](dout, BLOCK=128, num_warps=4)
    tl.synchronize()
    assert dout.to_numpy()[0] == 0.0


@tl.kernel
def atomic_add_scalar_val_block_addr_kernel(out_ptr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    tl.atomic_add(out_ptr + offs, 1.0)  # scalar value, block address


def test_atomic_add_scalar_value_block_address_raises():
    """A scalar value against a non-scalar address used to silently add
    at the column base only — now a loud TileConfigError."""
    from minitriton.compiler.builder import TileConfigError
    dout = tl.Buffer(128, tl.float32)
    with pytest.raises(TileConfigError):
        atomic_add_scalar_val_block_addr_kernel[(1,)](
            dout, BLOCK=128, num_warps=4)


@tl.kernel
def row_reduce2d_kernel(x_ptr, mx_ptr, sm_ptr, R, C,
                        BR: tl.constexpr, BC: tl.constexpr):
    pid = tl.program_id(0)
    offs_r = pid * BR + tl.arange(0, BR)
    offs_c = tl.arange(0, BC)
    m = (offs_r < R)[:, None] & (offs_c < C)[None, :]
    x = tl.load(x_ptr + offs_r[:, None] * C + offs_c[None, :], mask=m,
                other=0.0)
    mx = tl.max(x, axis=1)
    sm = tl.sum(x, axis=1)
    mo = (offs_r < R)[:, None]
    tl.store(mx_ptr + offs_r[:, None] + tl.arange(0, 1) * 0, mx, mask=mo)
    tl.store(sm_ptr + offs_r[:, None] + tl.arange(0, 1) * 0, sm, mask=mo)


@pytest.mark.parametrize("R,C,warps", [(64, 64, 2), (128, 64, 2), (128, 64, 1)])
def test_row_reduce_axis1(R, C, warps):
    rng = np.random.default_rng(0)
    x = rng.standard_normal((R, C)).astype(np.float32)
    dx = tl.Buffer.from_numpy(x)
    dmx = tl.Buffer(R, tl.float32)
    dsm = tl.Buffer(R, tl.float32)
    row_reduce2d_kernel[(R // 64,)](dx, dmx, dsm, R, C, BR=64, BC=C,
                                    num_warps=warps)
    tl.synchronize()
    np.testing.assert_allclose(dmx.to_numpy(), x.max(axis=1), rtol=1e-6)
    np.testing.assert_allclose(dsm.to_numpy(), x.sum(axis=1), rtol=1e-4)


@tl.kernel
def _trig_kernel(x_ptr, s_ptr, c_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    v = tl.load(x_ptr + offs, mask=m, other=0.0)
    tl.store(s_ptr + offs, tl.sin(v), mask=m)
    tl.store(c_ptr + offs, tl.cos(v), mask=m)


def test_sin_cos_dsl():
    x_np = np.linspace(-20.0, 20.0, 4097).astype(np.float32)
    x = tl.tensor(x_np, device='cuda')
    s = tl.empty(4097, device='cuda')
    c = tl.empty(4097, device='cuda')
    _trig_kernel[((4097 + 255) // 256,)](x._buffer_arg(), s._buffer_arg(),
                                         c._buffer_arg(), 4097, BLOCK=256,
                                         num_warps=4)
    # sin.approx/cos.approx: ~2^-20 rel error over moderate args
    np.testing.assert_allclose(s.numpy(), np.sin(x_np), rtol=1e-5, atol=1e-5)
    np.testing.assert_allclose(c.numpy(), np.cos(x_np), rtol=1e-5, atol=1e-5)


def test_dot_num_warps1_wide_b():
    """dot((32,K),(K,128)) at num_warps=1: BN/num_threads % 4 == 0 takes
    the vector-unit smem staging for b, which extracted a scalar where a
    sub-vector belonged (MLIR verifier type mismatch)."""
    out, ref = run_matmul(32, 128, 64, 32, 128, 32, 1)
    np.testing.assert_allclose(out, ref, rtol=1e-4, atol=1e-4)
