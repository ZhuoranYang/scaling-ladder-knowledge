"""Stream-scope infrastructure tests.

numpy/fp64-oracle only (tests/ stay torch-free). Covers:

- ``current_stream`` + ``stream()`` scope semantics and the E0/E1 event
  model (values produced on one stream, consumed on the other);
- the allocator's cross-stream reuse guard (adversarial side-alloc -> free
  -> main-reuse loop);
- the single-stream fast path creating ZERO events;
- ``Linear.backward`` wgrad/dgrad overlap: bit-equal grads on vs off
  (same process, warm launch machinery), fp64-oracle sanity, the
  warm-first-call and shape-threshold gates;
- bounded-memory guards (topic-overlap-alloc-fix): keepalive reaping +
  byte budget, pool stability over an overlapped-backward loop, scopes
  as no-ops under CUDA graph capture, Graph.__del__ unpinning.
"""

import contextlib
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.autograd import functions as _funcs
from minitriton.frontend import types as tl_types
from minitriton.runtime import streams

rng = np.random.default_rng(0)
DEV = "cuda"


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


@contextlib.contextmanager
def _overlap(on):
    """MT_STREAM_OVERLAP is read LIVE from the env per backward call
    (launch-routing lever, precision.py): flip the env var — poking a
    module global would reach nothing."""
    saved = os.environ.get("MT_STREAM_OVERLAP")
    os.environ["MT_STREAM_OVERLAP"] = "1" if on else "0"
    try:
        yield
    finally:
        if saved is None:
            os.environ.pop("MT_STREAM_OVERLAP", None)
        else:
            os.environ["MT_STREAM_OVERLAP"] = saved


@pytest.fixture(autouse=True)
def _sync():
    yield
    tl.get_device().synchronize()


# ---------------------------------------------------------------------------
# TLS + scope semantics
# ---------------------------------------------------------------------------

def test_current_stream_default_is_zero():
    assert streams.current_stream() == 0


def test_scope_switch_and_restore():
    tl.get_device()  # ensure a context exists before touching the pool
    side = streams.default_pool().side()
    assert side != 0
    assert streams.current_stream() == 0
    with streams.stream(side):
        assert streams.current_stream() == side
    assert streams.current_stream() == 0


def test_scope_ordering_values_flow_both_ways():
    """Main-produced inputs read on the side stream; side-produced output
    read back on main after the join — all stream-ordered by E0/E1."""
    n = 4096
    a = tl.tensor(rn(n, n // 8), device=DEV)
    b = tl.tensor(rn(n // 8, n // 4), device=DEV)
    side = streams.default_pool().side()
    with streams.stream(side):
        c = tl.matmul(a, b)          # side reads main-produced a, b
        c = c + 1.0
    d = c * 2.0                      # main reads side-produced c (E1 join)
    got = d.numpy()
    want = (a.numpy() @ b.numpy() + 1.0) * 2.0
    err = float(np.max(np.abs(got - want)))
    assert err < 1e-3, f"scope ordering broke: max err {err}"


def test_nested_same_stream_scope_creates_no_events():
    tl.get_device()
    side = streams.default_pool().side()
    with streams.stream(side):
        pass                          # warm the pool's events
    before = streams.default_pool().events_created
    with streams.stream(side):
        with streams.stream(side):    # same stream: no fork/join events
            pass
    assert streams.default_pool().events_created == before


def test_placement_is_tls_only():
    tl.get_device()
    side = streams.default_pool().side()
    with streams.stream(side):
        pass                          # warm pool events
    before = streams.default_pool().events_created
    with streams.placement(side):
        assert streams.current_stream() == side
    assert streams.current_stream() == 0
    assert streams.default_pool().events_created == before


def test_deferred_join_parks_and_drains():
    tl.get_device()
    side = streams.default_pool().side()
    x = tl.tensor(rn(1024), device=DEV)
    with streams.stream(side, join=False):
        y = x + 1.0
    assert streams.pending()
    streams.join_pending()
    assert not streams.pending()
    assert np.allclose(y.numpy(), x.numpy() + 1.0, rtol=1e-5)
    streams.join_pending()            # no-op when nothing is pending


def test_deferred_window_buffer_reuse():
    """Inside an un-joined window, side-freed buffers reused on main must
    still observe the release-time ordering (allocator guard)."""
    tl.get_device()
    side = streams.default_pool().side()
    n = 1 << 20
    with streams.stream(side, join=False):
        a = tl.zeros((n,), device=DEV) + 7.0
        del a                         # side-home, freed in the window
    assert streams.pending()
    for i in range(32):
        b = tl.zeros((n,), device=DEV) + (i + 1.0)   # main reuse
        got = b.numpy()
        assert np.all(got == i + 1.0), \
            f"iter {i}: in-window reuse observed stale/corrupt data"
        del b
    streams.join_pending()
    assert not streams.pending()


# ---------------------------------------------------------------------------
# allocator cross-stream reuse (adversarial loop)
# ---------------------------------------------------------------------------

def test_cross_stream_buffer_reuse_adversarial():
    """side-alloc -> free -> main-reuse of the same size class, plus the
    release-after-scope-exit variant; every iteration must observe its own
    fill, never the previous tenant's."""
    side = streams.default_pool().side()
    n = 1 << 20  # 4MB fp32: kernels long enough to still be in flight
    for i in range(64):
        with streams.stream(side):
            a = tl.zeros((n,), device=DEV) + (i + 1.0)
            del a                     # freed inside the scope (home=side)
        b = tl.zeros((n,), device=DEV) + (i + 100.0)   # main reuse
        got = b.numpy()
        assert np.all(got == i + 100.0), \
            f"iter {i}: main reuse observed stale/corrupt data"
        del b
        # variant: side-allocated buffer released AFTER the scope exit
        with streams.stream(side):
            c = tl.zeros((n,), device=DEV) + (i + 50.0)
        del c                         # release on main, home still side
        d = tl.zeros((n,), device=DEV) + (i + 200.0)
        got = d.numpy()
        assert np.all(got == i + 200.0), \
            f"iter {i}: post-scope reuse observed stale/corrupt data"
        del d


# ---------------------------------------------------------------------------
# single-stream fast path: zero events
# ---------------------------------------------------------------------------

def test_single_stream_ops_create_no_events():
    pool = streams.default_pool()
    before = pool.events_created
    a = tl.tensor(rn(256, 256), device=DEV)
    b = tl.tensor(rn(256, 256), device=DEV)
    for _ in range(8):
        c = tl.matmul(a, b) + 1.0
        d = c.sum()
        del c, d
    tl.get_device().synchronize()
    assert pool.events_created == before, \
        "single-stream code must never pay for scope events"


# ---------------------------------------------------------------------------
# Linear.backward overlap (bf16 route)
# ---------------------------------------------------------------------------

M, IN_F, OUT_F = 512, 640, 640   # MACs = 2.1e8 >> 1<<24 threshold


def _bf16_linear_triplet(seed):
    r = np.random.default_rng(seed)
    # leaves: astype records a tape node if the SOURCE requires grad, so
    # build the bf16 tensors from non-grad fp32 temporaries first
    x = tl.tensor(r.standard_normal((M, IN_F)).astype(np.float32),
                  device=DEV).astype(tl_types.bfloat16)
    w = tl.tensor(r.standard_normal((OUT_F, IN_F)).astype(np.float32),
                  device=DEV).astype(tl_types.bfloat16)
    b = tl.tensor(r.standard_normal((OUT_F,)).astype(np.float32),
                  device=DEV).astype(tl_types.bfloat16)
    for t in (x, w, b):
        t.requires_grad = True
    g = r.standard_normal((M, OUT_F)).astype(np.float32)
    return x, w, b, g


def _run_linear_bwd(x, w, b, g, overlap):
    with _overlap(overlap):
        y = _funcs.linear(x, w, b)
        y.backward(tl.tensor(g, device=DEV, requires_grad=False))
        tl.get_device().synchronize()
        out = (x.grad.astype(tl_types.float32).numpy().copy(),
               w.grad.astype(tl_types.float32).numpy().copy(),
               b.grad.astype(tl_types.float32).numpy().copy())
    x.grad = w.grad = b.grad = None
    return out


def test_linear_overlap_bit_equal():
    """overlap on vs off, same process (shared autotune/fast-launch state):
    grads must be BIT-identical (deterministic kernels, same configs)."""
    x, w, b, g = _bf16_linear_triplet(1)
    # two calls per mode: the FIRST overlap candidate runs serialized
    # (warm-first-call gate); the second exercises the side stream
    off0 = _run_linear_bwd(x, w, b, g, False)
    on0 = _run_linear_bwd(x, w, b, g, True)
    on1 = _run_linear_bwd(x, w, b, g, True)
    off1 = _run_linear_bwd(x, w, b, g, False)
    for name, a, ref in zip(("da", "dw", "db"), on1, off1):
        assert np.array_equal(a, ref), f"overlap changed {name} bitwise"
    for name, a, ref in zip(("da", "dw", "db"), off1, off0):
        assert np.array_equal(a, ref), f"serialized path not deterministic: {name}"
    assert all(np.array_equal(a, b_) for a, b_ in zip(on0, off0)), \
        "warm-first-call must be the serialized path"


def test_linear_overlap_fp64_oracle():
    """The overlapped grads must still be right, not just equal: bf16
    inputs, fp64 numpy oracle, rel err < 2e-2 (bf16 band)."""
    x, w, b, g = _bf16_linear_triplet(2)
    x64 = x.astype(tl_types.float32).numpy().astype(np.float64)
    w64 = w.astype(tl_types.float32).numpy().astype(np.float64)
    g64 = g.astype(np.float64)
    da64, dw64, db64 = g64 @ w64, g64.T @ x64, g64.sum(axis=0)
    _run_linear_bwd(x, w, b, g, True)    # warm-first-call (serialized)
    da, dw, db = _run_linear_bwd(x, w, b, g, True)   # overlapped
    for name, got, ref in (("da", da, da64), ("dw", dw, dw64),
                           ("db", db, db64)):
        rel = float(np.max(np.abs(got - ref)) / (np.max(np.abs(ref)) + 1e-12))
        assert rel < 2e-2, f"{name}: rel err {rel} vs fp64 oracle"


def test_overlap_threshold_gate():
    """Below MT_STREAM_OVERLAP_MIN_MACS the dw branch stays on the default
    stream: no scope, no events."""
    pool = streams.default_pool()
    r = np.random.default_rng(3)
    x = tl.tensor(r.standard_normal((8, 64)).astype(np.float32),
                  device=DEV, requires_grad=True).astype(tl_types.bfloat16)
    w = tl.tensor(r.standard_normal((64, 64)).astype(np.float32),
                  device=DEV, requires_grad=True).astype(tl_types.bfloat16)
    x.requires_grad = w.requires_grad = True
    with _overlap(True):
        before = pool.events_created
        y = _funcs.linear(x, w)
        y.backward(tl.tensor(r.standard_normal((8, 64)).astype(np.float32),
                             device=DEV, requires_grad=False))
        tl.get_device().synchronize()
        assert pool.events_created == before


def test_linear_overlap_chain_bit_equal():
    """Two chained bf16 Linears (deferred join spans both nodes; the
    intermediate's grad is produced/consumed inside the window): on vs
    off must remain bit-identical."""
    r = np.random.default_rng(5)
    def leaf(*shape):
        t = tl.tensor(r.standard_normal(shape).astype(np.float32),
                      device=DEV).astype(tl_types.bfloat16)
        t.requires_grad = True
        return t
    x, w1, b1 = leaf(M, IN_F), leaf(OUT_F, IN_F), leaf(OUT_F)
    w2, b2 = leaf(OUT_F, OUT_F), leaf(OUT_F)
    g = r.standard_normal((M, OUT_F)).astype(np.float32)

    def run(overlap):
        with _overlap(overlap):
            z = _funcs.linear(_funcs.linear(x, w1, b1), w2, b2)
            z.backward(tl.tensor(g, device=DEV, requires_grad=False))
            tl.get_device().synchronize()
            out = tuple(t.grad.astype(tl_types.float32).numpy().copy()
                        for t in (x, w1, b1, w2, b2))
        for t in (x, w1, b1, w2, b2):
            t.grad = None
        return out

    run(False)
    run(True)                          # warm-first-call per shape
    off, on = run(False), run(True)
    assert not streams.pending()       # engine drained the deferred joins
    for i, (a, b_) in enumerate(zip(on, off)):
        assert np.array_equal(a, b_), f"chain grad {i} differs bitwise"


def test_overlap_actually_uses_side_stream():
    """With overlap on, warm, and a big-enough shape, the dw scope must
    leave a trace: current_stream returns to 0 afterwards and events were
    recorded (2 per scope, recycled from the pool)."""
    x, w, b, g = _bf16_linear_triplet(4)
    _run_linear_bwd(x, w, b, g, True)    # warm-first-call (serialized)
    pool = streams.default_pool()
    before = pool.events_created
    _run_linear_bwd(x, w, b, g, True)    # overlapped
    assert streams.current_stream() == 0
    assert pool.events_created > before or len(pool._free_events) > 0


# ---------------------------------------------------------------------------
# bounded-memory guards (topic-overlap-alloc-fix)
# ---------------------------------------------------------------------------

def test_completed_scope_reaped_at_next_fork():
    """A join=False scope whose side work has finished must release its
    keepalive set at the NEXT fork (cuEventQuery reap), without waiting
    for the end-of-backward join."""
    tl.get_device()
    side = streams.default_pool().side()
    x = tl.tensor(rn(256), device=DEV)
    with streams.stream(side, join=False):
        y = x + 1.0
    streams.keepalive(x)
    pool = streams.default_pool()
    assert len(pool._pending) == 1
    tl.get_device().synchronize()       # side work completes -> E1 fires
    with streams.stream(side, join=False):   # this fork reaps the old entry
        z = x + 2.0
    entry = pool._pending.get(side)
    assert entry is not None and entry[1] == [] and entry[2] == 0
    streams.join_pending()
    assert not streams.pending()


def test_overlap_keepalive_budget_bounds_peak():
    """Regression for the unbounded keepalive hold: with a small byte
    budget the deferred-join window must close early, so the backward
    peak stays within (budget + one scope) of the serialized peak."""
    CM, CD = 2048, 1280          # keepalive ~19MB per scope (g/x/w)
    r = np.random.default_rng(7)

    def leaf(*shape):
        t = tl.tensor(r.standard_normal(shape).astype(np.float32),
                      device=DEV).astype(tl_types.bfloat16)
        t.requires_grad = True
        return t
    x = leaf(CM, CD)
    ws = [leaf(CD, CD) for _ in range(8)]
    g = r.standard_normal((CM, CD)).astype(np.float32)

    def chained_peak(overlap):
        with _overlap(overlap):
            z = x
            for w_ in ws:
                z = _funcs.linear(z, w_)
            tl.reset_peak_stats()
            z.backward(tl.tensor(g, device=DEV, requires_grad=False))
            tl.get_device().synchronize()
            out = tl.memory_stats()["peak_allocated_bytes"]
        x.grad = None
        for w_ in ws:
            w_.grad = None
        return out

    chained_peak(True)                  # warm-first-call per shape
    chained_peak(True)
    peak_off = chained_peak(False)
    saved_budget = streams._KEEPALIVE_BUDGET
    streams._KEEPALIVE_BUDGET = 64 << 20
    try:
        peak_on = chained_peak(True)
    finally:
        streams._KEEPALIVE_BUDGET = saved_budget
    slack = (64 + 19 + 45) << 20        # budget + one scope + jitter
    assert peak_on - peak_off < slack, \
        f"keepalive pile-up: on-peak exceeds off-peak by " \
        f"{(peak_on - peak_off) >> 20}MB (budget 64MB)"


def test_overlap_loop_pool_bounded():
    """Adversarial loop (the OOM repro's core pattern): overlapped
    backward steps must drain every deferred join and leave the pool
    byte-stable — no per-step growth from keepalive/pending residue."""
    x, w, b, g = _bf16_linear_triplet(6)
    _run_linear_bwd(x, w, b, g, True)    # warm-first-call
    _run_linear_bwd(x, w, b, g, True)
    import gc
    gc.collect()
    tl.get_device().synchronize()
    base = tl.memory_stats()["reserved_bytes"]
    for _ in range(20):
        _run_linear_bwd(x, w, b, g, True)
        assert not streams.pending()
        assert not streams.default_pool()._pending
    gc.collect()
    tl.get_device().synchronize()
    after = tl.memory_stats()["reserved_bytes"]
    assert after <= base + (1 << 20), \
        f"pool grew {(after - base) >> 20}MB over the overlap loop"


def test_scope_during_capture_is_noop():
    """A stream scope entered while a CUDA graph capture is active must
    not switch streams, create events, or park joins — the captured
    sequence stays identical to the non-overlap path."""
    from minitriton.runtime import graph as mt_graph
    x = tl.tensor(rn(1024), device=DEV)
    side = streams.default_pool().side()

    def fn():
        with streams.stream(side, join=False):
            return x + 1.0

    fn()                                 # warm the kernel (events here)
    streams.join_pending()
    pool = streams.default_pool()
    before = pool.events_created
    g = mt_graph.capture(fn)
    assert not streams.pending()
    assert pool.events_created == before, \
        "scope under capture must not record events"
    g.launch()
    tl.get_device().synchronize()
    assert np.allclose(g.out.numpy(), x.numpy() + 1.0, rtol=1e-5)
    g.teardown()


def test_graph_del_unpins():
    """Graph.__del__ must release the pinned pool footprint (the bench
    sweeps graph configs in one process; without it each config's pins
    were retained forever)."""
    import gc
    from minitriton.runtime import graph as mt_graph
    from minitriton.runtime import allocator as A
    x = tl.tensor(rn(1 << 20), device=DEV)
    (x + 1.0).numpy()                    # warm
    tl.get_device().synchronize()
    free0 = tl.memory_stats()["num_free_buffers"]
    g = mt_graph.capture(lambda: x + 1.0)
    assert tl.memory_stats()["num_free_buffers"] < free0  # pins evicted
    del g
    gc.collect()
    assert tl.memory_stats()["num_free_buffers"] == free0
    # and the addresses are reusable: same-size alloc needs no new reserve
    res0 = tl.memory_stats()["reserved_bytes"]
    y = tl.tensor(rn(1 << 20), device=DEV)
    (y + 1.0).numpy()
    assert tl.memory_stats()["reserved_bytes"] <= res0 + (1 << 20)
