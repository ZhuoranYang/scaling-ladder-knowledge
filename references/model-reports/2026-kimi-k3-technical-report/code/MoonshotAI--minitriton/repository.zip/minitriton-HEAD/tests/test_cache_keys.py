"""Cache-key coverage: every input that changes the
launched cubin must be part of every cache layer's key.

- Autotuner.launch fast path: launch kwargs (keyword constexprs
  like BIAS/SCALE) and the RESOLVED grid (bmm's batch lives only in the
  grid lambda's closure) are in the key.
- captured globals (plain values, tl.constexpr, @tl.inline
  helper sources) salt the mem/disk/fast keys.
- MINITRITON_WIR_ANNOTATE salts the codegen fingerprint.
- @tl.compile documents + warns on captured mutable state.
"""

import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
import minitriton.ops as _ops

rng = np.random.default_rng(0)
_MOD = sys.modules[__name__]


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


# ---------------------------------------------------------------------------
# autotuner fast-path key
# ---------------------------------------------------------------------------

def test_matmul_bias_plain_launches_do_not_collide():
    """bias/plain alternate on one (M, N, K) variant: the BIAS kwarg must
    separate the two fast-launch entries (pre-fix the second launch of
    each pair replayed the first one's cubin)."""
    M, N, K = 1, 128, 64
    a_np, b_np, bias_np = rn(M, K), rn(K, N), rn(N)
    a, b, bias = tl.tensor(a_np), tl.tensor(b_np), tl.tensor(bias_np)

    plain = _ops.matmul(a, b).numpy()
    np.testing.assert_allclose(plain, a_np @ b_np, rtol=1e-5, atol=1e-5)
    biased = _ops.matmul(a, b, bias=bias).numpy()
    np.testing.assert_allclose(biased, a_np @ b_np + bias_np,
                               rtol=1e-5, atol=1e-5)

    # fresh operands, bias first then plain (reverse contamination order)
    a2_np, b2_np, bias2_np = rn(M, K), rn(K, N), rn(N)
    a2, b2, bias2 = (tl.tensor(a2_np), tl.tensor(b2_np),
                     tl.tensor(bias2_np))
    biased2 = _ops.matmul(a2, b2, bias=bias2).numpy()
    np.testing.assert_allclose(biased2, a2_np @ b2_np + bias2_np,
                               rtol=1e-5, atol=1e-5)
    plain2 = _ops.matmul(a2, b2).numpy()
    np.testing.assert_allclose(plain2, a2_np @ b2_np, rtol=1e-5,
                               atol=1e-5)


@tl.autotune(configs=[tl.Config({"BLOCK": 128}, num_warps=4)], key=["N"])
@tl.kernel
def _scale_kw(x_ptr, out_ptr, N, SCALE: tl.constexpr,
              BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m)
    tl.store(out_ptr + offs, x * SCALE, mask=m)


def test_autotune_keyword_constexpr_rekeys():
    """A constexpr passed by keyword never entered _args_key: changing
    SCALE between calls replayed the stale cubin."""
    n = 256
    x_np = np.arange(n, dtype=np.float32)
    x = tl.Buffer.from_numpy(x_np)
    out = tl.Buffer(n, tl.float32)
    grid = lambda a: ((a["N"] + a["BLOCK"] - 1) // a["BLOCK"],)
    _scale_kw[grid](x, out, n, SCALE=2.0, BLOCK=0)
    tl.synchronize()
    np.testing.assert_allclose(out.to_numpy(), x_np * 2.0)
    _scale_kw[grid](x, out, n, SCALE=5.0, BLOCK=0)
    tl.synchronize()
    np.testing.assert_allclose(out.to_numpy(), x_np * 5.0)


def test_bmm_resolved_grid_in_fast_key():
    """bmm's batch B is not a kernel argument — it lives only in the grid
    lambda's closure. Guarded failure mode: pool size-class collision
    makes the fast key identical for B=48 and B=64, so the second launch
    reuses the smaller baked grid and never writes slabs 48..63."""
    M = N = K = 80

    def run(B, seed):
        r = np.random.default_rng(seed)
        a_np = r.standard_normal((B, M, K)).astype(np.float32)
        b_np = r.standard_normal((B, K, N)).astype(np.float32)
        # op-produced (pooled) inputs: per-slab 80*80*4B puts both Bs in
        # the same 2MB size class — the collision precondition
        a = tl.zeros((B, M, K)) + tl.tensor(a_np)
        b = tl.zeros((B, K, N)) + tl.tensor(b_np)
        return a_np, b_np, _ops.bmm(a, b).numpy()

    a48, b48, y48 = run(48, 1)
    np.testing.assert_allclose(y48, a48 @ b48, rtol=1e-4, atol=1e-4)
    a64, b64, y64 = run(64, 2)
    ref = a64 @ b64
    for i in range(64):
        np.testing.assert_allclose(y64[i], ref[i], rtol=1e-4, atol=1e-4,
                                   err_msg=f"slab {i}")


# ---------------------------------------------------------------------------
# captured globals salt the key
# ---------------------------------------------------------------------------

_G_PLAIN = 2.0
_G_CE = tl.constexpr(2.0)


@tl.kernel
def _k_g_plain(x_ptr, out_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m)
    tl.store(out_ptr + offs, x * _G_PLAIN, mask=m)


@tl.kernel
def _k_g_ce(x_ptr, out_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m)
    tl.store(out_ptr + offs, x * _G_CE, mask=m)


def _run_scale_kernel(kern, n=256):
    x_np = np.arange(n, dtype=np.float32)
    x = tl.Buffer.from_numpy(x_np)
    out = tl.Buffer(n, tl.float32)
    kern[(2,)](x, out, n, BLOCK=128)
    tl.synchronize()
    return x_np, out.to_numpy()


def test_captured_plain_global_rekeys():
    """Editing a captured plain-number global must invalidate the fast
    entry, the in-memory cubin and the disk entry (pre-fix all three
    replayed the stale cubin)."""
    old = _MOD._G_PLAIN
    try:
        _MOD._G_PLAIN = 2.0
        x_np, got = _run_scale_kernel(_k_g_plain)
        np.testing.assert_allclose(got, x_np * 2.0)
        _MOD._G_PLAIN = 3.0
        x_np, got = _run_scale_kernel(_k_g_plain)
        np.testing.assert_allclose(got, x_np * 3.0)
    finally:
        _MOD._G_PLAIN = old


def test_captured_constexpr_global_rekeys():
    old = _MOD._G_CE
    try:
        _MOD._G_CE = tl.constexpr(2.0)
        x_np, got = _run_scale_kernel(_k_g_ce)
        np.testing.assert_allclose(got, x_np * 2.0)
        _MOD._G_CE = tl.constexpr(5.0)
        x_np, got = _run_scale_kernel(_k_g_ce)
        np.testing.assert_allclose(got, x_np * 5.0)
    finally:
        _MOD._G_CE = old


# ---------------------------------------------------------------------------
# @tl.inline helper source salts the key
# ---------------------------------------------------------------------------

@tl.inline
def _hk_add(x):
    return x + 2.0


@tl.inline
def _hk_mul(x):
    return x * 3.0


_HK_HELPER = _hk_add


@tl.kernel
def _k_helper(x_ptr, out_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m)
    tl.store(out_ptr + offs, _HK_HELPER(x), mask=m)


def test_inline_helper_source_in_key():
    """Swapping the helper a kernel inlines (same kernel source) must
    re-key: the helper's source is part of the sampled globals."""
    old = _MOD._HK_HELPER
    try:
        _MOD._HK_HELPER = _hk_add
        x_np, got = _run_scale_kernel(_k_helper)
        np.testing.assert_allclose(got, x_np + 2.0)
        g1 = _k_helper._sample_globals()
        _MOD._HK_HELPER = _hk_mul
        x_np, got = _run_scale_kernel(_k_helper)
        np.testing.assert_allclose(got, x_np * 3.0)
        g2 = _k_helper._sample_globals()
        assert g1 != g2  # helper source is mixed into the key
    finally:
        _MOD._HK_HELPER = old


_HELPER_SRC = '''import minitriton as tl

ADD_C = {val}


@tl.inline
def add_const(x):
    return x {op} ADD_C
'''

_CHILD_SRC = '''\
import sys
sys.path.insert(0, {tmp!r})
sys.path.insert(0, {root!r})
import numpy as np
import minitriton as mt
from ck_helper import add_const, ADD_C  # noqa: F401


@mt.kernel
def k(x_ptr, out_ptr, N, BLOCK: mt.constexpr):
    pid = mt.program_id(0)
    offs = pid * BLOCK + mt.arange(0, BLOCK)
    m = offs < N
    x = mt.load(x_ptr + offs, mask=m)
    mt.store(out_ptr + offs, add_const(x), mask=m)


x = mt.Buffer.from_numpy(np.ones(128, dtype=np.float32))
out = mt.Buffer(128, mt.float32)
k[(1,)](x, out, 128, BLOCK=128)
mt.synchronize()
print(float(out.to_numpy()[0]))
'''


def _run_child(tmp_path: Path, cache: Path) -> float:
    env = dict(os.environ)
    env["MINITRITON_CACHE_DIR"] = str(cache)
    child = tmp_path / "ck_child.py"
    child.write_text(_CHILD_SRC.format(
        tmp=str(tmp_path),
        root=str(Path(__file__).resolve().parents[1])))
    r = subprocess.run([sys.executable, str(child)], capture_output=True,
                       text=True, env=env, timeout=300)
    assert r.returncode == 0, f"child failed:\n{r.stdout}\n{r.stderr}"
    return float(r.stdout.strip().splitlines()[-1])


def test_helper_change_invalidates_disk_cache(tmp_path):
    """Two processes share one MINITRITON_CACHE_DIR: editing the helper's
    global (or its body) between runs must not hit the stale cubin."""
    cache = tmp_path / "cache"
    helper = tmp_path / "ck_helper.py"

    helper.write_text(_HELPER_SRC.format(val=1.0, op="+"))
    assert _run_child(tmp_path, cache) == pytest.approx(2.0)

    # same kernel source, helper's global changed: stale hit pre-fix
    helper.write_text(_HELPER_SRC.format(val=100.0, op="+"))
    assert _run_child(tmp_path, cache) == pytest.approx(101.0)

    # helper body rewritten, hot cache: stale hit pre-fix
    helper.write_text(_HELPER_SRC.format(val=7.0, op="*"))
    assert _run_child(tmp_path, cache) == pytest.approx(7.0)


# ---------------------------------------------------------------------------
# MINITRITON_WIR_ANNOTATE salts the codegen fingerprint
# ---------------------------------------------------------------------------

def test_wir_annotate_env_salts_fingerprint(monkeypatch):
    from minitriton.runtime.cache import codegen_fingerprint
    monkeypatch.setenv("MINITRITON_WIR_ANNOTATE", "0")
    codegen_fingerprint.cache_clear()
    fp0 = codegen_fingerprint()
    monkeypatch.setenv("MINITRITON_WIR_ANNOTATE", "1")
    codegen_fingerprint.cache_clear()
    fp1 = codegen_fingerprint()
    codegen_fingerprint.cache_clear()
    assert fp0 != fp1


# ---------------------------------------------------------------------------
# @tl.compile captured-state contract
# ---------------------------------------------------------------------------

def test_compile_closure_warns_and_documents():
    """Non-empty __closure__ warns at trace time; the decorator's
    docstring states the captured-state contract."""
    def make_f():
        scale = 2.0

        @tl.compile
        def f(x):
            return x * scale + 1.0
        return f

    f = make_f()
    x = tl.tensor(np.full((4,), 1.0, dtype=np.float32))
    with pytest.warns(UserWarning, match="captured state"):
        y = f(x)
    np.testing.assert_allclose(y.numpy(), [3.0, 3.0, 3.0, 3.0])
    assert "captured state" in (tl.compile.__doc__ or "")


def test_compile_plain_fn_no_warning():
    import warnings

    @tl.compile
    def f(x):
        return x * 2.0

    x = tl.tensor(np.full((4,), 1.0, dtype=np.float32))
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        f(x)
    assert not any("captured state" in str(x_.message) for x_ in w)
