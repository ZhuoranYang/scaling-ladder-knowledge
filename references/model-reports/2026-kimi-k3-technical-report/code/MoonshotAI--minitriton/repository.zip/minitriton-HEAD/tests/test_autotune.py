"""Autotune + do_bench tests."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl


@tl.autotune(
    configs=[
        tl.Config({"BLOCK": 256}, num_warps=4),
        tl.Config({"BLOCK": 512}, num_warps=4),
        tl.Config({"BLOCK": 4096}, num_warps=4),  # invalid for small N? no—
    ],
    key=["N"],
)
@tl.kernel
def vecadd_at(x_ptr, y_ptr, out_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < N
    x = tl.load(x_ptr + offs, mask=mask)
    y = tl.load(y_ptr + offs, mask=mask)
    tl.store(out_ptr + offs, x + y, mask=mask)


def test_autotune_picks_valid_config():
    n = 100_003
    rng = np.random.default_rng(0)
    x = rng.random(n, dtype=np.float32)
    y = rng.random(n, dtype=np.float32)
    dx = tl.Buffer.from_numpy(x)
    dy = tl.Buffer.from_numpy(y)
    dout = tl.Buffer(n, tl.float32)
    grid = lambda args: ((args["N"] + args["BLOCK"] - 1) // args["BLOCK"],)
    vecadd_at[grid](dx, dy, dout, n, 0)
    tl.synchronize()
    np.testing.assert_allclose(dout.to_numpy(), x + y, rtol=1e-6, atol=1e-7)
    best = vecadd_at.autotuner._mem[(n,)]
    assert best.kwargs["BLOCK"] in (256, 512, 4096)
    # second call uses the cached choice
    vecadd_at[grid](dx, dy, dout, n, 0)
    tl.synchronize()


def test_do_bench_returns_positive_ms():
    n = 1 << 20
    x = tl.Buffer(n, tl.float32)
    grid = lambda args: ((args["N"] + args["BLOCK"] - 1) // args["BLOCK"],)
    ms = tl.do_bench(lambda: vecadd_at[grid](x, x, x, n, 0), warmup=2, rep=5)
    assert ms > 0


def test_autotune_interleaved_leaders_beat_drift(monkeypatch):
    """Pick quality: the true best must win even when round 1 suffers a
    monotonic clock-ramp bias against early configs (fc.fwd fp32 pinned
    6.9% off-best before the interleaved leader rounds)."""
    from minitriton.runtime import autotune as at

    cfgs = [tl.Config({"BLOCK": 256}, num_warps=4),
            tl.Config({"BLOCK": 512}, num_warps=4),
            tl.Config({"BLOCK": 1024}, num_warps=4),
            tl.Config({"BLOCK": 2048}, num_warps=4)]
    true_ms = {(256, 4): 1.00, (512, 4): 1.06,
               (1024, 4): 1.02, (2048, 4): 1.10}  # BLOCK=256 true best
    tuner = at.Autotuner(vecadd_at, cfgs, ["N"])

    # spy records the config of each measure() call in order
    measured = []
    orig_compile = vecadd_at.compile_with

    def spy_compile(args, config, num_warps, launch_kwargs=None):
        measured.append((config["BLOCK"], num_warps))
        return orig_compile(args, config, num_warps, launch_kwargs)

    monkeypatch.setattr(vecadd_at, "compile_with", spy_compile)

    def fake_do_bench(fn, warmup=5, rep=20, return_mode="median"):
        i = len(measured) - 1  # spy already registered this measurement
        ramp = 1.0 + 0.12 * max(0.0, 1.0 - i / 12.0)  # early = 12% slow
        return true_ms[measured[-1]] * ramp

    monkeypatch.setattr(at, "do_bench", fake_do_bench)

    n = 100_003
    rng = np.random.default_rng(0)
    dx = tl.Buffer.from_numpy(rng.random(n, dtype=np.float32))
    dout = tl.Buffer(n, tl.float32)
    grid = lambda args: ((args["N"] + args["BLOCK"] - 1) // args["BLOCK"],)
    # scripted ramp flips round-1 order: 256 measures 1.12 > 512's 1.04,
    # so a single-round (or top-1-only) policy would crown 512
    best = tuner._tune(grid, (dx, dx, dout, n), {"BLOCK": 0}, (n,))
    assert best.kwargs["BLOCK"] == 256
    # leaders got interleaved confirmation rounds, not a single extra pass
    assert len(measured) > len(cfgs)


