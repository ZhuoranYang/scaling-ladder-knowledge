"""Autograd test matrix: forward + backward of every differentiable
op x {cpu, cuda}, checked against hand-written numpy gradient references
(no torch in tests/; torch comparison lives in benchmarks/training/grad_check.py).

Tolerances follow test_ops.py: fp32 rtol ~1e-5 (1e-4 for approx-PTX
transcendentals), matmul err/sqrt(K) < 1e-4.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl

DEVS = pytest.mark.parametrize("dev", ["cpu", "cuda"])

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


def T(x, dev, requires_grad=True):
    return tl.tensor(np.ascontiguousarray(x), device=dev,
                     requires_grad=requires_grad)


def close(out, ref, rtol=1e-5, atol=1e-6):
    arr = out.numpy() if isinstance(out, tl.Tensor) else out
    ref = np.asarray(ref)
    assert arr.shape == ref.shape, f"shape {arr.shape} != ref {ref.shape}"
    np.testing.assert_allclose(arr, ref, rtol=rtol, atol=atol)


def _unbroadcast(g, shape):
    while g.ndim > len(shape):
        g = g.sum(axis=0)
    for d, s in enumerate(shape):
        if s == 1 and g.shape[d] != 1:
            g = g.sum(axis=d, keepdims=True)
    return g.reshape(shape)


# ---------------------------------------------------------------------------
# elementwise binary (with broadcasting) + scalar operands
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("sa,sb", [((4, 3), (4, 3)), ((4, 3), (3,)),
                                   ((4, 3), (4, 1)), ((2, 3, 4), (3, 4))])
def test_binary_broadcast_backward(dev, sa, sb):
    a, b, g = rn(*sa), rn(*sb), rn(*np.broadcast_shapes(sa, sb))
    for op, fa, fb in (
            ("add", lambda a, b, g: g, lambda a, b, g: g),
            ("sub", lambda a, b, g: g, lambda a, b, g: -g),
            ("mul", lambda a, b, g: g * b, lambda a, b, g: g * a),
            ("div", lambda a, b, g: g / b, lambda a, b, g: -g * a / (b * b))):
        ta, tb = T(a, dev), T(b, dev)
        getattr(tl, op)(ta, tb).backward(T(g, dev, False))
        close(ta.grad, _unbroadcast(fa(a, b, g), sa), rtol=1e-4, atol=1e-5)
        close(tb.grad, _unbroadcast(fb(a, b, g), sb), rtol=1e-4, atol=1e-5)


@DEVS
def test_pow_backward(dev):
    a, b, g = np.abs(rn(4, 3)) + 0.5, rn(4, 3), rn(4, 3)
    ta, tb = T(a, dev), T(b, dev)
    tl.pow(ta, tb).backward(T(g, dev, False))
    out = a**b
    close(ta.grad, g * b * a**(b - 1), rtol=1e-3, atol=1e-4)
    close(tb.grad, g * out * np.log(a), rtol=1e-3, atol=1e-4)
    # tensor ** scalar and scalar ** tensor
    ta, tb = T(a, dev), T(b, dev)
    tl.pow(ta, 2.5).backward(T(g, dev, False))
    close(ta.grad, g * 2.5 * a**1.5, rtol=1e-3, atol=1e-4)
    tl.pow(2.0, tb).backward(T(g, dev, False))
    close(tb.grad, g * (2.0**b) * np.log(2.0), rtol=1e-3, atol=1e-4)


@DEVS
def test_pow_nonpositive_scalar_base_backward(dev):
    # a non-positive real base is NaN territory in the forward too (pow is
    # only real for integer exponents); the exponent grad is NaN, never a
    # math-domain exception
    for base in (-2.0, 0.0):
        tb = T(rn(3), dev)
        tl.pow(base, tb).backward(T(np.ones((3,), np.float32), dev, False))
        assert np.isnan(tb.grad.numpy()).all()


@DEVS
def test_scalar_operand_backward(dev):
    a, g = rn(4, 3), rn(4, 3)
    for fwd, ref in ((lambda x: x * 2.0, g * 2.0),
                     (lambda x: 2.0 * x, g * 2.0),
                     (lambda x: x / 2.0, g / 2.0),
                     (lambda x: 2.0 / x, -g * 2.0 / (a * a)),
                     (lambda x: x - 1.5, g),
                     (lambda x: 1.5 - x, -g),
                     (lambda x: x**2, g * 2 * a)):
        ta = T(a, dev)
        fwd(ta).backward(T(g, dev, False))
        close(ta.grad, ref, rtol=1e-4, atol=1e-5)


# ---------------------------------------------------------------------------
# elementwise unary
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("op", ["neg", "abs", "relu", "exp", "log", "sqrt",
                                "tanh", "sigmoid", "gelu", "silu"])
def test_unary_backward(dev, op):
    a = rn(4, 5) * 0.7
    if op in ("log", "sqrt"):
        a = np.abs(a) + 0.3
    g = rn(4, 5)
    ta = T(a, dev)
    getattr(tl, op)(ta).backward(T(g, dev, False))
    refs = {
        "neg": -g,
        "abs": g * np.sign(a),
        "relu": g * (a > 0),
        "exp": g * np.exp(a),
        "log": g / a,
        "sqrt": g * 0.5 / np.sqrt(a),
        "tanh": g * (1 - np.tanh(a)**2),
        "sigmoid": g * (1 / (1 + np.exp(-a))) * (1 - 1 / (1 + np.exp(-a))),
        "gelu": None, "silu": None,
    }
    if op == "gelu":
        from minitriton import precision as _prec
        if _prec.gelu_erf():
            import math
            refs[op] = g * (0.5 * (1 + np.vectorize(math.erf)(
                a * 0.7071067811865476))
                + 0.3989422804014327 * a * np.exp(-0.5 * a**2))
        else:
            c = 0.7978845608028654
            u = c * (a + 0.044715 * a**3)
            t = np.tanh(u)
            refs[op] = g * (0.5 * (1 + t) + 0.5 * a * (1 - t**2) * c
                            * (1 + 3 * 0.044715 * a**2))
    if op == "silu":
        s = 1 / (1 + np.exp(-a))
        refs[op] = g * (s * (1 + a * (1 - s)))
    close(ta.grad, refs[op], rtol=1e-3, atol=1e-4)


@DEVS
def test_log_sigmoid_backward(dev):
    """log_sigmoid records a grad edge like its unary siblings
    (d/dx log_sigmoid(x) = 1 - sigmoid(x)) — it used to bypass the tape
    (not in the autograd install mapping), so backward() raised
    'does not require grad and does not have a grad_fn'."""
    from minitriton.ops import log_sigmoid
    a = rn(4, 5) * 2.0
    g = rn(4, 5)
    ta = T(a, dev)
    log_sigmoid(ta).backward(T(g, dev, False))
    s = 1 / (1 + np.exp(-a))
    close(ta.grad, g * (1 - s), rtol=1e-3, atol=1e-4)


# ---------------------------------------------------------------------------
# matmul / bmm
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("M,N,K", [(4, 5, 3), (1, 1, 1), (16, 24, 40)])
def test_matmul_backward(dev, M, N, K):
    a, b, g = rn(M, K), rn(K, N), rn(M, N)
    ta, tb = T(a, dev), T(b, dev)
    tl.matmul(ta, tb).backward(T(g, dev, False))
    close(ta.grad, g @ b.T / np.sqrt(K) * np.sqrt(K), rtol=1e-4, atol=1e-4)
    close(tb.grad, a.T @ g, rtol=1e-4, atol=1e-4)


@DEVS
def test_bmm_backward(dev):
    a, b, g = rn(3, 4, 5), rn(3, 5, 2), rn(3, 4, 2)
    ta, tb = T(a, dev), T(b, dev)
    tl.bmm(ta, tb).backward(T(g, dev, False))
    close(ta.grad, g @ b.transpose(0, 2, 1), rtol=1e-4, atol=1e-4)
    close(tb.grad, a.transpose(0, 2, 1) @ g, rtol=1e-4, atol=1e-4)


@DEVS
def test_matmul_fold_leading_dims_backward(dev):
    """(B, T, K) @ (K, N) folds to a 2D matmul; grads must still flow."""
    a, b, g = rn(2, 3, 4), rn(4, 5), rn(2, 3, 5)
    ta, tb = T(a, dev), T(b, dev)
    out = tl.matmul(ta, tb)
    assert out.shape == (2, 3, 5)
    out.backward(T(g, dev, False))
    close(ta.grad, g @ b.T, rtol=1e-4, atol=1e-4)
    close(tb.grad, a.reshape(-1, 4).T @ g.reshape(-1, 5), rtol=1e-4,
          atol=1e-4)


# ---------------------------------------------------------------------------
# reductions
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("dim,keepdim", [(None, False), (None, True),
                                         (0, False), (1, False), (1, True),
                                         (-1, False)])
def test_sum_mean_backward(dev, dim, keepdim):
    a = rn(3, 4)
    if dim is None:
        g_shape = (1, 1) if keepdim else ()
    else:
        d = dim % a.ndim
        g_shape = a.shape[:d] + ((1,) if keepdim else ()) + a.shape[d + 1:]
    g = rn(*g_shape) if g_shape else rn(1)[0].reshape(())
    for name in ("sum", "mean"):
        ta = T(a, dev)
        n = a.size if dim is None else a.shape[dim % a.ndim]
        out = getattr(tl, name)(ta, dim=dim, keepdim=keepdim)
        out.backward(T(g, dev, False))
        ge = g
        if dim is None:
            ge = g.reshape((1,) * a.ndim) if not keepdim else g
        elif not keepdim:
            ge = np.expand_dims(g, dim)
        ref = np.broadcast_to(ge, a.shape).astype(np.float32)
        if name == "mean":
            ref = ref / n
        close(ta.grad, ref, rtol=1e-5, atol=1e-5)


@DEVS
def test_empty_mean_backward(dev):
    # mean over an empty extent is NaN in the forward; the backward gives
    # an empty gradient of the input shape, not a ZeroDivisionError
    ta = T(np.zeros((0,), np.float32), dev)
    out = ta.mean()
    assert np.isnan(out.numpy())
    out.backward(tl.tensor(np.float32(1.0), device=dev))
    assert ta.grad.shape == (0,)
    # empty along a reduced dim: same, per-output NaN and empty grad
    ta = T(np.zeros((0, 3), np.float32), dev)
    out = ta.mean(dim=0)
    assert np.isnan(out.numpy()).all()
    out.backward(T(np.ones((3,), np.float32), dev, False))
    assert ta.grad.shape == (0, 3)


@DEVS
def test_max_min_backward(dev):
    a = rn(4, 5)
    g = rn(4)
    for name in ("max", "min"):
        ta = T(a, dev)
        out = getattr(tl, name)(ta, dim=1)
        out.backward(T(g, dev, False))
        extreme = getattr(np, name)(a, axis=1, keepdims=True)
        ref = (a == extreme).astype(np.float32) * g[:, None]
        close(ta.grad, ref, rtol=1e-5, atol=1e-5)


# ---------------------------------------------------------------------------
# softmax / norms / embedding / cross_entropy
# ---------------------------------------------------------------------------

@DEVS
def test_softmax_backward(dev):
    a, g = rn(6, 8), rn(6, 8)
    ta = T(a, dev)
    tl.softmax(ta, dim=-1).backward(T(g, dev, False))
    z = a - a.max(1, keepdims=True)
    p = np.exp(z) / np.exp(z).sum(1, keepdims=True)
    close(ta.grad, p * (g - (g * p).sum(1, keepdims=True)), rtol=1e-4,
          atol=1e-5)


@DEVS
def test_log_softmax_backward(dev):
    a, g = rn(6, 8), rn(6, 8)
    ta = T(a, dev)
    tl.log_softmax(ta, dim=-1).backward(T(g, dev, False))
    z = a - a.max(1, keepdims=True)
    lsm = z - np.log(np.exp(z).sum(1, keepdims=True))
    close(ta.grad, g - np.exp(lsm) * g.sum(1, keepdims=True), rtol=1e-4,
          atol=1e-5)


@DEVS
@pytest.mark.parametrize("affine", [True, False])
def test_layer_norm_backward(dev, affine):
    a, g = rn(6, 8), rn(6, 8)
    w, b = rn(8), rn(8)
    tw = T(w, dev) if affine else None
    tb = T(b, dev) if affine else None
    ta = T(a, dev)
    tl.layer_norm(ta, (8,), tw, tb, 1e-5).backward(T(g, dev, False))
    mu = a.mean(1, keepdims=True)
    var = a.var(1, keepdims=True)
    rstd = 1.0 / np.sqrt(var + 1e-5)
    xh = (a - mu) * rstd
    u = g * w if affine else g
    dx = rstd * (u - u.mean(1, keepdims=True)
                 - xh * (u * xh).mean(1, keepdims=True))
    close(ta.grad, dx, rtol=1e-4, atol=1e-5)
    if affine:
        close(tw.grad, (g * xh).sum(0), rtol=1e-4, atol=1e-5)
        close(tb.grad, g.sum(0), rtol=1e-4, atol=1e-5)


@DEVS
@pytest.mark.parametrize("which", ["w_only", "b_only"])
def test_layer_norm_backward_partial_affine(dev, which):
    """weight-only / bias-only LN must take the fused path on cuda and
    still produce exact grads for the affine param that exists."""
    a, g = rn(6, 8), rn(6, 8)
    w, b = rn(8), rn(8)
    tw = T(w, dev) if which == "w_only" else None
    tb = T(b, dev) if which == "b_only" else None
    ta = T(a, dev)
    tl.layer_norm(ta, (8,), tw, tb, 1e-5).backward(T(g, dev, False))
    mu = a.mean(1, keepdims=True)
    var = a.var(1, keepdims=True)
    rstd = 1.0 / np.sqrt(var + 1e-5)
    xh = (a - mu) * rstd
    u = g * w if which == "w_only" else g
    dx = rstd * (u - u.mean(1, keepdims=True)
                 - xh * (u * xh).mean(1, keepdims=True))
    close(ta.grad, dx, rtol=1e-4, atol=1e-5)
    if which == "w_only":
        close(tw.grad, (g * xh).sum(0), rtol=1e-4, atol=1e-5)
    else:
        close(tb.grad, g.sum(0), rtol=1e-4, atol=1e-5)


@DEVS
@pytest.mark.parametrize("affine", [True, False])
def test_rms_norm_backward(dev, affine):
    a, g = rn(6, 8), rn(6, 8)
    w = rn(8)
    tw = T(w, dev) if affine else None
    ta = T(a, dev)
    tl.rms_norm(ta, (8,), tw, 1e-6).backward(T(g, dev, False))
    ms = (a * a).mean(1, keepdims=True)
    rstd = 1.0 / np.sqrt(ms + 1e-6)
    xr = a * rstd
    u = g * w if affine else g
    dx = rstd * (u - xr * (u * xr).mean(1, keepdims=True))
    close(ta.grad, dx, rtol=1e-4, atol=1e-5)
    if affine:
        close(tw.grad, (g * xr).sum(0), rtol=1e-4, atol=1e-5)


# ---------------------------------------------------------------------------
# fused ops (case-fusions)
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("sa,sb", [((4, 3), (4, 3)), ((4, 3), (3,)),
                                   ((4, 3), (4, 1)), ((2, 3, 4), (3, 4))])
def test_swiglu_backward(dev, sa, sb):
    a, b = rn(*sa), rn(*sb)
    g = rn(*np.broadcast_shapes(sa, sb))
    ta, tb = T(a, dev), T(b, dev)
    tl.swiglu(ta, tb).backward(T(g, dev, False))
    sig = 1 / (1 + np.exp(-a))
    close(ta.grad, _unbroadcast(g * sig * (1 + a * (1 - sig)) * b, sa),
          rtol=1e-4, atol=1e-5)
    close(tb.grad, _unbroadcast(g * a * sig, sb), rtol=1e-4, atol=1e-5)


def _ln_bw(g, s, w, eps=1e-5):
    """numpy reference: layer_norm backward on the last dim -> (ds, shat)."""
    mu = s.mean(-1, keepdims=True)
    rstd = 1.0 / np.sqrt(s.var(-1, keepdims=True) + eps)
    shat = (s - mu) * rstd
    u = g if w is None else g * w
    ds = rstd * (u - u.mean(-1, keepdims=True)
                 - shat * (u * shat).mean(-1, keepdims=True))
    return ds, shat


@DEVS
@pytest.mark.parametrize("affine", [True, False])
def test_add_layernorm_backward(dev, affine):
    x, r, g = rn(6, 8), rn(6, 8), rn(6, 8)
    w, b = rn(8), rn(8)
    tx, tr = T(x, dev), T(r, dev)
    tw = T(w, dev) if affine else None
    tb = T(b, dev) if affine else None
    tl.add_layernorm(tx, tr, (8,), tw, tb, 1e-5).backward(T(g, dev, False))
    ds, shat = _ln_bw(g, x + r, w if affine else None)
    close(tx.grad, ds, rtol=1e-4, atol=1e-5)  # dx: ds flows to both inputs
    close(tr.grad, ds, rtol=1e-4, atol=1e-5)
    if affine:
        close(tw.grad, (g * shat).sum(0), rtol=1e-4, atol=1e-5)
        close(tb.grad, g.sum(0), rtol=1e-4, atol=1e-5)


@DEVS
def test_add_layernorm_backward_residual_out(dev):
    """return_residual=True: grads of BOTH outputs flow into a and res."""
    x, r = rn(6, 8), rn(6, 8)
    w = rn(8)
    g1, g2 = rn(6, 8), rn(6, 8)
    tx, tr, tw = T(x, dev), T(r, dev), T(w, dev)
    y, s = tl.add_layernorm(tx, tr, (8,), tw, None, 1e-5,
                            return_residual=True)
    loss = tl.sum(tl.mul(y, T(g1, dev, False))) \
        + tl.sum(tl.mul(s, T(g2, dev, False)))
    loss.backward()
    ds, shat = _ln_bw(g1, x + r, w)
    close(tx.grad, ds + g2, rtol=1e-4, atol=1e-5)
    close(tr.grad, ds + g2, rtol=1e-4, atol=1e-5)
    close(tw.grad, (g1 * shat).sum(0), rtol=1e-4, atol=1e-5)


@DEVS
def test_add_layernorm_backward_3d(dev):
    x, r, g = rn(4, 8, 24), rn(4, 8, 24), rn(4, 8, 24)
    w = rn(24)
    tx, tr, tw = T(x, dev), T(r, dev), T(w, dev)
    tl.add_layernorm(tx, tr, (24,), tw, None, 1e-5).backward(T(g, dev, False))
    ds, shat = _ln_bw(g, x + r, w)
    close(tx.grad, ds, rtol=1e-4, atol=1e-5)
    close(tr.grad, ds, rtol=1e-4, atol=1e-5)
    close(tw.grad, (g * shat).sum((0, 1)), rtol=1e-4, atol=1e-5)


@DEVS
def test_embedding_backward_repeated_indices(dev):
    w = rn(10, 4)
    idx = np.array([1, 3, 3, 7, 1, 9, 3], dtype=np.int64)
    g = rn(7, 4)
    tw = T(w, dev)
    tl.embedding(tw, T(idx, dev, False)).backward(T(g, dev, False))
    ref = np.zeros_like(w)
    np.add.at(ref, idx, g)
    close(tw.grad, ref, rtol=1e-5, atol=1e-5)


@DEVS
@pytest.mark.parametrize("reduction", ["mean", "sum", "none"])
def test_cross_entropy_backward(dev, reduction):
    a = rn(6, 8)
    t = np.array([1, 4, 2, 0, 7, 5], dtype=np.int64)
    g = rn(6) if reduction == "none" else np.float32(0.7)
    ta = T(a, dev)
    tl.cross_entropy(ta, T(t, dev, False), reduction=reduction) \
        .backward(T(g, dev, False))
    z = a - a.max(1, keepdims=True)
    p = np.exp(z) / np.exp(z).sum(1, keepdims=True)
    p[np.arange(6), t] -= 1.0
    scale = g if reduction == "none" else \
        (g / 6.0 if reduction == "mean" else g)
    close(ta.grad, p * np.asarray(scale, dtype=np.float32)[:, None]
          if reduction == "none" else p * float(scale), rtol=1e-4, atol=1e-5)


@DEVS
@pytest.mark.parametrize("reduction", ["mean", "sum", "none"])
@pytest.mark.parametrize("rows,cols", [(4, 8193), (3, 32000), (2, 131072)])
def test_cross_entropy_backward_wide(dev, reduction, rows, cols):
    """Split-reduction CE backward (partials -> lse -> apply) vs the numpy
    (softmax - onehot) * g reference, across reductions and odd/wide
    vocab widths."""
    a = rn(rows, cols)
    t = rng.integers(0, cols, rows).astype(np.int64)
    g = rn(rows) if reduction == "none" else np.float32(0.7)
    ta = T(a, dev)
    tl.cross_entropy(ta, T(t, dev, False), reduction=reduction) \
        .backward(T(g, dev, False))
    z = a - a.max(1, keepdims=True)
    p = np.exp(z) / np.exp(z).sum(1, keepdims=True)
    p[np.arange(rows), t] -= 1.0
    scale = g if reduction == "none" else \
        (g / rows if reduction == "mean" else g)
    close(ta.grad, p * np.asarray(scale, dtype=np.float32)[:, None]
          if reduction == "none" else p * float(scale), rtol=1e-4, atol=1e-5)


@DEVS
def test_cross_entropy_backward_wide_262144(dev):
    """262144-column vocab: the widest split-reduction shape, fwd+bwd."""
    rows, cols = 2, 262144
    a = rn(rows, cols)
    t = rng.integers(0, cols, rows).astype(np.int64)
    ta = T(a, dev)
    loss = tl.cross_entropy(ta, T(t, dev, False))
    loss.backward()
    z = a - a.max(1, keepdims=True)
    nll = np.log(np.exp(z).sum(1)) + a.max(1) - a[np.arange(rows), t]
    close(loss, nll.mean(), rtol=1e-4)
    p = np.exp(z) / np.exp(z).sum(1, keepdims=True)
    p[np.arange(rows), t] -= 1.0
    close(ta.grad, p / rows, rtol=1e-4, atol=1e-5)


# ---------------------------------------------------------------------------
# views / movement ops
# ---------------------------------------------------------------------------

@DEVS
def test_reshape_backward(dev):
    a, g = rn(2, 3, 4), rn(4, 6)
    ta = T(a, dev)
    ta.reshape(4, 6).backward(T(g, dev, False))
    close(ta.grad, g.reshape(a.shape))


@DEVS
def test_permute_transpose_backward(dev):
    a, g = rn(2, 3, 4), rn(4, 2, 3)
    ta = T(a, dev)
    ta.permute(2, 0, 1).backward(T(g, dev, False))
    close(ta.grad, g.transpose(1, 2, 0))
    a2, g2 = rn(3, 5), rn(5, 3)
    ta2 = T(a2, dev)
    ta2.t().backward(T(g2, dev, False))
    close(ta2.grad, g2.T)


@DEVS
def test_slice_backward(dev):
    a = rn(6, 8)
    g = rn(2, 4)
    ta = T(a, dev)
    ta[1:5:2, 2:6].backward(T(g, dev, False))
    ref = np.zeros_like(a)
    ref[1:5:2, 2:6] = g
    close(ta.grad, ref)
    # negative step
    ta2 = T(a, dev)
    g2 = rn(6, 8)
    ta2[::-1].backward(T(g2, dev, False))
    close(ta2.grad, g2[::-1])


@DEVS
def test_int_index_backward(dev):
    a = rn(6, 8)
    g = rn(8)
    ta = T(a, dev)
    ta[3].backward(T(g, dev, False))
    ref = np.zeros_like(a)
    ref[3] = g
    close(ta.grad, ref)


@DEVS
def test_broadcast_to_backward(dev):
    a, g = rn(3, 1), rn(2, 3, 4)
    ta = T(a, dev)
    ta.broadcast_to((2, 3, 4)).backward(T(g, dev, False))
    close(ta.grad, g.sum(axis=(0, 2)).reshape(3, 1))


@DEVS
def test_cat_split_backward(dev):
    a, b, g = rn(2, 3), rn(2, 5), rn(2, 8)
    ta, tb = T(a, dev), T(b, dev)
    tl.cat([ta, tb], dim=1).backward(T(g, dev, False))
    close(ta.grad, g[:, :3])
    close(tb.grad, g[:, 3:])
    # split: grads of the parts are concatenated back
    c0, c1 = T(a, dev), T(b, dev)
    cat_ab = tl.cat([c0, c1], dim=1)
    p, q = tl.split(cat_ab, [3, 5], dim=1)
    (p.sum() + q.sum()).backward()
    close(c0.grad, np.ones_like(a))
    close(c1.grad, np.ones_like(b))


@DEVS
def test_unsqueeze_contiguous_backward(dev):
    a, g = rn(4), rn(1, 4, 1)
    ta = T(a, dev)
    ta.unsqueeze(0).unsqueeze(-1).contiguous().backward(T(g, dev, False))
    close(ta.grad, g.reshape(4))


# ---------------------------------------------------------------------------
# composite graphs / engine semantics
# ---------------------------------------------------------------------------

@DEVS
def test_mlp_end_to_end(dev):
    """Two-layer MLP + cross entropy: full analytic gradient check."""
    x, w1, b1, w2, b2 = rn(8, 6), rn(6, 10) * 0.3, rn(10), rn(10, 5) * 0.3, \
        rn(5)
    t = np.array([0, 2, 1, 4, 3, 2, 0, 1], dtype=np.int64)
    tx, tw1, tb1, tw2, tb2 = (T(v, dev) for v in (x, w1, b1, w2, b2))
    h = tl.relu(tl.matmul(tx, tw1) + tb1)
    logits = tl.matmul(h, tw2) + tb2
    loss = tl.cross_entropy(logits, T(t, dev, False))
    loss.backward()
    # numpy reference backward
    z1 = x @ w1 + b1
    h_n = np.maximum(z1, 0)
    z2 = h_n @ w2 + b2
    zz = z2 - z2.max(1, keepdims=True)
    p = np.exp(zz) / np.exp(zz).sum(1, keepdims=True)
    p[np.arange(8), t] -= 1.0
    dz2 = p / 8.0
    dw2 = h_n.T @ dz2
    db2 = dz2.sum(0)
    dh = dz2 @ w2.T
    dz1 = dh * (z1 > 0)
    dw1 = x.T @ dz1
    db1 = dz1.sum(0)
    assert abs(loss.item() - float((-np.log(
        np.exp(zz) / np.exp(zz).sum(1, keepdims=True)))[np.arange(8), t]
        .mean())) < 1e-5
    close(tw2.grad, dw2, rtol=1e-4, atol=1e-5)
    close(tb2.grad, db2, rtol=1e-4, atol=1e-5)
    close(tw1.grad, dw1, rtol=1e-4, atol=1e-5)
    close(tb1.grad, db1, rtol=1e-4, atol=1e-5)


@DEVS
def test_grad_accumulates_across_backward_calls(dev):
    a = rn(3, 3)
    ta = T(a, dev)
    (ta * 2.0).sum().backward()
    g1 = ta.grad.numpy().copy()
    (ta * 2.0).sum().backward()
    close(ta.grad, g1 * 2.0)


@DEVS
def test_no_grad_and_detach(dev):
    a = rn(3, 3)
    ta = T(a, dev)
    with tl.no_grad():
        y = ta * 2.0
    assert y.grad_fn is None and not y.requires_grad
    z = (ta * 3.0).detach()
    assert z.grad_fn is None and not z.requires_grad
    w = (ta * 4.0).sum()
    w.backward()
    close(ta.grad, np.full_like(a, 4.0))


@DEVS
def test_shared_subexpression_fanout(dev):
    """grad through a tensor used twice: (x*x).sum() -> 2x."""
    a = rn(4)
    ta = T(a, dev)
    (ta * ta).sum().backward()
    close(ta.grad, 2 * a)


@DEVS
def test_scalar_loss_implicit_grad(dev):
    a = rn(3)
    ta = T(a, dev)
    ta.sum().backward()  # no explicit grad
    close(ta.grad, np.ones(3, dtype=np.float32))


@DEVS
def test_mixed_requires_grad(dev):
    a, b = rn(4, 3), rn(4, 3)
    ta = T(a, dev, True)
    tb = T(b, dev, False)
    (ta * tb).sum().backward()
    close(ta.grad, b)
    assert tb.grad is None


@DEVS
def test_non_scalar_backward_requires_grad_arg(dev):
    a = rn(3)
    ta = T(a, dev)
    with pytest.raises(RuntimeError):
        (ta * 2).backward()


@DEVS
def test_int_tensor_cannot_require_grad(dev):
    with pytest.raises(RuntimeError):
        T(np.array([1, 2, 3], dtype=np.int64), dev, True)


@DEVS
def test_copy_alias_cannot_replay_consumed_tape(dev):
    # copy.copy shares the tensor's Node; a second backward entering
    # through the copy used to replay the consumed nodes with misrouted
    # (silently zero) grads — the node itself now carries the
    # consumed-tape flag, so every alias path raises.
    import copy
    a = rn(4)
    ta = T(a, dev)
    y = ta * 2
    c = copy.copy(y)      # c.grad_fn is the SAME node as y.grad_fn
    y.sum().backward()
    close(ta.grad, np.full(4, 2.0, np.float32))
    with pytest.raises(RuntimeError, match="second time"):
        (c * 3).sum().backward()


@DEVS
def test_second_backward_still_raises_on_original(dev):
    # the plain double-backward guard keeps working after the node-flag
    # move (root check and DFS check both go through it)
    a = rn(4)
    ta = T(a, dev)
    y = (ta * 2).sum()
    y.backward()
    with pytest.raises(RuntimeError, match="second time"):
        y.backward()
