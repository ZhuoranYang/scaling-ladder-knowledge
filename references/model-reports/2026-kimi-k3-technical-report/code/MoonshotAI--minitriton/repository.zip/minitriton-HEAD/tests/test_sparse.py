"""Sparse / message-passing primitive tests.

Every primitive is checked forward AND backward against numpy/scipy
references (np.add.at / take_along_axis / scipy.sparse.csr) on both cpu
and cuda, fp32 rtol 1e-5. The MatOff (materialized-index) builder path is
unit-tested directly with @tl.kernel gather load / scatter store /
atomic-scatter forms. No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import sparse

DEVS = pytest.mark.parametrize("dev", ["cpu", "cuda"])

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


def close(out, ref, rtol=1e-5, atol=1e-6):
    a = out.numpy() if isinstance(out, tl.Tensor) else out
    np.testing.assert_allclose(a, ref, rtol=rtol, atol=atol)


def T(x, dev, requires_grad=False):
    return tl.tensor(np.ascontiguousarray(x), device=dev,
                     requires_grad=requires_grad)


# ---------------------------------------------------------------------------
# gather
# ---------------------------------------------------------------------------

@DEVS
def test_gather_rows(dev):
    x_np = rn(32, 16)
    idx_np = rng.integers(0, 32, 50).astype(np.int64)
    x = T(x_np, dev, requires_grad=True)
    out = sparse.gather(x, tl.tensor(idx_np, device=dev), dim=0)
    close(out, x_np[idx_np])
    g_np = rn(50, 16)
    out.backward(T(g_np, dev))
    dx = np.zeros_like(x_np)
    np.add.at(dx, idx_np, g_np)
    close(x.grad, dx)


@DEVS
def test_gather_1d(dev):
    x_np = rn(64)
    idx_np = rng.integers(0, 64, 20).astype(np.int64)
    x = T(x_np, dev, requires_grad=True)
    out = sparse.gather(x, tl.tensor(idx_np, device=dev))
    close(out, x_np[idx_np])
    g_np = rn(20)
    out.backward(T(g_np, dev))
    dx = np.zeros_like(x_np)
    np.add.at(dx, idx_np, g_np)
    close(x.grad, dx)


@DEVS
@pytest.mark.parametrize("R,C,E", [(1, 1, 1), (3, 400, 1000), (17, 33, 9)])
def test_gather_dim1(dev, R, C, E):
    x_np = rn(R, C)
    idx_np = rng.integers(0, C, (R, E)).astype(np.int64)
    x = T(x_np, dev, requires_grad=True)
    out = sparse.gather(x, tl.tensor(idx_np, device=dev), dim=1)
    close(out, np.take_along_axis(x_np, idx_np, 1))
    g_np = rn(R, E)
    out.backward(T(g_np, dev))
    dx = np.zeros_like(x_np)
    np.add.at(dx, (np.arange(R)[:, None], idx_np), g_np)
    close(x.grad, dx)


@DEVS
@pytest.mark.parametrize("N,E,D", [(1, 1, 1), (24, 500, 37), (64, 64, 128)])
def test_gather_dim0_2d(dev, N, E, D):
    x_np = rn(N, D)
    idx_np = rng.integers(0, N, (E, D)).astype(np.int64)
    x = T(x_np, dev, requires_grad=True)
    out = sparse.gather(x, tl.tensor(idx_np, device=dev), dim=0)
    close(out, x_np[idx_np, np.arange(D)])
    g_np = rn(E, D)
    out.backward(T(g_np, dev))
    dx = np.zeros_like(x_np)
    np.add.at(dx, (idx_np, np.arange(D)), g_np)
    # ~E/N atomic f32 adds per slot land in arbitrary order, so the
    # rounding differs from sequential np.add.at: loosen atol
    close(x.grad, dx, atol=1e-5)


@DEVS
def test_gather_no_grad_path(dev):
    # raw forward without tape: same result
    x_np = rn(8, 4)
    idx_np = rng.integers(0, 8, (3, 4)).astype(np.int64)
    out = sparse.gather(T(x_np, dev), tl.tensor(idx_np, device=dev), dim=0)
    close(out, x_np[idx_np, np.arange(4)])
    assert out.grad_fn is None


@DEVS
def test_gather_index_bounds(dev):
    x_np = rn(8, 4)
    x = T(x_np, dev)
    for bad in (-1, 8):
        with pytest.raises(IndexError):
            sparse.gather(x, T(np.array([bad]), dev), dim=0)
    # grad path goes through the same check
    xg = T(x_np, dev, requires_grad=True)
    with pytest.raises(IndexError):
        sparse.gather(xg, T(np.array([-1]), dev), dim=0)
    # 1D x: same [0, N) rule
    with pytest.raises(IndexError):
        sparse.gather(T(rn(8), dev), T(np.array([8]), dev), dim=0)
    # dim=1 checks against the column count, 2D dim=0 against the rows
    with pytest.raises(IndexError):
        sparse.gather(x, T(np.full((8, 2), 4), dev), dim=1)
    with pytest.raises(IndexError):
        sparse.gather(x, T(np.full((8, 2), -1), dev), dim=1)
    with pytest.raises(IndexError):
        sparse.gather(x, T(np.full((2, 4), 8), dev), dim=0)
    idx = np.array([0, 7, 3])  # boundary rows are legal
    close(sparse.gather(x, T(idx, dev), dim=0), x_np[idx])


# ---------------------------------------------------------------------------
# scatter_add
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("E,N", [(1, 1), (1000, 64), (37, 5)])
def test_scatter_add_1d(dev, E, N):
    src_np = rn(E)
    idx_np = rng.integers(0, N, E).astype(np.int64)
    src = T(src_np, dev, requires_grad=True)
    out = sparse.scatter_add(src, tl.tensor(idx_np, device=dev), (N,))
    ref = np.zeros(N, dtype=np.float32)
    np.add.at(ref, idx_np, src_np)
    close(out, ref)
    g_np = rn(N)
    out.backward(T(g_np, dev))
    close(src.grad, g_np[idx_np])


@DEVS
@pytest.mark.parametrize("E,N,D", [(1, 1, 3), (128, 16, 33), (48, 7, 512)])
def test_scatter_add_2d(dev, E, N, D):
    src_np = rn(E, D)
    idx_np = rng.integers(0, N, E).astype(np.int64)
    src = T(src_np, dev, requires_grad=True)
    out = sparse.scatter_add(src, tl.tensor(idx_np, device=dev), (N, D))
    ref = np.zeros((N, D), dtype=np.float32)
    np.add.at(ref, idx_np, src_np)
    close(out, ref)
    g_np = rn(N, D)
    out.backward(T(g_np, dev))
    close(src.grad, g_np[idx_np])


@DEVS
def test_scatter_add_zero_edges(dev):
    if dev == "cpu":
        src_np, idx_np = np.zeros(0, np.float32), np.zeros(0, np.int64)
        src = tl.tensor(src_np, device=dev, requires_grad=False)
        idx = tl.tensor(idx_np, device=dev)
    else:  # cuda Buffers hold >= 1 element; zero rows become empty()
        src, idx = tl.empty((0,), device=dev), tl.empty((0,), dtype=tl.int32,
                                                        device=dev)
    out = sparse.scatter_add(src, idx, (4,))
    close(out, np.zeros(4, dtype=np.float32))
    if dev == "cpu":
        src2, idx2 = tl.tensor(np.zeros((0, 3), np.float32), device=dev), idx
    else:
        src2, idx2 = tl.empty((0, 3), device=dev), idx
    out2 = sparse.scatter_add(src2, idx2, (4, 3))
    close(out2, np.zeros((4, 3), dtype=np.float32))


@DEVS
def test_scatter_add_index_bounds(dev):
    src_np = rn(5)
    idx_ok = np.array([0, 2, 2, 6, 6])
    guard = T(np.ones(4, np.float32), dev)
    for bad in (-1, 7):
        idx = idx_ok.copy()
        idx[2] = bad
        with pytest.raises(IndexError):
            sparse.scatter_add(T(src_np, dev), T(idx, dev), (7,))
    # a rejected launch must not have touched unrelated memory
    close(guard, np.ones(4, np.float32))
    # 2D src: same row-range rule against out_shape[0]
    with pytest.raises(IndexError):
        sparse.scatter_add(T(rn(5, 3), dev),
                           T(np.array([0, 1, 2, 3, 7]), dev), (7, 3))
    ref = np.zeros(7, np.float32)
    np.add.at(ref, idx_ok, src_np)
    close(sparse.scatter_add(T(src_np, dev), T(idx_ok, dev), (7,)), ref)


# ---------------------------------------------------------------------------
# segment_reduce
# ---------------------------------------------------------------------------

def _seg_case(max_rows=11, max_len=9, allow_empty=True):
    lens = rng.integers(0 if allow_empty else 1, max_len,
                        rng.integers(1, max_rows))
    rp = np.concatenate([[0], np.cumsum(lens)]).astype(np.int64)
    v = rn(rp[-1]) if rp[-1] else np.zeros(0, dtype=np.float32)
    return v, rp


def _seg_ref(v, rp, op):
    out = np.zeros(len(rp) - 1, dtype=np.float32)
    for r, (s, e) in enumerate(zip(rp[:-1], rp[1:])):
        if e > s:
            out[r] = v[s:e].sum() if op == "sum" else v[s:e].max()
        elif op == "max":
            out[r] = float("-inf")
    return out


def _seg_bwd_ref(v, rp, g, op):
    gv = np.zeros_like(v)
    for r, (s, e) in enumerate(zip(rp[:-1], rp[1:])):
        if e <= s:
            continue
        if op == "sum":
            gv[s:e] = g[r]
        else:
            gv[s:e] = (v[s:e] == v[s:e].max()) * g[r]
    return gv


@DEVS
@pytest.mark.parametrize("op", ["sum", "max"])
def test_segment_reduce(dev, op):
    # fixed seeds make ties impossible; empty segments exercise the neutral
    # element rule (0 for sum, -inf for max)
    for v_np, rp_np in [_seg_case(), _seg_case(), _seg_case()]:
        v = T(v_np, dev, requires_grad=True)
        out = sparse.segment_reduce(v, tl.tensor(rp_np, device=dev), op=op)
        close(out, _seg_ref(v_np, rp_np, op))
        g_np = rn(len(rp_np) - 1)
        out.backward(T(g_np, dev))
        close(v.grad, _seg_bwd_ref(v_np, rp_np, g_np, op))


@DEVS
def test_segment_reduce_long_segments(dev):
    # segments longer than the kernel BLOCK chunk the loop multiple times
    rp = np.array([0, 3000, 3001, 8200], dtype=np.int64)
    v_np = rn(8200)
    for op in ("sum", "max"):
        v = T(v_np, dev, requires_grad=True)
        out = sparse.segment_reduce(v, tl.tensor(rp, device=dev), op=op)
        close(out, _seg_ref(v_np, rp, op), rtol=1e-5)
        g_np = rn(3)
        out.backward(T(g_np, dev))
        close(v.grad, _seg_bwd_ref(v_np, rp, g_np, op))


# ---------------------------------------------------------------------------
# spmm_csr
# ---------------------------------------------------------------------------

def _csr_case(R, K, density, rng=rng):
    from scipy.sparse import csr_matrix
    a = (np.random.default_rng(rng.integers(1 << 31))
         .standard_normal((R, K)).astype(np.float32)
         * (np.random.default_rng(0).random((R, K)) < density))
    m = csr_matrix(a)
    m.sum_duplicates()
    return (m.indptr.astype(np.int64), m.indices.astype(np.int64),
            m.data.astype(np.float32))


@DEVS
@pytest.mark.parametrize("R,K,N,d", [(1, 1, 1, 1.0), (8, 16, 24, 0.3),
                                     (33, 64, 130, 0.1), (64, 40, 7, 0.6)])
def test_spmm_csr(dev, R, K, N, d):
    from scipy.sparse import csr_matrix
    rp_np, col_np, val_np = _csr_case(R, K, d)
    b_np = rn(K, N)
    g_np = rn(R, N)
    rp = tl.tensor(rp_np, device=dev)
    col = tl.tensor(col_np, device=dev)
    val = T(val_np, dev, requires_grad=True)
    b = T(b_np, dev, requires_grad=True)
    out = sparse.spmm_csr(rp, col, val, b)
    ref = csr_matrix((val_np, col_np, rp_np), shape=(R, K)) @ b_np
    close(out, ref)
    out.backward(T(g_np, dev))
    dval_ref = np.zeros_like(val_np)
    db_ref = np.zeros_like(b_np)
    for r in range(R):
        s, e = rp_np[r], rp_np[r + 1]
        if e > s:
            dval_ref[s:e] = (b_np[col_np[s:e]] * g_np[r]).sum(axis=1)
            np.add.at(db_ref, col_np[s:e], val_np[s:e, None] * g_np[r])
    close(val.grad, dval_ref)
    close(b.grad, db_ref)


@DEVS
def test_spmm_csr_empty(dev):
    rp = np.zeros(5, dtype=np.int64)  # 4 empty rows
    col = np.zeros(0, dtype=np.int64)
    val = np.zeros(0, dtype=np.float32)
    b_np = rn(3, 8)
    if dev == "cpu":
        col_t = tl.tensor(col, device=dev)
        val_t = tl.tensor(val, device=dev, requires_grad=True)
    else:  # cuda Buffers hold >= 1 element; zero nnz becomes empty()
        col_t = tl.empty((0,), dtype=tl.int32, device=dev)
        val_t = tl.empty((0,), device=dev).requires_grad_(True)
    out = sparse.spmm_csr(tl.tensor(rp, device=dev), col_t, val_t,
                          T(b_np, dev, requires_grad=True))
    close(out, np.zeros((4, 8), dtype=np.float32))
    out.backward(T(rn(4, 8), dev))  # no crash on empty segments


# ---------------------------------------------------------------------------
# MatOff builder path: direct DSL unit tests
# ---------------------------------------------------------------------------

@tl.kernel
def _gather1d_kernel(x_ptr, idx_ptr, out_ptr, E, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < E
    idx = tl.load(idx_ptr + offs, mask=m)
    tl.store(out_ptr + offs, tl.load(x_ptr + idx, mask=m), mask=m)


@tl.kernel
def _scatter_atomic1d_kernel(src_ptr, idx_ptr, out_ptr, E,
                             BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < E
    idx = tl.load(idx_ptr + offs, mask=m)
    v = tl.load(src_ptr + offs, mask=m)
    tl.atomic_add(out_ptr + idx, v, mask=m)


@tl.kernel
def _matoff_2d_kernel(x_ptr, idx_ptr, out_ptr, C,
                      BR: tl.constexpr, BC: tl.constexpr):
    # 2D dist MatOff: out[r, c] = x[idx[r, c]] with a (BR, BC) index block
    offs_r = tl.arange(0, BR)[:, None] * C + tl.arange(0, BC)[None, :]
    idx = tl.load(idx_ptr + offs_r)
    tl.store(out_ptr + offs_r, tl.load(x_ptr + idx))


def test_matoff_dsl_1d():
    E, N = 777, 4096
    x_np = rn(N)
    idx_np = rng.integers(0, N, E).astype(np.int32)
    x, idx = T(x_np, "cuda"), T(idx_np, "cuda")
    out = tl.empty(E)
    _gather1d_kernel[((E + 255) // 256,)](x._buffer_arg(), idx._buffer_arg(),
                                          out._buffer_arg(), E, BLOCK=256,
                                          num_warps=4)
    close(out, x_np[idx_np])
    acc = tl.zeros(N)
    _scatter_atomic1d_kernel[((E + 255) // 256,)](
        out._buffer_arg(), idx._buffer_arg(), acc._buffer_arg(), E,
        BLOCK=256, num_warps=4)
    ref = np.zeros(N, dtype=np.float32)
    np.add.at(ref, idx_np, x_np[idx_np])
    close(acc, ref)


def test_matoff_dsl_2d():
    R, BC, N = 64, 128, 8192
    x_np = rn(N)
    idx_np = rng.integers(0, N, R * BC).astype(np.int32)
    out = tl.zeros(R * BC)
    _matoff_2d_kernel[(1,)](T(x_np, "cuda")._buffer_arg(),
                            T(idx_np, "cuda")._buffer_arg(),
                            out._buffer_arg(), BC, BR=R, BC=BC, num_warps=4)
    close(out, x_np[idx_np])


# ---------------------------------------------------------------------------
# searchsorted / coo_sort_by_key / cell_list
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("N,V", [(1, 1), (2, 9), (17, 3), (1000, 777),
                                 (8, 16), (1023, 129)])
@pytest.mark.parametrize("side", ["left", "right"])
def test_searchsorted_i32(dev, N, V, side):
    a_np = np.sort(rng.integers(-50, 50, N).astype(np.int32))
    v_np = rng.integers(-60, 60, V).astype(np.int32)
    out = sparse.searchsorted(T(a_np, dev), T(v_np, dev), side=side)
    assert out.dtype == tl.int32
    close(out, np.searchsorted(a_np, v_np, side=side))


@DEVS
@pytest.mark.parametrize("side", ["left", "right"])
def test_searchsorted_f32(dev, side):
    a_np = np.sort(rng.standard_normal(641).astype(np.float32))
    v_np = rng.standard_normal(133).astype(np.float32)
    out = sparse.searchsorted(T(a_np, dev), T(v_np, dev), side=side)
    close(out, np.searchsorted(a_np, v_np, side=side))


@DEVS
def test_coo_sort_by_key(dev):
    for N in (1, 3, 255, 257, 5000):
        keys_np = rng.integers(-100, 4096, N).astype(np.int32)
        sk, perm = sparse.coo_sort_by_key(T(keys_np, dev))
        skn, pn = sk.numpy(), perm.numpy()
        np.testing.assert_array_equal(skn, np.sort(keys_np))
        assert keys_np[pn].tolist() == skn.tolist()          # payload rides
        np.testing.assert_array_equal(np.sort(pn), np.arange(N))  # permutation


@DEVS
def test_coo_sort_by_key_f32_payload(dev):
    keys_np = rng.integers(0, 10, 333).astype(np.int32)
    vals_np = (rng.standard_normal(333) * 10).astype(np.float32)
    sk, sv = sparse.coo_sort_by_key(T(keys_np, dev), T(vals_np, dev))
    np.testing.assert_array_equal(sk.numpy(), np.sort(keys_np))
    perm = np.argsort(keys_np, kind="stable")  # stable ref; grouping must match
    for c in range(10):
        got = np.sort(sv.numpy()[sk.numpy() == c])
        ref = np.sort(vals_np[keys_np == c])
        np.testing.assert_allclose(got, ref, rtol=1e-7)


@DEVS
def test_cell_list(dev):
    keys_np = rng.integers(0, 256, 3000).astype(np.int32)
    rp, perm = sparse.cell_list(T(keys_np, dev), 256)
    rpn, pn = rp.numpy(), perm.numpy()
    np.testing.assert_array_equal(
        rpn, np.searchsorted(np.sort(keys_np), np.arange(257)))
    grouped = keys_np[pn]
    for c in (0, 7, 100, 255):
        seg = grouped[rpn[c]:rpn[c + 1]]
        assert (seg == c).all()
    np.testing.assert_array_equal(np.sort(pn), np.arange(3000))
