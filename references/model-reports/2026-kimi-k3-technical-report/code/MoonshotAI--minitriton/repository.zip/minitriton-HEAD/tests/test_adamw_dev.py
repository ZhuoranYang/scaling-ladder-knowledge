"""Device-scalar optimizer kernels (CUDA graph tail): clip_coef /
scale_dev / adamw_dev against the numpy oracle of the eager path
(nn.clip_grad_norm + ops.adamw_step semantics), including the
non-finite gate (skip-step) behavior. No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import ops
from minitriton.device.cuda import kernels as K
from minitriton.tensor import empty


def _oracle_adamw(p, g, m, v, lr_t, wd_lr, b1, b2, eps):
    mt = b1 * m + (1 - b1) * g
    vt = b2 * v + (1 - b2) * g * g
    pn = p - wd_lr * p - lr_t * mt / (np.sqrt(vt) + eps)
    return pn, mt, vt


@pytest.mark.parametrize("N", [1, 1024, 1 << 20, 999983])
def test_adamw_dev_matches_eager(N):
    rng = np.random.default_rng(0)
    p = rng.standard_normal(N).astype(np.float32) * 0.02
    g = rng.standard_normal(N).astype(np.float32) * 1e-3
    m = rng.standard_normal(N).astype(np.float32) * 1e-4
    v = np.abs(rng.standard_normal(N).astype(np.float32)) * 1e-6
    lr_t, wd_lr = 2.3e-4, 1e-5
    b1, b2, eps = 0.9, 0.95, 1e-8
    tp = tl.tensor(p.copy())
    tg = tl.tensor(g)
    tm = tl.tensor(m.copy())
    tv = tl.tensor(v.copy())
    sc = tl.tensor(np.array([lr_t, wd_lr, 1.0, 1.0], dtype=np.float32))
    K.launch_adamw_dev(tp, tg, tm, tv, N, sc, b1, b2, eps)
    tl.synchronize()
    pn, mn, vn = _oracle_adamw(p, g, m, v, lr_t, wd_lr, b1, b2, eps)
    np.testing.assert_allclose(tp.numpy(), pn, rtol=2e-6, atol=1e-9)
    np.testing.assert_allclose(tm.numpy(), mn, rtol=2e-6, atol=1e-12)
    np.testing.assert_allclose(tv.numpy(), vn, rtol=2e-6, atol=1e-14)


def test_adamw_dev_gate_holds_state():
    """gate=0 (non-finite step): params AND moments hold exactly, the
    host-side skip semantics."""
    rng = np.random.default_rng(1)
    N = 4096
    p = rng.standard_normal(N).astype(np.float32)
    g = rng.standard_normal(N).astype(np.float32)
    m = rng.standard_normal(N).astype(np.float32)
    v = np.abs(rng.standard_normal(N).astype(np.float32))
    tp = tl.tensor(p.copy())
    tg = tl.tensor(g)
    tm = tl.tensor(m.copy())
    tv = tl.tensor(v.copy())
    sc = tl.tensor(np.array([1.0, 1.0, 0.5, 0.0], dtype=np.float32))
    K.launch_adamw_dev(tp, tg, tm, tv, N, sc, 0.9, 0.95, 1e-8)
    tl.synchronize()
    assert np.array_equal(tp.numpy(), p)
    assert np.array_equal(tm.numpy(), m)
    assert np.array_equal(tv.numpy(), v)


@pytest.mark.parametrize("total,max_norm,eps,want_clip,want_gate", [
    (4.0, 1.0, 1e-6, 0.5, 1.0),      # norm 2 > max: clip to 0.5
    (0.25, 1.0, 1e-6, 1.0, 1.0),     # norm 0.5 < max: no clip
    (float("inf"), 1.0, 1e-6, 0.0, 0.0),
    (float("nan"), 1.0, 1e-6, 0.0, 0.0),
])
def test_clip_coef(total, max_norm, eps, want_clip, want_gate):
    tt = tl.tensor(np.array([total], dtype=np.float32))
    sc = tl.tensor(np.zeros(4, dtype=np.float32))
    K.launch_clip_coef(tt, sc, max_norm, eps)
    tl.synchronize()
    got = sc.numpy()
    assert np.allclose(got[2], want_clip * want_gate or want_clip, atol=1e-7) \
        or np.allclose(got[2], want_clip, atol=1e-7)
    assert got[3] == want_gate


@pytest.mark.parametrize("N", [1024, 999983])
def test_adamw_dev_torch_eps(N):
    """TORCH_EPS branch with s2 riding the device buffer (S2_DEV=1, the
    CUDA-graph path): p -= lr_t*mt/(sqrt(vt)/s2 + eps)."""
    rng = np.random.default_rng(3)
    p = rng.standard_normal(N).astype(np.float32) * 0.02
    g = rng.standard_normal(N).astype(np.float32) * 1e-3
    m = rng.standard_normal(N).astype(np.float32) * 1e-4
    v = np.abs(rng.standard_normal(N).astype(np.float32)) * 1e-6
    lr_t, wd_lr, s2 = 2.3e-4, 1e-5, 0.7071
    b1, b2, eps = 0.9, 0.95, 1e-8
    tp = tl.tensor(p.copy())
    tg = tl.tensor(g)
    tm = tl.tensor(m.copy())
    tv = tl.tensor(v.copy())
    sc = tl.tensor(np.array([lr_t, wd_lr, 1.0, 1.0, s2], dtype=np.float32))
    K.launch_adamw_dev(tp, tg, tm, tv, N, sc, b1, b2, eps,
                       torch_eps=True, s2_dev=True)
    tl.synchronize()
    mt = b1 * m + (1 - b1) * g
    vt = b2 * v + (1 - b2) * g * g
    pn = p - wd_lr * p - lr_t * mt / (np.sqrt(vt) / s2 + eps)
    np.testing.assert_allclose(tp.numpy(), pn, rtol=2e-6, atol=1e-9)


def test_scale_dev():
    rng = np.random.default_rng(2)
    N = 100_000
    x = rng.standard_normal(N).astype(np.float32)
    tx = tl.tensor(x)
    out = tl.empty(N, tl.float32, "cuda")
    sc = tl.tensor(np.array([0.0, 0.0, 0.25, 1.0], dtype=np.float32))
    K.launch_scale_dev(tx, out, sc, 2)
    tl.synchronize()
    np.testing.assert_allclose(out.numpy(), x * 0.25, rtol=0, atol=0)
