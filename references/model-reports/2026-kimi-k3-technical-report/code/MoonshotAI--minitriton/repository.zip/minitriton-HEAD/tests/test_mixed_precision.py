"""bf16 mixed-precision training tests: GradScaler
dynamics, BF16AdamW fp32-master consistency, embedding bf16 backward,
and the NaN guard flow. CUDA only (bf16 has no numpy dtype; the CPU
backend never sees bf16). numpy/fp64 is the oracle. No torch."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import nn

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


def bf16_round(x):
    """f32 -> bf16 -> f32 round trip (round to nearest even), in numpy."""
    x = np.ascontiguousarray(x, dtype=np.float32)
    u = x.view(np.uint32)
    return ((u + 0x7FFF + ((u >> 16) & 1)) & 0xFFFF0000).view(np.float32)


def make_bf16_param(arr):
    """A leaf bf16 Parameter on cuda from a numpy f32 array (the same
    construct as train_gpt's _convert_bf16_: cast under no_grad, then
    re-mark as a leaf that accumulates grads)."""
    with tl.no_grad():
        t = tl.tensor(np.ascontiguousarray(arr), device="cuda") \
            .astype(tl.bfloat16)
    p = nn.Parameter(np.zeros(arr.shape, dtype=np.float32), device="cuda")
    with tl.no_grad():
        p._steal(t)
    p.requires_grad = True
    p.grad = None
    return p


# ---------------------------------------------------------------------------
# GradScaler
# ---------------------------------------------------------------------------

def test_grad_scaler_scale_loss_and_unscale():
    x = tl.tensor([2.0], device="cuda", requires_grad=True)
    scaler = nn.GradScaler(init_scale=8.0)
    # scale_loss multiplies the loss value by the scale
    loss = scaler.scale_loss(x * x).sum()
    assert loss.item() == pytest.approx(32.0)
    p = nn.Parameter(rn(3, 3), device="cuda")
    p.grad = tl.tensor(np.full((3, 3), 4.0, dtype=np.float32), device="cuda")
    scaler.unscale_([p])
    np.testing.assert_allclose(p.grad.numpy(),
                               np.full((3, 3), 0.5, dtype=np.float32),
                               rtol=1e-6)


def test_grad_scaler_unscale_exact_pow2_and_f32():
    # bf16 grads unscale exactly for a power-of-two scale, and become f32
    p = make_bf16_param(rn(4, 4))
    p.grad = make_bf16_param(rn(4, 4)).detach()
    scaler = nn.GradScaler(init_scale=2.0 ** 15)
    ref = p.grad.numpy() / 2.0 ** 15
    scaler.unscale_([p])
    assert p.grad.dtype == tl.float32
    np.testing.assert_array_equal(p.grad.numpy(), ref)


def test_grad_scaler_update_dynamics():
    s = nn.GradScaler(init_scale=1024.0, growth_interval=3)
    s.update(False)
    assert s.scale == 1024.0
    s.update(True)  # inf: halve + reset the streak
    assert s.scale == 512.0
    s.update(False)
    s.update(False)
    assert s.scale == 512.0
    s.update(False)  # 3 consecutive good steps: double
    assert s.scale == 1024.0
    s.update(True)  # reset again
    s.update(False)
    s.update(False)
    assert s.scale == 512.0


# ---------------------------------------------------------------------------
# BF16AdamW
# ---------------------------------------------------------------------------

def _ref_adamw(p0, grads, lr=0.05, betas=(0.9, 0.95), eps=1e-8, wd=0.1):
    """numpy fp32 AdamW, matching nn.AdamW's eps placement
    (default: torch-exact; MT_ADAMW_FOLDED_EPS=1: folded-lr_t)."""
    from minitriton import precision as _prec
    torch_eps = _prec.adamw_eps()
    m = np.zeros_like(p0)
    v = np.zeros_like(p0)
    p = p0.copy()
    b1, b2 = betas
    for t, g in enumerate(grads, 1):
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        if torch_eps:
            lr_t = lr / (1 - b1 ** t)
            denom = np.sqrt(v) / np.sqrt(1 - b2 ** t) + eps
        else:
            lr_t = lr * np.sqrt(1 - b2 ** t) / (1 - b1 ** t)
            denom = np.sqrt(v) + eps
        p = p - lr * wd * p - lr_t * m / denom
    return p


def test_bf16_adamw_master_and_param_consistency():
    p0 = rn(4, 5)
    p = make_bf16_param(p0)
    opt = nn.BF16AdamW([p], lr=0.05, betas=(0.9, 0.95), eps=1e-8,
                       weight_decay=0.1)
    # master starts as the fp32 copy of the bf16-rounded parameter
    np.testing.assert_array_equal(opt._master[0].numpy(), bf16_round(p0))
    assert opt._master[0].dtype == tl.float32
    grads = [rn(4, 5) for _ in range(4)]
    for g in grads:
        p.grad = tl.tensor(g, device="cuda")
        opt.step()
    ref = _ref_adamw(bf16_round(p0), grads)
    with tl.no_grad():
        master_now = opt._master[0].numpy()
    # master tracks the fp32 reference (same kernel as AdamW); the
    # torch-eps branch divides by s2 in-kernel (one more fp32 rounding
    # than the folded form), so its fp32-vs-float64 op-order noise on
    # the smallest elements needs atol 1e-8 instead of bit-tight 1e-9
    from minitriton import precision as _prec
    np.testing.assert_allclose(
        master_now, ref, rtol=1e-6,
        atol=1e-8 if _prec.adamw_eps() else 1e-9)
    # the bf16 param is the master rounded to bf16 (allow 1 bf16 ulp)
    got = p.numpy()
    want = bf16_round(master_now)
    ulp = np.maximum(np.abs(want), 1e-30) * 2 ** -8 + 1e-20
    assert np.all(np.abs(got - want) <= ulp), \
        f"param != bf16(master): max diff {np.abs(got - want).max():.3e}"
    # moment state is fp32
    for st in opt._inner._state.values():
        assert st[0].dtype == tl.float32 and st[1].dtype == tl.float32


def test_bf16_adamw_accumulates_subresolution_updates():
    # an update smaller than the bf16 resolution of the weight is not lost
    # (it lands in the fp32 master and eventually flips the bf16 param)
    p0 = np.full((64,), 1.0, dtype=np.float32)
    p = make_bf16_param(p0)
    opt = nn.BF16AdamW([p], lr=1e-3, betas=(0.9, 0.95), weight_decay=0.0)
    g = np.full((64,), 1e-2, dtype=np.float32)  # update ~ lr*1 ~ 1e-3
    for _ in range(20):
        p.grad = tl.tensor(g, device="cuda")
        opt.step()
    assert not np.array_equal(p.numpy(), p0), \
        "20 sub-resolution updates left the bf16 param unchanged"


def test_bf16_adamw_skips_none_grad_and_keeps_identity():
    p1 = make_bf16_param(rn(3, 3))
    p2 = make_bf16_param(rn(5))
    store1 = p1._storage
    opt = nn.BF16AdamW([p1, p2], lr=0.01)
    p1.grad = tl.tensor(rn(3, 3), device="cuda")
    p2.grad = None
    m2_before = opt._master[1].numpy()
    opt.step()  # p2 untouched; storages/identity preserved
    assert p1._storage is store1
    np.testing.assert_array_equal(opt._master[1].numpy(), m2_before)
    assert opt.t == 1


def test_bf16_adamw_masters_override_and_f32_no_alias():
    p0 = rn(4, 5)
    p = make_bf16_param(p0)
    custom = rn(4, 5)  # stands in for the unrounded fp32 original
    m = tl.tensor(np.ascontiguousarray(custom), device="cuda")
    opt = nn.BF16AdamW([p], lr=0.05, masters={id(p): m})
    np.testing.assert_array_equal(opt._master[0].numpy(), custom)
    # an fp32 param gets a REAL fp32 copy as master (no storage alias)
    p32 = nn.Parameter(p0.copy(), device="cuda")
    opt2 = nn.BF16AdamW([p32], lr=0.05)
    assert opt2._master[0]._storage is not p32._storage
    np.testing.assert_array_equal(opt2._master[0].numpy(), p0)
    p32.grad = tl.tensor(rn(4, 5), device="cuda")
    before = p32.numpy().copy()
    opt2.step()
    after = p32.numpy()
    assert not np.array_equal(before, after)
    np.testing.assert_allclose(after, opt2._master[0].numpy(), rtol=1e-6)


# ---------------------------------------------------------------------------
# embedding backward (bf16): f32 scatter-add, cast back (nn contract)
# ---------------------------------------------------------------------------

def test_embedding_backward_bf16():
    V, C, R = 7, 8, 64
    w = make_bf16_param(rn(V, C))
    idx_np = rng.integers(0, V, size=R).astype(np.int64)
    idx = tl.tensor(idx_np, device="cuda")
    g = make_bf16_param(rn(R, C)).detach()
    emb = nn.Embedding(V, C, device="cuda")
    with tl.no_grad():
        emb.weight._steal(w)
    emb.weight.requires_grad = True
    out = emb(idx)
    out.backward(g)
    ref = np.zeros((V, C), dtype=np.float32)
    for i, r in enumerate(idx_np):
        ref[r] += bf16_round(g.numpy())[i]
    want = bf16_round(ref)
    got = emb.weight.grad.numpy()
    assert emb.weight.grad.dtype == tl.bfloat16
    np.testing.assert_allclose(got, want, rtol=2e-2, atol=1e-3)


# ---------------------------------------------------------------------------
# NaN guard end-to-end (scaler + clip + skip)
# ---------------------------------------------------------------------------

def test_nan_guard_skips_step_and_purges():
    import math
    p = make_bf16_param(rn(4, 4))
    opt = nn.BF16AdamW([p], lr=0.1)
    scaler = nn.GradScaler(init_scale=1024.0)
    master0 = opt._master[0].numpy()
    # one good step
    p.grad = tl.tensor(rn(4, 4), device="cuda")
    scaler.unscale_([p])
    total = nn.clip_grad_norm([p], 1.0)
    assert math.isfinite(total)
    opt.step()
    scaler.update(False)
    assert not np.array_equal(opt._master[0].numpy(), master0)
    master1 = opt._master[0].numpy()
    # poisoned step: inf grad -> norm non-finite -> skip + backoff
    p.grad = tl.tensor(np.full((4, 4), np.inf, dtype=np.float32),
                       device="cuda")
    scaler.unscale_([p])
    total = nn.clip_grad_norm([p], 1.0)
    assert not math.isfinite(total)
    if math.isfinite(total):
        opt.step()
    else:
        p.grad = None  # purge, as the train loop does via zero_grad
    scaler.update(True)
    assert scaler.scale == 512.0
    np.testing.assert_array_equal(opt._master[0].numpy(), master1)


# ---------------------------------------------------------------------------
# one-step numeric agreement: bf16 Linear+scaler vs fp32, bf16 tolerance
# ---------------------------------------------------------------------------

def test_bf16_linear_step_tracks_fp32():
    x_np, w0 = rn(16, 8), rn(8, 8)
    def run(dtype):
        w = make_bf16_param(w0) if dtype == "bf16" else \
            nn.Parameter(w0.copy(), device="cuda")
        x = tl.tensor(x_np, device="cuda")
        if dtype == "bf16":
            with tl.no_grad():
                x = x.astype(tl.bfloat16)
        y = tl.matmul(x, w)
        if dtype == "bf16":
            y = y.astype(tl.float32)
        loss = tl.sum(y * y)
        loss.backward()
        return w, loss.item()
    wb, lb = run("bf16")
    wf, lf = run("fp32")
    assert lb == pytest.approx(lf, rel=2e-2)
    ref = wb.grad.numpy()
    grd = wf.grad.numpy()
    # bf16 tolerance 2e-2 on the rel L2 of the whole grad
    # tensor: per-element rel error is meaningless
    # near zero, where one bf16 rounding of the forward output is O(1)
    rel_l2 = np.linalg.norm(ref - grd) / np.linalg.norm(grd)
    assert rel_l2 < 2e-2, f"grad rel L2 {rel_l2:.4f}"


# ---------------------------------------------------------------------------
# bf16 g_pre contract (gelu_bw stores bf16; mma consumers bit-identical)
# ---------------------------------------------------------------------------

def test_gelu_backward_edge_dtype_contract():
    # the grad of a bf16-valued interior edge stores bf16 (torch AMP's
    # own semantics); an fp32 edge stays f32
    from minitriton.autograd import functions as _f  # noqa: F401
    x_np = rn(64, 128)
    g_np = rn(64, 128)
    xb = make_bf16_param(x_np)
    y = tl.gelu(xb)
    y.backward(tl.tensor(g_np, device="cuda"))
    assert xb.grad.dtype == tl.bfloat16
    # the bf16 store is the same round-to-nearest as a materialized
    # astype of the f32 route
    from minitriton.device.cuda import ops as be
    from minitriton.device.cuda import elementwise as be_ew
    from minitriton.frontend import types as tl_types
    gp32 = be_ew.binary("gelu_bw", tl.tensor(g_np, device="cuda"),
                     xb.detach(), tl_types.float32)
    want = bf16_round(gp32.numpy())
    np.testing.assert_array_equal(xb.grad.numpy(), want)
    # fp32 edge: unchanged (f32 out, computed from the f32 pre-image)
    x32 = nn.Parameter(x_np.copy(), device="cuda")
    tl.gelu(x32).backward(tl.tensor(g_np, device="cuda"))
    assert x32.grad.dtype == tl.float32
    gp32f = be_ew.binary("gelu_bw", tl.tensor(g_np, device="cuda"),
                      x32.detach(), tl_types.float32)
    np.testing.assert_array_equal(x32.grad.numpy(), gp32f.numpy())


def test_linear_gelu_backward_bf16_consumers_bit_identical():
    # the real chain (fc Linear -> gelu, upstream grad f32): da/dw must
    # be BIT-IDENTICAL to the f32-g_pre route (the store's cvt.rn is the
    # in-kernel pack's rounding; K < 4096 keeps both routes off split-K
    # so the accumulation order is fixed), dbias f32 with only the
    # pre-sum bf16 rounding (fp64 oracle).
    from minitriton.device.cuda import ops as be
    from minitriton.device.cuda import elementwise as be_ew
    from minitriton.frontend import types as tl_types
    from minitriton.autograd import functions as _f
    M, K, N = 1000, 136, 520  # masked mma path (EVEN_MN False), K < 4096
    x_np, w_np, b_np, g_np = rn(M, K), rn(N, K), rn(N), rn(M, N)
    x = make_bf16_param(x_np)
    w = make_bf16_param(w_np)
    b = make_bf16_param(b_np)
    h = tl.gelu(_f.linear(x, w, b))
    h.backward(tl.tensor(g_np, device="cuda"))
    # reference via the f32 g_pre route (pre recomputed under no_grad)
    with tl.no_grad():
        wt = w.detach().t()
        pre = be.matmul_bf16(x.detach(), wt, out_dtype=tl_types.bfloat16,
                             bias=b.detach())
        gp32 = be_ew.binary("gelu_bw", tl.tensor(g_np, device="cuda"), pre,
                         tl_types.float32)
        da_ref = be.matmul_bf16(gp32, w.detach(), out_dtype=tl_types.float32)
        dw_ref = be.matmul_bf16(gp32.t(), x.detach(),
                                out_dtype=tl_types.float32)
    assert x.grad.dtype == tl.float32 and w.grad.dtype == tl.float32
    assert b.grad.dtype == tl.float32
    np.testing.assert_array_equal(x.grad.numpy(), da_ref.numpy())
    np.testing.assert_array_equal(w.grad.numpy(), dw_ref.numpy())
    # dbias: colsum of the bf16-rounded g_pre, f32 accumulate
    ref = bf16_round(gp32.numpy()).astype(np.float64).sum(axis=0)
    np.testing.assert_allclose(b.grad.numpy(), ref, rtol=1e-5, atol=1e-5)


def test_colsum_bf16_to_f32():
    # the (bf16 in, f32 out) column-sum gate: direct colsum route,
    # f32 accumulation, matches the fp64 oracle and the f32-cast route
    a_np = rn(4096, 640)
    a = tl.tensor(a_np, device="cuda").astype(tl.bfloat16)
    s = a.sum(dim=0, dtype=tl.float32)
    assert s.dtype == tl.float32
    ref = bf16_round(a_np).astype(np.float64).sum(axis=0)
    np.testing.assert_allclose(s.numpy(), ref, rtol=1e-5, atol=1e-5)
    s32 = a.astype(tl.float32).sum(dim=0)
    np.testing.assert_allclose(s.numpy(), s32.numpy(), rtol=1e-5,
                               atol=1e-5)


def _bf16m(x):
    """f64 oracle for a bf16 mma product: bf16-round operands, f32-ish
    matmul, bf16-round the output (RN, matching the kernel's pack)."""
    return _bf16_round(_bf16_round(x[0]) @ _bf16_round(x[1]))


from test_fusion import _bf16_round


def test_matmul_bf16_bias_all_ndims():
    # regression: the bias kwarg was silently dropped on the 1D/batched
    # branches of matmul_bf16 (public path: ops.matmul(a, b, bias=c);
    # ops.matmul already rejects bias for non-2D rhs loudly)
    from minitriton import ops as _o
    from minitriton.device.cuda import ops as _be
    rng = np.random.default_rng(3)
    a1 = rng.standard_normal(48).astype(np.float32)
    a2 = rng.standard_normal((8, 48)).astype(np.float32)
    b2 = rng.standard_normal((48, 32)).astype(np.float32)
    b1 = rng.standard_normal(48).astype(np.float32)
    a3 = rng.standard_normal((2, 8, 48)).astype(np.float32)
    b3 = rng.standard_normal((2, 48, 16)).astype(np.float32)
    bias = rng.standard_normal(32).astype(np.float32)
    b1s = rng.standard_normal(1).astype(np.float32)
    b16 = rng.standard_normal(16).astype(np.float32)

    def T(x):
        return tl.tensor(x).astype(tl.bfloat16)

    def ref(x, y, c):
        return _bf16_round(_bf16_round(x) @ _bf16_round(y) + c)

    def be_mm(x, y, c):
        return _be.matmul_bf16(T(x), T(y),
                               bias=T(c)).astype(tl.float32).numpy()

    # 1D @ 2D / 2D @ 2D / nd @ 2D — public ops.matmul path (the case
    # that used to drop the bias): bias must land in the fused epilogue
    def o_mm(x, y, c):
        return _o.matmul(T(x), T(y), bias=T(c)).astype(tl.float32).numpy()

    np.testing.assert_allclose(o_mm(a1, b2, bias),
                               ref(a1.reshape(1, -1), b2, bias).reshape(-1),
                               rtol=2e-2, atol=2e-2)
    np.testing.assert_allclose(o_mm(a2, b2, bias), ref(a2, b2, bias),
                               rtol=2e-2, atol=2e-2)
    np.testing.assert_allclose(o_mm(a3, b2, bias), ref(a3, b2, bias),
                               rtol=2e-2, atol=2e-2)
    # 1D @ 1D / 2D @ 1D — forwarded through the reshape to the 2D path
    np.testing.assert_allclose(be_mm(a1, b1, b1s), ref(a1, b1, b1s[0]),
                               rtol=2e-2, atol=2e-2)
    np.testing.assert_allclose(be_mm(a2, b1, b1s),
                               ref(a2, b1.reshape(-1, 1), b1s[0]).reshape(-1),
                               rtol=2e-2, atol=2e-2)
    # compiled == eager on the nd@2D branch
    @tl.compile
    def f(x, y, c):
        return _o.matmul(x, y, bias=c)
    ce = f(T(a3), T(b2), T(bias)).astype(tl.float32).numpy()
    np.testing.assert_allclose(ce, ref(a3, b2, bias), rtol=2e-2, atol=2e-2)
    # batched + bias via the backend: loud, not silent
    with pytest.raises(NotImplementedError):
        be_mm(a3, b3, b16)
    # batched + bias via the public layer: also loud (ops-layer guard)
    with pytest.raises(RuntimeError):
        o_mm(a3, b3, b16)


def test_matmul_bf16_bias_out_dtype_guard():
    a = tl.tensor(np.ones((4, 8), np.float32)).astype(tl.bfloat16)
    b = tl.tensor(np.ones((8, 4), np.float32)).astype(tl.bfloat16)
    c = tl.tensor(np.ones(4, np.float32)).astype(tl.bfloat16)
    with pytest.raises(ValueError):
        from minitriton.device.cuda import ops as _be
        _be.matmul_bf16(a, b, out_dtype=tl.float32, bias=c)
