"""Fusion rule engine (fusion.py): registry /
env-gate / stats, per-rule positive+negative matching. Oracles: numpy
where exact, otherwise the same function evaluated on the plain eager
path (fusion must not change results). The legacy-equivalence test pins
the fallback path: with the three new rules disabled, planning is
identical to the two-pattern _plan.
"""

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import fusion as _fusion
from minitriton import ops as _ops

rng = np.random.default_rng(0)

_NEW_RULES = "r3_cast_fold,r4_bw_chain,r8_trans_contig,r2v_mm_v2_epilogue"


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


def _only_spec(cf):
    exe = list(cf._cache.values())[0]
    assert len(exe.fused) == 1
    return list(exe.fused.values())[0]


def _last_stats():
    st = _fusion.stats()
    assert st, "no plan() stats recorded"
    return st[-1]


@pytest.fixture(autouse=True)
def _clean_stats():
    _fusion.reset_stats()
    yield
    _fusion.reset_stats()


# ---------------------------------------------------------------------------
# engine: registry, env gate, stats, legacy equivalence
# ---------------------------------------------------------------------------

def test_legacy_equivalence_when_new_rules_disabled(monkeypatch):
    """New rules off -> planning identical to the two-pattern _plan."""
    monkeypatch.setenv("MT_FUSION_RULES", _NEW_RULES)

    @tl.compile
    def f(x, y):
        return tl.sigmoid(tl.tanh(x * y + 2.0) * 0.5 + tl.exp(x))

    x, y = rn(64, 96), rn(64, 96)
    out = f(tl.tensor(x), tl.tensor(y))
    ref = 1 / (1 + np.exp(-(np.tanh(x * y + 2.0) * 0.5 + np.exp(x))))
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-4, atol=1e-5)
    spec = _only_spec(f)
    assert spec["type"] == "ew_chain" and len(spec["members"]) == 7
    st = _last_stats()
    assert st["rules"]["r1_ew_chain"]["hit"] == 1
    assert "r3_cast_fold" not in st["rules"]  # disabled rules do not plan

    @tl.compile
    def g(x, w, b):
        return tl.gelu(tl.matmul(x, w) + b)

    x, w, b = rn(128, 64), rn(64, 96), rn(96)
    out = g(tl.tensor(x), tl.tensor(w), tl.tensor(b))
    z = x @ w + b
    ref = _gelu_np(z)  # flag-aware: erf default / tanh opt-out
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-3, atol=1e-4)
    assert _only_spec(g)["type"] == "mm_epilogue"
    assert _last_stats()["rules"]["r2_mm_epilogue"]["hit"] == 1


def test_env_gate_disables_ew_chain(monkeypatch):
    monkeypatch.setenv("MT_FUSION_RULES",
                       "r1_ew_chain,r3_cast_fold,r4_bw_chain")

    @tl.compile
    def f(x):
        return tl.sigmoid(x * 2.0 + tl.exp(x))

    x = rn(32, 48)
    out = f(tl.tensor(x))
    ref = 1 / (1 + np.exp(-(x * 2.0 + np.exp(x))))
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-4, atol=1e-5)
    exe = list(f._cache.values())[0]
    assert len(exe.fused) == 0  # every ew rule off -> pure eager replay


def test_stats_group_and_node_counts():
    @tl.compile
    def f(x, y):
        return tl.relu(x * y) + 1.0

    f(tl.tensor(rn(16, 16)), tl.tensor(rn(16, 16)))
    st = _last_stats()
    assert st["groups"] == 1
    hits = sum(r["hit"] for r in st["rules"].values())
    assert hits == st["groups"]
    assert st["fused_nodes"] == 3  # {add_scalar, mul, relu}


# ---------------------------------------------------------------------------
# R4 — backward-expr chains (gelu_bw -> add family)
# ---------------------------------------------------------------------------

def _gelu_bw_np(g, x):
    from minitriton import precision as _prec
    if _prec.gelu_erf():
        import math
        return g * (0.5 * (1 + np.vectorize(math.erf)(
            x * 0.7071067811865476))
            + 0.3989422804014327 * x * np.exp(-0.5 * x * x))
    c = 0.7978845608028654
    u = c * (x + 0.044715 * x**3)
    t = np.tanh(u)
    return g * (0.5 * (1 + t) + 0.5 * x * (1 - t * t) * c
                * (1 + 0.134145 * x * x))


def test_r4_gelu_bw_add_fused(monkeypatch):
    monkeypatch.setenv("MT_FUSION_RULES", "r3_cast_fold")  # isolate R4

    def f(g, x, dy):
        return _ops._binary_op("gelu_bw", g, x) + dy

    cf = tl.compile(f)
    g, x, dy = rn(64, 96), rn(64, 96), rn(64, 96)
    args = [tl.tensor(v) for v in (g, x, dy)]
    out = cf(*args)
    ref = _gelu_bw_np(g, x) + dy
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-4, atol=1e-5)
    spec = _only_spec(cf)
    assert spec["type"] == "ew_chain" and len(spec["members"]) == 2
    assert _last_stats()["rules"]["r4_bw_chain"]["hit"] == 1


def test_r4_bw_chain_composes_with_unary():
    def f(g, x):
        return tl.sigmoid(_ops._binary_op("gelu_bw", g, x))

    cf = tl.compile(f)
    g, x = rn(48, 32), rn(48, 32)
    out = cf(tl.tensor(g), tl.tensor(x))
    ref = 1 / (1 + np.exp(-_gelu_bw_np(g, x)))
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-4, atol=1e-5)
    spec = _only_spec(cf)
    assert spec["type"] == "ew_chain" and len(spec["members"]) == 2


def test_r1_excludes_backward_ops_no_crash(monkeypatch):
    """With only the R1 vocab, a backward op (eq/gelu_bw/...) must
    stay on the eager path — the two-pattern build() would KeyError-crash
    on it; the vocab-checked walker must skip it instead."""
    monkeypatch.setenv("MT_FUSION_RULES", "r3_cast_fold,r4_bw_chain")

    @tl.compile
    def f(a, b):
        return _ops._binary_op("eq", a, b) * 2.0

    a, b = rn(32, 32), rn(32, 32)
    out = f(tl.tensor(a), tl.tensor(b))
    ref = (a == b).astype(np.float32) * 2.0
    np.testing.assert_allclose(out.numpy(), ref)
    assert len(list(f._cache.values())[0].fused) == 0


# ---------------------------------------------------------------------------
# R3 — cast folding
# ---------------------------------------------------------------------------

def test_r3_cast_fold_explicit_astype():
    def f(x, y):  # x bf16; the explicit cast is absorbed into the chain
        return tl.relu(x.astype(tl.float32) * y + 1.0)

    cf = tl.compile(f)
    x, y = rn(64, 96), rn(64, 96)
    tx = tl.tensor(x).astype(tl.bfloat16)
    ty = tl.tensor(y)
    out = cf(tx, ty)
    ref = f(tx, ty)  # eager path (real cast kernel + separate ew kernels)
    np.testing.assert_allclose(out.numpy(), ref.numpy(), rtol=1e-5,
                               atol=1e-6)
    spec = _only_spec(cf)
    assert spec["type"] == "ew_chain"
    assert len(spec["cast_members"]) == 1
    assert len(spec["members"]) == 4  # {relu, +1.0, mul, astype}
    assert _last_stats()["rules"]["r3_cast_fold"]["hit"] == 1


def test_r3_mixed_dtype_leaves_load_cast():
    """Mixed-dtype binary WITHOUT an astype node: leaves load-cast."""
    def f(x, y):
        return tl.relu(x * y)

    cf = tl.compile(f)
    x, y = rn(64, 96), rn(64, 96)
    tx = tl.tensor(x).astype(tl.bfloat16)
    ty = tl.tensor(y)
    out = cf(tx, ty)
    ref = f(tx, ty)
    np.testing.assert_allclose(out.numpy(), ref.numpy(), rtol=1e-5,
                               atol=1e-6)
    spec = _only_spec(cf)
    assert spec["type"] == "ew_chain" and len(spec["members"]) == 2
    assert len(spec["cast_members"]) == 0  # nothing absorbed, no cast node


def test_r3_cast_multi_consumer_not_folded():
    """A cast whose other consumer stays outside the group must still
    execute — it becomes a plain leaf, and the reject is recorded."""
    def f(x, y):
        c = x.astype(tl.float32)
        return tl.relu(c * y) + tl.softmax(c, dim=-1)

    cf = tl.compile(f)
    x, y = rn(32, 64), rn(32, 64)
    tx = tl.tensor(x).astype(tl.bfloat16)
    ty = tl.tensor(y)
    out = cf(tx, ty)
    ref = f(tx, ty)
    np.testing.assert_allclose(out.numpy(), ref.numpy(), rtol=1e-5,
                               atol=1e-6)
    spec = _only_spec(cf)
    assert spec["type"] == "ew_chain"
    assert len(spec["cast_members"]) == 0  # ejected: softmax needed it
    st = _last_stats()
    assert st["rules"]["r3_cast_fold"].get("cast_multi_consumer", 0) >= 1


# ---------------------------------------------------------------------------
# R8 — permute -> contiguous -> matmul: drop the copy
# ---------------------------------------------------------------------------

def test_r8_trans_contig_alias():
    def f(x, w):
        return tl.matmul(x.t().contiguous(), w)

    cf = tl.compile(f)
    x, w = rn(48, 64), rn(48, 32)
    out = cf(tl.tensor(x), tl.tensor(w))
    np.testing.assert_allclose(out.numpy(), x.T @ w, rtol=1e-4, atol=1e-4)
    spec = _only_spec(cf)
    assert spec["type"] == "alias"
    assert _last_stats()["rules"]["r8_trans_contig"]["hit"] == 1


def test_r8_negative_ew_consumer_not_aliased():
    @tl.compile
    def f(x):
        return x.t().contiguous() * 2.0

    x = rn(24, 40)
    out = f(tl.tensor(x))
    np.testing.assert_allclose(out.numpy(), x.T * 2.0, rtol=1e-5)
    st = _last_stats()
    assert st["rules"]["r8_trans_contig"]["hit"] == 0
    assert st["rules"]["r8_trans_contig"].get("consumer_not_matmul", 0) >= 1


def test_r8_output_contiguous_not_aliased():
    @tl.compile
    def f(x):
        return x.t().contiguous()

    x = rn(24, 40)
    out = f(tl.tensor(x))
    np.testing.assert_allclose(out.numpy(), x.T, rtol=1e-5)
    assert _last_stats()["rules"]["r8_trans_contig"].get(
        "output_node", 0) >= 1


# ---------------------------------------------------------------------------
# arbitration: mm epilogue beats ew chain on the same nodes
# ---------------------------------------------------------------------------

def test_arbitration_mm_before_ew():
    """matmul -> bias add -> unary must be claimed by an mm epilogue rule
    (r2v on the fp32 flag-off path: matmul+bias fused with the store_t2
    bias_pt, the unary replaying eagerly), not an ew chain over the
    add+unary (priority 10x > 1x)."""
    def f(x, w, b):
        return tl.relu(tl.matmul(x, w) + b)

    cf = tl.compile(f)
    x, w, b = rn(64, 32), rn(32, 48), rn(48)
    out = cf(tl.tensor(x), tl.tensor(w), tl.tensor(b))
    np.testing.assert_allclose(out.numpy(), np.maximum(x @ w + b, 0),
                               rtol=1e-4, atol=1e-4)
    spec = _only_spec(cf)
    assert spec["type"] == "mm_v2_epilogue"


# ---------------------------------------------------------------------------
# R2' — matmul epilogue on the mma path (r2p_mma_epilogue)
# ---------------------------------------------------------------------------

import minitriton.device.cuda.ops as _be_ops  # noqa: E402


def _bf16_round(x: np.ndarray) -> np.ndarray:
    """f32 -> bf16 -> f32 (RNE): host-side exact bf16 values."""
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    u = (b + np.uint32(0x7FFF) + ((b >> 16) & 1)) >> 16
    return (u.astype(np.uint32) << 16).view(np.float32).reshape(x.shape)


def _rn16(*shape, seed=0):
    return _bf16_round(np.random.default_rng(seed)
                       .standard_normal(shape).astype(np.float32))


def _gelu_np(z):
    from minitriton import precision as _prec
    if _prec.gelu_erf():
        import math
        return 0.5 * z * (1 + np.vectorize(math.erf)(
            z * 0.7071067811865476))
    return 0.5 * z * (1 + np.tanh(0.7978845608028654
                                  * (z + 0.044715 * z**3)))


def test_r2p_bf16_match_and_numerics():
    """bf16 gelu(matmul + bias): r2p claims the group; numerics vs the
    composed eager path and the fp64 oracle (bf16 tier, 2e-2)."""
    @tl.compile
    def f(a, b, bias):
        return _ops.gelu(_ops.matmul(a, b) + bias)

    a_np, b_np, bias_np = _rn16(128, 640), _rn16(640, 256, seed=1), \
        _rn16(256, seed=2)
    args = [tl.tensor(x).astype(tl.bfloat16) for x in (a_np, b_np, bias_np)]
    out = f(*args)
    assert out.dtype == tl.bfloat16
    ref = _gelu_np(a_np.astype(np.float64) @ b_np.astype(np.float64)
                   + bias_np)
    np.testing.assert_allclose(out.astype(tl.float32).numpy(), ref,
                               rtol=2e-2, atol=2e-2)
    spec = _only_spec(f)
    assert spec["type"] == "mma_epilogue" and spec["atom"] == "bf16"
    assert _last_stats()["rules"]["r2p_mma_epilogue"]["hit"] == 1
    # vs the composed eager path (matmul_bf16 + separate ew ops)
    eager = _ops.gelu(_ops.matmul(*args[:2]) + args[2])
    np.testing.assert_allclose(out.astype(tl.float32).numpy(),
                               eager.astype(tl.float32).numpy(),
                               rtol=2e-2, atol=2e-2)


def test_r2p_baked_bias_trans_b():
    """The Linear form: matmul_bf16(x, w.t(), bias=..) — bias baked into
    the mm node, b a pure transpose view. The bias alone is the
    epilogue (no unary chain needed)."""
    @tl.compile
    def lin(x, w, bias):
        return _ops.matmul_bf16(x, w.t(), bias=bias)

    x_np, w_np, b_np = _rn16(256, 640), _rn16(192, 640, seed=1), \
        _rn16(192, seed=2)
    args = [tl.tensor(v).astype(tl.bfloat16) for v in (x_np, w_np, b_np)]
    out = lin(*args)
    ref = x_np.astype(np.float64) @ w_np.astype(np.float64).T + b_np
    np.testing.assert_allclose(out.astype(tl.float32).numpy(), ref,
                               rtol=2e-2, atol=2e-2)
    spec = _only_spec(lin)
    assert spec["type"] == "mma_epilogue" and spec["bias"] is not None
    assert _last_stats()["rules"]["r2p_mma_epilogue"]["hit"] == 1


def test_r2p_f32_operands_bf16_kernel():
    """f32 operands on the bf16 route (cast-in-kernel staging): the
    fused kernel reads f32 planes directly."""
    @tl.compile
    def f(a, b, bias):
        return _ops.gelu(_ops.matmul_bf16(a, b) + bias)

    a_np, b_np, bias_np = _rn16(128, 320, seed=3), _rn16(320, 128,
                                                         seed=4), \
        _rn16(128, seed=5)
    out = f(tl.tensor(a_np), tl.tensor(b_np), tl.tensor(bias_np))
    ref = _gelu_np(a_np.astype(np.float64) @ b_np.astype(np.float64)
                   + bias_np)
    np.testing.assert_allclose(out.astype(tl.float32).numpy(), ref,
                               rtol=2e-2, atol=2e-2)
    assert _only_spec(f)["type"] == "mma_epilogue"


def test_r2p_f32_out_route():
    """out_dtype=f32 (the backward route, non-split-K): f32 store."""
    @tl.compile
    def f(g, w):
        return _ops.gelu(_ops.matmul_bf16(g, w, out_dtype=tl.float32))

    g_np, w_np = _rn16(128, 640, seed=6), _rn16(640, 192, seed=7)
    out = f(tl.tensor(g_np).astype(tl.bfloat16),
            tl.tensor(w_np).astype(tl.bfloat16))
    assert out.dtype == tl.float32
    ref = _gelu_np(g_np.astype(np.float64) @ w_np.astype(np.float64))
    np.testing.assert_allclose(out.numpy(), ref, rtol=2e-2, atol=2e-2)
    assert _only_spec(f)["type"] == "mma_epilogue"


def test_r2p_splitk_candidate_rejected():
    """f32-out with K >= 4096 and K >= 4*M: split-K's structural gate —
    partials not yet reduced can't take an epilogue, so r2p must
    reject and the graph replays eagerly (correct, unfused)."""
    @tl.compile
    def f(g, x):
        return _ops.matmul_bf16(g.t(), x, out_dtype=tl.float32)

    g_np, x_np = _rn16(16384, 64, seed=8), _rn16(16384, 640, seed=9)
    out = f(tl.tensor(g_np).astype(tl.bfloat16),
            tl.tensor(x_np).astype(tl.bfloat16))
    ref = g_np.astype(np.float64).T @ x_np.astype(np.float64)
    np.testing.assert_allclose(out.numpy(), ref, rtol=2e-2, atol=2e-2)
    st = _last_stats()
    assert st["rules"]["r2p_mma_epilogue"].get("splitk_candidate", 0) >= 1
    assert st["groups"] == 0  # nothing fused


def test_r2p_stride_degrade():
    """An operand whose strides violate the bf16 staging rules (odd row
    stride) can't take the mma route: the exec-time guard degrades to
    the eager replay (correct, unfused) instead of failing."""
    @tl.compile
    def f(a, b, bias):
        return _ops.gelu(_ops.matmul(a, b) + bias)

    a_big = _rn16(128, 641, seed=10)
    a_np = a_big[:, :640]                   # strides (641, 1): odd
    b_np, bias_np = _rn16(640, 256, seed=11), _rn16(256, seed=12)
    ta = tl.tensor(a_big).astype(tl.bfloat16)[:, :640]
    tb = tl.tensor(b_np).astype(tl.bfloat16)
    tbias = tl.tensor(bias_np).astype(tl.bfloat16)
    out = f(ta, tb, tbias)
    ref = _gelu_np(a_np.astype(np.float64) @ b_np.astype(np.float64)
                   + bias_np)
    np.testing.assert_allclose(out.astype(tl.float32).numpy(), ref,
                               rtol=2e-2, atol=2e-2)
    # the group matched (plan time) but degraded at exec; either way
    # the result is the eager-composed one, checked above
    eager = _ops.gelu(_ops.matmul(ta, tb) + tbias)
    np.testing.assert_allclose(out.astype(tl.float32).numpy(),
                               eager.astype(tl.float32).numpy(),
                               rtol=2e-2, atol=2e-2)


def test_r2p_tf32_tier_and_priority():
    """allow_tf32 on: an f32 matmul+bias+gelu goes to the mma route
    (r2p, priority 110 > r2v's 105); flag off: same graph takes the r2v
    fp32 store_t2 route (matmul+bias fused, the gelu replaying eagerly
    on the fused output). The flag is part of the compile cache key."""
    @tl.compile
    def f(a, b, bias):
        return _ops.gelu(_ops.matmul(a, b) + bias)

    a_np, b_np, bias_np = rn(128, 320), rn(320, 128), rn(128)
    args = [tl.tensor(v) for v in (a_np, b_np, bias_np)]
    _be_ops.set_allow_tf32(True)
    try:
        out = f(*args)
        assert out.dtype == tl.float32
        # test_mma discipline: fp64 matmul of the tf32-rounded inputs
        z = _tf32_round(a_np).astype(np.float64) \
            @ _tf32_round(b_np).astype(np.float64) + bias_np
        ref = _gelu_np(z)
        np.testing.assert_allclose(out.numpy(), ref, rtol=1e-2, atol=1e-2)
        spec = list(f._cache.values())[-1]
        assert spec.fused, "r2p should have claimed the group"
        assert list(spec.fused.values())[0]["type"] == "mma_epilogue"
        assert _last_stats()["rules"]["r2p_mma_epilogue"]["hit"] == 1
    finally:
        _be_ops.set_allow_tf32(False)
    out2 = f(*args)  # new cache entry (flag is in the key)
    # flag-off result must equal the eager composition (r2v fused
    # matmul+bias + eager gelu)
    z2 = a_np @ b_np + bias_np
    np.testing.assert_allclose(out2.numpy(), _gelu_np(z2),
                               rtol=1e-4, atol=1e-4)
    spec2 = list(f._cache.values())[-1]
    assert list(spec2.fused.values())[0]["type"] == "mm_v2_epilogue"


def _tf32_round(x: np.ndarray) -> np.ndarray:
    """f32 with a tf32 mantissa (10 bits, round-half-away) — mirrors
    cvt.rna.tf32.f32 (test_mma.py's helper)."""
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    r = (b + np.uint32(0x1000)) & np.uint32(0xFFFFE000)
    return r.view(np.float32).reshape(x.shape)


def test_r2p_env_gate(monkeypatch):
    """MT_FUSION_RULES disables r2p by name: the mm replays through the
    eager matmul_bf16 (correct, unfused)."""
    monkeypatch.setenv("MT_FUSION_RULES", "r2p_mma_epilogue")

    @tl.compile
    def lin(x, w, bias):
        return _ops.matmul_bf16(x, w.t(), bias=bias)

    x_np, w_np, b_np = _rn16(128, 320, seed=13), _rn16(96, 320,
                                                       seed=14), \
        _rn16(96, seed=15)
    args = [tl.tensor(v).astype(tl.bfloat16) for v in (x_np, w_np, b_np)]
    out = lin(*args)
    ref = x_np.astype(np.float64) @ w_np.astype(np.float64).T + b_np
    np.testing.assert_allclose(out.astype(tl.float32).numpy(), ref,
                               rtol=2e-2, atol=2e-2)
    assert "r2p_mma_epilogue" not in _last_stats()["rules"]
    exe = list(lin._cache.values())[0]
    assert len(exe.fused) == 0


# ---------------------------------------------------------------------------
# R2v — matmul epilogue on the fp32 store_t2 (matmul_v2) path
# ---------------------------------------------------------------------------

def test_r2v_unary_chain_full_fusion():
    """No bias: the whole unary chain fuses into the store_t2 epilogue."""
    @tl.compile
    def f(a, b):
        return _ops.gelu(_ops.matmul(a, b))

    a_np, b_np = rn(128, 64), rn(64, 96)
    out = f(tl.tensor(a_np), tl.tensor(b_np))
    ref = _gelu_np(a_np @ b_np)
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-4, atol=1e-4)
    spec = _only_spec(f)
    assert spec["type"] == "mm_v2_epilogue"
    assert _last_stats()["rules"]["r2v_mm_v2_epilogue"]["hit"] == 1
    # second consumer count: the fused group covers matmul + gelu
    assert len(spec["members"]) == 2


def test_r2v_bias_only_is_bit_exact_vs_production():
    """matmul + bias only: fused via the store_t2 bias_pt (the production
    matmul_v2 BIAS form) — per-element single f32 add, bit-identical to
    the eager composition."""
    @tl.compile
    def f(a, b, bias):
        return _ops.matmul(a, b) + bias

    a_np, b_np, bias_np = rn(128, 64), rn(64, 96), rn(96)
    out = f(tl.tensor(a_np), tl.tensor(b_np), tl.tensor(bias_np))
    eager = _ops.matmul(tl.tensor(a_np), tl.tensor(b_np)) \
        + tl.tensor(bias_np)
    np.testing.assert_array_equal(out.numpy(), eager.numpy())
    spec = _only_spec(f)
    assert spec["type"] == "mm_v2_epilogue" and spec["expr"] == "v"


def test_r2v_bias_unary_decomposition():
    """bias + unary: only the matmul+bias fuses (store_t2 bias_pt); the
    gelu replays eagerly on the fused output — result still exact."""
    @tl.compile
    def f(a, b, bias):
        return _ops.gelu(_ops.matmul(a, b) + bias)

    a_np, b_np, bias_np = rn(128, 64), rn(64, 96), rn(96)
    out = f(tl.tensor(a_np), tl.tensor(b_np), tl.tensor(bias_np))
    ref = _gelu_np(a_np @ b_np + bias_np)
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-4, atol=1e-4)
    spec = _only_spec(f)
    assert spec["type"] == "mm_v2_epilogue"
    assert len(spec["members"]) == 2  # matmul + add only, gelu eager


def test_r2v_splitk_candidate_rejected():
    """f32 matmul with K >= 4096 and K >= 4*M (the fp32 split-K gate):
    partials not yet reduced can't take an epilogue — r2v rejects and
    the graph replays eagerly (correct, unfused)."""
    @tl.compile
    def f(g, x):
        return _ops.matmul(g.t(), x)

    g_np, x_np = rn(16384, 64), rn(16384, 640)
    out = f(tl.tensor(g_np), tl.tensor(x_np))
    ref = g_np.T @ x_np
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-3, atol=1e-3)
    st = _last_stats()
    assert st["rules"]["r2v_mm_v2_epilogue"].get("splitk_candidate", 0) \
        >= 1
    assert st["groups"] == 0


def test_r2v_stride_degrade():
    """An operand that is neither unit-last-stride nor a pure transpose
    view: the group matches at plan time (strides are exec-time facts)
    but degrades to the eager replay — the result is the eager-composed
    one (r2p_stride_degrade precedent)."""
    @tl.compile
    def f(a, b, bias):
        return _ops.gelu(_ops.matmul(a, b) + bias)

    big = rn(128, 128)
    a_np = big[:, ::2]           # strides[-1] == 2: ineligible
    b_np, bias_np = rn(64, 96), rn(96)
    out = f(tl.tensor(a_np), tl.tensor(b_np), tl.tensor(bias_np))
    ref = _gelu_np(a_np @ b_np + bias_np)
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-4, atol=1e-4)
    ta, tb = tl.tensor(a_np), tl.tensor(b_np)
    eager = _ops.gelu(_ops.matmul(ta, tb) + tl.tensor(bias_np))
    np.testing.assert_allclose(out.numpy(), eager.numpy(),
                               rtol=1e-5, atol=1e-5)


def test_r2v_env_gate(monkeypatch):
    """MT_FUSION_RULES disables r2v by name: the graph falls back to
    r2's v1-dot mm_epilogue (priority 100), still correct."""
    monkeypatch.setenv("MT_FUSION_RULES", "r2v_mm_v2_epilogue")

    @tl.compile
    def f(a, b):
        return _ops.gelu(_ops.matmul(a, b))

    a_np, b_np = rn(128, 64), rn(64, 96)
    out = f(tl.tensor(a_np), tl.tensor(b_np))
    np.testing.assert_allclose(out.numpy(), _gelu_np(a_np @ b_np),
                               rtol=1e-4, atol=1e-4)
    assert "r2v_mm_v2_epilogue" not in _last_stats()["rules"]
    exe = list(f._cache.values())[0]
    assert list(exe.fused.values())[0]["type"] == "mm_epilogue"


def test_fusion_module_layer_invariant():
    """L0 invariant: fusion.py operates on the
    duck-typed trace graph and must not import compile.py (cycle) —
    backends imports stay lazy inside functions."""
    import ast as _ast
    src = open(_fusion.__file__).read()
    for node in _ast.walk(_ast.parse(src)):
        if isinstance(node, _ast.ImportFrom) and node.module:
            top = node.module.split(".")[-1] if node.level else \
                node.module.split(".")[0]
            assert top != "compile", "fusion.py must not import compile.py"
