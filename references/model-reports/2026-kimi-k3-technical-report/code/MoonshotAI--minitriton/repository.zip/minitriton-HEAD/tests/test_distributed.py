"""Distributed tests: real NCCL collectives and DDP gradient
consistency across 2 spawned GPU processes.

Skipped unless >= 2 CUDA devices are visible:

    CUDA_VISIBLE_DEVICES=1,2 pytest tests/test_distributed.py

Worker functions are module-level (spawn pickling) and each one computes
its own reference locally, so verdicts are asserted inside the children;
the parent only re-raises non-zero exits. No torch anywhere (tests rule).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest


def _gpu_count() -> int:
    try:
        from minitriton.runtime import cuda_driver
        cuda_driver.init()
        return cuda_driver.check(cuda_driver.CU.cuDeviceGetCount(),
                                 "cuDeviceGetCount")
    except Exception:
        return 0


pytestmark = pytest.mark.skipif(_gpu_count() < 2,
                                reason="distributed tests need >= 2 visible "
                                       "GPUs (CUDA_VISIBLE_DEVICES=1,2)")


# ---------------------------------------------------------------------------
# workers (module level for spawn pickling; assertions run in the children)
# ---------------------------------------------------------------------------

def _collectives_worker(rank, world):
    import minitriton as tl
    from minitriton import distributed as dist

    dist.init_process_group()
    pg = dist.get_process_group()
    assert pg.rank == rank and pg.world_size == world

    # allreduce: each rank contributes (rank+1) * base
    base = np.arange(8, dtype=np.float32)
    x = tl.from_numpy(base * (rank + 1))
    pg.allreduce(x, op="sum")
    total = sum(r + 1 for r in range(world))
    np.testing.assert_allclose(x.numpy(), base * total, rtol=1e-6, atol=0)

    # broadcast from the last rank
    y = tl.from_numpy(base * (rank + 1))
    pg.broadcast(y, root=world - 1)
    np.testing.assert_allclose(y.numpy(), base * world, rtol=0, atol=0)

    # allgather
    z = tl.from_numpy(base[:4] * (rank + 1))
    cat = pg.allgather(z)
    ref = np.concatenate([base[:4] * (r + 1) for r in range(world)])
    np.testing.assert_allclose(cat.numpy().reshape(-1), ref, rtol=0, atol=0)

    # reduce_scatter: shards of a (world*4,) tensor
    w = tl.from_numpy(base)
    shard = pg.reduce_scatter(w, op="sum")
    np.testing.assert_allclose(
        shard.numpy(), base[rank * 4:(rank + 1) * 4] * world,
        rtol=1e-6, atol=0)

    pg.barrier()
    dist.destroy_process_group()


def _ddp_worker(rank, world):
    import minitriton as tl
    from minitriton import distributed as dist
    from minitriton import nn

    dist.init_process_group()

    class MLP(nn.Module):
        def __init__(self):
            super().__init__()
            self.fc1 = nn.Linear(8, 32, device="cuda", seed=5)
            self.fc2 = nn.Linear(32, 4, device="cuda", seed=6)
            self.mid = nn.Linear(32, 32, device="cuda", seed=7)

        def forward(self, x):
            return self.fc2(tl.gelu(self.mid(tl.gelu(self.fc1(x)))))

    rng = np.random.default_rng(123)
    x_np = rng.standard_normal((16, 8)).astype(np.float32)
    y_np = rng.standard_normal((16, 4)).astype(np.float32)

    # full-batch reference, computed identically on every rank
    ref = MLP()
    xb = tl.tensor(x_np)
    yb = tl.tensor(y_np)
    ((ref(xb) - yb) ** 2).mean().backward()
    ref_grads = [p.grad.numpy().copy() for p in ref.parameters()]

    # DDP on the rank's shard: mean of shard-mean grads == full-batch grad
    ddp = dist.DistributedDataParallel(MLP())
    h = x_np.shape[0] // world
    xs = tl.tensor(x_np[rank * h:(rank + 1) * h])
    ys = tl.tensor(y_np[rank * h:(rank + 1) * h])
    ((ddp(xs) - ys) ** 2).mean().backward()
    ddp.sync_grads()

    for i, (p, g0) in enumerate(zip(ddp.parameters(), ref_grads)):
        np.testing.assert_allclose(p.grad.numpy(), g0, rtol=1e-5, atol=1e-7,
                                   err_msg=f"param {i} grad mismatch")

    # synced grads must be identical across ranks
    flat = np.concatenate([p.grad.numpy().ravel() for p in ddp.parameters()])
    gsum = tl.from_numpy(flat)
    dist.get_process_group().allreduce(gsum, op="sum")
    np.testing.assert_allclose(gsum.numpy(), flat * world, rtol=1e-5,
                               atol=1e-7)

    # a flat-param broadcast keeps all ranks bitwise identical
    p0 = np.concatenate([p.numpy().ravel() for p in ddp.parameters()])
    wsum = tl.from_numpy(p0)
    dist.get_process_group().allreduce(wsum, op="sum")
    np.testing.assert_allclose(wsum.numpy(), p0 * world, rtol=0, atol=0)

    dist.destroy_process_group()


# ---------------------------------------------------------------------------
# tests
# ---------------------------------------------------------------------------

def test_collectives_2proc():
    from minitriton import distributed as dist
    dist.launch(_collectives_worker, 2)


def test_ddp_grad_consistency_2proc():
    from minitriton import distributed as dist
    dist.launch(_ddp_worker, 2)
