"""Helper module for test_frontend_inline.py: @tl.inline helpers
whose free variables must resolve in THIS module's globals, not the
kernel module's."""

import minitriton as tl

HELPER_SCALE = tl.constexpr(2.0)
ONLY_IN_HELPER = tl.constexpr(11.0)


@tl.inline
def scale_it(x):
    return x * HELPER_SCALE


@tl.inline
def only_here(x):
    return x + ONLY_IN_HELPER


HELPER_DEFAULT = tl.constexpr(7.0)


@tl.inline
def add_default(x, c=HELPER_DEFAULT):
    return x + c
