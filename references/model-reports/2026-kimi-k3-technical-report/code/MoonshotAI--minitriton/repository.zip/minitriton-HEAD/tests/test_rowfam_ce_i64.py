"""rowfam (sched composed reference path) cross_entropy fwd/bwd must
accept i64 targets — the torch/numpy-default label dtype — like the
production route does.

The kernels' `offs == t` comparison requires i32 bounds
(`SemanticsError: offset comparisons require i32 bounds`; the wide-row
online forms require i32 scalars: `pointer offsets must be i32
scalars`). The entry converts to i32, mirroring device/cuda/ops.py's
cross_entropy_rows.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl
from minitriton import ops as tl_ops
from minitriton.device.cuda import ops as tl_be
from minitriton.sched import rowfam


def f64(x):
    return np.asarray(x, dtype=np.float64)


def np_ce(x, t):
    x, t = f64(x), np.asarray(t)
    z = x - x.max(-1, keepdims=True)
    lse = np.log(np.exp(z).sum(-1)) + x.max(-1)
    return lse - x[np.arange(x.shape[0]), t]


def np_ce_bwd(x, t, g):
    x, t, g = f64(x), np.asarray(t), f64(g)
    z = x - x.max(-1, keepdims=True)
    e = np.exp(z)
    p = e / e.sum(-1, keepdims=True)
    p[np.arange(x.shape[0]), t] -= 1.0
    return p * g[:, None]


def test_ce_fwd_i64_target():
    rng = np.random.default_rng(0)
    R, C = 96, 640
    x = rng.standard_normal((R, C)).astype(np.float32)
    t = rng.integers(0, C, size=R)  # int64
    assert t.dtype == np.int64
    got = rowfam.cross_entropy(tl.tensor(x), tl.tensor(t)).numpy()
    np.testing.assert_allclose(got, np_ce(x, t), rtol=1e-5, atol=1e-6)


def test_ce_bwd_i64_target():
    rng = np.random.default_rng(1)
    R, C = 96, 640
    x = rng.standard_normal((R, C)).astype(np.float32)
    t = rng.integers(0, C, size=R)
    g = rng.standard_normal(R).astype(np.float32)
    got = rowfam.cross_entropy_backward(tl.tensor(x), tl.tensor(t),
                                        tl.tensor(g)).numpy()
    np.testing.assert_allclose(got, np_ce_bwd(x, t, g), rtol=1e-5,
                               atol=1e-5)


def test_ce_fwd_i64_wide_row():
    # C > 2048 takes the composed online chunked form (same i32
    # conversion at the entry)
    rng = np.random.default_rng(2)
    R, C = 8, 3000
    x = rng.standard_normal((R, C)).astype(np.float32)
    t = rng.integers(0, C, size=R)
    got = rowfam.cross_entropy(tl.tensor(x), tl.tensor(t)).numpy()
    np.testing.assert_allclose(got, np_ce(x, t), rtol=1e-4, atol=1e-5)


def test_ce_bwd_i64_wide_row():
    # C > 8192 takes the two-pass online bwd form
    rng = np.random.default_rng(3)
    R, C = 4, 9000
    x = rng.standard_normal((R, C)).astype(np.float32)
    t = rng.integers(0, C, size=R)
    g = rng.standard_normal(R).astype(np.float32)
    got = rowfam.cross_entropy_backward(tl.tensor(x), tl.tensor(t),
                                        tl.tensor(g)).numpy()
    np.testing.assert_allclose(got, np_ce_bwd(x, t, g), rtol=1e-4,
                               atol=1e-4)


def test_ce_i64_matches_production_bit_equal():
    # rowfam's documented contract at C <= 8192: bit-equal to production
    rng = np.random.default_rng(4)
    R, C = 64, 512
    x = rng.standard_normal((R, C)).astype(np.float32)
    t = rng.integers(0, C, size=R)
    g = rng.standard_normal(R).astype(np.float32)
    got = rowfam.cross_entropy(tl.tensor(x), tl.tensor(t)).numpy()
    prod = tl_be.cross_entropy_rows(tl.tensor(x), tl.tensor(t)).numpy()
    assert got.tobytes() == prod.tobytes()
    got_b = rowfam.cross_entropy_backward(tl.tensor(x), tl.tensor(t),
                                          tl.tensor(g)).numpy()
    # the production bwd's i32 conversion lives in the shared ops layer
    prod_b = tl_ops.cross_entropy_backward_rows(tl.tensor(x), tl.tensor(t),
                                                tl.tensor(g)).numpy()
    assert got_b.tobytes() == prod_b.tobytes()


def test_ce_i32_control():
    rng = np.random.default_rng(5)
    R, C = 96, 640
    x = rng.standard_normal((R, C)).astype(np.float32)
    t32 = rng.integers(0, C, size=R).astype(np.int32)
    got = rowfam.cross_entropy(tl.tensor(x), tl.tensor(t32)).numpy()
    np.testing.assert_allclose(got, np_ce(x, t32), rtol=1e-5, atol=1e-6)
