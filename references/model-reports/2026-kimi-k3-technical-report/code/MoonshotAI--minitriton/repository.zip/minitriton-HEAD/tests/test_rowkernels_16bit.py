"""16-bit (bf16/f16) coverage of the norm/softmax/CE row-kernel family
and the DSL reduce/ptx-math paths.

Background (dual root cause): the compiler warp butterfly's nvvm.shfl.sync is
32-bit-only and the ptx math (tl.exp/tl.log) took f32 blocks only, so
every row kernel crashed on bf16/f16 inputs — as did any user DSL
kernel doing tl.sum/tl.max/tl.min on a 16-bit block. Fix: the kernels
cast sub-f32 loads to f32 and pack back on store (the CALC_F32
discipline of reduce_row_kernel), and the compiler extends sub-f32
floats to f32 inside reduce/ptx-math (dtype-preserving).

Also covered: layer_norm(out_dtype=...) packed on store only for bf16; the
seam is generalized to a constexpr cast to the out elem dtype.

Oracle: numpy fp64 on the 16-bit-rounded inputs (bf16 has no numpy
dtype; read back via .astype(tl.float32)). Tolerances: bf16 2e-2,
f16 2e-3 (16-bit output rounding dominates; f32 compute vs fp64 is
~1e-6). No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.tensor import empty
from minitriton.device.cuda import ops as cuda_ops
from minitriton.device.cuda.kernels import norm as NM
from minitriton.device.cuda.kernels import ce as CEM

rng = np.random.default_rng(7)

DT16 = [tl.bfloat16, tl.float16]
TOL = {tl.bfloat16: (2e-2, 2e-2), tl.float16: (2e-3, 2e-3)}
CS = [32, 64, 128, 1024, 4096, 8192]


def bf16_round(x):
    """f32 -> bf16 -> f32 round trip (round to nearest even), in numpy."""
    x = np.ascontiguousarray(x, dtype=np.float32)
    u = x.view(np.uint32)
    return ((u + 0x7FFF + ((u >> 16) & 1)) & 0xFFFF0000).view(np.float32)


def rounded(x, dt):
    if dt == tl.bfloat16:
        return bf16_round(x)
    return x.astype(np.float16).astype(np.float32)


def T(x, dt):
    return tl.tensor(np.ascontiguousarray(x, dtype=np.float32),
                     device="cuda").astype(dt)


def back(t):
    return t.astype(tl.float32).numpy()


def case(R, C, dt, seed=0):
    r = np.random.default_rng(seed)
    x = rounded(r.standard_normal((R, C)).astype(np.float32), dt)
    g = rounded(r.standard_normal((R, C)).astype(np.float32), dt)
    w = rounded(r.standard_normal(C).astype(np.float32), dt)
    b = rounded(r.standard_normal(C).astype(np.float32), dt)
    gr = rounded(r.standard_normal(R).astype(np.float32), dt)
    t = r.integers(0, C, R).astype(np.int32)
    return x, g, w, b, gr, t


# -- fp64 oracles on the rounded inputs --------------------------------------

def np_softmax(v):
    e = np.exp(v - v.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)


def np_ln(v, w=None, b=None, eps=1e-5):
    d = v - v.mean(-1, keepdims=True)
    y = d / np.sqrt((d * d).mean(-1, keepdims=True) + eps)
    if w is not None:
        y = y * w
    if b is not None:
        y = y + b
    return y


def np_rms(v, w=None, eps=1e-6):
    y = v / np.sqrt((v * v).mean(-1, keepdims=True) + eps)
    return y if w is None else y * w


def np_ce(v, t):
    lse = np.log(np.exp(v - v.max(-1, keepdims=True)).sum(-1)) + v.max(-1)
    return lse - v[np.arange(v.shape[0]), t]


def np_ce_bwd(v, t, g):
    p = np_softmax(v)
    p[np.arange(v.shape[0]), t] -= 1.0
    return p * g[:, None]


def np_ln_bwd(g, v, w=None, eps=1e-5):
    d = v - v.mean(-1, keepdims=True)
    rstd = 1.0 / np.sqrt((d * d).mean(-1, keepdims=True) + eps)
    xh = d * rstd
    u = g if w is None else g * w
    dx = rstd * (u - u.mean(-1, keepdims=True)
                 - xh * (u * xh).mean(-1, keepdims=True))
    return dx, xh


def np_rms_bwd(g, v, w=None, eps=1e-6):
    rstd = 1.0 / np.sqrt((v * v).mean(-1, keepdims=True) + eps)
    xr = v * rstd
    u = g if w is None else g * w
    dx = rstd * (u - xr * (u * xr).mean(-1, keepdims=True))
    return dx, xr


# -- eager forward matrix ----------------------------------------------

@pytest.mark.parametrize("dt", DT16)
@pytest.mark.parametrize("C", CS)
def test_rowkernels_fwd_16bit(dt, C):
    R = 8
    rtol, atol = TOL[dt]
    x, _, w, b, _, t = case(R, C, dt, seed=C)
    vx, vw, vb = (x.astype(np.float64), w.astype(np.float64),
                  b.astype(np.float64))
    xt, wt, bt = T(x, dt), T(w, dt), T(b, dt)
    tt = tl.tensor(t, device="cuda")

    np.testing.assert_allclose(
        back(tl.layer_norm(xt, (C,), wt, bt)), np_ln(vx, vw, vb),
        rtol=rtol, atol=atol)
    np.testing.assert_allclose(
        back(tl.layer_norm(xt, (C,))), np_ln(vx), rtol=rtol, atol=atol)
    np.testing.assert_allclose(
        back(tl.rms_norm(xt, (C,), wt)), np_rms(vx, vw),
        rtol=rtol, atol=atol)
    y, s = tl.add_layernorm(xt, xt, (C,), wt, bt, return_residual=True)
    np.testing.assert_allclose(back(y), np_ln(vx + vx, vw, vb),
                               rtol=rtol, atol=atol)
    np.testing.assert_allclose(back(s), vx + vx, rtol=rtol, atol=atol)
    np.testing.assert_allclose(back(tl.softmax(xt)), np_softmax(vx),
                               rtol=rtol, atol=atol)
    np.testing.assert_allclose(back(tl.log_softmax(xt)),
                               np.log(np_softmax(vx)), rtol=rtol, atol=atol)
    np.testing.assert_allclose(back(cuda_ops.cross_entropy_rows(xt, tt)),
                               np_ce(vx, t), rtol=rtol, atol=atol)


# -- backward via the launch functions (same methodology as the forward) --

@pytest.mark.parametrize("dt", DT16)
@pytest.mark.parametrize("C", CS)
def test_rowkernels_bwd_16bit(dt, C):
    R = 8
    rtol, atol = TOL[dt]
    x, g, w, _, gr, t = case(R, C, dt, seed=C + 1)
    vx, vg, vw, vgr = (x.astype(np.float64), g.astype(np.float64),
                       w.astype(np.float64), gr.astype(np.float64))
    xt, gt, wt, grt = T(x, dt), T(g, dt), T(w, dt), T(gr, dt)
    tt = tl.tensor(t, device="cuda")
    dx = empty((R, C), dt, "cuda")
    aux = empty((R, C), dt, "cuda")

    NM.launch_layernorm_backward(gt, xt, wt, dx, aux, C, 1e-5)
    rdx, rxh = np_ln_bwd(vg, vx, vw)
    np.testing.assert_allclose(back(dx), rdx, rtol=rtol, atol=atol)
    np.testing.assert_allclose(back(aux), rxh, rtol=rtol, atol=atol)

    # fused three-stage LN backward (stats row kernel + col2 partials
    # + fold): bf16/f16 g/x accumulate in f32 end to end
    dgamma = empty((C,), tl.float32, "cuda")
    dbeta = empty((C,), tl.float32, "cuda")
    NM.launch_layernorm_backward_fused(gt, xt, wt, dx, dbeta, dgamma,
                                       R, C, 1e-5)
    np.testing.assert_allclose(back(dx), rdx, rtol=rtol, atol=atol)
    np.testing.assert_allclose(dgamma.numpy(), (vg * rxh).sum(0),
                               rtol=1e-4, atol=1e-5)
    np.testing.assert_allclose(dbeta.numpy(), vg.sum(0),
                               rtol=1e-4, atol=1e-5)

    NM.launch_rmsnorm_backward(gt, xt, wt, dx, aux, C, 1e-6)
    rdx, rxr = np_rms_bwd(vg, vx, vw)
    np.testing.assert_allclose(back(dx), rdx, rtol=rtol, atol=atol)
    np.testing.assert_allclose(back(aux), rxr, rtol=rtol, atol=atol)

    # softmax bwd consumes the (16-bit) softmax output as y
    y16 = rounded(np_softmax(vx).astype(np.float32), dt)
    yt = T(y16, dt)
    vy = y16.astype(np.float64)
    NM.launch_softmax_backward(gt, yt, dx, C, False)
    np.testing.assert_allclose(back(dx), vy * (vg - (vg * vy).sum(
        -1, keepdims=True)), rtol=rtol, atol=atol)
    NM.launch_softmax_backward(gt, yt, dx, C, True)
    np.testing.assert_allclose(back(dx), vg - np.exp(vy) * vg.sum(
        -1, keepdims=True), rtol=rtol, atol=atol)

    # CE bwd: C <= 2048 the single row kernel; wider rows the fused
    # online form (16-bit rows are routed there at any width)
    CEM.launch_cross_entropy_backward(xt, tt, grt, dx, C)
    np.testing.assert_allclose(back(dx), np_ce_bwd(vx, t, vgr),
                               rtol=rtol, atol=atol)


# -- DSL level: tl.sum/tl.max/tl.min and tl.exp/tl.log on 16-bit ------

@tl.kernel
def _reduce16_kernel(x_ptr, o_ptr, C, OP: tl.constexpr,
                     BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + offs, mask=m, other=float("-inf"))
    if OP == 0:
        r = tl.sum(tl.where(m, x, 0.0))
    elif OP == 1:
        r = tl.max(x)
    else:
        r = tl.min(x)
    tl.store(o_ptr, r)


@tl.kernel
def _math16_kernel(x_ptr, o_ptr, C, OP: tl.constexpr, BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + offs, mask=m, other=0.5)
    if OP == 0:
        y = tl.exp(x)
    else:
        y = tl.log(x)
    tl.store(o_ptr + offs, y, mask=m)


@pytest.mark.parametrize("dt", DT16)
def test_dsl_reduce_16bit(dt):
    """User-level tl.sum/tl.max/tl.min on a 16-bit block: the warp
    butterfly extends to f32 internally; the scalar result keeps the
    block dtype."""
    rtol, atol = TOL[dt]
    C = 128
    v = rounded(rng.standard_normal(C).astype(np.float32), dt)
    x = T(v, dt)
    o = empty((1,), dt, "cuda")
    for op, want in ((0, v.astype(np.float64).sum()), (1, v.max()),
                     (2, v.min())):
        _reduce16_kernel[(1,)](x._buffer_arg(), o._buffer_arg(), C,
                               OP=op, BLOCK=128, num_warps=4)
        np.testing.assert_allclose(back(o), np.array([want]),
                                   rtol=rtol, atol=atol)


@pytest.mark.parametrize("dt", DT16)
def test_dsl_ptx_math_16bit(dt):
    """tl.exp/tl.log on a 16-bit block: extended to f32 per lane and
    truncated back (dtype-preserving)."""
    rtol, atol = TOL[dt]
    C = 128
    v = np.abs(rounded(rng.standard_normal(C).astype(np.float32), dt)) + 0.5
    x = T(v, dt)
    y = empty((C,), dt, "cuda")
    _math16_kernel[(1,)](x._buffer_arg(), y._buffer_arg(), C, OP=0,
                         BLOCK=128, num_warps=4)
    np.testing.assert_allclose(back(y), np.exp(v.astype(np.float64)),
                               rtol=rtol, atol=atol)
    _math16_kernel[(1,)](x._buffer_arg(), y._buffer_arg(), C, OP=1,
                         BLOCK=128, num_warps=4)
    np.testing.assert_allclose(back(y), np.log(v.astype(np.float64)),
                               rtol=rtol, atol=atol)


# -- layer_norm out_dtype seam -----------------------------------------

@pytest.mark.parametrize("in_dt", [tl.float32, tl.bfloat16, tl.float16])
@pytest.mark.parametrize("out_dt", [tl.float32, tl.bfloat16, tl.float16])
def test_layernorm_out_dtype_matrix(in_dt, out_dt):
    """The pack-on-store seam casts to the out elem dtype (f32 compute);
    every in/out float combination is legal MLIR and correctly rounded."""
    R, C = 8, 256
    r = np.random.default_rng(3)
    base = r.standard_normal((R, C)).astype(np.float32)
    wb = r.standard_normal(C).astype(np.float32)
    bb = r.standard_normal(C).astype(np.float32)
    xin = base if in_dt == tl.float32 else rounded(base, in_dt)
    x = tl.tensor(xin, device="cuda") if in_dt == tl.float32 \
        else T(xin, in_dt)
    w = tl.tensor(wb, device="cuda")
    b = tl.tensor(bb, device="cuda")
    got = tl.layer_norm(x, (C,), w, b, out_dtype=out_dt)
    assert got.dtype == out_dt
    want = np_ln(xin.astype(np.float64), wb.astype(np.float64),
                 bb.astype(np.float64))
    rtol, atol = (1e-5, 1e-6) if out_dt == tl.float32 else TOL[out_dt]
    np.testing.assert_allclose(back(got), want, rtol=rtol, atol=atol)


def test_layernorm_out_dtype_rejects_int():
    x = tl.tensor(rng.standard_normal((2, 8)).astype(np.float32),
                  device="cuda")
    with pytest.raises(ValueError, match="must be float"):
        tl.layer_norm(x, (8,), out_dtype=tl.int32)
