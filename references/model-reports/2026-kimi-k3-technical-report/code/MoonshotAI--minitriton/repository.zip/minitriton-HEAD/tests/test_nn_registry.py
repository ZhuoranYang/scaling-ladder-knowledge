"""nn.Module registry symmetry: replacing or deleting an
attribute must drop its registry entries — guards against a bare list
of submodules registering name.0/name.1 keys that no replacement clears,
a Module attr overwritten by a Parameter keeping the old module
registered, and ``del m.head`` leaving _modules untouched, so
parameters() (and everything built on it: optimizer, zero_grad, to,
train) would keep seeing detached params. Device-independent registry
logic; runs on cpu. No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl
from minitriton import nn


def lin(i=4, o=4):
    return nn.Linear(i, o, device="cpu")


def test_list_replaced_by_none_clears_indexed_keys():
    m = nn.Module()
    m.layers = [lin(), lin()]
    assert len(list(m.parameters())) == 4
    m.layers = None
    assert len(list(m.parameters())) == 0
    assert not any(k.startswith("layers") for k in m._modules)


def test_list_shrink_drops_removed_element():
    m = nn.Module()
    m.layers = [lin(), lin()]
    m.layers = m.layers[:1]
    assert len(list(m.parameters())) == 2
    assert "layers.1" not in m._modules


def test_list_reregistration_replaces_all_keys():
    m = nn.Module()
    m.layers = [lin(), lin(), lin()]
    assert len(list(m.parameters())) == 6
    m.layers = [lin(4, 2)]
    assert len(list(m.parameters())) == 2
    assert set(m._modules) == {"layers.0"}


def test_list_replaced_by_module():
    m = nn.Module()
    m.layers = [lin(), lin()]
    m.layers = lin(4, 2)
    assert len(list(m.parameters())) == 2
    assert set(m._modules) == {"layers"}


def test_module_attr_overwritten_by_parameter():
    m = nn.Module()
    m.sub = lin()
    m.sub = nn.Parameter(np.ones((4,), dtype=np.float32), device="cpu")
    params = list(m.parameters())
    assert len(params) == 1
    assert params[0].shape == (4,)
    assert "sub" not in m._modules


def test_module_attr_overwritten_by_int():
    # control: already worked
    m = nn.Module()
    m.sub = lin()
    m.sub = 3
    assert len(list(m.parameters())) == 0


def test_module_attr_overwritten_by_module():
    # control: already worked
    m = nn.Module()
    m.sub = lin()
    m.sub = lin(4, 2)
    assert len(list(m.parameters())) == 2


def test_del_module_attr_unregisters():
    m = nn.Module()
    m.head = lin()
    del m.head
    assert not hasattr(m, "head")
    assert len(list(m.parameters())) == 0
    assert "head" not in m._modules


def test_del_parameter_attr_unregisters():
    m = nn.Module()
    m.p = nn.Parameter(np.ones((4,), dtype=np.float32), device="cpu")
    assert len(list(m.parameters())) == 1
    del m.p
    assert len(list(m.parameters())) == 0
    assert "p" not in m._parameters


def test_del_list_attr_unregisters_indexed_keys():
    m = nn.Module()
    m.layers = [lin(), lin()]
    del m.layers
    assert len(list(m.parameters())) == 0
    assert not any(k.startswith("layers") for k in m._modules)


def test_reregister_after_del_works():
    m = nn.Module()
    m.head = lin()
    del m.head
    m.head = lin(4, 2)
    assert len(list(m.parameters())) == 2
    x = tl.tensor(np.ones((1, 4), dtype=np.float32), device="cpu")
    assert m.head(x).shape == (1, 2)  # callable


def test_parameter_dedup_still_works():
    # the identity re-registration rule (tied weights) must survive
    class Tied(nn.Module):
        def __init__(self):
            super().__init__()
            self.emb = nn.Embedding(5, 4, device="cpu")
            self.head = nn.Linear(4, 5, bias=False, device="cpu")
            self.head.weight = self.emb.weight
    m = Tied()
    assert len(list(m.parameters())) == 1


def test_train_and_zero_grad_reach_list_registered_modules():
    m = nn.Module()
    m.layers = [lin(), lin()]
    m.train(False)
    assert all(not sub.training for sub in m.layers)
    x = tl.tensor(np.ones((1, 4), dtype=np.float32), device="cpu")
    for sub in m.layers:
        sub(x).sum().backward()
    m.zero_grad()
    assert all(p.grad is None for p in m.parameters())
