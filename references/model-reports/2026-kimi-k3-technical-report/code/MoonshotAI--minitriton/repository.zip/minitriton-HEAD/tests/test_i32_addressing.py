"""i32 addressing: >2**31-element single tensors must not wrap kernel
addresses.

Two layers of coverage:

1. Row-chunk correctness matrix (always on): the launchers in
   device/cuda/kernels/{norm,misc}.py split over-budget problems into
   row-range sub-launches (CE's `_ce_i32_row_budget` pattern, generalized)
   and route data-driven out-of-range addresses (embedding/gather/spmm
   weight rows) through guarded per-chunk kernels. Monkeypatching the
   module `_I32_ELEM_BUDGET` forces that chunking at toy sizes, so the
   exact same code paths that run at >2**31 elements are exercised here
   against numpy oracles — including ragged tails, odd widths, and
   multi-chunk vocab/row splits.

2. Real >2**31-element end-to-end cases (MT_TEST_BIG=1; ~9-26 GiB of
   device memory): layer_norm fwd, the fused LN backward (stacked
   partial planes), and embedding fwd with an over-budget weight.
"""

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
import minitriton.precision as _prec
from minitriton.device.cuda import ops as tl_be
from minitriton.device.cuda.kernels import misc as misc_mod
from minitriton.device.cuda.kernels import norm as norm_mod


@pytest.fixture(autouse=True)
def _clear_plans():
    # the eager layer's plan cache replays resolved fast-launch handles,
    # bypassing the Python launchers (and the budget checks) — clear it
    # so every test really goes through the chunked launch logic.
    tl_be._PLANS.clear()
    yield
    tl_be._PLANS.clear()


class KernelSpy:
    """Records the grids a @tl.kernel is launched with."""

    def __init__(self, orig):
        self.orig = orig
        self.grids = []

    def __getitem__(self, grid):
        self.grids.append(tuple(grid))
        return self.orig[grid]


def force_budget(monkeypatch, mod, C, rows, itemsize=4):
    """Force row-chunking at `rows * align` rows per launch (align =
    16/itemsize, the budget helper's 16B-alignment discipline)."""
    align = 16 // itemsize
    monkeypatch.setattr(mod, "_I32_ELEM_BUDGET", rows * C * align)
    return rows * align


def f64(x):
    return np.asarray(x, dtype=np.float64)


def np_ln(x, w=None, b=None, eps=1e-5):
    x = f64(x)
    mu = x.mean(-1, keepdims=True)
    var = ((x - mu) ** 2).mean(-1, keepdims=True)
    y = (x - mu) / np.sqrt(var + eps)
    if w is not None:
        y = y * f64(w)
    if b is not None:
        y = y + f64(b)
    return y


# ---------------------------------------------------------------------------
# norm.py launchers
# ---------------------------------------------------------------------------


def test_softmax_row_chunking(monkeypatch):
    rng = np.random.default_rng(0)
    R, C = 21, 100  # 8-row chunks -> 3 launches, ragged tail
    rpc = force_budget(monkeypatch, norm_mod, C, 2)
    assert rpc == 8
    spy = KernelSpy(norm_mod.softmax_row_kernel)
    monkeypatch.setattr(norm_mod, "softmax_row_kernel", spy)
    x = rng.standard_normal((R, C)).astype(np.float32)
    for log in (False, True):
        spy.grids.clear()
        got = tl_be.softmax_rows(tl.tensor(x), log).numpy()
        z = f64(x) - f64(x).max(-1, keepdims=True)
        e = np.exp(z)
        ref = (z - np.log(e.sum(-1, keepdims=True))) if log \
            else (e / e.sum(-1, keepdims=True))
        np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-6)
        assert spy.grids == [(8,), (8,), (5,)]


def test_layernorm_row_chunking(monkeypatch):
    rng = np.random.default_rng(1)
    R, C = 21, 128
    force_budget(monkeypatch, norm_mod, C, 2)  # 8-row chunks
    spy = KernelSpy(norm_mod.layernorm_kernel)
    monkeypatch.setattr(norm_mod, "layernorm_kernel", spy)
    x = rng.standard_normal((R, C)).astype(np.float32)
    w = rng.standard_normal(C).astype(np.float32)
    b = rng.standard_normal(C).astype(np.float32)
    got = tl_be.layer_norm_rows(tl.tensor(x), tl.tensor(w), tl.tensor(b),
                                1e-5).numpy()
    np.testing.assert_allclose(got, np_ln(x, w, b), rtol=1e-5, atol=1e-6)
    assert spy.grids == [(8,), (8,), (5,)]
    # no weight/bias variant through the same chunked path
    spy.grids.clear()
    got2 = tl_be.layer_norm_rows(tl.tensor(x), None, None, 1e-5).numpy()
    np.testing.assert_allclose(got2, np_ln(x), rtol=1e-5, atol=1e-6)
    assert spy.grids == [(8,), (8,), (5,)]


def test_rmsnorm_row_chunking(monkeypatch):
    rng = np.random.default_rng(2)
    R, C = 21, 96
    force_budget(monkeypatch, norm_mod, C, 2)
    x = rng.standard_normal((R, C)).astype(np.float32)
    w = rng.standard_normal(C).astype(np.float32)
    got = tl_be.rms_norm_rows(tl.tensor(x), tl.tensor(w), 1e-6).numpy()
    ms = (f64(x) ** 2).mean(-1, keepdims=True)
    ref = f64(x) / np.sqrt(ms + 1e-6) * f64(w)
    np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-6)


def test_add_layernorm_row_chunking(monkeypatch):
    rng = np.random.default_rng(3)
    R, C = 21, 100
    force_budget(monkeypatch, norm_mod, C, 2)
    x = rng.standard_normal((R, C)).astype(np.float32)
    res = rng.standard_normal((R, C)).astype(np.float32)
    w = rng.standard_normal(C).astype(np.float32)
    b = rng.standard_normal(C).astype(np.float32)
    got, s = tl_be.add_layernorm_rows(tl.tensor(x), tl.tensor(res),
                                      tl.tensor(w), tl.tensor(b), 1e-5,
                                      need_sum=True)
    xs = f64(x) + f64(res)
    np.testing.assert_allclose(s.numpy(), xs, rtol=1e-5, atol=1e-6)
    np.testing.assert_allclose(got.numpy(), np_ln(xs, w, b),
                               rtol=1e-5, atol=1e-6)


def test_softmax_backward_row_chunking(monkeypatch):
    rng = np.random.default_rng(4)
    R, C = 21, 100
    force_budget(monkeypatch, norm_mod, C, 2)
    g = rng.standard_normal((R, C)).astype(np.float32)
    z = f64(rng.standard_normal((R, C)))
    e = np.exp(z - z.max(-1, keepdims=True))
    y = (e / e.sum(-1, keepdims=True)).astype(np.float32)
    got = tl_be.softmax_backward_rows(tl.tensor(g), tl.tensor(y)).numpy()
    ref = f64(y) * (f64(g) - (f64(g) * f64(y)).sum(-1, keepdims=True))
    np.testing.assert_allclose(got, ref, rtol=1e-5, atol=1e-6)
    ly = np.log(e / e.sum(-1, keepdims=True)).astype(np.float32)
    gotl = tl_be.log_softmax_backward_rows(tl.tensor(g), tl.tensor(ly)).numpy()
    refl = f64(g) - np.exp(f64(ly)) * f64(g).sum(-1, keepdims=True)
    np.testing.assert_allclose(gotl, refl, rtol=1e-5, atol=1e-6)


def np_ln_bwd(g, x, w=None, eps=1e-5):
    g, x = f64(g), f64(x)
    mu = x.mean(-1, keepdims=True)
    var = ((x - mu) ** 2).mean(-1, keepdims=True)
    rstd = 1.0 / np.sqrt(var + eps)
    xh = (x - mu) * rstd
    u = g if w is None else g * f64(w)
    C = x.shape[1]
    dx = rstd * (u - u.mean(-1, keepdims=True)
                 - xh * (u * xh).mean(-1, keepdims=True))
    return dx, xh


def test_layernorm_backward_row_chunking(monkeypatch):
    rng = np.random.default_rng(5)
    R, C = 21, 128
    force_budget(monkeypatch, norm_mod, C, 2)
    g = rng.standard_normal((R, C)).astype(np.float32)
    x = rng.standard_normal((R, C)).astype(np.float32)
    w = rng.standard_normal(C).astype(np.float32)
    dx, xh = tl_be.layernorm_backward_rows(tl.tensor(g), tl.tensor(x),
                                           tl.tensor(w), 1e-5)
    ref_dx, ref_xh = np_ln_bwd(g, x, w)
    np.testing.assert_allclose(dx.numpy(), ref_dx, rtol=1e-4, atol=1e-5)
    np.testing.assert_allclose(xh.numpy(), ref_xh, rtol=1e-5, atol=1e-6)


def test_layernorm_backward_fused_row_chunking(monkeypatch):
    rng = np.random.default_rng(6)
    R, C = 21, 128
    force_budget(monkeypatch, norm_mod, C, 2)  # 3 chunks (8/8/5)
    spy2 = KernelSpy(norm_mod.reduce_col2_stats_kernel)
    monkeypatch.setattr(norm_mod, "reduce_col2_stats_kernel", spy2)
    spy3 = KernelSpy(norm_mod.splitk_reduce2_kernel)
    monkeypatch.setattr(norm_mod, "splitk_reduce2_kernel", spy3)
    g = rng.standard_normal((R, C)).astype(np.float32)
    x = rng.standard_normal((R, C)).astype(np.float32)
    w = rng.standard_normal(C).astype(np.float32)
    dx, dgamma, dbeta = tl_be.layernorm_backward_fused(
        tl.tensor(g), tl.tensor(x), tl.tensor(w), 1e-5)
    ref_dx, ref_xh = np_ln_bwd(g, x, w)
    np.testing.assert_allclose(dx.numpy(), ref_dx, rtol=1e-4, atol=1e-5)
    np.testing.assert_allclose(dgamma.numpy(), (f64(g) * ref_xh).sum(0),
                               rtol=1e-4, atol=1e-4)
    np.testing.assert_allclose(dbeta.numpy(), f64(g).sum(0),
                               rtol=1e-4, atol=1e-4)
    # per-chunk partials + exactly one fold over the stacked planes
    assert len(spy2.grids) == 3
    assert len(spy3.grids) == 1


def test_layernorm_backward_dx_row_chunking(monkeypatch):
    rng = np.random.default_rng(7)
    R, C = 21, 128
    force_budget(monkeypatch, norm_mod, C, 2)
    g = rng.standard_normal((R, C)).astype(np.float32)
    x = rng.standard_normal((R, C)).astype(np.float32)
    w = rng.standard_normal(C).astype(np.float32)
    dx = tl_be.layernorm_backward_dx(tl.tensor(g), tl.tensor(x),
                                     tl.tensor(w), 1e-5)
    ref_dx, _ = np_ln_bwd(g, x, w)
    np.testing.assert_allclose(dx.numpy(), ref_dx, rtol=1e-4, atol=1e-5)


def test_rmsnorm_backward_row_chunking(monkeypatch):
    rng = np.random.default_rng(8)
    R, C = 21, 96
    force_budget(monkeypatch, norm_mod, C, 2)
    g = rng.standard_normal((R, C)).astype(np.float32)
    x = rng.standard_normal((R, C)).astype(np.float32)
    w = rng.standard_normal(C).astype(np.float32)
    dx, xr = tl_be.rmsnorm_backward_rows(tl.tensor(g), tl.tensor(x),
                                         tl.tensor(w), 1e-6)
    ms = (f64(x) ** 2).mean(-1, keepdims=True)
    rstd = 1.0 / np.sqrt(ms + 1e-6)
    ref_xr = f64(x) * rstd
    u = f64(g) * f64(w)
    ref_dx = rstd * (u - ref_xr * (u * ref_xr).mean(-1, keepdims=True))
    np.testing.assert_allclose(xr.numpy(), ref_xr, rtol=1e-5, atol=1e-6)
    np.testing.assert_allclose(dx.numpy(), ref_dx, rtol=1e-4, atol=1e-5)


# ---------------------------------------------------------------------------
# misc.py: embedding
# ---------------------------------------------------------------------------


def test_embedding_row_chunking(monkeypatch):
    rng = np.random.default_rng(9)
    V, C, R = 7, 64, 21  # V under budget: idx/out side chunking only
    # idx/out side: 8-row chunks -> 3 launches (8/8/5)
    force_budget(monkeypatch, misc_mod, C, 2)
    spy = KernelSpy(misc_mod.embedding_kernel)
    monkeypatch.setattr(misc_mod, "embedding_kernel", spy)
    w = rng.standard_normal((V, C)).astype(np.float32)
    idx = rng.integers(0, V, size=R).astype(np.int32)
    got = tl_be.embedding_rows(tl.tensor(w), tl.tensor(idx)).numpy()
    np.testing.assert_allclose(got, f64(w)[idx], rtol=1e-6, atol=1e-7)
    assert spy.grids == [(8,), (8,), (5,)]


def test_embedding_vocab_chunking(monkeypatch):
    rng = np.random.default_rng(10)
    V, C, R = 21, 32, 5  # R stays under the row budget: weight side only
    # weight side: 8 vocab rows/launch -> 3 guarded launches (8/8/5)
    force_budget(monkeypatch, misc_mod, C, 2)
    spy = KernelSpy(misc_mod.embedding_chunked_kernel)
    monkeypatch.setattr(misc_mod, "embedding_chunked_kernel", spy)
    spy_plain = KernelSpy(misc_mod.embedding_kernel)
    monkeypatch.setattr(misc_mod, "embedding_kernel", spy_plain)
    w = rng.standard_normal((V, C)).astype(np.float32)
    idx = rng.integers(0, V, size=R).astype(np.int32)
    got = tl_be.embedding_rows(tl.tensor(w), tl.tensor(idx)).numpy()
    np.testing.assert_allclose(got, f64(w)[idx], rtol=1e-6, atol=1e-7)
    assert len(spy.grids) == 3 and not spy_plain.grids


def test_embedding_backward_chunking(monkeypatch):
    rng = np.random.default_rng(11)
    V, C, R = 21, 32, 17
    # both chunkings at once: g/idx 8-row chunks; dw also 8-row chunks
    force_budget(monkeypatch, misc_mod, C, 2)
    spy = KernelSpy(misc_mod.embedding_backward_chunked_kernel)
    monkeypatch.setattr(misc_mod, "embedding_backward_chunked_kernel", spy)
    g = rng.standard_normal((R, C)).astype(np.float32)
    idx = rng.integers(0, V, size=R).astype(np.int32)
    dw = tl_be.embedding_backward_rows(tl.tensor(g), tl.tensor(idx), V)
    ref = np.zeros((V, C), dtype=np.float64)
    np.add.at(ref, idx, f64(g))
    np.testing.assert_allclose(dw.numpy(), ref, rtol=1e-5, atol=1e-5)
    assert spy.grids  # the guarded dw-chunk path really ran


def test_embedding_backward_ds_vocab_chunking(monkeypatch):
    rng = np.random.default_rng(12)
    V, C, R = 21, 64, 7  # R under budget: the ds scan stays unchunked
    force_budget(monkeypatch, misc_mod, C, 2)
    monkeypatch.setattr(_prec, "_EMBED_FP64", True)
    g = rng.standard_normal((R, C)).astype(np.float32)
    idx = rng.integers(0, V, size=R).astype(np.int32)
    dw = tl_be.embedding_backward_rows(tl.tensor(g), tl.tensor(idx), V)
    ref = np.zeros((V, C), dtype=np.float64)
    np.add.at(ref, idx, f64(g))
    # TwoSum-compensated serial accumulation: fp64-class result
    np.testing.assert_allclose(dw.numpy(), ref, rtol=1e-6, atol=1e-6)


# ---------------------------------------------------------------------------
# misc.py: argmax / gather / scatter
# ---------------------------------------------------------------------------


def test_argmax_row_chunking(monkeypatch):
    rng = np.random.default_rng(13)
    R, C = 21, 100
    force_budget(monkeypatch, misc_mod, C, 2)
    x = rng.standard_normal((R, C)).astype(np.float32)
    got = tl_be.argmax_rows(tl.tensor(x)).numpy()
    np.testing.assert_array_equal(got, np.argmax(f64(x), axis=1))


def test_gather_flat_chunking(monkeypatch):
    rng = np.random.default_rng(14)
    N, E = 500, 21
    force_budget(monkeypatch, misc_mod, 1, 2)  # 8-element chunks
    x = rng.standard_normal(N).astype(np.float32)
    idx = rng.integers(0, N, size=E).astype(np.int32)
    got = tl_be.gather_flat(tl.tensor(x), tl.tensor(idx)).numpy()
    np.testing.assert_allclose(got, f64(x)[idx], rtol=1e-6, atol=1e-7)


def test_scatter_flat_chunking(monkeypatch):
    rng = np.random.default_rng(15)
    N, E = 64, 21
    force_budget(monkeypatch, misc_mod, 1, 2)
    src = rng.standard_normal(E).astype(np.float32)
    idx = rng.permutation(N)[:E].astype(np.int32)  # unique: deterministic
    got = tl_be.scatter_add_flat(tl.tensor(src), tl.tensor(idx), N).numpy()
    ref = np.zeros(N, dtype=np.float64)
    np.add.at(ref, idx, f64(src))
    np.testing.assert_allclose(got, ref, rtol=1e-6, atol=1e-7)


def test_gather_cols_row_chunking(monkeypatch):
    rng = np.random.default_rng(16)
    R, C, E = 21, 40, 24
    # rows are max(C, E) wide for the budget -> 8-row chunks
    force_budget(monkeypatch, misc_mod, max(C, E), 2)
    x = rng.standard_normal((R, C)).astype(np.float32)
    idx = rng.integers(0, C, size=(R, E)).astype(np.int32)
    got = tl_be.gather_cols(tl.tensor(x), tl.tensor(idx)).numpy()
    ref = np.take_along_axis(f64(x), idx, axis=1)
    np.testing.assert_allclose(got, ref, rtol=1e-6, atol=1e-7)


def test_gather_rc_row_chunking(monkeypatch):
    rng = np.random.default_rng(17)
    N, C, E = 7, 24, 21  # x stays under budget: idx/out side chunking
    force_budget(monkeypatch, misc_mod, C, 2)
    spy = KernelSpy(misc_mod.gather_rc_kernel)
    monkeypatch.setattr(misc_mod, "gather_rc_kernel", spy)
    x = rng.standard_normal((N, C)).astype(np.float32)
    idx = rng.integers(0, N, size=(E, C)).astype(np.int32)
    got = tl_be.gather_rc(tl.tensor(x), tl.tensor(idx)).numpy()
    ref = np.take_along_axis(f64(x), idx, axis=0)
    np.testing.assert_allclose(got, ref, rtol=1e-6, atol=1e-7)
    assert spy.grids == [(8,), (8,), (5,)]


def test_gather_rc_source_chunking(monkeypatch):
    rng = np.random.default_rng(18)
    N, C, E = 21, 24, 5  # E under budget: gather-source side only
    # gather source side: 8 x-rows/launch -> 3 guarded launches
    force_budget(monkeypatch, misc_mod, C, 2)
    spy = KernelSpy(misc_mod.gather_rc_chunked_kernel)
    monkeypatch.setattr(misc_mod, "gather_rc_chunked_kernel", spy)
    x = rng.standard_normal((N, C)).astype(np.float32)
    idx = rng.integers(0, N, size=(E, C)).astype(np.int32)
    got = tl_be.gather_rc(tl.tensor(x), tl.tensor(idx)).numpy()
    ref = np.take_along_axis(f64(x), idx, axis=0)
    np.testing.assert_allclose(got, ref, rtol=1e-6, atol=1e-7)
    assert len(spy.grids) == 3


def test_gather_cols_backward_row_chunking(monkeypatch):
    rng = np.random.default_rng(19)
    R, C, E = 21, 40, 24
    force_budget(monkeypatch, misc_mod, max(C, E), 2)
    g = rng.standard_normal((R, E)).astype(np.float32)
    idx = np.stack([rng.permutation(C)[:E] for _ in range(R)]
                   ).astype(np.int32)  # unique per row: deterministic
    dx = tl_be.gather_cols_backward(tl.tensor(g), tl.tensor(idx), C)
    ref = np.zeros((R, C), dtype=np.float64)
    for r in range(R):
        np.add.at(ref[r], idx[r], f64(g[r]))
    np.testing.assert_allclose(dx.numpy(), ref, rtol=1e-6, atol=1e-7)


def test_gather_rc_backward_chunking(monkeypatch):
    rng = np.random.default_rng(20)
    N, C, E = 21, 24, 9
    # dx side guarded chunks (8 rows/launch) + g/idx side row chunks
    force_budget(monkeypatch, misc_mod, C, 2)
    spy = KernelSpy(misc_mod.gather_rc_backward_chunked_kernel)
    monkeypatch.setattr(misc_mod, "gather_rc_backward_chunked_kernel", spy)
    g = rng.standard_normal((E, C)).astype(np.float32)
    flat = rng.permutation(N * C)[: E * C]
    idx = (flat // C).astype(np.int32).reshape(E, C)  # unique targets
    dx = tl_be.gather_rc_backward(tl.tensor(g), tl.tensor(idx), N)
    ref = np.zeros((N, C), dtype=np.float64)
    cols = np.tile(np.arange(C), E)
    np.add.at(ref, (idx.ravel(), cols), f64(g).ravel())
    np.testing.assert_allclose(dx.numpy(), ref, rtol=1e-6, atol=1e-7)
    assert spy.grids


# ---------------------------------------------------------------------------
# misc.py: spmm CSR
# ---------------------------------------------------------------------------


def make_csr(rng, R, KR, density=0.3):
    A = (rng.random((R, KR)) < density) * rng.standard_normal((R, KR))
    rows, cols = np.nonzero(A)
    order = np.lexsort((cols, rows))
    rows, cols = rows[order], cols[order]
    rp = np.zeros(R + 1, dtype=np.int32)
    np.add.at(rp, rows + 1, 1)
    rp = np.cumsum(rp).astype(np.int32)
    val = A[rows, cols].astype(np.float32)
    return A.astype(np.float32), rp, cols.astype(np.int32), val


def test_spmm_csr_row_chunking(monkeypatch):
    rng = np.random.default_rng(21)
    R, KR, N = 21, 30, 16
    force_budget(monkeypatch, misc_mod, max(N, 2), 2)  # 8-row chunks
    A, rp, col, val = make_csr(rng, R, KR)
    b = rng.standard_normal((KR, N)).astype(np.float32)
    got = tl_be.spmm_csr_forward(tl.tensor(rp), tl.tensor(col),
                                 tl.tensor(val), tl.tensor(b)).numpy()
    np.testing.assert_allclose(got, f64(A) @ f64(b), rtol=1e-5, atol=1e-5)


def test_spmm_csr_b_chunking(monkeypatch):
    rng = np.random.default_rng(22)
    R, KR, N = 7, 21, 16
    force_budget(monkeypatch, misc_mod, N, 2)  # 8 B-rows/launch -> 3
    spy = KernelSpy(misc_mod.spmm_csr_bchunked_kernel)
    monkeypatch.setattr(misc_mod, "spmm_csr_bchunked_kernel", spy)
    A, rp, col, val = make_csr(rng, R, KR)
    b = rng.standard_normal((KR, N)).astype(np.float32)
    got = tl_be.spmm_csr_forward(tl.tensor(rp), tl.tensor(col),
                                 tl.tensor(val), tl.tensor(b)).numpy()
    np.testing.assert_allclose(got, f64(A) @ f64(b), rtol=1e-5, atol=1e-5)
    assert len(spy.grids) == 3


def test_spmm_csr_backward_val_chunking(monkeypatch):
    rng = np.random.default_rng(23)
    R, KR, N = 7, 21, 16
    force_budget(monkeypatch, misc_mod, N, 2)
    spy = KernelSpy(misc_mod.spmm_csr_backward_val_bchunked_kernel)
    monkeypatch.setattr(misc_mod, "spmm_csr_backward_val_bchunked_kernel",
                        spy)
    A, rp, col, val = make_csr(rng, R, KR)
    b = rng.standard_normal((KR, N)).astype(np.float32)
    g = rng.standard_normal((R, N)).astype(np.float32)
    dv = tl_be.spmm_csr_backward_val(tl.tensor(g), tl.tensor(rp),
                                     tl.tensor(col), tl.tensor(b)).numpy()
    rows = np.repeat(np.arange(R), np.diff(rp))
    ref = (f64(g)[rows] * f64(b)[col]).sum(-1)
    np.testing.assert_allclose(dv, ref, rtol=1e-5, atol=1e-5)
    assert spy.grids


def test_spmm_csr_backward_dense_chunking(monkeypatch):
    rng = np.random.default_rng(24)
    R, KR, N = 7, 21, 16
    force_budget(monkeypatch, misc_mod, N, 2)
    spy = KernelSpy(misc_mod.spmm_csr_backward_dense_bchunked_kernel)
    monkeypatch.setattr(misc_mod,
                        "spmm_csr_backward_dense_bchunked_kernel", spy)
    A, rp, col, val = make_csr(rng, R, KR)
    g = rng.standard_normal((R, N)).astype(np.float32)
    db = tl_be.spmm_csr_backward_dense(tl.tensor(g), tl.tensor(rp),
                                       tl.tensor(col), tl.tensor(val),
                                       KR).numpy()
    np.testing.assert_allclose(db, f64(A).T @ f64(g), rtol=1e-4, atol=1e-4)
    assert spy.grids


# ---------------------------------------------------------------------------
# chunked vs unchunked consistency (per-row kernels must be bit-equal)
# ---------------------------------------------------------------------------


def test_chunked_matches_unchunked_bitwise(monkeypatch):
    """Row kernels compute each output row from the same input row with
    the same reduction tree regardless of chunking — chunked launches
    must reproduce the unchunked result bit-for-bit. (The fused weight
    grads and the accumulating spmm/scatter paths re-order their fp32
    sums across chunks: tolerance-only there.)"""
    rng = np.random.default_rng(30)
    R, C = 21, 128
    x = rng.standard_normal((R, C)).astype(np.float32)
    w = rng.standard_normal(C).astype(np.float32)
    b = rng.standard_normal(C).astype(np.float32)
    g = rng.standard_normal((R, C)).astype(np.float32)

    ref = tl_be.layer_norm_rows(tl.tensor(x), tl.tensor(w), tl.tensor(b),
                                1e-5).numpy()
    ref_dx, ref_xh = tl_be.layernorm_backward_rows(
        tl.tensor(g), tl.tensor(x), tl.tensor(w), 1e-5)
    ref_sm = tl_be.softmax_rows(tl.tensor(x), False).numpy()
    V = 64
    wt = rng.standard_normal((V, C)).astype(np.float32)
    idx = rng.integers(0, V, size=R).astype(np.int32)
    ref_emb = tl_be.embedding_rows(tl.tensor(wt), tl.tensor(idx)).numpy()
    N = 32
    xr = rng.standard_normal((N, C)).astype(np.float32)
    idx2 = rng.integers(0, N, size=(R, C)).astype(np.int32)
    ref_grc = tl_be.gather_rc(tl.tensor(xr), tl.tensor(idx2)).numpy()

    # drop the plans the reference calls resolved: the chunked calls
    # below must go through the Python launchers, not the cached
    # fast-launch handles
    tl_be._PLANS.clear()

    # tiny budgets on both modules: everything above chunks
    force_budget(monkeypatch, norm_mod, C, 2)
    force_budget(monkeypatch, misc_mod, C, 2)

    got = tl_be.layer_norm_rows(tl.tensor(x), tl.tensor(w), tl.tensor(b),
                                1e-5).numpy()
    assert got.tobytes() == ref.tobytes()
    got_dx, got_xh = tl_be.layernorm_backward_rows(
        tl.tensor(g), tl.tensor(x), tl.tensor(w), 1e-5)
    assert got_dx.numpy().tobytes() == ref_dx.numpy().tobytes()
    assert got_xh.numpy().tobytes() == ref_xh.numpy().tobytes()
    got_sm = tl_be.softmax_rows(tl.tensor(x), False).numpy()
    assert got_sm.tobytes() == ref_sm.tobytes()
    got_emb = tl_be.embedding_rows(tl.tensor(wt), tl.tensor(idx)).numpy()
    assert got_emb.tobytes() == ref_emb.tobytes()  # V=64 > 8: guarded
    got_grc = tl_be.gather_rc(tl.tensor(xr), tl.tensor(idx2)).numpy()
    assert got_grc.tobytes() == ref_grc.tobytes()  # N=32 > 8: guarded

    # fused bwd: dx stays bit-equal; the weight-grad column sums reorder
    dx2, dg2, db2 = tl_be.layernorm_backward_fused(
        tl.tensor(g), tl.tensor(x), tl.tensor(w), 1e-5)
    assert dx2.numpy().tobytes() == ref_dx.numpy().tobytes()
    ref_dx2, ref_xh2 = np_ln_bwd(g, x, w)
    np.testing.assert_allclose(dg2.numpy(), (f64(g) * ref_xh2).sum(0),
                               rtol=1e-5, atol=1e-5)
    np.testing.assert_allclose(db2.numpy(), f64(g).sum(0),
                               rtol=1e-5, atol=1e-5)


# ---------------------------------------------------------------------------
# real >2**31-element end-to-end cases (gated: ~9-26 GiB device memory)
# ---------------------------------------------------------------------------

BIG = os.environ.get("MT_TEST_BIG", "") not in ("", "0")


def _rows(rs, C):
    rs = np.asarray(rs, dtype=np.float64)[:, None]
    cs = np.arange(C, dtype=np.float64)[None, :]
    return np.sin(rs * 0.001 + cs * 0.01) + np.cos(rs * 0.0007 - cs * 0.02)


@pytest.mark.skipif(not BIG, reason="set MT_TEST_BIG=1 for >2**31-element e2e")
def test_big_layernorm_fwd():
    R, C = 16_900_001, 128  # 2.163e9 f32 elements (8.65 GiB)
    x_np = _rows(np.arange(R), C).astype(np.float32)
    x = tl.from_numpy(x_np, device="cuda")
    del x_np
    y = tl.layer_norm(x, (C,))
    yn = y.numpy()
    del x, y
    b = (2**31) // C  # first row whose base offset wraps i32
    for r in [0, 1, b - 1, b, b + 1, R - 2, R - 1]:
        ref = np_ln(_rows([r], C))[0]
        np.testing.assert_allclose(yn[r], ref, rtol=1e-5, atol=1e-6)


@pytest.mark.skipif(not BIG, reason="set MT_TEST_BIG=1 for >2**31-element e2e")
def test_big_layernorm_backward_fused():
    R, C = 16_900_001, 128
    g_np = _rows(np.arange(R) * 0.7, C).astype(np.float32)
    x_np = _rows(np.arange(R), C).astype(np.float32)
    g = tl.from_numpy(g_np, device="cuda")
    x = tl.from_numpy(x_np, device="cuda")
    w = tl.tensor(np.full(C, 1.3, dtype=np.float32))
    dx, dgamma, dbeta = tl_be.layernorm_backward_fused(g, x, w, 1e-5)
    dxn = dx.numpy()
    del g, x, dx
    b = (2**31) // C
    for r in [0, b - 1, b, b + 1, R - 1]:
        ref_dx, _ = np_ln_bwd(g_np[r:r + 1], x_np[r:r + 1],
                              np.full(C, 1.3, dtype=np.float32))
        np.testing.assert_allclose(dxn[r], ref_dx[0], rtol=1e-4, atol=1e-5)
    del dxn
    # weight grads: full column sums in fp64 on the host. The kernel
    # accumulates 16.9M terms per column in fp32 (partials + fold), so
    # the comparison tolerance reflects that accumulation noise, not the
    # addressing — the point of this test is that rows past the 2**31
    # boundary are read/written at all (pre-fix: ILLEGAL_ADDRESS).
    _, ref_xh = np_ln_bwd(g_np, x_np, np.full(C, 1.3, dtype=np.float32))
    np.testing.assert_allclose(dgamma.numpy(), (f64(g_np) * ref_xh).sum(0),
                               rtol=5e-2, atol=1.0)
    np.testing.assert_allclose(dbeta.numpy(), f64(g_np).sum(0),
                               rtol=5e-2, atol=1.0)


@pytest.mark.skipif(not BIG, reason="set MT_TEST_BIG=1 for >2**31-element e2e")
def test_big_embedding_fwd():
    V, C = 1_060_000, 2048  # 2.17e9 f32 elements (8.69 GiB)
    vs = np.arange(V, dtype=np.float64)[:, None]
    cs = np.arange(C, dtype=np.float64)[None, :]
    w_np = (np.sin(vs * 0.01 + cs * 0.001) * 0.5
            + np.cos(vs * 0.003 - cs * 0.002)).astype(np.float32)
    w = tl.from_numpy(w_np, device="cuda")
    del w_np, vs, cs
    b = (2**31) // C  # first vocab row whose base offset wraps i32
    idx_np = np.array([0, 1, b - 1, b, b + 1, V - 2, V - 1],
                      dtype=np.int64)
    out = tl.embedding(w, tl.from_numpy(idx_np, device="cuda"))
    on = out.numpy()
    del w, out
    rs = idx_np.astype(np.float64)[:, None]
    cs = np.arange(C, dtype=np.float64)[None, :]
    ref = np.sin(rs * 0.01 + cs * 0.001) * 0.5 + np.cos(rs * 0.003 - cs * 0.002)
    np.testing.assert_allclose(on, ref, rtol=1e-5, atol=1e-6)
