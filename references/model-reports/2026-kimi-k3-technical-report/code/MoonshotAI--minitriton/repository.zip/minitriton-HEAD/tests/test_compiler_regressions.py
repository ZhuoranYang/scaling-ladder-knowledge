"""Compiler regression tests: mask-fragment emission, cp.async zfill
folding, and newaxis shape semantics.

numpy-oracle only (tests/ stay torch-free). Covers:

- materialized (Tensor) i1 masks on flat-layout load/store/atomic: the
  flat mask's value IS the whole per-thread fragment; extracting a row
  from it used to feed a scalar to vector.reduction and crash the MLIR
  layer (segfault, not a Python error);
- tl.mma_tile VEC=False with a non-prefix (lower-bound, ``offs >= lo``)
  mask: cp.async's src-size zfill copies a leading run and zero-fills
  the tail, so it is only legal for prefix masks (``offs < hi``);
  non-prefix masks now stage synchronously, one predicated LDG+STS per
  element (the fold used to copy the wrong element AND zero the live
  one — silently wrong C tiles on bf16, where one 4B unit spans two
  columns);
- tl.atomic_add rejects non-f32 block values at trace time (they used
  to sail past the shape check and die in LLVM translation, feeding an
  f16 operand to red.global.add.f32);
- the t3 scalar-path (``cols % vl != 0``) zfill constant follows the
  element dtype — a hardcoded ``0.0`` crashed integer (BM, 1) t3 loads
  at trace ("expected floating point type");
- ``x[None]`` is numpy's ``x[None, :]`` — (1, N), data axis last (it
  used to produce (N, 1), contradicting ``x[None, :]``).
"""

import os
import subprocess
import sys
import textwrap

from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl

from test_mma import bf16_bits_to_f32, bf16_buffer, f32_to_bf16_bits  # noqa: E402


# ---------------------------------------------------------------------------
# materialized Tensor masks on flat layouts (load / store / atomic arms)
# ---------------------------------------------------------------------------

@tl.kernel
def _flat_mask_load_store(src, msrc, dst, R: tl.constexpr, C: tl.constexpr):
    offs_r = tl.arange(0, R)
    offs_c = tl.arange(0, C)
    offs = offs_r[:, None] * C + offs_c[None, :]
    m = tl.load(msrc + offs) > 0          # materialized i1 Tensor (flat)
    v = tl.load(src + offs, mask=m, other=0.0)
    tl.store(dst + offs, v, mask=m)


@tl.kernel
def _flat_mask_atomic(src, msrc, dst, R: tl.constexpr, C: tl.constexpr):
    offs_r = tl.arange(0, R)
    offs_c = tl.arange(0, C)
    offs = offs_r[:, None] * C + offs_c[None, :]
    m = tl.load(msrc + offs) > 0          # materialized i1 Tensor (flat)
    v = tl.load(src + offs)
    tl.atomic_add(dst + offs, v, mask=m)


@pytest.mark.parametrize("R,C,warps", [(4, 24, 1), (8, 24, 2)])
def test_flat_materialized_mask_load_store(R, C, warps):
    # C % nt != 0 and (R*C) % nt == 0 with C % ept == 0 -> the default
    # layout is flat (ept=3 here, so the store does not reroute to t2)
    rng = np.random.default_rng(0)
    src_np = rng.standard_normal(R * C).astype(np.float32)
    keep = (rng.standard_normal(R * C) > 0)
    src = tl.Buffer.from_numpy(src_np)
    msrc = tl.Buffer.from_numpy(keep.astype(np.float32))
    dst = tl.Buffer.from_numpy(np.zeros(R * C, np.float32))
    _flat_mask_load_store[(1, 1)](src, msrc, dst, R=R, C=C,
                                  num_warps=warps)
    tl.synchronize()
    np.testing.assert_allclose(dst.to_numpy(), src_np * keep, rtol=1e-6)


def test_flat_materialized_mask_atomic():
    R, C = 4, 24
    rng = np.random.default_rng(1)
    src_np = rng.standard_normal(R * C).astype(np.float32)
    keep = (rng.standard_normal(R * C) > 0)
    init_np = rng.standard_normal(R * C).astype(np.float32)
    src = tl.Buffer.from_numpy(src_np)
    msrc = tl.Buffer.from_numpy(keep.astype(np.float32))
    dst = tl.Buffer.from_numpy(init_np.copy())
    _flat_mask_atomic[(1, 1)](src, msrc, dst, R=R, C=C, num_warps=1)
    tl.synchronize()
    np.testing.assert_allclose(dst.to_numpy(), init_np + src_np * keep,
                               rtol=1e-6)


# ---------------------------------------------------------------------------
# mma_tile VEC=False + non-prefix masks (cp.async zfill is prefix-only)
# ---------------------------------------------------------------------------

@tl.kernel
def _mma_b_lo_mask_kernel(a_ptr, b_ptr, c_ptr,
                          BM: tl.constexpr, BN: tl.constexpr,
                          BK: tl.constexpr, LO: tl.constexpr):
    offs_m = tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * BN + offs_n[None, :]
    bn = (offs_n >= LO)[None, :]
    acc = tl.mma_tile(a_ptrs, b_ptrs, BK, ATOM="bf16", VEC=False,
                      b_mask=bn)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


@tl.kernel
def _mma_ta_lo_mask_kernel(a_ptr, b_ptr, c_ptr, lda,
                           BM: tl.constexpr, BN: tl.constexpr,
                           BK: tl.constexpr, LO: tl.constexpr):
    offs_m = tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] + offs_k[None, :] * lda
    b_ptrs = b_ptr + offs_k[:, None] * BN + offs_n[None, :]
    am = (offs_m >= LO)[:, None]
    acc = tl.mma_tile(a_ptrs, b_ptrs, BK, ATOM="bf16", VEC=False,
                      a_mask=am, TRANS_A=True)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


def _bf16_ref(a_np, b_np):
    """f64 product of the exact (RNE-rounded) bf16 inputs."""
    a_q = bf16_bits_to_f32(f32_to_bf16_bits(a_np)).astype(np.float64)
    b_q = bf16_bits_to_f32(f32_to_bf16_bits(b_np)).astype(np.float64)
    return a_q @ b_q


def test_mma_zfill_lower_bound_b_col_mask():
    """Plain-B staging units run along n (gran=2 for bf16): an odd LO
    makes the boundary 4B unit [F, T] — the non-prefix case."""
    BM = BN = BK = 16
    LO = 5
    rng = np.random.default_rng(0)
    a_np = rng.standard_normal((BM, BK)).astype(np.float32)
    b_np = rng.standard_normal((BK, BN)).astype(np.float32)
    da = bf16_buffer(f32_to_bf16_bits(a_np))
    db = bf16_buffer(f32_to_bf16_bits(b_np))
    dc = tl.Buffer(BM * BN, tl.float32)
    _mma_b_lo_mask_kernel[(1, 1)](da, db, dc, BM=BM, BN=BN, BK=BK, LO=LO,
                                  num_warps=1)
    tl.synchronize()
    b_ref = b_np.copy()
    b_ref[:, :LO] = 0.0
    np.testing.assert_allclose(dc.to_numpy().reshape(BM, BN),
                               _bf16_ref(a_np, b_ref), rtol=2e-2, atol=1e-3)


def test_mma_zfill_lower_bound_trans_a_row_mask():
    """Transposed-A staging units run along m: a lower-bound row mask is
    the non-prefix case there (same guard, other stage arm)."""
    BM = BN = BK = 16
    LO = 5
    lda = BM  # even, as bf16 pair-granular staging requires
    rng = np.random.default_rng(1)
    phys = rng.standard_normal((BK, lda)).astype(np.float32)
    a_np = phys[:, :BM].T.copy()              # logical (BM, BK)
    b_np = rng.standard_normal((BK, BN)).astype(np.float32)
    da = bf16_buffer(f32_to_bf16_bits(phys.reshape(-1)))
    db = bf16_buffer(f32_to_bf16_bits(b_np))
    dc = tl.Buffer(BM * BN, tl.float32)
    _mma_ta_lo_mask_kernel[(1, 1)](da, db, dc, lda, BM=BM, BN=BN, BK=BK,
                                   LO=LO, num_warps=1)
    tl.synchronize()
    a_ref = a_np.copy()
    a_ref[:LO, :] = 0.0
    np.testing.assert_allclose(dc.to_numpy().reshape(BM, BN),
                               _bf16_ref(a_ref, b_np), rtol=2e-2, atol=1e-3)


# ---------------------------------------------------------------------------
# newaxis: x[None] == x[None, :] == (1, N); x[:, None] == (N, 1)
# ---------------------------------------------------------------------------

@tl.kernel
def _newaxis_store_kernel(x_ptr, o_ptr, N: tl.constexpr,
                          FORM: tl.constexpr):
    offs = tl.arange(0, N)
    one = tl.arange(0, 1)
    x = tl.load(x_ptr + offs)
    if FORM == 0:        # x[None]    -> (1, N)
        tl.store(o_ptr + one[:, None] * N + offs[None, :], x[None])
    elif FORM == 1:      # x[None, :] -> (1, N)
        tl.store(o_ptr + one[:, None] * N + offs[None, :], x[None, :])
    else:                # x[:, None] -> (N, 1)
        tl.store(o_ptr + offs[:, None] + one[None, :] * 0, x[:, None])


@tl.kernel
def _mask_newaxis_kernel(x_ptr, o_ptr, N: tl.constexpr, LO: tl.constexpr):
    offs = tl.arange(0, N)
    one = tl.arange(0, 1)
    x = tl.load(x_ptr + offs)
    m = (offs >= LO)[None]           # symbolic mask: (1, N), like [None, :]
    tl.store(o_ptr + one[:, None] * N + offs[None, :], x[None, :], mask=m)


@pytest.mark.parametrize("form", [0, 1])
@pytest.mark.parametrize("N", [5, 64])   # 5: rep layout; 64: dist layout
def test_newaxis_row_forms(form, N):
    # the (1, N) store compiles only if the value is (1, N)-shaped, and
    # the values pin WHERE the elements landed
    x_np = np.arange(N, dtype=np.float32) + 1.0
    o = tl.Buffer(N, tl.float32)
    _newaxis_store_kernel[(1, 1)](tl.Buffer.from_numpy(x_np), o, N=N,
                                  FORM=form, num_warps=1)
    tl.synchronize()
    np.testing.assert_array_equal(o.to_numpy(), x_np)


def test_newaxis_col_form():
    # x[:, None] -> (N, 1): rep layout (on a distributed block x[:, None]
    # is a separate, intentional "needs layout conversion" error)
    x_np = np.arange(5, dtype=np.float32) + 1.0
    o = tl.Buffer(5, tl.float32)
    _newaxis_store_kernel[(1, 1)](tl.Buffer.from_numpy(x_np), o, N=5,
                                  FORM=2, num_warps=1)
    tl.synchronize()
    np.testing.assert_array_equal(o.to_numpy(), x_np)


def test_mask_newaxis_row():
    N, LO = 64, 20
    x_np = np.arange(N, dtype=np.float32) + 1.0
    o = tl.Buffer.from_numpy(np.zeros(N, np.float32))
    _mask_newaxis_kernel[(1, 1)](tl.Buffer.from_numpy(x_np), o, N=N, LO=LO,
                                 num_warps=1)
    tl.synchronize()
    want = np.where(np.arange(N) >= LO, x_np, 0.0)
    np.testing.assert_array_equal(o.to_numpy(), want)


# ---------------------------------------------------------------------------
# promoted block stored back to a narrower pointer (f16 load, * 2.0, store)
# ---------------------------------------------------------------------------

@tl.kernel
def _f16_scale_store_kernel(src, dst, N: tl.constexpr):
    offs = tl.arange(0, N)
    v = tl.load(src + offs)          # f16 block
    tl.store(dst + offs, v * 2.0)    # promotes to f32; store casts back


@pytest.mark.parametrize("N", [5, 64])   # 5: rep layout; 64: dist layout
def test_f16_block_store_after_scalar_promotion(N):
    # f16 block * python float promotes to f32 (same as numpy); the
    # default block-store path must cast back to the pointer's element
    # type lane-wise — it used to reach memref.store with an f32 vector
    # against an f16 memref and die in the MLIR verifier.
    rng = np.random.default_rng(2)
    src_np = rng.standard_normal(N).astype(np.float16)
    dst = tl.Buffer.from_numpy(np.zeros(N, np.float16))
    _f16_scale_store_kernel[(1, 1)](tl.Buffer.from_numpy(src_np), dst,
                                    N=N, num_warps=1)
    tl.synchronize()
    np.testing.assert_array_equal(dst.to_numpy(), src_np * np.float16(2.0))


# ---------------------------------------------------------------------------
# loop-carried symbolic offsets: stride updates must persist or error out
# ---------------------------------------------------------------------------

from minitriton.frontend.code_generator import DSLCompileError  # noqa: E402


@tl.kernel
def _loop_const_stride_scale(src, dst, N: tl.constexpr):
    offs = tl.arange(0, N)
    for i in range(3):
        tl.store(dst + i * N + offs, tl.load(src + offs))
        offs = offs * 2            # compile-time stride 1 -> 2 -> 4


def test_loop_carried_const_stride_change_errors():
    # a carried offset may update its base but not its stride structure;
    # it used to be silently reset to the loop-entry stride, so every
    # iteration stored to the same addresses. Now a clear trace-time error.
    src = tl.Buffer.from_numpy(np.ones(8, np.float32))
    dst = tl.Buffer.from_numpy(np.zeros(64, np.float32))
    with pytest.raises(DSLCompileError, match="offset structure"):
        _loop_const_stride_scale[(1, 1)](src, dst, N=8, num_warps=1)


@tl.kernel
def _loop_runtime_stride_scale(src, dst, k, N: tl.constexpr):
    v = tl.load(src + tl.arange(0, N))
    offs = tl.arange(0, N) * k     # runtime stride: carried as an SSA value
    for i in range(3):
        tl.store(dst + offs, v)
        offs = offs * 2


def test_loop_carried_runtime_stride_persists():
    # a runtime stride rides the loop carry: iteration i must store to
    # j * k * 2**i (pre-fix every iteration reused the entry stride).
    N, k = 8, 3
    src_np = np.arange(1, N + 1, dtype=np.float32)
    dst = tl.Buffer.from_numpy(np.zeros((N - 1) * k * 4 + 1, np.float32))
    _loop_runtime_stride_scale[(1, 1)](tl.Buffer.from_numpy(src_np), dst,
                                       k, N=N, num_warps=1)
    tl.synchronize()
    want = np.zeros_like(dst.to_numpy())
    stride = k
    for _ in range(3):
        for j in range(N):
            want[j * stride] = src_np[j]   # later iterations win overlaps
        stride *= 2
    np.testing.assert_array_equal(dst.to_numpy(), want)


# ---------------------------------------------------------------------------
# tl.async_stage: tile must fit the pipe's shared-memory footprint
# ---------------------------------------------------------------------------

from minitriton.compiler.builder import TileConfigError  # noqa: E402


@tl.kernel
def _stage_oversized_tile(src, TR: tl.constexpr, TC: tl.constexpr):
    p = tl.stage_pipe((TC, TC), tl.float32)
    offs_r = tl.arange(0, TR)
    offs_c = tl.arange(0, TC)
    t = tl.async_stage(p, src + offs_r[:, None] * TC + offs_c[None, :])
    tl.async_wait(t, 0)


def test_async_stage_rejects_oversized_tile():
    # a (64,32) tile into a (32,32) pipe used to slip through and the
    # cp.async copies stomped the adjacent shared-memory buffer; now a
    # trace-time error. (Smaller tiles stay legal: the double-buffered
    # attention kernel stages half-tiles into a 2x pipe via OFFSET.)
    src = tl.Buffer.from_numpy(np.zeros(64 * 32, np.float32))
    with pytest.raises(TileConfigError, match="does not fit"):
        _stage_oversized_tile[(1, 1)](src, TR=64, TC=32, num_warps=4)


# ---------------------------------------------------------------------------
# mma_tile masks: K-dim predicates are rejected (the K arg / EVEN_K owns K)
# ---------------------------------------------------------------------------

@tl.kernel
def _mma_a_kdim_mask_kernel(a_ptr, b_ptr, c_ptr,
                            BM: tl.constexpr, BN: tl.constexpr,
                            BK: tl.constexpr, LO: tl.constexpr):
    offs_m = tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * BN + offs_n[None, :]
    am = (offs_k >= LO)[None, :]     # K-dim predicate on A
    acc = tl.mma_tile(a_ptrs, b_ptrs, BK, ATOM="bf16", VEC=False, a_mask=am)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


@tl.kernel
def _mma_b_kdim_mask_kernel(a_ptr, b_ptr, c_ptr,
                            BM: tl.constexpr, BN: tl.constexpr,
                            BK: tl.constexpr, LO: tl.constexpr):
    offs_m = tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * BN + offs_n[None, :]
    bm_ = (offs_k >= LO)[:, None]    # K-dim predicate on B
    acc = tl.mma_tile(a_ptrs, b_ptrs, BK, ATOM="bf16", VEC=False, b_mask=bm_)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


@tl.kernel
def _mma_a_row_mask_kernel(a_ptr, b_ptr, c_ptr,
                           BM: tl.constexpr, BN: tl.constexpr,
                           BK: tl.constexpr, HI: tl.constexpr):
    offs_m = tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * BN + offs_n[None, :]
    am = (offs_m < HI)[:, None]      # legal: M-dim predicate on A
    acc = tl.mma_tile(a_ptrs, b_ptrs, BK, ATOM="bf16", VEC=False, a_mask=am)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


def _bf16_io(a_np, b_np):
    da = bf16_buffer(f32_to_bf16_bits(a_np))
    db = bf16_buffer(f32_to_bf16_bits(b_np))
    return da, db, tl.Buffer(a_np.shape[0] * b_np.shape[1], tl.float32)


def test_mma_tile_rejects_a_mask_k_pred():
    # a_mask's column predicates (the K dim) used to be silently dropped
    # by staging — the kernel computed the full product. Now a
    # trace-time error.
    BM = BN = BK = 16
    rng = np.random.default_rng(0)
    da, db, dc = _bf16_io(rng.standard_normal((BM, BK)).astype(np.float32),
                          rng.standard_normal((BK, BN)).astype(np.float32))
    with pytest.raises(TileConfigError, match="a_mask"):
        _mma_a_kdim_mask_kernel[(1, 1)](da, db, dc, BM=BM, BN=BN, BK=BK,
                                        LO=4, num_warps=1)


def test_mma_tile_rejects_b_mask_k_pred():
    # same hole on the other operand: b_mask's row predicates (K) had no
    # consumer either
    BM = BN = BK = 16
    rng = np.random.default_rng(1)
    da, db, dc = _bf16_io(rng.standard_normal((BM, BK)).astype(np.float32),
                          rng.standard_normal((BK, BN)).astype(np.float32))
    with pytest.raises(TileConfigError, match="b_mask"):
        _mma_b_kdim_mask_kernel[(1, 1)](da, db, dc, BM=BM, BN=BN, BK=BK,
                                        LO=4, num_warps=1)


def test_mma_tile_a_row_mask_still_stages():
    # the legal direction stays live: row-only a_mask (M-dim) zfills the
    # masked rows of the staged A tile
    BM = BN = BK = 16
    HI = 5
    rng = np.random.default_rng(2)
    a_np = rng.standard_normal((BM, BK)).astype(np.float32)
    b_np = rng.standard_normal((BK, BN)).astype(np.float32)
    da, db, dc = _bf16_io(a_np, b_np)
    _mma_a_row_mask_kernel[(1, 1)](da, db, dc, BM=BM, BN=BN, BK=BK, HI=HI,
                                   num_warps=1)
    tl.synchronize()
    a_ref = a_np.copy()
    a_ref[HI:, :] = 0.0
    np.testing.assert_allclose(dc.to_numpy().reshape(BM, BN),
                               _bf16_ref(a_ref, b_np), rtol=2e-2, atol=1e-3)


# ---------------------------------------------------------------------------
# tl.async_stage: dtype and compile-time OFFSET footprint checks
# ---------------------------------------------------------------------------

@tl.kernel
def _stage_dtype_mismatch(src, TR: tl.constexpr, TC: tl.constexpr):
    p = tl.stage_pipe((TR, TC), tl.bfloat16)
    offs_r = tl.arange(0, TR)
    offs_c = tl.arange(0, TC)
    t = tl.async_stage(p, src + offs_r[:, None] * TC + offs_c[None, :])
    tl.async_wait(t, 0)


def test_async_stage_rejects_dtype_mismatch():
    # equal element counts but an f32 tile into a bf16 pipe used to pass
    # the footprint check and die in the MLIR verifier; now a trace-time
    # error naming both element types
    src = tl.Buffer.from_numpy(np.zeros(32 * 32, np.float32))
    with pytest.raises(TileConfigError, match="element types"):
        _stage_dtype_mismatch[(1, 1)](src, TR=32, TC=32, num_warps=4)


@tl.kernel
def _stage_static_offset_overrun(src, TR: tl.constexpr, TC: tl.constexpr):
    p = tl.stage_pipe((TR, TC), tl.float32)
    offs_r = tl.arange(0, TR)
    offs_c = tl.arange(0, TC)
    t = tl.async_stage(p, src + offs_r[:, None] * TC + offs_c[None, :],
                       OFFSET=(TR - 1) * TC)
    tl.async_wait(t, 0)


def test_async_stage_rejects_static_offset_overrun():
    # compile-time OFFSET + tile past the pipe's capacity used to reach
    # the GPU and fault (CUDA_ERROR_ILLEGAL_ADDRESS); now a compile
    # error. (A boundary OFFSET — tile into a 2x pipe — stays legal: the
    # double-buffered attention kernel stages that way.)
    src = tl.Buffer.from_numpy(np.zeros(32 * 32, np.float32))
    with pytest.raises(DSLCompileError, match="OFFSET"):
        _stage_static_offset_overrun[(1, 1)](src, TR=32, TC=32, num_warps=4)


# ---------------------------------------------------------------------------
# scatter store (materialized i32 offsets) of a promoted block: cast back
# ---------------------------------------------------------------------------

@tl.kernel
def _f16_scatter_store_kernel(src, isrc, dst, N: tl.constexpr):
    offs = tl.arange(0, N)
    idx = tl.load(isrc + offs)         # materialized i32 index block
    v = tl.load(src + offs) * 2.0      # f16 block, promoted to f32
    tl.store(dst + idx, v)             # scatter store casts back to f16


@pytest.mark.parametrize("N", [5, 64])   # 5: rep layout; 64: dist layout
def test_f16_scatter_store_after_scalar_promotion(N):
    # same promotion as the block-store case above, but through the
    # MatOff scatter path — the f32 value used to reach memref.store
    # against the f16 memref and die in the MLIR verifier
    rng = np.random.default_rng(3)
    src_np = rng.standard_normal(N).astype(np.float16)
    idx_np = rng.permutation(N).astype(np.int32)
    dst = tl.Buffer.from_numpy(np.zeros(N, np.float16))
    _f16_scatter_store_kernel[(1, 1)](tl.Buffer.from_numpy(src_np),
                                      tl.Buffer.from_numpy(idx_np), dst,
                                      N=N, num_warps=1)
    tl.synchronize()
    want = np.zeros(N, np.float16)
    want[idx_np] = src_np * np.float16(2.0)
    np.testing.assert_array_equal(dst.to_numpy(), want)


# ---------------------------------------------------------------------------
# tl.exp under MT_PRECISE_MATH=1: sub-f32 blocks extend to f32 (the lever is
# an import-time snapshot, so this needs a fresh interpreter)
# ---------------------------------------------------------------------------

def test_exp_precise_math_subf32_block(tmp_path):
    tests_dir = str(Path(__file__).resolve().parent)
    child = tmp_path / "precise_exp16_child.py"
    child.write_text(textwrap.dedent(f"""
        import sys
        sys.path.insert(0, {tests_dir!r})
        import numpy as np
        import minitriton as tl
        from test_mma import bf16_bits_to_f32, bf16_buffer, f32_to_bf16_bits

        @tl.kernel
        def _exp16(src, dst, N: tl.constexpr):
            offs = tl.arange(0, N)
            tl.store(dst + offs, tl.exp(tl.load(src + offs)))

        N = 64
        rng = np.random.default_rng(0)
        x = rng.uniform(-4.0, 4.0, N).astype(np.float32)

        xf = x.astype(np.float16)
        df = tl.Buffer.from_numpy(np.zeros(N, np.float16))
        _exp16[(1, 1)](tl.Buffer.from_numpy(xf), df, N=N, num_warps=1)
        tl.synchronize()
        np.testing.assert_allclose(df.to_numpy(), np.exp(xf), rtol=1e-3)

        xb = bf16_bits_to_f32(f32_to_bf16_bits(x))  # exact bf16 inputs
        db = tl.Buffer(N, tl.bfloat16)
        _exp16[(1, 1)](bf16_buffer(f32_to_bf16_bits(x)), db, N=N, num_warps=1)
        tl.synchronize()
        u = np.empty(db.nelem, dtype=np.uint16)
        db.device.memcpy_d2h(u, db.ptr, db.nbytes)
        np.testing.assert_allclose(bf16_bits_to_f32(u), np.exp(xb), rtol=1e-2)
        print("precise exp16 ok")
    """))
    root = str(Path(__file__).resolve().parents[1])
    p = subprocess.run([sys.executable, str(child)],
                       capture_output=True, text=True,
                       env={**os.environ, "PYTHONPATH": root,
                            "MT_PRECISE_MATH": "1"})
    assert p.returncode == 0, p.stderr
    assert "precise exp16 ok" in p.stdout


# ---------------------------------------------------------------------------
# matmul_tile (f32 whole-K pipeline): K-dim mask predicates are rejected
# ---------------------------------------------------------------------------

@tl.kernel
def _matmul_tile_kdim_mask_kernel(a_ptr, b_ptr, c_ptr,
                                  BM: tl.constexpr, BN: tl.constexpr,
                                  BK: tl.constexpr, K: tl.constexpr,
                                  LO: tl.constexpr):
    offs_m = tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * BN + offs_n[None, :]
    am = (offs_k >= LO)[None, :]     # K-dim predicate on A
    acc = tl.matmul_tile(a_ptrs, b_ptrs, K, 4, 8, VEC=False, a_mask=am)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


def test_matmul_tile_rejects_k_dim_mask():
    # same convention as mma_tile: staging consumes a_mask's row preds
    # (M) / b_mask's col preds (N) only — a K-dim predicate used to be
    # silently dropped; now a trace-time error.
    BM = BN = 32
    BK = 16
    rng = np.random.default_rng(3)
    da = tl.Buffer.from_numpy(rng.standard_normal(BM * BK).astype(np.float32))
    db = tl.Buffer.from_numpy(rng.standard_normal(BK * BN).astype(np.float32))
    dc = tl.Buffer.from_numpy(np.zeros(BM * BN, np.float32))
    with pytest.raises(TileConfigError, match="a_mask"):
        _matmul_tile_kdim_mask_kernel[(1, 1)](da, db, dc, BM=BM, BN=BN,
                                              BK=BK, K=BK, LO=4,
                                              num_warps=1)


# ---------------------------------------------------------------------------
# tl.atomic_add block-value dtype guard (f32 only, like the target check)
# ---------------------------------------------------------------------------

@tl.kernel
def _atomic_f16_block_kernel(src, dst, N: tl.constexpr):
    offs = tl.arange(0, N)
    v = tl.load(src + offs)          # f16 block value, f32 target
    tl.atomic_add(dst + offs, v)


def test_atomic_add_block_value_dtype_guard():
    # an f16 block value used to pass the shape check and die in LLVM
    # translation (red.global.add.f32 with an f16 operand) — now a
    # trace-time TileConfigError; f32 block values stay covered by
    # test_flat_materialized_mask_atomic above
    N = 128
    src = tl.Buffer.from_numpy(np.ones(N, np.float16))
    dst = tl.Buffer.from_numpy(np.zeros(N, np.float32))
    with pytest.raises(TileConfigError, match="f32 block values only"):
        _atomic_f16_block_kernel[(1,)](src, dst, N=N, num_warps=4)


# ---------------------------------------------------------------------------
# t3 scalar path (cols % vl != 0): the zfill constant follows the elem dtype
# ---------------------------------------------------------------------------

@tl.kernel
def _t3_i32_stat_kernel(x_ptr, y_ptr, T, BM: tl.constexpr):
    offs_m = tl.arange(0, BM)
    x_pt = x_ptr + offs_m[:, None]
    y_pt = y_ptr + offs_m[:, None]
    v = tl.load(x_pt, LAYOUT=tl.t3_layout((BM, 1)),
                mask=(offs_m < T)[:, None])
    tl.store(y_pt, v)                # unmasked: masked rows land as zfill


def test_t3_scalar_path_i32_zfill():
    # the (BM, 1) t3 load takes the scalar path (1 % vl != 0); its zfill
    # constant was a hardcoded 0.0 and crashed integer dtypes at trace
    BM, T = 128, 100
    x = np.arange(BM, dtype=np.int32)
    tx = tl.Buffer.from_numpy(x)
    ty = tl.Buffer.from_numpy(np.full(BM, -1, np.int32))
    _t3_i32_stat_kernel[(1,)](tx, ty, T, BM=BM, num_warps=4)
    tl.synchronize()
    ref = np.where(np.arange(BM) < T, x, 0)
    np.testing.assert_array_equal(ty.to_numpy(), ref)
