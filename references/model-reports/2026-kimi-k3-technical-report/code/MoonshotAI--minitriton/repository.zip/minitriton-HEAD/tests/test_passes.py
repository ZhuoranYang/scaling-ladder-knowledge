"""W-IR pass framework tests (compiler/passes.py, IR-1): registration,
priority ordering, env kill-switches, stats shape, and the
verify_sync soundness verifier catching an unsynchronized dependence
the transforms would have fixed. solve_tril remains the end-to-end
oracle (tests/test_solve_tril.py).
"""

import sys

from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from minitriton.compiler import passes
from minitriton.compiler.lowering import lower_device_module
from minitriton.compiler.wir import dump_form

MOD_TMPL = """
module {
  gpu.module @m {
    gpu.func @k(%buf: memref<128xf32, #gpu.address_space<workgroup>>) kernel attributes {wir.nt = 128 : i64} {
      %tid = gpu.thread_id x
      %c0 = arith.constant 0 : index
      %v = arith.constant 1.0 : f32
      memref.store %v, %buf[%c0] {wir.off = "@OFF0@", wir.sh = "s", wir.vl = 1 : i64} : memref<128xf32, #gpu.address_space<workgroup>>
      @BAR@%l = memref.load %buf[%c0] {wir.off = "@OFF1@", wir.sh = "s", wir.vl = 1 : i64} : memref<128xf32, #gpu.address_space<workgroup>>
      gpu.return
    }
  }
}
"""


def _mod(off0, off1, barrier=False):
    esc = lambda f: dump_form(f).replace('"', '\\"')
    m = MOD_TMPL.replace("@OFF0@", esc(off0)) \
                .replace("@OFF1@", esc(off1)) \
                .replace("@BAR@", "gpu.barrier\n      " if barrier else "")
    return m


def test_registry_and_priority():
    names = [p.name for p in passes.PASSES]
    assert "p1" in names and "p2" in names and "verify_sync" in names
    pm = passes.PassManager()
    assert [p.name for p in pm.transforms] == ["p1", "p2"]
    assert [p.name for p in pm.verifiers] == ["verify_sync"]


def test_env_kill_switches(monkeypatch):
    monkeypatch.setenv("MINITRITON_WIR_P2", "0")
    pm = passes.PassManager()
    assert [p.name for p in pm.transforms] == ["p1"]
    assert [p.name for p in pm.verifiers] == ["verify_sync"]
    monkeypatch.setenv("MINITRITON_WIR_PASSES", "0")
    pm = passes.PassManager()
    assert pm.transforms == [] and pm.verifiers == []


def test_stats_shape_and_flat_keys(monkeypatch):
    monkeypatch.setenv("MINITRITON_WIR_PASSES", "1")
    n0 = len(passes.stats())
    # independent offsets: no sync needed, but the verifier runs
    lower_device_module(_mod(("tid",), ("add", ("tid",), ("c", 64))))
    st = passes.stats()[-1]
    for key in ("func", "p1_distributed", "p1_bail_dep",
                "p1_bail_opaque", "p2_top_warp", "p2_top_lane",
                "p2_inner_warp", "p2_inner_lane",
                "verify_sync_segments", "verify_sync_checked"):
        assert key in st
    assert st["verify_sync_checked"] == st["verify_sync_segments"] >= 1


def test_verify_sync_catches_missing_barrier(monkeypatch):
    """thread t reads the word thread (t+32)%128 wrote: a cross-warp
    R-after-W with no separator — with transforms off, the verifier
    must hard-error."""
    monkeypatch.setenv("MINITRITON_WIR_P1", "0")
    monkeypatch.setenv("MINITRITON_WIR_P2", "0")
    shifted = ("mod", ("add", ("tid",), ("c", 32)), 128)
    with pytest.raises(RuntimeError, match="verify_sync"):
        lower_device_module(_mod(("tid",), shifted))
    # the same module with an explicit separator passes the verifier
    monkeypatch.delenv("MINITRITON_WIR_P2", raising=False)
    lower_device_module(_mod(("tid",), shifted, barrier=True))
