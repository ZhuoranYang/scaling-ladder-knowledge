"""KDA v2/v3 fused-pipeline tests — prefill optimization.

Stage-wise plane checks and e2e for the fused CUDA pipeline in
device/cuda/kernels/kda.py (kda_decay / kda_wy2 / solve / kda_mv3a / kda_mv3b /
kda_scan (one-level + segmented) / kda_out2), against the same oracle
hierarchy as test_kda.py: L2 = the fp64 numpy chunk closed form
(device.cpu._kda_chunk_np) and an fp32 kernel-form simulation of the v3
numerics (scalar shift + +-80 clip, tail-shifted write keys, the
reassociated affine scan S = Diag(exp(gT))(.)S - Aw@S + b with
Aw = wt@(M@delta), b = wt@(M@v)). The red-line parity checks assert
rtol/atol 1e-5 against both the fp64 oracle and the v1 CUDA pipeline.
No torch in tests/.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import ops as tl_ops
from minitriton.device.cpu import _kda_chunk_np

C = 64
RTOL, ATOL = 2e-4, 5e-4
PAR_RTOL, PAR_ATOL = 1e-5, 1e-5   # red line: v2 vs fp64 oracle and vs v1


# ---------------------------------------------------------------------------
# input generation + fp64/fp32 preprocessing (mirrors ops/kda.py)
# ---------------------------------------------------------------------------

def _log_sigmoid_np(x):
    return np.where(x > 0, 0.0, x) - np.log(np.exp(-np.abs(x)) + 1.0)


def _sigmoid_np(x):
    return 1.0 / (1.0 + np.exp(-x))


def gen(B, H, T, dk, dv, seed=0, loga_lo=-0.7, with_s0=False):
    rng = np.random.default_rng(seed)
    q = rng.standard_normal((B, H, T, dk)).astype(np.float32)
    k = rng.standard_normal((B, H, T, dk)).astype(np.float32)
    v = rng.standard_normal((B, H, T, dv)).astype(np.float32)
    xb = rng.standard_normal((B, H, T)).astype(np.float32)
    loga = rng.uniform(loga_lo, 0.0, (B, H, T, dk))
    a = np.exp(loga)
    xd = np.log(a / (1.0 - a)).astype(np.float32)
    s0 = rng.standard_normal((B, H, dk, dv)).astype(np.float32) \
        if with_s0 else None
    return q, k, v, xb, xd, s0


def preprocess_np(q, k, v, xb, xd, dt):
    kn = k / np.sqrt((k * k).sum(-1, keepdims=True))
    qn = q / np.sqrt((q * q).sum(-1, keepdims=True))
    beta = _sigmoid_np(xb)
    loga = _log_sigmoid_np(xd)
    return (kn.astype(dt), qn.astype(dt), v.astype(dt),
            beta.astype(dt), loga.astype(dt))


# ---------------------------------------------------------------------------
# v3 kernel-form simulation (fp32): the exact numerical actions of the
# fused pipeline (incl. the reassociated affine scan and the Aw/b maps)
# ---------------------------------------------------------------------------

def _prod_of_squares_inv(L):
    """(I + L)^-1 for nilpotent strict-lower L (solve_tril control, as in
    test_kda.py — both approximate the inverse to ~1e-6)."""
    dt = L.dtype
    P = -L
    W = np.eye(L.shape[-1], dtype=dt) + P
    for _ in range(5):
        P = P @ P
        W = W + P @ W
    return W


def kda_v3_sim(q, k, v, xb, xd, s0=None, planes=False):
    f = np.float32
    kn, qn, vv, beta, loga = preprocess_np(q, k, v, xb, xd, f)
    B, H, T, dk = kn.shape
    dv = vv.shape[-1]
    NC = (T + C - 1) // C

    def _pad(x):
        n = NC * C - x.shape[2]
        if n == 0:
            return x
        pad = [(0, 0)] * x.ndim
        pad[2] = (0, n)
        return np.pad(x, pad)

    kn, qn, vv, loga, beta = (_pad(x) for x in (kn, qn, vv, loga, beta))
    il = np.tril(np.ones((C, C), dtype=f))
    strict = np.tril(il, -1)
    incl = il
    o = np.zeros((B, H, NC * C, dv), dtype=f)
    S = np.zeros((B, H, dk, dv), dtype=f) if s0 is None \
        else np.asarray(s0, f).copy()
    pl = None
    if planes:
        pl = {"g": np.zeros((B * H, NC, C, dk), dtype=f),
              "gt": np.zeros((B * H, NC, dk), dtype=f),
              "c": np.zeros((B * H, NC), dtype=f),
              "emc": np.zeros((B * H, NC), dtype=f),
              "l": np.zeros((B * H, NC, C, C), dtype=f),
              "m": np.zeros((B * H, NC, C, C), dtype=f),
              "delta": np.zeros((B * H, NC, C, dk), dtype=f),
              "qh": np.zeros((B * H, NC, C, dk), dtype=f),
              "wc": np.zeros((B * H, NC, dk, C), dtype=f),
              "wt": np.zeros((B * H, NC, dk, C), dtype=f),
              "md": np.zeros((B * H, NC, C, dk), dtype=f),
              "mv": np.zeros((B * H, NC, C, dv), dtype=f),
              "aw": np.zeros((B * H, NC, dk, dk), dtype=f),
              "bb": np.zeros((B * H, NC, dk, dv), dtype=f),
              "hc": np.zeros((B * H, NC, dk, dv), dtype=f)}
    for b in range(B):
        for h in range(H):
            s = S[b, h]
            for c in range(NC):
                lo = c * C
                loga_c = loga[b, h, lo:lo + C]
                g = (il @ loga_c).astype(f)
                gT = g[C - 1].copy()
                csh = max(gT.min(), np.float32(-80.0))
                emc = np.exp(-csh)
                d = np.exp(g)
                kn_c = kn[b, h, lo:lo + C]
                delta = (d * kn_c).astype(f)
                qhat = (d * qn[b, h, lo:lo + C]).astype(f)
                e = np.clip(csh - g, -80.0, 80.0)
                wc = (beta[b, h, lo:lo + C][:, None] * kn_c
                      * np.exp(e)).astype(f)
                L = ((delta @ wc.T) * strict * emc).astype(f)
                W = _prod_of_squares_inv(L)
                Md = (W @ delta).astype(f)
                Mv = (W @ vv[b, h, lo:lo + C]).astype(f)
                wt = (beta[b, h, lo:lo + C][:, None] * kn_c
                      * np.exp(gT[None, :] - g)).astype(f)   # tail-shifted
                Aw = (wt.T @ Md).astype(f)                  # raw, no diag
                bb = (wt.T @ Mv).astype(f)
                if planes:
                    bh, sl = b * H + h, c
                    pl["g"][bh, sl] = g
                    pl["gt"][bh, sl] = gT
                    pl["c"][bh, sl] = csh
                    pl["emc"][bh, sl] = emc
                    pl["l"][bh, sl] = L
                    pl["m"][bh, sl] = W
                    pl["delta"][bh, sl] = delta
                    pl["qh"][bh, sl] = qhat
                    pl["wc"][bh, sl] = wc.T
                    pl["wt"][bh, sl] = wt.T
                    pl["md"][bh, sl] = Md
                    pl["mv"][bh, sl] = Mv
                    pl["aw"][bh, sl] = Aw
                    pl["bb"][bh, sl] = bb
                    pl["hc"][bh, sl] = s
                vt = (Mv - Md @ s).astype(f)
                Aq = ((qhat @ wc.T) * incl * emc).astype(f)
                o[b, h, lo:lo + C] = qhat @ s + Aq @ vt
                # the reassociated one-dot scan update
                s = (np.exp(gT)[:, None] * s - Aw @ s + bb).astype(f)
            S[b, h] = s
    if planes:
        pl["s1"] = S
        pl["o"] = o[:, :, :T]
        return pl
    return o[:, :, :T], S


# ---------------------------------------------------------------------------
# GPU stage runner for the fused pipeline
# ---------------------------------------------------------------------------

def _cuda_run_stages(q, k, v, xb, xd, s0=None):
    """Run the fused pipeline stage by stage; returns the plane dicts."""
    from minitriton.device.cuda.kernels import kda as kda_k
    ts = [tl.tensor(x, device="cuda") for x in (q, k, v, xb, xd)]
    tq, tk, tv, txb, txd = ts
    B, H, T, dk = k.shape
    dv = v.shape[-1]
    BH = B * H
    NC = (T + C - 1) // C
    f = tl.float32
    kn = tl.empty((B, H, T, dk), f, "cuda")
    qn = tl.empty((B, H, T, dk), f, "cuda")
    g = tl.empty((BH * NC, C, dk), f, "cuda")
    gt = tl.empty((BH * NC, dk), f, "cuda")
    c = tl.empty((BH * NC,), f, "cuda")
    emc = tl.empty((BH * NC,), f, "cuda")
    planes = kda_k.alloc_wy_planes(BH, NC, dk)
    mv_planes = kda_k.alloc_mv_planes(BH, NC, dk, dv)
    scan_planes = kda_k.alloc_scan_planes(BH, NC, dk, dv)
    hc = tl.empty((BH * NC, dk, dv), f, "cuda")
    s1 = tl.empty((BH, dk, dv), f, "cuda")
    o = tl.empty((B, H, T, dv), f, "cuda")
    s0t = tl.tensor(s0, device="cuda") if s0 is not None else None
    kda_k.launch_kda_qknorm(tq, tk, qn, kn, B * H * T, dk)
    kda_k.launch_kda_decay(txd, g, gt, BH, T, NC, dk)
    kda_k.launch_kda_wy2(kn, qn, txb, g, gt, planes, c, emc, BH, T, NC, dk)
    kda_k.launch_kda_solve(planes, BH, NC)
    kda_k.launch_kda_mv3a(planes, mv_planes, tv, BH, T, NC, dk, dv)
    kda_k.launch_kda_mv3b(planes, mv_planes, scan_planes, BH, NC, dk, dv)
    kda_k.launch_kda_scan(scan_planes, gt, s0t, hc, s1, BH, T, NC, dk, dv)
    kda_k.launch_kda_out2(planes, mv_planes, hc, emc, o, BH, T, NC, dk, dv)
    tl.synchronize()
    return {"g": g, "gt": gt, "c": c, "emc": emc,
            "planes": planes, "mv": mv_planes, "scan": scan_planes,
            "hc": hc, "s1": s1, "o": o}


# ---------------------------------------------------------------------------
# stage-wise plane tests vs the v3 simulation
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("T", [63, 64, 65, 300])
@pytest.mark.parametrize("dk", [64, 128])
def test_dcy_planes(T, dk):
    q, k, v, xb, xd, _ = gen(2, 2, T, dk, dk, seed=T + dk)
    r = _cuda_run_stages(q, k, v, xb, xd)
    ref = kda_v3_sim(q, k, v, xb, xd, planes=True)
    np.testing.assert_allclose(r["g"].numpy(), ref["g"].reshape(r["g"].shape),
                               rtol=1e-3, atol=1e-4, err_msg="dcy g")
    np.testing.assert_allclose(r["gt"].numpy(),
                               ref["gt"].reshape(r["gt"].shape),
                               rtol=1e-3, atol=1e-4, err_msg="dcy gt")


@pytest.mark.parametrize("T", [63, 64, 65, 300])
@pytest.mark.parametrize("dk", [64, 128])
def test_wy2_planes(T, dk):
    q, k, v, xb, xd, _ = gen(2, 2, T, dk, dk, seed=T + dk + 1)
    r = _cuda_run_stages(q, k, v, xb, xd)
    ref = kda_v3_sim(q, k, v, xb, xd, planes=True)
    for nm, rtol, atol in (("delta", 1e-3, 1e-4), ("qh", 1e-3, 1e-4),
                           ("l", 1e-3, 1e-4), ("wt", 1e-3, 1e-4),
                           ("wc", 1e-2, 1e-30)):  # wc: exp(+-80) range
        got = r["planes"][nm].numpy()
        np.testing.assert_allclose(got, ref[nm].reshape(got.shape),
                                   rtol=rtol, atol=atol,
                                   err_msg=f"wy2 plane {nm}")
    np.testing.assert_allclose(r["c"].numpy(), ref["c"].reshape(r["c"].shape),
                               rtol=1e-5, atol=1e-6, err_msg="wy2 c")
    np.testing.assert_allclose(r["emc"].numpy(),
                               ref["emc"].reshape(r["emc"].shape),
                               rtol=1e-3, atol=1e-30, err_msg="wy2 emc")


@pytest.mark.parametrize("T", [63, 64, 65, 300])
@pytest.mark.parametrize("dk,dv", [(64, 64), (128, 128), (64, 128)])
def test_mv3_planes(T, dk, dv):
    q, k, v, xb, xd, _ = gen(2, 2, T, dk, dv, seed=T + dk + dv)
    r = _cuda_run_stages(q, k, v, xb, xd)
    ref = kda_v3_sim(q, k, v, xb, xd, planes=True)
    got_md = r["mv"]["md"].numpy()
    got_mv = r["mv"]["mv"].numpy()
    got_aw = r["scan"]["ab"].numpy()
    got_bb = r["scan"]["bb"].numpy()
    np.testing.assert_allclose(got_md, ref["md"].reshape(got_md.shape),
                               rtol=1e-3, atol=1e-4, err_msg="mv3a md")
    np.testing.assert_allclose(got_mv, ref["mv"].reshape(got_mv.shape),
                               rtol=1e-3, atol=1e-4, err_msg="mv3a mv")
    np.testing.assert_allclose(got_aw, ref["aw"].reshape(got_aw.shape),
                               rtol=1e-3, atol=1e-4, err_msg="mv3b aw")
    np.testing.assert_allclose(got_bb, ref["bb"].reshape(got_bb.shape),
                               rtol=1e-3, atol=1e-4, err_msg="mv3b bb")


@pytest.mark.parametrize("T,dk,dv", [(63, 64, 64), (64, 64, 64), (65, 64, 64),
                                     (300, 64, 64), (300, 128, 128),
                                     (300, 64, 128), (2048, 64, 64),
                                     (2048, 64, 128)])
@pytest.mark.parametrize("with_s0", [False, True])
def test_scan_state(T, dk, dv, with_s0):
    """hc/s1 vs the sim. T=2048 (NC=32) exercises the segmented scan at
    B2H2 (BH=4 <= 16) and the one-level scan at dk=128/dv=128; the
    B4H16 case below pins the one-level dispatch at BH > 32."""
    q, k, v, xb, xd, s0 = gen(2, 2, T, dk, dv, seed=T + dk,
                              with_s0=with_s0)
    r = _cuda_run_stages(q, k, v, xb, xd, s0)
    ref = kda_v3_sim(q, k, v, xb, xd, s0, planes=True)
    got_hc = r["hc"].numpy()
    got_s1 = r["s1"].numpy()
    np.testing.assert_allclose(got_hc, ref["hc"].reshape(got_hc.shape),
                               rtol=1e-3, atol=1e-4, err_msg="scan hc")
    np.testing.assert_allclose(got_s1, ref["s1"].reshape(got_s1.shape),
                               rtol=1e-3, atol=1e-4, err_msg="scan s1")


def test_scan_dispatch_paths():
    """Same math on all three dispatch paths: one-level (small NC, and
    throughput-bound BH > 32 at NC >= 32) and segmented (BH <= 16)."""
    for B, H, T in ((1, 2, 300), (4, 16, 2048), (1, 2, 2048), (2, 2, 2062)):
        q, k, v, xb, xd, s0 = gen(B, H, T, 64, 64, seed=T + B,
                                  with_s0=True)
        r = _cuda_run_stages(q, k, v, xb, xd, s0)
        ref = kda_v3_sim(q, k, v, xb, xd, s0, planes=True)
        np.testing.assert_allclose(
            r["s1"].numpy(), ref["s1"].reshape(r["s1"].shape),
            rtol=1e-3, atol=1e-4, err_msg=f"s1 B{B}H{H}T{T}")
        np.testing.assert_allclose(
            r["hc"].numpy(), ref["hc"].reshape(r["hc"].shape),
            rtol=1e-3, atol=1e-4, err_msg=f"hc B{B}H{H}T{T}")


# ---------------------------------------------------------------------------
# e2e matrix (cuda): fused pipeline vs L2 (fp64), the v3 sim, and the v1
# CUDA pipeline (red line rtol/atol 1e-5)
# ---------------------------------------------------------------------------

def _e2e(q, k, v, xb, xd, s0, rtol=RTOL, atol=ATOL, check_l2=True):
    from minitriton.device.cuda.kernels import kda as kda_k
    from minitriton.ops.kda import kda_preprocess
    args = [tl.tensor(x, device="cuda") for x in (q, k, v, xb, xd)]
    s0t = tl.tensor(s0, device="cuda") if s0 is not None else None
    o_g, s_g = tl_ops.kda_forward(*args, initial_state=s0t,
                                  output_final_state=True)
    # v1 pipeline for the parity red line
    with tl.no_grad():
        kn, qn, beta, loga, g, gt, c, emc = kda_preprocess(*args)
        o_1, s_1 = kda_k.kda_forward(kn, qn, args[2], beta, g, gt, c, emc,
                                     s0t, True)
    tl.synchronize()
    o_g, s_g = o_g.numpy(), s_g.numpy()
    assert np.all(np.isfinite(o_g)) and np.all(np.isfinite(s_g))
    # red line: v2 vs v1 pipeline, rtol/atol 1e-5
    np.testing.assert_allclose(o_g, o_1.numpy(), rtol=PAR_RTOL,
                               atol=PAR_ATOL, err_msg="o vs v1 (1e-5)")
    np.testing.assert_allclose(s_g, s_1.numpy(), rtol=PAR_RTOL,
                               atol=PAR_ATOL, err_msg="S vs v1 (1e-5)")
    o3, s3 = kda_v3_sim(q, k, v, xb, xd, s0)
    np.testing.assert_allclose(o_g, o3, rtol=rtol, atol=atol,
                               err_msg="o vs v3 sim")
    np.testing.assert_allclose(s_g, s3, rtol=rtol, atol=atol,
                               err_msg="S vs v3 sim")
    if check_l2:
        kn64, qn64, vv, beta64, loga64 = preprocess_np(q, k, v, xb, xd,
                                                       np.float64)
        o2, s2 = _kda_chunk_np(kn64, qn64, vv, beta64, loga64, s0)
        # red line: v2 vs the fp64 oracle, rtol/atol 1e-5 (regular decay)
        np.testing.assert_allclose(o_g, o2, rtol=PAR_RTOL, atol=PAR_ATOL,
                                   err_msg="o vs fp64 (1e-5)")
        np.testing.assert_allclose(s_g, s2, rtol=PAR_RTOL, atol=PAR_ATOL,
                                   err_msg="S vs fp64 (1e-5)")


@pytest.mark.parametrize("T", [1, 63, 64, 65, 100, 1024, 2048])
@pytest.mark.parametrize("B,H", [(1, 1), (4, 4)])
@pytest.mark.parametrize("with_s0", [False, True])
def test_kda2_e2e_64(T, B, H, with_s0):
    q, k, v, xb, xd, s0 = gen(B, H, T, 64, 64, seed=T + B * 10 + H,
                              with_s0=with_s0)
    _e2e(q, k, v, xb, xd, s0)


@pytest.mark.parametrize("T", [1, 64, 65, 1024, 2048])
@pytest.mark.parametrize("B,H", [(1, 1), (4, 4)])
@pytest.mark.parametrize("with_s0", [False, True])
def test_kda2_e2e_128(T, B, H, with_s0):
    q, k, v, xb, xd, s0 = gen(B, H, T, 128, 128, seed=T + B * 10 + H + 1,
                              with_s0=with_s0)
    _e2e(q, k, v, xb, xd, s0)


@pytest.mark.parametrize("B,H", [(1, 4), (4, 1), (8, 4)])
@pytest.mark.parametrize("T", [63, 1024, 4096])
@pytest.mark.parametrize("with_s0", [False, True])
def test_kda2_e2e_mixed_bh(T, B, H, with_s0):
    q, k, v, xb, xd, s0 = gen(B, H, T, 64, 64, seed=T + B + H * 7,
                              with_s0=with_s0)
    _e2e(q, k, v, xb, xd, s0)


@pytest.mark.parametrize("T", [2048, 2062, 4100])
def test_kda2_e2e_segmented(T):
    """Long-T shapes on the segmented-scan dispatch (BH <= 16), incl.
    ragged tails."""
    q, k, v, xb, xd, s0 = gen(1, 4, T, 64, 64, seed=T, with_s0=True)
    _e2e(q, k, v, xb, xd, s0)


@pytest.mark.parametrize("T", [300, 1024, 2048])
def test_kda2_e2e_v1tail(T):
    """BH >= 128 takes the throughput-regime tail (tiled mv3a + the v1
    two-dot scan and three-dot out) — same red-line oracles."""
    q, k, v, xb, xd, s0 = gen(4, 32, T, 64, 64, seed=T + 5, with_s0=True)
    _e2e(q, k, v, xb, xd, s0)


# ---------------------------------------------------------------------------
# numerical boundary cases (same regimes as test_kda.py)
# ---------------------------------------------------------------------------

def _edge_case(xb_val=None, xd_val=None, dead_channel=False,
               repeat_k=False, s0_scale=None, T=200, seed=11):
    q, k, v, xb, xd, s0 = gen(2, 2, T, 64, 64, seed=seed)
    if xb_val is not None:
        xb = np.full((2, 2, T), xb_val, dtype=np.float32)
    if xd_val is not None:
        xd = np.full((2, 2, T, 64), xd_val, dtype=np.float32)
    if dead_channel:
        xd = xd.copy()
        xd[:, :, :, 7] = -20.0
    if repeat_k:
        k = np.repeat(k[:, :, :1], T, axis=2)
    if s0_scale is not None:
        s0 = (s0_scale * np.ones((2, 2, 64, 64), dtype=np.float32))
    return q, k, v, xb, xd, s0


def test_edge_beta_hi():
    _e2e(*_edge_case(xb_val=4.6))


def test_edge_beta_lo():
    _e2e(*_edge_case(xb_val=-4.6))


def test_edge_loga_zero():
    _e2e(*_edge_case(xd_val=20.0))


def test_edge_dead_channel():
    """Clip-zone channel (excursion ~1280 in one channel): finiteness +
    tight agreement with the v3 sim (same shift/clip numerics); the v1
    parity check still holds (both pipelines clip identically)."""
    _e2e(*_edge_case(dead_channel=True), rtol=1e-3, atol=1e-4,
         check_l2=False)


def test_edge_repeat_k():
    _e2e(*_edge_case(repeat_k=True))


def test_edge_s0_large():
    _e2e(*_edge_case(s0_scale=100.0))


def test_edge_loga_neg20_clip_zone():
    _e2e(*_edge_case(xd_val=-20.0), rtol=5e-2, atol=5e-2, check_l2=False)


def test_edge_strong_decay_clip_zone():
    _e2e(*_edge_case(xd_val=-6.0), rtol=5e-2, atol=5e-2, check_l2=False)


def test_edge_t1_s0():
    q, k, v, xb, xd, s0 = gen(1, 1, 1, 64, 64, seed=3, with_s0=True)
    _e2e(q, k, v, xb, xd, s0)


def test_noncontiguous_inputs():
    """Non-contiguous views take the _contig normalization inside
    kda_forward_fused."""
    q, k, v, xb, xd, s0 = gen(2, 2, 130, 64, 64, seed=17, with_s0=True)
    qq = np.ascontiguousarray(np.moveaxis(q, 1, 2))       # (B,T,H,dk)
    kk = np.ascontiguousarray(np.moveaxis(k, 1, 2))
    vv = np.ascontiguousarray(np.moveaxis(v, 1, 2))
    args = [tl.tensor(x, device="cuda") for x in (qq, kk, vv, xb, xd)]
    args[0] = args[0].permute(0, 2, 1, 3)                 # non-contiguous
    args[1] = args[1].permute(0, 2, 1, 3)
    args[2] = args[2].permute(0, 2, 1, 3)
    assert not args[0].is_contiguous()
    s0t = tl.tensor(s0, device="cuda")
    o_g, s_g = tl_ops.kda_forward(*args, initial_state=s0t,
                                  output_final_state=True)
    tl.synchronize()
    kn64, qn64, vv64, beta64, loga64 = preprocess_np(q, k, v, xb, xd,
                                                     np.float64)
    o2, s2 = _kda_chunk_np(kn64, qn64, vv64, beta64, loga64, s0)
    np.testing.assert_allclose(o_g.numpy(), o2, rtol=PAR_RTOL,
                               atol=PAR_ATOL)
    np.testing.assert_allclose(s_g.numpy(), s2, rtol=PAR_RTOL,
                               atol=PAR_ATOL)
