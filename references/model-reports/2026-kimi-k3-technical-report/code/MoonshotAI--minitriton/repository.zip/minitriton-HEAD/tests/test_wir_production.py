"""General passes pay off on a production-shaped kernel.

The kernel: a naive fp32 matmul written the natural phase-structured
way — cooperative tile staging into smem, then a par_loop over
warp-column slices computing one product plane per K tile (global,
idempotent writes), and a thread-parallel epilogue summing the planes.
NO hand-placed synchronization anywhere: P2 derives the whole smem
handshake (staging writes -> compute reads -> next-tile writes) from
the annotations, P1 (warp distribution) maps the slice loops to one
column slice per warp (4x compute recovery on 4 warps). Redundant
all-warp execution (passes off) computes identical values, so
passes-on and passes-off are bit-equal (the W-IR legality contract).
"""

import os
import sys

from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.compiler.builder import Builder, SepOff, Affine

NTILES = 2


def build_naive_matmul(BM=64, BN=64, BK=32, nt=128):
    """The naive phase-structured fp32 matmul (see module docstring).
    Grid = (M/BM, N/BN); K = BK * NTILES (compile-time tiles)."""
    from mlir import ir
    from mlir.dialects import arith, memref, scf

    from minitriton.compiler.builder import _ensure_block
    from minitriton.compiler.wir import WIR

    warps = nt // 32
    wa_n = BN // warps
    with Builder("naive_matmul", nt) as b:
        args = b.begin([("a", ("ptr", tl.float32)),
                        ("bb", ("ptr", tl.float32)),
                        ("c", ("ptr", tl.float32)),
                        ("p", ("ptr", tl.float32)),
                        ("M", tl.int32), ("N", tl.int32), ("K", tl.int32)])
        a_arg, b_arg, c_arg, p_arg = (args["a"], args["bb"], args["c"],
                                      args["p"])
        M, N, K = args["M"], args["N"], args["K"]
        pid_m = b.program_id(0)
        pid_n = b.program_id(1)
        w = WIR(b)
        b.entry.owner.attributes["wir.nt"] = ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), nt)
        sA = w.shmem("nmat_a", BM * BK)
        sB = w.shmem("nmat_b", BK * BN)
        c = b.c_i32
        lane = w.mod(w.tid(), 32)

        def stage(t):
            # cooperative W-IR staging (always annotated, solve_tril
            # idiom): 16B vector loads from the global tiles into the
            # smem buffers — the naive form, whose handshake P2 must
            # recover (no cp.async, no waits, no hand barriers)
            from minitriton.compiler.builder import SmemBuf
            VL = 4
            vty = ir.VectorType.get([VL], b.f32)
            tid_w = w.tid()
            a_pt = type(a_arg)(a_arg.arg, SepOff(
                (BM, BK),
                Affine(arith.muli(pid_m.val, arith.muli(K.val, c(BM))),
                       K.val, BM),
                Affine(t * BK, 1, BK)))
            b_pt = type(b_arg)(b_arg.arg, SepOff(
                (BK, BN),
                Affine(t * BK * BN, N.val, BK),
                Affine(arith.muli(pid_n.val, c(BN)), 1, BN)))
            for j in range(BM * BK // VL // nt):
                idx = w.add(tid_w, j * nt)
                r = w.div(idx, BK // VL)
                f = w.mod(idx, BK // VL)
                g = arith.addi(
                    b.eval_affine(a_pt.off.row, r.val),
                    b.eval_affine(a_pt.off.col,
                                  arith.muli(f.val, c(VL))))
                v = memref.LoadOp(a_pt.arg.vec_view,
                                  [b.to_index(arith.divsi(g, c(VL)))])
                w.shstore_vec(sA, w.add(w.mul(r, BK), w.mul(f, VL)),
                              v.result)
            for j in range(BK * BN // VL // nt):
                idx = w.add(tid_w, j * nt)
                r = w.div(idx, BN // VL)
                f = w.mod(idx, BN // VL)
                g = arith.addi(
                    b.eval_affine(b_pt.off.row, r.val),
                    b.eval_affine(b_pt.off.col,
                                  arith.muli(f.val, c(VL))))
                v = memref.LoadOp(b_pt.arg.vec_view,
                                  [b.to_index(arith.divsi(g, c(VL)))])
                w.shstore_vec(sB, w.add(w.mul(r, BN), w.mul(f, VL)),
                              v.result)

        def pbase(t):
            # plane base (elements) of tile t's product for this program
            return arith.addi(
                arith.muli(c(t), arith.muli(M.val, N.val)),
                arith.addi(arith.muli(pid_m.val, arith.muli(c(BM), N.val)),
                           arith.muli(pid_n.val, c(BN))))

        for t in range(NTILES):
            stage(t)
            with w.par_loop(warps, "warp") as ww:
                for ml in range(BM // 32):
                    m = w.add(lane, ml * 32)
                    accs = [w.f32(0.0) for _ in range(wa_n)]
                    for kk in range(BK):
                        a_v = w.shload(sA, w.add(w.mul(m, BK), kk))
                        for n in range(wa_n):
                            b_v = w.shload(
                                sB, w.add(w.mul(kk, BN),
                                          w.add(w.mul(ww, wa_n), n)))
                            accs[n] = arith.addf(accs[n],
                                                 arith.mulf(a_v, b_v))
                    row_l = arith.addi(arith.remsi(b.tid(), c(32)),
                                       c(ml * 32))
                    for n in range(wa_n):
                        addr = arith.addi(
                            pbase(t),
                            arith.addi(arith.muli(row_l, N.val),
                                       arith.addi(arith.muli(ww.val,
                                                             c(wa_n)),
                                                  c(n))))
                        memref.StoreOp(accs[n], p_arg.arg.scalar_view,
                                       [b.to_index(addr)])
        # epilogue (thread-parallel): C = sum of the planes — one barrier
        # publishes the planes (written by every warp) to all threads
        b.barrier()
        for e in range(BM * BN // nt):
            idx = arith.addi(b.tid(), c(e * nt))
            mm = arith.divsi(idx, c(BN))
            nn = arith.remsi(idx, c(BN))
            acc = w.f32(0.0)
            for t in range(NTILES):
                v = memref.LoadOp(
                    p_arg.arg.scalar_view,
                    [b.to_index(arith.addi(pbase(t),
                                           arith.addi(
                                               arith.muli(mm, N.val),
                                               nn)))])
                acc = arith.addf(acc, v.result)
            c_pt = type(c_arg)(c_arg.arg, SepOff(
                (BM, BN),
                Affine(arith.muli(pid_m.val, arith.muli(c(BM), N.val)),
                       N.val, BM),
                Affine(arith.muli(pid_n.val, c(BN)), 1, BN)))
            memref.StoreOp(
                acc, c_pt.arg.scalar_view,
                [b.to_index(arith.addi(arith.muli(mm, N.val), nn))])
        return b.finish()


def _run(text, a_np, b_np, out_np, planes_np, M, N, K, nt=128):
    import ctypes

    from minitriton.compiler.lowering import compile_to_cubin
    from minitriton.runtime.cuda_driver import Device, memref1d_params
    dev = Device(0)
    cubin = compile_to_cubin(text, name="naive_matmul",
                             build_dir=Path(os.environ.get("TMPDIR",
                                                           "/tmp")))
    kernel = dev.load_module(cubin).function("naive_matmul")
    da = dev.alloc(a_np.nbytes)
    db = dev.alloc(b_np.nbytes)
    do = dev.alloc(out_np.nbytes)
    dp = dev.alloc(planes_np.nbytes)
    try:
        dev.memcpy_h2d(da, np.ascontiguousarray(a_np), a_np.nbytes)
        dev.memcpy_h2d(db, np.ascontiguousarray(b_np), b_np.nbytes)
        vl = 4
        params = (memref1d_params(da, a_np.size)
                  + memref1d_params(da, a_np.size // vl)
                  + memref1d_params(db, b_np.size)
                  + memref1d_params(db, b_np.size // vl)
                  + memref1d_params(do, out_np.size)
                  + memref1d_params(do, out_np.size // vl)
                  + memref1d_params(dp, planes_np.size)
                  + memref1d_params(dp, planes_np.size // vl)
                  + [ctypes.c_int32(M), ctypes.c_int32(N),
                     ctypes.c_int32(K)])
        kernel.launch((M // 64, N // 64, 1), (nt, 1, 1), params)
        dev.synchronize()
        dev.memcpy_d2h(out_np, do, out_np.nbytes)
    finally:
        dev.free(da)
        dev.free(db)
        dev.free(do)
        dev.free(dp)


# ---------------------------------------------------------------------------
# tests
# ---------------------------------------------------------------------------

def test_p1_distributes_and_bit_equal():
    """P1 maps the slice loops to one column slice per warp; outputs are
    bit-identical with P1 off and P2 on (the redundant all-warp compute
    is value-identical). Fully-off is racy BY DESIGN — W-IR programs
    get their synchronization from P2 (documented in wir.py)."""
    M, N, K = 64, 64, 64
    rng = np.random.default_rng(0)
    a_np = rng.standard_normal((M, K)).astype(np.float32)
    b_np = rng.standard_normal((K, N)).astype(np.float32)
    planes_np = np.zeros((NTILES, M, N), np.float32)
    text = build_naive_matmul()

    outs = []
    for env, var in (("1", None), (None, "0")):
        if env is not None:
            os.environ["MINITRITON_WIR_PASSES"] = env
        else:
            os.environ["MINITRITON_WIR_P1"] = var
        try:
            out_np = np.zeros((M, N), dtype=np.float32)
            _run(text, a_np, b_np, out_np, planes_np, M, N, K)
            outs.append(out_np.copy())
        finally:
            os.environ.pop("MINITRITON_WIR_PASSES", None)
            os.environ.pop("MINITRITON_WIR_P1", None)
    np.testing.assert_array_equal(outs[0], outs[1])
    np.testing.assert_allclose(outs[1], a_np.astype(np.float64)
                               @ b_np.astype(np.float64),
                               rtol=1e-5, atol=1e-5)


def test_p1_p2_stats_and_verifier():
    from minitriton.compiler import passes
    from minitriton.compiler.lowering import lower_device_module
    text = build_naive_matmul()
    n0 = len(passes.stats())
    lower_device_module(text)
    st = [s for s in passes.stats()[n0:] if s["func"] == "naive_matmul"]
    assert len(st) == 1
    st = st[0]
    assert st["p1_distributed"] == NTILES
    assert st["p1_bail_dep"] == 0 and st["p1_bail_opaque"] == 0
    # P2 recovers the whole handshake: stage -> compute (W->R) and
    # compute -> next stage (R->W), cross-warp both ways
    assert st["p2_top_warp"] >= NTILES
    assert st["verify_sync_checked"] >= 1
