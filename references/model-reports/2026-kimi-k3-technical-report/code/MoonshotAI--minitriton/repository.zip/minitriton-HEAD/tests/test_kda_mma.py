"""KDA tensor-core (mma) tier tests (tf32 / bf16).

Same three-level oracle discipline as tests/test_kda.py, reused through
its helpers (L1 naive fp64 / L2 chunk fp64 / L3 fp32 kernel-form sim):
- stage-wise mma-tier plane tests (K1 wy+L, K1b md/mv, K2 hc/vt/s1)
  against L3, at mma-appropriate tolerances
- e2e ops.kda_forward(precision=...) against L2 (fp64, rtol 5e-3 tf32 /
  2e-2 bf16) and against the fp32 GPU pipeline (mutual
  sanity, ~1e-3 both sides)

Host-side bf16 reference rounding via the test_mma.py helpers. No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import ops as tl_ops
from minitriton.device.cpu import _kda_chunk_np
from minitriton.device.cuda.kernels import kda as kda_k
from minitriton.device.cuda.kernels import kda_mma as kda_m

from test_kda import (_log_sigmoid_np, gen, kda_kernel_sim, kda_naive,
                      preprocess_np)

C = 64
RTOL_TF32, ATOL_TF32 = 5e-3, 5e-3
RTOL_BF16, ATOL_BF16 = 2e-2, 2e-2


# ---------------------------------------------------------------------------
# host-side helpers (mirror test_mma.py)
# ---------------------------------------------------------------------------

def f32_to_bf16_bits(x: np.ndarray) -> np.ndarray:
    """f32 -> bf16 bit pattern (round-to-nearest-even), as uint16."""
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    r = (b + np.uint32(0x7FFF) + ((b >> 16) & 1)) >> 16
    return r.astype(np.uint16).reshape(x.shape)


def bf16_bits_to_f32(u: np.ndarray) -> np.ndarray:
    return (np.ascontiguousarray(u, dtype=np.uint16).astype(np.uint32)
            << 16).view(np.float32).reshape(u.shape)


def _np(t):
    """eager Tensor -> numpy, via f32 for bf16 planes."""
    if t.dtype == tl.bfloat16:
        return t.astype(tl.float32).numpy().astype(np.float32)
    return t.numpy()


# ---------------------------------------------------------------------------
# stage drivers (mma tiers)
# ---------------------------------------------------------------------------

def _cuda_run_k1_mma(q, k, v, xb, xd, atom):
    """K0 eager preprocessing + mma-tier K1 (+K1s); returns
    (planes, preprocessed tensors)."""
    from minitriton.ops.kda import kda_preprocess
    ts = [tl.tensor(x, device="cuda") for x in (q, k, v, xb, xd)]
    kn, qn, beta, loga, g, gt, c, emc = kda_preprocess(*ts)
    B, H, T, dk = k.shape
    NC = (T + C - 1) // C
    planes = kda_m.alloc_mma_planes(B * H, NC, dk, atom)
    kda_m.launch_kda_wy_mma(kn, qn, beta, g, gt, c, emc, planes,
                            B * H, T, NC, dk, atom)
    kda_k.launch_kda_solve(planes, B * H, NC)
    tl.synchronize()
    return planes, (kn, qn, beta, loga, g, gt, c, emc)


@pytest.mark.parametrize("atom,rtol", [("tf32", 5e-3), ("bf16", 2e-2)])
@pytest.mark.parametrize("T", [1, 63, 64, 65, 100, 300])
@pytest.mark.parametrize("dk", [64, 128])
def test_k1_planes_mma(T, dk, atom, rtol):
    q, k, v, xb, xd, _ = gen(2, 2, T, dk, dk, seed=T + dk)
    planes, _ = _cuda_run_k1_mma(q, k, v, xb, xd, atom)
    ref = kda_kernel_sim(q, k, v, xb, xd, planes=True)
    for nm in ("delta", "qh", "wt"):
        got, want = _np(planes[nm]), ref[nm]
        np.testing.assert_allclose(got, want.reshape(got.shape),
                                   rtol=rtol, atol=1e-3,
                                   err_msg=f"K1[{atom}] plane {nm}")
    got, want = _np(planes["wc"]), ref["wc"]
    np.testing.assert_allclose(got, want.reshape(got.shape), rtol=rtol,
                               atol=1e-30,  # exp(+-80) range
                               err_msg=f"K1[{atom}] plane wc")
    got, want = planes["l"].numpy(), ref["l"]
    np.testing.assert_allclose(got, want.reshape(got.shape),
                               rtol=rtol, atol=rtol,
                               err_msg=f"K1[{atom}] plane l")


@pytest.mark.parametrize("atom,rtol", [("tf32", 5e-3), ("bf16", 2e-2)])
@pytest.mark.parametrize("T", [1, 63, 64, 65, 100, 300])
@pytest.mark.parametrize("with_s0", [False, True])
def test_k2_state_mma(T, with_s0, atom, rtol):
    q, k, v, xb, xd, s0 = gen(2, 2, T, 64, 64, seed=T * 7 + 64,
                              with_s0=with_s0)
    planes, (_, _, _, _, _, gt, _, emc) = _cuda_run_k1_mma(
        q, k, v, xb, xd, atom)
    B, H = q.shape[:2]
    NC = (T + C - 1) // C
    mv_planes = kda_k.alloc_mv_planes(B * H, NC, 64, 64)
    vo = kda_m.cast_bf16(tl.tensor(v, device="cuda")) \
        if atom == "bf16" else tl.tensor(v, device="cuda")
    m_op = kda_m.cast_bf16(planes["m"]) if atom == "bf16" else planes["m"]
    kda_m.launch_kda_mv_mma(m_op, planes, mv_planes, vo, B * H, T, NC,
                            64, 64, atom)
    dt = tl.bfloat16 if atom == "bf16" else tl.float32
    hc = tl.empty((B * H * NC, 64, 64), dt, "cuda")
    vt = tl.empty((B * H * NC, C, 64), dt, "cuda")
    s1 = tl.empty((B * H, 64, 64), tl.float32, "cuda")
    ts0 = tl.tensor(s0, device="cuda") if s0 is not None else None
    kda_m.launch_kda_state_mma(mv_planes, planes["wt"], gt, ts0, hc, vt,
                               s1, B * H, T, NC, 64, 64, atom)
    tl.synchronize()
    ref = kda_kernel_sim(q, k, v, xb, xd, s0, planes=True)
    np.testing.assert_allclose(mv_planes["md"].numpy(),
                               ref["md"].reshape(B * H * NC, C, 64),
                               rtol=rtol, atol=rtol, err_msg=f"K1b[{atom}] md")
    np.testing.assert_allclose(mv_planes["mv"].numpy(),
                               ref["mv"].reshape(B * H * NC, C, 64),
                               rtol=rtol, atol=rtol, err_msg=f"K1b[{atom}] mv")
    np.testing.assert_allclose(_np(hc), ref["hc"].reshape(hc.shape),
                               rtol=rtol, atol=rtol, err_msg=f"K2[{atom}] hc")
    np.testing.assert_allclose(_np(vt), ref["vt"].reshape(vt.shape),
                               rtol=rtol, atol=rtol, err_msg=f"K2[{atom}] vt")
    np.testing.assert_allclose(s1.numpy(), ref["s1"].reshape(s1.shape),
                               rtol=rtol, atol=rtol, err_msg=f"K2[{atom}] s1")


# ---------------------------------------------------------------------------
# e2e (ops.kda_forward precision=...; wired in step 2 of the task)
# ---------------------------------------------------------------------------

def _e2e_mma(q, k, v, xb, xd, s0, atom, rtol, atol, check_l2=True):
    args = [tl.tensor(x, device="cuda") for x in (q, k, v, xb, xd)]
    s0t = tl.tensor(s0, device="cuda") if s0 is not None else None
    o_g, s_g = tl_ops.kda_forward(*args, initial_state=s0t,
                                  output_final_state=True, precision=atom)
    tl.synchronize()
    o_g, s_g = o_g.numpy(), s_g.numpy()
    assert np.all(np.isfinite(o_g)) and np.all(np.isfinite(s_g))
    o3, s3 = kda_kernel_sim(q, k, v, xb, xd, s0)
    np.testing.assert_allclose(o_g, o3, rtol=rtol, atol=atol,
                               err_msg=f"o vs L3 [{atom}]")
    np.testing.assert_allclose(s_g, s3, rtol=rtol, atol=atol,
                               err_msg=f"S vs L3 [{atom}]")
    if check_l2:
        kn, qn, vv, beta, loga = preprocess_np(q, k, v, xb, xd, np.float64)
        o2, s2 = _kda_chunk_np(kn, qn, vv, beta, loga, s0)
        np.testing.assert_allclose(o_g, o2, rtol=rtol, atol=atol,
                                   err_msg=f"o vs L2 [{atom}]")
        np.testing.assert_allclose(s_g, s2, rtol=rtol, atol=atol,
                                   err_msg=f"S vs L2 [{atom}]")


@pytest.mark.parametrize("atom,rtol,atol",
                         [("tf32", RTOL_TF32, ATOL_TF32),
                          ("bf16", RTOL_BF16, ATOL_BF16)])
@pytest.mark.parametrize("T", [1, 63, 64, 65, 100, 1024])
@pytest.mark.parametrize("B,H", [(1, 1), (4, 4)])
@pytest.mark.parametrize("with_s0", [False, True])
def test_kda_e2e_mma(T, B, H, with_s0, atom, rtol, atol):
    q, k, v, xb, xd, s0 = gen(B, H, T, 64, 64, seed=T + B * 10 + H,
                              with_s0=with_s0)
    _e2e_mma(q, k, v, xb, xd, s0, atom, rtol, atol)


@pytest.mark.parametrize("atom,rtol,atol",
                         [("tf32", RTOL_TF32, ATOL_TF32),
                          ("bf16", RTOL_BF16, ATOL_BF16)])
@pytest.mark.parametrize("T", [1, 64, 65, 300])
@pytest.mark.parametrize("with_s0", [False, True])
def test_kda_e2e_mma_128(T, with_s0, atom, rtol, atol):
    q, k, v, xb, xd, s0 = gen(2, 2, T, 128, 128, seed=T + 21,
                              with_s0=with_s0)
    _e2e_mma(q, k, v, xb, xd, s0, atom, rtol, atol)


@pytest.mark.parametrize("atom,rtol,atol",
                         [("tf32", RTOL_TF32, ATOL_TF32),
                          ("bf16", RTOL_BF16, ATOL_BF16)])
@pytest.mark.parametrize("T", [63, 1024])
@pytest.mark.parametrize("B,H", [(1, 4), (4, 1)])
def test_kda_e2e_mma_mixed_bh(T, B, H, atom, rtol, atol):
    q, k, v, xb, xd, s0 = gen(B, H, T, 64, 64, seed=T + B + H * 7,
                              with_s0=True)
    _e2e_mma(q, k, v, xb, xd, s0, atom, rtol, atol)


# ---------------------------------------------------------------------------
# decay regimes (bf16 numerical-defence re-evaluation). Measured facts
# (seeds as below, o err vs the fp64 L2 oracle, scaled by max(|o|,1)):
#
#   case                                   fp32     tf32     bf16    (s bf16)
#   random loga in (-0.7,0)               7.9e-07  5.1e-04  4.0e-03   2.8e-03
#   random loga in (-6,0)  (~clip zone)   5.6e-01  5.9e-01  5.9e-01   1.8e-03
#   random loga in (-12,0) (clip zone)    5.8e-01  5.8e-01  5.8e-01   2.1e-03
#   const xd=-6 (excursion ~384, clip)    5.7e-01  5.7e-01  5.7e-01   1.4e-03
#
# i.e. inside the clip zone every implementation lands at the same ~0.6
# design ceiling ("should-be-dead" bounded
# residuals from catastrophic cancellation of clip-shifted write keys);
# the mma tiers add NO extra degradation vs fp32 there, and the final
# state S stays healthy in every tier (the tail-shifted state write keys
# never touch the clip). The w~ clip bound +-80 is far inside bf16's
# ~3e38 range, so the shift/clip defence itself ports unchanged.
# Assertions therefore are: finiteness; o vs L2 within 2x of the fp32
# pipeline's own ceiling; S vs L3 within the tier tolerance.
# ---------------------------------------------------------------------------

def _decay_case(atom, xd_fill=None, loga_lo=None):
    q, k, v, xb, xd, s0 = gen(1, 2, 200, 64, 64, seed=7, with_s0=True,
                              loga_lo=loga_lo or -0.7)
    if xd_fill is not None:
        xd = np.full_like(xd, xd_fill)
    args = [tl.tensor(x, device="cuda") for x in (q, k, v, xb, xd)]
    s0t = tl.tensor(s0, device="cuda")
    o_g, s_g = tl_ops.kda_forward(*args, initial_state=s0t,
                                  output_final_state=True, precision=atom)
    o_32, s_32 = tl_ops.kda_forward(*args, initial_state=s0t,
                                    output_final_state=True)
    tl.synchronize()
    o_g, s_g, o_32 = o_g.numpy(), s_g.numpy(), o_32.numpy()
    assert np.all(np.isfinite(o_g)) and np.all(np.isfinite(s_g))
    # fp64 oracle (undefined in the deep clip zone; call sites skip it)
    kn, qn, vv, beta, loga = preprocess_np(q, k, v, xb, xd, np.float64)
    o2, _ = _kda_chunk_np(kn, qn, vv, beta, loga, s0)
    scale = np.maximum(np.abs(o2), 1.0)
    err_m = float(np.max(np.abs(o_g - o2) / scale))
    err_32 = float(np.max(np.abs(o_32 - o2) / scale))
    return o_g, s_g, err_m, err_32, (q, k, v, xb, xd, s0)


@pytest.mark.parametrize("atom,rtol", [("tf32", RTOL_TF32),
                                       ("bf16", RTOL_BF16)])
@pytest.mark.parametrize("loga_lo", [-6.0, -12.0])
def test_kda_mma_decay_regimes(atom, rtol, loga_lo):
    """Heavy/extreme random decay (excursion deep into the clip zone):
    o within 2x of the fp32 pipeline's own vs-oracle ceiling; S vs L3
    within the tier tolerance."""
    o_g, s_g, err_m, err_32, case = _decay_case(atom, loga_lo=loga_lo)
    assert err_m <= max(2.0 * err_32, 5e-2), \
        f"o vs L2 [{atom}]: {err_m:.3e} vs fp32's {err_32:.3e}"
    q, k, v, xb, xd, s0 = case
    _, s3 = kda_kernel_sim(q, k, v, xb, xd, s0)
    np.testing.assert_allclose(s_g, s3, rtol=rtol, atol=rtol,
                               err_msg=f"S vs L3 [{atom}, {loga_lo}]")


@pytest.mark.parametrize("atom", ["tf32", "bf16"])
def test_kda_mma_clip_zone(atom):
    """log alpha = -6 const (excursion ~384 > 2*CL): clip active. Same
    assertion shape as the decay regimes (o ceiling + S vs L3)."""
    o_g, s_g, err_m, err_32, case = _decay_case(atom, xd_fill=-6.0)
    assert err_m <= max(2.0 * err_32, 5e-2), \
        f"o vs L2 [{atom}]: {err_m:.3e} vs fp32's {err_32:.3e}"
    q, k, v, xb, xd, s0 = case
    _, s3 = kda_kernel_sim(q, k, v, xb, xd, s0)
    np.testing.assert_allclose(s_g, s3, rtol=5e-2, atol=5e-2,
                               err_msg=f"S vs L3 clip zone [{atom}]")


def test_kda_mma_deep_clip_finite():
    """log alpha = -20 const (excursion ~1280, deep clip): the fp64
    oracle itself overflows materializing w~ (w~ = exp(20*64) = e^1280,
    past fp64's ~e^709 ceiling — an algorithm-level overflow, identical
    for every implementation) — assert finiteness + bounded magnitude
    only."""
    q, k, v, xb, xd, s0 = gen(1, 2, 200, 64, 64, seed=13, with_s0=False)
    xd = np.full_like(xd, -20.0)
    args = [tl.tensor(x, device="cuda") for x in (q, k, v, xb, xd)]
    for atom in ("tf32", "bf16"):
        o_g = tl_ops.kda_forward(*args, precision=atom)
        tl.synchronize()
        o_g = o_g.numpy()
        assert np.all(np.isfinite(o_g))
        assert np.max(np.abs(o_g)) < 1e4


# ---------------------------------------------------------------------------
# mutual check against the fp32 CUDA-core pipeline (both approximate the
# same fp64 math; the gap should sit inside 2x the tier tolerance)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("atom,rtol", [("tf32", 1e-3), ("bf16", 3e-2)])
@pytest.mark.parametrize("T", [64, 512])
def test_kda_mma_vs_fp32(atom, rtol, T):
    q, k, v, xb, xd, s0 = gen(2, 3, T, 64, 64, seed=T + 5, with_s0=True)
    args = [tl.tensor(x, device="cuda") for x in (q, k, v, xb, xd)]
    s0t = tl.tensor(s0, device="cuda")
    o_32, s_32 = tl_ops.kda_forward(*args, initial_state=s0t,
                                    output_final_state=True)
    o_m, s_m = tl_ops.kda_forward(*args, initial_state=s0t,
                                  output_final_state=True, precision=atom)
    tl.synchronize()
    np.testing.assert_allclose(o_m.numpy(), o_32.numpy(), rtol=rtol,
                               atol=rtol, err_msg=f"o mma vs fp32 [{atom}]")
    np.testing.assert_allclose(s_m.numpy(), s_32.numpy(), rtol=rtol,
                               atol=rtol, err_msg=f"S mma vs fp32 [{atom}]")


def test_kda_precision_routing():
    """Default / explicit-fp32 route to the fp32 pipeline (bit-identical);
    bad tier names and mma tiers on CPU are rejected."""
    q, k, v, xb, xd, s0 = gen(1, 1, 64, 64, 64, seed=3)
    args_c = [tl.tensor(x, device="cuda") for x in (q, k, v, xb, xd)]
    o_def = tl_ops.kda_forward(*args_c)
    o_32 = tl_ops.kda_forward(*args_c, precision="fp32")
    o_tf = tl_ops.kda_forward(*args_c, precision="tf32")
    tl.synchronize()
    assert np.array_equal(o_def.numpy(), o_32.numpy())
    assert not np.array_equal(o_def.numpy(), o_tf.numpy())
    with pytest.raises(RuntimeError):
        tl_ops.kda_forward(*args_c, precision="fp16")
    args_cpu = [tl.tensor(x, device="cpu") for x in (q, k, v, xb, xd)]
    with pytest.raises(RuntimeError):
        tl_ops.kda_forward(*args_cpu, precision="tf32")
