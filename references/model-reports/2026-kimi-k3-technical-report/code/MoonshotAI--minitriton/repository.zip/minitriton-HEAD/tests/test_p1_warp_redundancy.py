"""P1 warp distribution: intra-iteration warp-redundancy proof.

P1WarpDistribute rewrites ``par_loop(n, "warp")`` to one iteration per
warp. The guarded failure mode: a loop whose access offsets depend on
the full tid but whose per-iteration address ranges are mutually
disjoint passes a CROSS-iteration-only independence proof and then
silently loses the writes of the nt-32 threads no longer executing each
iteration. The pass therefore also requires every access offset to be
warp-invariant
(``eval_form(form, tid, t) == eval_form(form, tid % 32, t)``), and
``_body_clean`` rejects smem loads/stores without a wir.off annotation.
numpy oracle only, no torch.
"""

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

import minitriton as tl
from minitriton.compiler import passes
from minitriton.compiler.builder import Builder
from minitriton.compiler.lowering import compile_to_cubin, lower_device_module
from minitriton.compiler.wir import WIR

NT = 128
NELEM = 512


def _build(tid_dependent=True, nt=NT):
    """par_loop(4, "warp"): iteration t writes s[(tid or lane) + t*32x]."""
    from mlir import ir
    from mlir.dialects import memref

    with Builder("p1_redundancy", nt) as b:
        args = b.begin([("outp", ("ptr", tl.float32))])
        out_arg = args["outp"]
        b.entry.owner.attributes["wir.nt"] = ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), nt)
        w = WIR(b)
        s = w.shmem("p1r", NELEM)
        neg1 = w.f32(-1.0)
        one = w.f32(1.0)
        for e in range(NELEM // nt):
            w.shstore(s, w.add(w.tid(), e * nt), neg1)
        b.barrier()
        with w.par_loop(4, "warp") as ww:
            if tid_dependent:
                # offset depends on the full tid: NOT warp-redundant
                w.shstore(s, w.add(w.tid(), w.mul(ww, nt)), one)
            else:
                # offset depends on the lane only: warp-redundant control
                w.shstore(s, w.add(w.mod(w.tid(), 32),
                                   w.mul(ww, 32)), one)
        b.barrier()
        for e in range(NELEM // nt):
            idx = w.add(w.tid(), e * nt)
            v = w.shload(s, idx)
            memref.StoreOp(v, out_arg.arg.scalar_view,
                           [b.to_index(idx.val)])
        return b.finish()


def _run(text, nt=NT):
    import ctypes

    from minitriton.runtime.cuda_driver import Device, memref1d_params
    dev = Device(0)
    cubin = compile_to_cubin(text, name="p1_redundancy",
                             build_dir=Path(os.environ.get("TMPDIR",
                                                           "/tmp")))
    kernel = dev.load_module(cubin).function("p1_redundancy")
    out_np = np.zeros(NELEM, np.float32)
    do = dev.alloc(out_np.nbytes)
    try:
        vl = 4
        params = (memref1d_params(do, out_np.size)
                  + memref1d_params(do, out_np.size // vl))
        kernel.launch((1, 1, 1), (nt, 1, 1), params)
        dev.synchronize()
        dev.memcpy_d2h(out_np, do, out_np.nbytes)
    finally:
        dev.free(do)
    return out_np


def _run_with_passes(text, on):
    old = os.environ.get("MINITRITON_WIR_PASSES")
    os.environ["MINITRITON_WIR_PASSES"] = "1" if on else "0"
    try:
        return _run(text)
    finally:
        if old is None:
            os.environ.pop("MINITRITON_WIR_PASSES", None)
        else:
            os.environ["MINITRITON_WIR_PASSES"] = old


def test_p1_bails_on_non_warp_redundant_loop():
    # pre-fix this distributed and silently dropped 384/512 writes
    text = _build(tid_dependent=True)
    n0 = len(passes.stats())
    os.environ["MINITRITON_WIR_PASSES"] = "1"
    try:
        lower_device_module(text)
    finally:
        os.environ.pop("MINITRITON_WIR_PASSES", None)
    st = [s for s in passes.stats()[n0:] if s["func"] == "p1_redundancy"]
    assert len(st) == 1
    assert st[0]["p1_distributed"] == 0
    assert st[0]["p1_bail_warp"] == 1


def test_p1_bail_preserves_naive_semantics():
    # the bailed loop runs redundantly across warps: passes-on must be
    # bit-equal to passes-off, and both are all ones
    text = _build(tid_dependent=True)
    off = _run_with_passes(text, on=False)
    on = _run_with_passes(text, on=True)
    np.testing.assert_array_equal(on, off)
    np.testing.assert_array_equal(on, np.ones(NELEM, np.float32))


def test_p1_warp_redundant_control_still_distributes():
    # lane-based offsets stay distributable (the shipped payloads)
    text = _build(tid_dependent=False)
    n0 = len(passes.stats())
    os.environ["MINITRITON_WIR_PASSES"] = "1"
    try:
        lower_device_module(text)
    finally:
        os.environ.pop("MINITRITON_WIR_PASSES", None)
    st = [s for s in passes.stats()[n0:] if s["func"] == "p1_redundancy"]
    assert len(st) == 1
    assert st[0]["p1_distributed"] == 1
    assert st[0]["p1_bail_warp"] == 0


def test_p1_bails_on_unannotated_smem_access():
    # a raw (unannotated) smem store inside the par_loop escapes both
    # proofs: _body_clean must reject the loop outright
    from mlir import ir
    from mlir.dialects import memref

    with Builder("p1_unannotated", NT) as b:
        args = b.begin([("outp", ("ptr", tl.float32))])
        b.entry.owner.attributes["wir.nt"] = ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), NT)
        w = WIR(b)
        s = w.shmem("p1u", NELEM)
        with w.par_loop(4, "warp") as ww:
            idx = w.add(w.tid(), w.mul(ww, NT))
            memref.StoreOp(w.f32(1.0), s.memref,
                           [b.to_index(idx.val)])  # no wir.off
        text = b.finish()
    n0 = len(passes.stats())
    os.environ["MINITRITON_WIR_PASSES"] = "1"
    try:
        lower_device_module(text)
    finally:
        os.environ.pop("MINITRITON_WIR_PASSES", None)
    st = [s for s in passes.stats()[n0:] if s["func"] == "p1_unannotated"]
    assert len(st) == 1
    assert st[0]["p1_distributed"] == 0
