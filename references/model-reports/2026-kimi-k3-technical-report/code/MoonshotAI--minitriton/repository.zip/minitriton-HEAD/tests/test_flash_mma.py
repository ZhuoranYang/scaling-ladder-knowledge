"""flash-attention mma (tensor-core) forward tests: the tf32 and
bf16 tiers of Builder.flash_attention_fwd_mma against fp64 numpy references
and the existing fp32 FMA kernel, plus the eager/nn precision routing
(explicit precision=, the allow_tf32 flag, bf16 dtype routing). No torch.

Numerics discipline (mirrors test_mma.py):
- tf32: reference = numpy(f64) attention of the inputs rounded to 10-bit
  mantissa (round-half-away, mirroring cvt.rna.tf32.f32): rtol 1e-2.
- bf16: reference = numpy(f64) attention of the exact bf16 inputs (RNE
  rounded host-side): rtol 2e-2 (P is also bf16-rounded for the PV mma).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import nn, ops as tl_ops


# ---------------------------------------------------------------------------
# host-side dtype helpers (numpy has no tf32/bf16)
# ---------------------------------------------------------------------------

def tf32_round(x: np.ndarray) -> np.ndarray:
    """f32 -> f32 with a tf32 mantissa (10 bits), round-to-nearest-away —
    bit-identical to cvt.rna.tf32.f32 for finite x."""
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    r = (b + np.uint32(0x1000)) & np.uint32(0xFFFFE000)
    return r.view(np.float32).reshape(x.shape)


def f32_to_bf16_bits(x: np.ndarray) -> np.ndarray:
    """f32 -> bf16 bit pattern (round-to-nearest-even), as uint16."""
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    r = (b + np.uint32(0x7FFF) + ((b >> 16) & 1)) >> 16
    return r.astype(np.uint16).reshape(x.shape)


def bf16_bits_to_f32(u: np.ndarray) -> np.ndarray:
    return (np.ascontiguousarray(u, dtype=np.uint16).astype(np.uint32)
            << 16).view(np.float32).reshape(u.shape)


def bf16_round(x: np.ndarray) -> np.ndarray:
    return bf16_bits_to_f32(f32_to_bf16_bits(x))


def np_attention(q, k, v, scale):
    """fp64 causal reference; returns (out, lse) with lse = m + ln(l) of the
    scaled masked scores (the kernel's lse contract)."""
    T = q.shape[-2]
    s = np.einsum("bhtd,bhsd->bhts", q.astype(np.float64),
                  k.astype(np.float64)) * scale
    mask = np.triu(np.ones((T, T), dtype=bool), 1)
    s = np.where(mask, -np.inf, s)
    m = s.max(-1)
    e = np.exp(s - m[..., None])
    l = e.sum(-1)
    o = np.einsum("bhts,bhsd->bhtd", e / l[..., None], v.astype(np.float64))
    return o, m + np.log(l)


def rn(*shape, seed=0):
    return np.random.default_rng(seed).standard_normal(shape).astype(np.float32)


# ---------------------------------------------------------------------------
# tf32 tier
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("B,H,T", [(1, 2, 128), (2, 3, 256), (2, 3, 200),
                                   (1, 2, 512), (1, 2, 1000), (1, 2, 1024),
                                   (1, 2, 2048)])
def test_flash_mma_tf32(B, H, T):
    """tf32 flash fwd vs the fp64 tf32-rounded reference, the fp32 FMA
    kernel, and its lse (T=200/1000: ragged, predicated staging path)."""
    hd = 64
    q, k, v = rn(B, H, T, hd), rn(B, H, T, hd, seed=1), rn(B, H, T, hd, seed=2)
    scale = 1.0 / np.sqrt(hd)
    tq, tk, tv = (tl.tensor(x) for x in (q, k, v))
    out, lse = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                              with_lse=True, precision="tf32")
    assert out.dtype == tl.float32 and lse.dtype == tl.float32
    ref, lse_ref = np_attention(tf32_round(q), tf32_round(k), v, scale)
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-2, atol=1e-2)
    np.testing.assert_allclose(lse.numpy(), lse_ref, rtol=1e-2, atol=1e-2)
    # vs the existing fp32 FMA kernel (same semantics, exact-FMA compute)
    out32, lse32 = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                                  with_lse=True,
                                                  precision="fp32")
    np.testing.assert_allclose(out.numpy(), out32.numpy(), rtol=1e-2,
                               atol=1e-2)
    np.testing.assert_allclose(lse.numpy(), lse32.numpy(), rtol=1e-2,
                               atol=1e-2)


# ---------------------------------------------------------------------------
# bf16 tier
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("B,H,T", [(1, 2, 128), (2, 3, 256), (2, 3, 200),
                                   (1, 2, 512), (1, 2, 1000), (1, 2, 1024),
                                   (1, 2, 2048)])
def test_flash_mma_bf16(B, H, T):
    """bf16 flash fwd (bf16 in/out, f32 accumulate + f32 lse) vs the fp64
    reference of the exact bf16 inputs and the fp32 FMA kernel."""
    hd = 64
    q, k, v = (bf16_round(rn(B, H, T, hd, seed=s)) for s in (0, 1, 2))
    scale = 1.0 / np.sqrt(hd)
    tq, tk, tv = (tl.tensor(x).astype(tl.bfloat16) for x in (q, k, v))
    # dtype routing: no explicit precision needed for bf16 inputs
    out, lse = tl_ops.flash_attention_forward(tq, tk, tv, scale, with_lse=True)
    assert out.dtype == tl.bfloat16 and lse.dtype == tl.float32
    ref, lse_ref = np_attention(q, k, v, scale)
    o = out.astype(tl.float32).numpy()
    np.testing.assert_allclose(o, ref, rtol=2e-2, atol=2e-2)
    np.testing.assert_allclose(lse.numpy(), lse_ref, rtol=2e-2, atol=2e-2)
    # vs the fp32 FMA kernel on the same (rounded) inputs
    fq, fk, fv = (tl.tensor(x) for x in (q, k, v))
    out32 = tl_ops.flash_attention_forward(fq, fk, fv, scale,
                                           precision="fp32")
    np.testing.assert_allclose(o, out32.numpy(), rtol=2e-2, atol=2e-2)


# ---------------------------------------------------------------------------
# launcher edge cases: BM < BN (num_warps=2) and BM > BN (num_warps=8)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("warps", [2, 8])
@pytest.mark.parametrize("atom", ["tf32", "bf16"])
def test_flash_mma_warp_configs(warps, atom):
    """BM = 16 * warps rows/program: warps=2 exercises BM < BN (hi2 not a
    multiple of BN: prefetch clamp + wider diagonal-mask condition)."""
    import minitriton.device.cuda.kernels as K
    from minitriton.tensor import empty
    B, H, T, hd = 1, 2, 256, 64
    q, k, v = rn(B * H, T, hd), rn(B * H, T, hd, seed=1), rn(B * H, T, hd,
                                                            seed=2)
    scale = 1.0 / np.sqrt(hd)
    dt = tl.bfloat16 if atom == "bf16" else tl.float32
    tq, tk, tv = (tl.tensor(x).astype(dt) for x in (q, k, v))
    out = empty((B * H, T, hd), dt, "cuda")
    lse = empty((B * H, T), tl.float32, "cuda")
    K.launch_flash_attention_mma(tq, tk, tv, out, lse, scale, atom=atom,
                                 num_warps=warps)
    tl.synchronize()
    ref, lse_ref = np_attention(q.reshape(B, H, T, hd),
                                k.reshape(B, H, T, hd),
                                v.reshape(B, H, T, hd), scale)
    o = out.astype(tl.float32).numpy().reshape(B, H, T, hd)
    tol = 1e-2 if atom == "tf32" else 2e-2
    np.testing.assert_allclose(o, ref, rtol=tol, atol=tol)
    np.testing.assert_allclose(lse.numpy().reshape(B, H, T), lse_ref,
                               rtol=tol, atol=tol)


# ---------------------------------------------------------------------------
# eager / nn routing
# ---------------------------------------------------------------------------

def test_flash_mma_allow_tf32_flag():
    """set_allow_tf32(True) routes f32 flash attention to the tf32 mma
    kernel (torch allow_tf32 semantics); default off keeps the exact fp32
    kernel bit-for-bit."""
    from minitriton.device.cuda import ops as cuda_ops
    B, H, T, hd = 1, 2, 256, 64
    q, k, v = rn(B, H, T, hd), rn(B, H, T, hd, seed=1), rn(B, H, T, hd, seed=2)
    scale = 1.0 / np.sqrt(hd)
    tq, tk, tv = (tl.tensor(x) for x in (q, k, v))
    assert not cuda_ops.get_allow_tf32()
    out0 = tl_ops.flash_attention_forward(tq, tk, tv, scale).numpy()
    ref0 = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                          precision="fp32").numpy()
    assert np.array_equal(out0, ref0)
    try:
        cuda_ops.set_allow_tf32(True)
        out1 = tl_ops.flash_attention_forward(tq, tk, tv, scale).numpy()
        ref1 = tl_ops.flash_attention_forward(tq, tk, tv, scale,
                                              precision="tf32").numpy()
        assert np.array_equal(out1, ref1)
    finally:
        cuda_ops.set_allow_tf32(False)
    assert np.array_equal(tl_ops.flash_attention_forward(tq, tk, tv,
                                                         scale).numpy(),
                          out0)


def test_flash_mma_nn_precision_switch():
    """nn.CausalSelfAttention precision= opt-in: tf32 forward vs the fp64
    tf32-rounded reference; default (None) stays the fp32 kernel."""
    B, T, C, H = 2, 128, 128, 2
    x = rn(B, T, C)
    attn = nn.CausalSelfAttention(C, H, device="cuda", seed=0,
                                  precision="tf32")
    y = attn(tl.tensor(x)).numpy()
    attn32 = nn.CausalSelfAttention(C, H, device="cuda", seed=0)
    y32 = attn32(tl.tensor(x)).numpy()
    # same weights, different compute tier: tf32 tracks fp32 closely
    np.testing.assert_allclose(y, y32, rtol=1e-2, atol=1e-2)


def test_flash_mma_bf16_nn_backward():
    """bf16 fused forward + the mixed-precision backward contract (unfused
    composition in f32, grads cast back to bf16) vs an f32 reference."""
    B, H, T, hd = 1, 2, 128, 64
    q, k, v = (bf16_round(rn(B, H, T, hd, seed=s)) for s in (0, 1, 2))
    g = bf16_round(rn(B, H, T, hd, seed=3))
    scale = 1.0 / np.sqrt(hd)
    tq, tk, tv = (tl.tensor(x).astype(tl.bfloat16) for x in (q, k, v))
    for t in (tq, tk, tv):
        t.requires_grad = True
    out = nn.causal_attention(tq, tk, tv, scale=scale)
    assert out.dtype == tl.bfloat16
    out.backward(tl.tensor(g).astype(tl.bfloat16))
    # f32 reference through the unfused composition
    uq, uk, uv = (tl.tensor(x) for x in (q, k, v))
    for t in (uq, uk, uv):
        t.requires_grad = True
    out2 = nn.attention.unfused_causal_attention(uq, uk, uv, scale)
    out2.backward(tl.tensor(g))
    for name, a, b in (("dq", tq.grad, uq.grad), ("dk", tk.grad, uk.grad),
                       ("dv", tv.grad, uv.grad)):
        np.testing.assert_allclose(a.astype(tl.float32).numpy(), b.numpy(),
                                   rtol=2e-2, atol=2e-2, err_msg=name)
