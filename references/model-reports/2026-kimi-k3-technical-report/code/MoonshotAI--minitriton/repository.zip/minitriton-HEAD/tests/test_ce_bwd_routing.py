"""CE backward routing thresholds (2048 < C <= 8192, R*C >= 2**24 →
the fused online single-program kernel): bit-equality vs the replaced
partials+merge+apply chain inside the pocket, fp64 numpy oracles on
both sides of every boundary, and no behavior change outside it.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.device.cuda import kernels as K
from minitriton.device.cuda import ops as tl_be


def old_route(x, t, g, out, C):
    """The pre-change production path (partials + merge + apply)."""
    R = x.numel() // C
    seg, s = K._ce_split_plan(C)
    mp = tl.empty((R * s,), tl.float32)
    sp = tl.empty((R * s,), tl.float32)
    lse = tl.empty((R,), tl.float32)
    K.cross_entropy_partials_kernel[(R * s,)](
        x._buffer_arg(), t._buffer_arg(), mp._buffer_arg(),
        sp._buffer_arg(), out._buffer_arg(), C, s, seg,
        SINGLE=False, BLOCK=K._CE_BLOCK, num_warps=4)
    K.cross_entropy_merge_kernel[(R,)](
        mp._buffer_arg(), sp._buffer_arg(), x._buffer_arg(),
        t._buffer_arg(), lse._buffer_arg(), C, s,
        LSE=True, SBLOCK=K._ce_sblock(s), num_warps=4)
    sa = (C + K._CE_BLOCK - 1) // K._CE_BLOCK
    K.cross_entropy_backward_apply_kernel[(R * sa,)](
        x._buffer_arg(), t._buffer_arg(), g._buffer_arg(),
        lse._buffer_arg(), out._buffer_arg(), C, sa,
        BLOCK=K._CE_BLOCK, num_warps=4)


def np_ce_bwd(x, t, g):
    e = np.exp(x.astype(np.float64) - x.astype(np.float64).max(
        -1, keepdims=True))
    p = e / e.sum(-1, keepdims=True)
    p[np.arange(x.shape[0]), t] -= 1.0
    return p * g[:, None]


def case(R, C, seed=0):
    rng = np.random.default_rng(seed)
    x = rng.standard_normal((R, C)).astype(np.float32)
    t = rng.integers(0, C, R).astype(np.int32)
    g = rng.standard_normal(R).astype(np.float32)
    return x, t, g


POCKET = [(32, 2049), (1024, 2560), (64, 4095), (4096, 4096),
          (2048, 8192)]


@pytest.mark.parametrize("R,C", POCKET)
def test_ce_bwd_pocket_bit_equal(R, C):
    """Inside the fused pocket (2048 < C <= 8192, R*C >= 2**24): the
    production route is BIT-EQUAL to the replaced 3-kernel chain."""
    x, t, g = case(R, C)
    a = tl_be.cross_entropy_backward_rows(tl.tensor(x), tl.tensor(t),
                                          tl.tensor(g)).numpy()
    out = tl.empty((R, C), tl.float32)
    old_route(tl.tensor(x), tl.tensor(t), tl.tensor(g), out, C)
    b = out.numpy()
    assert np.array_equal(a.view(np.int32), b.view(np.int32)), \
        f"R{R} C{C}: fused online not bit-equal to the replaced chain"
    np.testing.assert_allclose(a, np_ce_bwd(x, t, g), rtol=1e-5,
                               atol=1e-6)


BOUNDARIES = [(6, 8), (32, 2048), (32, 2049), (4, 8192), (4, 8193),
              (2, 32000)]


@pytest.mark.parametrize("R,C", BOUNDARIES)
def test_ce_bwd_boundaries_oracle(R, C):
    """fp64 oracle across every routing boundary (row kernel / split at
    small R / fused online / split at wide C); C=8193 stays split."""
    x, t, g = case(R, C)
    a = tl_be.cross_entropy_backward_rows(tl.tensor(x), tl.tensor(t),
                                          tl.tensor(g)).numpy()
    np.testing.assert_allclose(a, np_ce_bwd(x, t, g), rtol=1e-5,
                               atol=1e-6)


def test_ce_bwd_small_r_keeps_chain_bit_identically():
    """R*C below the element threshold inside the C pocket keeps the
    chain route — production output equals it bit for bit (same code
    path, so this pins the routing boundary, not just the numerics)."""
    R, C = 1024, 4096  # R*C = 4M < 2**24
    x, t, g = case(R, C)
    a = tl_be.cross_entropy_backward_rows(tl.tensor(x), tl.tensor(t),
                                          tl.tensor(g)).numpy()
    out = tl.empty((R, C), tl.float32)
    old_route(tl.tensor(x), tl.tensor(t), tl.tensor(g), out, C)
    assert np.array_equal(a.view(np.int32), out.numpy().view(np.int32))
