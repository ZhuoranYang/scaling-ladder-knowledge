"""Explicit DSL scheduling constructs (TileLang
route): tl.smem / tl.async_copy / tl.load_smem / tl.store_smem /
tl.barrier — numpy-oracle tests. Also the config-validation family
(TileConfigError on misuse). No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.compiler.builder import TileConfigError
from minitriton.frontend.code_generator import DSLCompileError


def rn(*shape, seed):
    rng = np.random.default_rng(seed)
    return rng.standard_normal(shape).astype(np.float32)


@tl.kernel
def _copy_roundtrip_kernel(x_ptr, y_ptr, T,
                           R: tl.constexpr, C: tl.constexpr,
                           EVEN: tl.constexpr, MASKED: tl.constexpr):
    """global -> async_copy -> smem -> load_smem -> global roundtrip."""
    rows = tl.arange(0, R)
    cols = tl.arange(0, C)
    buf = tl.smem((R, C), tl.float32)
    if MASKED:
        tok = tl.async_copy(buf, x_ptr + rows[:, None] * C + cols[None, :],
                            MASK=(rows < T)[:, None])
    else:
        tok = tl.async_copy(buf, x_ptr + rows[:, None] * C + cols[None, :],
                            EVEN=EVEN)
    tl.async_wait(tok, 0)
    tl.barrier()
    v = tl.load_smem(buf)
    tl.store(y_ptr + rows[:, None] * C + cols[None, :], v)


def test_async_copy_roundtrip_even():
    R, C = 64, 64
    x = rn(R, C, seed=0)
    tx, ty = tl.tensor(x), tl.empty((R, C), tl.float32)
    _copy_roundtrip_kernel[(1,)](tx._buffer_arg(), ty._buffer_arg(), R,
                                 R=R, C=C, EVEN=True, MASKED=False,
                                 num_warps=4)
    np.testing.assert_array_equal(ty.numpy(), x)


def test_async_copy_masked_zfill():
    R, C, T = 64, 64, 37
    x = rn(R, C, seed=0)
    tx, ty = tl.tensor(x), tl.empty((R, C), tl.float32)
    _copy_roundtrip_kernel[(1,)](tx._buffer_arg(), ty._buffer_arg(), T,
                                 R=R, C=C, EVEN=False, MASKED=True,
                                 num_warps=4)
    ref = np.where((np.arange(R) < T)[:, None], x, 0.0)
    np.testing.assert_array_equal(ty.numpy(), ref)


@tl.kernel
def _smem_rw_kernel(x_ptr, y_ptr, R: tl.constexpr, C: tl.constexpr):
    """load -> store_smem -> barrier -> load_smem -> store roundtrip
    (value round-trips through the buffer in its own layout)."""
    rows = tl.arange(0, R)
    cols = tl.arange(0, C)
    buf = tl.smem((R, C), tl.float32)
    v = tl.load(x_ptr + rows[:, None] * C + cols[None, :])
    tl.store_smem(buf, v * 2.0)
    tl.barrier()
    w = tl.load_smem(buf)
    tl.store(y_ptr + rows[:, None] * C + cols[None, :], w + 1.0)


def test_smem_store_load():
    R, C = 64, 64
    x = rn(R, C, seed=1)
    tx, ty = tl.tensor(x), tl.empty((R, C), tl.float32)
    _smem_rw_kernel[(1,)](tx._buffer_arg(), ty._buffer_arg(), R=R, C=C,
                          num_warps=4)
    np.testing.assert_allclose(ty.numpy(), x * 2.0 + 1.0, rtol=1e-6)


@tl.kernel
def _dbl_buffer_kernel(x_ptr, y_ptr, N,
                       BLK: tl.constexpr, C: tl.constexpr):
    """Hand-written 2-stage pipeline on raw constructs: two user buffers
    alternate; the copy for block i+1 overlaps the compute of block i
    (rolling sum of (N/BLK) (BLK, C) tiles)."""
    pid = tl.program_id(0)
    rows = tl.arange(0, BLK)
    cols = tl.arange(0, C)
    base = pid * N * C
    buf0 = tl.smem((BLK, C), tl.float32)
    buf1 = tl.smem((BLK, C), tl.float32)
    acc = tl.zeros((BLK, C), tl.float32)
    nblk = N // BLK
    offs = base + rows[:, None] * C + cols[None, :]
    tok0 = tl.async_copy(buf0, x_ptr + offs, EVEN=True)
    tok1 = tl.async_copy(buf1, x_ptr + offs + BLK * C, EVEN=True)
    for i in range(0, nblk, 2):
        tl.async_wait(tok0, 0)
        tl.barrier()
        acc = acc + tl.load_smem(buf0) + tl.load_smem(buf1)
        tl.barrier()
        if i + 2 < nblk:
            tok0 = tl.async_copy(buf0, x_ptr + offs + (i + 2) * BLK * C,
                                 EVEN=True)
        if i + 3 < nblk:
            tok1 = tl.async_copy(buf1, x_ptr + offs + (i + 3) * BLK * C,
                                 EVEN=True)
    tl.store(y_ptr + pid * BLK * C + rows[:, None] * C + cols[None, :],
             acc)


def test_double_buffer_pipeline():
    """rolling sum over 8 blocks through two alternating smem buffers."""
    BLK, C, NB = 32, 64, 8
    N = BLK * NB
    x = rn(2, N, C, seed=2)  # two programs, each sums its own N rows
    tx, ty = tl.tensor(x), tl.empty((2, BLK, C), tl.float32)
    _dbl_buffer_kernel[(2,)](tx._buffer_arg(), ty._buffer_arg(), N,
                             BLK=BLK, C=C, num_warps=4)
    ref = x.reshape(2, NB, BLK, C).sum(axis=1)
    np.testing.assert_allclose(ty.numpy(), ref, rtol=1e-6, atol=1e-6)


# -- config validation (TileConfigError family, early and loud) ---------------

@tl.kernel
def _bad_shape_kernel(x_ptr, R: tl.constexpr, C: tl.constexpr):
    buf = tl.smem((R, C), tl.float32)
    cols = tl.arange(0, C)
    tok = tl.async_copy(buf, x_ptr + cols[None, :], EVEN=True)
    tl.async_wait(tok, 0)


def test_async_copy_shape_mismatch():
    x = tl.tensor(rn(64, seed=0))
    with pytest.raises(TileConfigError):
        _bad_shape_kernel[(1,)](x._buffer_arg(), R=32, C=64, num_warps=4)


@tl.kernel
def _overflow_kernel(x_ptr):
    buf0 = tl.smem((224, 224), tl.float32)   # 200KB > 48KB static
    cols = tl.arange(0, 224)
    tok = tl.async_copy(buf0, x_ptr + cols[None, :], EVEN=True)
    tl.async_wait(tok, 0)


def test_smem_budget_overflow():
    x = tl.tensor(rn(224, seed=0))
    with pytest.raises(TileConfigError):
        _overflow_kernel[(1,)](x._buffer_arg(), num_warps=4)


@tl.kernel
def _bad_mma_tok_kernel(x_ptr, R: tl.constexpr, C: tl.constexpr):
    rows = tl.arange(0, R)
    cols = tl.arange(0, C)
    buf = tl.smem((R, C), tl.bfloat16)
    tok = tl.async_copy(buf, x_ptr + rows[:, None] * C + cols[None, :],
                        EVEN=True)
    a_fr = tl.load(x_ptr + rows[:, None] * C + cols[None, :],
                   LAYOUT=tl.mma_layout("A", (R, C), "bf16"))
    acc = tl.mma(a_fr, tok, PENDING=0)  # raw copy token is not mma food


def test_mma_rejects_raw_copy_token():
    x = tl.tensor(rn(64, 64, seed=0)).astype(tl.bfloat16)
    with pytest.raises(TileConfigError):
        _bad_mma_tok_kernel[(1,)](x._buffer_arg(), R=64, C=64, num_warps=4)


# -- tl.pipelined: explicit loop-level pipeline annotation -------------

@tl.kernel
def _pipelined_mma_kernel(a_ptr, b_ptr, c_ptr, K,
                          BM: tl.constexpr, BK: tl.constexpr,
                          BN: tl.constexpr):
    """whole-K matmul on tl.pipelined(range, stages=2): the canonical
    single-buffer 2-stage rotation as explicit sugar — one tl.stage
    site, PENDING defaults mechanically to 0."""
    pid_m = tl.program_id(0)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_k = tl.arange(0, BK)
    offs_n = tl.arange(0, BN)
    lay_a = tl.mma_layout("A", (BM, BK), "bf16")
    b_pipe = tl.stage_pipe((BK, BN), tl.bfloat16, EVEN=True)
    acc = tl.zeros((BM, BN), tl.float32,
                   LAYOUT=tl.mma_layout("C", (BM, BN), "bf16"))
    for k0 in tl.pipelined(range(0, K, BK), stages=2):
        a_fr = tl.load(a_ptr + offs_m[:, None] * K + (k0 + offs_k)[None, :],
                       LAYOUT=lay_a)
        acc = tl.mma(a_fr, p_b, acc)
        p_b = tl.stage(b_pipe,
                       b_ptr + (k0 + offs_k)[:, None] * BN + offs_n[None, :])
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


def test_pipelined_mma_oracle():
    from test_dsl_mma import bf16_round
    BM, BK, BN, K = 64, 64, 64, 256
    a = bf16_round(rn(BM, K, seed=0))
    b = bf16_round(rn(K, BN, seed=1))
    ta, tb = (tl.tensor(x).astype(tl.bfloat16) for x in (a, b))
    tc = tl.empty((BM, BN), tl.float32)
    _pipelined_mma_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                                tc._buffer_arg(), K,
                                BM=BM, BK=BK, BN=BN, num_warps=4)
    ref = a.astype(np.float64) @ b.astype(np.float64)
    np.testing.assert_allclose(tc.numpy(), ref, rtol=1e-5, atol=1e-5)


def test_pipelined_matches_manual_bit_equal():
    """the tl.pipelined rotation is bit-equal to the hand-written
    prologue/restage/drain pipeline (test_dsl_mma's _mma_pipe_kernel)."""
    from test_dsl_mma import _mma_pipe_kernel, bf16_round
    BM, BK, BN, K = 64, 64, 64, 256
    a = bf16_round(rn(BM, K, seed=0))
    b = bf16_round(rn(K, BN, seed=1))
    ta, tb = (tl.tensor(x).astype(tl.bfloat16) for x in (a, b))
    kw = dict(BM=BM, BK=BK, BN=BN, num_warps=4)
    tc1 = tl.empty((BM, BN), tl.float32)
    _mma_pipe_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                           tc1._buffer_arg(), K, **kw)
    tc2 = tl.empty((BM, BN), tl.float32)
    _pipelined_mma_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                                tc2._buffer_arg(), K, **kw)
    np.testing.assert_array_equal(tc1.numpy().view(np.int32),
                                  tc2.numpy().view(np.int32))


@tl.kernel
def _pipelined_nostage_kernel(x_ptr, y_ptr, N, BLK: tl.constexpr):
    p0 = tl.stage_pipe((BLK, 64), tl.float32, EVEN=True)
    acc = tl.zeros((BLK, 64), tl.float32)
    for i in tl.pipelined(range(0, N, BLK), stages=2):
        acc = acc + 1.0
    tl.store(y_ptr + tl.arange(0, BLK)[:, None] * 64 +
             tl.arange(0, 64)[None, :], acc)


@tl.kernel
def _pipelined_nested_kernel(x_ptr, y_ptr, N, BLK: tl.constexpr):
    p0 = tl.stage_pipe((BLK, 64), tl.float32, EVEN=True)
    acc = tl.zeros((BLK, 64), tl.float32)
    for i in tl.pipelined(range(0, N, BLK), stages=2):
        if i > 0:
            p_b = tl.stage(p0, x_ptr + tl.arange(0, BLK)[:, None] * 64 +
                           tl.arange(0, 64)[None, :])
        acc = acc + 1.0
    tl.store(y_ptr + tl.arange(0, BLK)[:, None] * 64 +
             tl.arange(0, 64)[None, :], acc)


@tl.kernel
def _pipelined_rawstage_kernel(x_ptr, y_ptr, N, BLK: tl.constexpr):
    p0 = tl.stage_pipe((BLK, 64), tl.float32, EVEN=True)
    acc = tl.zeros((BLK, 64), tl.float32)
    for i in tl.pipelined(range(0, N, BLK), stages=2):
        acc = acc + 1.0
        p_b = tl.async_stage(p0, x_ptr + tl.arange(0, BLK)[:, None] * 64 +
                             tl.arange(0, 64)[None, :])
    tl.store(y_ptr + tl.arange(0, BLK)[:, None] * 64 +
             tl.arange(0, 64)[None, :], acc)


def test_pipelined_structural_errors():
    """misuse is rejected at trace time (DSLCompileError, early + loud):
    no stage sites / nested stage site / raw async_stage inside."""
    x = tl.tensor(rn(64, 64, seed=0))
    y = tl.empty((32, 64), tl.float32)
    for k in (_pipelined_nostage_kernel, _pipelined_nested_kernel,
              _pipelined_rawstage_kernel):
        with pytest.raises(DSLCompileError):
            k[(1,)](x._buffer_arg(), y._buffer_arg(), 128, BLK=32,
                    num_warps=4)


# -- minitriton/sched: the scheduling-helper library (@tl.inline) -------------

from minitriton.sched import gemm_2stage_bf16


@tl.kernel
def _sched_gemm_kernel(a_ptr, b_ptr, c_ptr, M, N, K,
                       BM: tl.constexpr, BN: tl.constexpr,
                       BK: tl.constexpr):
    """bf16 GEMM whose whole-K pipeline is the sched-library canonical
    2-stage skeleton (@tl.inline-expanded at trace time)."""
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    acc = tl.zeros((BM, BN), tl.float32,
                   LAYOUT=tl.mma_layout("C", (BM, BN), "bf16"))
    acc = gemm_2stage_bf16(a_ptr, b_ptr, K, K, N, offs_m, offs_n, acc,
                           BM, BK, BN)
    tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)


def test_sched_gemm_skeleton():
    from test_dsl_mma import bf16_round
    M, N, K = 128, 128, 256
    a = bf16_round(rn(M, K, seed=0))
    b = bf16_round(rn(K, N, seed=1))
    ta, tb = (tl.tensor(x).astype(tl.bfloat16) for x in (a, b))
    tc = tl.empty((M, N), tl.float32)
    _sched_gemm_kernel[(M // 64, N // 64)](
        ta._buffer_arg(), tb._buffer_arg(), tc._buffer_arg(), M, N, K,
        BM=64, BN=64, BK=64, num_warps=4)
    ref = a.astype(np.float64) @ b.astype(np.float64)
    np.testing.assert_allclose(tc.numpy(), ref, rtol=1e-5, atol=1e-5)


@tl.inline
def _scale_add(x, y, bias, scale=2.0):
    return (x + y) * scale + bias


@tl.inline
def _outer_helper(v, w):
    return _scale_add(v, w, bias=1.0, scale=0.5)  # nested inline + kwargs


@tl.kernel
def _inline_kernel(x_ptr, y_ptr, o_ptr, N, BLK: tl.constexpr):
    offs = tl.program_id(0) * BLK + tl.arange(0, BLK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m, other=0.0)
    y = tl.load(y_ptr + offs, mask=m, other=0.0)
    v = _scale_add(x, y, 3.0)               # default scale=2.0
    w = _outer_helper(x, y)                 # nested: (x+y)*0.5 + 1.0
    tl.store(o_ptr + offs, v + w, mask=m)


def test_inline_mechanics():
    N, BLK = 100, 128
    x, y = rn(N, seed=0), rn(N, seed=1)
    tx, ty, to = tl.tensor(x), tl.tensor(y), tl.empty((N,), tl.float32)
    _inline_kernel[(1,)](tx._buffer_arg(), ty._buffer_arg(),
                         to._buffer_arg(), N, BLK=BLK, num_warps=4)
    ref = (x + y) * 2.0 + 3.0 + (x + y) * 0.5 + 1.0
    np.testing.assert_allclose(to.numpy(), ref, rtol=1e-5)


@tl.inline
def _noreturn(x):
    y = x + 1.0


@tl.kernel
def _inline_bad_kernel(x_ptr, o_ptr, BLK: tl.constexpr):
    offs = tl.arange(0, BLK)
    v = _noreturn(tl.load(x_ptr + offs))
    tl.store(o_ptr + offs, v)


def test_inline_missing_return_rejected():
    x = tl.tensor(rn(64, seed=0))
    o = tl.empty((64,), tl.float32)
    with pytest.raises(DSLCompileError):
        _inline_bad_kernel[(1,)](x._buffer_arg(), o._buffer_arg(), BLK=64,
                                 num_warps=4)



def test_async_copy_masked_odd_cols_raise():
    # masked path: an odd column count used to drop the tail column
    # silently (upr = cols // 2 floored); it must now fail loudly
    from minitriton.compiler.builder import TileConfigError

    @tl.kernel
    def k(x_ptr, y_ptr):
        rows = tl.arange(0, 4)
        cols = tl.arange(0, 5)
        buf = tl.smem((4, 5), tl.float32)
        tok = tl.async_copy(buf, x_ptr + rows[:, None] * 5 + cols[None, :],
                            MASK=(rows < 3)[:, None])
        tl.async_wait(tok, 0)
        tl.barrier()
        v = tl.load_smem(buf)
        tl.store(y_ptr + rows[:, None] * 5 + cols[None, :], v)

    with pytest.raises(TileConfigError, match="odd column count"):
        x = tl.tensor(np.ones((4, 5), np.float32))
        y = tl.empty((4, 5), tl.float32)
        k[(1,)](x._buffer_arg(), y._buffer_arg(), num_warps=1)


def test_async_copy_masked_single_col_raise():
    # cols=1 floored the copy unit to zero: nothing staged at all
    from minitriton.compiler.builder import TileConfigError

    @tl.kernel
    def k(x_ptr, y_ptr):
        rows = tl.arange(0, 4)
        cols = tl.arange(0, 1)
        buf = tl.smem((4, 1), tl.float32)
        tok = tl.async_copy(buf, x_ptr + rows[:, None] + cols[None, :],
                            MASK=(rows < 3)[:, None])
        tl.async_wait(tok, 0)
        tl.barrier()
        v = tl.load_smem(buf)
        tl.store(y_ptr + rows[:, None] + cols[None, :], v)

    with pytest.raises(TileConfigError, match="odd column count"):
        x = tl.tensor(np.ones((4, 1), np.float32))
        y = tl.empty((4, 1), tl.float32)
        k[(1,)](x._buffer_arg(), y._buffer_arg(), num_warps=1)
