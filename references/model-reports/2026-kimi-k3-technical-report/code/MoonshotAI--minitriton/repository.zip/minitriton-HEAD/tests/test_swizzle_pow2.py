"""smem XOR-swizzle staging: non-power-of-two 16B-chunk rows are rejected.

The staging swizzle (chunk ^ (row & (chunks_per_row - 1))) only stays
inside its smem row when the 16B-chunks-per-row count is a power of two;
anything else makes two elements write one slot (last write wins), leaves
slots never written (uninitialized smem reads) and overruns the tile into
the adjacent buffer. The staging entries — tl.mma_tile, tl.mma /
tl.async_stage (_mma_stage_tile), tl.matmul_tile — must reject such tiles
loudly (TileConfigError), while power-of-two controls keep compiling and
matching the numpy oracle. No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.compiler.builder import TileConfigError

from test_flash_mma import bf16_round, rn
from test_kernels import run_matmul_tile
from test_mma import run_mma


# ---------------------------------------------------------------------------
# tl.mma_tile staging entries (plain A/B, transposed A/B, bf16/tf32)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("M,N,K,bm,bn,bk,warps,atom,kw", [
    # bf16 BN=24/48: crb = 3/6 chunks per staged B row
    (64, 24, 64, 64, 24, 16, 4, "bf16", {}),
    (64, 48, 64, 64, 48, 16, 4, "bf16", {}),
    # bf16 BK=48: cra = 6 per staged A row
    (64, 64, 96, 64, 64, 48, 4, "bf16", {}),
    # tf32 BK=24 / BN=24: cra/crb = 6 (f32 16B chunk = 4 elems)
    (64, 64, 48, 64, 64, 24, 4, "tf32", {}),
    (64, 24, 64, 64, 24, 16, 4, "tf32", {}),
    # transposed B: crbt = 6 per staged n row (bf16 and tf32)
    (64, 64, 96, 64, 64, 48, 4, "bf16", dict(trans_b=True, ldb=112)),
    (64, 64, 48, 64, 64, 24, 4, "tf32", dict(trans_b=True, ldb=72)),
    # bf16 transposed A: bm//v16 = 6 m-chunks per staged k row
    (48, 64, 64, 48, 64, 16, 4, "bf16", dict(trans_a=True, lda=48)),
])
def test_mma_tile_rejects_nonpow2_chunk_rows(M, N, K, bm, bn, bk, warps,
                                             atom, kw):
    with pytest.raises(TileConfigError, match="power-of-two"):
        run_mma(M, N, K, bm, bn, bk, warps, 2, atom=atom, **kw)


def test_mma_tile_bf16_bk24_rejected_earlier():
    # bf16 BK=24 never reaches the swizzle gate: BK % atom.k (16) != 0 is
    # rejected by the divisibility check — loud, not silent.
    with pytest.raises(TileConfigError):
        run_mma(64, 64, 48, 64, 64, 24, 4, 2, atom="bf16")


def test_mma_tile_pow2_controls():
    # plain bf16 tile, power-of-two chunk rows: unchanged numerics
    out, ref = run_mma(64, 64, 64, 64, 64, 32, 4, 2, atom="bf16")
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)
    # transposed B, crbt = 4 (pow2): compiles and matches
    out, ref = run_mma(64, 64, 64, 64, 64, 32, 4, 2, atom="bf16",
                       trans_b=True, ldb=72)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)
    # bf16 transposed A, bm//v16 = 8 (pow2): compiles and matches
    out, ref = run_mma(64, 64, 64, 64, 64, 16, 4, 2, atom="bf16",
                       trans_a=True, lda=72)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


def test_mma_tile_tf32_trans_a_not_over_rejected():
    # tf32 TRANS_A smem is UNSWIZZLED (k-major, multicast reads): BM=48
    # (6 chunks/row) is legal and must keep working — the gate only
    # applies where the swizzle actually runs.
    out, ref = run_mma(48, 64, 64, 48, 64, 16, 4, 2, atom="tf32",
                       trans_a=True, lda=48)
    np.testing.assert_allclose(out, ref, rtol=1e-2, atol=1e-2)


# ---------------------------------------------------------------------------
# tl.mma / tl.async_stage staging entry (_mma_stage_tile, even + 4B paths)
# ---------------------------------------------------------------------------

@tl.kernel
def _mma_sync_b_kernel(a_ptr, b_ptr, c_ptr, Kb,
                       BM: tl.constexpr, BK: tl.constexpr, BN: tl.constexpr,
                       MASKED: tl.constexpr):
    offs_m = tl.arange(0, BM)
    offs_k = tl.arange(0, BK)
    offs_n = tl.arange(0, BN)
    a_pt = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    b_pt = b_ptr + offs_k[:, None] * BN + offs_n[None, :]
    a_fr = tl.load(a_pt, LAYOUT=tl.mma_layout("A", (BM, BK), "bf16"))
    if MASKED:
        acc = tl.mma(a_fr, b_pt, TRANS_B=False,
                     MASK=(offs_k < Kb)[:, None])
    else:
        acc = tl.mma(a_fr, b_pt, TRANS_B=False, EVEN=True)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


@tl.kernel
def _mma_pipe_b_kernel(a_ptr, b_ptr, c_ptr,
                       BM: tl.constexpr, BK: tl.constexpr, BN: tl.constexpr):
    offs_m = tl.arange(0, BM)
    offs_k = tl.arange(0, BK)
    offs_n = tl.arange(0, BN)
    a_pt = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    b_pipe = tl.stage_pipe((BK, BN), tl.bfloat16, EVEN=True)
    a_fr = tl.load(a_pt, LAYOUT=tl.mma_layout("A", (BM, BK), "bf16"))
    p_b = tl.async_stage(
        b_pipe, b_ptr + offs_k[:, None] * BN + offs_n[None, :])
    acc = tl.mma(a_fr, p_b, PENDING=0)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


def _run_dsl_mma(BM, BK, BN, masked=False, pipelined=False, Kb=None):
    a = bf16_round(rn(BM, BK, seed=0))
    b = bf16_round(rn(BK, BN, seed=1))
    ta, tb = (tl.tensor(x).astype(tl.bfloat16) for x in (a, b))
    tc = tl.empty((BM, BN), tl.float32)
    if pipelined:
        _mma_pipe_b_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                                 tc._buffer_arg(),
                                 BM=BM, BK=BK, BN=BN, num_warps=1)
    else:
        _mma_sync_b_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                                 tc._buffer_arg(),
                                 BK if Kb is None else Kb,
                                 BM=BM, BK=BK, BN=BN, MASKED=masked,
                                 num_warps=1)
    if masked:
        b = b.copy()
        b[Kb:] = 0          # staged rows past Kb are zfilled
    return tc.numpy(), a.astype(np.float64) @ b.astype(np.float64)


def test_dsl_mma_rejects_nonpow2_chunk_rows():
    # BN=24: 3 bf16 16B chunks per staged row — sync EVEN (16B) path,
    # sync MASKED (4B) path and the stage_pipe/async_stage pipeline form
    with pytest.raises(TileConfigError, match="power-of-two"):
        _run_dsl_mma(32, 32, 24)
    with pytest.raises(TileConfigError, match="power-of-two"):
        _run_dsl_mma(32, 32, 24, masked=True, Kb=16)
    with pytest.raises(TileConfigError, match="power-of-two"):
        _run_dsl_mma(32, 32, 24, pipelined=True)


def test_dsl_mma_pow2_controls():
    out, ref = _run_dsl_mma(32, 32, 32)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-5)
    out, ref = _run_dsl_mma(32, 32, 32, masked=True, Kb=16)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-5)
    out, ref = _run_dsl_mma(32, 32, 32, pipelined=True)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-5)


# ---------------------------------------------------------------------------
# tl.matmul_tile (fp32 t2 path): the vec A staging swizzle needs BK/4 pow2
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("M,N,K,bm,bn,bk,tm,tn,warps", [
    (64, 64, 12, 64, 64, 12, 4, 16, 2),   # cra = 3
    (64, 64, 24, 64, 64, 24, 8, 4, 4),    # cra = 6
    (64, 64, 48, 64, 64, 48, 8, 4, 4),    # cra = 12
])
def test_matmul_tile_rejects_nonpow2_chunk_rows(M, N, K, bm, bn, bk, tm,
                                                tn, warps):
    with pytest.raises(TileConfigError, match="power-of-two"):
        run_matmul_tile(M, N, K, bm, bn, bk, tm, tn, warps, 2)


def test_matmul_tile_pow2_control():
    out, ref = run_matmul_tile(64, 64, 64, 64, 64, 32, 4, 4, 8, 2)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-4 * np.sqrt(64))


def test_matmul_tile_masked_bk12_not_over_rejected():
    # the masked (vec=False) path stages UNSWIZZLED: BK=12 is legal there
    # and must keep working (the gate fires on the vec path only)
    out, ref = run_matmul_tile(40, 40, 12, 32, 32, 12, 1, 32, 1, 2)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-4 * np.sqrt(12))


# ---------------------------------------------------------------------------
# transposed-B multiplicative swizzle (nn ^ kk*f): the bn >= 4*bk guard
# is not sufficient for bijectivity (bk=8/bn=48, bk=16/bn=96 collide /
# hole / overrun in the write formula). _btrans_swizzle_factor degrades
# to unswizzled staging for non-bijective shapes. All three
# staging/compute sites use it: the masked path, the compute side, and
# the vec fast-path prologue (a prologue formula mismatch makes TRANS_B
# vec configs like BK=16/BN=48 read a different smem layout than the
# staging wrote; the shapes below DO pass the staging-chunk divisibility
# gate and reach the kernel end-to-end).
# ---------------------------------------------------------------------------

from minitriton.compiler.builder import _btrans_swizzle_factor


def test_btrans_swizzle_factor_is_bijective_wherever_kept():
    def factor(bk, bn):
        return _btrans_swizzle_factor(bk, bn)

    for bk in (4, 8, 12, 16, 24, 32, 48, 64):
        for bn in (16, 24, 32, 40, 48, 64, 80, 96, 128, 192):
            f = factor(bk, bn)
            seen = set()
            for c in range(bk * bn):
                kk, nn = c % bk, c // bk
                dst = kk * bn + ((nn ^ (kk * f)) if f else nn)
                assert 0 <= dst < bk * bn, (bk, bn, f, dst)
                assert dst not in seen, (bk, bn, f, dst)
                seen.add(dst)


def test_btrans_swizzle_factor_degrades_known_bad_configs():
    # the bn >= 4*bk guard alone lets these through non-bijective
    assert _btrans_swizzle_factor(8, 48) == 0
    assert _btrans_swizzle_factor(16, 96) == 0
    assert _btrans_swizzle_factor(8, 80) == 0
    # bijective configs keep their swizzle
    assert _btrans_swizzle_factor(16, 64) == 4
    assert _btrans_swizzle_factor(32, 96) == 1
    assert _btrans_swizzle_factor(32, 32) == 1


@tl.kernel
def _matmul_tile_btrans_kernel(a_ptr, b_ptr, c_ptr, M, N, K,
                               BM: tl.constexpr, BN: tl.constexpr,
                               BK: tl.constexpr, TM: tl.constexpr,
                               TN: tl.constexpr, STAGES: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    # b stored as (N, K) row-major: element (k, n) at k + n*K
    b_ptrs = b_ptr + offs_k[:, None] + offs_n[None, :] * K
    acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                         TRANS_B=True)
    tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)


def test_matmul_tile_btrans_swizzled_control():
    # bijective config (bk=16/bn=64, factor 4 kept): the swizzled
    # staging + LDS.128 read path stays numerically correct
    M, N, K = 64, 64, 64
    rng = np.random.default_rng(0)
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)
    bt = np.ascontiguousarray(b.T)  # (N, K) row-major
    da, db = tl.Buffer.from_numpy(a), tl.Buffer.from_numpy(bt)
    dc = tl.Buffer(M * N, tl.float32)
    _matmul_tile_btrans_kernel[(1, 1)](
        da, db, dc, M, N, K, BM=64, BN=64, BK=16, TM=4, TN=4, STAGES=2,
        num_warps=8)
    tl.synchronize()
    np.testing.assert_allclose(dc.to_numpy().reshape(M, N), a @ b,
                               rtol=1e-4, atol=1e-4 * np.sqrt(K))


@pytest.mark.parametrize("M,N,K,bm,bn,bk,tm,tn,warps", [
    # non-bijective TRANS_B vec shapes that pass every divisibility gate:
    # the vec fast-path prologue must stage with the same validated
    # swizzle factor the compute side reads with
    (128, 48, 64, 128, 48, 16, 4, 12, 4),   # unvalidated f=2 vs validated 0
    (64, 96, 64, 64, 96, 16, 4, 12, 4),     # unvalidated f=4 vs validated 0
    (128, 48, 64, 128, 48, 8, 4, 12, 4),    # unvalidated f=4 vs validated 0
])
def test_matmul_tile_btrans_vec_nonbijective(M, N, K, bm, bn, bk, tm, tn,
                                             warps):
    rng = np.random.default_rng(0)
    a = rng.standard_normal((M, K)).astype(np.float32)
    b = rng.standard_normal((K, N)).astype(np.float32)
    bt = np.ascontiguousarray(b.T)  # (N, K) row-major
    da, db = tl.Buffer.from_numpy(a), tl.Buffer.from_numpy(bt)
    dc = tl.Buffer(M * N, tl.float32)
    _matmul_tile_btrans_kernel[(M // bm, N // bn)](
        da, db, dc, M, N, K, BM=bm, BN=bn, BK=bk, TM=tm, TN=tn, STAGES=2,
        num_warps=warps)
    tl.synchronize()
    np.testing.assert_allclose(dc.to_numpy().reshape(M, N), a @ b,
                               rtol=1e-4, atol=1e-4 * np.sqrt(K))


# ---------------------------------------------------------------------------
# stride-0 (k-broadcast) B operand: the staging source advance must be
# k0*ldb (= 0 for ldb == 0), not a special-case k0 — with K > BK a k0
# advance reads a window sliding along k
# ---------------------------------------------------------------------------

@tl.kernel
def _matmul_tile_bcast_b_kernel(a_ptr, b_ptr, c_ptr, M, N, K,
                                BM: tl.constexpr, BN: tl.constexpr,
                                BK: tl.constexpr, TM: tl.constexpr,
                                TN: tl.constexpr, STAGES: tl.constexpr,
                                VEC: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    # broadcast B: B[k, n] = v[n] — row (k) stride 0
    b_ptrs = b_ptr + offs_k[:, None] * 0 + offs_n[None, :]
    acc = tl.matmul_tile(a_ptrs, b_ptrs, K, TM, TN, STAGES=STAGES,
                         VEC=VEC)
    tl.store(c_ptr + offs_m[:, None] * N + offs_n[None, :], acc)


@pytest.mark.parametrize("vec", [True, False])
def test_matmul_tile_broadcast_b_multi_tile(vec):
    # K=64 > BK=16: four K tiles must each re-read the same v, not slide
    M, N, K = 64, 64, 64
    rng = np.random.default_rng(0)
    a = rng.standard_normal((M, K)).astype(np.float32)
    v = rng.standard_normal(N).astype(np.float32)
    da, db = tl.Buffer.from_numpy(a), tl.Buffer.from_numpy(v)
    dc = tl.Buffer(M * N, tl.float32)
    _matmul_tile_bcast_b_kernel[(1, 1)](
        da, db, dc, M, N, K, BM=64, BN=64, BK=16, TM=4, TN=4, STAGES=2,
        VEC=vec, num_warps=8)
    tl.synchronize()
    ref = a @ np.broadcast_to(v[None, :], (K, N))
    np.testing.assert_allclose(dc.to_numpy().reshape(M, N), ref,
                               rtol=1e-4, atol=1e-4 * np.sqrt(K))
