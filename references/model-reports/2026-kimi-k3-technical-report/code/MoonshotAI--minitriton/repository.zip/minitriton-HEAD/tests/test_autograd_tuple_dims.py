"""Autograd tuple/list-dim reductions: the raw path
supported dim=(0, 1) but the recorded Mean crashed in forward
(tuple % int) and every keepdim=False reduction crashed in backward
(unsqueeze(dim) with a tuple) — even for dim=(0,). numpy oracle, no torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl

DEVS = pytest.mark.parametrize("dev", ["cpu", "cuda"])

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


def T(x, dev, requires_grad=True):
    return tl.tensor(np.ascontiguousarray(x), device=dev,
                     requires_grad=requires_grad)


def close(out, ref, rtol=1e-5, atol=1e-6):
    arr = out.numpy() if isinstance(out, tl.Tensor) else out
    ref = ref.numpy() if isinstance(ref, tl.Tensor) else np.asarray(ref)
    assert arr.shape == ref.shape, f"shape {arr.shape} != ref {ref.shape}"
    np.testing.assert_allclose(arr, ref, rtol=rtol, atol=atol)


@DEVS
def test_mean_tuple_dim_backward(dev):
    a = rn(3, 4, 5)
    ta = T(a, dev)
    tl.mean(ta, dim=(0, 2)).sum().backward()
    close(ta.grad, np.ones_like(a) / (3 * 5), rtol=1e-5, atol=1e-6)


@DEVS
def test_mean_list_dim_backward(dev):
    a = rn(3, 4, 5)
    ta = T(a, dev)
    tl.mean(ta, dim=[0, 2]).sum().backward()
    close(ta.grad, np.ones_like(a) / (3 * 5), rtol=1e-5, atol=1e-6)


@DEVS
def test_mean_negative_tuple_dim_backward(dev):
    a = rn(3, 4, 5)
    ta = T(a, dev)
    tl.mean(ta, dim=(-3, -1)).sum().backward()
    close(ta.grad, np.ones_like(a) / (3 * 5), rtol=1e-5, atol=1e-6)


@DEVS
def test_sum_tuple_dim_no_keepdim_backward(dev):
    a = rn(3, 4, 5)
    ta = T(a, dev)
    tl.sum(ta, dim=(0, 1)).sum().backward()
    close(ta.grad, np.ones_like(a), rtol=1e-5, atol=1e-6)


@DEVS
def test_sum_single_tuple_dim_backward(dev):
    # dim=(0,) also crashed (unsqueeze with a 1-tuple)
    a = rn(3, 4, 5)
    ta = T(a, dev)
    tl.sum(ta, dim=(0,)).sum().backward()
    close(ta.grad, np.ones_like(a), rtol=1e-5, atol=1e-6)


@DEVS
def test_sum_tuple_dim_keepdim_backward(dev):
    # control: keepdim=True already worked
    a = rn(3, 4, 5)
    ta = T(a, dev)
    tl.sum(ta, dim=(0, 1), keepdim=True).sum().backward()
    close(ta.grad, np.ones_like(a), rtol=1e-5, atol=1e-6)


@DEVS
def test_max_tuple_dim_backward(dev):
    a = rn(3, 4, 5)
    ta = T(a, dev)
    tl.max(ta, dim=(0, 1)).sum().backward()
    # oracle: grad flows to the per-column extrema; ties share (v1 rule)
    m = a.max(axis=(0, 1))
    ref = np.zeros_like(a)
    for k in range(a.shape[2]):
        hit = a[:, :, k] == m[k]
        ref[:, :, k] = hit / hit.sum()
    close(ta.grad, ref, rtol=1e-5, atol=1e-6)


@DEVS
def test_min_tuple_dim_backward(dev):
    a = rn(3, 4, 5)
    ta = T(a, dev)
    tl.min(ta, dim=(0, 1)).sum().backward()
    m = a.min(axis=(0, 1))
    ref = np.zeros_like(a)
    for k in range(a.shape[2]):
        hit = a[:, :, k] == m[k]
        ref[:, :, k] = hit / hit.sum()
    close(ta.grad, ref, rtol=1e-5, atol=1e-6)


@DEVS
def test_mean_tuple_dim_upstream_grad(dev):
    # non-trivial upstream grad: broadcast back to the reduced axes —
    # mean over (0, 2) of (3, 4, 5) leaves shape (4,)
    a = rn(3, 4, 5)
    g = rn(4)
    ta = T(a, dev)
    tl.mean(ta, dim=(0, 2)).backward(T(g, dev, False))
    ref = np.broadcast_to(g[None, :, None] / (3 * 5), a.shape)
    close(ta.grad, ref, rtol=1e-5, atol=1e-6)
