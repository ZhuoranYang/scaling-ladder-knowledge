"""Frontend whitelist tests: unsupported syntax must fail early and loud
(with line numbers); constexpr and scalar control flow must work."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.frontend.code_generator import DSLCompileError


_BUF = None


def _buf():
    global _BUF
    if _BUF is None:
        _BUF = tl.Buffer(256, tl.float32)
    return _BUF


def expect_error(fn, needle: str, *args, **kwargs):
    args = [_buf() if a is None else a for a in args]
    with pytest.raises(DSLCompileError) as ei:
        fn[(1,)](*args, **kwargs)
    msg = str(ei.value)
    assert needle in msg, f"expected {needle!r} in error message:\n{msg}"
    assert "line" in msg  # errors always carry kernel line info


def test_while_rejected():
    @tl.kernel
    def k(x_ptr, N, BLOCK: tl.constexpr):
        i = 0
        while i < N:
            i = i + BLOCK
    expect_error(k, "while-loops are not supported", None, 8, BLOCK=4)


def _helper_fn(n):  # module-scope so kernels can see it in __globals__
    return n


def test_non_tl_call_rejected():
    @tl.kernel
    def k(x_ptr, N, BLOCK: tl.constexpr):
        y = _helper_fn(N)
    expect_error(k, "only tl.* calls are supported", None, 8, BLOCK=4)


_TABLE = np.zeros(4, dtype=np.float32)  # non-scalar global capture


def test_closure_capture_rejected():
    @tl.kernel
    def k(x_ptr, N, BLOCK: tl.constexpr):
        s = _TABLE
    expect_error(k, "cannot capture global", None, 8, BLOCK=4)


def test_return_value_rejected():
    @tl.kernel
    def k(x_ptr, N, BLOCK: tl.constexpr):
        return N
    expect_error(k, "cannot return values", None, 8, BLOCK=4)


def test_chained_compare_rejected():
    @tl.kernel
    def k(x_ptr, N, BLOCK: tl.constexpr):
        if 0 < N < 100:
            pass
    expect_error(k, "chained comparisons", None, 8, BLOCK=4)


def test_unknown_tl_builtin_rejected():
    @tl.kernel
    def k(x_ptr, N, BLOCK: tl.constexpr):
        y = tl.nonexistent(N)
    expect_error(k, "unknown tl.* builtin", None, 8, BLOCK=4)


def test_subscript_assign_rejected():
    @tl.kernel
    def k(x_ptr, N, BLOCK: tl.constexpr):
        offs = tl.arange(0, BLOCK)
        offs[0] = 1
    expect_error(k, "single-name assignments", None, 8, BLOCK=4)


def test_if_on_block_rejected():
    @tl.kernel
    def k(x_ptr, N, BLOCK: tl.constexpr):
        offs = tl.arange(0, BLOCK)
        m = offs < N
        if m:
            pass
    expect_error(k, "if condition must be a scalar i1", None, 8, BLOCK=4)


# -- positive cases ----------------------------------------------------------

CAP = tl.constexpr(4)


@tl.kernel
def scalar_if_for_kernel(x_ptr, out_ptr, N, BLOCK: tl.constexpr):
    # constexpr global capture + scalar if + runtime-bound for loop
    total = 0.0
    for i in range(0, N):
        total += 1.0
    if N > 3:
        total += 1.0
    else:
        total += 2.0
    acc = tl.zeros((CAP.value * 32,), tl.float32)
    offs = tl.arange(0, CAP.value * 32)
    acc += 1.0
    tl.store(out_ptr + tl.arange(0, 128), acc + total)
    tl.store(x_ptr + 0, total)


def test_scalar_control_flow():
    n = 10
    dx = tl.Buffer(128, tl.float32)
    dout = tl.Buffer(128, tl.float32)
    scalar_if_for_kernel[(1,)](dx, dout, n, BLOCK=128)
    tl.synchronize()
    x = dx.to_numpy()
    out = dout.to_numpy()
    assert x[0] == pytest.approx(n + 1.0)
    np.testing.assert_allclose(out, np.full(128, 1.0 + n + 1.0,
                                            dtype=np.float32))


@tl.kernel
def i32_arith_kernel(out_ptr, a, b):
    c = a // b
    d = a % b
    e = a * b - c
    tl.store(out_ptr + 0, c)
    tl.store(out_ptr + 1, d)
    tl.store(out_ptr + 2, e)
    f = a / b  # python float division semantics
    tl.store(out_ptr + 3, f)


def test_i32_scalar_arith():
    dout = tl.Buffer(4, tl.float32)
    i32_arith_kernel[(1,)](dout, 17, 5)
    tl.synchronize()
    out = dout.to_numpy()
    assert out[0] == 3 and out[1] == 2 and out[2] == 82
    assert out[3] == pytest.approx(3.4)


@tl.kernel
def scalar_offset_cmp_kernel(x_ptr, out_ptr, out2_ptr, N,
                             BLOCK: tl.constexpr):
    offs = tl.arange(0, BLOCK)
    m_left = N > offs                 # scalar on the left flips to offs < N
    m_right = offs > N
    v = tl.load(x_ptr + offs, mask=m_left, other=0.0)
    tl.store(out_ptr + offs, v)
    v2 = tl.load(x_ptr + offs, mask=m_right, other=0.0)
    tl.store(out2_ptr + offs, v2)


def test_scalar_left_offset_compare():
    n = 100
    src_np = np.arange(128, dtype=np.float32)
    src = tl.Buffer.from_numpy(src_np)
    d1, d2 = tl.Buffer(128, tl.float32), tl.Buffer(128, tl.float32)
    scalar_offset_cmp_kernel[(1,)](src, d1, d2, n, BLOCK=128)
    tl.synchronize()
    np.testing.assert_array_equal(d1.to_numpy(),
                                  np.where(n > np.arange(128), src_np, 0.0))
    np.testing.assert_array_equal(d2.to_numpy(),
                                  np.where(np.arange(128) > n, src_np, 0.0))


def test_offset_vs_offset_compare_rejected():
    from minitriton.compiler.builder import TileConfigError

    @tl.kernel
    def k(x_ptr, BLOCK: tl.constexpr):
        offs = tl.arange(0, BLOCK)
        m = offs > (BLOCK - offs)     # comparing two offset tensors
    with pytest.raises(TileConfigError, match="two offset tensors"):
        k[(1,)](_buf(), BLOCK=8)
