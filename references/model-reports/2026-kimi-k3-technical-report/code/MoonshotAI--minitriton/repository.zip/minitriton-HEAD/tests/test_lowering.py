"""Compile-pipeline tests: MLIR text -> cubin via the full toolchain."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from minitriton.compiler.lowering import (
    DEFAULT_CHIP,
    compile_to_cubin,
    lower_device_module,
)

MINI_KERNEL = """
module {
  gpu.module @mini_module {
    gpu.func @mini(%x: memref<?xf32>, %n: i32) kernel {
      %bid = gpu.block_id x
      %bdim = gpu.block_dim x
      %tid = gpu.thread_id x
      %tmp = arith.muli %bid, %bdim : index
      %i = arith.addi %tmp, %tid : index
      %n_idx = arith.index_cast %n : i32 to index
      %inb = arith.cmpi ult, %i, %n_idx : index
      scf.if %inb {
        %a = memref.load %x[%i] : memref<?xf32>
        %b = arith.mulf %a, %a : f32
        memref.store %b, %x[%i] : memref<?xf32>
      }
      gpu.return
    }
  }
}
"""


def test_lower_device_module_is_llvm_dialect():
    text = lower_device_module(MINI_KERNEL)
    assert "gpu.module" not in text
    assert "gpu.func" not in text
    assert "llvm.func @mini" in text
    assert "nvvm.read.ptx.sreg" in text


def test_compile_to_cubin(tmp_path):
    cubin = compile_to_cubin(MINI_KERNEL, name="mini", build_dir=tmp_path)
    assert len(cubin) > 0
    assert cubin[:4] == b"\x7fELF"  # cubin is an ELF binary
    # intermediates go to a temp dir and are discarded by default
    assert list(tmp_path.iterdir()) == []


def test_compile_to_cubin_keep_intermediates(tmp_path, monkeypatch):
    monkeypatch.setenv("MINITRITON_KEEP_INTERMEDIATES", "1")
    cubin = compile_to_cubin(MINI_KERNEL, name="mini", build_dir=tmp_path)
    assert cubin[:4] == b"\x7fELF"
    # intermediates kept for debugging
    for ext in (".device.mlir", ".ll", ".ptx", ".cubin"):
        assert (tmp_path / f"mini{ext}").is_file()
    ptx = (tmp_path / "mini.ptx").read_text()
    assert f".target {DEFAULT_CHIP}" in ptx
    assert ".entry mini" in ptx
