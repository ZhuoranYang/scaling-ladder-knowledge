#!/usr/bin/env python
"""Eager tensor semantics: comparison dunders, tuple-dim reductions,
in-place arithmetic on views.

Oracles are numpy; no torch import (repo test-gate rule).
"""
import numpy as np
import pytest

import minitriton as tl


def _t(a, dtype=None):
    t = tl.tensor(np.asarray(a))
    return t.astype(dtype) if dtype is not None else t


A = np.array([[1.0, -2.0, 3.0], [4.0, 0.0, -1.5]], np.float32)
B = np.array([[1.0, 2.0, -3.0], [4.5, 0.0, -1.5]], np.float32)


# -- comparison dunders ------------------------------------------------------

def test_comparison_tensor_tensor():
    a, b = _t(A), _t(B)
    for op, ref in (("eq", A == B), ("ne", A != B), ("lt", A < B),
                    ("le", A <= B), ("gt", A > B), ("ge", A >= B)):
        out = {"eq": a == b, "ne": a != b, "lt": a < b,
               "le": a <= b, "gt": a > b, "ge": a >= b}[op]
        assert out.dtype == tl.float32, op  # f32 mask, no bool dtype
        np.testing.assert_array_equal(out.numpy(), ref.astype(np.float32),
                                      err_msg=op)


def test_comparison_scalar_and_broadcast():
    a = _t(A)
    np.testing.assert_array_equal((a >= 0.0).numpy(),
                                  (A >= 0.0).astype(np.float32))
    np.testing.assert_array_equal((a < 1.0).numpy(),
                                  (A < 1.0).astype(np.float32))
    row = _t(A[0])
    np.testing.assert_array_equal((a == row).numpy(),
                                  (A == A[0]).astype(np.float32))


def test_comparison_int_exact():
    xi = np.array([[1, 2, 3], [-4, 3, 0]], np.int32)
    t = _t(xi, tl.int32)
    np.testing.assert_array_equal((t == 3).numpy(),
                                  (xi == 3).astype(np.float32))
    np.testing.assert_array_equal((t != 3).numpy(),
                                  (xi != 3).astype(np.float32))
    xl = np.array([[2**40, 5]], np.int64)
    tl64 = _t(xl, tl.int64)
    np.testing.assert_array_equal((tl64 == tl64).numpy(),
                                  np.ones((1, 2), np.float32))


def test_tensor_still_hashable():
    # __eq__ is defined on Tensor; __hash__ must stay identity-based
    a, b = _t(A), _t(A)
    d = {a: 1}
    d[b] = 2
    assert d[a] == 1 and len(d) == 2
    assert len({a, a, b}) == 2


# -- tuple-dim reductions ------------------------------------------------------

X = np.random.default_rng(0).standard_normal((2, 3, 4, 5)).astype(np.float32)


def test_sum_tuple_dim():
    x = _t(X)
    np.testing.assert_allclose(x.sum(dim=(0, 2)).numpy(),
                               X.sum(axis=(0, 2)), rtol=1e-5)
    out = x.sum(dim=(0, 2), keepdim=True)
    assert out.shape == (1, 3, 1, 5)
    np.testing.assert_allclose(out.numpy(), X.sum(axis=(0, 2),
                                                  keepdims=True), rtol=1e-5)


def test_mean_tuple_dim():
    np.testing.assert_allclose(_t(X).mean(dim=(1, 3)).numpy(),
                               X.mean(axis=(1, 3)), rtol=1e-5)


def test_max_min_tuple_dim():
    np.testing.assert_allclose(_t(X).max(dim=(0, 3)).numpy(),
                               X.max(axis=(0, 3)), rtol=1e-6)
    np.testing.assert_allclose(_t(X).min(dim=(2,)).numpy(),
                               X.min(axis=2), rtol=1e-6)


def test_sum_empty_dim_tuple_is_identity():
    x = _t(X)
    np.testing.assert_array_equal(x.sum(dim=()).numpy(), X)


# -- in-place arithmetic ---------------------------------------------------------

def test_iadd_writes_through_view():
    base = _t(A.copy())
    v = base[0:1, 1:]
    v += 10.0
    ref = A.copy()
    ref[0:1, 1:] += 10.0
    np.testing.assert_array_equal(base.numpy(), ref)


def test_iadd_plain_and_aliased():
    t = _t(A.copy())
    alias = t
    t += _t(B)
    assert alias is t
    np.testing.assert_allclose(t.numpy(), A + B, rtol=1e-6)


def test_isub_imul_idiv():
    t = _t(A.copy())
    t -= 1.0
    np.testing.assert_allclose(t.numpy(), A - 1.0, rtol=1e-6)
    t *= 2.0
    np.testing.assert_allclose(t.numpy(), (A - 1.0) * 2.0, rtol=1e-6)
    t /= 4.0
    np.testing.assert_allclose(t.numpy(), (A - 1.0) * 2.0 / 4.0,
                               rtol=1e-6)


def test_iadd_dtype_casts_like_torch():
    t = _t(A.copy(), tl.bfloat16)
    t += 0.5  # result computed then stored in bf16, like torch
    np.testing.assert_allclose(t.astype(tl.float32).numpy(),
                               (A + 0.5).astype(np.float32), atol=0.02)


def test_iadd_broadcast_growth_raises():
    t = _t(np.ones((2, 1), np.float32))
    with pytest.raises(RuntimeError):
        t += _t(np.ones((3,), np.float32))  # torch: shape must not grow


def test_iadd_requires_grad_raises():
    t = tl.tensor(A.copy(), requires_grad=True)
    with pytest.raises(RuntimeError, match="in-place"):
        t += 1.0


# -- Tensor(Tensor) detaches autograd state -------------------------------------

def test_tensor_from_tensor_detaches_graph():
    from minitriton.tensor import Tensor
    a = tl.tensor(np.array([1.0, 2.0, 3.0], np.float32), requires_grad=True)
    b = a * 2
    c = Tensor(b, requires_grad=True)
    assert c.grad_fn is None and c.grad is None  # new leaf, not b's node
    (c * 3).sum().backward()
    # grad lands on c; the source graph is untouched (guards against
    # a.grad getting wrongly materialized as zeros and c.grad dropped)
    np.testing.assert_array_equal(c.grad.numpy(), [3.0, 3.0, 3.0])
    assert a.grad is None and b.grad is None


def test_tensor_from_tensor_does_not_share_grad_buffer():
    from minitriton.tensor import Tensor
    a = tl.tensor(np.ones(3, np.float32), requires_grad=True)
    b = a * 2
    c = Tensor(b, requires_grad=True)
    (c * 5).sum().backward()
    np.testing.assert_array_equal(c.grad.numpy(), [5.0, 5.0, 5.0])
    assert b.grad is None  # c's accumulation never touched b's state


def test_parameter_from_nonleaf_is_fresh_leaf():
    from minitriton import nn
    a = tl.tensor(np.ones((2, 2), np.float32), requires_grad=True)
    p = nn.Parameter(a * 2)
    assert p.requires_grad and p.grad_fn is None and p.grad is None


# -- numpy f64 input (np.random.randn) treated as f32 ---------------------------

@pytest.mark.parametrize("dev", ["cpu", "cuda"])
def test_tensor_f64_ndarray_treated_as_f32(dev):
    # np.random.randn returns f64 (numpy's default): tl.tensor treats it as
    # f32, same as the python-float list path, instead of raising (f64 is
    # not a supported dtype). Explicit dtype=tl.float32 must work too.
    src = np.random.randn(3, 4)
    ref = src.astype(np.float32)
    for t in (tl.tensor(src, device=dev),
              tl.tensor(src, dtype=tl.float32, device=dev)):
        assert t.dtype == tl.float32
        np.testing.assert_array_equal(t.numpy(), ref)


# -- dim bounds: out-of-range raises, no silent modulo wrap ---------------------

def test_dim_out_of_range_raises():
    x = _t(X)  # 4D
    with pytest.raises(IndexError):
        x.sum(dim=4)
    with pytest.raises(IndexError):
        x.sum(dim=-5)
    with pytest.raises(IndexError):
        x.max(dim=(0, 4))
    with pytest.raises(IndexError):
        x.mean(dim=(0, 0))  # duplicate dims
    with pytest.raises(IndexError):
        x.transpose(0, 7)
    with pytest.raises(IndexError):
        x.permute(0, 1, 2, 4)
    y = _t(A)  # 2D
    with pytest.raises(IndexError):
        y.softmax(dim=2)
    with pytest.raises(IndexError):
        from minitriton import ops as _o
        _o.split(y, 1, dim=3)


def test_dim_negative_edge_still_works():
    x = _t(X)
    np.testing.assert_allclose(x.sum(dim=-4).numpy(), X.sum(axis=0),
                               rtol=1e-5)
    np.testing.assert_allclose(x.sum(dim=(0, -1)).numpy(),
                               X.sum(axis=(0, 3)), rtol=1e-5)


# -- big int scalars (past i32) fall back to the 0-d nd path --------------------

def test_i64_big_scalar_compare_and_arith():
    xl = np.array([[2**40, 5, -3]], np.int64)
    t = _t(xl, tl.int64)
    np.testing.assert_array_equal((t == 2**40).numpy(),
                                  (xl == 2**40).astype(np.float32))
    np.testing.assert_array_equal((t > 2**40 - 1).numpy(),
                                  (xl > 2**40 - 1).astype(np.float32))
    out = t + 2**40
    assert out.dtype == tl.int64
    np.testing.assert_array_equal(out.numpy(), xl + 2**40)


def test_i32_tensor_big_scalar_promotes():
    xi = np.array([1, 2, 3], np.int32)
    out = _t(xi, tl.int32) + 2**40
    assert out.dtype == tl.int64  # torch promotes to i64
    np.testing.assert_array_equal(out.numpy(), xi.astype(np.int64) + 2**40)


# -- eager numerics -----------------------------------------------------------

def test_i64_tensor_tensor_eq_exact():
    a = _t(np.array([2**40, 2**40 + 1, 7]))
    b = _t(np.array([2**40 + 1, 2**40, 7]))
    np.testing.assert_array_equal((a == b).numpy(), [0.0, 0.0, 1.0])
    np.testing.assert_array_equal((a != b).numpy(), [1.0, 1.0, 0.0])


def test_noncontig_int_cmp_big_scalar_layout_independent():
    S = 2**30 + 1
    arr = np.array([2**30, 7, 2**30], np.int32)
    nc, cc = _t(arr)[::2], _t(arr)
    np.testing.assert_array_equal((nc < S).numpy(), [1.0, 1.0])
    np.testing.assert_array_equal((nc == S).numpy(), [0.0, 0.0])
    np.testing.assert_array_equal((cc < S).numpy(), [1.0, 1.0, 1.0])


def test_iadd_strided_view_and_getitem_backward():
    x = _t(np.arange(8, dtype=np.float32))
    v = x[::2]
    v += 1.0
    np.testing.assert_array_equal(x.numpy(),
                                  [1, 1, 3, 3, 5, 5, 7, 7])
    a = tl.tensor(np.arange(8, dtype=np.float32), requires_grad=True)
    a[::2].sum().backward()
    np.testing.assert_array_equal(a.grad.numpy(),
                                  [1, 0, 1, 0, 1, 0, 1, 0])


@pytest.mark.parametrize("dev", ["cpu", "cuda"])
def test_scalar_getitem_backward(dev):
    # an all-int index gives a 0-d view; its backward scatters the grad
    # into the indexed slot of the base
    a = tl.tensor(np.arange(8, dtype=np.float32), device=dev,
                  requires_grad=True)
    a[3].backward()
    ref = np.zeros(8, np.float32)
    ref[3] = 1.0
    np.testing.assert_array_equal(a.grad.numpy(), ref)
    # negative and multi-dim all-int indices land on the same slot as numpy
    b = tl.tensor(np.arange(12, dtype=np.float32).reshape(3, 4),
                  device=dev, requires_grad=True)
    b[-1, 2].backward()
    ref = np.zeros((3, 4), np.float32)
    ref[-1, 2] = 1.0
    np.testing.assert_array_equal(b.grad.numpy(), ref)


def test_zero_elem_reshape_to_nonempty_raises():
    with pytest.raises(RuntimeError):
        tl.empty((0,)).reshape((2, 3))
    z = tl.empty((0, 5)).reshape((0, 5))  # prod stays 0: legal
    assert z.shape == (0, 5)


def test_empty_dim_reduce_returns_new_object():
    x = tl.tensor(np.array([1.0, 2.0], np.float32), requires_grad=True)
    y = x.sum(dim=())
    assert y is not x
    y.sum().backward()  # must terminate (guards against a self-loop hang)
    np.testing.assert_array_equal(x.grad.numpy(), [1.0, 1.0])
    assert x.max(dim=()) is not x


def test_squeeze_dim_bounds():
    z = tl.zeros((1, 3))
    with pytest.raises(IndexError):
        z.squeeze(2)
    with pytest.raises(IndexError):
        z.squeeze(-3)
    assert z.squeeze(0).shape == (3,)


def test_cpu_backend_comparisons():
    a = tl.tensor(np.array([2**30, 7], np.int32), device="cpu")
    np.testing.assert_array_equal((a == 3).numpy(), [0.0, 0.0])
    x = tl.tensor(np.array([2**40, 2**40 + 1, 7]), device="cpu")
    y = tl.tensor(np.array([2**40 + 1, 2**40, 7]), device="cpu")
    np.testing.assert_array_equal((x == y).numpy(), [0.0, 0.0, 1.0])


# -- plan-cache / empty / copy / scalar & index semantics ----------------------

def test_cat_plan_cache_with_zero_size_tensors():
    a = tl.tensor(np.ones((2, 3), np.float32))
    z = tl.tensor(np.zeros((0, 3), np.float32))
    b = tl.tensor(np.full((4, 3), 7.0, np.float32))
    ref = np.concatenate([np.ones((2, 3)), np.zeros((0, 3)),
                          np.full((4, 3), 7.0)])
    for _ in range(3):  # the plan-cache hit path must stay aligned
        np.testing.assert_array_equal(tl.cat([a, z, b], dim=0).numpy(), ref)


def test_empty_full_reduce_identity_and_raises():
    e = tl.tensor(np.zeros((0,), np.float32))
    assert e.sum().item() == 0.0
    with pytest.raises(RuntimeError):
        e.max()
    with pytest.raises(RuntimeError):
        e.min()


def test_copy_and_deepcopy_pool_accounting():
    import copy as _cp
    t = tl.zeros(8, tl.float32) + 5.0  # pooled buffer
    c = _cp.copy(t)
    assert t._storage._owners == 2
    del c
    tl.synchronize()
    np.testing.assert_array_equal(t.numpy(), np.full(8, 5.0))
    d = _cp.deepcopy(t)
    d += 1.0
    np.testing.assert_array_equal(t.numpy(), np.full(8, 5.0))  # independent
    np.testing.assert_array_equal(d.numpy(), np.full(8, 6.0))


def test_zero_elem_steal_does_not_leak_pool_blocks():
    from minitriton.runtime.allocator import _ALLOCATOR
    b0 = _ALLOCATOR.allocated
    for _ in range(200):
        x = tl.tensor(np.zeros((0, 3), np.float32))
        del x
    tl.synchronize()
    assert _ALLOCATOR.allocated == b0


def test_np_integer_scalar_compare_exact():
    t = _t(np.array([2147483646, 2147483647, 100], np.int32), tl.int32)
    s = np.int64(2147483647)
    np.testing.assert_array_equal((t == s).numpy(), [0.0, 1.0, 0.0])
    np.testing.assert_array_equal((t < s).numpy(), [1.0, 0.0, 1.0])
    np.testing.assert_array_equal((t != s).numpy(), [1.0, 0.0, 1.0])


def test_np_scalar_integer_exponent_pow():
    x = _t(np.array([-2.0, 3.0], np.float32))
    np.testing.assert_allclose((x ** np.float32(3.0)).numpy(), [-8.0, 27.0],
                               rtol=1e-5)
    np.testing.assert_allclose((x ** np.int32(2)).numpy(), [4.0, 9.0],
                               rtol=1e-5)


def test_zero_dim_inplace_add():
    a = tl.tensor(5.0)
    a += 1.0
    assert a.item() == 6.0
    z = _t(np.array([1.0, 2.0, 3.0], np.float32))
    s = z[1]
    s += 5.0
    np.testing.assert_array_equal(z.numpy(), [1.0, 7.0, 3.0])


def test_bool_semantics():
    with pytest.raises(RuntimeError, match="ambiguous"):
        bool(tl.zeros(3))
    assert bool(tl.tensor(1.0)) is True
    assert bool(tl.tensor(0.0)) is False


def test_bool_scalar_index_matches_numpy():
    u = _t(np.arange(8, dtype=np.float32).reshape(2, 4))
    assert u[True].shape == (1, 2, 4)
    assert u[False].shape == (0, 2, 4)
    np.testing.assert_array_equal(u[True].numpy(),
                                  np.arange(8).reshape(1, 2, 4))
    np.testing.assert_array_equal(u[True, 1].numpy(), [[4, 5, 6, 7]])
    c = tl.tensor(np.arange(8, dtype=np.float32).reshape(2, 4), device="cpu")
    assert c[True].shape == (1, 2, 4)


def test_bool_scalar_ellipsis_combo_matches_numpy():
    """bool scalars consume no axis: combined with Ellipsis the fill
    count must use the same accounting as the plain-int path (bool was
    miscounted as one consumed axis, under-filling the Ellipsis)."""
    a = np.arange(6, dtype=np.float32).reshape(2, 3)
    u = _t(a)
    ref = a[True, ..., 0]
    got = u[True, ..., 0]
    assert got.shape == ref.shape == (1, 2)
    np.testing.assert_array_equal(got.numpy(), ref)
    c = tl.tensor(a, device="cpu")
    assert c[True, ..., 0].shape == (1, 2)
    np.testing.assert_array_equal(c[True, ..., 0].numpy(), ref)


def test_numpy_scalar_on_left_uses_dunder():
    r = np.float32(2) * _t(np.array([1.0, 2.0, 3.0], np.float32))
    assert isinstance(r, tl.Tensor)
    np.testing.assert_array_equal(r.numpy(), [2.0, 4.0, 6.0])


def test_split_negative_sections_raise():
    from minitriton import ops as _o
    with pytest.raises(RuntimeError, match="non-negative"):
        _o.split(tl.tensor(np.arange(5, dtype=np.float32)), [3, -1, 3])


def test_argmax_empty_raises():
    with pytest.raises(RuntimeError):
        tl.tensor(np.zeros((0,), np.float32)).argmax()
    with pytest.raises(RuntimeError):
        tl.tensor(np.zeros((3, 0), np.float32)).argmax(dim=1)


def test_requires_grad_on_nonleaf_raises():
    x = tl.tensor(np.ones(3, np.float32), requires_grad=True)
    y = x * 2
    with pytest.raises(RuntimeError, match="leaf"):
        y.requires_grad_(False)
    x.requires_grad_(False)  # leaf is fine
    assert not x.requires_grad
