"""@tl.inline helper scoping + return-placement rules:

- a helper's free variables resolve in the HELPER module's globals
  (_inline_call switches gscope along with env), never shadowed by a
  same-name global of the kernel module; a name that exists only in the
  helper module must resolve.
- return nested inside if/for is rejected loudly (kernels and
  inline helpers alike); only the last top-level statement may return.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pytest

import minitriton as tl
from minitriton.frontend.code_generator import DSLCompileError

import _inline_helper_mod as hm
from _inline_helper_mod import scale_it, only_here, add_default

# same-name global in the KERNEL module: must NOT shadow the helper's own
HELPER_SCALE = tl.constexpr(7.0)

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


@tl.kernel
def _k_helper_scope(x_ptr, out_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m)
    tl.store(out_ptr + offs, scale_it(x) + only_here(x), mask=m)


def test_inline_helper_resolves_own_module_globals():
    """The helper's HELPER_SCALE (2.0) wins over the kernel module's
    same-name global (7.0); ONLY_IN_HELPER (11.0) resolves at all."""
    n = 256
    x_np = rn(n)
    x = tl.tensor(x_np)
    out = tl.empty((n,), tl.float32)
    _k_helper_scope[(2,)](x._buffer_arg(), out._buffer_arg(), n, BLOCK=128)
    tl.synchronize()
    ref = x_np * 2.0 + (x_np + 11.0)
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-6, atol=1e-6)
    assert hm.HELPER_SCALE.value == 2.0 and HELPER_SCALE.value == 7.0


@tl.inline
def _pick(x, c):
    if c > 0:
        return x * 1.0
    return x * 2.0


@tl.kernel
def _k_nested_ret_helper(x_ptr, out_ptr, N, C, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m)
    tl.store(out_ptr + offs, _pick(x, C), mask=m)


def test_nested_return_inline_helper_rejected():
    """Runtime-if early return in a helper: both regions would trace and
    the later one would win silently — must fail loudly instead."""
    n = 128
    x = tl.tensor(rn(n))
    out = tl.empty((n,), tl.float32)
    with pytest.raises(DSLCompileError) as ei:
        _k_nested_ret_helper[(1,)](x._buffer_arg(), out._buffer_arg(),
                                   n, 5, BLOCK=128)
    assert "return is only allowed as the last top-level statement" \
        in str(ei.value)


@tl.kernel
def _k_nested_ret(x_ptr, N, BLOCK: tl.constexpr):
    if N == 0:
        return
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    tl.store(x_ptr + offs, 1.0 + tl.zeros((BLOCK,), tl.float32))


def test_nested_bare_return_kernel_rejected():
    """A bare return nested in an if is a silent no-op in a kernel — the
    store below would execute unconditionally. Reject loudly."""
    x = tl.empty((128,), tl.float32)
    with pytest.raises(DSLCompileError) as ei:
        _k_nested_ret[(1,)](x._buffer_arg(), 0, BLOCK=128)
    assert "return is only allowed as the last top-level statement" \
        in str(ei.value)


@tl.kernel
def _k_ret_in_for(x_ptr, N, BLOCK: tl.constexpr):
    for i in range(0, N):
        return
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    tl.store(x_ptr + offs, 1.0 + tl.zeros((BLOCK,), tl.float32))


def test_return_inside_for_rejected():
    x = tl.empty((128,), tl.float32)
    with pytest.raises(DSLCompileError) as ei:
        _k_ret_in_for[(1,)](x._buffer_arg(), 4, BLOCK=128)
    assert "return is only allowed as the last top-level statement" \
        in str(ei.value)


@tl.kernel
def _k_trailing_ret(x_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m)
    tl.store(x_ptr + offs, x * 3.0, mask=m)
    return  # legal: last top-level statement


def test_trailing_top_level_return_still_works():
    """Control: a bare return as the final top-level statement and the
    usual helper returns remain legal."""
    n = 128
    x_np = rn(n)
    x = tl.tensor(x_np)
    _k_trailing_ret[(1,)](x._buffer_arg(), n, BLOCK=128)
    tl.synchronize()
    np.testing.assert_allclose(x.numpy(), x_np * 3.0,
                               rtol=1e-6, atol=1e-6)


# same-name global in the KERNEL module: parameter defaults must resolve
# in the HELPER module's globals (7.0), never shadowed by this one
HELPER_DEFAULT = tl.constexpr(100.0)


@tl.kernel
def _k_inline_param_default(x_ptr, out_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < N
    x = tl.load(x_ptr + offs, mask=m)
    tl.store(out_ptr + offs, add_default(x) + add_default(x, 1.0), mask=m)


def test_inline_helper_param_defaults_resolve_in_helper_module():
    """add_default's default c=HELPER_DEFAULT binds the helper module's
    7.0 — before, defaults were evaluated in the caller's scope and
    silently bound the kernel module's same-name 100.0 (or raised
    'undefined name' when the caller had none)."""
    n = 256
    x_np = rn(n)
    x = tl.tensor(x_np)
    out = tl.empty((n,), tl.float32)
    _k_inline_param_default[(2,)](x._buffer_arg(), out._buffer_arg(), n,
                                  BLOCK=128)
    tl.synchronize()
    ref = (x_np + 7.0) + (x_np + 1.0)
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-6, atol=1e-6)
    assert hm.HELPER_DEFAULT.value == 7.0 and HELPER_DEFAULT.value == 100.0
