"""Fused LN backward (dx + dgamma + dbeta, no materialized xhat/product)
vs the numpy fp32 reference formula (tests/ oracle convention).

Covers the two-stage column-reduce geometry (R up to 16384), the masked
column path (odd C), a weight-free call, and the EVEN_C vectorized
column reduce.
"""

import numpy as np
import pytest

import minitriton as tl
from minitriton import ops


def _ref(g, x, w, eps=1e-5):
    mu = x.mean(1, keepdims=True)
    rstd = 1.0 / np.sqrt(x.var(1, keepdims=True) + eps)
    xh = (x - mu) * rstd
    u = g * w if w is not None else g
    dx = rstd * (u - u.mean(1, keepdims=True)
                 - xh * (u * xh).mean(1, keepdims=True))
    dgamma = (g * xh).sum(0) if w is not None else None
    dbeta = g.sum(0)
    return dx, dgamma, dbeta


def _close(a, b, rtol, atol):
    np.testing.assert_allclose(a.numpy().astype(np.float64), b,
                               rtol=rtol, atol=atol)


@pytest.mark.parametrize("R,C", [(6, 8), (128, 640), (16384, 640),
                                 (100, 96), (333, 130)])
def test_layernorm_backward_fused_f32(R, C):
    rng = np.random.default_rng(0)
    g = rng.standard_normal((R, C)).astype(np.float32)
    x = rng.standard_normal((R, C)).astype(np.float32) * 3
    w = rng.standard_normal((C,)).astype(np.float32)
    dx, dgamma, dbeta = ops.layernorm_backward_fused(
        tl.tensor(g), tl.tensor(x), tl.tensor(w), 1e-5)
    rdx, rdg, rdb = _ref(g, x, w)
    _close(dx, rdx, 1e-4, 1e-5)
    # 16K-row f32 sums: reorder noise floor ~1e-4 absolute (zero crossings)
    _close(dgamma, rdg, 2e-3, 1e-3)
    _close(dbeta, rdb, 2e-3, 1e-3)


def test_layernorm_backward_fused_noweight():
    rng = np.random.default_rng(1)
    g = rng.standard_normal((64, 128)).astype(np.float32)
    x = rng.standard_normal((64, 128)).astype(np.float32)
    dx, dgamma, dbeta = ops.layernorm_backward_fused(
        tl.tensor(g), tl.tensor(x), None, 1e-5)
    rdx, _, rdb = _ref(g, x, None)
    _close(dx, rdx, 1e-4, 1e-5)
    _close(dbeta, rdb, 2e-3, 1e-3)


def test_layernorm_backward_fused_cpu_fallback():
    """Non-CUDA inputs route to the composed path (the fused kernels are
    a CUDA f32 contract): results still match the reference formula."""
    rng = np.random.default_rng(2)
    g = rng.standard_normal((64, 96)).astype(np.float32)
    x = rng.standard_normal((64, 96)).astype(np.float32)
    w = rng.standard_normal((96,)).astype(np.float32)
    dx, dgamma, dbeta = ops.layernorm_backward_fused(
        tl.tensor(g, device="cpu"), tl.tensor(x, device="cpu"),
        tl.tensor(w, device="cpu"), 1e-5)
    rdx, rdg, rdb = _ref(g, x, w)
    _close(dx, rdx, 1e-4, 1e-5)
    _close(dgamma, rdg, 2e-3, 1e-3)
    _close(dbeta, rdb, 2e-3, 1e-3)


def test_reduce_col_even_vec():
    """EVEN_C vectorized column reduce: exact-cover BC (bf16 C=2560) and
    the f32 full-cover case still match the fp64 column sums."""
    from minitriton.device.cuda import ops as be
    for dtype, R, C in ((tl.bfloat16, 16384, 2560),
                        (tl.float32, 16384, 640),
                        (tl.float32, 1000, 512)):
        rng = np.random.default_rng(3)
        x = rng.standard_normal((R, C)).astype(np.float32)
        xt = tl.tensor(x).astype(dtype)
        out = be.reduce_col_sum(xt, tl.float32)
        # the reference sums the values the kernel actually sees (the
        # rounded ones), not the pre-cast originals
        xr = xt.astype(tl.float32).numpy().astype(np.float64)
        np.testing.assert_allclose(out.numpy().astype(np.float64),
                                   xr.sum(0), rtol=2e-3, atol=1e-3)
