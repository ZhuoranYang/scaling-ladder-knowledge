"""Runtime regression tests (cuda graphs / streams / autotune).

numpy-oracle only (tests/ stay torch-free). Covers:

- ``graph.capture``: a nested capture failure must restore
  ``pool._record`` — the outer capture's later allocations stay pinned,
  so replay can never clobber an eager tensor reusing a freed address;
- ``keepalive()``: after interleaved join=False scopes on two side
  streams (s1, s2, s1), a keepalive must attach to the MOST RECENT scope
  (s1) — superseding re-parks the entry to the newest dict position;
- precision compile levers: runtime pokes of ``precision._ROW_FP64``
  & co. are uniformly inert — codegen (builder) and the compile-cache
  fingerprint (runtime/cache) both consume import-time snapshots;
- autotune disk cache: tuple config values survive the JSON
  round-trip (marked encoding), so a second process hits the entry;
- first-time autotune inside a graph capture raises CaptureError
  (not a misleading "no valid config" RuntimeError);
- ``Graph.__del__`` stays silent at interpreter shutdown (no
  function-level ``import sys`` ImportError).
"""

import os
import subprocess
import sys
import textwrap
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.runtime import streams

rng = np.random.default_rng(0)
DEV = "cuda"


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


@pytest.fixture(autouse=True)
def _sync():
    yield
    tl.get_device().synchronize()


# ---------------------------------------------------------------------------
# nested capture failure must not strand pool._record
# ---------------------------------------------------------------------------

def test_capture_nested_failure_restores_record_and_pins():
    from minitriton.runtime import graph as mt_graph
    from minitriton.runtime import allocator as A
    from minitriton.runtime.cuda_driver import CaptureError

    a = tl.tensor(np.full(1024, 2.0, dtype=np.float32), device=DEV)
    # warm kernels AND free pool blocks: during capture b and c each hold
    # one same-size block (temporaries free only when outer returns)
    w = [a * 2.0, a * 3.0, a * 1.0]
    for t in w:
        t.numpy()
    del w
    tl.get_device().synchronize()

    seen = {}

    def outer():
        b = a * 2.0
        try:
            mt_graph.capture(lambda: a * 1.0)   # nested -> CaptureError
        except CaptureError:
            seen["raised"] = True
        c = a * 3.0                             # must stay recorded+pinned
        seen["c_ptr"] = c._storage.ptr
        return b                                # c dropped: freed to pool

    g = mt_graph.capture(outer)
    try:
        assert seen.get("raised"), "nested capture should have raised"
        assert A._ALLOCATOR._record is None
        # the dropped temp's freed buffer was pinned with the rest of the
        # footprint: a same-size eager alloc must NOT land on it
        e1 = tl.zeros(1024, device=DEV)
        tl.get_device().synchronize()
        assert e1._storage.ptr != seen["c_ptr"], \
            "eager alloc landed on the graph's (unpinned) footprint"
        g.launch()
        tl.get_device().synchronize()
        assert bool((e1.numpy() == 0).all()), \
            "graph replay clobbered a live eager tensor"
        # and the graph itself still works
        assert np.allclose(g.out.numpy(), 4.0, rtol=1e-6)
    finally:
        g.teardown()


# ---------------------------------------------------------------------------
# keepalive attaches to the most recent join=False scope
# ---------------------------------------------------------------------------

def test_keepalive_attaches_to_most_recent_scope(monkeypatch):
    from minitriton.runtime import cuda_driver as _drv

    tl.get_device()  # context before touching the pool
    pool = streams.default_pool()
    s1 = pool.side()
    dev = _drv.get_default_device()
    dev.set_current()
    s2 = int(_drv.check(_drv.CU.cuStreamCreate(
        _drv.CU.CUstream_flags.CU_STREAM_NON_BLOCKING), "cuStreamCreate"))
    # keep parked entries un-reaped so the attachment target is
    # deterministic (the bug is an ordering bug, not a timing one)
    monkeypatch.setattr(_drv.Event, "query", lambda self: False)
    try:
        with streams.stream(s1, join=False):
            pass
        with streams.stream(s2, join=False):
            pass
        with streams.stream(s1, join=False):  # supersedes s1's entry
            pass
        # superseding re-parked s1's entry to the newest position
        assert list(pool._pending) == [s2, s1]
        a = tl.zeros(64, device=DEV)
        streams.keepalive(a)
        assert a in pool._pending[s1][1], \
            "keepalive must attach to the most recent scope (s1)"
        assert a not in pool._pending[s2][1]
    finally:
        streams.join_pending()
        _drv.CU.cuStreamDestroy(_drv.CU.CUstream(s2))


# ---------------------------------------------------------------------------
# precision compile levers: import-time snapshots for codegen + keys
# ---------------------------------------------------------------------------

@tl.kernel
def _rowsum_lever_inert(x_ptr, out_ptr, C, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    m = offs < C
    x = tl.load(x_ptr + row * C + offs, mask=m, other=0.0)
    s = tl.sum(x)
    tl.store(out_ptr + row * C + offs, x * 0.0 + s, mask=m)


def _emit_mlir(k, args, warps=4):
    bindings, values, _ = k._bind(args, None, {})
    return k._emit_mlir(bindings, values, warps)[0]


def test_precision_lever_poke_is_inert_for_codegen_and_keys(monkeypatch):
    from minitriton import precision
    from minitriton.compiler import builder as _b
    from minitriton.runtime import cache as rt_cache

    # snapshots taken at import agree with the (unpoked) live globals
    assert _b._ROW_FP64 == precision.row_fp64()
    assert _b._PRECISE_MATH == precision.precise_math()

    x = tl.Buffer.from_numpy(rn(1024))
    out = tl.Buffer(1024, tl.float32)
    args = (x, out, 1024, 1024)
    mlir0 = _emit_mlir(_rowsum_lever_inert, args)

    fp0 = rt_cache.codegen_fingerprint()
    monkeypatch.setattr(precision, "_ROW_FP64", not _b._ROW_FP64)
    assert precision.row_fp64() == (not _b._ROW_FP64)  # poke reached the
    # live global, but neither consumer may follow it:
    assert _b._ROW_FP64 == (not precision.row_fp64()), \
        "builder snapshot must be frozen at import"
    mlir1 = _emit_mlir(_rowsum_lever_inert, args)
    assert mlir0 == mlir1, "runtime poke reached codegen (stale-key cubin)"
    assert rt_cache.codegen_fingerprint() == fp0
    # the disk-key component is the same import-time snapshot
    assert f"row_fp64={_b._ROW_FP64}" in rt_cache._PREC_FINGERPRINT


def test_stream_overlap_lever_reads_live(monkeypatch):
    """MT_STREAM_OVERLAP is a launch-routing lever (side streams, not
    compiled code): precision.stream_overlap() must follow a mid-process
    env flip, like MT_FP32_SPLITK — the module docstring documents it as
    the one read-live exception to the import-frozen compile levers."""
    from minitriton import precision

    monkeypatch.delenv("MT_STREAM_OVERLAP", raising=False)
    assert precision.stream_overlap() is False
    monkeypatch.setenv("MT_STREAM_OVERLAP", "1")
    assert precision.stream_overlap() is True
    monkeypatch.setenv("MT_STREAM_OVERLAP", "0")
    assert precision.stream_overlap() is False


# ---------------------------------------------------------------------------
# autotune disk cache round-trips tuple config values
# ---------------------------------------------------------------------------

@tl.kernel
def _tuple_cfg_kernel(x_ptr, N, BLOCK: tl.constexpr, TILE: tl.constexpr):
    pass


def test_autotune_disk_roundtrip_tuple_config(tmp_path, monkeypatch):
    monkeypatch.setenv("MINITRITON_CACHE_DIR", str(tmp_path))
    from minitriton.runtime import autotune as at

    cfgs = [tl.Config({"BLOCK": 128, "TILE": (64, 2)}, num_warps=4),
            tl.Config({"BLOCK": 256, "TILE": (32, 4)}, num_warps=4)]
    tuner = at.Autotuner(_tuple_cfg_kernel, cfgs, ["N"])
    kvals = (1024,)
    tuner._save(kvals, cfgs[0])
    loaded = tuner._load(kvals)
    assert loaded is not None, "tuple config read back as list: key mismatch"
    assert loaded.kwargs == cfgs[0].kwargs
    assert isinstance(loaded.kwargs["TILE"], tuple)
    # a second "process" (fresh tuner, empty mem) must HIT the disk entry
    tuner2 = at.Autotuner(_tuple_cfg_kernel, cfgs, ["N"])
    assert tuner2._load(kvals) is not None


# ---------------------------------------------------------------------------
# first-time autotune inside capture raises CaptureError
# ---------------------------------------------------------------------------

@tl.autotune(configs=[tl.Config({"BLOCK": 256}, num_warps=4),
                      tl.Config({"BLOCK": 512}, num_warps=4)],
             key=["N"])
@tl.kernel
def _vecadd_capture(x_ptr, y_ptr, out_ptr, N, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < N
    x = tl.load(x_ptr + offs, mask=mask)
    y = tl.load(y_ptr + offs, mask=mask)
    tl.store(out_ptr + offs, x + y, mask=mask)


def test_autotune_inside_capture_raises_capture_error(tmp_path, monkeypatch):
    from minitriton.runtime import autotune as at
    from minitriton.runtime import graph as mt_graph
    from minitriton.runtime.cuda_driver import CaptureError

    monkeypatch.setenv("MINITRITON_CACHE_DIR", str(tmp_path))
    # fresh tuner (empty mem + tmp disk) so the in-capture launch really
    # reaches _tune instead of a cached pick
    tuner = at.Autotuner(
        _vecadd_capture,
        [tl.Config({"BLOCK": 256}, num_warps=4),
         tl.Config({"BLOCK": 512}, num_warps=4)], ["N"])
    monkeypatch.setattr(_vecadd_capture, "autotuner", tuner)

    n = 100_003
    x = tl.Buffer.from_numpy(rn(n))
    y = tl.Buffer.from_numpy(rn(n))
    out = tl.Buffer(n, tl.float32)
    grid = lambda a: ((a["N"] + a["BLOCK"] - 1) // a["BLOCK"],)
    # pre-load both cubins OUTSIDE capture so the in-capture tune reaches
    # do_bench deterministically (no cuModuleLoad under capture)
    for cfg in ({"BLOCK": 256}, {"BLOCK": 512}):
        _vecadd_capture.compile_with((x, y, out, n, 0), cfg, 4, {})

    with pytest.raises(CaptureError):
        mt_graph.capture(lambda: _vecadd_capture[grid](x, y, out, n, 0))


# ---------------------------------------------------------------------------
# Graph.__del__ is silent at interpreter shutdown
# ---------------------------------------------------------------------------

def test_graph_del_clean_at_interpreter_exit():
    child = textwrap.dedent("""
        import numpy as np
        import minitriton as tl
        from minitriton.runtime import graph as mt_graph

        x = tl.tensor(np.ones(1024, dtype=np.float32), device="cuda")
        (x + 1.0).numpy()
        g = mt_graph.capture(lambda: x + 1.0)  # kept till shutdown
        print("captured ok")
    """)
    root = str(Path(__file__).resolve().parents[1])
    p = subprocess.run([sys.executable, "-c", child],
                       capture_output=True, text=True,
                       env={**os.environ, "PYTHONPATH": root})
    assert p.returncode == 0, p.stderr
    assert "captured ok" in p.stdout
    assert "Exception ignored" not in p.stderr
