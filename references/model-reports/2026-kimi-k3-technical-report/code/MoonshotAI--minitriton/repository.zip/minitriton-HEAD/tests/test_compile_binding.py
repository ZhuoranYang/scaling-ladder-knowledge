"""Binding / cache-key correctness regressions (numpy oracles):

- @tl.compile kwargs must bind alphabetically everywhere — trace-time
      input recording, exec-time argument assembly, and the cache key.
      Non-alphabetical kwarg order mis-binding values positionally also
      poisons the cached graph for the alphabetical order.
- a tl.constexpr passed POSITIONALLY must be part of the fast-launch
      cache key: relaunching with a different value must compile a second
      cubin instead of silently reusing the first one.
- fused elementwise chains load their leaves flat: a transposed /
      broadcast-expanded / non-contiguous leaf must make the group
      degrade to the eager per-node replay (correct, just unfused), and
      tensor strides are part of the @tl.compile cache key.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.compile import _Exec

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


# ---------------------------------------------------------------------------
# kwargs binding order
# ---------------------------------------------------------------------------

def test_compile_kwargs_binding_order():
    @tl.compile
    def f(x, p, q):
        return x * p + q

    x, a, b = rn(4, 8), rn(4, 8), rn(4, 8)
    tx, ta, tb = tl.tensor(x), tl.tensor(a), tl.tensor(b)
    ref = x * b + a  # p=b, q=a
    # non-alphabetical kwarg order must not swap the values
    np.testing.assert_allclose(f(tx, q=ta, p=tb).numpy(), ref,
                               rtol=1e-5, atol=1e-6)
    # the alphabetical order shares the cached graph and must agree
    np.testing.assert_allclose(f(tx, p=tb, q=ta).numpy(), ref,
                               rtol=1e-5, atol=1e-6)
    # mixed positional + kwarg hits the same canonical binding
    np.testing.assert_allclose(f(tx, tb, q=ta).numpy(), ref,
                               rtol=1e-5, atol=1e-6)
    assert len(f._cache) == 1


def test_compile_kwargs_order_with_scalar():
    @tl.compile
    def f(x, p, s, q):
        return (x * p + q) * s

    x, a, b = rn(16), rn(16), rn(16)
    tx, ta, tb = tl.tensor(x), tl.tensor(a), tl.tensor(b)
    ref = (x * b + a) * 2.5
    out = f(tx, q=ta, s=2.5, p=tb)  # q/s/p: neither sorted nor signature
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-5, atol=1e-6)
    assert len(f._cache) == 1


# ---------------------------------------------------------------------------
# positional constexpr in the fast-launch key
# ---------------------------------------------------------------------------

def _add_block_kernel():
    @tl.kernel
    def add_block(buf, n, BLOCK: tl.constexpr):
        offs = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
        v = tl.load(buf + offs, mask=offs < n, other=0.0)
        tl.store(buf + offs, v + BLOCK, mask=offs < n)
    return add_block


def test_fast_launch_positional_constexpr_recompiles():
    add_block = _add_block_kernel()
    n = 8
    buf = tl.Buffer.from_numpy(np.zeros(n, dtype=np.float32))
    add_block[(1,)](buf, n, 4)  # BLOCK=4 positionally: elems 0..3 += 4
    add_block[(1,)](buf, n, 8)  # BLOCK=8 positionally: all elems += 8
    tl.synchronize()
    # different positional constexpr values are different cubins; the
    # second launch must not reuse the BLOCK=4 entry
    assert len(add_block._compiled) == 2
    assert len(add_block._fast) == 2
    np.testing.assert_array_equal(
        buf.to_numpy(),
        np.array([12, 12, 12, 12, 8, 8, 8, 8], dtype=np.float32))


def test_fast_launch_runtime_int_not_in_key():
    add_block = _add_block_kernel()
    buf = tl.Buffer.from_numpy(np.zeros(8, dtype=np.float32))
    add_block[(1,)](buf, 8, 8)
    add_block[(1,)](buf, 4, 8)  # runtime scalar: refreshed, same cubin
    tl.synchronize()
    assert len(add_block._compiled) == 1
    assert len(add_block._fast) == 1
    np.testing.assert_array_equal(
        buf.to_numpy(),
        np.array([16, 16, 16, 16, 8, 8, 8, 8], dtype=np.float32))


# ---------------------------------------------------------------------------
# fused ew chains with non-contiguous / broadcast leaves
# ---------------------------------------------------------------------------

@pytest.fixture
def replay_spy(monkeypatch):
    """Counts exec-time degrades to the eager per-node replay."""
    calls = []
    orig = _Exec._replay_group

    def spy(self, root, spec, env):
        calls.append(root)
        return orig(self, root, spec, env)

    monkeypatch.setattr(_Exec, "_replay_group", spy)
    return calls


def test_ew_fusion_transposed_leaf_degrades(replay_spy):
    @tl.compile
    def f(x, y):
        return (x.t() + y) * 2.0

    x, y = rn(4, 8), rn(8, 4)
    out = f(tl.tensor(x), tl.tensor(y))
    np.testing.assert_allclose(out.numpy(), (x.T + y) * 2.0,
                               rtol=1e-5, atol=1e-6)
    # planned as one fused ew group, degraded at exec (leaf is a view)
    exe = list(f._cache.values())[0]
    assert len(exe.fused) == 1
    assert list(exe.fused.values())[0]["type"] == "ew_chain"
    assert len(replay_spy) == 1


def test_ew_fusion_broadcast_leaf_degrades(replay_spy):
    @tl.compile
    def f(x, z):
        return (x + z.expand(x.shape)) * 2.0

    x, z = rn(4, 8), rn(1, 8)
    tx, tz = tl.tensor(x), tl.tensor(z)
    # marker allocation next to z's storage: a flat OOB read of the
    # broadcast leaf would pick up pool garbage instead of z's values
    _marker = tl.tensor(np.full((4, 8), -777.0, dtype=np.float32))
    out = f(tx, tz)
    np.testing.assert_allclose(out.numpy(), (x + z) * 2.0,
                               rtol=1e-5, atol=1e-6)
    assert len(replay_spy) == 1


def test_ew_fusion_noncontiguous_arg_gets_own_graph(replay_spy):
    @tl.compile
    def f(x, y):
        return (x + y) * 2.0

    a, b = rn(8, 4), rn(8, 4)
    np.testing.assert_allclose(f(tl.tensor(a), tl.tensor(b)).numpy(),
                               (a + b) * 2.0, rtol=1e-5, atol=1e-6)
    assert len(replay_spy) == 0  # contiguous args stay on the fused path
    # same shapes but a transposed view: strides enter the cache key, the
    # new graph degrades to the eager replay instead of reading flat
    base = rn(4, 8)
    out = f(tl.tensor(base).t(), tl.tensor(b))
    np.testing.assert_allclose(out.numpy(), (base.T + b) * 2.0,
                               rtol=1e-5, atol=1e-6)
    assert len(f._cache) == 2
    assert len(replay_spy) == 1
