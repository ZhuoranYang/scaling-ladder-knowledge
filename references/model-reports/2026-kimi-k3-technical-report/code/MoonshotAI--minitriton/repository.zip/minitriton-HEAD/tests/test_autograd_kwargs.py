"""Autograd Function.apply kwargs binding: inputs were
recorded as (positional args, kwargs in call-site insertion order) while
backward() returns grads in forward-SIGNATURE order — out-of-order kwargs
silently swapped grads (mul(b=y, a=x)) or dropped them
(embedding(indices=i, weight=w) left weight with no grad). numpy oracle,
no torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import ops

DEVS = pytest.mark.parametrize("dev", ["cpu", "cuda"])

rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


def T(x, dev, requires_grad=True):
    return tl.tensor(np.ascontiguousarray(x), device=dev,
                     requires_grad=requires_grad)


def close(out, ref, rtol=1e-5, atol=1e-6):
    arr = out.numpy() if isinstance(out, tl.Tensor) else out
    ref = ref.numpy() if isinstance(ref, tl.Tensor) else np.asarray(ref)
    assert arr.shape == ref.shape, f"shape {arr.shape} != ref {ref.shape}"
    np.testing.assert_allclose(arr, ref, rtol=rtol, atol=atol)


@DEVS
def test_mul_kwargs_out_of_order(dev):
    a, b, g = rn(2, 3), rn(2, 3), rn(2, 3)
    ta, tb = T(a, dev), T(b, dev)
    ops.mul(b=tb, a=ta).backward(T(g, dev, False))
    close(ta.grad, g * b, rtol=1e-4, atol=1e-5)
    close(tb.grad, g * a, rtol=1e-4, atol=1e-5)


@DEVS
def test_sub_kwargs_out_of_order(dev):
    # non-commutative: catches both forward-binding and grad-order bugs
    a, b, g = rn(4), rn(4), rn(4)
    ta, tb = T(a, dev), T(b, dev)
    out = ops.sub(b=tb, a=ta)
    close(out, a - b)
    out.backward(T(g, dev, False))
    close(ta.grad, g, rtol=1e-4, atol=1e-5)
    close(tb.grad, -g, rtol=1e-4, atol=1e-5)


@DEVS
def test_kwargs_match_positional(dev):
    a, b, g = rn(2, 3), rn(2, 3), rn(2, 3)
    ta1, tb1 = T(a, dev), T(b, dev)
    ops.mul(ta1, tb1).backward(T(g, dev, False))
    ta2, tb2 = T(a, dev), T(b, dev)
    ops.mul(b=tb2, a=ta2).backward(T(g, dev, False))
    close(ta2.grad, ta1.grad)
    close(tb2.grad, tb1.grad)


@DEVS
def test_layer_norm_kwargs_out_of_order(dev):
    a, w, b, g = rn(2, 8), rn(8), rn(8), rn(2, 8)
    ta, tw, tb = T(a, dev), T(w, dev), T(b, dev)
    ops.layer_norm(ta, (8,), bias=tb, weight=tw).backward(T(g, dev, False))
    mu = a.mean(-1, keepdims=True)
    var = a.var(-1, keepdims=True)
    xhat = (a - mu) / np.sqrt(var + 1e-5)
    close(tb.grad, g.sum(0), rtol=1e-4, atol=1e-5)             # dbeta
    close(tw.grad, (g * xhat).sum(0), rtol=1e-4, atol=1e-5)    # dgamma


@DEVS
def test_embedding_kwargs_weight_gets_grad(dev):
    w = rn(6, 4)
    idx = np.array([0, 2, 2, 5], dtype=np.int32)
    g = rn(4, 4)
    tw, ti = T(w, dev), T(idx, dev, False)
    ops.embedding(indices=ti, weight=tw).backward(T(g, dev, False))
    assert tw.grad is not None, "weight grad dropped by kwargs ordering"
    ref = np.zeros_like(w)
    for r, i in enumerate(idx):
        ref[i] += g[r]
    close(tw.grad, ref, rtol=1e-4, atol=1e-5)


@DEVS
def test_cross_entropy_kwargs_logits_gets_grad(dev):
    x = rn(3, 5)
    tgt = np.array([1, 3, 0], dtype=np.int32)
    tx, tt = T(x, dev), T(tgt, dev, False)
    ops.cross_entropy(target=tt, logits=tx).backward()
    assert tx.grad is not None, "logits grad dropped by kwargs ordering"
    e = np.exp(x - x.max(-1, keepdims=True))
    p = e / e.sum(-1, keepdims=True)
    p[np.arange(3), tgt] -= 1.0
    close(tx.grad, p / 3, rtol=1e-4, atol=1e-5)
