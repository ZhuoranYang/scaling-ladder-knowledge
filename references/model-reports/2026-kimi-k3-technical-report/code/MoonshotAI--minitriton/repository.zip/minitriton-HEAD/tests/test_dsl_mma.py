"""General tile-level mma DSL primitives: tl.mma_layout /
tl.load(LAYOUT=Fragment A) / tl.mma / tl.materialize(LAYOUT=) /
tl.convert_layout / fragment gathers — numpy-oracle unit tests.

These are the building blocks the flash/kda DSL kernels choreograph;
each test is a small @tl.kernel composed from the primitives, checked
against fp64/bf16-rounded numpy references. No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton.compiler.layout import Fragment, mma_layout, parse

from test_flash_mma import bf16_round, rn


def test_mma_layout_geometry():
    """constructor + dump/parse roundtrip; the warp-slab invariant."""
    la = mma_layout("A", (64, 64), "bf16", 128)
    lc = mma_layout("C", (64, 64), "bf16", 128)
    assert la.role == "A" and la.warps == (4, 1) and la.atoms == (1, 4)
    assert lc.role == "C" and lc.warps == (4, 1) and lc.atoms == (1, 8)
    assert parse(la.dump()) == la and parse(lc.dump()) == lc
    with pytest.raises(Exception):
        mma_layout("B", (64, 64), "bf16", 128)   # B stays staged-only
    with pytest.raises(Exception):
        mma_layout("A", (50, 64), "bf16", 128)   # geometry must divide


@tl.kernel
def _mma_nat_kernel(a_ptr, b_ptr, c_ptr, Kb,
                    BM: tl.constexpr, BK: tl.constexpr, BN: tl.constexpr,
                    EVEN: tl.constexpr, MASKED: tl.constexpr):
    """C(BM,BN) = A(BM,BK) @ B(BK,BN), bf16 operands, f32 out: one
    register-A x staged-B tl.mma tile."""
    offs_m = tl.arange(0, BM)
    offs_k = tl.arange(0, BK)
    offs_n = tl.arange(0, BN)
    a_pt = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    b_pt = b_ptr + offs_k[:, None] * BN + offs_n[None, :]
    a_fr = tl.load(a_pt, LAYOUT=tl.mma_layout("A", (BM, BK), "bf16"))
    if MASKED:
        acc = tl.mma(a_fr, b_pt, TRANS_B=False,
                     MASK=(offs_k < Kb)[:, None])
    else:
        acc = tl.mma(a_fr, b_pt, TRANS_B=False, EVEN=EVEN)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


@tl.kernel
def _mma_trans_kernel(a_ptr, b_ptr, c_ptr, Nb,
                      BM: tl.constexpr, BK: tl.constexpr, BN: tl.constexpr,
                      EVEN: tl.constexpr, MASKED: tl.constexpr):
    """C(BM,BN) = A(BM,BK) @ B(BN,BK)ᵀ — b_ptr is the (BK,BN) transposed
    VIEW of the (BN,BK) data (unit row stride), TRANS_B staging."""
    offs_m = tl.arange(0, BM)
    offs_k = tl.arange(0, BK)
    offs_n = tl.arange(0, BN)
    a_pt = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    bt_pt = b_ptr + offs_k[:, None] + offs_n[None, :] * BK
    a_fr = tl.load(a_pt, LAYOUT=tl.mma_layout("A", (BM, BK), "bf16"))
    if MASKED:
        acc = tl.mma(a_fr, bt_pt, TRANS_B=True,
                     MASK=(offs_n < Nb)[None, :])
    else:
        acc = tl.mma(a_fr, bt_pt, TRANS_B=True, EVEN=EVEN)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


def test_dsl_mma_natural():
    BM, BK, BN = 64, 64, 64
    a = bf16_round(rn(BM, BK, seed=0))
    b = bf16_round(rn(BK, BN, seed=1))
    ta, tb = (tl.tensor(x).astype(tl.bfloat16) for x in (a, b))
    tc = tl.empty((BM, BN), tl.float32)
    _mma_nat_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                          tc._buffer_arg(), BK,
                          BM=BM, BK=BK, BN=BN, EVEN=True, MASKED=False,
                          num_warps=4)
    ref = a.astype(np.float64) @ b.astype(np.float64)
    # bf16 mma with f32 accumulate == the fp64 product of the rounded
    # operands, up to the fp32 accumulation order (tight tolerance)
    np.testing.assert_allclose(tc.numpy(), ref, rtol=1e-5, atol=1e-5)


def test_dsl_mma_trans():
    BM, BK, BN = 64, 64, 64
    a = bf16_round(rn(BM, BK, seed=0))
    b = bf16_round(rn(BN, BK, seed=1))
    ta, tb = (tl.tensor(x).astype(tl.bfloat16) for x in (a, b))
    tc = tl.empty((BM, BN), tl.float32)
    _mma_trans_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                            tc._buffer_arg(), BN,
                            BM=BM, BK=BK, BN=BN, EVEN=True, MASKED=False,
                            num_warps=4)
    ref = a.astype(np.float64) @ b.astype(np.float64).T
    np.testing.assert_allclose(tc.numpy(), ref, rtol=1e-5, atol=1e-5)


def test_dsl_mma_masked_staging():
    """MASK zfills staged B rows/cols out of bounds (4B staging path)."""
    BM, BK, BN = 64, 64, 64
    Kb, Nb = 40, 24
    a = bf16_round(rn(BM, BK, seed=0))
    b = bf16_round(rn(BK, BN, seed=1))
    ta, tb = (tl.tensor(x).astype(tl.bfloat16) for x in (a, b))
    tc = tl.empty((BM, BN), tl.float32)
    _mma_nat_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                          tc._buffer_arg(), Kb,
                          BM=BM, BK=BK, BN=BN, EVEN=False, MASKED=True,
                          num_warps=4)
    ref = a.astype(np.float64)[:, :Kb] @ b.astype(np.float64)[:Kb]
    np.testing.assert_allclose(tc.numpy(), ref, rtol=1e-5, atol=1e-5)
    tc2 = tl.empty((BM, BN), tl.float32)
    _mma_trans_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                            tc2._buffer_arg(), Nb,
                            BM=BM, BK=BK, BN=BN, EVEN=False, MASKED=True,
                            num_warps=4)
    ref2 = a.astype(np.float64)[:, :] @ np.where(
        np.arange(BN) < Nb, b.astype(np.float64).T, 0.0)
    np.testing.assert_allclose(tc2.numpy(), ref2, rtol=1e-5, atol=1e-5)


@tl.kernel
def _frag_a_mask_kernel(a_ptr, c_ptr, T,
                        BM: tl.constexpr, BK: tl.constexpr,
                        BN: tl.constexpr):
    """fragment-A load with row guards: out-of-T rows zfill."""
    offs_m = tl.arange(0, BM)
    offs_k = tl.arange(0, BK)
    offs_n = tl.arange(0, BN)
    a_pt = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    b_pt = a_ptr + offs_k[:, None] * BN + offs_n[None, :]  # reuse a as B
    a_fr = tl.load(a_pt, LAYOUT=tl.mma_layout("A", (BM, BK), "bf16"),
                   mask=(offs_m < T)[:, None])
    acc = tl.mma(a_fr, b_pt, TRANS_B=False, EVEN=True)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


def test_dsl_frag_a_masked_load():
    BM, BK, BN, T = 64, 64, 64, 37
    a = bf16_round(rn(BM, BK, seed=0))
    ta = tl.tensor(a).astype(tl.bfloat16)
    tc = tl.empty((BM, BN), tl.float32)
    _frag_a_mask_kernel[(1,)](ta._buffer_arg(), tc._buffer_arg(), T,
                              BM=BM, BK=BK, BN=BN, num_warps=4)
    az = np.where((np.arange(BM) < T)[:, None], a, 0.0)
    ref = az.astype(np.float64) @ a.astype(np.float64)
    np.testing.assert_allclose(tc.numpy(), ref, rtol=1e-5, atol=1e-5)


@tl.kernel
def _frag_gather_kernel(x_ptr, y_ptr, o_ptr, XB,
                        BM: tl.constexpr, BN: tl.constexpr):
    """o[i, j] = x[i] - y[j] computed on a Fragment(C) from NARROW
    Sliced stat loads (x guarded by XB) — no wide replicated vectors."""
    offs_m = tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    lay_c = tl.mma_layout("C", (BM, BN), "bf16")
    xv = tl.load(x_ptr + offs_m[:, None], LAYOUT=lay_c,
                 mask=(offs_m < XB)[:, None], other=0.0)
    yv = tl.load(y_ptr + offs_n[None, :], LAYOUT=lay_c)
    v = tl.zeros((BM, BN), tl.float32, LAYOUT=lay_c) + xv - yv
    tl.store(o_ptr + offs_m[:, None] * BN + offs_n[None, :], v)


def test_dsl_fragment_gather():
    BM, BN, XB = 64, 64, 51
    x = rn(BM, seed=0)
    y = rn(BN, seed=1)
    tx, ty = tl.tensor(x), tl.tensor(y)
    to = tl.empty((BM, BN), tl.float32)
    _frag_gather_kernel[(1,)](tx._buffer_arg(), ty._buffer_arg(),
                              to._buffer_arg(), XB,
                              BM=BM, BN=BN, num_warps=4)
    ref = np.where((np.arange(BM) < XB)[:, None], x[:, None], 0.0) - y[None, :]
    np.testing.assert_allclose(to.numpy(), ref, rtol=1e-6, atol=1e-6)


@tl.kernel
def _mma_chain_kernel(a_ptr, k_ptr, v_ptr, x_ptr, o_ptr, scale,
                      BM: tl.constexpr, BK: tl.constexpr,
                      BN: tl.constexpr, HD: tl.constexpr):
    """The flash-style mma -> elementwise -> mma chain: S = A·Kᵀ (trans
    staging), P = exp(S·scale − x[row]) on the C fragment, out =
    pack(P)·V (convert_layout C->A, natural staging) — bf16 end to end.
    """
    offs_m = tl.arange(0, BM)
    offs_k = tl.arange(0, BK)
    offs_n = tl.arange(0, BN)
    offs_d = tl.arange(0, HD)
    a_pt = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    kt_pt = k_ptr + offs_k[:, None] + offs_n[None, :] * BK
    v_pt = v_ptr + offs_n[:, None] * HD + offs_d[None, :]
    lay_c = tl.mma_layout("C", (BM, BN), "bf16")
    a_fr = tl.load(a_pt, LAYOUT=tl.mma_layout("A", (BM, BK), "bf16"))
    s = tl.mma(a_fr, kt_pt, TRANS_B=True, EVEN=True)
    xv = tl.load(x_ptr + offs_m[:, None], LAYOUT=lay_c)
    p = tl.exp(s * scale - xv)
    p_a = tl.convert_layout(p, tl.mma_layout("A", (BM, BN), "bf16"))
    acc = tl.zeros((BM, HD), tl.float32,
                   LAYOUT=tl.mma_layout("C", (BM, HD), "bf16"))
    acc = tl.mma(p_a, v_pt, acc, TRANS_B=False, EVEN=True)
    tl.store(o_ptr + offs_m[:, None] * HD + offs_d[None, :], acc * scale)


def test_dsl_mma_chain():
    """mma -> exp on the fragment -> frag_c_to_a -> mma (the flash tile
    shape), against an fp64 oracle with a bf16-rounded P."""
    BM, BK, BN, HD = 64, 64, 64, 64
    scale = 0.125
    a = bf16_round(rn(BM, BK, seed=0))
    k = bf16_round(rn(BN, BK, seed=1))
    v = bf16_round(rn(BN, HD, seed=2))
    x = rn(BM, seed=3)
    ta, tk, tv, tx = (tl.tensor(t).astype(tl.bfloat16) if t.ndim == 2
                      else tl.tensor(t) for t in (a, k, v, x))
    to = tl.empty((BM, HD), tl.float32)
    _mma_chain_kernel[(1,)](ta._buffer_arg(), tk._buffer_arg(),
                            tv._buffer_arg(), tx._buffer_arg(),
                            to._buffer_arg(), scale,
                            BM=BM, BK=BK, BN=BN, HD=HD, num_warps=4)
    s = a.astype(np.float64) @ k.astype(np.float64).T * scale - x[:, None]
    p = bf16_round(np.exp(s))          # the A operand packs to bf16
    ref = (p @ v.astype(np.float64)) * scale
    np.testing.assert_allclose(to.numpy(), ref, rtol=2e-2, atol=2e-2)


@tl.kernel
def _mma_pipe_kernel(a_ptr, b_ptr, c_ptr, K,
                     BM: tl.constexpr, BK: tl.constexpr, BN: tl.constexpr):
    """Whole-K matmul on the async-pipeline primitives: one b pipe, the
    next tile staged right after the current tile's mma (the flash bwd
    pipeline pattern)."""
    pid_m = tl.program_id(0)
    offs_m = pid_m * BM + tl.arange(0, BM)
    offs_k = tl.arange(0, BK)
    offs_n = tl.arange(0, BN)
    a_pt = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    b_pipe = tl.stage_pipe((BK, BN), tl.bfloat16, EVEN=True)
    a_fr = tl.load(a_pt, LAYOUT=tl.mma_layout("A", (BM, BK), "bf16"))
    acc = tl.zeros((BM, BN), tl.float32,
                   LAYOUT=tl.mma_layout("C", (BM, BN), "bf16"))
    p_b = tl.async_stage(
        b_pipe, b_ptr + offs_k[:, None] * BN + offs_n[None, :])
    for k0 in range(0, K, BK):
        acc = tl.mma(a_fr, p_b, acc, PENDING=0)
        k_next = tl.where(k0 + BK < K, k0 + BK, K - BK)
        offs_kn = k_next + offs_k
        p_b = tl.async_stage(
            b_pipe, b_ptr + offs_kn[:, None] * BN + offs_n[None, :])
        a_pt = a_ptr + offs_m[:, None] * K + offs_kn[None, :]
        a_fr = tl.load(a_pt, LAYOUT=tl.mma_layout("A", (BM, BK), "bf16"))
    tl.async_wait(p_b, 0)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


def test_dsl_mma_pipeline():
    """stage_pipe/async_stage/async_wait + promise-form tl.mma: a K-loop
    matmul with one-tile lookahead vs the fp64 oracle."""
    BM, BK, BN, K = 64, 64, 64, 256
    a = bf16_round(rn(BM, K, seed=0))
    b = bf16_round(rn(K, BN, seed=1))
    ta, tb = (tl.tensor(x).astype(tl.bfloat16) for x in (a, b))
    tc = tl.empty((BM, BN), tl.float32)
    _mma_pipe_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                           tc._buffer_arg(), K,
                           BM=BM, BK=BK, BN=BN, num_warps=4)
    ref = a.astype(np.float64) @ b.astype(np.float64)
    np.testing.assert_allclose(tc.numpy(), ref, rtol=1e-5, atol=1e-5)


# ---------------------------------------------------------------------------
# KDA DSL constructs: f32-plane A-load operand casts, tf32 tl.mma,
# full-tile fragment-C loads
# ---------------------------------------------------------------------------

@tl.kernel
def _mma_f32a_kernel(a_ptr, b_ptr, c_ptr,
                     BM: tl.constexpr, BK: tl.constexpr, BN: tl.constexpr,
                     ATOM: tl.constexpr):
    """C = A @ B with the A operand read from an f32 plane straight into
    the atom's packed registers (cvt.rn.bf16x2 pairs / cvt.rna.tf32 —
    the staged route's cast-in-load semantics)."""
    offs_m = tl.arange(0, BM)
    offs_k = tl.arange(0, BK)
    offs_n = tl.arange(0, BN)
    a_pt = a_ptr + offs_m[:, None] * BK + offs_k[None, :]
    b_pt = b_ptr + offs_k[:, None] * BN + offs_n[None, :]
    a_fr = tl.load(a_pt, LAYOUT=tl.mma_layout("A", (BM, BK), ATOM))
    acc = tl.mma(a_fr, b_pt, EVEN=True)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


def test_dsl_mma_f32_plane_a_cast_bf16():
    """f32 plane -> bf16 A-fragment pack: bit-equal to the mma_tile
    f32-staged route (same cvt.rn at the same point, same h-ascending
    per-element accumulation order)."""
    from minitriton.device.cuda import kernels as K
    BM = BK = BN = 64
    a = rn(BM, BK, seed=0)
    b = bf16_round(rn(BK, BN, seed=1))
    ta, tb = tl.tensor(a), tl.tensor(b).astype(tl.bfloat16)
    tc = tl.empty((BM, BN), tl.float32)
    _mma_f32a_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                           tc._buffer_arg(),
                           BM=BM, BK=BK, BN=BN, ATOM="bf16", num_warps=4)
    ref = tl.empty((BM, BN), tl.float32)
    K.launch_matmul_mma(ta, tb, ref, BM, BN, BK, "bf16")
    np.testing.assert_array_equal(tc.numpy().view(np.uint32),
                                  ref.numpy().view(np.uint32))


def test_dsl_mma_tf32_atom():
    """tf32 tl.mma (f32 planes, cvt.rna operands): bit-equal to the
    mma_tile tf32 route."""
    from minitriton.device.cuda import kernels as K
    BM = BK = BN = 64
    a, b = rn(BM, BK, seed=0), rn(BK, BN, seed=1)
    ta, tb = tl.tensor(a), tl.tensor(b)
    tc = tl.empty((BM, BN), tl.float32)
    _mma_f32a_kernel[(1,)](ta._buffer_arg(), tb._buffer_arg(),
                           tc._buffer_arg(),
                           BM=BM, BK=BK, BN=BN, ATOM="tf32", num_warps=4)
    ref = tl.empty((BM, BN), tl.float32)
    K.launch_matmul_mma(ta, tb, ref, BM, BN, BK, "tf32")
    np.testing.assert_array_equal(tc.numpy().view(np.uint32),
                                  ref.numpy().view(np.uint32))


@tl.kernel
def _frag_c_rt_kernel(a_ptr, c_ptr, T,
                      BM: tl.constexpr, BN: tl.constexpr,
                      ATOM: tl.constexpr, MASKED: tl.constexpr):
    """Full-tile fragment-C load -> store round trip."""
    offs_m = tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    a_pt = a_ptr + offs_m[:, None] * BN + offs_n[None, :]
    c_pt = c_ptr + offs_m[:, None] * BN + offs_n[None, :]
    lay = tl.mma_layout("C", (BM, BN), ATOM)
    if MASKED:
        v = tl.load(a_pt, LAYOUT=lay, mask=(offs_m < T)[:, None])
    else:
        v = tl.load(a_pt, LAYOUT=lay)
    tl.store(c_pt, v)


def test_dsl_frag_c_full_load():
    """the store_m4 load-twin: f32 round trip bit-equal; masked rows
    zfill; bf16 plane unpacks to the f32 fragment (exact up-cast)."""
    BM, BN = 64, 64
    a = rn(BM, BN, seed=0)
    ta = tl.tensor(a)
    tc = tl.empty((BM, BN), tl.float32)
    _frag_c_rt_kernel[(1,)](ta._buffer_arg(), tc._buffer_arg(), BM,
                            BM=BM, BN=BN, ATOM="bf16", MASKED=False,
                            num_warps=4)
    np.testing.assert_array_equal(tc.numpy(), a)
    T = 40
    tc2 = tl.empty((BM, BN), tl.float32)
    _frag_c_rt_kernel[(1,)](ta._buffer_arg(), tc2._buffer_arg(), T,
                            BM=BM, BN=BN, ATOM="tf32", MASKED=True,
                            num_warps=4)
    want = a.copy()
    want[T:] = 0.0
    np.testing.assert_array_equal(tc2.numpy(), want)
    ab = bf16_round(a)
    tcb = tl.empty((BM, BN), tl.float32)
    _frag_c_rt_kernel[(1,)](tl.tensor(ab).astype(tl.bfloat16)
                            ._buffer_arg(), tcb._buffer_arg(), BM,
                            BM=BM, BN=BN, ATOM="bf16", MASKED=False,
                            num_warps=4)
    np.testing.assert_array_equal(tcb.numpy(), ab)
