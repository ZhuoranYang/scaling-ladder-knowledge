"""Viz tests: the three render kernels
(particles/heatmap/mesh) against numpy/piecewise-linear references, the
pixel buffer resolve path, the stdlib PNG writer (round-trip without
PIL), and Window frame-mode behavior incl. display-degradation. CUDA
only: render kernels are DSL kernels. No torch.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl
from minitriton import viz
from minitriton.viz import _png


def T(x):
    return tl.tensor(np.ascontiguousarray(x), device="cuda")


# ---------------------------------------------------------------------------
# render kernels
# ---------------------------------------------------------------------------

def test_particles_scatter_and_clip():
    H, W = 64, 96
    buf = viz.PixelBuffer(H, W)
    viz.clear(buf, (0.1, 0.2, 0.3))
    xs = np.array([0.25, 0.5, 1.1, -0.2, 0.99], np.float32)
    ys = np.array([0.25, 0.5, 0.5, 0.5, 0.99], np.float32)
    viz.particles(buf, T(xs), T(ys), color=(1.0, 0.5, 0.0), radius=0)
    u8 = buf.resolve()
    ref = np.full((H, W, 3), [26, 51, 77], np.uint8)
    for x, y in zip(xs, ys):
        c, r = int(x * W), int((1.0 - y) * H)
        if 0 <= r < H and 0 <= c < W:
            ref[r, c] = [255, 128, 0]
    np.testing.assert_array_equal(u8, ref)


def test_particles_radius1_and_y_down():
    buf = viz.PixelBuffer(8, 8)
    viz.clear(buf, (0.0, 0.0, 0.0))
    viz.particles(buf, T(np.array([0.5], np.float32)),
                  T(np.array([0.5], np.float32)), color=(1, 1, 1), radius=1,
                  y_up=False)
    u8 = buf.resolve()
    assert u8[4, 4].tolist() == [255, 255, 255]
    assert (u8[3:6, 3:6] == 255).all()
    assert (u8[3:6, 3:6].reshape(9, 3) == 255).all()
    assert u8[2, 2].tolist() == [0, 0, 0]  # corner outside the 3x3 disc
    assert u8[4, 1].tolist() == [0, 0, 0]


def test_heatmap_against_piecewise_linear_oracle():
    rng = np.random.default_rng(1)
    f_np = rng.standard_normal((24, 40)).astype(np.float32)
    buf = viz.PixelBuffer(48, 80)
    viz.heatmap(buf, T(f_np), cmap="viridis", vmin=-2.0, vmax=2.0)
    u8 = buf.resolve()
    # nearest upsampling + the shared 8-stop oracle
    samp = f_np[np.arange(48) * 24 // 48][:, np.arange(80) * 40 // 80]
    ref = np.round(viz.lookup("viridis", (samp + 2.0) / 4.0) * 255)
    ref = ref.astype(np.uint8)
    np.testing.assert_array_equal(u8, ref)


def test_heatmap_clamps_out_of_range():
    f = np.zeros((4, 4), np.float32)
    f[0, 0] = -10.0
    f[3, 3] = 10.0
    buf = viz.PixelBuffer(4, 4)
    viz.heatmap(buf, T(f), cmap="gray", vmin=0.0, vmax=1.0)
    u8 = buf.resolve()
    assert u8[0, 0].tolist() == [0, 0, 0]
    assert u8[3, 3].tolist() == [255, 255, 255]


def test_mesh_endpoints_and_midpoint():
    buf = viz.PixelBuffer(64, 64)
    viz.clear(buf, (0, 0, 0))
    verts = T(np.array([[0.5, 0.5], [0.75, 0.5]], np.float32))
    edges = T(np.array([[0, 1]], np.int32))
    viz.mesh(buf, verts, edges, vcolor=(0.9, 0.9, 0.9),
             ecolor=(0.3, 0.6, 1.0))
    u8 = buf.resolve().astype(int)
    vc = int(np.round(float(np.float32(0.9)) * 255.0))
    assert u8[32, 32].tolist() == [vc] * 3
    assert u8[32, 48].tolist() == [vc] * 3
    np.testing.assert_array_equal(
        u8[32, 40].astype(np.uint8),
        np.round(np.array([0.3, 0.6, 1.0], np.float32).astype(np.float64)
                 * 255).astype(np.uint8))


def test_mesh_shared_vertex_and_clipping():
    # a chain of three edges shares vertices; out-of-frame verts clip
    buf = viz.PixelBuffer(64, 64)
    viz.clear(buf, (0, 0, 0))
    verts = T(np.array([[0.25, 0.5], [0.5, 0.5], [0.75, 0.5], [1.5, 0.5]],
                       np.float32))
    edges = T(np.array([[0, 1], [1, 2], [2, 3]], np.int32))
    viz.mesh(buf, verts, edges)
    u8 = buf.resolve().astype(int)
    vc = int(np.round(float(np.float32(0.9)) * 255.0))
    for col in (16, 32, 48):
        assert u8[32, col].tolist() == [vc] * 3
    assert u8[32, 24].tolist() != [0, 0, 0]  # midpoint of edge 0
    assert u8[32, 40].tolist() != [0, 0, 0]  # midpoint of edge 1
    assert not (u8 == [255, 255, 255]).all(-1).any()


# ---------------------------------------------------------------------------
# pixel buffer + png
# ---------------------------------------------------------------------------

def test_resolve_clamps_to_uint8():
    buf = viz.PixelBuffer(2, 2)
    viz.clear(buf, (2.0, -1.0, 0.5))
    u8 = buf.resolve()
    assert u8.dtype == np.uint8
    assert u8[0, 0].tolist() == [255, 0, 128]


def test_png_roundtrip(tmp_path):
    rng = np.random.default_rng(2)
    img = rng.integers(0, 256, (17, 9, 3), dtype=np.uint8)
    p = tmp_path / "x.png"
    _png.write_png(str(p), img)
    back = _png.decode_png4test(str(p))
    np.testing.assert_array_equal(back, img)


# ---------------------------------------------------------------------------
# window (headless frame mode + degradation)
# ---------------------------------------------------------------------------

def test_window_frame_mode(tmp_path):
    win = viz.Window(8, 8, frames_dir=tmp_path, save_every=1, max_frames=3)
    buf = viz.PixelBuffer(8, 8)
    viz.clear(buf, (0.2, 0.4, 0.6))
    acts = [win.show(buf) for _ in range(5)]
    assert acts == ["continue", "continue", "continue", "quit", "quit"]
    assert win.mode == "frames"
    assert (tmp_path / "frame_00000.png").exists()
    back = _png.decode_png4test(str(tmp_path / "frame_00000.png"))
    assert back[0, 0].tolist() == [51, 102, 153]


def test_window_display_degrades_to_frames(monkeypatch, tmp_path):
    def boom(W, H, t):
        raise RuntimeError("no video mode large enough")
    monkeypatch.setattr(viz, "_try_display", boom)
    with pytest.warns(UserWarning, match="display unavailable"):
        win = viz.Window(8, 8, frames_dir=tmp_path, display=True)
    assert win.mode == "frames"
    buf = viz.PixelBuffer(8, 8)
    assert win.show(buf) == "continue"
    assert list(tmp_path.glob("frame_*.png"))
