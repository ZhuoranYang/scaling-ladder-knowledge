"""solve_tril (warp-level triangular inverse primitive) vs numpy references.

Ai = (I + A)^-1 per BTxBT strictly-lower-triangular block, for
A of shape [B, T, H, BT] (dense) or [1, T_total, H, BT] with
cu_seqlens/chunk_indices (varlen). Inputs are built the same way fla's
test-suite does (normalized K @ K^T, tril(-1)) so the inverse is stable.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl


@tl.kernel
def solve_tril_dense_kernel(a_ptr, ai_ptr, T, H, BT: tl.constexpr):
    pid_t = tl.program_id(0)
    pid_bh = tl.program_id(1)
    tl.solve_tril(a_ptr, ai_ptr, pid_t, pid_bh, T, H, BT=BT)


@tl.kernel
def solve_tril_varlen_kernel(a_ptr, ai_ptr, cu_ptr, ci_ptr, T, H,
                             BT: tl.constexpr):
    pid_t = tl.program_id(0)
    pid_bh = tl.program_id(1)
    tl.solve_tril(a_ptr, ai_ptr, pid_t, pid_bh, T, H, BT=BT,
                  cu_seqlens=cu_ptr, chunk_indices=ci_ptr)


@tl.kernel
def solve_tril_wir_dense_kernel(a_ptr, ai_ptr, T, H, BT: tl.constexpr):
    pid_t = tl.program_id(0)
    pid_bh = tl.program_id(1)
    tl._wir_solve_tril(a_ptr, ai_ptr, pid_t, pid_bh, T, H, BT=BT)


@tl.kernel
def solve_tril_wir_varlen_kernel(a_ptr, ai_ptr, cu_ptr, ci_ptr, T, H,
                                 BT: tl.constexpr):
    pid_t = tl.program_id(0)
    pid_bh = tl.program_id(1)
    tl._wir_solve_tril(a_ptr, ai_ptr, pid_t, pid_bh, T, H, BT=BT,
                       cu_seqlens=cu_ptr, chunk_indices=ci_ptr)


def gen_input(B, T, H, BT, seed=0):
    rng = np.random.default_rng(seed)
    k = rng.standard_normal((B, H, T, 64)).astype(np.float32)
    k /= np.linalg.norm(k, axis=-1, keepdims=True)
    pad = (BT - T % BT) % BT
    k = np.pad(k, ((0, 0), (0, 0), (0, pad), (0, 0)))
    k = k.reshape(B, H, -1, BT, 64)
    A = np.matmul(k, k.transpose(0, 1, 2, 4, 3))
    A = np.tril(A, -1)
    return np.ascontiguousarray(
        A.reshape(B, H, -1, BT)[:, :, :T, :].transpose(0, 2, 1, 3))


def oracle_inv(A):
    """fp64 inverse per BT block. A: [B, T, H, BT] -> same shape."""
    B, T, H, BT = A.shape
    NT = (T + BT - 1) // BT
    pad = NT * BT - T
    Ap = np.pad(A.astype(np.float64), ((0, 0), (0, pad), (0, 0), (0, 0)))
    Ap = Ap.reshape(B, NT, BT, H, BT).transpose(0, 1, 3, 2, 4)  # [B,NT,H,BT,BT]
    X = np.linalg.inv(Ap + np.eye(BT))
    X = X.transpose(0, 1, 3, 2, 4)  # back to [B,NT,BT,H,BT]
    return np.ascontiguousarray(X.reshape(B, NT * BT, H, BT)[:, :T])


def run_dense(B, T, H, BT, kernel=solve_tril_dense_kernel):
    A = gen_input(B, T, H, BT)
    a_buf = tl.Buffer.from_numpy(A)
    ai_buf = tl.Buffer(A.size, tl.float32)
    NT = (T + BT - 1) // BT
    kernel[(NT, B * H)](a_buf, ai_buf, T, H, BT=BT)
    tl.synchronize()
    return ai_buf.to_numpy().reshape(A.shape), oracle_inv(A)


def chunk_indices_np(cu_list, BT):
    out = []
    for i in range(len(cu_list) - 1):
        L = cu_list[i + 1] - cu_list[i]
        for t in range((L + BT - 1) // BT):
            out.append((i, t))
    return np.array(out, dtype=np.int64).reshape(-1)


def run_varlen(cu_list, H, BT, kernel=solve_tril_varlen_kernel):
    seqs = [gen_input(1, cu_list[i + 1] - cu_list[i], H, BT, seed=i)
            for i in range(len(cu_list) - 1)]
    A = np.concatenate(seqs, axis=1)
    ref = np.concatenate([oracle_inv(s) for s in seqs], axis=1)
    a_buf = tl.Buffer.from_numpy(A)
    ai_buf = tl.Buffer(A.size, tl.float32)
    ci = chunk_indices_np(cu_list, BT)
    cu_buf = tl.Buffer.from_numpy(np.array(cu_list, dtype=np.int32))
    ci_buf = tl.Buffer.from_numpy(ci)
    T = A.shape[1]
    kernel[(len(ci) // 2, H)](a_buf, ai_buf, cu_buf, ci_buf, T, H, BT=BT)
    tl.synchronize()
    return ai_buf.to_numpy().reshape(A.shape), ref


@pytest.mark.parametrize("B,T,H,BT", [
    (1, 63, 1, 16),     # BT=16, ragged last chunk
    (2, 500, 4, 32),    # BT=32
    (2, 1000, 5, 64),   # BT=64
    (3, 1024, 6, 64),
    (4, 2048, 8, 64),
])
def test_solve_tril_dense(B, T, H, BT):
    out, ref = run_dense(B, T, H, BT)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-5)


@pytest.mark.parametrize("cu_list,BT", [
    ([0, 15], 16),
    ([0, 256, 500, 1000], 32),
    ([0, 15, 100, 300, 1200, 2000], 64),
    ([0, 1, 100, 300, 1200, 2048], 16),
    ([0, 200, 512, 1200, 2048], 32),
])
def test_solve_tril_varlen(cu_list, BT):
    out, ref = run_varlen(cu_list, 4, BT)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-5)


# --- naive W-IR formulation: same math driven through
# the generic P1/P2 passes instead of the hand-written schedule -------------

_DENSE = [(1, 63, 1, 16), (2, 500, 4, 32), (2, 1000, 5, 64),
          (3, 1024, 6, 64), (4, 2048, 8, 64)]


@pytest.mark.parametrize("B,T,H,BT", _DENSE)
def test_solve_tril_wir_dense(B, T, H, BT):
    out, ref = run_dense(B, T, H, BT, kernel=solve_tril_wir_dense_kernel)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-5)


@pytest.mark.parametrize("cu_list,BT", [
    ([0, 15], 16),
    ([0, 256, 500, 1000], 32),
    ([0, 15, 100, 300, 1200, 2000], 64),
    ([0, 1, 100, 300, 1200, 2048], 16),
    ([0, 200, 512, 1200, 2048], 32),
])
def test_solve_tril_wir_varlen(cu_list, BT):
    out, ref = run_varlen(cu_list, 4, BT, kernel=solve_tril_wir_varlen_kernel)
    np.testing.assert_allclose(out, ref, rtol=1e-5, atol=1e-5)


def test_solve_tril_wir_passes_engaged(tmp_path):
    """The pass pipeline must distribute every parallel loop and place a
    bounded sync set (regression guard against silent pass bail-outs)."""
    from minitriton.compiler import passes
    from minitriton.runtime.cache import get_cache

    @tl.kernel
    def probe16(a_ptr, ai_ptr, T, H, BT: tl.constexpr):
        tl._wir_solve_tril(a_ptr, ai_ptr, tl.program_id(0),
                           tl.program_id(1), T, H, BT=16)

    @tl.kernel
    def probe64(a_ptr, ai_ptr, T, H, BT: tl.constexpr):
        tl._wir_solve_tril(a_ptr, ai_ptr, tl.program_id(0),
                           tl.program_id(1), T, H, BT=64)

    cache = get_cache()
    old_root = cache.root
    cache.root = tmp_path
    cache._mem.clear()
    try:
        A = gen_input(1, 63, 1, 16)
        probe16[(4, 1)](tl.Buffer.from_numpy(A), tl.Buffer(A.size, tl.float32),
                        63, 1, BT=16)
        A = gen_input(1, 200, 1, 64)
        probe64[(4, 1)](tl.Buffer.from_numpy(A), tl.Buffer(A.size, tl.float32),
                        200, 1, BT=64)
    finally:
        cache.root = old_root
        cache._mem.clear()
    st = {s["func"]: s for s in passes.stats()
          if s["func"] in ("probe16", "probe64")}
    assert set(st) == {"probe16", "probe64"}
    # phase-1 + per-distance loops all distributed (BT: 1 + (NB-1) loops)
    assert st["probe16"]["p1_distributed"] == 1
    assert st["probe64"]["p1_distributed"] == 4
    # no bail-outs, and inner syncs stay warp-scoped (never grid-wide)
    for s in st.values():
        assert s["p1_bail_dep"] == 0 and s["p1_bail_opaque"] == 0
        assert s["p2_inner_warp"] == 0
