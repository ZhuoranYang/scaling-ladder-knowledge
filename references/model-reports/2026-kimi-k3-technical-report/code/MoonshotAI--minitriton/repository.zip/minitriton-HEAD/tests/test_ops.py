"""Eager op test matrix: every op x {cpu, cuda} x shapes,
checked against numpy references (no torch in tests/).

Tolerances: fp32 rtol ~1e-5 (1e-4 for transcendentals composed from
ex2/lg2 approx PTX), fp16 rtol 1e-3, matmul err/sqrt(K) < 1e-4.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

import minitriton as tl

DEVS = pytest.mark.parametrize("dev", ["cpu", "cuda"])


def T(x, dev):
    return tl.tensor(np.ascontiguousarray(x), device=dev)


def close(out, ref, rtol=1e-5, atol=1e-6):
    arr = out.numpy() if isinstance(out, tl.Tensor) else out
    ref = np.asarray(ref)
    assert arr.shape == ref.shape, f"shape {arr.shape} != ref {ref.shape}"
    np.testing.assert_allclose(arr, ref, rtol=rtol, atol=atol)


def mm_close(out, ref, K):
    arr = out.numpy()
    err = float(np.max(np.abs(arr - ref)) / np.sqrt(max(K, 1)))
    assert err < 1e-4, f"matmul err/sqrt(K) = {err}"


rng = np.random.default_rng(0)


def rn(*shape):
    return rng.standard_normal(shape).astype(np.float32)


# ---------------------------------------------------------------------------
# creation / object model
# ---------------------------------------------------------------------------

@DEVS
def test_zeros_ones_empty(dev):
    close(tl.zeros((3, 4), device=dev), np.zeros((3, 4), np.float32))
    close(tl.ones((2, 5), device=dev), np.ones((2, 5), np.float32))
    close(tl.ones((3,), dtype=tl.int32, device=dev), np.ones((3,), np.int32))
    close(tl.zeros((2, 2), dtype=tl.float16, device=dev),
          np.zeros((2, 2), np.float16))
    close(tl.ones((4,), dtype=tl.int64, device=dev), np.ones((4,), np.int64))
    # f16/bf16 ones: the memset32 pattern must cover BOTH halves of each
    # 32-bit word (regression: 0x00003C00 zeroing every other element)
    close(tl.ones((4,), dtype=tl.float16, device=dev),
          np.ones((4,), np.float16))
    if dev != "cpu":  # bf16 has no numpy dtype on the cpu oracle
        close(tl.ones((4,), dtype=tl.bfloat16, device=dev).astype(tl.float32),
              np.ones((4,), np.float32))
        close(tl.ones((5,), dtype=tl.bfloat16, device=dev).astype(tl.float32),
              np.ones((5,), np.float32))
    e = tl.empty((7, 3), device=dev)
    assert e.shape == (7, 3) and e.dtype == tl.float32 and e.device == dev
    assert e.numel() == 21 and e.ndim == 2


@DEVS
def test_arange_randn(dev):
    close(tl.arange(10, device=dev), np.arange(10, dtype=np.int64))
    close(tl.arange(2, 9, 2, device=dev), np.arange(2, 9, 2, dtype=np.int64))
    close(tl.arange(0, 1, 0.25, device=dev),
          np.arange(0, 1, 0.25, dtype=np.float32))
    r = tl.randn(64, 32, device=dev, seed=7)
    ref = np.random.default_rng(7).standard_normal((64, 32)).astype(np.float32)
    close(r, ref, rtol=1e-6, atol=1e-7)


@DEVS
def test_from_numpy_dtypes(dev):
    for npt, tdt in [(np.float32, tl.float32), (np.float16, tl.float16),
                     (np.int32, tl.int32), (np.int64, tl.int64)]:
        x = np.zeros((2, 3), dtype=npt)
        t = tl.from_numpy(x, device=dev)
        assert t.dtype == tdt
        assert t.numpy().dtype == npt


@DEVS
def test_to_and_item(dev):
    x = rn(4, 4)
    t = T(x, dev)
    other = "cuda" if dev == "cpu" else "cpu"
    u = t.to(other)
    assert u.device == other
    close(u, x)
    close(u.to(dev), x)
    s = T(np.float32(3.25), dev)
    assert abs(s.item() - 3.25) < 1e-6
    assert float(s) == pytest.approx(3.25)
    assert T(np.int32(5), dev).item() == 5
    t16 = T(x, dev).astype(tl.float16)
    assert t16.dtype == tl.float16
    close(t16, x.astype(np.float16), rtol=1e-3, atol=1e-3)
    close(t16.astype(tl.float32), x.astype(np.float16).astype(np.float32),
          rtol=1e-3, atol=1e-3)
    if dev == "cuda":
        # bf16: host roundtrip goes through f32
        tb = T(x, dev).astype(tl.bfloat16)
        assert tb.dtype == tl.bfloat16
        close(tb.astype(tl.float32), x, rtol=1e-2, atol=1e-2)


@DEVS
def test_astype(dev):
    x = rn(5, 7)
    close(T(x, dev).astype(tl.int32), x.astype(np.int32))
    xi = (x * 100).astype(np.int32)
    close(T(xi, dev).astype(tl.float32), xi.astype(np.float32))
    xi64 = xi.astype(np.int64)
    close(T(xi64, dev).astype(tl.int32), xi64.astype(np.int32))


# ---------------------------------------------------------------------------
# views / movement
# ---------------------------------------------------------------------------

@DEVS
def test_reshape_view(dev):
    x = rn(6, 8)
    t = T(x, dev)
    close(t.reshape(4, 12), x.reshape(4, 12))
    close(t.reshape(-1), x.reshape(-1))
    close(t.reshape(2, -1), x.reshape(2, -1))
    close(t.t().reshape(-1), x.T.reshape(-1))  # copy path
    close(t.view(3, 16), x.reshape(3, 16))
    with pytest.raises(RuntimeError):
        t.t().view(-1)  # incompatible: must raise


@DEVS
def test_permute_transpose(dev):
    x = rn(2, 3, 4)
    t = T(x, dev)
    close(t.permute(2, 0, 1).contiguous(), np.transpose(x, (2, 0, 1)))
    close(t.transpose(0, 2).contiguous(), np.transpose(x, (2, 1, 0)))
    y = rn(4, 5)
    close(T(y, dev).t().contiguous(), y.T)
    assert t.permute(2, 0, 1).shape == (4, 2, 3)
    assert t.permute(2, 0, 1).is_contiguous() is False
    # unsqueeze / squeeze
    close(t.unsqueeze(1), np.expand_dims(x, 1))
    close(t.unsqueeze(-1), np.expand_dims(x, -1))
    close(t.unsqueeze(1).squeeze(1), x)
    xs = rn(1, 5, 1)
    close(T(xs, dev).squeeze(), np.squeeze(xs))
    close(T(xs, dev).squeeze(0), np.squeeze(xs, axis=0))


@DEVS
def test_getitem(dev):
    x = rn(10, 12)
    t = T(x, dev)
    close(t[3], x[3])
    close(t[-2], x[-2])
    close(t[2:8], x[2:8])
    close(t[2:8:2], x[2:8:2])
    close(t[::-1], x[::-1])
    close(t[:, 3:9:2], x[:, 3:9:2])
    close(t[1:9:3, ::-1], x[1:9:3, ::-1])
    close(t[2, 3:6], x[2, 3:6])
    close(t[...], x[...])
    close(t[4:, ...], x[4:, ...])
    x3 = rn(3, 4, 5)
    t3 = T(x3, dev)
    close(t3[1], x3[1])
    close(t3[:, 2], x3[:, 2])
    close(t3[::2, 1:3, -1], x3[::2, 1:3, -1])


@DEVS
def test_broadcast_to_expand(dev):
    x = rn(3, 1)
    t = T(x, dev)
    close(t.broadcast_to((3, 5)), np.broadcast_to(x, (3, 5)))
    close(t.expand(3, 5), np.broadcast_to(x, (3, 5)))
    b = T(rn(4), dev)
    close(b.broadcast_to((2, 3, 4)), np.broadcast_to(b.numpy(), (2, 3, 4)))
    with pytest.raises(RuntimeError):
        T(rn(3, 2), dev).broadcast_to((3, 4))  # 2 -> 4 is illegal


@DEVS
def test_cat_split(dev):
    x, y, z = rn(4, 6), rn(2, 6), rn(4, 3)
    close(tl.cat([T(x, dev), T(y, dev)], dim=0), np.concatenate([x, y], 0))
    close(tl.cat([T(x, dev), T(z, dev), T(x, dev)], dim=1),
          np.concatenate([x, z, x], 1))
    close(tl.cat([T(x, dev), T(z, dev)], dim=-1), np.concatenate([x, z], -1))
    xi, yi = (x * 10).astype(np.int32), (y * 10).astype(np.int32)
    close(tl.cat([T(xi, dev), T(yi, dev)]), np.concatenate([xi, yi], 0))
    a = T(rn(4, 10), dev)
    s = tl.split(a, 3, dim=1)
    ref = np.split(a.numpy(), [3, 6, 9], axis=1)
    assert len(s) == 4
    for o, r in zip(s, ref):
        close(o, r)
    s2 = tl.split(a, [1, 4, 5], dim=1)
    for o, r in zip(s2, np.split(a.numpy(), [1, 5], axis=1)):
        close(o, r)


@DEVS
def test_cat_mismatched_non_concat_dims_raise(dev):
    # the CUDA backend used to write the second tensor's rows into the
    # first one's width silently (numpy raises) — the op entry now
    # rejects mismatched non-concat dims on both backends
    a, b = T(rn(2, 3), dev), T(rn(2, 4), dev)
    with pytest.raises(RuntimeError, match="cat"):
        tl.cat([a, b], dim=0)
    c = T(rn(2, 3, 2), dev)
    with pytest.raises(RuntimeError, match="cat"):
        tl.cat([a, c], dim=0)          # ndim mismatch
    d = T(rn(3, 3), dev)
    with pytest.raises(RuntimeError, match="cat"):
        tl.cat([a, d], dim=1)          # rows differ on a dim=1 cat


# ---------------------------------------------------------------------------
# elementwise binary
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("op,npop", [
    ("add", np.add), ("sub", np.subtract), ("mul", np.multiply),
    ("div", np.divide),
])
@pytest.mark.parametrize("shapes", [
    ((64, 96), (64, 96)),      # flat
    ((100003,), (100003,)),    # odd length
    ((64, 96), (96,)),         # row broadcast
    ((64, 96), (1, 96)),
    ((64, 96), (64, 1)),       # col broadcast
    ((2, 3, 4), (3, 1)),       # 3D broadcast
    ((2, 3, 4), (4,)),
    ((1, 5), (7, 1)),          # both broadcast
])
def test_binary_shapes(dev, op, npop, shapes):
    x, y = rn(*shapes[0]), np.abs(rn(*shapes[1])) + 0.5
    out = getattr(tl, op)(T(x, dev), T(y, dev))
    close(out, npop(x, y), rtol=1e-4, atol=1e-5)


@DEVS
def test_binary_scalar(dev):
    x = rn(32, 48)
    close(T(x, dev) + 2.5, x + 2.5)
    close(2.5 + T(x, dev), 2.5 + x)
    close(T(x, dev) - 1.5, x - 1.5)
    close(1.0 - T(x, dev), 1.0 - x)
    close(T(x, dev) * 3, x * 3)
    close(4 * T(x, dev), 4 * x)
    close(T(x, dev) / 2.0, x / 2.0)
    close(6.0 / T(x, dev), 6.0 / x, rtol=1e-4, atol=1e-5)


@DEVS
def test_binary_noncontig(dev):
    x, y = rn(48, 64), rn(48, 64)
    close(T(x, dev).t() + T(y, dev).t(), x.T + y.T)
    close(T(x, dev)[::2] * T(y, dev)[::2], x[::2] * y[::2])
    close(T(x, dev)[::-1] + 1.0, x[::-1] + 1.0)
    x3, y3 = rn(4, 8, 16), rn(16,)
    close(T(x3, dev) + T(y3, dev), x3 + y3)
    close(T(x3, dev)[:, :, ::2] + T(y3, dev)[::2], x3[:, :, ::2] + y3[::2])


@DEVS
def test_misaligned_view_elementwise(dev):
    """Views whose byte offset is not 16B-aligned must take the scalar
    paths (regression: the flat/vec-mode kernels fault with a misaligned
    address — the in-kernel index check can't see offsets)."""
    base = rn(64 * 64 + 1)
    v = base[1:].reshape(64, 64)          # contiguous, offset 1 elem (4B)
    ref = v.reshape(64, 64)
    tv = T(base, dev)[1:].reshape(64, 64)
    close(tv + 1.0, ref + 1.0)            # binary_scalar flat guard
    close(tv * tv, ref * ref)             # binary flat guard
    close(tv + tv, ref + ref)
    # non-contiguous with misaligned base: operand_spec must downgrade
    x = rn(48, 65)[:, 1:]
    close(T(x, dev) * 2.0, x * 2.0)
    close(T(x, dev) + T(x, dev), x + x)
    if dev == "cuda":  # cpu backend has no bf16 numpy dtype
        close(tv.astype(tl.bfloat16).astype(tl.float32),
              ref.astype(np.float32), rtol=2e-2, atol=1e-5)
        close(T(x, dev).astype(tl.bfloat16).astype(tl.float32), x,
              rtol=2e-2, atol=1e-5)


@DEVS
def test_binary_int(dev):
    x = rng.integers(-50, 50, (33, 17)).astype(np.int32)
    y = rng.integers(-50, 50, (33, 17)).astype(np.int32)
    close(T(x, dev) + T(y, dev), x + y)
    close(T(x, dev) - T(y, dev), x - y)
    close(T(x, dev) * T(y, dev), x * y)
    close(T(x, dev) + 7, x + 7)
    with np.errstate(divide="ignore", invalid="ignore"):
        ref = x / y
    out = T(x, dev) / T(y, dev)  # int true division -> f32
    np.testing.assert_allclose(out.numpy(), ref, rtol=1e-5, atol=1e-6)
    x64 = x.astype(np.int64)
    close(T(x64, dev) + T(y, dev), x64 + y)  # i64 + i32 -> i64
    close(T(x64, dev) + 5, x64 + 5)


@DEVS
def test_binary_f16(dev):
    x, y = rn(32, 64).astype(np.float16), rn(32, 64).astype(np.float16)
    close(T(x, dev) + T(y, dev), x + y, rtol=1e-3, atol=1e-3)
    close(T(x, dev) * T(y, dev), x * y, rtol=1e-3, atol=1e-3)
    close(T(x, dev) + 1.5, x + np.float16(1.5), rtol=1e-3, atol=1e-3)


@DEVS
def test_dtype_promotion(dev):
    xf, xh = rn(4, 4), rn(4, 4).astype(np.float16)
    out = T(xf, dev) + T(xh, dev)
    assert out.dtype == tl.float32
    close(out, xf + xh, rtol=1e-3, atol=1e-4)
    xi = rng.integers(0, 10, (4, 4)).astype(np.int32)
    out = T(xf, dev) + T(xi, dev)
    assert out.dtype == tl.float32
    out = T(xh, dev) + 2
    assert out.dtype == tl.float16  # int scalar keeps f16
    out = T(xi, dev) + 1.5
    assert out.dtype == tl.float32  # float scalar lifts int tensor
    if dev == "cuda":
        xb = T(xf, dev).astype(tl.bfloat16)
        out = xb + T(xh, dev)
        assert out.dtype == tl.float32  # bf16 + f16 -> f32


def _bf16_round(x: np.ndarray) -> np.ndarray:
    """bf16 round-to-nearest-even of an f32 array, emulated on the host
    (bf16 has no numpy dtype)."""
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    lsb = (b >> np.uint32(16)) & np.uint32(1)
    b = b + np.uint32(0x7FFF) + lsb
    return (b & np.uint32(0xFFFF0000)).view(np.float32)


@DEVS
def test_binary_mixed_dtype_flat(dev):
    """Same-shape contiguous mixed-dtype binary: the flat kernel casts
    each load to the compute dtype."""
    if dev != "cuda":
        pytest.skip("mixed-dtype flat path is CUDA-specific "
                    "(same numerics via numpy on cpu)")
    f32, bf16, f16 = tl.float32, tl.bfloat16, tl.float16
    xf, yf = rn(33, 65), np.abs(rn(33, 65)) + 0.5
    cases = [
        # (a_dtype, b_dtype, out_dtype, np reference of {op})
        (f32, bf16, f32, lambda a, b: (a + _bf16_round(b),
                                       a - _bf16_round(b),
                                       a * _bf16_round(b))),
        (bf16, f32, f32, lambda a, b: (_bf16_round(a) + b,
                                       _bf16_round(a) - b,
                                       _bf16_round(a) * b)),
        (f16, f32, f32, lambda a, b: (a.astype(np.float16).astype(np.float32)
                                      + b,
                                      a.astype(np.float16).astype(np.float32)
                                      - b,
                                      a.astype(np.float16).astype(np.float32)
                                      * b)),
        (bf16, f16, f32, lambda a, b: (
            _bf16_round(a) + b.astype(np.float16).astype(np.float32),
            _bf16_round(a) - b.astype(np.float16).astype(np.float32),
            _bf16_round(a) * b.astype(np.float16).astype(np.float32))),
    ]
    for da, db, dout, mkref in cases:
        a = T(xf, dev).astype(da)
        b = T(yf, dev).astype(db)
        refs = mkref(xf, yf)
        for out, ref in zip((tl.add(a, b), tl.sub(a, b), tl.mul(a, b)),
                            refs):
            assert out.dtype == dout, (da.name, db.name, out.dtype)
            # bf16 rounding of the low-precision operand, f32 arithmetic
            np.testing.assert_allclose(out.numpy(), ref, rtol=1e-5,
                                       atol=1e-5)
    # bf16 x bf16 -> bf16 computes in bf16: emulate RN of the rounded
    # operands/products (tolerance bf16 2e-2, values O(4))
    a = T(xf, dev).astype(bf16)
    b = T(yf, dev).astype(bf16)
    ra, rb = _bf16_round(xf), _bf16_round(yf)
    for out, ref in ((tl.add(a, b), _bf16_round(ra + rb)),
                     (tl.mul(a, b), _bf16_round(ra * rb))):
        assert out.dtype == bf16
        np.testing.assert_allclose(out.numpy(), ref, rtol=2e-2, atol=1e-3)
    # mixed ints / int+float take the same flat path
    xi = rng.integers(-50, 50, (33, 65)).astype(np.int32)
    x64 = xi.astype(np.int64)
    out = T(x64, dev) + T(xi, dev)
    assert out.dtype == tl.int64
    close(out, x64 + xi)
    out = T(xf, dev) + T(xi, dev)
    assert out.dtype == tl.float32
    close(out, xf + xi, rtol=1e-4, atol=1e-4)


# ---------------------------------------------------------------------------
# elementwise unary
# ---------------------------------------------------------------------------

def _gelu_ref(x):
    """gelu oracle: erf-exact (default) or tanh (MT_GELU_TANH=1)."""
    from minitriton import precision as _prec
    if _prec.gelu_erf():
        import math
        return 0.5 * x * (1 + np.vectorize(math.erf)(
            x * 0.7071067811865476))
    return 0.5 * x * (1 + np.tanh(0.7978845608028654
                                  * (x + 0.044715 * x**3)))


@DEVS
@pytest.mark.parametrize("op,npop", [
    ("neg", np.negative),
    ("abs", np.abs),
    ("exp", np.exp),
    ("log", np.log),
    ("sqrt", np.sqrt),
    ("tanh", np.tanh),
    ("sigmoid", lambda x: 1 / (1 + np.exp(-x))),
    ("relu", lambda x: np.maximum(x, 0)),
    ("gelu", _gelu_ref),
    ("silu", lambda x: x / (1 + np.exp(-x))),
])
@pytest.mark.parametrize("n", [(64, 96), (99991,)])
def test_unary(dev, op, npop, n):
    x = np.abs(rn(*n)) + 0.1 if op in ("log", "sqrt") else rn(*n)
    close(getattr(tl, op)(T(x, dev)), npop(x), rtol=1e-4, atol=1e-5)


@DEVS
def test_unary_int(dev):
    x = rng.integers(-50, 50, (64, 32)).astype(np.int32)
    close(tl.neg(T(x, dev)), -x)
    close(tl.abs(T(x, dev)), np.abs(x))
    close(tl.relu(T(x, dev)), np.maximum(x, 0))
    out = tl.exp(T(x, dev))
    assert out.dtype == tl.float32  # math op on ints lifts to f32


@DEVS
def test_unary_f16(dev):
    x = rn(64, 32).astype(np.float16)
    close(tl.exp(T(x, dev)), np.exp(x), rtol=1e-3, atol=1e-3)
    close(tl.sigmoid(T(x, dev)), 1 / (1 + np.exp(-x)), rtol=1e-3, atol=1e-3)


@DEVS
def test_unary_noncontig(dev):
    x = rn(64, 96)
    close(tl.exp(T(x, dev).t()), np.exp(x.T), rtol=1e-4, atol=1e-5)
    close(tl.sqrt(T(x, dev)[::2] ** 2), np.sqrt((x[::2]) ** 2),
          rtol=1e-4, atol=1e-5)


# ---------------------------------------------------------------------------
# fused elementwise / fused row ops (case-fusions)
# ---------------------------------------------------------------------------

def _swiglu_ref(a, b):
    return a / (1 + np.exp(-a)) * b


@DEVS
@pytest.mark.parametrize("n", [(64, 96), (99991,), (100003,)])
def test_swiglu(dev, n):
    a, b = rn(*n), rn(*n)
    close(tl.swiglu(T(a, dev), T(b, dev)), _swiglu_ref(a, b),
          rtol=1e-4, atol=1e-5)


@DEVS
@pytest.mark.parametrize("sa,sb", [((4, 3), (3,)), ((4, 3), (4, 1)),
                                   ((2, 3, 4), (3, 4)), ((4, 3), ())])
def test_swiglu_broadcast(dev, sa, sb):
    a, b = rn(*sa), rn(*sb)
    close(tl.swiglu(T(a, dev), T(b, dev)), _swiglu_ref(a, b),
          rtol=1e-4, atol=1e-5)


@DEVS
def test_swiglu_noncontig(dev):
    a = rn(64, 96)
    b = rn(96, 64)
    close(tl.swiglu(T(a, dev).t(), T(b, dev)), _swiglu_ref(a.T, b),
          rtol=1e-4, atol=1e-5)
    c = rn(8, 12)
    d = rn(8, 6)
    close(tl.swiglu(T(c, dev)[:, ::2], T(d, dev)), _swiglu_ref(c[:, ::2], d),
          rtol=1e-4, atol=1e-5)


@DEVS
def test_swiglu_f16(dev):
    a = rn(64, 32).astype(np.float16)
    b = rn(64, 32).astype(np.float16)
    close(tl.swiglu(T(a, dev), T(b, dev)), _swiglu_ref(a, b),
          rtol=1e-2, atol=1e-3)


def _add_ln_ref(x, r, w=None, b=None, eps=1e-5):
    s = x + r
    y = (s - s.mean(-1, keepdims=True)) / np.sqrt(s.var(-1, keepdims=True)
                                                  + eps)
    if w is not None:
        y = y * w
    if b is not None:
        y = y + b
    return y, s


@DEVS
def test_add_layernorm(dev):
    x, r = rn(32, 96), rn(32, 96)
    w, b = rn(96), rn(96)
    ref, _ = _add_ln_ref(x, r, w, b)
    close(tl.add_layernorm(T(x, dev), T(r, dev), (96,), T(w, dev),
                           T(b, dev)), ref, rtol=1e-4, atol=1e-5)
    ref2, _ = _add_ln_ref(x, r)
    close(tl.add_layernorm(T(x, dev), T(r, dev), (96,)), ref2,
          rtol=1e-4, atol=1e-5)
    close(tl.add_layernorm(T(x, dev), T(r, dev), (96,), T(w, dev)),
          ref2 * w, rtol=1e-4, atol=1e-5)
    # 3D input, normalized over the last dim
    x3, r3 = rn(4, 8, 24), rn(4, 8, 24)
    w3 = rn(24)
    ref3, _ = _add_ln_ref(x3, r3, w3)
    close(tl.add_layernorm(T(x3, dev), T(r3, dev), (24,), T(w3, dev)), ref3,
          rtol=1e-4, atol=1e-5)
    # odd row length
    xo, ro = rn(64, 1000), rn(64, 1000)
    refo, _ = _add_ln_ref(xo, ro)
    close(tl.add_layernorm(T(xo, dev), T(ro, dev), (1000,)), refo,
          rtol=1e-4, atol=1e-5)


@DEVS
def test_add_layernorm_return_residual(dev):
    x, r = rn(7, 96), rn(7, 96)
    w, b = rn(96), rn(96)
    ref, s = _add_ln_ref(x, r, w, b)
    y, rs = tl.add_layernorm(T(x, dev), T(r, dev), (96,), T(w, dev),
                             T(b, dev), return_residual=True)
    close(y, ref, rtol=1e-4, atol=1e-5)
    close(rs, s, rtol=1e-5, atol=1e-6)


@DEVS
def test_add_layernorm_noncontig(dev):
    x = rn(64, 192)
    r = rn(64, 192)
    w = rn(96)
    ref, _ = _add_ln_ref(x[:, ::2], r[:, ::2], w)
    close(tl.add_layernorm(T(x, dev)[:, ::2], T(r, dev)[:, ::2], (96,),
                           T(w, dev)), ref, rtol=1e-4, atol=1e-5)


@DEVS
def test_add_layernorm_shape_mismatch(dev):
    with pytest.raises(RuntimeError):
        tl.add_layernorm(T(rn(4, 8), dev), T(rn(4, 9), dev), (8,))


@DEVS
def test_pow(dev):
    x = np.abs(rn(32, 48)) + 0.5
    close(T(x, dev) ** 2, x ** 2)
    close(T(x, dev) ** 3, x ** 3)
    close(T(x, dev) ** 0.5, x ** 0.5, rtol=1e-4)
    close(T(x, dev) ** -1, x ** -1, rtol=1e-4)
    close(T(x, dev) ** -2, x ** -2, rtol=1e-4)
    close(T(x, dev) ** 1.5, x ** 1.5, rtol=1e-3)
    close(2.0 ** T(x, dev), 2.0 ** x, rtol=1e-4)
    close(T(x, dev) ** T(x, dev), x ** x, rtol=1e-3)
    xi = rng.integers(1, 5, (16, 8)).astype(np.int32)
    out = T(xi, dev) ** 2
    assert out.dtype == tl.int32
    close(out, xi ** 2)


# ---------------------------------------------------------------------------
# matmul / bmm
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("M,N,K", [(64, 48, 32), (128, 100, 77),
                                   (256, 256, 256), (33, 65, 129)])
def test_matmul(dev, M, N, K):
    a, b = rn(M, K), rn(K, N)
    mm_close(T(a, dev) @ T(b, dev), a @ b, K)


@DEVS
def test_matmul_views(dev):
    a, b = rn(64, 48), rn(32, 48)
    mm_close(T(a, dev) @ T(b, dev).t(), a @ b.T, 48)  # transposed operand
    a2, b2 = rn(128, 96), rn(32, 96)
    mm_close(T(a2, dev)[::2] @ T(b2, dev).t(), a2[::2] @ b2.T, 96)


@DEVS
def test_matmul_vector(dev):
    a, v = rn(8, 16), rn(16)
    mm_close(T(a, dev) @ T(v, dev), a @ v, 16)
    mm_close(T(v, dev) @ T(v, dev), v @ v, 16)


# fp32 split-K route (K-heavy wgrad shapes): kernel-level numerics across
# split factors / transposed views / ragged tails, plus the route-level
# judgement mechanics.
@pytest.mark.parametrize("M,N,K,sk,trans_a,trans_b", [
    (64, 128, 8192, 2, False, False),
    (64, 128, 8192, 4, False, False),
    (64, 128, 8192, 8, False, False),
    (128, 256, 16384, 4, True, False),    # the wgrad form (^Ta)
    (128, 256, 8192, 4, False, True),     # ^Tb
    (100, 96, 5000, 4, False, False),     # ragged everything
    (100, 96, 5000, 2, True, True),
])
def test_matmul_splitk_kernel(M, N, K, sk, trans_a, trans_b):
    from minitriton.device.cuda import kernels as K_
    a32 = rng.standard_normal((K, M) if trans_a else (M, K)
                              ).astype(np.float32)
    b32 = rng.standard_normal((N, K) if trans_b else (K, N)
                              ).astype(np.float32)
    a = tl.tensor(a32)
    b = tl.tensor(b32)
    if trans_a:
        a = a.transpose(0, 1)
    if trans_b:
        b = b.transpose(0, 1)
    partials = tl.empty((sk, M, N), tl.float32, "cuda")
    out = tl.empty((M, N), tl.float32, "cuda")
    # pin SPLIT_K via a direct kernel launch through the tuner's compile
    ta, tb = K_._trans_kstride(a), K_._trans_kstride(b)
    sam = ta if ta is not None else a.strides[0]
    sbk = tb if tb is not None else b.strides[0]
    cfgs = K_._mm_v2_splitk_configs(M, N, K, sam, sbk, trans_a, trans_b)
    cfg = next(c for c in cfgs if c.kwargs["SPLIT_K"] == sk)
    kw = dict(cfg.kwargs)
    grid = (((M + kw["BM"] - 1) // kw["BM"])
            * ((N + kw["BN"] - 1) // kw["BN"]), 1, sk)
    args = (a._buffer_arg(), b._buffer_arg(), partials._buffer_arg(),
            M, N, K, sam, sbk)
    ck, values = K_.matmul_v2_splitk_kernel.compile_with(
        args, kw, cfg.num_warps, kw)
    ck.launch(grid, tuple(values))
    K_.launch_splitk_reduce(partials, sk, out, M * N)
    tl.synchronize()
    ref = (a32.T if trans_a else a32) @ (b32.T if trans_b else b32)
    mm_close(out, ref, K)


def test_matmul_splitk_route_judgement():
    """Route level: the K-heavy wgrad shape must judge split-K faster and
    take it; the result stays within matmul tolerance of the plain route."""
    from minitriton.device.cuda import ops as tl_be
    from minitriton.device.cuda import kernels as K_
    M, N, K = 640, 640, 16384   # proj.dW form: plain route underfills SMs
    a32 = rn(K, M)
    b32 = rn(K, N)
    a = T(a32, "cuda").transpose(0, 1)
    b = T(b32, "cuda")
    tl_be._SPLITK_PICKS_FP32.clear()
    out = tl_be.matmul(a, b)   # triggers the one-time judgement
    tl.synchronize()
    pick = tl_be._SPLITK_PICKS_FP32[(M, N, K, M, N, True, False)]
    assert pick >= 2, f"split-K not picked on the wgrad shape: {pick}"
    ref = a32.T @ b32
    mm_close(out, ref, K)
    # the plain route's own result (same inputs) agrees within fp32 noise
    out_plain = tl.empty((M, N), tl.float32, "cuda")
    K_.launch_matmul(a, b, out_plain, M, N, K)
    tl.synchronize()
    err = float(np.max(np.abs(out.numpy() - out_plain.numpy()))
                / (np.max(np.abs(ref)) + 1e-9))
    assert err < 1e-5, f"split-K vs plain route rel err {err}"
    # small-K shapes judge to plain (pick 0), never split
    tl_be._SPLITK_PICKS_FP32.clear()
    c, d = T(rn(64, 128), "cuda"), T(rn(128, 48), "cuda")
    tl_be.matmul(c, d)
    assert tl_be._SPLITK_PICKS_FP32.get(
        (64, 48, 128, 128, 48, False, False)) == 0
    tl_be._SPLITK_PICKS_FP32.clear()


def test_matmul_splitk_judgement_persists():
    """A proven split judgement survives to the next process (disk);
    plain judgements do not (they are re-judged)."""
    from minitriton.device.cuda import ops as tl_be
    key = (640, 640, 16384, 640, 640, True, False)
    path = tl_be._fp32_splitk_disk_path(key)
    if path.is_file():
        path.unlink()
    assert tl_be._fp32_splitk_disk_load(key) == 0
    tl_be._fp32_splitk_disk_save(key, 4)
    assert tl_be._fp32_splitk_disk_load(key) == 4
    path.unlink()
    assert tl_be._fp32_splitk_disk_load(key) == 0


@DEVS
def test_bmm(dev):
    a, b = rn(4, 32, 48), rn(4, 48, 16)
    mm_close(tl.bmm(T(a, dev), T(b, dev)), a @ b, 48)
    w = rn(48, 16)
    close(tl.matmul(T(a, dev), T(w, dev)), a @ w, rtol=1e-4, atol=1e-4)


# ---------------------------------------------------------------------------
# reductions
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("op", ["sum", "mean", "max", "min"])
@pytest.mark.parametrize("shape,dim", [
    ((64, 96), None), ((64, 96), 0), ((64, 96), 1), ((64, 96), -1),
    ((2, 3, 4), 1), ((2, 3, 4), 2), ((100003,), None), ((1000, 1001), 1),
])
@pytest.mark.parametrize("keepdim", [False, True])
def test_reduce(dev, op, shape, dim, keepdim):
    x = rn(*shape)
    npop = getattr(np, op if op != "mean" else "mean")
    ref = npop(x, axis=dim, keepdims=keepdim)
    out = getattr(T(x, dev), op)(dim=dim, keepdim=keepdim)
    close(out, ref, rtol=1e-4, atol=1e-5)


@DEVS
def test_reduce_int(dev):
    x = rng.integers(-100, 100, (33, 65)).astype(np.int32)
    out = T(x, dev).sum()
    assert out.dtype == tl.int64
    close(out, x.sum())
    close(T(x, dev).sum(dim=1), x.sum(axis=1))
    close(T(x, dev).max(dim=0), x.max(axis=0))
    close(T(x, dev).min(dim=1, keepdim=True), x.min(axis=1, keepdims=True))
    out = T(x, dev).mean()
    assert out.dtype == tl.float32
    close(out, x.mean())


@DEVS
def test_reduce_large(dev):
    x = rn(1 << 22)
    close(T(x, dev).sum(), x.sum(), rtol=1e-4)
    x2 = rn(1 << 24)  # exercises the multi-chunk stage-1 loop
    close(T(x2, dev).sum(), x2.sum(), rtol=1e-4)
    close(T(x2, dev).max(), x2.max())


@DEVS
def test_reduce_bf16_colsum(dev):
    """sum(dim=0) on a contiguous bf16 (R, C): the direct column-reduce
    (f32 accumulation, bf16 pack on store). Oracle: fp64 sums of the
    bf16-rounded inputs rounded to bf16."""
    if dev != "cuda":
        pytest.skip("bf16 has no numpy dtype (CUDA-only reduce path)")
    for R, C in [(16384, 1920), (8192, 640), (100, 7)]:
        x = rn(R, C)
        ref = _bf16_round(_bf16_round(x).astype(np.float64)
                          .sum(0).astype(np.float32))
        out = T(x, dev).astype(tl.bfloat16).sum(dim=0)
        assert out.dtype == tl.bfloat16
        np.testing.assert_allclose(out.numpy(), ref, rtol=2e-2, atol=1e-2)
        out_kd = T(x, dev).astype(tl.bfloat16).sum(dim=0, keepdim=True)
        assert out_kd.shape == (1, C)


@DEVS
def test_argmax(dev):
    x = rn(64, 97)
    close(T(x, dev).argmax(dim=1), np.argmax(x, axis=1))
    close(T(x, dev).argmax(dim=0), np.argmax(x, axis=0))
    close(T(x, dev).argmax(dim=1, keepdim=True),
          np.argmax(x, axis=1, keepdims=True))
    close(T(x, dev).argmax(), np.argmax(x))
    x3 = rn(3, 4, 5)
    close(T(x3, dev).argmax(dim=1), np.argmax(x3, axis=1))


# ---------------------------------------------------------------------------
# softmax / layernorm / embedding / cross_entropy
# ---------------------------------------------------------------------------

@DEVS
@pytest.mark.parametrize("shape,dim", [((64, 96), -1), ((64, 96), 0),
                                       ((4, 8, 16), 1), ((128, 1000), -1),
                                       ((8, 5000), -1)])
def test_softmax(dev, shape, dim):
    x = rn(*shape)
    z = x - x.max(axis=dim, keepdims=True)
    ref = np.exp(z) / np.exp(z).sum(axis=dim, keepdims=True)
    close(T(x, dev).softmax(dim=dim), ref, rtol=1e-4, atol=1e-5)
    close(T(x, dev).log_softmax(dim=dim),
          z - np.log(np.exp(z).sum(axis=dim, keepdims=True)),
          rtol=1e-4, atol=1e-5)


@DEVS
def test_layernorm(dev):
    x = rn(32, 96)
    w, b = rn(96), rn(96)
    ref = (x - x.mean(1, keepdims=True)) / np.sqrt(x.var(1, keepdims=True)
                                                   + 1e-5) * w + b
    close(tl.layer_norm(T(x, dev), (96,), T(w, dev), T(b, dev)), ref,
          rtol=1e-4, atol=1e-5)
    ref2 = (x - x.mean(1, keepdims=True)) / np.sqrt(x.var(1, keepdims=True)
                                                    + 1e-5)
    close(tl.layer_norm(T(x, dev), (96,)), ref2, rtol=1e-4, atol=1e-5)
    close(tl.layer_norm(T(x, dev), (96,), T(w, dev)), ref2 * w,
          rtol=1e-4, atol=1e-5)
    x3 = rn(4, 8, 24)
    w3 = rn(24)
    ref3 = (x3 - x3.mean(-1, keepdims=True)) / np.sqrt(
        x3.var(-1, keepdims=True) + 1e-5) * w3
    close(tl.layer_norm(T(x3, dev), (24,), T(w3, dev)), ref3,
          rtol=1e-4, atol=1e-5)
    xo = rn(64, 1000)
    refo = (xo - xo.mean(-1, keepdims=True)) / np.sqrt(
        xo.var(-1, keepdims=True) + 1e-5)
    close(tl.layer_norm(T(xo, dev), (1000,)), refo, rtol=1e-4, atol=1e-5)


@DEVS
def test_rmsnorm(dev):
    x = rn(32, 96)
    w = rn(96)
    ref = x / np.sqrt((x * x).mean(1, keepdims=True) + 1e-6) * w
    close(tl.rms_norm(T(x, dev), (96,), T(w, dev), eps=1e-6), ref,
          rtol=1e-4, atol=1e-5)
    ref2 = x / np.sqrt((x * x).mean(1, keepdims=True) + 1e-6)
    close(tl.rms_norm(T(x, dev), (96,), eps=1e-6), ref2, rtol=1e-4, atol=1e-5)


@DEVS
def test_embedding(dev):
    w = rn(50, 24)
    idx = rng.integers(0, 50, (3, 7))
    close(tl.embedding(T(w, dev), T(idx, dev)), w[idx])
    idx64 = idx.astype(np.int64)
    close(tl.embedding(T(w, dev), T(idx64, dev)), w[idx64])
    wbig = rn(100, 48)
    wv = wbig[::2]  # non-contiguous weight
    close(tl.embedding(T(wv, dev), T(idx, dev)), wv[idx])
    close(tl.embedding(T(w, dev), T(idx.reshape(-1), dev)),
          w[idx.reshape(-1)])


@DEVS
def test_embedding_index_bounds(dev):
    w_np = rn(10, 4)
    w = T(w_np, dev)
    for bad in (-1, 10, 25):
        with pytest.raises(IndexError):
            tl.embedding(w, T(np.array([bad]), dev))
    idx = np.array([0, 9, 3])  # boundary rows are legal
    close(tl.embedding(w, T(idx, dev)), w_np[idx])
    # empty index tensor is legal and skips the check
    out = tl.embedding(w, tl.empty((0,), dtype=tl.int64, device=dev))
    assert out.shape == (0, 4)


@DEVS
def test_cross_entropy(dev):
    x = rn(64, 96)
    tgt = rng.integers(0, 96, 64)
    z = x - x.max(1, keepdims=True)
    nll = np.log(np.exp(z).sum(1)) + x.max(1) - x[np.arange(64), tgt]
    close(tl.cross_entropy(T(x, dev), T(tgt, dev), reduction="none"), nll,
          rtol=1e-4, atol=1e-5)
    close(tl.cross_entropy(T(x, dev), T(tgt, dev), reduction="sum"),
          nll.sum(), rtol=1e-4)
    close(tl.cross_entropy(T(x, dev), T(tgt, dev), reduction="mean"),
          nll.mean(), rtol=1e-4)
    xo = rn(16, 1000)
    to = rng.integers(0, 1000, 16).astype(np.int64)
    zo = xo - xo.max(1, keepdims=True)
    nllo = np.log(np.exp(zo).sum(1)) + xo.max(1) - xo[np.arange(16), to]
    close(tl.cross_entropy(T(xo, dev), T(to, dev)), nllo.mean(), rtol=1e-4)


@DEVS
def test_cross_entropy_target_bounds(dev):
    x_np = rn(4, 8)
    x = T(x_np, dev)
    for bad in (-1, 8, 100):
        tgt = np.array([0, 7, 2, 5])
        tgt[1] = bad
        with pytest.raises(IndexError):
            tl.cross_entropy(x, T(tgt, dev))
    tgt = np.array([0, 7, 2, 5])  # boundary classes are legal
    z = x_np - x_np.max(1, keepdims=True)
    nll = np.log(np.exp(z).sum(1)) + x_np.max(1) - x_np[np.arange(4), tgt]
    close(tl.cross_entropy(x, T(tgt, dev), reduction="none"), nll,
          rtol=1e-4, atol=1e-5)


def test_cross_entropy_cross_device_target():
    # a target on the other device is moved onto the logits' device,
    # same handling as embedding's indices
    x_np = rn(4, 8)
    tgt = np.array([0, 7, 2, 5])
    z = x_np - x_np.max(1, keepdims=True)
    nll = np.log(np.exp(z).sum(1)) + x_np.max(1) - x_np[np.arange(4), tgt]
    out = tl.cross_entropy(T(x_np, "cuda"), T(tgt, "cpu"), reduction="none")
    assert out.device == "cuda"
    close(out, nll, rtol=1e-4, atol=1e-5)
    out = tl.cross_entropy(T(x_np, "cpu"), T(tgt, "cuda"), reduction="none")
    assert out.device == "cpu"
    close(out, nll, rtol=1e-4, atol=1e-5)


@DEVS
@pytest.mark.parametrize("rows,cols", [
    (5, 7), (37, 1024), (3, 2049), (3, 8191), (64, 8192), (5, 8193),
    (4, 32000), (4, 50257), (2, 131072), (2, 262144), (1, 32000),
])
def test_cross_entropy_wide(dev, rows, cols):
    """Wide-vocab CE forward vs numpy: past the single-pass row limit the
    cuda backend takes the split-reduction path (online segment max/sum +
    merge); covers odd widths, the 8192 boundary, real vocab sizes and
    batch sizes down to 1."""
    x = rn(rows, cols)
    tgt = rng.integers(0, cols, rows)
    z = x - x.max(1, keepdims=True)
    nll = np.log(np.exp(z).sum(1)) + x.max(1) - x[np.arange(rows), tgt]
    close(tl.cross_entropy(T(x, dev), T(tgt, dev), reduction="none"), nll,
          rtol=1e-4, atol=1e-5)
    close(tl.cross_entropy(T(x, dev), T(tgt, dev), reduction="sum"),
          nll.sum(), rtol=1e-4)
    close(tl.cross_entropy(T(x, dev), T(tgt, dev), reduction="mean"),
          nll.mean(), rtol=1e-4)


@DEVS
def test_cross_entropy_wide_noncontig(dev):
    """Non-contiguous logits (strided column slice) at a split-path width;
    the op layer must stage them contiguous first."""
    xf = rn(8, 64002)
    x = xf[:, ::2]  # (8, 32001) non-contiguous
    tgt = rng.integers(0, 32001, 8).astype(np.int64)
    z = x - x.max(1, keepdims=True)
    nll = np.log(np.exp(z).sum(1)) + x.max(1) - x[np.arange(8), tgt]
    tx = T(xf, dev)[:, ::2]
    close(tl.cross_entropy(tx, T(tgt, dev), reduction="none"), nll,
          rtol=1e-4, atol=1e-5)


@DEVS
def test_reshape_of_strided_view_split_dim(dev):
    """Regression: _reshape_strides split rule — reshaping a
    non-contiguous view by splitting a dim must keep element order
    (bug gave inverted inner/outer strides; found by attention heads
    reshape)."""
    x = np.arange(2 * 8 * 96, dtype=np.float32).reshape(2, 8, 96)
    t = T(x, dev)
    r = t[:, :, :32].reshape(2, 8, 4, 8).numpy()
    close(r, x[:, :, :32].reshape(2, 8, 4, 8))
    r2 = t[:, :, :32].reshape(2, 8, 4, 8).transpose(1, 2).numpy()
    close(r2, x[:, :, :32].reshape(2, 8, 4, 8).transpose(0, 2, 1, 3))
    # 1D strided split
    y = np.arange(12, dtype=np.float32)
    t2 = T(y, dev)[::2]
    close(t2.reshape(2, 3).numpy(), y[::2].reshape(2, 3))
