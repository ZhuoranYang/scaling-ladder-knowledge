"""Layout algebra tests (compiler/layout.py).

Pure Python (no GPU, no MLIR): dump/parse round-trips of the compact text form,
hand-computed ownership cases per constructor, Fragment ownership against
the store_m4/_mma_frag_a/_mma_frag_b coordinate formulas, the
string-layout mapping table, regs_per_thread conventions, and the
convert_layout tier-1 rule matching (layout.convert_t1).

GPU: Fragment ownership verified against the real
mma store (arange-encoded C = I@B tiles read back coordinate-exact),
and the tier-1 frag_c_to_a P->A conversion checked bit-identical against
the hand-written inline fragment conversion (flash pv_mma / kda_out_mma,
both tiers).
"""

import sys

from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from types import SimpleNamespace

import pytest

from minitriton.compiler.layout import (
    Blocked,
    Fragment,
    Layout,
    LayoutError,
    Replicated,
    Sliced,
    convert_plan,
    convert_t1,
    default_layout,
    dist_layout,
    flat_layout,
    is_dist,
    is_flat,
    is_rep_like,
    is_t2,
    parse,
    rep_layout,
    store_compatible,
    t2_layout,
    t3_layout,
    vec_ept,
)

NT = 128  # default num_threads for the hand-computed cases


def _coords(shape):
    if len(shape) == 1:
        return [(i,) for i in range(shape[0])]
    return [(i, j) for i in range(shape[0]) for j in range(shape[1])]


def _owners(layout, coord, nt):
    return [t for t in range(nt) if layout.owns(coord, t, nt)]


# ---------------------------------------------------------------------------
# dump/parse round-trip (the compact text form)
# ---------------------------------------------------------------------------

#: canonical text forms — parse(s).dump() must reproduce s verbatim.
TEXT_FORMS = [
    # the design's own blocked example (a syntax illustration, kept verbatim)
    "blocked((64,64), spt=(1,4), thr=(1,128), ord=(1,0))",
    "blocked((128,), spt=(1,), thr=(128,), ord=(0,))",            # dist 1D
    "blocked((4,512), spt=(1,4), thr=(1,128), ord=(1,0))",        # dist 2D
    "blocked((8,24), spt=(1,3), thr=(8,8), ord=(1,0))",           # flat
    "blocked((64,64), spt=(4,4), thr=(16,4), ord=(1,0))",         # t2
    "blocked((8,64), spt=(2,64), thr=(4,1), ord=(1,0))",          # t3
    "rep((64,1))",                                                # text-form literal
    "rep((7,))",
    # the original fragment text-form example had shape (128,64) with warps (4,1) atoms
    # (2,4), which violates shape == warps*atoms*atom_extent (64 != 1*4*8);
    # this is the same example with consistent geometry.
    "fragment((128,32), atom=bf16, role=C, warps=(4,1), atoms=(2,4))",
    "fragment((32,16), atom=tf32, role=A, warps=(2,1), atoms=(1,2))",
    "fragment((32,16), atom=bf16, role=B, warps=(2,1), atoms=(2,2), ldsm=x2t)",
    "fragment((128,128), atom=tf32x3, role=C, warps=(4,2), atoms=(2,8))",
    "slice(blocked((4,512), spt=(1,4), thr=(1,128), ord=(1,0)), dim=1)",
    "slice(rep((8,16)), dim=0)",
]


@pytest.mark.parametrize("text", TEXT_FORMS)
def test_text_form_round_trip(text):
    lay = parse(text)
    assert lay.dump() == text                 # canonical text form
    assert parse(lay.dump()) == lay           # object round-trip
    assert Layout.parse(text) == lay          # staticmethod entry point
    assert hash(parse(lay.dump())) == hash(lay)  # cache-key usable


def test_round_trip_all_constructors():
    cases = [
        Blocked((64, 64), (4, 4), (16, 4), (1, 0)),
        Replicated((64, 1)),
        Sliced(Blocked((4, 512), (1, 4), (1, 128), (1, 0)), 1),
        Sliced(Replicated((8, 16)), 0),
        Fragment((128, 32), "bf16", "C", (4, 1), (2, 4)),
        Fragment((16, 32), "bf16", "A", (1, 1), (1, 2), "x4t"),
        Fragment((16, 16), "tf32", "B", (2, 1), (2, 2), "x2"),
        Fragment((16, 16), "tf32x3", "A", (1, 2), (1, 2), "x2t"),
    ]
    for lay in cases:
        assert parse(lay.dump()) == lay
        assert len({lay, parse(lay.dump())}) == 1  # hash/eq as cache keys


def test_ldsm_default_omitted_from_text():
    assert parse("fragment((32,16), atom=tf32, role=A, warps=(2,1), "
                 "atoms=(1,2))").ldsm == "x4"
    frag = Fragment((32, 16), "tf32", "A", (2, 1), (1, 2), "x2t")
    assert "ldsm=x2t" in frag.dump()


def test_eq_hash_and_frozen():
    a = Blocked((64, 64), (4, 4), (16, 4), (1, 0))
    b = Blocked((64, 64), (4, 4), (16, 4), (1, 0))
    c = Blocked((64, 64), (4, 4), (16, 4), (0, 1))
    assert a == b and hash(a) == hash(b)
    assert a != c and len({a, b, c}) == 2
    with pytest.raises(AttributeError):
        a.shape = (1,)


@pytest.mark.parametrize("bad", [
    "blocked((64,64))",                              # missing kwargs
    "blocked((64,64), spt=(1,4), thr=(1,128))",      # missing ord
    "fragment((32,16), atom=tf32, role=A, warps=(2,1))",  # missing atoms
    "fragment((32,16), atom=tf32, role=A, warps=(2,1), atoms=(1,2), x=1)",
    "rep((64,1)",                                    # unbalanced
    "rep((64,1), dim=1)",                            # unexpected kwarg
    "slice(rep((8,16)))",                            # missing dim
    "slice(rep((8,16)), dim=x)",
    "nope((1,))",
    "blocked((64,64), spt=(1,4), thr=(1,128), ord=(1.5,0))",
    "",
])
def test_parse_errors(bad):
    with pytest.raises(LayoutError):
        parse(bad)


# ---------------------------------------------------------------------------
# Blocked ownership — hand-computed dist/flat/t2/t3 cases
# ---------------------------------------------------------------------------

class TestBlockedOwns:
    def test_dist_1d(self):
        lay = Blocked((128,), (1,), (128,), (0,))
        assert lay.owns((37,), 37, NT)
        assert not lay.owns((38,), 37, NT)
        assert not lay.owns((36,), 37, NT)
        assert lay.regs_per_thread() == 1

    def test_dist_2d(self):
        # (4, 512) over 128 threads: ept = 4, thread t owns cols 4t..4t+3
        # of every row; per-thread value is vector<4 x 4> (R x VEC).
        lay = Blocked((4, 512), (1, 4), (1, 128), (1, 0))
        for r in range(4):
            for c in (20, 21, 22, 23):
                assert lay.owns((r, c), 5, NT)
            assert not lay.owns((r, 19), 5, NT)
            assert not lay.owns((r, 24), 5, NT)
        assert lay.regs_per_thread() == 16  # R * (C/nt) total

    def test_flat(self):
        # (8, 16) over 32 threads: ept = 4, thread t owns the raveled run
        # [4t, 4t+4) -> row (4t)//16, cols (4t)%16...
        lay = Blocked((8, 16), (1, 4), (8, 4), (1, 0))
        for c in range(4, 8):
            assert lay.owns((0, c), 1, 32)
        for c in range(4):
            assert lay.owns((1, c), 4, 32)
            assert lay.owns((7, 12 + c), 31, 32)
        assert not lay.owns((1, 0), 0, 32)
        assert lay.regs_per_thread() == 4

    def test_t2(self):
        # (64, 64) tm=4 tn=16 over 64 threads: thread (ty, tx) = (t//4,
        # t%4) owns rows ty*4..+4 and, per row, the tn/4=4 column chunks
        # (tx + j*nt_n)*4 .. +4 (builder.matmul_tile docstring :4571-4575).
        lay = Blocked((64, 64), (4, 4), (16, 4), (1, 0))
        tid, ty, tx = 5, 1, 1
        for ii in range(4):
            for j in range(4):
                for e in range(4):
                    assert lay.owns((ty * 4 + ii, (tx + j * 4) * 4 + e), tid, 64)
        assert not lay.owns((4, 8), tid, 64)   # tx=2's chunk
        assert not lay.owns((8, 4), tid, 64)   # ty=2's rows
        assert lay.regs_per_thread() == 64     # tm * tn

    def test_t3(self):
        # (8, 64) tm=2 over 4 threads: thread t owns rows 2t, 2t+1 fully
        # (flash_attention_fwd thread mapping :2440-2442).
        lay = Blocked((8, 64), (2, 64), (4, 1), (1, 0))
        for c in range(64):
            assert lay.owns((2, c), 1, 4)
            assert lay.owns((3, c), 1, 4)
            assert not lay.owns((4, c), 1, 4)
        assert lay.regs_per_thread() == 128    # tm * 64

    def test_full_coverage_invariant(self):
        # every element has exactly one owner; every thread holds exactly
        # regs_per_thread() elements.
        cases = [
            (Blocked((128,), (1,), (128,), (0,)), NT),
            (Blocked((4, 512), (1, 4), (1, 128), (1, 0)), NT),
            (Blocked((8, 16), (1, 4), (8, 4), (1, 0)), 32),
            (Blocked((64, 64), (4, 4), (16, 4), (1, 0)), 64),
            (Blocked((8, 64), (2, 64), (4, 1), (1, 0)), 4),
        ]
        for lay, nt in cases:
            counts = [0] * nt
            for coord in _coords(lay.shape):
                owners = _owners(lay, coord, nt)
                assert len(owners) == 1, (coord, owners)
                counts[owners[0]] += 1
            assert counts == [lay.regs_per_thread()] * nt

    def test_query_validation(self):
        lay = Blocked((4, 512), (1, 4), (1, 128), (1, 0))
        with pytest.raises(LayoutError):
            lay.owns((4, 0), 0, NT)            # row out of bounds
        with pytest.raises(LayoutError):
            lay.owns((0,), 0, NT)              # rank mismatch
        with pytest.raises(LayoutError):
            lay.owns((0, 0), 128, NT)          # tid out of range
        with pytest.raises(LayoutError):
            lay.owns((0, 0), 0, 64)            # grid product != num_threads
        with pytest.raises(LayoutError):
            lay.owns((0, 0), 0, 0)             # nonpositive num_threads

    def test_construction_validation(self):
        with pytest.raises(LayoutError):
            Blocked((64,), (2,), (32,), (1,))        # order not a permutation
        with pytest.raises(LayoutError):
            Blocked((64,), (2, 2), (32,), (0,))      # rank mismatch
        with pytest.raises(LayoutError):
            Blocked((64,), (0,), (32,), (0,))        # nonpositive spt
        with pytest.raises(LayoutError):
            Blocked((), (1,), (1,), (0,))            # empty shape


# ---------------------------------------------------------------------------
# Replicated / Sliced
# ---------------------------------------------------------------------------

class TestReplicated:
    def test_owns_everything(self):
        lay = Replicated((64, 1))
        for tid in (0, 37, NT - 1):
            for r in range(64):
                assert lay.owns((r, 0), tid, NT)
        assert lay.regs_per_thread() == 64     # full copy per thread

    def test_1d(self):
        lay = Replicated((7,))
        assert lay.regs_per_thread() == 7
        assert lay.owns((6,), 3, 8)
        with pytest.raises(LayoutError):
            lay.owns((7,), 0, 8)


class TestSliced:
    PARENT = Blocked((4, 512), (1, 4), (1, 128), (1, 0))  # dist 2D

    def test_shape(self):
        assert Sliced(self.PARENT, 1).shape == (4,)
        assert Sliced(self.PARENT, 0).shape == (512,)
        assert Sliced(self.PARENT, -1).dim == 1          # negative dim ok

    def test_reduce_column_result_replicates(self):
        # (R, C) dist reduced along dim 1 -> (R,): every thread participated
        # in every row, so every thread owns every row (today: treated as
        # rep, reduce_axis1 :1735).
        lay = Sliced(self.PARENT, 1)
        for tid in (0, 5, NT - 1):
            for r in range(4):
                assert lay.owns((r,), tid, NT)
        assert lay.regs_per_thread() == 4

    def test_slice_dim0(self):
        lay = Sliced(self.PARENT, 0)
        assert lay.owns((21,), 5, NT)
        assert not lay.owns((24,), 5, NT)
        assert lay.regs_per_thread() == 4      # thread's 4 columns

    def test_slice_flat_parent(self):
        parent = Blocked((8, 16), (1, 4), (8, 4), (1, 0))   # flat, nt=32
        lay = Sliced(parent, 1)
        assert lay.owns((0,), 0, 32) and lay.owns((0,), 3, 32)
        assert not lay.owns((1,), 0, 32)
        assert lay.regs_per_thread() == 1
        for r in range(8):
            assert len(_owners(lay, (r,), 32)) == 4  # the row's 4 threads

    def test_slice_replicated_parent(self):
        lay = Sliced(Replicated((8, 16)), 0)
        assert lay.shape == (16,)
        assert lay.regs_per_thread() == 16
        assert lay.owns((9,), 3, 8)

    def test_validation(self):
        with pytest.raises(LayoutError):
            Sliced(self.PARENT, 2)
        with pytest.raises(LayoutError):
            Sliced("not-a-layout", 0)
        with pytest.raises(LayoutError):
            Sliced(self.PARENT, 1).owns((4,), 0, NT)


# ---------------------------------------------------------------------------
# Fragment (m4) ownership — builder coordinate formulas
# ---------------------------------------------------------------------------

class TestFragmentC:
    # bf16 mma C tile (128, 32): warp grid (4, 1), warp tile (32, 32) =
    # (2, 4) atoms of (16, 8); 128 threads.
    FRAG = Fragment((128, 32), "bf16", "C", (4, 1), (2, 4))

    def test_hand_cases(self):
        # tid 0: warp 0, lane 0 -> g=0, t=0: rows {0,8,16,24} (atoms im,
        # halves), cols {0,1} + in_*8 for in_ in 0..3.
        for coord in [(0, 0), (8, 1), (16, 9), (24, 25)]:
            assert self.FRAG.owns(coord, 0, NT), coord
        for coord in [(1, 0), (0, 2), (32, 0), (0, 26)]:
            assert not self.FRAG.owns(coord, 0, NT), coord
        # tid 33: warp 1 (wy=1, slab rows 32..63), lane 1 -> g=0, t=1:
        # cols t*2 = {2,3} + in_*8.
        assert self.FRAG.owns((32, 2), 33, NT)
        assert self.FRAG.owns((56, 27), 33, NT)
        assert not self.FRAG.owns((32, 0), 33, NT)
        assert not self.FRAG.owns((0, 2), 33, NT)

    def test_matches_store_m4_formula(self):
        # Re-derive every owned coordinate from the store_m4/mma_tile
        # docstring formula (builder.py:6350, :5947-5951) and check the
        # layout agrees, element for element.
        wn_m, wn_n, atoms_m, atoms_n = 4, 1, 2, 4
        wa_m, wa_n = 32, 32
        for tid in range(NT):
            warp, lane = tid // 32, tid % 32
            wy, wx = warp // wn_n, warp % wn_n
            g, t = lane // 4, lane % 4
            expected = set()
            for im in range(atoms_m):
                for in_ in range(atoms_n):
                    for j in range(4):
                        r = wy * wa_m + im * 16 + g + 8 * (j // 2)
                        c = wx * wa_n + in_ * 8 + t * 2 + j % 2
                        expected.add((r, c))
            assert len(expected) == 32 == self.FRAG.regs_per_thread()
            for coord in expected:
                assert self.FRAG.owns(coord, tid, NT), (coord, tid)
            # and nothing else: full sweep against the formula's set.
            for coord in _coords(self.FRAG.shape):
                assert self.FRAG.owns(coord, tid, NT) == (coord in expected)

    def test_full_coverage_invariant(self):
        counts = [0] * NT
        for coord in _coords(self.FRAG.shape):
            owners = _owners(self.FRAG, coord, NT)
            assert len(owners) == 1, (coord, owners)
            counts[owners[0]] += 1
        assert counts == [4 * 2 * 4] * NT     # 4 f32 accumulators per atom

    def test_tf32x3_geometry(self):
        # tf32x3 shares the tf32 atom geometry (m16n8k8).
        frag = Fragment((128, 128), "tf32x3", "C", (4, 2), (2, 8))
        tid = 5 * 32 + 10       # warp 5 -> (wy, wx) = (2, 1); lane 10 -> g=2, t=2
        assert frag.owns((64 + 2, 64 + 4), tid, 256)
        assert frag.owns((64 + 26, 64 + 29), tid, 256)
        assert not frag.owns((64 + 2, 64 + 6), tid, 256)   # t=3's column
        assert not frag.owns((2, 68), tid, 256)            # wy=0's slab
        assert frag.regs_per_thread() == 4 * 2 * 8

    def test_num_threads_mismatch(self):
        with pytest.raises(LayoutError):
            self.FRAG.owns((0, 0), 0, 64)


class TestFragmentA:
    # tf32 A tile (32, 16): warp grid (2, 1), warp tile (16, 16) =
    # (1, 2) atoms of (16, 8); 64 threads.
    FRAG = Fragment((32, 16), "tf32", "A", (2, 1), (1, 2))

    def test_hand_cases(self):
        # _mma_frag_a (:5352): element (row g + 8*(j%2), col t*ep +
        # (j//2)*(k/2)) of atom (h, im). tid 6: warp 0, lane 6 -> g=1, t=2.
        tid = 6
        for coord in [(1, 2), (1, 6), (9, 2), (9, 6),      # h = 0
                      (1, 10), (1, 14), (9, 10), (9, 14)]:  # h = 1
            assert self.FRAG.owns(coord, tid, 64), coord
        assert not self.FRAG.owns((1, 3), tid, 64)
        assert not self.FRAG.owns((2, 2), tid, 64)
        assert not self.FRAG.owns((17, 2), tid, 64)        # wy=1's slab
        assert self.FRAG.owns((17, 2), 32 + 6, 64)

    def test_replication_across_wx(self):
        # A replicates across the warp grid's n dim: warps (1, 2) -> the
        # same (g, t) lane of both warps owns each element.
        frag = Fragment((16, 16), "tf32", "A", (1, 2), (1, 2))
        assert sorted(_owners(frag, (1, 2), 64)) == [6, 38]
        assert sorted(_owners(frag, (9, 14), 64)) == [6, 38]

    def test_full_coverage_invariant(self):
        counts = [0] * 64
        for coord in _coords(self.FRAG.shape):
            owners = _owners(self.FRAG, coord, 64)
            assert len(owners) == 1, (coord, owners)
            counts[owners[0]] += 1
        assert counts == [self.FRAG.regs_per_thread()] * 64  # 4 regs/atom

    def test_bf16_packing(self):
        # bf16 A (16, 32): atom k=16, ep=2 — each i32 reg holds the
        # (t*2, t*2+1) pair, so per-thread element count = regs * 2.
        frag = Fragment((16, 32), "bf16", "A", (1, 1), (1, 2))
        tid = 13                # lane 13 -> g=3, t=1
        for coord in [(3, 2), (3, 3), (3, 10), (3, 11),
                      (11, 2), (11, 27)]:
            assert frag.owns(coord, tid, 32), coord
        assert not frag.owns((3, 4), tid, 32)
        assert not frag.owns((3, 0), tid, 32)
        counts = [0] * 32
        for coord in _coords(frag.shape):
            owners = _owners(frag, coord, 32)
            assert len(owners) == 1, (coord, owners)
            counts[owners[0]] += 1
        assert counts == [frag.regs_per_thread() * 2] * 32  # 8 regs, 16 elems


class TestFragmentB:
    # tf32 B tile (16, 32): warp grid (1, 4), warp tile (16, 8) =
    # (2, 1) atoms of (8, 8); 128 threads.
    FRAG = Fragment((16, 32), "tf32", "B", (1, 4), (2, 1))

    def test_hand_cases(self):
        # _mma_frag_b (:5423): element (row t*ep + j*(k/2), col g) of atom
        # (h, in_). tid 33: warp 1 -> wx=1 (col slab 8..15), lane 1 -> t=1.
        tid = 33
        for coord in [(1, 8), (5, 8), (9, 8), (13, 8)]:
            assert self.FRAG.owns(coord, tid, NT), coord
        assert not self.FRAG.owns((1, 9), tid, NT)   # g=1's column
        assert not self.FRAG.owns((1, 0), tid, NT)   # wx=0's slab
        assert not self.FRAG.owns((0, 8), tid, NT)   # t=0's row
        assert self.FRAG.regs_per_thread() == 4      # 2 regs per atom

    def test_replication_across_wy(self):
        frag = Fragment((32, 16), "bf16", "B", (2, 1), (2, 2))
        # same lane (g=2, t=1) of both wy warps owns (2, 2).
        assert sorted(_owners(frag, (2, 2), 64)) == [9, 41]

    def test_full_coverage_invariant(self):
        counts = [0] * NT
        for coord in _coords(self.FRAG.shape):
            owners = _owners(self.FRAG, coord, NT)
            assert len(owners) == 1, (coord, owners)
            counts[owners[0]] += 1
        assert counts == [self.FRAG.regs_per_thread()] * NT


class TestFragmentValidation:
    @pytest.mark.parametrize("args", [
        ((16, 16), "fp16", "C", (1, 1), (1, 2)),        # unknown atom
        ((16, 16), "tf32", "D", (1, 1), (1, 2)),        # unknown role
        ((16, 16), "tf32", "C", (1, 1), (1, 2), "x8"),  # unknown ldsm
        ((16, 16), "tf32", "C", (1, 1), (1, 1)),        # dim1: 1*1*8 != 16
        ((16, 16, 1), "tf32", "C", (1, 1), (1, 2)),     # not 2D
        ((16, 16), "tf32", "C", (1,), (1, 2)),          # warps not 2-tuple
    ])
    def test_bad_construction(self, args):
        with pytest.raises(LayoutError):
            Fragment(*args)

    def test_geometry_mismatch_is_caught(self):
        # the literal fragment text-form example is geometrically inconsistent
        # (shape (128,64) with warps (4,1) atoms (2,4): 64 != 1*4*8) —
        # the constructor rejects it rather than building a broken map.
        with pytest.raises(LayoutError):
            parse("fragment((128,64), atom=bf16, role=C, warps=(4,1), "
                  "atoms=(2,4))")


# ---------------------------------------------------------------------------
# The load-time default rule — the pick_layout cascade
# ---------------------------------------------------------------------------

class TestDefaultLayout:
    """default_layout == the builder.pick_layout cascade, rule for rule
    (the behavioral-equivalence regression pin)."""

    @staticmethod
    def _pick_layout(shape, nt):
        # verbatim copy of builder.pick_layout's rules
        if len(shape) == 1:
            c = shape[0]
            if c % nt == 0:
                return "dist", c // nt
            return "rep", c
        r, c = shape
        if c % nt == 0:
            return "dist", c // nt
        if (r * c) % nt == 0 and c > 1:
            ept = (r * c) // nt
            if c % ept == 0:
                return "flat", ept
        return "rep", r * c

    @pytest.mark.parametrize("shape,nt", [
        ((256,), NT), ((100,), NT), ((7,), 4),
        ((4, 512), NT), ((8, 24), 64), ((3, 5), 64), ((6, 10), 4),
        ((2, 8), 4), ((1, 1), 32), ((16, 33), 32), ((32, 32), 32),
    ])
    def test_default_rule_equivalence(self, shape, nt):
        name, ept = self._pick_layout(shape, nt)
        lay = default_layout(shape, nt)
        if name == "rep":
            assert isinstance(lay, Replicated)
            assert lay.regs_per_thread() == ept
        elif name == "flat":
            assert isinstance(lay, Blocked) and is_flat(lay)
            assert lay.regs_per_thread() == ept
        else:  # dist
            assert isinstance(lay, Blocked) and is_dist(lay)
            assert lay.size_per_thread[-1] == ept
            # total per-thread registers: 1D = ept, 2D = R * ept (builder's
            # Tensor.ept for 2D dist is the per-row VEC)
            total = ept if len(shape) == 1 else shape[0] * ept
            assert lay.regs_per_thread() == total


# ---------------------------------------------------------------------------
# Address-form compatibility query (SepOff/MatOff stay outside)
# ---------------------------------------------------------------------------

class TestAcceptsAddr:
    def test_shape_match(self):
        lay = Blocked((64, 64), (4, 4), (16, 4), (1, 0))
        assert lay.accepts_addr(SimpleNamespace(shape=(64, 64)))     # SepOff
        assert lay.accepts_addr(SimpleNamespace(shape=(64, 64),
                                                mat="x"))            # MatOff
        assert not lay.accepts_addr(SimpleNamespace(shape=(64,)))
        assert not lay.accepts_addr(SimpleNamespace(shape=(64, 32)))
        assert not lay.accepts_addr(object())                        # no shape

    def test_sliced_and_fragment(self):
        sl = Sliced(Blocked((4, 512), (1, 4), (1, 128), (1, 0)), 1)
        assert sl.accepts_addr(SimpleNamespace(shape=(4,)))
        assert not sl.accepts_addr(SimpleNamespace(shape=(4, 512)))
        frag = Fragment((128, 32), "bf16", "C", (4, 1), (2, 4))
        assert frag.accepts_addr(SimpleNamespace(shape=(128, 32)))
        assert not frag.accepts_addr(SimpleNamespace(shape=(128, 64)))


# ---------------------------------------------------------------------------
# convert_layout tier-1 rule matching — pure layout metadata
# ---------------------------------------------------------------------------

class TestConvertT1:
    """layout.convert_t1 is the rule table's matching half (metadata only);
    the emission half (Builder.convert_layout) is GPU-tested below."""

    def test_frag_c_to_a_tf32(self):
        # tf32 k=8 == C's atom n: one C atom per A atom.
        c = Fragment((64, 64), "tf32", "C", (4, 1), (1, 8))
        a = Fragment((64, 64), "tf32", "A", (4, 1), (1, 8))
        assert convert_t1(c, a) == "frag_c_to_a"

    def test_frag_c_to_a_bf16(self):
        # bf16 k=16: two adjacent C n-atoms feed one A k-atom.
        c = Fragment((64, 64), "bf16", "C", (4, 1), (1, 8))
        a = Fragment((64, 64), "bf16", "A", (4, 1), (1, 4))
        assert convert_t1(c, a) == "frag_c_to_a"

    def test_frag_c_to_a_tf32x3(self):
        # tf32x3 shares the tf32 atom geometry.
        c = Fragment((64, 64), "tf32x3", "C", (4, 1), (1, 8))
        a = Fragment((64, 64), "tf32x3", "A", (4, 1), (1, 8))
        assert convert_t1(c, a) == "frag_c_to_a"

    @pytest.mark.parametrize("src,dst,why", [
        (Fragment((64, 64), "tf32", "C", (4, 1), (1, 8)),
         Fragment((64, 64), "bf16", "A", (4, 1), (1, 4)),
         "atom mismatch"),
        (Fragment((64, 64), "tf32", "A", (4, 1), (1, 8)),
         Fragment((64, 64), "tf32", "C", (4, 1), (1, 8)),
         "A -> C is not a tier-1 rule"),
        (Fragment((128, 64), "tf32", "C", (2, 2), (4, 4)),
         Fragment((128, 64), "tf32", "A", (2, 2), (4, 8)),
         "warps[1] > 1 needs cross-warp traffic"),
        (Fragment((64, 64), "tf32", "C", (4, 1), (1, 8)),
         Fragment((64, 64), "tf32", "A", (2, 1), (2, 8)),
         "warp grid mismatch"),
        (Fragment((64, 64), "tf32", "C", (4, 1), (1, 8)),
         Fragment((64, 32), "tf32", "A", (4, 1), (1, 4)),
         "shape mismatch (K != N)"),
        (Blocked((64, 64), (1, 4), (1, 128), (1, 0)),
         Fragment((64, 64), "tf32", "A", (4, 1), (1, 8)),
         "Blocked -> Fragment has no S1 rule"),
        (Fragment((64, 64), "tf32", "C", (4, 1), (1, 8)),
         Replicated((64, 64)),
         "Fragment -> Replicated has no S1 rule"),
    ])
    def test_no_rule(self, src, dst, why):
        assert convert_t1(src, dst) is None, why


# ---------------------------------------------------------------------------
# GPU: Fragment ownership vs the real mma store,
# and the tier-1 P->A conversion vs the inline fragment conversion
# ---------------------------------------------------------------------------

import hashlib  # noqa: E402

import numpy as np  # noqa: E402

import minitriton as tl  # noqa: E402
from minitriton import ops as tl_ops  # noqa: E402
from minitriton.device.cuda import kernels as _K  # noqa: E402
from minitriton.tensor import empty as _empty  # noqa: E402

from test_flash_mma import np_attention  # noqa: E402
from test_mma import bf16_buffer, f32_to_bf16_bits  # noqa: E402


@tl.kernel
def _m4_arange_kernel(a_ptr, b_ptr, c_ptr, K,
                      BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
                      ATOM: tl.constexpr, WM: tl.constexpr, WN: tl.constexpr):
    """C (BM, BN) = A (BM, K) @ B (K, BN), one mma tile, stored through
    the Fragment-dispatched tl.store (builder.store -> store_m4)."""
    offs_m = tl.arange(0, BM)
    offs_n = tl.arange(0, BN)
    offs_k = tl.arange(0, BK)
    a_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    b_ptrs = b_ptr + offs_k[:, None] * BN + offs_n[None, :]
    acc = tl.mma_tile(a_ptrs, b_ptrs, K, ATOM=ATOM, WN_M=WM, WN_N=WN)
    tl.store(c_ptr + offs_m[:, None] * BN + offs_n[None, :], acc)


def _m4_arange_store(bm, bn, bk, warps, wm, wn, atom, channel):
    """C = I @ B with B[k, j] = k (channel "row") or j ("col"): every
    output element reads back its own coordinate. All values are small
    ints, exact in every tier (tf32 holds ints <= 2047, bf16 <= 256), so
    the readback must be bit-exact."""
    a_np = np.eye(bm, dtype=np.float32)            # K == BM
    k_idx = np.arange(bm, dtype=np.float32)[:, None]
    j_idx = np.arange(bn, dtype=np.float32)[None, :]
    b_np = np.broadcast_to(k_idx if channel == "row" else j_idx,
                           (bm, bn)).copy()
    if atom == "bf16":
        da = bf16_buffer(f32_to_bf16_bits(a_np))
        db = bf16_buffer(f32_to_bf16_bits(b_np))
    else:
        da = tl.Buffer.from_numpy(a_np)
        db = tl.Buffer.from_numpy(b_np)
    dc = tl.Buffer(bm * bn, tl.float32)
    _m4_arange_kernel[(1, 1)](da, db, dc, bm, BM=bm, BN=bn, BK=bk,
                              ATOM=atom, WM=wm, WN=wn, num_warps=warps)
    tl.synchronize()
    return dc.to_numpy().reshape(bm, bn)


def _store_formula_coords(frag, tid):
    """The store_m4 coordinate formula (builder.py store_m4 docstring):
    the owned-coordinate set of thread `tid`, hand-derived."""
    (wm, wn), (am, an) = frag.warps, frag.atoms
    wa_m, wa_n = frag.shape[0] // wm, frag.shape[1] // wn
    warp, lane = tid // 32, tid % 32
    wy, wx = warp // wn, warp % wn
    g, t = lane // 4, lane % 4
    out = set()
    for im in range(am):
        for in_ in range(an):
            for j in range(4):
                r = wy * wa_m + im * 16 + g + 8 * (j // 2)
                c = wx * wa_n + in_ * 8 + t * 2 + j % 2
                out.add((r, c))
    return out


class TestFragmentOwnershipGpu:
    """Fragment.owns against store_m4's GPU behaviour — arange-
    encoded tiles stored by the real kernel and read back coordinate by
    coordinate, composed with the formula-level owns() sweep."""

    @pytest.mark.parametrize("atom", ["tf32", "bf16"])
    @pytest.mark.parametrize("bm,bn,bk,warps,wm,wn", [
        (64, 64, 32, 4, 2, 2),
        (64, 64, 32, 4, 4, 1),
        (128, 64, 32, 8, 4, 2),
    ])
    def test_arange_store_coordinates(self, atom, bm, bn, bk, warps, wm,
                                      wn):
        rows = _m4_arange_store(bm, bn, bk, warps, wm, wn, atom, "row")
        cols = _m4_arange_store(bm, bn, bk, warps, wm, wn, atom, "col")
        # hardware-observed: the fragment element the formula places at
        # (i, j) really landed at global (i, j), for every element.
        want_r = np.arange(bm, dtype=np.float32)[:, None]
        want_c = np.arange(bn, dtype=np.float32)[None, :]
        np.testing.assert_array_equal(
            rows, np.broadcast_to(want_r, (bm, bn)))
        np.testing.assert_array_equal(
            cols, np.broadcast_to(want_c, (bm, bn)))

        frag = Fragment((bm, bn), atom, "C", (wm, wn),
                        (bm // wm // 16, bn // wn // 8))
        nt = warps * 32
        # pure side, same geometry: owns() agrees with the store formula
        # on every thread's owned set, and the sets partition the tile.
        seen = {}
        for tid in range(nt):
            owned = _store_formula_coords(frag, tid)
            assert len(owned) == frag.regs_per_thread()
            for coord in owned:
                assert frag.owns(coord, tid, nt), (coord, tid)
                assert coord not in seen, (coord, tid, seen.get(coord))
                seen[coord] = tid
        assert len(seen) == bm * bn  # full coverage, exactly one owner

    def test_tensor_layout_is_fragment(self):
        # Tensor.layout carries Layout objects only; shape/regs are
        # validated at construction.
        from minitriton.compiler.builder import Tensor, TileConfigError
        frag = Fragment((64, 64), "tf32", "C", (4, 1), (1, 8))
        t = Tensor(None, (64, 64), frag, object(), 32)
        assert t.layout is frag
        with pytest.raises(TileConfigError):      # string layout rejected
            Tensor(None, (64, 64), "dist", object(), 16)
        with pytest.raises(TileConfigError):      # shape != layout.shape
            Tensor(None, (64, 32), frag, object(), 32)
        with pytest.raises(TileConfigError):      # ept != regs/thread
            Tensor(None, (64, 64), frag, object(), 16)

    def test_store_compatible(self):
        d = dist_layout((4, 512), NT)
        assert store_compatible(d, dist_layout((4, 512), NT))
        assert not store_compatible(d, flat_layout((8, 24), 64))
        # a Sliced reduce result stores through a rep address (same
        # per-thread full-copy value form)
        assert store_compatible(Sliced(d, 1), rep_layout((4, 1)))
        assert store_compatible(rep_layout((4, 1)), Sliced(d, 1))
        assert not store_compatible(d, rep_layout((4, 512)))


class TestP2AGpu:
    """The tier-1 frag_c_to_a conversion (Builder.convert_layout)
    is numerically identical to the hand-written inline fragment
    conversion in flash_attention_fwd_mma (pv_mma) and kda_out_mma.
    Pins are sha256 of the raw output bytes; regenerate them only
    alongside a deliberate emission change."""

    PINS = {
        ("flash", "tf32"):
            "b9a8e6ba9eca4fe1704d5c353ee9746ea08306914c2b82a8f5cabc59c16e4669",
        ("flash", "bf16"):
            "1ac51075ff021ce9bc3b789473c424fae6f169f64bea1875562500e661fe3580",
        ("kda", "tf32"):
            "2b8ccf84f38f6f0865d7c2e81eec77ede91df624edd0439459fadeed825e371d",
        ("kda", "bf16"):
            "6bc3a043e2099221a30f6934a19d2747725573c27636e25c28342c54b5e8aa54",
    }

    @staticmethod
    def _flash_out(atom, warps, T=192, BH=2, seed=0):
        rng = np.random.default_rng(seed)
        hd = 64
        q, k, v = (rng.standard_normal((BH, T, hd)).astype(np.float32)
                   for _ in range(3))
        dt = tl.bfloat16 if atom == "bf16" else tl.float32
        tq, tk, tv = (tl.tensor(x).astype(dt) for x in (q, k, v))
        out = _empty((BH, T, hd), dt, "cuda")
        lse = _empty((BH, T), tl.float32, "cuda")
        _K.launch_flash_attention_mma(tq, tk, tv, out, lse,
                                      1.0 / np.sqrt(hd), atom=atom,
                                      num_warps=warps)
        tl.synchronize()
        return out.astype(tl.float32).numpy(), lse.numpy(), (q, k, v)

    @pytest.mark.parametrize("atom,tol", [("tf32", 1e-2), ("bf16", 2e-2)])
    @pytest.mark.parametrize("warps", [2, 4])
    def test_flash_p2a(self, atom, tol, warps):
        o, l, (q, k, v) = self._flash_out(atom, warps)
        # bit pin vs the inline pv_mma conversion
        h = hashlib.sha256(o.tobytes() + l.tobytes()).hexdigest()
        assert h == self.PINS[("flash", atom)]
        # fp64 oracle (independent of the pin): the P@V mma via the
        # tier-1 rule stays within the tier tolerance of true attention
        ref, lse_ref = np_attention(q.reshape(1, -1, *q.shape[-2:]),
                                    k.reshape(1, -1, *k.shape[-2:]),
                                    v.reshape(1, -1, *v.shape[-2:]),
                                    1.0 / np.sqrt(64))
        np.testing.assert_allclose(o.reshape(ref.shape), ref,
                                   rtol=tol, atol=tol)
        np.testing.assert_allclose(l.reshape(lse_ref.shape), lse_ref,
                                   rtol=tol, atol=tol)

    @staticmethod
    def _kda_out(atom, B=1, H=2, T=100, dk=64, dv=64, seed=7):
        rng = np.random.default_rng(seed)
        q = rng.standard_normal((B, H, T, dk)).astype(np.float32)
        k = rng.standard_normal((B, H, T, dk)).astype(np.float32)
        v = rng.standard_normal((B, H, T, dv)).astype(np.float32)
        xb = rng.standard_normal((B, H, T)).astype(np.float32)
        loga = rng.uniform(-0.7, 0.0, (B, H, T, dk))
        a = np.exp(loga)
        xd = np.log(a / (1.0 - a)).astype(np.float32)
        o = tl_ops.kda_forward(*(tl.tensor(x) for x in (q, k, v, xb, xd)),
                               precision=atom)
        tl.synchronize()
        return o.numpy()

    @pytest.mark.parametrize("atom", ["tf32", "bf16"])
    def test_kda_p2a(self, atom):
        # kda_out_mma's Aq -> A conversion (K3) through the tier-1 rule:
        # bit-identical to the inline a_frag_aq.
        o = self._kda_out(atom)
        h = hashlib.sha256(o.tobytes()).hexdigest()
        assert h == self.PINS[("kda", atom)]


# ---------------------------------------------------------------------------
# parameter-instance constructors + structural predicates + vec_ept
# ---------------------------------------------------------------------------


class TestParameterInstances:
    """dist/flat/rep/t2/t3 as Blocked/Replicated parameter instances
    (the parameter-instance mapping), with the structural predicates the
    store/emission dispatch keys on."""

    def test_dist_1d(self):
        lay = dist_layout((256,), NT)
        assert lay == Blocked((256,), (2,), (NT,), (0,))
        assert is_dist(lay) and not is_flat(lay) and not is_t2(lay)
        assert not is_rep_like(lay)
        assert vec_ept(lay) == 2

    def test_dist_2d(self):
        lay = dist_layout((4, 512), NT)
        assert lay == Blocked((4, 512), (1, 4), (1, NT), (1, 0))
        assert is_dist(lay) and not is_flat(lay) and not is_t2(lay)
        assert vec_ept(lay) == 4          # per-row VEC, not the total
        assert parse(lay.dump()) == lay

    def test_dist_1c_is_not_flat(self):
        # a (1, C) dist shares the thr[0]==shape[0] coincidence with the
        # flat rule; the shape[0] > 1 guard keeps it classified dist.
        lay = dist_layout((1, 512), NT)
        assert is_dist(lay) and not is_flat(lay)

    def test_flat(self):
        lay = flat_layout((8, 24), 64)
        assert lay == Blocked((8, 24), (1, 3), (8, 8), (1, 0))
        assert is_flat(lay) and not is_dist(lay) and not is_t2(lay)
        assert vec_ept(lay) == 3

    def test_rep(self):
        lay = rep_layout((3, 5))
        assert lay == Replicated((3, 5))
        assert is_rep_like(lay) and vec_ept(lay) == 15

    def test_t2(self):
        lay = t2_layout((64, 64), 4, 16, 64)
        assert lay == Blocked((64, 64), (4, 4), (16, 4), (1, 0))
        assert is_t2(lay) and not is_flat(lay) and not is_dist(lay)
        assert vec_ept(lay) == 64         # tm * tn
        assert parse(lay.dump()) == lay

    def test_t2_tm1_tn4_shares_flat_ownership(self):
        # documented collision: t2 (tm=1, tn=4) and an ept=4 flat are
        # the SAME ownership map — is_t2 wins by dispatch order, and the
        # owned addresses coincide anyway.
        t2 = t2_layout((64, 64), 1, 4, 1024)
        fl = flat_layout((64, 64), 1024)
        assert t2 == fl and is_t2(t2)
        for coord in [(0, 0), (7, 28), (63, 60)]:
            assert t2.owns(coord, 5, 1024) == fl.owns(coord, 5, 1024)

    def test_t3(self):
        lay = t3_layout((8, 64), 2, 4)
        assert lay == Blocked((8, 64), (2, 64), (4, 1), (1, 0))
        assert not is_dist(lay) and not is_flat(lay) and not is_t2(lay)
        assert vec_ept(lay) == 128        # tm * 64

    def test_sliced_is_rep_like(self):
        sl = Sliced(dist_layout((4, 512), NT), 1)
        assert is_rep_like(sl)
        assert vec_ept(sl) == sl.regs_per_thread() == 4

    @pytest.mark.parametrize("ctor,args", [
        (dist_layout, ((100,), NT)),           # not divisible
        (dist_layout, ((64,), None)),          # needs num_threads
        (flat_layout, ((6, 10), 4)),           # C % ept != 0
        (t2_layout, ((64, 64), 3, 16, 64)),    # tm not in (1,2,4,8)
        (t2_layout, ((64, 64), 4, 8, 64)),     # grid != num_threads
        (t3_layout, ((8, 64), 2, 8)),          # shape[0] != nt*tm
    ])
    def test_constructor_errors(self, ctor, args):
        with pytest.raises(LayoutError):
            ctor(*args)


class TestConvertPlan:
    """Tier selection unit tests covering all three tiers; tier-3
    is documented as graph-only and must never be selected in-kernel."""

    def test_tier0_identity(self):
        lay = dist_layout((4, 512), NT)
        assert convert_plan(lay, dist_layout((4, 512), NT)) == "t0"
        frag = Fragment((128, 32), "bf16", "C", (4, 1), (2, 4))
        assert convert_plan(frag, parse(frag.dump())) == "t0"

    def test_tier1_rules(self):
        c = Fragment((64, 64), "tf32", "C", (4, 1), (1, 8))
        a = Fragment((64, 64), "tf32", "A", (4, 1), (1, 8))
        assert convert_plan(c, a) == "t1:frag_c_to_a"

    @pytest.mark.parametrize("src,dst", [
        (dist_layout((4, 512), NT), flat_layout((8, 24), 64)),
        (dist_layout((4, 512), NT), rep_layout((4, 512))),
        (rep_layout((8, 24)), flat_layout((8, 24), 64)),
        (Sliced(dist_layout((4, 512), NT), 1), dist_layout((256,), NT)),
        (dist_layout((4, 512), NT), Fragment((128, 32), "bf16", "C",
                                            (4, 1), (2, 4))),
    ])
    def test_tier2_fallback(self, src, dst):
        # no tier-1 rule -> the smem round-trip is the structural
        # fallback (builder additionally checks the 48KB budget)
        assert convert_plan(src, dst) == "t2"

    def test_tier3_is_graph_only(self):
        # tier-3 (global round-trip) is the fusion engine's do-not-fuse
        # cost item; convert_plan has no "t3" outcome at all.
        pairs = [
            (dist_layout((4, 512), NT), rep_layout((4, 512))),
            (rep_layout((8, 24)), flat_layout((8, 24), 64)),
            (Fragment((64, 64), "bf16", "C", (4, 1), (1, 8)),
             dist_layout((4, 512), NT)),
        ]
        for src, dst in pairs:
            assert convert_plan(src, dst) in ("t0", "t1:frag_c_to_a", "t2")


# ---------------------------------------------------------------------------
# Sliced wired into reduce results (registration, emission unchanged)
# ---------------------------------------------------------------------------

class TestSlicedReduce:
    def test_reduce_axis1_result_layout(self):
        # builder-level (CPU, no launch): the (R, 1) reduce result
        # carries Sliced(dist, dim=1); downstream broadcast still treats
        # it as a per-thread full column (rep-like).
        from minitriton.compiler.builder import Builder, SepOff, Affine
        import minitriton as _tl
        from minitriton.frontend import semantics as sem
        with Builder("s2_sliced", 128) as b:
            args = b.begin([("x", ("ptr", _tl.float32))])
            pt = type(args["x"])(
                args["x"].arg,
                SepOff((8, 256), Affine(0, 256, 8), Affine(0, 1, 256)))
            x = b.load(pt)
            y = b.reduce_axis1(x, "sum")
            assert isinstance(y.layout, Sliced) and y.layout.dim == 1
            assert y.layout.parent == x.layout
            assert y.shape == (8, 1) and y.ept == 8
            assert is_rep_like(y.layout)
            # the (R, 1) x (R, C) broadcast still applies (emission only,
            # no launch): dist result of the parent's layout
            x2, y2 = sem.broadcast_tensors(b, x, y)
            assert is_dist(y2.layout) and y2.shape == x.shape
            b.finish()

    def test_sliced_ownership_matches_reduce_contract(self):
        # every thread owns every row of the (R,)-sliced result — the
        # ownership reading of "the row reduce replicates across the
        # column dim's threads".
        parent = dist_layout((8, 256), 128)
        sl = Sliced(parent, 1)
        for r in range(8):
            assert sl.owns((r,), 0, 128)
            assert sl.owns((r,), 77, 128)
        assert sl.regs_per_thread() == 8


class TestT3Registration:
    """t3 as a Blocked parameter instance, checked against
    flash_attention_fwd's documented row-per-thread mapping
    (builder.py flash_attention_fwd docstring): thread tid owns rows
    tid*tm .. tid*tm+tm-1 of the (R, 64) tile outright."""

    def test_ownership_vs_flash_formula(self):
        tm, nt = 2, 4
        lay = t3_layout((nt * tm, 64), tm, nt)
        for tid in range(nt):
            owned = {(r, c) for r in range(nt * tm) for c in range(64)
                     if lay.owns((r, c), tid, nt)}
            want = {(r, c) for r in range(tid * tm, tid * tm + tm)
                    for c in range(64)}
            assert owned == want


# ---------------------------------------------------------------------------
# tier-2 smem round-trip — builder-level GPU tests
# ---------------------------------------------------------------------------

class TestTier2Gpu:
    """convert_layout's tier-2 (register layout A -> smem -> register
    layout B): data must come back bit-exact through the round-trip.
    Kernels are driven at Builder level (no new frontend API) and
    compiled/launched through the standard pipeline."""

    @staticmethod
    def _round_trip(shape, chain, nt, tmp_path, device):
        """load (choose_layout default) -> convert_layout over chain ->
        store; the chain must end at the load's own layout so the final
        store validates. Returns the output array."""
        import minitriton as _tl
        from minitriton.compiler.builder import Builder, SepOff, Affine
        from minitriton.compiler.lowering import compile_to_cubin
        from minitriton.runtime.cuda_driver import memref1d_params

        r, c = shape
        rng = np.random.default_rng(0)
        x_np = rng.standard_normal((r, c)).astype(np.float32)
        out_np = np.zeros_like(x_np)

        with Builder("s2cvt", nt) as b:
            args = b.begin([("x", ("ptr", _tl.float32)),
                            ("o", ("ptr", _tl.float32))])
            x_pt = type(args["x"])(args["x"].arg, SepOff(
                shape, Affine(0, c, r), Affine(0, 1, c)))
            o_pt = type(args["o"])(args["o"].arg, SepOff(
                shape, Affine(0, c, r), Affine(0, 1, c)))
            v = b.load(x_pt)
            for dst in chain(v.layout):
                v = b.convert_layout(v, dst)
            b.store(o_pt, v)
            text = b.finish()

        cubin = compile_to_cubin(text, name="s2cvt", build_dir=tmp_path)
        kernel = device.load_module(cubin).function("s2cvt")
        nbytes = x_np.nbytes
        dx = device.alloc(nbytes)
        do = device.alloc(nbytes)
        try:
            device.memcpy_h2d(dx, np.ascontiguousarray(x_np), nbytes)
            vl = 4  # f32 16-byte lanes (the dual-view ABI's vector view)
            params = (memref1d_params(dx, x_np.size)
                      + memref1d_params(dx, x_np.size // vl)
                      + memref1d_params(do, x_np.size)
                      + memref1d_params(do, x_np.size // vl))
            kernel.launch((1, 1, 1), (nt, 1, 1), params)
            device.synchronize()
            device.memcpy_d2h(out_np, do, nbytes)
        finally:
            device.free(dx)
            device.free(do)
        return out_np

    @pytest.fixture(scope="class")
    @classmethod
    def device(cls):
        from minitriton.runtime.cuda_driver import Device
        return Device(0)

    def test_dist_rep_dist(self, tmp_path, device):
        shape, nt = (4, 512), 128
        lay0 = dist_layout(shape, nt)
        out = self._round_trip(
            shape, lambda lay0=lay0: [rep_layout(shape), lay0], nt,
            tmp_path, device)
        np.testing.assert_array_equal(out, self._x_np(shape))

    def test_flat_rep_flat(self, tmp_path, device):
        shape, nt = (8, 24), 64
        # (8, 24) with nt=64: choose_layout picks flat
        lay0 = flat_layout(shape, nt)
        out = self._round_trip(
            shape, lambda lay0=lay0: [rep_layout(shape), lay0], nt,
            tmp_path, device)
        np.testing.assert_array_equal(out, self._x_np(shape))

    def test_dist_flat_dist(self, tmp_path, device):
        # the (16, 256) tile with nt=128: dist by default; flat exists
        # (ept = 32); go dist -> flat -> dist through two round-trips.
        shape, nt = (16, 256), 128
        lay0 = dist_layout(shape, nt)
        out = self._round_trip(
            shape, lambda lay0=lay0: [flat_layout(shape, nt), lay0], nt,
            tmp_path, device)
        np.testing.assert_array_equal(out, self._x_np(shape))

    @staticmethod
    def _x_np(shape):
        rng = np.random.default_rng(0)
        return rng.standard_normal(shape).astype(np.float32)

    def test_tier2_scratch_reuse(self, tmp_path, device):
        # two conversions in one kernel share one scratch buffer via the
        # scratch= parameter (the SmemRef precursor form)
        import minitriton as _tl
        from minitriton.compiler.builder import Builder, SepOff, Affine
        from minitriton.compiler.lowering import compile_to_cubin
        from minitriton.runtime.cuda_driver import memref1d_params

        shape, nt = (4, 512), 128
        r, c = shape
        x_np = self._x_np(shape)
        out_np = np.zeros_like(x_np)
        with Builder("s2cvt2", nt) as b:
            args = b.begin([("x", ("ptr", _tl.float32)),
                            ("o", ("ptr", _tl.float32))])
            x_pt = type(args["x"])(args["x"].arg, SepOff(
                shape, Affine(0, c, r), Affine(0, 1, c)))
            o_pt = type(args["o"])(args["o"].arg, SepOff(
                shape, Affine(0, c, r), Affine(0, 1, c)))
            scratch = b._scratch_smem("cvt_manual", r * c, _tl.float32)
            v = b.load(x_pt)
            v = b.convert_layout(v, rep_layout(shape), scratch=scratch)
            v = b.convert_layout(v, dist_layout(shape, nt), scratch=scratch)
            b.store(o_pt, v)
            text = b.finish()
        cubin = compile_to_cubin(text, name="s2cvt2", build_dir=tmp_path)
        kernel = device.load_module(cubin).function("s2cvt2")
        nbytes = x_np.nbytes
        dx = device.alloc(nbytes)
        do = device.alloc(nbytes)
        try:
            device.memcpy_h2d(dx, np.ascontiguousarray(x_np), nbytes)
            vl = 4  # f32 16-byte lanes (the dual-view ABI's vector view)
            params = (memref1d_params(dx, x_np.size)
                      + memref1d_params(dx, x_np.size // vl)
                      + memref1d_params(do, x_np.size)
                      + memref1d_params(do, x_np.size // vl))
            kernel.launch((1, 1, 1), (nt, 1, 1), params)
            device.synchronize()
            device.memcpy_d2h(out_np, do, nbytes)
        finally:
            device.free(dx)
            device.free(do)
        np.testing.assert_array_equal(out_np, x_np)


# ---------------------------------------------------------------------------
# R2': tier-1 bcast_to_frag_c (Blocked/Replicated -> Fragment(C), the
# unlock example — the mma matmul epilogue's bias broadcast)
# ---------------------------------------------------------------------------

class TestBcastToFragC:
    def test_matcher(self):
        frag = Fragment((64, 64), "tf32", "C", (2, 2), (2, 4))
        assert convert_t1(rep_layout((64,)), frag) == "bcast_to_frag_c"
        assert convert_t1(rep_layout((1, 64)), frag) == "bcast_to_frag_c"
        assert convert_t1(dist_layout((64,), 64), frag) == "bcast_to_frag_c"
        assert convert_t1(dist_layout((1, 64), 64), frag) \
            == "bcast_to_frag_c"
        assert convert_plan(rep_layout((64,)), frag) == "t1:bcast_to_frag_c"

    def test_matcher_misses(self):
        frag = Fragment((64, 64), "tf32", "C", (2, 2), (2, 4))
        assert convert_t1(rep_layout((32,)), frag) is None     # N mismatch
        assert convert_t1(rep_layout((64, 1)), frag) is None   # column, not row
        assert convert_t1(dist_layout((64, 64), 64), frag) is None  # 2D tile
        fa = Fragment((64, 64), "tf32", "A", (2, 2), (2, 8))
        assert convert_t1(rep_layout((64,)), fa) is None       # role A
        # flat is not a vector form
        assert convert_t1(flat_layout((8, 24), 64),
                          Fragment((64, 24), "tf32", "C", (2, 1), (2, 3))) \
            is None

    @staticmethod
    def _bcast_store(shape_v, frag, nt, tmp_path, device):
        """bias (N,) -> convert_layout(Fragment(C)) -> store_m4: every
        output row must equal the bias vector."""
        import minitriton as _tl
        from minitriton.compiler.builder import Builder, SepOff, Affine
        from minitriton.compiler.lowering import compile_to_cubin
        from minitriton.runtime.cuda_driver import memref1d_params

        (n,), (bm, bn) = shape_v, frag.shape
        rng = np.random.default_rng(0)
        x_np = rng.standard_normal(n).astype(np.float32)
        out_np = np.zeros((bm, bn), dtype=np.float32)
        with Builder("r2p_bcast", nt) as b:
            args = b.begin([("x", ("ptr", _tl.float32)),
                            ("o", ("ptr", _tl.float32))])
            x_pt = type(args["x"])(args["x"].arg,
                                   SepOff((n,), None, Affine(0, 1, n)))
            o_pt = type(args["o"])(args["o"].arg, SepOff(
                (bm, bn), Affine(0, bn, bm), Affine(0, 1, bn)))
            v = b.load(x_pt)
            fv = b.convert_layout(v, frag)
            b.store(o_pt, fv)
            text = b.finish()
        cubin = compile_to_cubin(text, name="r2p_bcast",
                                 build_dir=tmp_path)
        kernel = device.load_module(cubin).function("r2p_bcast")
        dx = device.alloc(x_np.nbytes)
        do = device.alloc(out_np.nbytes)
        try:
            device.memcpy_h2d(dx, np.ascontiguousarray(x_np), x_np.nbytes)
            vl = 4
            params = (memref1d_params(dx, n) + memref1d_params(dx, n // vl)
                      + memref1d_params(do, out_np.size)
                      + memref1d_params(do, out_np.size // vl))
            kernel.launch((1, 1, 1), (nt, 1, 1), params)
            device.synchronize()
            device.memcpy_d2h(out_np, do, out_np.nbytes)
        finally:
            device.free(dx)
            device.free(do)
        return x_np, out_np

    @pytest.fixture(scope="class")
    @classmethod
    def device(cls):
        from minitriton.runtime.cuda_driver import Device
        return Device(0)

    @pytest.mark.parametrize("n,frag,nt", [
        # rep source (N % nt != 0), single warp column
        (64, Fragment((64, 64), "tf32", "C", (2, 2), (2, 4)), 128),
        # dist source (VEC = 2), single warp column
        (256, Fragment((64, 256), "bf16", "C", (4, 1), (1, 32)), 128),
        # dist source, two warp columns (wx != 0 covered)
        (256, Fragment((64, 256), "bf16", "C", (2, 2), (2, 16)), 128),
        # rep source, four warp columns
        (64, Fragment((64, 64), "tf32", "C", (4, 2), (1, 4)), 256),
    ])
    def test_columns_match(self, n, frag, nt, tmp_path, device):
        x_np, out = self._bcast_store((n,), frag, nt, tmp_path, device)
        np.testing.assert_array_equal(
            out, np.broadcast_to(x_np[None, :], frag.shape).copy())


def test_layout_module_is_pure_python():
    """L1 invariant: compiler/layout.py is the
    layout-metadata layer — pure Python, zero MLIR, zero minitriton
    imports; the builder consumes it, never the other way around."""
    import ast as _ast
    from minitriton.compiler import layout as _layout
    src = open(_layout.__file__).read()
    for node in _ast.walk(_ast.parse(src)):
        if isinstance(node, _ast.Import):
            for a in node.names:
                assert a.name.split(".")[0] not in ("mlir", "minitriton"), \
                    f"layout.py must not import {a.name}"
        elif isinstance(node, _ast.ImportFrom):
            assert node.level > 0 or \
                (node.module or "").split(".")[0] not in ("mlir",
                                                          "minitriton"), \
                f"layout.py must not import {node.module}"
            assert node.level == 0, \
                "layout.py must not import from the package (relative import)"
