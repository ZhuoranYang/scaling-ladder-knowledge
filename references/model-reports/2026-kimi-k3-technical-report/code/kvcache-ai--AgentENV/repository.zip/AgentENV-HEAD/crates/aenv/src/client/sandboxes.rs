use super::{handle_status, Client};
use anyhow::Result;
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::collections::HashMap;
use std::time::Duration;

#[derive(Debug, Serialize)]
pub struct SandboxVolumeMount {
    pub name: String,
    pub path: String,
}

fn volume_mounts_request(
    mounts: Option<HashMap<String, String>>,
) -> Option<Vec<SandboxVolumeMount>> {
    mounts.map(|mounts| {
        mounts
            .into_iter()
            .map(|(path, name)| SandboxVolumeMount { name, path })
            .collect()
    })
}

#[derive(Debug, PartialEq, Serialize)]
pub struct AttachedDrive {
    #[serde(rename = "driveID")]
    pub drive_id: String,
    #[serde(rename = "readOnly")]
    pub read_only: bool,
    #[serde(rename = "mountPath")]
    pub mount_path: String,
    pub source: AttachedDriveSource,
}

#[derive(Debug, PartialEq, Serialize)]
pub struct AttachedDriveSource {
    pub image: String,
}

#[derive(Debug, Serialize)]
pub struct NewSandboxV2<'a> {
    #[serde(rename = "templateID")]
    pub template_id: &'a str,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub timeout: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none", rename = "volumeMounts")]
    pub volume_mounts: Option<Vec<SandboxVolumeMount>>,
    #[serde(skip_serializing_if = "Option::is_none", rename = "attachedDrives")]
    pub attached_drives: Option<Vec<AttachedDrive>>,
}

#[derive(Debug, Serialize)]
pub struct NewColdSandbox<'a> {
    pub image: &'a str,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub timeout: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none", rename = "cpuCount")]
    pub cpu_count: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none", rename = "memoryMB")]
    pub memory_mb: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none", rename = "diskSizeMB")]
    pub disk_size_mb: Option<u32>,
    pub secure: bool,
    #[serde(skip_serializing_if = "Option::is_none", rename = "volumeMounts")]
    pub volume_mounts: Option<Vec<SandboxVolumeMount>>,
    #[serde(skip_serializing_if = "Option::is_none", rename = "attachedDrives")]
    pub attached_drives: Option<Vec<AttachedDrive>>,
}

#[derive(Deserialize)]
pub struct Sandbox {
    #[serde(rename = "sandboxID")]
    pub sandbox_id: String,
    #[serde(default, rename = "envdAccessToken")]
    pub envd_access_token: Option<String>,
    #[serde(default, rename = "trafficAccessToken")]
    pub traffic_access_token: Option<String>,
}

#[derive(Debug, Serialize)]
pub struct RefreshSandbox {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub duration: Option<u32>,
}

#[derive(Deserialize)]
pub struct SandboxDetail {
    pub state: String,
    #[serde(default, rename = "envdAccessToken")]
    pub envd_access_token: Option<String>,
}

#[derive(Debug, Deserialize, Serialize)]
pub struct ListedSandbox {
    #[serde(rename = "sandboxID")]
    pub sandbox_id: String,
    #[serde(rename = "templateID")]
    pub template_id: String,
    #[serde(default)]
    pub alias: Option<String>,
    #[serde(default)]
    pub state: Option<String>,
    #[serde(default, rename = "cpuCount")]
    pub cpu_count: Option<u32>,
    #[serde(default, rename = "memoryMB")]
    pub memory_mib: Option<u32>,
    #[serde(default, rename = "diskSizeMB")]
    pub disk_size_mib: Option<u32>,
    #[serde(default, rename = "startedAt")]
    pub started_at: Option<String>,
    #[serde(default, rename = "endAt")]
    pub end_at: Option<String>,
}

impl Client {
    pub fn create_sandbox(
        &self,
        template_id: &str,
        timeout: Option<u32>,
        volume_mounts: Option<HashMap<String, String>>,
        attached_drives: Option<Vec<AttachedDrive>>,
    ) -> Result<Sandbox> {
        let body = NewSandboxV2 {
            template_id,
            timeout,
            volume_mounts: volume_mounts_request(volume_mounts),
            attached_drives,
        };
        let resp = handle_status(self.post("/v2/sandboxes").send_json(&body))?;
        let sandbox: Sandbox = resp.into_json()?;
        Ok(sandbox)
    }

    #[allow(clippy::too_many_arguments)]
    pub fn create_cold_sandbox(
        &self,
        image: &str,
        timeout: Option<u32>,
        cpu_count: Option<u32>,
        memory_mb: Option<u32>,
        disk_size_mb: Option<u32>,
        volume_mounts: Option<HashMap<String, String>>,
        attached_drives: Option<Vec<AttachedDrive>>,
    ) -> Result<Sandbox> {
        let body = NewColdSandbox {
            image,
            timeout,
            cpu_count,
            memory_mb,
            disk_size_mb,
            secure: true,
            volume_mounts: volume_mounts_request(volume_mounts),
            attached_drives,
        };
        let resp = handle_status(self.post("/sandboxes-cold").send_json(&body))?;
        let sandbox: Sandbox = resp.into_json()?;
        Ok(sandbox)
    }

    pub fn list_sandboxes(&self) -> Result<Vec<ListedSandbox>> {
        let resp = handle_status(self.get("/v2/sandboxes").call())?;
        Ok(resp.into_json()?)
    }

    pub fn delete_sandbox(&self, id: &str) -> Result<()> {
        handle_status(self.delete(&format!("/sandboxes/{}", id)).call())?;
        Ok(())
    }

    pub fn pause_sandbox(&self, id: &str) -> Result<()> {
        handle_status(self.post(&format!("/sandboxes/{}/pause", id)).call())?;
        Ok(())
    }

    pub fn sandbox_state_with_timeout(
        &self,
        id: &str,
        timeout: Duration,
    ) -> Result<Option<String>> {
        let resp = match self
            .get(&format!("/sandboxes/{}", id))
            .timeout(timeout)
            .call()
        {
            Ok(resp) => resp,
            Err(ureq::Error::Status(404, _)) => return Ok(None),
            Err(err) => handle_status(Err(err))?,
        };
        let detail: SandboxDetail = resp.into_json()?;
        Ok(Some(detail.state))
    }

    pub fn get_sandbox(&self, id: &str) -> Result<SandboxDetail> {
        let resp = handle_status(self.get(&format!("/sandboxes/{id}")).call())?;
        Ok(resp.into_json()?)
    }

    /// `connect` resumes a paused sandbox or extends the TTL of a running one.
    pub fn connect_sandbox(&self, id: &str, timeout: u32) -> Result<Sandbox> {
        let resp = handle_status(
            self.post(&format!("/sandboxes/{}/connect", id))
                .send_json(json!({ "timeout": timeout })),
        )?;
        Ok(resp.into_json()?)
    }

    pub fn set_timeout(&self, id: &str, timeout: u32) -> Result<()> {
        handle_status(
            self.post(&format!("/sandboxes/{}/timeout", id))
                .send_json(json!({ "timeout": timeout })),
        )?;
        Ok(())
    }

    pub fn refresh_sandbox(&self, id: &str, duration: Option<u32>) -> Result<()> {
        let body = RefreshSandbox { duration };
        handle_status(
            self.post(&format!("/sandboxes/{}/refreshes", id))
                .send_json(&body),
        )?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::{AttachedDrive, AttachedDriveSource, NewColdSandbox, NewSandboxV2, RefreshSandbox};

    #[test]
    fn new_sandbox_serializes_template_start() {
        let body = NewSandboxV2 {
            template_id: "base-template",
            timeout: Some(300),
            volume_mounts: None,
            attached_drives: None,
        };

        let value = serde_json::to_value(body).unwrap();
        assert_eq!(value["templateID"], "base-template");
        assert_eq!(value["timeout"], 300);
        assert!(value.get("secure").is_none());
        assert!(value.get("cpuCount").is_none());
        assert!(value.get("memoryMB").is_none());
        assert!(value.get("attachedDrives").is_none());
    }

    #[test]
    fn new_sandbox_serializes_attached_drives() {
        let body = NewSandboxV2 {
            template_id: "base-template",
            timeout: None,
            volume_mounts: None,
            attached_drives: Some(vec![AttachedDrive {
                drive_id: "image_mnt_models".to_owned(),
                read_only: false,
                mount_path: "/mnt/models".to_owned(),
                source: AttachedDriveSource {
                    image: "aenv/models:v1".to_owned(),
                },
            }]),
        };

        let value = serde_json::to_value(body).unwrap();
        let drive = &value["attachedDrives"][0];
        assert_eq!(drive["driveID"], "image_mnt_models");
        assert_eq!(drive["readOnly"], false);
        assert_eq!(drive["mountPath"], "/mnt/models");
        assert_eq!(drive["source"]["image"], "aenv/models:v1");
    }

    #[test]
    fn new_cold_sandbox_serializes_resource_overrides() {
        let body = NewColdSandbox {
            image: "ubuntu:24.04",
            timeout: Some(300),
            cpu_count: Some(2),
            memory_mb: Some(1024),
            disk_size_mb: Some(8192),
            secure: true,
            volume_mounts: None,
            attached_drives: None,
        };

        let value = serde_json::to_value(body).unwrap();
        assert_eq!(value["image"], "ubuntu:24.04");
        assert_eq!(value["timeout"], 300);
        assert_eq!(value["cpuCount"], 2);
        assert_eq!(value["memoryMB"], 1024);
        assert_eq!(value["diskSizeMB"], 8192);
        assert_eq!(value["secure"], true);
        assert!(value.get("templateID").is_none());
    }

    #[test]
    fn refresh_sandbox_body_serializes_optional_duration() {
        let value = serde_json::to_value(RefreshSandbox {
            duration: Some(300),
        })
        .unwrap();

        assert_eq!(value["duration"], 300);

        let empty = serde_json::to_value(RefreshSandbox { duration: None }).unwrap();
        assert!(empty.get("duration").is_none());
    }
}
