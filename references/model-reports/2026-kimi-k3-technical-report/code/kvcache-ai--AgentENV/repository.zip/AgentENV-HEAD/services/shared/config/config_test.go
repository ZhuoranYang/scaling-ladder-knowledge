package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestDefaultConfigUsesAutoLogFormat(t *testing.T) {
	cfg := defaultConfig("gateway")
	if cfg.LogFormat != "auto" {
		t.Fatalf("expected default log format auto, got %q", cfg.LogFormat)
	}
}

func TestDefaultSchedulerDiscoveryModeIsStatic(t *testing.T) {
	cfg := defaultConfig("scheduler")
	if got := cfg.Scheduler.Discovery.Mode; got != "static" {
		t.Fatalf("expected scheduler discovery mode static, got %q", got)
	}
	if got := cfg.Scheduler.Discovery.Kubernetes.Scheme; got != "http" {
		t.Fatalf("expected kubernetes discovery scheme http, got %q", got)
	}
	if got := cfg.Scheduler.ReportTTL; got != 30*time.Second {
		t.Fatalf("expected scheduler report ttl 30s, got %s", got)
	}
	if got := cfg.Scheduler.BindingTTL; got != 30*time.Second {
		t.Fatalf("expected scheduler binding ttl 30s, got %s", got)
	}
	if got := cfg.Scheduler.MetricsListenAddr; got != ":9101" {
		t.Fatalf("expected scheduler metrics listen addr :9101, got %q", got)
	}
	if got := cfg.Scheduler.ArtifactStoreCapacity; got != defaultSchedulerArtifactStoreCapacity {
		t.Fatalf("expected scheduler artifact store capacity %d, got %d", defaultSchedulerArtifactStoreCapacity, got)
	}
	if got := cfg.Scheduler.ArtifactLookupNodeLimit; got != 0 {
		t.Fatalf("expected scheduler artifact lookup node limit 0, got %d", got)
	}
}

func TestLoadSchedulerAllowsQueryOnlyWithRedisWithoutNodes(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"redis_addr": "127.0.0.1:6379",
			"nodes": []
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	cfg, err := LoadScheduler(path, true)
	if err != nil {
		t.Fatalf("load query-only scheduler config failed: %v", err)
	}
	if cfg.Scheduler.RedisAddr != "127.0.0.1:6379" {
		t.Fatalf("unexpected redis addr: %q", cfg.Scheduler.RedisAddr)
	}
}

func TestLoadSchedulerRejectsQueryOnlyWithoutRedis(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"nodes": []
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	if _, err := LoadScheduler(path, true); err == nil {
		t.Fatal("expected query-only scheduler without redis_addr to fail")
	}
}

func TestValidateRejectsUnsupportedLogFormat(t *testing.T) {
	cfg := defaultConfig("gateway")
	cfg.LogFormat = "pretty"
	if err := cfg.Validate(); err == nil {
		t.Fatal("expected validate to reject unsupported log_format")
	}
}

func TestValidateAcceptsSupportedLogFormats(t *testing.T) {
	formats := []string{"auto", "console", "json"}
	for _, format := range formats {
		cfg := defaultConfig("gateway")
		cfg.LogFormat = format
		if err := cfg.Validate(); err != nil {
			t.Fatalf("expected format %q to validate, got error %v", format, err)
		}
	}
}

func TestLoadParsesGatewayRequestTimeoutDurationString(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"gateway": {
			"request_timeout": "45s",
			"sandbox_proxy_domains": ["sandbox-proxy.example.invalid", "sandbox-proxy-alt.example.invalid"]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	cfg, err := Load(path, "gateway")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if cfg.Gateway.RequestTimeout != 45*time.Second {
		t.Fatalf("expected request timeout 45s, got %s", cfg.Gateway.RequestTimeout)
	}
	if got := cfg.Gateway.SandboxProxyDomains; len(got) != 2 || got[0] != "sandbox-proxy.example.invalid" || got[1] != "sandbox-proxy-alt.example.invalid" {
		t.Fatalf("unexpected proxy domains: %#v", got)
	}
}

func TestLoadRejectsNumericGatewayRequestTimeout(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"gateway": {
			"request_timeout": 30
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	_, err := Load(path, "gateway")
	if err == nil {
		t.Fatal("expected load to fail for numeric request_timeout")
	}
}

func TestLoadAppliesGatewayRequestTimeoutEnvDuration(t *testing.T) {
	t.Setenv("GATEWAY_REQUEST_TIMEOUT", "1m30s")
	t.Setenv("GATEWAY_SANDBOX_PROXY_DOMAINS", " sandbox-proxy.example.invalid,sandbox-proxy-alt.example.invalid ,,")

	cfg, err := Load("", "gateway")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if cfg.Gateway.RequestTimeout != 90*time.Second {
		t.Fatalf("expected request timeout 90s, got %s", cfg.Gateway.RequestTimeout)
	}
	if got := cfg.Gateway.SandboxProxyDomains; len(got) != 2 || got[0] != "sandbox-proxy.example.invalid" || got[1] != "sandbox-proxy-alt.example.invalid" {
		t.Fatalf("unexpected proxy domains from env: %#v", got)
	}
}

func TestLoadRejectsInvalidGatewayRequestTimeoutEnvDuration(t *testing.T) {
	t.Setenv("GATEWAY_REQUEST_TIMEOUT", "1m30")

	_, err := Load("", "gateway")
	if err == nil {
		t.Fatal("expected load to fail for invalid GATEWAY_REQUEST_TIMEOUT")
	}
}

func TestLoadDefaultsSchedulerDiscoveryToStaticWhenUnset(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	cfg, err := Load(path, "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if got := cfg.Scheduler.Discovery.Mode; got != "static" {
		t.Fatalf("expected discovery mode static, got %q", got)
	}
}

func TestLoadParsesKubernetesSchedulerDiscoveryConfig(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"discovery": {
				"mode": "kubernetes",
				"kubernetes": {
					"namespace": "agentenv-system",
					"service_name": "agentenv-nodes",
					"port": 8000,
					"ignore_pod_selector": "agentenv.io/discovery=ignore",
					"no_schedule_pod_selector": "agentenv.io/scheduler-state in (draining,no-schedule)"
				}
			}
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	cfg, err := Load(path, "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if got := cfg.Scheduler.Discovery.Mode; got != "kubernetes" {
		t.Fatalf("expected discovery mode kubernetes, got %q", got)
	}
	if got := cfg.Scheduler.Discovery.Kubernetes.Scheme; got != "http" {
		t.Fatalf("expected default discovery scheme http, got %q", got)
	}
	if got := cfg.Scheduler.Discovery.Kubernetes.Namespace; got != "agentenv-system" {
		t.Fatalf("expected namespace agentenv-system, got %q", got)
	}
	if got := cfg.Scheduler.Discovery.Kubernetes.IgnorePodSelector; got != "agentenv.io/discovery=ignore" {
		t.Fatalf("expected ignore pod selector, got %q", got)
	}
	if got := cfg.Scheduler.Discovery.Kubernetes.NoSchedulePodSelector; got != "agentenv.io/scheduler-state in (draining,no-schedule)" {
		t.Fatalf("expected no-schedule pod selector, got %q", got)
	}
}

func TestLoadDefaultsSchedulerReportTTLWhenUnset(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	cfg, err := Load(path, "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if got := cfg.Scheduler.ReportTTL; got != 30*time.Second {
		t.Fatalf("expected scheduler report ttl default 30s, got %s", got)
	}
	if got := cfg.Scheduler.BindingTTL; got != 30*time.Second {
		t.Fatalf("expected scheduler binding ttl default 30s, got %s", got)
	}
}

func TestLoadParsesSchedulerReportTTLDurationString(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"report_ttl": "45s",
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	cfg, err := Load(path, "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if got := cfg.Scheduler.ReportTTL; got != 45*time.Second {
		t.Fatalf("expected scheduler report ttl 45s, got %s", got)
	}
}

func TestLoadParsesSchedulerBindingTTLDurationString(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"binding_ttl": "75s",
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	cfg, err := Load(path, "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if got := cfg.Scheduler.BindingTTL; got != 75*time.Second {
		t.Fatalf("expected scheduler binding ttl 75s, got %s", got)
	}
}

func TestLoadParsesSchedulerArtifactStoreCapacity(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"artifact_store_capacity": 42,
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	cfg, err := Load(path, "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if got := cfg.Scheduler.ArtifactStoreCapacity; got != 42 {
		t.Fatalf("expected scheduler artifact store capacity 42, got %d", got)
	}
}

func TestLoadParsesSchedulerArtifactLookupNodeLimit(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"artifact_lookup_node_limit": 7,
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	cfg, err := Load(path, "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if got := cfg.Scheduler.ArtifactLookupNodeLimit; got != 7 {
		t.Fatalf("expected scheduler artifact lookup node limit 7, got %d", got)
	}
}

func TestLoadAllowsNonPositiveSchedulerArtifactLookupNodeLimit(t *testing.T) {
	for _, limit := range []int{0, -1} {
		tmpDir := t.TempDir()
		path := filepath.Join(tmpDir, "config.json")
		content := fmt.Sprintf(`{
			"scheduler": {
				"artifact_lookup_node_limit": %d,
				"nodes": [
					{"id": "node-a", "endpoint": "http://node-a:8000"}
				]
			}
		}`, limit)
		if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
			t.Fatalf("write config file failed: %v", err)
		}

		cfg, err := Load(path, "scheduler")
		if err != nil {
			t.Fatalf("load config failed for limit %d: %v", limit, err)
		}
		if got := cfg.Scheduler.ArtifactLookupNodeLimit; got != limit {
			t.Fatalf("expected scheduler artifact lookup node limit %d, got %d", limit, got)
		}
	}
}

func TestLoadRejectsNonIntegerSchedulerArtifactLookupNodeLimit(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"artifact_lookup_node_limit": "many",
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	_, err := Load(path, "scheduler")
	if err == nil {
		t.Fatal("expected load to fail for non-integer scheduler.artifact_lookup_node_limit")
	}
}

func TestLoadRejectsNonPositiveSchedulerArtifactStoreCapacity(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"artifact_store_capacity": 0,
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	_, err := Load(path, "scheduler")
	if err == nil {
		t.Fatal("expected load to fail for non-positive scheduler.artifact_store_capacity")
	}
}

func TestLoadRejectsNonIntegerSchedulerArtifactStoreCapacity(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"artifact_store_capacity": "many",
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	_, err := Load(path, "scheduler")
	if err == nil {
		t.Fatal("expected load to fail for non-integer scheduler.artifact_store_capacity")
	}
}

func TestLoadRejectsNumericSchedulerReportTTL(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"report_ttl": 30,
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	_, err := Load(path, "scheduler")
	if err == nil {
		t.Fatal("expected load to fail for numeric scheduler.report_ttl")
	}
}

func TestLoadRejectsNumericSchedulerBindingTTL(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"binding_ttl": 30,
			"nodes": [
				{"id": "node-a", "endpoint": "http://node-a:8000"}
			]
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	_, err := Load(path, "scheduler")
	if err == nil {
		t.Fatal("expected load to fail for numeric scheduler.binding_ttl")
	}
}

func TestLoadAppliesSchedulerBindingTTLEnvDuration(t *testing.T) {
	t.Setenv("SCHEDULER_BINDING_TTL", "45s")

	cfg, err := Load("", "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if cfg.Scheduler.BindingTTL != 45*time.Second {
		t.Fatalf("expected binding ttl 45s, got %s", cfg.Scheduler.BindingTTL)
	}
}

func TestLoadAppliesSchedulerArtifactStoreCapacityEnv(t *testing.T) {
	t.Setenv("SCHEDULER_ARTIFACT_STORE_CAPACITY", "123")

	cfg, err := Load("", "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if got := cfg.Scheduler.ArtifactStoreCapacity; got != 123 {
		t.Fatalf("expected artifact store capacity 123, got %d", got)
	}
}

func TestLoadAppliesSchedulerArtifactLookupNodeLimitEnv(t *testing.T) {
	t.Setenv("SCHEDULER_ARTIFACT_LOOKUP_NODE_LIMIT", "9")

	cfg, err := Load("", "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if got := cfg.Scheduler.ArtifactLookupNodeLimit; got != 9 {
		t.Fatalf("expected artifact lookup node limit 9, got %d", got)
	}
}

func TestLoadAllowsNonPositiveSchedulerArtifactLookupNodeLimitEnv(t *testing.T) {
	t.Setenv("SCHEDULER_ARTIFACT_LOOKUP_NODE_LIMIT", "-1")

	cfg, err := Load("", "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if got := cfg.Scheduler.ArtifactLookupNodeLimit; got != -1 {
		t.Fatalf("expected artifact lookup node limit -1, got %d", got)
	}
}

func TestLoadRejectsInvalidSchedulerArtifactLookupNodeLimitEnv(t *testing.T) {
	t.Setenv("SCHEDULER_ARTIFACT_LOOKUP_NODE_LIMIT", "many")

	_, err := Load("", "scheduler")
	if err == nil {
		t.Fatal("expected load to fail for invalid SCHEDULER_ARTIFACT_LOOKUP_NODE_LIMIT")
	}
}

func TestLoadRejectsInvalidSchedulerArtifactStoreCapacityEnv(t *testing.T) {
	t.Setenv("SCHEDULER_ARTIFACT_STORE_CAPACITY", "many")

	_, err := Load("", "scheduler")
	if err == nil {
		t.Fatal("expected load to fail for invalid SCHEDULER_ARTIFACT_STORE_CAPACITY")
	}
}

func TestLoadRejectsNonPositiveSchedulerArtifactStoreCapacityEnv(t *testing.T) {
	t.Setenv("SCHEDULER_ARTIFACT_STORE_CAPACITY", "0")

	_, err := Load("", "scheduler")
	if err == nil {
		t.Fatal("expected load to fail for non-positive SCHEDULER_ARTIFACT_STORE_CAPACITY")
	}
}

func TestLoadRejectsInvalidSchedulerBindingTTLEnvDuration(t *testing.T) {
	t.Setenv("SCHEDULER_BINDING_TTL", "45")

	_, err := Load("", "scheduler")
	if err == nil {
		t.Fatal("expected load to fail for invalid SCHEDULER_BINDING_TTL")
	}
}

func TestLoadAppliesSchedulerMetricsListenAddrEnv(t *testing.T) {
	t.Setenv("SCHEDULER_METRICS_LISTEN_ADDR", ":19101")

	cfg, err := Load("", "scheduler")
	if err != nil {
		t.Fatalf("load config failed: %v", err)
	}
	if cfg.Scheduler.MetricsListenAddr != ":19101" {
		t.Fatalf("expected scheduler metrics listen addr :19101, got %q", cfg.Scheduler.MetricsListenAddr)
	}
}

func TestLoadRejectsIncompleteKubernetesSchedulerDiscoveryConfig(t *testing.T) {
	tmpDir := t.TempDir()
	path := filepath.Join(tmpDir, "config.json")
	content := `{
		"scheduler": {
			"discovery": {
				"mode": "kubernetes",
				"kubernetes": {
					"namespace": "agentenv-system",
					"service_name": "",
					"port": 0
				}
			}
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write config file failed: %v", err)
	}

	if _, err := Load(path, "scheduler"); err == nil {
		t.Fatal("expected load to fail for incomplete kubernetes discovery config")
	}
}

func TestTLSConfigLoadAndEnvironmentOverrides(t *testing.T) {
	path := filepath.Join(t.TempDir(), "gateway.json")
	if err := os.WriteFile(path, []byte(`{"gateway":{
		"https_listen_addr":":9443",
		"tls":{"mode":"manual","cert_file":"cert.pem","key_file":"key.pem"}
	}}`), 0o600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path, "gateway")
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Gateway.TLS.Mode != "manual" || cfg.Gateway.TLS.CertFile != "cert.pem" || cfg.Gateway.HTTPSListenAddr != ":9443" {
		t.Fatalf("TLS configuration was not decoded: %+v", cfg.Gateway)
	}
	// Removed TLS environment overrides must not supersede the JSON mode.
	t.Setenv("GATEWAY_TLS_MODE", "acme")
	t.Setenv("GATEWAY_TLS_AGREE_TO_TERMS", "not-a-boolean")
	t.Setenv("GATEWAY_HTTPS_LISTEN_ADDR", ":8080")
	cfg, err = Load(path, "gateway")
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Gateway.TLS.Mode != "manual" || cfg.Gateway.TLS.CertFile != "cert.pem" || cfg.Gateway.HTTPSListenAddr != ":8080" {
		t.Fatalf("environment overrides were not applied: %+v", cfg.Gateway)
	}
}

func TestTLSConfigValidation(t *testing.T) {
	valid := func() Config {
		cfg := defaultConfig("gateway")
		cfg.Gateway.TLS = GatewayTLSConfig{
			Mode: "acme", Domains: []string{"api.example.com"},
			StorageDir: "/data/tls", Challenge: "tls-alpn-01",
		}
		return cfg
	}
	for _, tc := range []struct {
		name string
		edit func(*Config)
	}{
		{"unknown mode", func(c *Config) { c.Gateway.TLS.Mode = "auto" }},
		{"missing manual certificate", func(c *Config) { c.Gateway.TLS.Mode = "manual" }},
		{"missing domains", func(c *Config) { c.Gateway.TLS.Domains = nil }},
		{"missing storage", func(c *Config) { c.Gateway.TLS.StorageDir = "" }},
		{"bad listener", func(c *Config) { c.Gateway.HTTPSListenAddr = ":bad" }},
		{"bad port", func(c *Config) { c.Gateway.HTTPSListenAddr = ":65536" }},
		{"unsupported challenge", func(c *Config) { c.Gateway.TLS.Challenge = "http-01" }},
		{"missing DNS provider", func(c *Config) { c.Gateway.TLS.Challenge = "dns-01" }},
		{"wildcard without DNS", func(c *Config) { c.Gateway.TLS.Domains = []string{"*.example.com"} }},
		{"IP address", func(c *Config) { c.Gateway.TLS.Domains = []string{"127.0.0.1"} }},
		{"URL instead of domain", func(c *Config) { c.Gateway.TLS.Domains = []string{"https://example.com"} }},
		{"plaintext CA", func(c *Config) { c.Gateway.TLS.CA = "http://ca.example.com" }},
	} {
		t.Run(tc.name, func(t *testing.T) {
			cfg := valid()
			tc.edit(&cfg)
			if err := cfg.Validate(); err == nil {
				t.Fatal("invalid TLS configuration accepted")
			}
		})
	}
	cfg := valid()
	cfg.Gateway.HTTPListenAddr = ""
	if err := cfg.Validate(); err != nil {
		t.Fatal(err)
	}
	cfg = defaultConfig("gateway")
	if err := cfg.Validate(); err != nil || cfg.Gateway.TLS.Mode != "off" {
		t.Fatalf("default HTTP compatibility lost: %v", err)
	}
}

func TestACMEIPAddressValidation(t *testing.T) {
	for _, tc := range []struct {
		address string
		valid   bool
	}{
		{"8.8.8.8", true}, {"2606:4700:4700::1111", true},
		{"127.0.0.2", false}, {"10.1.2.3", false}, {"172.16.0.1", false},
		{"172.31.255.255", false}, {"192.168.1.10", false}, {"169.254.1.1", false},
		{"100.64.0.1", false}, {"100.127.255.255", false}, {"0.1.2.3", false},
		{"192.0.2.1", false}, {"198.51.100.1", false}, {"203.0.113.1", false},
		{"198.19.1.1", false}, {"224.0.0.1", false}, {"240.1.1.1", false},
		{"255.255.255.255", false}, {"::", false}, {"::1", false},
		{"fc00::1", false}, {"fe80::1", false}, {"ff02::1", false},
		{"2001:db8::1", false}, {"2002::1", false}, {"3fff::1", false},
		{"64:ff9b::808:808", false}, {"::ffff:8.8.8.8", false},
		{"::ffff:192.168.1.10", false}, {"fe80::1%eth0", false},
		{"8.8.8.8:8000", false}, {"[2606:4700:4700::1111]", false},
		{"*.8.8.8.8", false},
	} {
		t.Run(tc.address, func(t *testing.T) {
			cfg := defaultConfig("gateway")
			cfg.Gateway.TLS = GatewayTLSConfig{Mode: "acme", Domains: []string{tc.address}, StorageDir: "/data/tls", Challenge: "tls-alpn-01"}
			err := cfg.Validate()
			if (err == nil) != tc.valid {
				t.Fatalf("Validate(%q) = %v, want valid=%v", tc.address, err, tc.valid)
			}
			if tc.valid {
				cfg.Gateway.TLS.Challenge = "dns-01"
				cfg.Gateway.TLS.DNSProvider = "cloudflare"
				cfg.Gateway.TLS.DNSConfig = []byte(`{"api_token":"test-token"}`)
				if cfg.Validate() == nil {
					t.Fatal("DNS-01 accepted an IP identifier")
				}
			}
			cfg.Gateway.TLS = GatewayTLSConfig{Mode: "manual", CertFile: "cert.pem", KeyFile: "key.pem", Domains: []string{tc.address}}
			if err := cfg.Validate(); err != nil {
				t.Fatalf("manual certificates should not use public-issuance checks: %v", err)
			}
		})
	}
}

func TestACMERejectsAmbiguousMultipleIPs(t *testing.T) {
	cfg := defaultConfig("gateway")
	cfg.Gateway.TLS = GatewayTLSConfig{Mode: "acme", Domains: []string{"8.8.8.8", "1.1.1.1"}, StorageDir: "/data/tls"}
	if cfg.Validate() == nil {
		t.Fatal("multiple IP identities on a single listener accepted")
	}
	cfg.Gateway.TLS.Domains = []string{"api.example.com", "8.8.8.8"}
	if err := cfg.Validate(); err != nil {
		t.Fatal(err)
	}
}

func TestDNSConfigJSONAndRedaction(t *testing.T) {
	path := filepath.Join(t.TempDir(), "gateway.json")
	data := []byte(`{"gateway":{"tls":{"mode":"acme","domains":["*.example.com"],"storage_dir":"/data/tls","challenge":"dns-01","dns_provider":"cloudflare","dns_config":{"api_token":"test-secret"}}}}`)
	if err := os.WriteFile(path, data, 0600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path, "gateway")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(cfg.Gateway.TLS.DNSConfig), "test-secret") {
		t.Fatal("DNS config not loaded")
	}
	for _, value := range []any{cfg, cfg.Gateway, cfg.Gateway.TLS} {
		encoded, err := json.Marshal(value)
		if err != nil {
			t.Fatal(err)
		}
		if strings.Contains(string(encoded), "test-secret") || strings.Contains(string(encoded), "dns_config") {
			t.Fatal("DNS credentials were serialized")
		}
	}
}

func TestDNSConfigValidation(t *testing.T) {
	for _, tc := range []struct {
		name, provider, raw, challenge string
		valid                          bool
	}{
		{"cloudflare", "cloudflare", `{"api_token":"test"}`, "dns-01", true},
		{"alidns", "alidns", `{}`, "dns-01", true},
		{"tencentcloud", "tencentcloud", `{}`, "dns-01", true},
		{"aws role", "route53", `{}`, "dns-01", true},
		{"unknown", "unknown", `{}`, "dns-01", false},
		{"missing config", "cloudflare", ``, "dns-01", false},
		{"null", "cloudflare", `null`, "dns-01", false},
		{"array", "cloudflare", `[]`, "dns-01", false},
		{"alpn config", "", `{}`, "tls-alpn-01", false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			cfg := defaultConfig("gateway")
			cfg.Gateway.TLS = GatewayTLSConfig{Mode: "acme", Domains: []string{"example.com"}, StorageDir: "/data/tls", Challenge: tc.challenge, DNSProvider: tc.provider, DNSConfig: []byte(tc.raw)}
			if err := cfg.Validate(); (err == nil) != tc.valid {
				t.Fatalf("unexpected validation result: %v", err)
			}
		})
	}
}
