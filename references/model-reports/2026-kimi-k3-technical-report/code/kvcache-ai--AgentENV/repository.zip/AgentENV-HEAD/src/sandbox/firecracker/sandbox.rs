use std::fs;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use anyhow::{bail, Context, Result};
use async_trait::async_trait;
use firecracker_client::models::drive::IoEngine;
use nix::libc;
use tempfile::TempDir;
use tracing::{debug, trace, warn};
use uuid::Uuid;
use uvm_ublk_daemon::CreateOverlaybdRuntimeDeviceRequest;

use super::config::{
    create_firecracker_work_dir, logging_enabled, FirecrackerCommonConfig,
    FirecrackerRuntimePolicy, FirecrackerSandboxConfig, FirecrackerSnapshotConfig,
    PersistentSnapshotRootGuard, MAX_EXTRA_DRIVES,
};
use super::mmds::MmdsMetadata;
use super::overlaybd_snapshot::{
    build_mem_snapshot_image_config, convert_dirty_memory_to_overlaybd,
    restack_snapshot_overlaybd_device, restack_snapshot_overlaybd_rootfs,
};
use super::pool::{warm_stdio_paths, FirecrackerPool};
use super::resources::SandboxResources;
use super::FirecrackerInstance;
use crate::sandbox::custom_extension::{
    CustomExtensionClient, CustomExtensionHookGuard, CustomExtensionParams,
};
use crate::snapshot::SandboxSnapshotManifest;

use crate::cfg::ConfigManager;
use crate::overlaybd::OverlaybdCompactOutput;
use crate::sandbox::access::EnvdAccessToken;
use crate::sandbox::backend::{
    CapturedSandboxSnapshot, PausedSandboxState, SandboxBackend, SandboxCaptureError,
    SandboxCaptureResult, SandboxExecutor, SandboxForkResult, SandboxForkSpec, SandboxRuntimeInfo,
};
use crate::sandbox::envd::EnvdInstance;
use crate::sandbox::extra_drive::{prepare_extra_drives, DriveMount, ExtraDrivePrepareMode};
use crate::sandbox::guest_volumes;
use crate::sandbox::network::{NetworkManager, SandboxNetworkPolicy, Slot};
use crate::sandbox::process::Executor;
use crate::sandbox::ublk::{
    OverlaybdConfig, OverlaybdRuntimeHandle, PackRecordingWindow, UblkBackend, UblkCreateSpec,
    UblkDeviceManager,
};
use crate::sandbox::SandboxLaunchConfig;
use crate::snapshot::RunnableSnapshot;
use crate::types::{
    ExtraDrive, ExtraDriveKind, RuntimeArtifactSet, SandboxId, ROOTFS_DRIVE_ID,
    USER_ROOTFS_DRIVE_ID, VOLUME_DRIVE_SLOT_PREFIX,
};

// ── Constants ────────────────────────────────────────────────────────────────

const VM_STATE_FILE_NAME: &str = "vm_state.bin";
const ROOTFS_DRIVE_PATH: &str = "rootfs.ext4";
const USER_ROOTFS_DRIVE_PATH: &str = "user-rootfs";
/// Guest userspace (e.g. systemd-udevd's `MACAddressPolicy=`) may change eth0's
/// MAC after boot; without a gratuitous ARP the tap0 neighbour entry goes stale.
const GUEST_ARP_NOTIFY_BOOT_ARG: &str = "sysctl.net.ipv4.conf.all.arp_notify=1";

/// Firecracker's `TokenBucket::size` is the number of tokens replenished every
/// `refill_time`, not a per-second rate. Pinning the refill period to 1000 ms
/// makes the configured `*_per_sec` values equal the sustained per-second rate.
const RATE_LIMIT_REFILL_TIME_MS: i64 = 1000;

fn bandwidth_bucket(
    cfg: &crate::cfg::DiskRateLimitConfig,
) -> Result<Option<Box<firecracker_client::models::TokenBucket>>> {
    if cfg.bandwidth_bytes_per_sec == 0 {
        return Ok(None);
    }
    let size = i64::try_from(cfg.bandwidth_bytes_per_sec)
        .context("disk bandwidth_bytes_per_sec exceeds Firecracker's i64 range")?;
    let mut bw = firecracker_client::models::TokenBucket::new(RATE_LIMIT_REFILL_TIME_MS, size);
    if cfg.bandwidth_burst_bytes > 0 {
        bw.one_time_burst = Some(
            i64::try_from(cfg.bandwidth_burst_bytes)
                .context("disk bandwidth_burst_bytes exceeds Firecracker's i64 range")?,
        );
    }
    Ok(Some(Box::new(bw)))
}

fn ops_bucket(
    cfg: &crate::cfg::DiskRateLimitConfig,
) -> Result<Option<Box<firecracker_client::models::TokenBucket>>> {
    if cfg.iops == 0 {
        return Ok(None);
    }
    let size = i64::try_from(cfg.iops).context("disk iops exceeds Firecracker's i64 range")?;
    let mut ops = firecracker_client::models::TokenBucket::new(RATE_LIMIT_REFILL_TIME_MS, size);
    if cfg.iops_burst > 0 {
        ops.one_time_burst = Some(
            i64::try_from(cfg.iops_burst)
                .context("disk iops_burst exceeds Firecracker's i64 range")?,
        );
    }
    Ok(Some(Box::new(ops)))
}

/// Build the limiter attached to the user rootfs drive at fresh boot (pre-boot
/// `PUT /drives`). Returns `None` when limiting is disabled or no dimension is
/// configured, in which case the drive is added with no limiter.
fn build_disk_rate_limiter(
    cfg: &crate::cfg::DiskRateLimitConfig,
) -> Result<Option<Box<firecracker_client::models::RateLimiter>>> {
    if !cfg.enabled {
        return Ok(None);
    }
    let bandwidth = bandwidth_bucket(cfg)?;
    let ops = ops_bucket(cfg)?;
    if bandwidth.is_none() && ops.is_none() {
        return Ok(None);
    }
    let mut rl = firecracker_client::models::RateLimiter::new();
    rl.bandwidth = bandwidth;
    rl.ops = ops;
    Ok(Some(Box::new(rl)))
}

/// A token bucket Firecracker interprets as "disable this dimension".
///
/// Firecracker's `PATCH /drives` maps an *absent* token bucket to
/// `BucketUpdate::None` (leave unchanged), so a snapshot-inherited limit cannot
/// be removed by omission. The explicit disable sentinel is a bucket with both
/// `size == 0` and `refill_time == 0`; a mixed bucket (e.g. `size == 0`,
/// `refill_time == 1`) is not the sentinel and can be rejected as an invalid
/// token bucket, failing the resume PATCH. Send both fields as zero.
fn disabled_bucket() -> Box<firecracker_client::models::TokenBucket> {
    Box::new(firecracker_client::models::TokenBucket::new(0, 0))
}

/// Build the limiter to PATCH on resume, reconciling a snapshot-inherited
/// limiter against the node's current config. BOTH buckets are always present:
/// a configured dimension uses its own bucket, an unset dimension is overwritten
/// with a disabled (`size == 0`) bucket so any inherited limit on that dimension
/// is cleared (an omitted bucket would instead be left unchanged; see
/// [`disabled_bucket`]).
fn reconcile_disk_rate_limiter(
    cfg: &crate::cfg::DiskRateLimitConfig,
) -> Result<Box<firecracker_client::models::RateLimiter>> {
    let (bandwidth, ops) = if cfg.enabled {
        (bandwidth_bucket(cfg)?, ops_bucket(cfg)?)
    } else {
        (None, None)
    };
    let mut rl = firecracker_client::models::RateLimiter::new();
    rl.bandwidth = Some(bandwidth.unwrap_or_else(disabled_bucket));
    rl.ops = Some(ops.unwrap_or_else(disabled_bucket));
    Ok(Box::new(rl))
}

pub(super) fn managed_snapshot_base() -> PathBuf {
    ConfigManager::global_config()
        .firecracker
        .work_dir
        .clone()
        .unwrap_or_else(|| std::env::temp_dir().join("aenv"))
        .join("managed-snapshots")
}

const VOLUME_DRIVE_PLACEHOLDER_SIZE: u64 = 4096;

fn volume_drive_slot_id(index: usize) -> String {
    format!("{VOLUME_DRIVE_SLOT_PREFIX}{index}")
}

// ── FirecrackerSandbox ───────────────────────────────────────────────────────

/// A Firecracker microVM-backed sandbox instance.
///
/// Internal state is managed via the high-level lifecycle methods.
/// Implements [`SandboxBackend`] for use by the Orchestrator.
pub struct FirecrackerSandbox {
    id: SandboxId,
    launch: LaunchMode,
    work_dir: TempDir,
    fc_instance: FirecrackerInstance,
    runtime_policy: FirecrackerRuntimePolicy,
    resources: SandboxResources,
    current_network_policy: Option<SandboxNetworkPolicy>,
    /// Current custom extension params. Initialized from the launch config and
    /// updated via `update_custom_extension_params`; persisted into snapshots
    /// on pause.
    current_custom_extension_params: Option<CustomExtensionParams>,
    envd_instance: Option<EnvdInstance>,
    frozen_volume_mounts: Vec<(PathBuf, String)>,
    /// Drives added to a committed snapshot at launch time are not represented
    /// in its guest mount namespace, and fresh read-only volumes must not be
    /// mounted by init. Mount only those drives after envd is ready;
    /// paused-state resumes must preserve the captured mount state.
    initial_guest_drive_mounts: Vec<(usize, ExtraDrive)>,
    current_rootfs_virtual_size: Option<u64>,
    live_snapshot_root: Option<Arc<PersistentSnapshotRootGuard>>,
}

// ── SandboxBackend impl ──────────────────────────────────────────────────────

/// Firecracker-specific capture payload carried as [`CapturedSandboxSnapshot`]
/// artifacts: what startup-pack recording needs to re-boot from the capture
/// while the layers are still node-local, plus the lease keeping the capture
/// directory alive for the detached recording/upload continuation.
#[derive(Debug)]
pub struct FirecrackerCaptureArtifacts {
    snapshot_config: FirecrackerSnapshotConfig,
    snapshot_dir: PathBuf,
    snapshot_root: Arc<PersistentSnapshotRootGuard>,
}

#[derive(Clone, Debug)]
pub struct FirecrackerPausedState {
    snapshot_config: FirecrackerSnapshotConfig,
}

impl FirecrackerPausedState {
    pub fn new(snapshot_config: FirecrackerSnapshotConfig) -> Self {
        Self { snapshot_config }
    }

    pub fn decode(_artifact_root: PathBuf, state: serde_json::Value) -> Result<Self> {
        let snapshot_config: FirecrackerSnapshotConfig =
            serde_json::from_value(state).context("deserialize Firecracker paused state")?;
        snapshot_config
            .validate_persisted()
            .context("validate Firecracker paused state artifacts")?;
        Ok(Self::new(snapshot_config))
    }

    pub fn snapshot_config(&self) -> &FirecrackerSnapshotConfig {
        &self.snapshot_config
    }
}

impl PausedSandboxState for FirecrackerPausedState {
    fn control_plane_port(&self) -> Option<u16> {
        let port = self.snapshot_config.common.control_plane_port;
        (port != 0).then_some(port)
    }

    fn encode(&self) -> Result<serde_json::Value> {
        serde_json::to_value(&self.snapshot_config).context("serialize Firecracker paused state")
    }

    fn runtime_artifacts(&self) -> RuntimeArtifactSet {
        RuntimeArtifactSet::from_overlaybd_image_configs(rootfs_and_extra_drive_image_config_paths(
            &self.snapshot_config.common,
        ))
    }
}

impl FirecrackerCaptureArtifacts {
    pub(crate) fn new(
        snapshot_config: FirecrackerSnapshotConfig,
        snapshot_dir: PathBuf,
        snapshot_root: Arc<PersistentSnapshotRootGuard>,
    ) -> Self {
        Self {
            snapshot_config,
            snapshot_dir,
            snapshot_root,
        }
    }

    /// The snapshot config produced at capture time (identical memory/rootfs
    /// layout to what publish exports). Startup-pack recording re-boots from
    /// it while the layers are still node-local.
    pub fn snapshot_config(&self) -> &FirecrackerSnapshotConfig {
        &self.snapshot_config
    }

    /// Directory holding this capture's artifacts (vm_state.bin's parent).
    pub fn snapshot_dir(&self) -> &Path {
        &self.snapshot_dir
    }

    /// Clone of the lease keeping the capture directory alive. Moved into
    /// the detached startup-manifest recording/upload task, which can
    /// outlive the synchronous publish flow.
    pub(crate) fn snapshot_root_guard(&self) -> Arc<PersistentSnapshotRootGuard> {
        Arc::clone(&self.snapshot_root)
    }
}

fn snapshot_config_for_fork(
    source: &FirecrackerSnapshotConfig,
    child: &SandboxForkSpec,
) -> Result<FirecrackerSnapshotConfig> {
    let mut snapshot = source.clone();
    if child.replace_drive_ids.is_empty() && child.extra_drives.is_empty() {
        return Ok(snapshot);
    }
    let mut replacement_ids = std::collections::HashSet::new();
    for (drive_id, replacement_id) in &child.replace_drive_ids {
        anyhow::ensure!(
            replacement_ids.insert(replacement_id.clone()),
            "duplicate fork replacement drive {}",
            replacement_id
        );
        let replacement = child
            .extra_drives
            .iter()
            .find(|drive| drive.drive_id() == replacement_id)
            .ok_or_else(|| anyhow::anyhow!("missing fork replacement drive {replacement_id}"))?;
        let index = snapshot
            .common
            .extra_drives
            .iter()
            .position(|drive| drive.drive_id() == drive_id)
            .ok_or_else(|| anyhow::anyhow!("fork source drive {drive_id} does not exist"))?;
        snapshot.common.extra_drives[index] = replacement.clone();
    }
    for drive in &child.extra_drives {
        anyhow::ensure!(
            snapshot
                .common
                .extra_drives
                .iter()
                .any(|existing| existing.drive_id() == drive.drive_id()),
            "fork cannot append drive {} to captured Firecracker state",
            drive.drive_id()
        );
    }
    Ok(snapshot)
}

#[async_trait]
impl SandboxBackend for FirecrackerSandbox {
    fn envd(&self) -> Option<Arc<dyn crate::sandbox::EnvdApi>> {
        let envd = self.envd_instance.clone()?;
        Some(Arc::new(envd))
    }

    async fn start(&mut self) -> Result<()> {
        FirecrackerSandbox::start(self).await
    }

    async fn start_nowait(&mut self) -> Result<()> {
        FirecrackerSandbox::start_nowait(self).await
    }

    async fn wait_for_ready(&self) -> Result<()> {
        FirecrackerSandbox::wait_for_ready(self).await
    }

    /// Pauses the VM and returns the paused state wrapped as a [`PausedSandboxState`].
    async fn pause(
        &mut self,
        artifact_root: Option<&Path>,
    ) -> SandboxCaptureResult<Arc<dyn PausedSandboxState>> {
        let pause_result = match artifact_root {
            Some(artifact_root) => FirecrackerSandbox::pause_to_dir(self, artifact_root)
                .await
                .map(|(snapshot_config, _)| snapshot_config),
            None => FirecrackerSandbox::pause(self).await,
        };
        let snapshot_config = match pause_result {
            Ok(snapshot_config) => snapshot_config,
            Err(error) => return self.recover_capture_failure("pause", error).await,
        };
        Ok(Arc::new(FirecrackerPausedState::new(snapshot_config)))
    }

    async fn snapshot(&mut self) -> SandboxCaptureResult<CapturedSandboxSnapshot> {
        let live_snapshot_root = self
            .live_snapshot_root()
            .await
            .map_err(SandboxCaptureError::from)?;
        let snapshot_dir = live_snapshot_root.path().join(Uuid::now_v7().to_string());

        let (snapshot_config, manifest) = match self.pause_to_dir(&snapshot_dir).await {
            Ok(snapshot) => snapshot,
            Err(error) => {
                return self
                    .recover_capture_failure("snapshot capture", error)
                    .await
            }
        };
        FirecrackerSandbox::resume(self)
            .await
            .map_err(SandboxCaptureError::terminal)?;

        Ok(CapturedSandboxSnapshot::new(
            manifest,
            FirecrackerCaptureArtifacts::new(snapshot_config, snapshot_dir, live_snapshot_root),
        ))
    }

    async fn capture_to_dir(
        &mut self,
        at: &Path,
    ) -> SandboxCaptureResult<(
        SandboxSnapshotManifest,
        Option<Box<dyn std::any::Any + Send>>,
    )> {
        match self.pause_to_dir(at).await {
            Ok((snapshot_config, manifest)) => Ok((manifest, Some(Box::new(snapshot_config)))),
            Err(error) => self.recover_capture_failure("capture", error).await,
        }
    }

    async fn snapshot_volumes(&mut self) -> SandboxCaptureResult<()> {
        if !self.has_writable_persistent_volumes() {
            return Ok(());
        }

        let envd = self
            .envd_instance
            .clone()
            .context("cannot flush writable volumes because envd is not running")
            .map_err(SandboxCaptureError::recoverable)?;
        guest_volumes::sync_writable_volume_filesystems(envd)
            .await
            .map_err(SandboxCaptureError::recoverable)?;

        if let Err(error) = self.fc_instance.pause().await {
            return self.recover_capture_failure("volume snapshot", error).await;
        }

        if let Err(error) = self.snapshot_persistent_volume_drives().await {
            return self.recover_capture_failure("volume snapshot", error).await;
        }

        FirecrackerSandbox::resume(self)
            .await
            .map_err(SandboxCaptureError::terminal)
    }

    async fn fork(
        &mut self,
        spec: &[SandboxForkSpec],
    ) -> SandboxCaptureResult<Vec<SandboxForkResult>> {
        let snapshot_config = match FirecrackerSandbox::pause(self).await {
            Ok(snapshot_config) => snapshot_config,
            Err(error) => return self.recover_capture_failure("fork snapshot", error).await,
        };

        FirecrackerSandbox::resume(self)
            .await
            .map_err(SandboxCaptureError::terminal)?;

        let children = spec
            .iter()
            .map(|child| {
                let physical_count = snapshot_config.common.physical_extra_drive_count;
                if child.replace_drive_ids.iter().any(|(drive_id, _)| {
                    snapshot_config
                        .common
                        .extra_drives
                        .iter()
                        .take(physical_count)
                        .any(|drive| drive.drive_id() == drive_id)
                }) {
                    return Err(anyhow::anyhow!(
                        "fork replacement drives must refer to launch-time volume drives"
                    ));
                }
                let child_snapshot_config = snapshot_config_for_fork(&snapshot_config, child)?;
                Self::from_snapshot_config_with_override(
                    child_snapshot_config,
                    child.sandbox_id,
                    child.envd_access_token.clone(),
                )
                .map(|child| Box::new(child) as Box<dyn SandboxBackend>)
                .context("build forked sandbox")
            })
            .collect::<Vec<_>>();

        let start_results = futures::future::join_all(children.into_iter().map(|child| {
            async move {
                let mut child = child?;
                match child.start().await {
                    Ok(()) => Ok(child),
                    Err(err) => {
                        if let Err(stop_err) = child.stop().await {
                            warn!(error = ?stop_err, "failed to stop fork child after start failure");
                        }
                        Err(err.context("start forked sandbox"))
                    }
                }
            }
        }))
        .await;
        Ok(start_results)
    }

    async fn resume(&mut self) -> Result<()> {
        FirecrackerSandbox::resume(self).await
    }

    async fn stop(&mut self) -> Result<()> {
        FirecrackerSandbox::stop(self).await
    }

    async fn freeze_and_snapshot_volumes(&mut self) -> SandboxCaptureResult<()> {
        let started = std::time::Instant::now();
        let result = async {
            let mounts = self
                .launch
                .common()
                .extra_drives
                .iter()
                .filter(|drive| !drive.read_only() && drive.snapshot_output_dir().is_some())
                .map(|drive| drive.mount_path().to_path_buf())
                .collect::<Vec<_>>();
            for mount in mounts {
                // An RPC failure leaves the ioctl's outcome unknown, so the VM
                // cannot safely be returned to service in that case.
                // Record the mount before awaiting so cancellation leaves a
                // thaw obligation on the owned sandbox handle.
                self.frozen_volume_mounts
                    .push((mount.clone(), String::new()));
                let output = self
                    .set_volume_freeze(&mount, None)
                    .await
                    .map_err(SandboxCaptureError::terminal)?;
                if output.exit_code != 0 {
                    self.frozen_volume_mounts.pop();
                    anyhow::bail!(
                        "freeze volume {} failed: {}",
                        mount.display(),
                        output.stderr.trim()
                    );
                }
                self.frozen_volume_mounts.last_mut().unwrap().1 = output.stdout.trim().to_owned();
            }
            self.snapshot_persistent_volume_drives().await?;
            Ok::<(), anyhow::Error>(())
        }
        .await;
        if let Err(error) = result {
            let error = SandboxCaptureError::from(error);
            if !error.is_terminal() {
                self.thaw_volumes().await.map_err(|thaw_error| {
                    SandboxCaptureError::terminal(anyhow::anyhow!(
                        "volume capture failed: {error}; thaw failed: {thaw_error:#}"
                    ))
                })?;
            }
            return Err(error);
        }
        debug!(
            elapsed_ms = started.elapsed().as_millis(),
            "volume filesystems frozen and sealed"
        );
        Ok(())
    }

    async fn thaw_volumes(&mut self) -> Result<()> {
        while let Some((mount, device)) = self.frozen_volume_mounts.last().cloned() {
            let output = self.set_volume_freeze(&mount, Some(&device)).await?;
            anyhow::ensure!(
                output.exit_code == 0,
                "thaw volume {} failed: {}",
                mount.display(),
                output.stderr.trim()
            );
            self.frozen_volume_mounts.pop();
        }
        Ok(())
    }

    fn host_interaction_ip(&self) -> Option<std::net::Ipv4Addr> {
        FirecrackerSandbox::host_interaction_ip(self)
    }

    fn runtime_info(&self) -> SandboxRuntimeInfo {
        SandboxRuntimeInfo {
            rootfs_virtual_size: self.current_rootfs_virtual_size,
            runtime_artifacts: RuntimeArtifactSet::from_overlaybd_image_configs(
                self.runtime_image_config_paths(),
            ),
        }
    }

    fn startup_artifacts(&self) -> RuntimeArtifactSet {
        let common = match &self.launch {
            LaunchMode::Fresh(config) => &config.common,
            LaunchMode::Resume(config) => &config.common,
        };
        RuntimeArtifactSet::from_overlaybd_image_configs(rootfs_and_extra_drive_image_config_paths(
            common,
        ))
    }

    async fn update_network_policy(&mut self, policy: Option<SandboxNetworkPolicy>) -> Result<()> {
        if let Some(slot) = self.resources.network_slot.as_mut() {
            slot.set_egress_policy(policy.as_ref())
                .context("configure sandbox network policy")?;
            self.current_network_policy = policy;
            Ok(())
        } else if policy.is_none() {
            self.current_network_policy = policy;
            Ok(())
        } else {
            bail!("sandbox has no active network slot")
        }
    }

    fn update_custom_extension_params(&mut self, params: Option<CustomExtensionParams>) {
        self.current_custom_extension_params = params;
    }
}

// ── SandboxExecutor impl ──────────────────────────────────────────────────────

#[async_trait(?Send)]
impl SandboxExecutor for FirecrackerSandbox {
    fn executor(&self) -> Result<Executor> {
        let envd = self
            .envd_instance
            .as_ref()
            .context("Sandbox is not running")?;
        Ok(Executor::new(envd.clone()))
    }
}

// ── FirecrackerSandbox public API ────────────────────────────────────────────

impl FirecrackerSandbox {
    /// Identity of this sandbox, including for capture provenance.
    pub fn sandbox_id(&self) -> SandboxId {
        self.id
    }

    async fn recover_capture_failure<T>(
        &mut self,
        operation: &'static str,
        error: anyhow::Error,
    ) -> SandboxCaptureResult<T> {
        let capture_error = SandboxCaptureError::from(error);
        if capture_error.is_terminal() {
            return Err(capture_error);
        }
        if let Err(resume_error) = FirecrackerSandbox::resume(self).await {
            return Err(SandboxCaptureError::terminal(anyhow::anyhow!(
                "{operation} failed and sandbox could not be resumed: {capture_error}; resume error: {resume_error:#}"
            )));
        }
        Err(capture_error)
    }

    fn snapshot_rootfs_virtual_size(&self) -> Result<u64> {
        self.current_rootfs_virtual_size.context(
            "rootfs virtual size cache missing; sandbox must record the user image block-device size before snapshot; ensure start() was called before pause() or snapshot",
        )
    }

    /// Create a sandbox handle for a fresh boot.
    ///
    /// This does not start Firecracker; it only prepares the object and its
    /// per-instance work directory.
    pub fn new(config: FirecrackerSandboxConfig) -> Result<Self> {
        Self::new_with_id(config, SandboxId::new())
    }

    pub(crate) fn new_with_id(mut config: FirecrackerSandboxConfig, id: SandboxId) -> Result<Self> {
        let (mut physical_drives, mut volume_drives): (Vec<_>, Vec<_>) =
            std::mem::take(&mut config.common.extra_drives)
                .into_iter()
                .partition(|drive| !drive.uses_reserved_slot());
        // Committed slot drives must take the first slots, before volumes.
        volume_drives.sort_by_key(ExtraDrive::is_volume);
        config.common.physical_extra_drive_count = physical_drives.len();
        config.common.volume_drive_slots = ConfigManager::global_config()
            .volume
            .max_volume_count
            .min(MAX_EXTRA_DRIVES.saturating_sub(config.common.physical_extra_drive_count));
        anyhow::ensure!(
            volume_drives.len() <= config.common.volume_drive_slots,
            "fresh sandbox has {} volumes but only {} reserved volume slots",
            volume_drives.len(),
            config.common.volume_drive_slots
        );
        physical_drives.extend(volume_drives);
        config.common.extra_drives = physical_drives;
        let initial_guest_drive_mounts = config
            .common
            .extra_drives
            .iter()
            .cloned()
            .enumerate()
            .filter(|(_, drive)| mounts_after_boot(drive))
            .collect();
        debug!(
            firecracker_binary = %config.common.firecracker_binary.display(),
            kernel_image = %config.kernel_image.display(),
            tools_drive_version = %config.common.tools_drive_version,
            "creating fresh firecracker sandbox"
        );
        let mut sandbox = Self::build(id, LaunchMode::Fresh(config))?;
        sandbox.initial_guest_drive_mounts = initial_guest_drive_mounts;
        Ok(sandbox)
    }

    /// Create a sandbox handle that resumes from the provided snapshot config.
    ///
    /// This only prepares the sandbox object and its per-instance workspace.
    /// Call [`FirecrackerSandbox::start`] or [`FirecrackerSandbox::start_nowait`] to boot it.
    #[tracing::instrument(skip(snapshot))]
    pub fn from_snapshot_config(snapshot: &FirecrackerSnapshotConfig) -> Result<Self> {
        Self::from_snapshot_config_with_override(
            snapshot.clone(),
            SandboxId::new(),
            snapshot.common.envd_access_token.clone(),
        )
    }

    /// The dedicated pack-recording memory device's id, when this sandbox was
    /// started with `pack_recording = true`.
    pub(crate) fn dedicated_mem_device_id(&self) -> Option<u32> {
        self.resources
            .mem_dedicated_device
            .as_ref()
            .map(|device| device.dev_id())
    }

    pub(crate) fn from_snapshot_config_with_override(
        mut snapshot: FirecrackerSnapshotConfig,
        id: SandboxId,
        envd_access_token: Option<EnvdAccessToken>,
    ) -> Result<Self> {
        if snapshot.common.volume_drive_slots == 0 {
            // Legacy snapshots contain every configured extra drive directly.
            snapshot.common.physical_extra_drive_count = snapshot.common.extra_drives.len();
        }
        anyhow::ensure!(
            snapshot.common.physical_extra_drive_count <= snapshot.common.extra_drives.len(),
            "snapshot records {} physical extra drives but only {} logical drives",
            snapshot.common.physical_extra_drive_count,
            snapshot.common.extra_drives.len()
        );
        anyhow::ensure!(
            snapshot.common.extra_drives.len() - snapshot.common.physical_extra_drive_count
                <= snapshot.common.volume_drive_slots,
            "snapshot has {} launch-time volume drives but only {} reserved drive slots",
            snapshot.common.extra_drives.len() - snapshot.common.physical_extra_drive_count,
            snapshot.common.volume_drive_slots
        );
        // Restore with the node's current runtime, matching the prewarmed pool.
        // Captured guest assets remain unchanged.
        snapshot.common.firecracker_binary =
            ConfigManager::global_config().resolved_firecracker_binary_path();
        // Runtime identity and auth override their values in the source snapshot.
        snapshot.common.envd_access_token = envd_access_token;
        let FirecrackerCommonConfig {
            mmds_metadata,
            envd_access_token,
            ..
        } = &mut snapshot.common;
        let metadata = mmds_metadata.get_or_insert_with(|| MmdsMetadata::new(id, "unknown"));
        metadata.sandbox_id = id.to_string();
        metadata.set_access_token(envd_access_token.as_ref());

        debug!(
            vm_state_path = %snapshot.vm_state_path.display(),
            mem_image_config_path = %snapshot.mem_overlaybd_config.image_config_path.display(),
            rootfs_path = ?snapshot.common.rootfs_image_config.as_ref().map(|rootfs| &rootfs.image_config_path),
            tools_drive_version = %snapshot.common.tools_drive_version,
            "creating firecracker sandbox from snapshot config"
        );
        Self::build(id, LaunchMode::Resume(snapshot))
    }

    /// Create a sandbox handle that boots from a resolved runnable committed snapshot.
    ///
    /// This only prepares the sandbox object and its per-instance workspace.
    /// Call [`FirecrackerSandbox::start`] or [`FirecrackerSandbox::start_nowait`] to boot it.
    pub fn from_snapshot(
        snapshot: &RunnableSnapshot,
        launch_config: &SandboxLaunchConfig,
    ) -> Result<Self> {
        let snapshot_config = Self::snapshot_config_for_launch(snapshot, launch_config)?;
        let initial_guest_drive_mounts =
            Self::initial_guest_drive_mounts_for_snapshot_launch(&snapshot_config, launch_config);
        let mut sandbox = Self::build(
            launch_config.sandbox_id,
            LaunchMode::Resume(snapshot_config),
        )?;
        sandbox.initial_guest_drive_mounts = initial_guest_drive_mounts;
        Ok(sandbox)
    }

    fn initial_guest_drive_mounts_for_snapshot_launch(
        snapshot_config: &FirecrackerSnapshotConfig,
        launch_config: &SandboxLaunchConfig,
    ) -> Vec<(usize, ExtraDrive)> {
        if launch_config.extra_drives_in_snapshot {
            return Vec::new();
        }

        // Launch-time drives follow the snapshot's own drives.
        let first_slot_index =
            snapshot_config.common.extra_drives.len() - launch_config.extra_drives.len();
        launch_config
            .extra_drives
            .iter()
            .cloned()
            .enumerate()
            .map(|(index, drive)| (first_slot_index + index, drive))
            .collect()
    }

    fn snapshot_config_for_launch(
        snapshot: &RunnableSnapshot,
        launch_config: &SandboxLaunchConfig,
    ) -> Result<FirecrackerSnapshotConfig> {
        let mut snapshot_config = FirecrackerSnapshotConfig::from_runnable_snapshot(snapshot)?;
        let free_slots = snapshot.manifest().free_drive_slots();
        anyhow::ensure!(
            launch_config.extra_drives.len() <= free_slots,
            "snapshot supports at most {} launch-time drives, requested {}",
            free_slots,
            launch_config.extra_drives.len()
        );
        anyhow::ensure!(
            launch_config
                .extra_drives
                .iter()
                .all(ExtraDrive::uses_reserved_slot)
                && launch_config
                    .extra_drives
                    .is_sorted_by_key(ExtraDrive::is_volume),
            "launch-time drives must use reserved slots, with attached drives before volumes"
        );
        snapshot_config
            .common
            .extra_drives
            .extend(launch_config.extra_drives.clone());
        snapshot_config.common.mmds_metadata = Some(
            MmdsMetadata::new(launch_config.sandbox_id, launch_config.snapshot_id.clone())
                .with_access_token(launch_config.envd_access_token.as_ref())
                .with_extra(launch_config.extra_mmds.clone()),
        );
        snapshot_config.common.envd_access_token = launch_config.envd_access_token.clone();
        snapshot_config.common.network_policy = launch_config.network.clone();

        // Launch-provided custom config overrides the value persisted in the
        // source snapshot; otherwise inherit the snapshot's.
        snapshot_config.common.custom_extension_params = launch_config
            .custom_extension_params
            .clone()
            .or_else(|| snapshot.committed().custom_extension_params.clone());

        if let Some(launch_env_vars) = &launch_config.env_vars {
            snapshot_config
                .common
                .env_vars
                .get_or_insert_default()
                .extend(launch_env_vars.clone());
        }

        Ok(snapshot_config)
    }

    /// Start the sandbox by launching Firecracker and waiting for readiness.
    ///
    /// This waits for the Firecracker API socket and the in-guest envd daemon.
    #[tracing::instrument(skip(self))]
    pub async fn start(&mut self) -> Result<()> {
        debug!("starting firecracker sandbox");
        self.start_nowait().await?;
        self.wait_for_ready().await
    }

    /// Start the sandbox WITHOUT waiting for envd's readiness.
    ///
    /// This only waits for the Firecracker API socket to be available and
    /// returns immediately after VM start command is issued.
    pub(crate) async fn start_nowait(&mut self) -> Result<()> {
        self.prepare_tools_drive().await?;
        self.launch.validate()?;
        trace!("launch config validated");
        match &self.launch {
            LaunchMode::Fresh(config) => self.start_fresh(config.clone()).await,
            LaunchMode::Resume(config) => self.start_resume(config.clone()).await,
        }
    }

    async fn prepare_tools_drive(&mut self) -> Result<()> {
        if self.resources.tools_ublk_device.is_some() {
            return Ok(());
        }
        let config = ConfigManager::global_config();
        if let Some(image_config) =
            crate::sandbox::resolve_tools_image(config, &self.launch.common().tools_drive_version)
                .await?
        {
            self.resources.tools_ublk_device = Some(
                UblkDeviceManager::global()
                    .get_or_create_shared_tools(&UblkCreateSpec::Overlaybd {
                        image_config,
                        global_config: config.ublk.overlaybd.global_config_path.clone(),
                    })
                    .await?,
            );
        }
        Ok(())
    }

    /// Wait for the sandbox to be fully ready.
    ///
    /// This should be called after `start_nowait()` if you want to interact with the sandbox.
    #[tracing::instrument(skip(self))]
    pub(crate) async fn wait_for_ready(&self) -> Result<()> {
        let Some(envd_instance) = self.envd_instance.as_ref() else {
            return Err(anyhow::anyhow!("envd instance not initialized"));
        };
        envd_instance
            .wait_for_ready(
                self.runtime_policy.envd_timeout,
                self.runtime_policy.envd_poll_interval,
            )
            .await?;
        if let Some(tools) = &self.resources.tools_ublk_device {
            let _ = UblkDeviceManager::global()
                .notify_sandbox_ready(tools.image_config_path())
                .await;
        }
        if let Some(device_key) = &self.resources.mem_snapshot_image_config_path {
            // envd is up: release held background downloads for this memory
            // device. Best-effort — downloads would also start after the
            // fallback timeout.
            UblkDeviceManager::global()
                .notify_sandbox_ready(device_key)
                .await;
        }
        if let Some(device_key) = &self.resources.rootfs_image_config_path {
            // Same release for the rootfs image's background download.
            UblkDeviceManager::global()
                .notify_sandbox_ready(device_key)
                .await;
        }
        envd_instance
            .init(
                self.launch.common().env_vars.clone(),
                self.launch.common().default_workdir.clone(),
                self.launch.common().default_user.clone(),
            )
            .await?;

        // The snapshot already carries mount state for its existing drives,
        // and init mounts fresh drives except read-only volumes. Only the
        // remaining drives need a guest-side mount.
        if !self.initial_guest_drive_mounts.is_empty() {
            let envd = self
                .envd_instance
                .clone()
                .context("Sandbox is not running")?;
            guest_volumes::mount_initial_guest_drives(
                envd,
                self.initial_guest_drive_mounts.clone(),
            )
            .await?;
        }

        Ok(())
    }

    async fn set_volume_freeze(
        &self,
        mount: &Path,
        frozen_device: Option<&str>,
    ) -> Result<crate::sandbox::process::ProcessOutput> {
        let envd = self.envd_instance.clone().context("envd is not running")?;
        guest_volumes::set_volume_freeze(envd, mount, frozen_device).await
    }

    /// Pause the running sandbox and create a snapshot for later resume.
    ///
    /// This produces `vm_state.bin`, an overlaybd memory layer, and rootfs state
    /// owned by the returned [`FirecrackerSnapshotConfig`]. For overlaybd-backed
    /// sandboxes, the snapshot stores a copy of the writable upper under the
    /// snapshot dir.
    ///
    /// The snapshot artifacts are stored in a managed temporary directory that is
    /// automatically cleaned up when the reference count drops to zero.
    /// Use [`FirecrackerSandbox::pause_to_dir`] to specify a custom, caller-managed
    /// directory for the snapshot artifacts.
    ///
    /// The managed snapshot root is structured as `<managed-snapshot-base>/<sandbox_id>/<uuid>`, where:
    /// - `<managed-snapshot-base>` is `[firecracker].work_dir/managed-snapshots`, or
    ///   `<system-temp>/aenv/managed-snapshots` when `work_dir` is unset.
    /// - `<sandbox_id>` is the [`SandboxID`](crate::types::SandboxId), used to group snapshots by sandbox and improve readability.
    pub async fn pause(&mut self) -> Result<FirecrackerSnapshotConfig> {
        let snapshot_root = self.live_snapshot_root().await?;
        snapshot_root.prepare().await?;
        let snapshot_dir = snapshot_root.path().join(Uuid::now_v7().to_string());

        let (mut snapshot, _) = self.pause_to_dir(&snapshot_dir).await?;
        snapshot.managed_snapshot_root = Some(snapshot_root);

        Ok(snapshot)
    }

    /// Pause the running sandbox and persist its snapshot artifacts into a caller-managed directory.
    #[tracing::instrument(skip(self, snapshot_dir))]
    pub async fn pause_to_dir(
        &mut self,
        snapshot_dir: &Path,
    ) -> Result<(FirecrackerSnapshotConfig, SandboxSnapshotManifest)> {
        debug!(snapshot_dir = %snapshot_dir.display(), "pausing sandbox");
        if self.has_writable_persistent_volumes() {
            let envd = self
                .envd_instance
                .clone()
                .context("cannot flush writable volumes because envd is not running")?;
            guest_volumes::sync_writable_volume_filesystems(envd).await?;
        }
        self.fc_instance.pause().await?;

        tokio::fs::create_dir_all(snapshot_dir)
            .await
            .with_context(|| format!("create snapshot dir {}", snapshot_dir.display()))?;

        let snapshot_result = self.snapshot_to_dir(snapshot_dir).await;
        match snapshot_result {
            Ok(snapshot) => Ok(snapshot),
            Err(err) => {
                Self::cleanup_failed_snapshot_dir(snapshot_dir).await;
                Err(err)
            }
        }
    }

    async fn snapshot_to_dir(
        &self,
        snapshot_dir: &Path,
    ) -> Result<(FirecrackerSnapshotConfig, SandboxSnapshotManifest)> {
        let vm_state_path = snapshot_dir.join(VM_STATE_FILE_NAME);
        // Local layers are always captured raw; when enabled, compression
        // happens once at publish time under `[snapshot.publish_compression]`.
        let (mem_layer_path, mem_virtual_size) = self
            .snapshot_memory_to_overlaybd(&vm_state_path, snapshot_dir, OverlaybdCompactOutput::Raw)
            .await?;

        // Build the memory image config: collect parent layers, make runtime
        // lowers local to this snapshot dir, and compact only if the layer
        // count exceeds the configured maximum.
        let resume_mem_image_config_path = match &self.launch {
            LaunchMode::Resume(config) => {
                Some(config.mem_overlaybd_config.image_config_path.as_path())
            }
            LaunchMode::Fresh(_) => None,
        };
        let mem_image_config = build_mem_snapshot_image_config(
            resume_mem_image_config_path,
            &mem_layer_path,
            snapshot_dir,
            OverlaybdCompactOutput::Raw,
        )
        .await?;
        let mem_image_config_path = snapshot_dir.join("mem_image.json");
        tokio::fs::write(
            &mem_image_config_path,
            serde_json::to_vec_pretty(&mem_image_config)
                .context("serialize mem image config for persistent dir")?,
        )
        .await
        .with_context(|| {
            format!(
                "write mem image config to {}",
                mem_image_config_path.display()
            )
        })?;

        let mem_overlaybd_config = OverlaybdConfig {
            image_config_path: mem_image_config_path,
            read_only: true,
            runtime_upper_mode: overlaybd::config::UpperMode::LogStructured,
        };

        let (base_rootfs_path, rootfs_virtual_size) = if self.uses_overlaybd_ublk() {
            let overlaybd_source = self
                .launch
                .common()
                .ublk_config
                .as_ref()
                .map(|config| match &config.backend {
                    UblkBackend::Overlaybd(source) => source,
                })
                .context("overlaybd snapshot requires overlaybd-backed ublk config")?;
            let rootfs_runtime = self
                .resources
                .rootfs_runtime
                .as_ref()
                .context("overlaybd snapshot requires an active ublk device")?;
            let rootfs_image_path = restack_snapshot_overlaybd_rootfs(
                &rootfs_runtime.device,
                overlaybd_source.read_only,
                &rootfs_runtime.image_config_path,
                snapshot_dir,
            )
            .await
            .context("snapshot overlaybd runtime state to persistent dir")?;
            let size = self
                .snapshot_rootfs_virtual_size()
                .context("persist rootfs virtual size for snapshot")?;
            (rootfs_image_path, size)
        } else {
            let rootfs_path = snapshot_dir.join(ROOTFS_DRIVE_PATH);
            // Preserve the writable disk state alongside the snapshot.
            let current_rootfs = self.work_dir.path().join(ROOTFS_DRIVE_PATH);
            copy_cow(&current_rootfs, &rootfs_path).await?;
            let size = self
                .snapshot_rootfs_virtual_size()
                .context("persist rootfs virtual size for snapshot")?;
            (rootfs_path, size)
        };
        let snapshot_extra_drives = self
            .snapshot_extra_drives(snapshot_dir)
            .await
            .context("snapshot extra drives to persistent dir")?;
        let manifest_extra_drives = snapshot_extra_drives
            .iter()
            .filter(|drive| !drive.is_volume())
            .cloned()
            .collect::<Vec<_>>();
        let mut snapshot_common = self.launch.common().clone();
        snapshot_common.network_policy = self.current_network_policy.clone();
        snapshot_common.custom_extension_params = self.current_custom_extension_params.clone();
        snapshot_common.extra_drives = snapshot_extra_drives.clone();
        let mut rootfs_read_only = false;

        // Rewrite the overlaybd backend's image config path to point at the snapshot's rootfs.
        // So that the resumed ublk device uses the captured rootfs layers instead of the original ones.
        if let Some(ublk_config) = snapshot_common.ublk_config.as_mut() {
            let UblkBackend::Overlaybd(source) = &mut ublk_config.backend;
            rootfs_read_only = source.read_only;
            source.image_config_path = base_rootfs_path.clone();
        }
        let runtime_upper_mode = snapshot_common
            .ublk_config
            .as_ref()
            .map(|config| match &config.backend {
                UblkBackend::Overlaybd(source) => source.runtime_upper_mode,
            })
            .unwrap_or(overlaybd::config::UpperMode::LogStructured);
        snapshot_common.rootfs_image_config = Some(OverlaybdConfig {
            image_config_path: base_rootfs_path.clone(),
            read_only: rootfs_read_only,
            runtime_upper_mode,
        });
        snapshot_common.rootfs_virtual_size = Some(rootfs_virtual_size);

        let mut manifest = SandboxSnapshotManifest::new(
            crate::sandbox::FIRECRACKER_BACKEND,
            vm_state_path.clone(),
            mem_overlaybd_config.image_config_path.clone(),
            mem_virtual_size,
            base_rootfs_path,
            rootfs_virtual_size,
            &manifest_extra_drives,
        )
        .context("build firecracker snapshot manifest")?;
        manifest.volume_drive_slots = snapshot_common.volume_drive_slots;

        let snapshot = FirecrackerSnapshotConfig {
            common: snapshot_common,
            vm_state_path,
            mem_overlaybd_config,
            mem_virtual_size,
            managed_snapshot_root: None,
            pack_recording: false,
            memory_startup_pack: None,
        };

        debug!(
            vm_state_path = %snapshot.vm_state_path.display(),
            mem_image_config_path = %snapshot.mem_overlaybd_config.image_config_path.display(),
            rootfs_path = ?snapshot.common.rootfs_image_config.as_ref().map(|rootfs| &rootfs.image_config_path),
            "persistent snapshot created"
        );
        Ok((snapshot, manifest))
    }

    async fn snapshot_memory_to_overlaybd(
        &self,
        vm_state_path: &Path,
        snapshot_dir: &Path,
        memory_output: OverlaybdCompactOutput,
    ) -> Result<(PathBuf, u64)> {
        let mem_overlaybd_dir = snapshot_dir.join("mem_overlaybd");
        let firecracker_pid = self.fc_instance.pid()?;
        self.fc_instance
            .create_state_only_snapshot(vm_state_path)
            .await?;
        // `vm_state.bin` now represents this paused VM state. Any later
        // error aborts this direct snapshot attempt and is propagated to
        // the lifecycle caller for recovery.
        let dirty_ranges = self.fc_instance.get_dirty_memory_ranges().await?;
        convert_dirty_memory_to_overlaybd(
            firecracker_pid,
            &dirty_ranges,
            &mem_overlaybd_dir,
            memory_output,
        )
        .await
        .context("convert dirty memory ranges to overlaybd layer")
    }

    /// Resume a paused sandbox in-place.
    ///
    /// Use this when you want to keep the same sandbox instance.
    pub async fn resume(&self) -> Result<()> {
        debug!("resuming paused sandbox in-place");
        self.fc_instance.resume().await
    }

    /// Resume a new sandbox instance from snapshot config.
    ///
    /// This creates a new sandbox, starts Firecracker, and loads the snapshot config.
    #[tracing::instrument(skip(snapshot))]
    pub async fn resume_from_snapshot_config(snapshot: &FirecrackerSnapshotConfig) -> Result<Self> {
        let mut sandbox = Self::from_snapshot_config(snapshot)?;
        sandbox.start().await?;
        Ok(sandbox)
    }

    /// Stop the Firecracker process and release network resources.
    ///
    /// Sends SIGTERM and waits for exit; if it times out, sends SIGKILL.
    #[tracing::instrument(skip(self))]
    pub async fn stop(&mut self) -> Result<()> {
        debug!("stopping firecracker sandbox");

        let timeout = self.runtime_policy.socket_timeout;
        self.resources.cancel_startup_prefetch();
        if let Err(error) = self.fc_instance.stop(timeout).await {
            // If a future Firecracker stop implementation can fail, the VM
            // may still own its devices. Request reader cleanup, but retain
            // the sandbox/device handles for a later stop attempt.
            self.resources.stop_startup_prefetch(timeout).await;
            return Err(error);
        }

        // Clear envd instance
        if let Some(envd) = self.envd_instance.take() {
            envd.invalidate();
        }
        self.frozen_volume_mounts.clear();

        self.resources.release(timeout).await?;

        debug!("firecracker sandbox stopped");
        Ok(())
    }

    pub(crate) fn host_interaction_ip(&self) -> Option<std::net::Ipv4Addr> {
        self.resources
            .network_slot
            .as_ref()
            .map(|slot| slot.host_interaction_ip)
    }

    /// Resolve the Firecracker stdout log path (created only when capture is enabled).
    pub fn firecracker_stdout_path(&self) -> PathBuf {
        self.launch
            .common()
            .stdout_path
            .clone()
            .unwrap_or_else(|| self.default_log_dir())
            .join("firecracker-stdout.log")
    }

    /// Resolve the Firecracker stderr log path (created only when capture is enabled).
    pub fn firecracker_stderr_path(&self) -> PathBuf {
        self.launch
            .common()
            .stderr_path
            .clone()
            .unwrap_or_else(|| self.default_log_dir())
            .join("firecracker-stderr.log")
    }

    fn firecracker_stdio_paths(&self) -> (Option<PathBuf>, Option<PathBuf>) {
        let common = self.launch.common();
        let capture_output = logging_enabled(common.firecracker_log_level.as_deref());
        (
            (capture_output || common.stdout_path.is_some())
                .then(|| self.firecracker_stdout_path()),
            (capture_output || common.stderr_path.is_some())
                .then(|| self.firecracker_stderr_path()),
        )
    }

    /// Resolve the Firecracker logger output path for this sandbox.
    ///
    /// Lives in the default log directory and is named `firecracker.log`.
    /// Only used when `firecracker_log_level` is set.
    pub fn firecracker_log_path(&self) -> PathBuf {
        self.default_log_dir().join("firecracker.log")
    }

    fn default_log_dir(&self) -> PathBuf {
        self.launch
            .common()
            .serial_output_base_dir
            .clone()
            .map(|p| p.join(self.id.to_string()))
            .unwrap_or_else(|| self.work_dir.path().join("logs"))
    }

    fn uses_overlaybd_ublk(&self) -> bool {
        self.launch.common().ublk_config.is_some()
    }

    fn mmds_metadata(&self, common: &FirecrackerCommonConfig) -> MmdsMetadata {
        common
            .mmds_metadata
            .clone()
            .unwrap_or_else(|| MmdsMetadata::new(self.id, "unknown"))
    }

    /// Return the writable user image path inside this sandbox's Firecracker CWD.
    pub fn work_rootfs_path(&self) -> PathBuf {
        self.work_dir.path().join(USER_ROOTFS_DRIVE_PATH)
    }

    fn new_managed_persistent_snapshot_root(&self) -> Arc<PersistentSnapshotRootGuard> {
        let sandbox_dir = self.id.to_string();
        let root = managed_snapshot_base().join(sandbox_dir);
        Arc::new(PersistentSnapshotRootGuard::new(root))
    }

    async fn live_snapshot_root(&mut self) -> Result<Arc<PersistentSnapshotRootGuard>> {
        if let Some(root) = &self.live_snapshot_root {
            return Ok(Arc::clone(root));
        }
        let root = self
            .launch
            .managed_snapshot_root()
            .unwrap_or_else(|| self.new_managed_persistent_snapshot_root());
        root.prepare().await?;
        self.live_snapshot_root = Some(Arc::clone(&root));
        Ok(root)
    }

    /// Best-effort cleanup of a caller-managed snapshot directory after a failed pause.
    ///
    /// Removes the directory contents so the caller isn't left with a partially-written snapshot.
    async fn cleanup_failed_snapshot_dir(path: &Path) {
        match tokio::fs::remove_dir_all(path).await {
            Ok(()) => {}
            Err(err) if err.kind() == std::io::ErrorKind::NotFound => {}
            Err(err) => {
                warn!(
                    snapshot_dir = %path.display(),
                    error = %err,
                    "failed to clean up incomplete snapshot directory"
                );
            }
        }
    }
}

/// Overlaybd image config paths a sandbox opens (rootfs + extra drives).
/// For fresh launches these are source configs; for paused states they are
/// snapshot artifact configs.
/// (Memory snapshot layers are remote/repository-backed, never local-only, so
/// they are not included.)
fn rootfs_and_extra_drive_image_config_paths(common: &FirecrackerCommonConfig) -> Vec<PathBuf> {
    let mut paths = Vec::new();
    if let Some(rootfs) = &common.rootfs_image_config {
        paths.push(rootfs.image_config_path.clone());
    }
    paths.extend(
        common
            .extra_drives
            .iter()
            .map(|drive| drive.image_config_path().to_path_buf()),
    );
    paths
}

/// Read-only drives in writable reserved slots, such as read-only volumes,
/// would have their superblock written by init's default mount. They are
/// mounted `ro,noload` through envd after boot instead, as on snapshot launches.
fn mounts_after_boot(drive: &ExtraDrive) -> bool {
    drive.uses_reserved_slot() && drive.read_only()
}

/// Build the `agentenv_drives=vdc:/mnt/data,vdd:/mnt/logs:sub/path` boot arg
/// for extra drives that init mounts. Returns `None` if there are none.
/// Drive letter mapping: vda = tools drive, vdb = user image, vdc = first extra drive.
/// Each entry is `vd<letter>:<mountPath>[:<subPath>]`, with optional
/// Kubernetes-style `subPath` semantics. API validation rejects `:` in both
/// `mountPath` and `subPath`, so the `:` separators are unambiguous.
fn build_drives_boot_arg(extra_drives: &[ExtraDrive]) -> Option<String> {
    assert!(
        extra_drives.len() <= MAX_EXTRA_DRIVES,
        "too many extra drives for guest naming: {} > {}",
        extra_drives.len(),
        MAX_EXTRA_DRIVES
    );
    let entries: Vec<String> = extra_drives
        .iter()
        .enumerate()
        .filter(|(_, drive)| !mounts_after_boot(drive))
        .map(|(i, drive)| {
            let dev_letter = (b'c' + i as u8) as char;
            let mut entry = format!("vd{}:{}", dev_letter, drive.mount_path().display());
            if let Some(sub_path) = drive.sub_path() {
                entry.push(':');
                entry.push_str(&sub_path.display().to_string());
            }
            entry
        })
        .collect();
    (!entries.is_empty()).then(|| format!("agentenv_drives={}", entries.join(",")))
}

/// Append a space-separated argument to an optional kernel command line.
fn append_boot_arg(boot_args: &mut Option<String>, arg: &str) {
    *boot_args = Some(match boot_args.take() {
        Some(existing) => format!("{existing} {arg}"),
        None => arg.to_owned(),
    });
}

fn relocate_warm_log(src: Option<&Path>, target: &Path) -> Result<()> {
    let Some(src) = src else {
        return Ok(());
    };
    if src == target || !src.exists() {
        return Ok(());
    }
    if let Some(parent) = target.parent() {
        fs::create_dir_all(parent)
            .with_context(|| format!("create firecracker log directory {}", parent.display()))?;
    }
    if target.exists() {
        fs::remove_file(target)
            .with_context(|| format!("remove existing firecracker log {}", target.display()))?;
    }
    match fs::rename(src, target) {
        Ok(()) => Ok(()),
        Err(err) if err.raw_os_error() == Some(libc::EXDEV) => {
            fs::copy(src, target).with_context(|| {
                format!(
                    "copy warm firecracker log {} to {} after cross-device rename failed",
                    src.display(),
                    target.display()
                )
            })?;
            match fs::remove_file(src) {
                Ok(()) => Ok(()),
                Err(err) if err.kind() == std::io::ErrorKind::NotFound => Ok(()),
                Err(err) => Err(err).with_context(|| {
                    format!(
                        "remove warm firecracker log {} after cross-device copy",
                        src.display()
                    )
                }),
            }
        }
        Err(err) => Err(err).with_context(|| {
            format!(
                "move warm firecracker log {} to {}",
                src.display(),
                target.display()
            )
        }),
    }
}

// ── Drop ─────────────────────────────────────────────────────────────────────

/// Release resources when the sandbox is dropped without `stop()`.
impl Drop for FirecrackerSandbox {
    fn drop(&mut self) {
        if let Some(envd) = self.envd_instance.as_ref() {
            envd.invalidate();
        }
        // Release before the work directory and Firecracker process drop.
        drop(std::mem::take(&mut self.resources));
    }
}

// ── Private helpers ──────────────────────────────────────────────────────────

impl FirecrackerSandbox {
    fn build(id: SandboxId, launch: LaunchMode) -> Result<Self> {
        let work_dir =
            create_firecracker_work_dir(launch.common().firecracker_work_base_dir.as_deref())?;
        let fc_instance = FirecrackerInstance::new(work_dir.path().to_path_buf());
        let runtime_policy = launch.common().runtime_policy;
        let current_network_policy = launch.common().network_policy.clone();
        let current_custom_extension_params = launch.common().custom_extension_params.clone();
        debug!(work_dir = %work_dir.path().display(), "sandbox work directory prepared");

        Ok(Self {
            id,
            runtime_policy,
            current_rootfs_virtual_size: match &launch {
                LaunchMode::Fresh(_) => None,
                LaunchMode::Resume(config) => config.common.rootfs_virtual_size,
            },
            launch,
            work_dir,
            fc_instance,
            resources: SandboxResources::default(),
            current_network_policy,
            current_custom_extension_params,
            envd_instance: None,
            frozen_volume_mounts: Vec::new(),
            initial_guest_drive_mounts: Vec::new(),
            live_snapshot_root: None,
        })
    }

    #[tracing::instrument(skip(self, config))]
    async fn start_fresh(&mut self, config: FirecrackerSandboxConfig) -> Result<()> {
        let work_dir = self.work_dir.path();
        debug!(work_dir = %work_dir.display(), "starting fresh sandbox");

        let global_config = ConfigManager::global_config();

        // ── Tools drive: shared read-only ublk, or legacy ext4 ──
        // Symlink work_dir/rootfs.ext4 → tools drive so Firecracker can use a
        // relative path inside the work directory.
        self.link_tools_drive(&config.common, work_dir)?;

        // ── User image: overlaybd via ublk, writable, per-sandbox ──
        let rootfs_image_config = config
            .common
            .rootfs_image_config
            .as_ref()
            .context("fresh sandbox rootfs image config is missing")?;
        self.attach_user_rootfs(
            rootfs_image_config,
            config.common.rootfs_virtual_size,
            None,
            config.common.rootfs_allow_shrink,
        )
        .await?;

        // ── Boot args: init=/init (tools drive has init baked in) ──
        let mut boot_args = config.boot_args.clone();
        // Tools drive contains /init; ensure boot args include init=/init.
        let missing_explicit_init_arg = match boot_args.as_deref() {
            Some(args) => !args.split_whitespace().any(|arg| arg.starts_with("init=")),
            None => true,
        };
        if missing_explicit_init_arg {
            append_boot_arg(&mut boot_args, "init=/init");
        }

        // ── Extra drives ──
        let (extra_drive_attachments, extra_drive_runtimes) =
            if config.common.extra_drives.is_empty() {
                (Vec::new(), Vec::new())
            } else {
                let overlaybd_global = global_config.ublk.overlaybd.global_config_path.clone();
                let runtime_upper_mode = global_config.ublk.overlaybd.runtime_upper_mode;
                let allow_shrink = global_config.ublk.overlaybd.allow_shrink;
                prepare_extra_drives(
                    &config.common.extra_drives,
                    &overlaybd_global,
                    self.work_dir.path(),
                    runtime_upper_mode,
                    |_| ExtraDrivePrepareMode::Fresh { allow_shrink },
                )
                .await
                .context("prepare extra drives")?
                .into_parts()
            };
        self.resources.extra_drive_runtimes = extra_drive_runtimes;

        // ── Boot args: extra drive mount points (agentenv_drives=vdc:...) ──
        if let Some(drives_arg) = build_drives_boot_arg(&config.common.extra_drives) {
            append_boot_arg(&mut boot_args, &drives_arg);
        }

        // ── Allocate network slot and create network infrastructure ──
        let slot = self.allocate_network_slot()?;
        slot.set_egress_policy(config.common.network_policy.as_ref())
            .context("Failed to configure sandbox egress policy")?;
        let interaction_ip = slot.host_interaction_ip;
        let netns = slot.namespace_path();
        // Add IP configuration to boot args for the VM.
        // Uses Slot::build_ip_boot_arg() to produce the kernel ip= parameter with a
        // valid DNS server IP in the 8th field. See that method for format details.
        append_boot_arg(&mut boot_args, &slot.build_ip_boot_arg());
        append_boot_arg(&mut boot_args, GUEST_ARP_NOTIFY_BOOT_ARG);

        // ── Custom extension hook: start-fresh (may contribute extra boot args) ──
        if let Some(client) = CustomExtensionClient::global() {
            let mut guard = CustomExtensionHookGuard::new(client, self.id);
            let extra_boot_args = guard
                .start_fresh(
                    &netns.to_string_lossy(),
                    interaction_ip,
                    config.common.custom_extension_params.as_ref(),
                )
                .await?;
            self.resources.custom_extension_hook_guard = Some(guard);
            if let Some(extra) = extra_boot_args.filter(|args| !args.trim().is_empty()) {
                append_boot_arg(&mut boot_args, &extra);
            }
        }

        boot_args =
            add_damon_monitor_region(boot_args, config.mem_size_mib, std::env::consts::ARCH);

        self.spawn_firecracker(&config.common, &netns).await?;
        self.init_envd_instance(interaction_ip, &config.common);

        // ── Configure microVM: tools drive as rootfs + user image + extras ──
        self.fc_instance
            .wait_for_ready(
                self.runtime_policy.socket_timeout,
                self.runtime_policy.socket_poll_interval,
            )
            .await?;
        self.configure_microvm(&config, boot_args.as_deref(), &extra_drive_attachments)
            .await?;
        self.fc_instance.start().await?;
        debug!("fresh sandbox started");
        Ok(())
    }

    #[tracing::instrument(skip(self, config))]
    async fn start_resume(&mut self, config: FirecrackerSnapshotConfig) -> Result<()> {
        // NOTE: The virtio-balloon device is NOT configured here. Balloon state
        // is part of vm_state.bin and is restored automatically by Firecracker.
        // Snapshots taken before balloon support was added will simply not have
        // the device — free_page_reporting will be absent for those VMs, which
        // is acceptable during rollout.

        // Fail fast: memory restore requires a ublk device. Check before
        // allocating any resources (Firecracker process, network namespace, …).
        anyhow::ensure!(
            UblkDeviceManager::global().is_available(),
            "snapshot resume requires an available ublk daemon client \
             because memory restore uses a shared ublk device"
        );

        let rootfs_virtual_size = config
            .common
            .rootfs_virtual_size
            .context("snapshot rootfs virtual size is missing")?;
        let rootfs_image_config = config
            .common
            .rootfs_image_config
            .as_ref()
            .context("snapshot rootfs image config is missing")?;
        self.current_rootfs_virtual_size = Some(rootfs_virtual_size);

        self.adopt_warm_firecracker(&config.common);

        let fc_cwd = self.work_dir.path();
        let vm_state_src = fs::canonicalize(&config.vm_state_path)
            .unwrap_or_else(|_| config.vm_state_path.clone());
        debug!(
            fc_cwd = %fc_cwd.display(),
            vm_state_path = %vm_state_src.display(),
            "starting sandbox from snapshot config"
        );

        // ── Tools drive: symlink rootfs.ext4 → tools drive (read-only, from snapshot config) ──
        self.link_tools_drive(&config.common, fc_cwd)?;

        // ── User image: restore overlaybd via ublk ──
        if config.common.ublk_config.is_some() {
            self.attach_user_rootfs(
                rootfs_image_config,
                Some(rootfs_virtual_size),
                Some(rootfs_virtual_size),
                false,
            )
            .await?;
        }

        // ── Extra drives and reserved volume slots ──
        let new_volume_binds = self.prepare_resume_drives(&config.common).await?;

        // ── Network + Firecracker spawn (a warm Firecracker already has both) ──
        let needs_socket_wait = self.resources.network_slot.is_none();
        if needs_socket_wait {
            let netns = self.allocate_network_slot()?.namespace_path();
            self.spawn_firecracker(&config.common, &netns).await?;
        }
        let slot = self
            .resources
            .network_slot
            .as_mut()
            .expect("network slot comes from the warm pool or was just allocated");
        slot.set_egress_policy(config.common.network_policy.as_ref())
            .context("Failed to configure sandbox egress policy for resume")?;
        let interaction_ip = slot.host_interaction_ip;
        let netns = slot.namespace_path();

        // ── Custom extension hook: start-resume ──
        // Pack-recording VMs are throwaway recorders: hooks must not fire
        // for them (the extension would see a phantom sandbox start/stop).
        if !config.pack_recording {
            if let Some(client) = CustomExtensionClient::global() {
                let mut guard = CustomExtensionHookGuard::new(client, self.id);
                guard
                    .start_resume(
                        &netns.to_string_lossy(),
                        interaction_ip,
                        config.common.custom_extension_params.as_ref(),
                    )
                    .await?;
                self.resources.custom_extension_hook_guard = Some(guard);
            }
        }

        self.init_envd_instance(interaction_ip, &config.common);

        // ── Memory device ──
        let mem_device_path = if config.pack_recording {
            self.create_pack_recording_mem_device(&config).await?
        } else {
            self.acquire_shared_mem_device(&config).await?
        };

        // ── Load snapshot and resume ──
        if needs_socket_wait {
            self.fc_instance
                .wait_for_ready(
                    self.runtime_policy.socket_timeout,
                    self.runtime_policy.socket_poll_interval,
                )
                .await?;
        }

        self.configure_logger(&config.common).await?;

        // Override the network interface to use the new tap0 in our namespace
        let network_overrides = [("eth0", "tap0")];
        self.fc_instance
            .load_snapshot_file(
                &vm_state_src,
                &mem_device_path,
                &network_overrides,
                false,
                config.common.track_dirty_pages,
            )
            .await?;

        self.attach_new_volume_drives(&new_volume_binds).await?;
        let mmds_metadata = self.mmds_metadata(&config.common);
        self.fc_instance.set_mmds(&mmds_metadata).await?;

        // A restored snapshot inherits whatever limiter was active when it was
        // paused, so reconcile against the node's current config while the VM is
        // still loaded-but-paused — before resume() lets the guest issue I/O.
        // Both buckets are always overwritten (configured or unlimited) so an
        // inherited dimension the current config leaves unset is cleared rather
        // than left unchanged.
        let reconciled = reconcile_disk_rate_limiter(&config.common.disk_rate_limit)?;
        self.fc_instance
            .patch_drive_rate_limiter(USER_ROOTFS_DRIVE_ID, reconciled)
            .await
            .context("reconcile disk rate limiter on snapshot resume")?;

        self.fc_instance.resume().await?;

        debug!("sandbox restored from snapshot config");
        Ok(())
    }

    /// Take a pre-spawned Firecracker and its network slot from the warm pool
    /// when this launch uses the default log paths.
    fn adopt_warm_firecracker(&mut self, common: &FirecrackerCommonConfig) {
        if common.stdout_path.is_some() || common.stderr_path.is_some() {
            return;
        }
        let capture_output = logging_enabled(common.firecracker_log_level.as_deref());
        let Some(warm) =
            FirecrackerPool::global().and_then(|pool| pool.try_acquire(capture_output))
        else {
            return;
        };
        let warm_dir = warm.work_dir.path();
        let (warm_stdout, warm_stderr) = warm_stdio_paths(warm_dir, capture_output);
        debug!(
            slot = warm.slot.idx,
            pool_work_dir = %warm_dir.display(),
            "using warm firecracker from pool"
        );

        self.resources.network_slot = Some(warm.slot);
        self.work_dir = warm.work_dir; // Update self.work_dir before relocating logs since the fallback log paths are relative to the work_dir.
        let _cold = std::mem::replace(&mut self.fc_instance, warm.fc_instance);
        if let Err(err) = relocate_warm_log(warm_stdout.as_deref(), &self.firecracker_stdout_path())
        {
            warn!(error = %err, "failed to relocate warm firecracker stdout log");
        }
        if let Err(err) = relocate_warm_log(warm_stderr.as_deref(), &self.firecracker_stderr_path())
        {
            warn!(error = %err, "failed to relocate warm firecracker stderr log");
        }
    }

    /// Allocate a network slot, storing it before any fallible setup so that
    /// `stop()` or `Drop` releases it.
    fn allocate_network_slot(&mut self) -> Result<&mut Slot> {
        let slot = NetworkManager::global()
            .allocate_any()
            .context("Failed to allocate network slot")?;
        debug!(slot = slot.idx, "allocated network slot");
        Ok(self.resources.network_slot.insert(slot))
    }

    /// Spawn Firecracker inside the network namespace so it can access tap0.
    async fn spawn_firecracker(
        &mut self,
        common: &FirecrackerCommonConfig,
        netns: &Path,
    ) -> Result<()> {
        let (stdout_path, stderr_path) = self.firecracker_stdio_paths();
        self.fc_instance
            .spawn_with_netns(
                &common.firecracker_binary,
                stdout_path.as_deref(),
                stderr_path.as_deref(),
                Some(netns),
            )
            .await
    }

    fn init_envd_instance(
        &mut self,
        interaction_ip: std::net::Ipv4Addr,
        common: &FirecrackerCommonConfig,
    ) {
        let envd_base_url = format!("http://{}:{}", interaction_ip, common.control_plane_port);
        self.envd_instance = Some(EnvdInstance::new(
            envd_base_url,
            common.envd_access_token.clone(),
        ));
    }

    /// Prepare snapshot-backed extra drives and the reserved volume slots.
    ///
    /// Snapshot loading reopens every serialized slot path, so all
    /// placeholders must exist. Slot drives in the source state, such as
    /// restored volumes, replace their placeholders before load. Drives newly
    /// supplied for this launch are absent from the source state; they are
    /// returned as `(slot, drive)` pairs to attach with
    /// [`attach_new_volume_drives`](Self::attach_new_volume_drives) after load.
    async fn prepare_resume_drives(
        &mut self,
        common: &FirecrackerCommonConfig,
    ) -> Result<Vec<(DriveMount, DriveMount)>> {
        let new_indices = self
            .initial_guest_drive_mounts
            .iter()
            .map(|(index, _)| *index)
            .collect::<Vec<_>>();
        let is_new_drive = |index: usize| new_indices.contains(&index);
        // Attached drives new to this launch carry the requested size, as on a
        // fresh boot; every other drive, including volumes, carries its known size.
        let allow_shrink = ConfigManager::global_config().ublk.overlaybd.allow_shrink;
        let extra_drive_attachments = self
            .prepare_snapshot_backing_drives(&common.extra_drives, |index| {
                if is_new_drive(index)
                    && common.extra_drives[index].kind() == ExtraDriveKind::LaunchSlot
                {
                    ExtraDrivePrepareMode::Fresh { allow_shrink }
                } else {
                    ExtraDrivePrepareMode::Resume
                }
            })
            .await
            .context("prepare snapshot-backed extra drives for resume")?;
        let volume_slots = self
            .prepare_volume_drive_slots(
                common.physical_extra_drive_count,
                common.volume_drive_slots,
            )
            .context("prepare reserved volume drive slots for resume")?;
        let physical_count = common.physical_extra_drive_count;
        anyhow::ensure!(
            physical_count <= extra_drive_attachments.len(),
            "snapshot expects {physical_count} physical extra drives, but only {} were prepared",
            extra_drive_attachments.len()
        );
        let volume_drive_attachments = &extra_drive_attachments[physical_count..];
        anyhow::ensure!(
            volume_drive_attachments.len() <= volume_slots.len(),
            "snapshot has more launch-time drives than reserved volume slots"
        );
        let mut new_binds = Vec::new();
        for (offset, (slot, drive)) in volume_slots
            .into_iter()
            .zip(volume_drive_attachments.iter().cloned())
            .enumerate()
        {
            if is_new_drive(physical_count + offset) {
                new_binds.push((slot, drive));
                continue;
            }
            self.bind_volume_drive_slot(&slot, &drive)
                .with_context(|| {
                    format!(
                        "bind restored drive {} to reserved drive {} before snapshot load",
                        drive.drive_id, slot.drive_id
                    )
                })?;
        }
        Ok(new_binds)
    }

    /// A volume absent from the source state was loaded as a placeholder.
    /// Replace and PATCH it once so Firecracker reopens the path and reports
    /// the real capacity.
    async fn attach_new_volume_drives(
        &self,
        volume_binds: &[(DriveMount, DriveMount)],
    ) -> Result<()> {
        for (slot, drive) in volume_binds {
            self.bind_volume_drive_slot(slot, drive).with_context(|| {
                format!(
                    "bind new volume {} to reserved drive {}",
                    drive.drive_id, slot.drive_id
                )
            })?;
            self.fc_instance
                .patch_drive_path(&slot.drive_id, &slot.attachment_path)
                .await
                .with_context(|| {
                    format!(
                        "attach new volume {} through reserved drive {}",
                        drive.drive_id, slot.drive_id
                    )
                })?;
        }
        Ok(())
    }

    /// Pack-recording VMs get a dedicated, non-shared memory device: sharing
    /// one (or the block-device page cache behind it) would hide first-touch
    /// reads from the recorder.
    async fn create_pack_recording_mem_device(
        &mut self,
        config: &FirecrackerSnapshotConfig,
    ) -> Result<PathBuf> {
        let global_config = ConfigManager::global_config();
        let device = UblkDeviceManager::global()
            .create_dedicated_mem_device(&UblkCreateSpec::Overlaybd {
                image_config: config.mem_overlaybd_config.image_config_path.clone(),
                global_config: global_config
                    .memory_snapshot
                    .overlaybd_global_config_path
                    .clone(),
            })
            .await
            .context("create dedicated memory ublk device for pack recording")?;
        let device_path = device.device_path().to_path_buf();
        let device_id = device.dev_id();
        // Store the device BEFORE any fallible step below: `stop()` owns
        // its deletion, so an arming failure cannot leak the device.
        self.resources.mem_dedicated_device = Some(device);

        // Arm the first-touch recorder BEFORE the snapshot loads so FC's
        // load-time reads and the guest's first faults are all recorded.
        let pack_config = &global_config.snapshot.memory_startup_pack;
        let output = config
            .vm_state_path
            .parent()
            .map(|dir| dir.join(crate::snapshot::MEMORY_STARTUP_TRACE_ARTIFACT))
            .context("pack recording requires a snapshot artifact dir")?;
        UblkDeviceManager::global()
            .start_pack_recording(
                device_id,
                &output,
                PackRecordingWindow {
                    max_pages: u32::try_from(
                        (pack_config.max_pack_bytes / overlaybd::startup_pack::PACK_PAGE_BYTES)
                            .min(u64::from(overlaybd::startup_pack::MAX_PACK_PAGES)),
                    )
                    .unwrap_or(overlaybd::startup_pack::MAX_PACK_PAGES),
                    min_window_ms: pack_config.record_min_window_ms,
                    quiet_ms: pack_config.record_quiet_ms,
                    max_window_ms: pack_config.record_max_window_ms,
                },
            )
            .await
            .context("arm startup pack recorder")?;
        Ok(device_path)
    }

    /// Create or reuse the shared memory device for this snapshot and start
    /// any configured startup-pack prefetch.
    async fn acquire_shared_mem_device(
        &mut self,
        config: &FirecrackerSnapshotConfig,
    ) -> Result<PathBuf> {
        let mem_global_config = ConfigManager::global_config()
            .memory_snapshot
            .overlaybd_global_config_path
            .clone();
        if let Some(pack) = &config.memory_startup_pack {
            match &pack.source {
                crate::snapshot::ResolvedStartupPackSource::OssUrl(_) => {
                    UblkDeviceManager::global()
                        .prefetch_startup_pack(
                            &config.mem_overlaybd_config.image_config_path,
                            &mem_global_config,
                            pack,
                        )
                        .await;
                }
                crate::snapshot::ResolvedStartupPackSource::LocalPath(_) => {
                    // Local prefetch needs the actual shared memory device,
                    // acquired below. Warming lower files is insufficient.
                }
            }
        }
        let mem_device = UblkDeviceManager::global()
            .get_or_create_shared_mem(
                &UblkCreateSpec::Overlaybd {
                    image_config: config.mem_overlaybd_config.image_config_path.clone(),
                    global_config: mem_global_config.clone(),
                },
                config.mem_virtual_size,
            )
            .await
            .context("create or reuse shared memory ublk device for resume")?;
        let device_path = mem_device.device_path().to_path_buf();

        if let Some(pack) = &config.memory_startup_pack {
            if matches!(
                &pack.source,
                crate::snapshot::ResolvedStartupPackSource::LocalPath(_)
            ) {
                self.resources
                    .stop_startup_prefetch(self.runtime_policy.socket_timeout)
                    .await;
                self.resources.startup_prefetch_task =
                    Some(super::startup_pack::submit_local_startup_prefetch(
                        mem_device.clone(),
                        mem_global_config.clone(),
                        pack.clone(),
                    ));
            }
        }

        self.resources.mem_snapshot_image_config_path =
            Some(config.mem_overlaybd_config.image_config_path.clone());
        self.resources.mem_ublk_device = Some(mem_device);
        Ok(device_path)
    }

    /// Create the writable user-image overlaybd device and link it into the
    /// Firecracker work directory as `user-rootfs`.
    async fn attach_user_rootfs(
        &mut self,
        rootfs_image_config: &OverlaybdConfig,
        requested_virtual_size: Option<u64>,
        known_source_virtual_size: Option<u64>,
        allow_shrink: bool,
    ) -> Result<()> {
        let work_dir = self.work_dir.path();
        let global_cfg_path = ConfigManager::global_config()
            .ublk
            .overlaybd
            .global_config_path
            .clone();
        let runtime_device = UblkDeviceManager::global()
            .create_overlaybd_runtime_device(CreateOverlaybdRuntimeDeviceRequest {
                source_image_config: &rootfs_image_config.image_config_path,
                global_config: &global_cfg_path,
                runtime_dir: &work_dir.join("overlaybd"),
                read_only: rootfs_image_config.read_only,
                runtime_upper_mode: rootfs_image_config.runtime_upper_mode,
                requested_virtual_size,
                known_source_virtual_size,
                allow_shrink,
            })
            .await
            .context("create user image overlaybd runtime device")?;
        self.resources.rootfs_image_config_path =
            Some(rootfs_image_config.image_config_path.clone());
        let symlink_result = std::os::unix::fs::symlink(
            runtime_device.device.device_path(),
            work_dir.join(USER_ROOTFS_DRIVE_PATH),
        )
        .context("symlink user-rootfs to ublk device");
        if let Err(err) = symlink_result {
            if let Err(release_err) = UblkDeviceManager::global()
                .release_device(&runtime_device.device)
                .await
            {
                warn!(
                    error = %release_err,
                    "failed to release user image ublk device after symlink failure"
                );
            }
            return Err(err);
        }
        self.resources.rootfs_runtime = Some(OverlaybdRuntimeHandle {
            device: runtime_device.device,
            image_config_path: runtime_device.image_config_path,
            actual_virtual_size: runtime_device.actual_virtual_size,
        });
        self.current_rootfs_virtual_size = Some(runtime_device.actual_virtual_size);
        Ok(())
    }

    /// Enable Firecracker logging when `firecracker_log_level` is configured.
    ///
    /// Must be called pre-boot (and before snapshot load). When no log level is
    /// set, this is a no-op so the default behaviour is unchanged.
    async fn configure_logger(&self, common: &FirecrackerCommonConfig) -> Result<()> {
        let Some(level) = common.firecracker_log_level.as_deref() else {
            return Ok(());
        };
        if level.trim().is_empty() {
            return Ok(());
        }
        let log_path = self.firecracker_log_path();
        if let Some(parent) = log_path.parent() {
            tokio::fs::create_dir_all(parent).await.with_context(|| {
                format!("create firecracker log directory {}", parent.display())
            })?;
        }
        self.fc_instance.set_logger(&log_path, level).await?;
        debug!(
            log_path = %log_path.display(),
            level,
            "firecracker logger enabled"
        );
        Ok(())
    }

    fn link_tools_drive(&self, common: &FirecrackerCommonConfig, work_dir: &Path) -> Result<()> {
        let tools_drive_path = match &self.resources.tools_ublk_device {
            Some(device) => Ok(device.device_path().to_path_buf()),
            None => common.resolved_tools_drive_path(ConfigManager::global_config()),
        }
        .with_context(|| {
            format!(
                "resolve tools drive version '{}' for sandbox {}",
                common.tools_drive_version, self.id
            )
        })?;
        let tools_drive_path = fs::canonicalize(&tools_drive_path).with_context(|| {
            format!(
                "open tools drive version '{}' at {} for sandbox {}",
                common.tools_drive_version,
                tools_drive_path.display(),
                self.id
            )
        })?;
        let firecracker_path = work_dir.join(ROOTFS_DRIVE_PATH);

        std::os::unix::fs::symlink(&tools_drive_path, &firecracker_path).with_context(|| {
            format!(
                "link tools drive version '{}' from {} to {} for sandbox {}",
                common.tools_drive_version,
                tools_drive_path.display(),
                firecracker_path.display(),
                self.id
            )
        })?;
        debug!(
            sandbox_id = %self.id,
            tools_drive_version = %common.tools_drive_version,
            source = %tools_drive_path.display(),
            destination = %firecracker_path.display(),
            "linked tools drive into Firecracker work directory"
        );
        Ok(())
    }

    #[tracing::instrument(skip_all)]
    async fn configure_microvm(
        &self,
        config: &FirecrackerSandboxConfig,
        boot_args: Option<&str>,
        extra_drive_attachments: &[DriveMount],
    ) -> Result<()> {
        self.configure_logger(&config.common).await?;

        self.fc_instance
            .set_machine_config(
                config.mem_size_mib,
                config.vcpu_count,
                false,
                config.common.track_dirty_pages,
            )
            .await?;

        if let Some(cpu_json) = config.common.cpu_config_json.as_deref() {
            if !cpu_json.is_empty() {
                self.fc_instance.set_cpu_config(cpu_json).await?;
            }
        }

        let kernel_image =
            fs::canonicalize(&config.kernel_image).unwrap_or_else(|_| config.kernel_image.clone());
        self.fc_instance
            .set_boot_source(&kernel_image, None, boot_args)
            .await?;

        // Drive 0 (/dev/vda): tools drive as root device, always read-only.
        self.fc_instance
            .add_drive(
                ROOTFS_DRIVE_ID,
                Path::new(ROOTFS_DRIVE_PATH),
                true,
                true,
                false,
                IoEngine::Sync,
                None,
            )
            .await
            .with_context(|| {
                format!(
                    "attach tools drive version '{}' as {} for fresh sandbox {}",
                    config.common.tools_drive_version, ROOTFS_DRIVE_PATH, self.id
                )
            })?;

        // Drive 1 (/dev/vdb): user image, writable. The disk rate limiter is
        // applied here as pre-boot drive config (rather than a post-start PATCH)
        // so throttling is in force the instant the guest starts issuing I/O.
        self.fc_instance
            .add_drive(
                USER_ROOTFS_DRIVE_ID,
                Path::new(USER_ROOTFS_DRIVE_PATH),
                false,
                false,
                true,
                IoEngine::Async,
                build_disk_rate_limiter(&config.common.disk_rate_limit)?,
            )
            .await?;

        // Drive 2+ (/dev/vdc...): physical extra drives followed by volume slots.
        // Firecracker cannot add a virtio-block device after snapshot restore,
        // so every volume uses a stable reserved slot from the first boot.
        let physical_count = config.common.physical_extra_drive_count;
        anyhow::ensure!(
            physical_count <= extra_drive_attachments.len(),
            "fresh sandbox expects {physical_count} physical extra drives, but only {} were prepared",
            extra_drive_attachments.len()
        );
        let (physical_drive_attachments, volume_drive_attachments) =
            extra_drive_attachments.split_at(physical_count);
        self.configure_extra_drives(physical_drive_attachments)
            .await?;
        let volume_slots =
            self.prepare_volume_drive_slots(physical_count, config.common.volume_drive_slots)?;
        anyhow::ensure!(
            volume_drive_attachments.len() <= volume_slots.len(),
            "fresh sandbox has more volume drives than reserved volume slots"
        );
        for (slot, drive) in volume_slots.iter().zip(volume_drive_attachments) {
            self.bind_volume_drive_slot(slot, drive).with_context(|| {
                format!(
                    "bind fresh volume {} to reserved drive {}",
                    drive.drive_id, slot.drive_id
                )
            })?;
        }
        self.configure_extra_drives(&volume_slots).await?;

        if self.resources.network_slot.is_some() {
            // Network interface.
            self.fc_instance
                .add_network_interface("eth0", None, "tap0".to_string(), None, None)
                .await
                .context("Failed to add network interface to microVM")?;

            // MMDS
            self.fc_instance
                .set_mmds_config("eth0")
                .await
                .context("Failed to set MMDS network configuration")?;
            let mmds_metadata = self.mmds_metadata(&config.common);
            self.fc_instance.set_mmds(&mmds_metadata).await?;
        }

        // ── Balloon: enable free page reporting ──
        // Paired with DAMON reclaim (kernel boot args): DAMON reclaims cold
        // pagecache pages inside the guest, and the balloon device reports the
        // resulting free pages to the host VMM so it can release physical memory.
        self.fc_instance.set_balloon().await?;

        Ok(())
    }

    async fn configure_extra_drives(&self, extra_drive_attachments: &[DriveMount]) -> Result<()> {
        for drive in extra_drive_attachments {
            self.fc_instance
                .add_drive(
                    &drive.drive_id,
                    &drive.attachment_path,
                    false,
                    drive.read_only,
                    true,
                    IoEngine::Async,
                    None,
                )
                .await
                .with_context(|| format!("Failed to add extra drive {}", drive.drive_id))?;
        }

        Ok(())
    }

    fn prepare_volume_drive_slots(
        &self,
        physical_extra_drive_count: usize,
        count: usize,
    ) -> Result<Vec<DriveMount>> {
        let mut slots = Vec::with_capacity(count);
        for index in 0..count {
            let drive_id = volume_drive_slot_id(index);
            let attachment_name = format!("{drive_id}.img");
            let attachment_path = self.work_dir.path().join(&attachment_name);
            let file = fs::OpenOptions::new()
                .create_new(true)
                .write(true)
                .open(&attachment_path)
                .with_context(|| {
                    format!("create reserved volume drive {}", attachment_path.display())
                })?;
            file.set_len(VOLUME_DRIVE_PLACEHOLDER_SIZE)
                .with_context(|| {
                    format!("size reserved volume drive {}", attachment_path.display())
                })?;
            slots.push(DriveMount {
                drive_id,
                attachment_path: PathBuf::from(attachment_name),
                read_only: false,
            });
        }
        anyhow::ensure!(
            physical_extra_drive_count + slots.len() <= MAX_EXTRA_DRIVES,
            "{} physical extra drives plus {} volume slots exceed Firecracker's {}-drive limit",
            physical_extra_drive_count,
            slots.len(),
            MAX_EXTRA_DRIVES
        );
        Ok(slots)
    }

    fn bind_volume_drive_slot(&self, slot: &DriveMount, drive: &DriveMount) -> Result<()> {
        let slot_path = self.work_dir.path().join(&slot.attachment_path);
        fs::remove_file(&slot_path)
            .with_context(|| format!("remove reserved volume drive {}", slot_path.display()))?;
        std::os::unix::fs::symlink(&drive.attachment_path, &slot_path).with_context(|| {
            format!(
                "link reserved volume drive {} to {}",
                slot_path.display(),
                drive.attachment_path.display()
            )
        })
    }

    async fn prepare_snapshot_backing_drives(
        &mut self,
        extra_drives: &[ExtraDrive],
        mode: impl Fn(usize) -> ExtraDrivePrepareMode,
    ) -> Result<Vec<DriveMount>> {
        if extra_drives.is_empty() {
            self.resources.extra_drive_runtimes.clear();
            return Ok(Vec::new());
        }

        let global_config = ConfigManager::global_config();
        let ublk_config = &global_config.ublk;
        let overlaybd_global = ublk_config.overlaybd.global_config_path.clone();
        let runtime_upper_mode = ublk_config.overlaybd.runtime_upper_mode;
        let prepared_extra_drives = prepare_extra_drives(
            extra_drives,
            &overlaybd_global,
            self.work_dir.path(),
            runtime_upper_mode,
            mode,
        )
        .await?;
        let (attachments, extra_drive_runtimes) = prepared_extra_drives.into_parts();
        self.resources.extra_drive_runtimes = extra_drive_runtimes;
        Ok(attachments)
    }

    async fn snapshot_extra_drives(&self, snapshot_dir: &Path) -> Result<Vec<ExtraDrive>> {
        let extra_drives = &self.launch.common().extra_drives;
        if extra_drives.is_empty() {
            return Ok(Vec::new());
        }
        if extra_drives.len() != self.resources.extra_drive_runtimes.len() {
            bail!(
                "extra drive bookkeeping mismatch: {} configured drives but {} prepared devices",
                extra_drives.len(),
                self.resources.extra_drive_runtimes.len()
            );
        }

        let mut snapped = Vec::with_capacity(extra_drives.len());
        for (drive, runtime) in extra_drives
            .iter()
            .zip(self.resources.extra_drive_runtimes.iter())
        {
            let persistent_output_dir = drive.snapshot_output_dir();
            let output_dir = persistent_output_dir.map_or_else(
                || snapshot_dir.join("drives").join(drive.drive_id()),
                PathBuf::from,
            );
            // A volume reuses its backing directory across pauses. Preserve every
            // sealed upper under a unique name so a later restack cannot overwrite
            // a lower that is still referenced by image.json.
            let snapshot_layer_file_name = persistent_output_dir.map_or_else(
                || "snapshot.commit".to_owned(),
                |_| format!("snapshot-{}.commit", Uuid::now_v7().simple()),
            );
            let snapshot_image_config_path = restack_snapshot_overlaybd_device(
                &runtime.device,
                drive.read_only(),
                &runtime.image_config_path,
                &output_dir,
                &snapshot_layer_file_name,
                "drive",
            )
            .await
            .with_context(|| format!("snapshot extra drive '{}'", drive.drive_id()))?;
            snapped.push(
                drive
                    .with_image_config_path(snapshot_image_config_path)
                    .try_with_virtual_size(runtime.actual_virtual_size)?,
            );
        }

        Ok(snapped)
    }

    fn has_writable_persistent_volumes(&self) -> bool {
        self.launch
            .common()
            .extra_drives
            .iter()
            .any(|drive| !drive.read_only() && drive.snapshot_output_dir().is_some())
    }

    async fn snapshot_persistent_volume_drives(&self) -> Result<()> {
        let extra_drives = &self.launch.common().extra_drives;
        anyhow::ensure!(
            extra_drives.len() == self.resources.extra_drive_runtimes.len(),
            "extra drive bookkeeping mismatch: {} configured drives but {} prepared devices",
            extra_drives.len(),
            self.resources.extra_drive_runtimes.len()
        );

        for (drive, runtime) in extra_drives
            .iter()
            .zip(&self.resources.extra_drive_runtimes)
        {
            let Some(output_dir) = drive.snapshot_output_dir() else {
                continue;
            };
            if drive.read_only() {
                continue;
            }
            let snapshot_layer_file_name = format!("snapshot-{}.commit", Uuid::now_v7().simple());
            restack_snapshot_overlaybd_device(
                &runtime.device,
                false,
                &runtime.image_config_path,
                output_dir,
                &snapshot_layer_file_name,
                "volume",
            )
            .await
            .with_context(|| format!("snapshot persistent volume '{}'", drive.drive_id()))?;
        }
        Ok(())
    }

    fn runtime_image_config_paths(&self) -> Vec<PathBuf> {
        let mut paths = Vec::new();
        if let Some(tools) = &self.resources.tools_ublk_device {
            paths.push(tools.image_config_path().to_path_buf());
        }
        if let Some(rootfs_runtime) = &self.resources.rootfs_runtime {
            paths.push(rootfs_runtime.image_config_path.clone());
        }
        paths.extend(
            self.resources
                .extra_drive_runtimes
                .iter()
                .map(|runtime| runtime.image_config_path.clone()),
        );
        paths
    }
}

const MIB: u64 = 1024 * 1024;
const GIB: u64 = 1024 * MIB;

fn damon_monitor_region(mem_size_mib: u32, arch: &str) -> Option<(u64, u64)> {
    let memory_size = u64::from(mem_size_mib).checked_mul(MIB)?;
    if memory_size == 0 {
        return None;
    }

    match arch {
        "x86_64" => {
            let end = if memory_size <= 3 * GIB {
                memory_size
            } else if memory_size <= 255 * GIB {
                memory_size + GIB
            } else {
                memory_size + 257 * GIB
            };
            Some((4096, end))
        }
        "aarch64" => {
            let end = if memory_size <= 254 * GIB {
                2 * GIB + memory_size
            } else {
                memory_size + 258 * GIB
            };
            Some((2 * GIB, end))
        }
        _ => None,
    }
}

fn add_damon_monitor_region(
    boot_args: Option<String>,
    mem_size_mib: u32,
    arch: &str,
) -> Option<String> {
    let mut args = boot_args?;
    let has_monitor_region = args.split_whitespace().any(|arg| {
        arg.starts_with("damon_reclaim.monitor_region_start=")
            || arg.starts_with("damon_reclaim.monitor_region_end=")
    });
    let use_computed_region = args
        .split_whitespace()
        .any(|arg| arg == "damon_reclaim.monitor_region_start=0")
        && args
            .split_whitespace()
            .any(|arg| arg == "damon_reclaim.monitor_region_end=0");
    if has_monitor_region && !use_computed_region {
        return Some(args);
    }

    let Some((start, end)) = damon_monitor_region(mem_size_mib, arch) else {
        return Some(args);
    };
    if use_computed_region {
        args = args
            .split_whitespace()
            .filter(|arg| {
                *arg != "damon_reclaim.monitor_region_start=0"
                    && *arg != "damon_reclaim.monitor_region_end=0"
            })
            .collect::<Vec<_>>()
            .join(" ");
    }
    Some(format!(
        "{args} damon_reclaim.monitor_region_start={start} damon_reclaim.monitor_region_end={end}"
    ))
}

// ── LaunchMode ───────────────────────────────────────────────────────────────

enum LaunchMode {
    Fresh(FirecrackerSandboxConfig),
    Resume(FirecrackerSnapshotConfig),
}

impl LaunchMode {
    fn common(&self) -> &FirecrackerCommonConfig {
        match self {
            LaunchMode::Fresh(config) => &config.common,
            LaunchMode::Resume(config) => &config.common,
        }
    }

    fn managed_snapshot_root(&self) -> Option<Arc<PersistentSnapshotRootGuard>> {
        match self {
            LaunchMode::Fresh(_) => None,
            LaunchMode::Resume(config) => config.managed_snapshot_root.clone(),
        }
    }

    fn validate(&self) -> Result<()> {
        match self {
            LaunchMode::Fresh(config) => config.validate(),
            LaunchMode::Resume(config) => config.validate(),
        }
    }
}

/// Copy a file using reflink (CoW) if available, falling back to a full copy.
async fn copy_cow(src: &Path, dst: &Path) -> Result<()> {
    let src = src.to_path_buf();
    let dst = dst.to_path_buf();
    // File copying can be multi-GB on snapshot paths, so keep the whole
    // reflink-or-copy fallback on a blocking thread.
    tokio::task::spawn_blocking(move || {
        let mut cmd = std::process::Command::new("cp");
        if cfg!(target_os = "linux") {
            cmd.arg("--reflink=auto");
        }
        let status = cmd.arg(&src).arg(&dst).status();
        if let Ok(s) = status {
            if s.success() {
                return Ok(());
            }
        }
        tracing::warn!(?src, ?dst, "reflink unavailable, falling back to full copy");
        fs::copy(&src, &dst)?;
        Ok(())
    })
    .await
    .context("copy_cow task failed")?
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cfg::ToolsConfig;
    use crate::sandbox::{SandboxAccessTokenGenerator, SandboxExecutor};
    use crate::snapshot::{CommittedSnapshot, RunnableSnapshot, SnapshotRecord};
    use std::collections::HashMap;

    fn fresh_config() -> FirecrackerSandboxConfig {
        FirecrackerSandboxConfig::new(
            "firecracker".into(),
            "vmlinux.bin".into(),
            "0.1.0".to_string(),
            "user-image.json".into(),
        )
    }

    #[test]
    fn damon_monitor_region_follows_firecracker_memory_layout() {
        assert_eq!(damon_monitor_region(1024, "x86_64"), Some((4096, GIB)));
        assert_eq!(damon_monitor_region(3072, "x86_64"), Some((4096, 3 * GIB)));
        assert_eq!(
            damon_monitor_region(3073, "x86_64"),
            Some((4096, 4 * GIB + MIB))
        );
        assert_eq!(damon_monitor_region(4096, "x86_64"), Some((4096, 5 * GIB)));
        assert_eq!(damon_monitor_region(8192, "x86_64"), Some((4096, 9 * GIB)));
        assert_eq!(
            damon_monitor_region(255 * 1024, "x86_64"),
            Some((4096, 256 * GIB))
        );
        assert_eq!(
            damon_monitor_region(255 * 1024 + 1, "x86_64"),
            Some((4096, 512 * GIB + MIB))
        );
        assert_eq!(
            damon_monitor_region(u32::MAX, "x86_64"),
            Some((4096, u64::from(u32::MAX) * MIB + 257 * GIB))
        );

        assert_eq!(
            damon_monitor_region(1024, "aarch64"),
            Some((2 * GIB, 3 * GIB))
        );
        assert_eq!(
            damon_monitor_region(254 * 1024, "aarch64"),
            Some((2 * GIB, 256 * GIB))
        );
        assert_eq!(
            damon_monitor_region(254 * 1024 + 1, "aarch64"),
            Some((2 * GIB, 512 * GIB + MIB))
        );
        assert_eq!(
            damon_monitor_region(u32::MAX, "aarch64"),
            Some((2 * GIB, u64::from(u32::MAX) * MIB + 258 * GIB))
        );
        assert_eq!(damon_monitor_region(0, "x86_64"), None);
        assert_eq!(damon_monitor_region(1024, "riscv64"), None);
    }

    #[test]
    fn damon_monitor_region_is_added_only_when_needed() {
        for args in [
            "console=ttyS0",
            "console=ttyS0 damon_reclaim.enabled=Y",
            "console=ttyS0 damon_reclaim.enabled=N",
        ] {
            let expected = format!(
                "{args} damon_reclaim.monitor_region_start=4096 \
                 damon_reclaim.monitor_region_end=5368709120"
            );
            assert_eq!(
                add_damon_monitor_region(Some(args.to_string()), 4096, "x86_64").as_deref(),
                Some(expected.as_str())
            );
        }

        for unchanged in [
            "damon_reclaim.enabled=Y damon_reclaim.monitor_region_start=1234",
            "damon_reclaim.enabled=Y damon_reclaim.monitor_region_end=5678",
            "damon_reclaim.monitor_region_start=1234 damon_reclaim.monitor_region_end=5678",
        ] {
            assert_eq!(
                add_damon_monitor_region(Some(unchanged.to_string()), 4096, "x86_64").as_deref(),
                Some(unchanged)
            );
        }

        assert_eq!(
            add_damon_monitor_region(
                Some(
                    "console=ttyS0 damon_reclaim.monitor_region_start=0 \
                     damon_reclaim.monitor_region_end=0"
                        .to_string()
                ),
                4096,
                "x86_64"
            )
            .as_deref(),
            Some(
                "console=ttyS0 damon_reclaim.monitor_region_start=4096 \
                 damon_reclaim.monitor_region_end=5368709120"
            )
        );

        assert_eq!(
            add_damon_monitor_region(Some("console=ttyS0".to_string()), 4096, "riscv64"),
            Some("console=ttyS0".to_string())
        );
        assert_eq!(add_damon_monitor_region(None, 4096, "x86_64"), None);
    }

    #[tokio::test]
    async fn disabled_firecracker_logging_creates_no_serial_files() -> Result<()> {
        for level in [None, Some(""), Some(" \t ")] {
            for persistent in [false, true] {
                let root = TempDir::new()?;
                let serial_root = root.path().join("serial");
                let mut config = fresh_config();
                config.common.firecracker_work_base_dir = Some(root.path().join("work"));
                config.common.serial_output_base_dir = persistent.then(|| serial_root.clone());
                config.common.firecracker_log_level = level.map(str::to_owned);
                let mut sandbox = FirecrackerSandbox::new(config)?;
                sandbox.configure_logger(sandbox.launch.common()).await?;
                for (stdout, stderr) in [
                    sandbox.firecracker_stdio_paths(),
                    warm_stdio_paths(sandbox.work_dir.path(), logging_enabled(level)),
                ] {
                    sandbox
                        .fc_instance
                        .spawn_with_netns(
                            Path::new("/bin/true"),
                            stdout.as_deref(),
                            stderr.as_deref(),
                            None,
                        )
                        .await?;
                    sandbox
                        .fc_instance
                        .stop(std::time::Duration::from_secs(1))
                        .await?;
                    relocate_warm_log(stdout.as_deref(), &sandbox.firecracker_stdout_path())?;
                    relocate_warm_log(stderr.as_deref(), &sandbox.firecracker_stderr_path())?;
                }

                assert!(!sandbox
                    .work_dir
                    .path()
                    .join("firecracker-stdout.log")
                    .exists());
                assert!(!sandbox
                    .work_dir
                    .path()
                    .join("firecracker-stderr.log")
                    .exists());
                assert!(
                    !serial_root.exists(),
                    "disabled logging created a serial root"
                );
                assert!(!sandbox.default_log_dir().exists());
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn enabled_firecracker_logging_captures_cold_and_warm_output() -> Result<()> {
        for warm in [false, true] {
            let root = TempDir::new()?;
            let mut config = fresh_config();
            config.common.firecracker_work_base_dir = Some(root.path().join("work"));
            config.common.serial_output_base_dir = Some(root.path().join("serial"));
            config.common.firecracker_log_level = Some(" Info ".to_owned());
            let mut sandbox = FirecrackerSandbox::new(config)?;
            let (stdout, stderr) = if warm {
                warm_stdio_paths(sandbox.work_dir.path(), true)
            } else {
                sandbox.firecracker_stdio_paths()
            };

            // echo accepts the Firecracker arguments and writes them to stdout.
            sandbox
                .fc_instance
                .spawn_with_netns(
                    Path::new("/bin/echo"),
                    stdout.as_deref(),
                    stderr.as_deref(),
                    None,
                )
                .await?;
            let err = sandbox
                .fc_instance
                .wait_for_ready(
                    std::time::Duration::from_secs(1),
                    std::time::Duration::from_millis(1),
                )
                .await
                .expect_err("echo exits without creating an API socket");
            assert!(err.to_string().contains("exited before its API socket"));
            sandbox
                .fc_instance
                .stop(std::time::Duration::from_secs(1))
                .await?;

            relocate_warm_log(stdout.as_deref(), &sandbox.firecracker_stdout_path())?;
            relocate_warm_log(stderr.as_deref(), &sandbox.firecracker_stderr_path())?;
            assert!(fs::read_to_string(sandbox.firecracker_stdout_path())?.contains("--api-sock"));
            assert!(sandbox.firecracker_stderr_path().is_file());
        }
        Ok(())
    }

    #[test]
    fn explicit_firecracker_stdio_enables_only_the_requested_stream() -> Result<()> {
        for capture_stdout in [false, true] {
            let root = TempDir::new()?;
            let destination = root.path().join("capture");
            let mut config = fresh_config();
            config.common.firecracker_work_base_dir = Some(root.path().join("work"));
            config.common.stdout_path = capture_stdout.then(|| destination.clone());
            config.common.stderr_path = (!capture_stdout).then(|| destination.clone());
            let sandbox = FirecrackerSandbox::new(config)?;
            let (stdout, stderr) = sandbox.firecracker_stdio_paths();
            assert_eq!(
                stdout,
                capture_stdout.then(|| destination.join("firecracker-stdout.log"))
            );
            assert_eq!(
                stderr,
                (!capture_stdout).then(|| destination.join("firecracker-stderr.log"))
            );
        }
        Ok(())
    }

    #[test]
    fn fresh_volume_drives_use_reserved_slots() -> Result<()> {
        let work_base = TempDir::new()?;
        let physical_drive = ExtraDrive::try_new_overlaybd("data", "/tmp/data-image.json", true)?;
        let volume_drive =
            ExtraDrive::try_new_overlaybd("volume", "/tmp/volume-image.json", false)?
                .with_volume_snapshot_output_dir(None);
        let mut config = fresh_config();
        config.common.firecracker_work_base_dir = Some(work_base.path().to_path_buf());
        config.common.extra_drives = vec![volume_drive.clone(), physical_drive.clone()];

        let sandbox = FirecrackerSandbox::new(config)?;
        let common = sandbox.launch.common();

        assert_eq!(common.physical_extra_drive_count, 1);
        assert!(common.volume_drive_slots >= 1);
        assert_eq!(common.extra_drives, vec![physical_drive, volume_drive]);
        assert!(sandbox.initial_guest_drive_mounts.is_empty());
        Ok(())
    }

    #[test]
    fn fresh_read_only_volumes_are_mounted_after_boot() -> Result<()> {
        let work_base = TempDir::new()?;
        let physical_drive = ExtraDrive::try_new_overlaybd("data", "/tmp/data-image.json", true)?;
        let writable_volume =
            ExtraDrive::try_new_overlaybd("volume", "/tmp/volume-image.json", false)?
                .with_volume_snapshot_output_dir(None);
        let read_only_volume =
            ExtraDrive::try_new_overlaybd("image", "/tmp/image-image.json", true)?
                .with_volume_snapshot_output_dir(None);
        let mut config = fresh_config();
        config.common.firecracker_work_base_dir = Some(work_base.path().to_path_buf());
        config.common.extra_drives = vec![
            read_only_volume.clone(),
            physical_drive.clone(),
            writable_volume.clone(),
        ];

        let sandbox = FirecrackerSandbox::new(config)?;

        assert_eq!(
            sandbox.launch.common().extra_drives,
            vec![physical_drive, read_only_volume.clone(), writable_volume]
        );
        assert_eq!(
            sandbox.initial_guest_drive_mounts,
            vec![(1, read_only_volume)]
        );
        assert_eq!(
            build_drives_boot_arg(&sandbox.launch.common().extra_drives),
            Some("agentenv_drives=vdc:/mnt/data,vde:/mnt/volume".to_string())
        );
        Ok(())
    }

    fn overlaybd_config() -> FirecrackerSandboxConfig {
        let mut config = fresh_config();
        config.common.ublk_config = Some(crate::sandbox::ublk::UblkConfig::overlaybd(
            "overlaybd-image.json".into(),
            false,
        ));
        config
    }

    fn rate_limit_cfg() -> crate::cfg::DiskRateLimitConfig {
        crate::cfg::DiskRateLimitConfig {
            enabled: true,
            bandwidth_bytes_per_sec: 0,
            bandwidth_burst_bytes: 0,
            iops: 0,
            iops_burst: 0,
        }
    }

    #[test]
    fn rate_limiter_disabled_returns_none() {
        let mut cfg = rate_limit_cfg();
        cfg.enabled = false;
        cfg.bandwidth_bytes_per_sec = 104_857_600;
        assert!(build_disk_rate_limiter(&cfg).unwrap().is_none());
    }

    #[test]
    fn rate_limiter_enabled_but_all_zero_returns_none() {
        assert!(build_disk_rate_limiter(&rate_limit_cfg())
            .unwrap()
            .is_none());
    }

    #[test]
    fn rate_limiter_bandwidth_size_equals_per_second_rate() {
        let mut cfg = rate_limit_cfg();
        cfg.bandwidth_bytes_per_sec = 104_857_600; // 100 MB/s
        cfg.bandwidth_burst_bytes = 10_485_760;
        let rl = build_disk_rate_limiter(&cfg)
            .unwrap()
            .expect("limiter present");
        let bw = rl.bandwidth.expect("bandwidth bucket");
        // With refill pinned to 1000 ms, bucket size == sustained bytes/sec.
        assert_eq!(bw.refill_time, RATE_LIMIT_REFILL_TIME_MS);
        assert_eq!(bw.size, 104_857_600);
        assert_eq!(bw.one_time_burst, Some(10_485_760));
        assert!(rl.ops.is_none());
    }

    #[test]
    fn rate_limiter_iops_bucket_populated() {
        let mut cfg = rate_limit_cfg();
        cfg.iops = 3000;
        cfg.iops_burst = 500;
        let rl = build_disk_rate_limiter(&cfg)
            .unwrap()
            .expect("limiter present");
        let ops = rl.ops.expect("ops bucket");
        assert_eq!(ops.refill_time, RATE_LIMIT_REFILL_TIME_MS);
        assert_eq!(ops.size, 3000);
        assert_eq!(ops.one_time_burst, Some(500));
        assert!(rl.bandwidth.is_none());
    }

    #[test]
    fn rate_limiter_rejects_values_beyond_i64_range() {
        let mut cfg = rate_limit_cfg();
        cfg.bandwidth_bytes_per_sec = u64::MAX;
        assert!(build_disk_rate_limiter(&cfg).is_err());
    }

    #[test]
    fn reconcile_disabled_makes_both_buckets_disabled() {
        // Firecracker treats an absent bucket in a PATCH as "leave unchanged", so
        // clearing an inherited limiter requires overwriting BOTH buckets with a
        // disabled (size == 0) bucket rather than sending an empty RateLimiter.
        let mut cfg = rate_limit_cfg();
        cfg.enabled = false;
        cfg.bandwidth_bytes_per_sec = 100 << 20;
        cfg.iops = 3000;
        let rl = reconcile_disk_rate_limiter(&cfg).unwrap();
        let bw = rl.bandwidth.expect("bandwidth bucket present");
        let ops = rl.ops.expect("ops bucket present");
        assert_eq!(bw.size, 0);
        assert_eq!(ops.size, 0);
    }

    #[test]
    fn reconcile_bandwidth_only_clears_inherited_iops() {
        // Enabled with bandwidth but no iops: bandwidth gets its configured
        // bucket, while the unset iops dimension is overwritten with a disabled
        // bucket so a snapshot-inherited IOPS limit does not survive the resume.
        let mut cfg = rate_limit_cfg();
        cfg.enabled = true;
        cfg.bandwidth_bytes_per_sec = 100 << 20;
        cfg.iops = 0;
        let rl = reconcile_disk_rate_limiter(&cfg).unwrap();
        let bw = rl.bandwidth.expect("bandwidth bucket present");
        let ops = rl.ops.expect("ops bucket present");
        assert_eq!(bw.refill_time, RATE_LIMIT_REFILL_TIME_MS);
        assert_eq!(bw.size, 100 << 20);
        assert_eq!(ops.size, 0);
    }

    #[test]
    fn reconcile_iops_only_clears_inherited_bandwidth() {
        let mut cfg = rate_limit_cfg();
        cfg.enabled = true;
        cfg.bandwidth_bytes_per_sec = 0;
        cfg.iops = 3000;
        let rl = reconcile_disk_rate_limiter(&cfg).unwrap();
        let bw = rl.bandwidth.expect("bandwidth bucket present");
        let ops = rl.ops.expect("ops bucket present");
        assert_eq!(bw.size, 0);
        assert_eq!(ops.refill_time, RATE_LIMIT_REFILL_TIME_MS);
        assert_eq!(ops.size, 3000);
    }

    #[test]
    fn reconcile_both_dimensions_use_configured_buckets() {
        let mut cfg = rate_limit_cfg();
        cfg.enabled = true;
        cfg.bandwidth_bytes_per_sec = 100 << 20;
        cfg.iops = 3000;
        let rl = reconcile_disk_rate_limiter(&cfg).unwrap();
        let bw = rl.bandwidth.expect("bandwidth bucket present");
        let ops = rl.ops.expect("ops bucket present");
        assert_eq!(bw.refill_time, RATE_LIMIT_REFILL_TIME_MS);
        assert_eq!(bw.size, 100 << 20);
        assert_eq!(ops.refill_time, RATE_LIMIT_REFILL_TIME_MS);
        assert_eq!(ops.size, 3000);
    }

    #[test]
    fn paused_state_image_cache_paths_use_snapshot_artifact_config() {
        let mut common = fresh_config().common;
        common
            .rootfs_image_config
            .as_mut()
            .expect("fresh config has a rootfs")
            .image_config_path = "snapshot/rootfs/image.json".into();
        let state = FirecrackerPausedState::new(FirecrackerSnapshotConfig {
            memory_startup_pack: None,
            common,
            vm_state_path: "snapshot/vm_state.bin".into(),
            mem_overlaybd_config: OverlaybdConfig {
                image_config_path: "snapshot/mem_image.json".into(),
                read_only: true,
                runtime_upper_mode: overlaybd::config::UpperMode::LogStructured,
            },
            mem_virtual_size: 4096,
            managed_snapshot_root: None,
            pack_recording: false,
        });

        assert_eq!(
            state.runtime_artifacts(),
            RuntimeArtifactSet::from_overlaybd_image_configs(vec![PathBuf::from(
                "snapshot/rootfs/image.json"
            )])
        );
    }

    #[test]
    fn snapshot_restore_selects_current_runtime_and_preserves_guest_assets() -> Result<()> {
        let mut common = fresh_config().common;
        common.firecracker_binary = "/missing/old/firecracker".into();
        common.tools_drive_version = "captured-tools".into();
        common.envd_version = "captured-envd".into();
        let rootfs = common.rootfs_image_config.clone();
        let drives = serde_json::to_value(&common.extra_drives)?;
        let snapshot = FirecrackerSnapshotConfig {
            common,
            vm_state_path: "snapshot/vm_state.bin".into(),
            mem_overlaybd_config: OverlaybdConfig {
                image_config_path: "snapshot/mem_image.json".into(),
                read_only: true,
                runtime_upper_mode: overlaybd::config::UpperMode::LogStructured,
            },
            mem_virtual_size: 4096,
            managed_snapshot_root: None,
            pack_recording: false,
            memory_startup_pack: None,
        };
        let sandbox = FirecrackerSandbox::from_snapshot_config(&snapshot)?;
        let restored = sandbox.launch.common();
        assert_eq!(
            restored.firecracker_binary,
            ConfigManager::global_config().resolved_firecracker_binary_path()
        );
        assert_eq!(restored.tools_drive_version, "captured-tools");
        assert_eq!(restored.envd_version, "captured-envd");
        assert_eq!(
            serde_json::to_value(&restored.rootfs_image_config)?,
            serde_json::to_value(rootfs)?
        );
        assert_eq!(serde_json::to_value(&restored.extra_drives)?, drives);
        Ok(())
    }

    #[test]
    fn snapshot_config_runtime_identity_replaces_source_auth() -> Result<()> {
        let source_id = SandboxId::new();
        let child_id = SandboxId::new();
        let generator = SandboxAccessTokenGenerator::new("fork-test-seed")?;
        let source_token = generator.generate(source_id);
        let child_token = generator.generate(child_id);
        let mut common = fresh_config().common;
        common.mmds_metadata =
            Some(MmdsMetadata::new(source_id, "snapshot").with_access_token(Some(&source_token)));
        common.envd_access_token = Some(source_token.clone());
        let snapshot = FirecrackerSnapshotConfig {
            common,
            vm_state_path: "snapshot/vm_state.bin".into(),
            mem_overlaybd_config: OverlaybdConfig {
                image_config_path: "snapshot/mem_image.json".into(),
                read_only: true,
                runtime_upper_mode: overlaybd::config::UpperMode::LogStructured,
            },
            mem_virtual_size: 4096,
            managed_snapshot_root: None,
            pack_recording: false,
            memory_startup_pack: None,
        };

        let child = FirecrackerSandbox::from_snapshot_config_with_override(
            snapshot,
            child_id,
            Some(child_token.clone()),
        )?;
        let common = child.launch.common();
        let metadata = common.mmds_metadata.as_ref().expect("child MMDS metadata");
        let expected =
            MmdsMetadata::new(child_id, "snapshot").with_access_token(Some(&child_token));

        assert_eq!(child.id, child_id);
        assert_eq!(common.envd_access_token.as_ref(), Some(&child_token));
        assert_eq!(metadata.sandbox_id, child_id.to_string());
        assert_eq!(metadata.access_token_hash, expected.access_token_hash);
        assert_ne!(
            metadata.access_token_hash,
            MmdsMetadata::new(source_id, "snapshot")
                .with_access_token(Some(&source_token))
                .access_token_hash
        );
        Ok(())
    }

    #[test]
    fn paused_state_without_tools_drive_version_remains_readable_but_not_resumable() -> Result<()> {
        let temp = TempDir::new()?;
        let vm_state_path = temp.path().join("vm-state.bin");
        let mem_image_path = temp.path().join("mem-image.json");
        let rootfs_image_path = temp.path().join("rootfs-image.json");
        fs::write(&vm_state_path, b"state")?;
        fs::write(&mem_image_path, b"{}")?;
        fs::write(&rootfs_image_path, b"{}")?;

        let mut common = fresh_config().common;
        common.rootfs_virtual_size = Some(4096);
        common
            .rootfs_image_config
            .as_mut()
            .expect("fresh config has a rootfs")
            .image_config_path = rootfs_image_path;
        let mut value = serde_json::to_value(FirecrackerSnapshotConfig {
            memory_startup_pack: None,
            common,
            vm_state_path,
            mem_overlaybd_config: OverlaybdConfig {
                image_config_path: mem_image_path,
                read_only: true,
                runtime_upper_mode: overlaybd::config::UpperMode::LogStructured,
            },
            mem_virtual_size: 4096,
            managed_snapshot_root: None,
            pack_recording: false,
        })?;
        let common = value["common"]
            .as_object_mut()
            .expect("common config must be an object");
        common.remove("tools_drive_version");
        common.insert(
            "tools_drive_path".to_string(),
            serde_json::Value::String("/legacy/node/tools.ext4".to_string()),
        );

        let state = FirecrackerPausedState::decode(PathBuf::new(), value)?;

        assert!(state
            .snapshot_config()
            .common
            .tools_drive_version
            .is_empty());
        let err = state
            .snapshot_config()
            .validate()
            .expect_err("legacy paused state must not resume without a tools drive version");
        assert!(err
            .to_string()
            .contains("sandbox state does not record a tools drive version"));
        Ok(())
    }

    #[test]
    fn executor_requires_running_envd_instance() -> Result<()> {
        let sandbox = FirecrackerSandbox::new(fresh_config())?;
        let err = match SandboxExecutor::executor(&sandbox) {
            Ok(_) => panic!("envd should be missing"),
            Err(err) => err,
        };
        assert!(err.to_string().contains("Sandbox is not running"));
        Ok(())
    }

    #[tokio::test]
    async fn wait_for_ready_requires_envd_instance() -> Result<()> {
        let sandbox = FirecrackerSandbox::new(fresh_config())?;
        let err = sandbox
            .wait_for_ready()
            .await
            .expect_err("envd should be missing");
        assert!(err.to_string().contains("envd instance not initialized"));
        Ok(())
    }

    #[tokio::test]
    async fn stop_without_process_clears_envd_instance() -> Result<()> {
        let mut sandbox = FirecrackerSandbox::new(fresh_config())?;
        sandbox.envd_instance = Some(EnvdInstance::new(
            format!(
                "http://127.0.0.1:{}",
                ToolsConfig::default().control_plane_port
            ),
            None,
        ));

        sandbox.stop().await?;

        assert!(sandbox.envd_instance.is_none());
        Ok(())
    }

    #[test]
    fn host_interaction_ip_reflects_network_slot_state() -> Result<()> {
        let mut sandbox = FirecrackerSandbox::new(fresh_config())?;
        assert_eq!(sandbox.host_interaction_ip(), None);

        let manager = NetworkManager::new(false, 0, 0);
        let slot = manager.allocate_test_slot()?;
        let expected = slot.host_interaction_ip;
        sandbox.resources.network_slot = Some(slot);

        assert_eq!(sandbox.host_interaction_ip(), Some(expected));
        let slot = sandbox
            .resources
            .network_slot
            .take()
            .expect("network slot should still be present");
        manager.release(slot)?;
        Ok(())
    }

    #[test]
    fn work_rootfs_path_uses_overlaybd_symlink_path() -> Result<()> {
        let sandbox = FirecrackerSandbox::new(overlaybd_config())?;
        assert_eq!(
            sandbox.work_rootfs_path(),
            sandbox.work_dir.path().join("user-rootfs")
        );
        assert!(sandbox.uses_overlaybd_ublk());
        Ok(())
    }

    #[test]
    fn build_drives_boot_arg_uses_custom_mount_path() -> Result<()> {
        let drives = vec![
            ExtraDrive::try_new_overlaybd_with_mount_path(
                "data",
                "/tmp/data-image.json",
                true,
                "/workspace/data",
                None::<std::path::PathBuf>,
            )?,
            ExtraDrive::try_new_overlaybd("logs", "/tmp/logs-image.json", true)?,
        ];

        assert_eq!(
            build_drives_boot_arg(&drives),
            Some("agentenv_drives=vdc:/workspace/data,vdd:/mnt/logs".to_string())
        );
        Ok(())
    }

    #[test]
    fn build_drives_boot_arg_includes_sub_path() -> Result<()> {
        let drives = vec![ExtraDrive::try_new_overlaybd_with_mount_path(
            "data",
            "/tmp/data-image.json",
            true,
            "/mnt/data",
            Some("sub/dir"),
        )?];

        assert_eq!(
            build_drives_boot_arg(&drives),
            Some("agentenv_drives=vdc:/mnt/data:sub/dir".to_string())
        );
        Ok(())
    }

    #[test]
    fn build_drives_boot_arg_omits_drives_mounted_after_boot() -> Result<()> {
        let drives = vec![
            ExtraDrive::try_new_overlaybd("image", "/tmp/image.json", true)?
                .with_volume_snapshot_output_dir(None),
        ];

        assert_eq!(build_drives_boot_arg(&drives), None);
        Ok(())
    }

    #[test]
    fn fresh_slot_drives_precede_volumes() -> Result<()> {
        let work_base = TempDir::new()?;
        let volume = ExtraDrive::try_new_overlaybd("volume", "/tmp/volume-image.json", false)?
            .with_volume_snapshot_output_dir(None);
        let slot_drive = ExtraDrive::try_new_overlaybd("data", "/tmp/data-image.json", false)?
            .with_kind(ExtraDriveKind::LaunchSlot);
        let mut config = fresh_config();
        config.common.firecracker_work_base_dir = Some(work_base.path().to_path_buf());
        config.common.extra_drives = vec![volume.clone(), slot_drive.clone()];

        let sandbox = FirecrackerSandbox::new(config)?;

        let common = sandbox.launch.common();
        assert_eq!(common.physical_extra_drive_count, 0);
        assert_eq!(common.extra_drives, vec![slot_drive, volume]);
        Ok(())
    }

    #[test]
    fn snapshot_launch_adds_drives_after_committed_slot_drives() -> Result<()> {
        let committed_drive = crate::snapshot::ResolvedAttachedDrive::Overlaybd {
            drive_id: "data".to_owned(),
            image_config_path: "/tmp/data-image.json".into(),
            read_only: false,
            virtual_size: 4096,
            mount_path: ExtraDrive::default_mount_path("data"),
            sub_path: None,
        };
        let snapshot = RunnableSnapshot::from_test_slot_drive_manifest(
            SnapshotRecord::mock_ready(CommittedSnapshot::mock()),
            vec![committed_drive],
        );
        let volume = ExtraDrive::try_new_overlaybd("volume", "/tmp/volume-image.json", false)?
            .with_volume_snapshot_output_dir(None);
        let launch_config = SandboxLaunchConfig {
            sandbox_id: SandboxId::new(),
            snapshot_id: "tpl-test".to_string(),
            extra_drives: vec![volume.clone()],
            ..SandboxLaunchConfig::default()
        };

        let snapshot_config =
            FirecrackerSandbox::snapshot_config_for_launch(&snapshot, &launch_config)?;

        assert_eq!(snapshot_config.common.physical_extra_drive_count, 0);
        assert_eq!(
            snapshot_config
                .common
                .extra_drives
                .iter()
                .map(ExtraDrive::kind)
                .collect::<Vec<_>>(),
            vec![ExtraDriveKind::LaunchSlot, ExtraDriveKind::Volume]
        );
        assert_eq!(
            FirecrackerSandbox::initial_guest_drive_mounts_for_snapshot_launch(
                &snapshot_config,
                &launch_config
            ),
            vec![(1, volume.clone())]
        );

        let free_slots = snapshot.manifest().free_drive_slots();
        let too_many = SandboxLaunchConfig {
            extra_drives: vec![volume.clone(); free_slots + 1],
            ..launch_config.clone()
        };
        assert!(FirecrackerSandbox::snapshot_config_for_launch(&snapshot, &too_many).is_err());

        let slot_drive = ExtraDrive::try_new_overlaybd("logs", "/tmp/logs-image.json", false)?
            .with_kind(ExtraDriveKind::LaunchSlot);
        for extra_drives in [
            vec![ExtraDrive::try_new_overlaybd(
                "logs",
                "/tmp/logs-image.json",
                false,
            )?],
            vec![volume, slot_drive],
        ] {
            let invalid = SandboxLaunchConfig {
                extra_drives,
                ..launch_config.clone()
            };
            assert!(FirecrackerSandbox::snapshot_config_for_launch(&snapshot, &invalid).is_err());
        }
        Ok(())
    }

    #[test]
    fn from_snapshot_merges_launch_env_over_snapshot_env() -> Result<()> {
        let mut snapshot_env_vars = HashMap::new();
        snapshot_env_vars.insert("FROM_SNAPSHOT".to_string(), "true".to_string());
        snapshot_env_vars.insert("SHARED_KEY".to_string(), "snapshot".to_string());
        let record = SnapshotRecord {
            id: crate::snapshot::SnapshotId::generate(),
            ..SnapshotRecord::mock_ready(CommittedSnapshot {
                context: crate::snapshot::CommandContext::new(snapshot_env_vars, "/"),
                ..CommittedSnapshot::mock()
            })
        };
        let snapshot = RunnableSnapshot::from_test_manifest(record, Vec::new());
        let launch_config = SandboxLaunchConfig {
            env_vars: Some(HashMap::from([
                ("FROM_LAUNCH".to_string(), "true".to_string()),
                ("SHARED_KEY".to_string(), "launch".to_string()),
            ])),
            sandbox_id: SandboxId::new(),
            snapshot_id: "tpl-test".to_string(),
            network: None,
            extra_mmds: serde_json::Map::new(),
            extra_drives: Vec::new(),
            extra_drives_in_snapshot: false,
            custom_extension_params: None,
            envd_access_token: None,
        };

        let snapshot_config =
            FirecrackerSandbox::snapshot_config_for_launch(&snapshot, &launch_config)
                .expect("snapshot launch config should merge env vars");
        let env_vars = snapshot_config
            .common
            .env_vars
            .as_ref()
            .expect("env vars should be present after merge");
        assert_eq!(env_vars.get("FROM_SNAPSHOT"), Some(&"true".to_string()));
        assert_eq!(env_vars.get("FROM_LAUNCH"), Some(&"true".to_string()));
        assert_eq!(env_vars.get("SHARED_KEY"), Some(&"launch".to_string()));
        Ok(())
    }

    /// Build custom extension params from a JSON object literal.
    fn params(value: serde_json::Value) -> CustomExtensionParams {
        value
            .as_object()
            .expect("params must be a JSON object")
            .clone()
    }

    #[test]
    fn from_snapshot_custom_extension_params_launch_overrides_snapshot() -> Result<()> {
        let record = SnapshotRecord {
            id: crate::snapshot::SnapshotId::generate(),
            ..SnapshotRecord::mock_ready(CommittedSnapshot {
                custom_extension_params: Some(params(serde_json::json!({"from": "snapshot"}))),
                ..CommittedSnapshot::mock()
            })
        };
        let snapshot = RunnableSnapshot::from_test_manifest(record, Vec::new());

        // Launch-provided value wins over the snapshot-persisted one.
        let launch_config = SandboxLaunchConfig {
            sandbox_id: SandboxId::new(),
            snapshot_id: "tpl-test".to_string(),
            custom_extension_params: Some(params(serde_json::json!({"from": "launch"}))),
            ..SandboxLaunchConfig::default()
        };
        let snapshot_config =
            FirecrackerSandbox::snapshot_config_for_launch(&snapshot, &launch_config)?;
        assert_eq!(
            snapshot_config.common.custom_extension_params,
            Some(params(serde_json::json!({"from": "launch"})))
        );

        // Without a launch value, the snapshot's persisted config is inherited.
        let launch_config = SandboxLaunchConfig {
            sandbox_id: SandboxId::new(),
            snapshot_id: "tpl-test".to_string(),
            ..SandboxLaunchConfig::default()
        };
        let snapshot_config =
            FirecrackerSandbox::snapshot_config_for_launch(&snapshot, &launch_config)?;
        assert_eq!(
            snapshot_config.common.custom_extension_params,
            Some(params(serde_json::json!({"from": "snapshot"})))
        );
        Ok(())
    }

    #[test]
    fn snapshot_rootfs_virtual_size_requires_cached_value() -> Result<()> {
        let sandbox = FirecrackerSandbox::new(overlaybd_config())?;
        let err = sandbox
            .snapshot_rootfs_virtual_size()
            .expect_err("missing cached rootfs virtual size should fail");
        assert!(err
            .to_string()
            .contains("ensure start() was called before pause() or snapshot"));
        Ok(())
    }
}
