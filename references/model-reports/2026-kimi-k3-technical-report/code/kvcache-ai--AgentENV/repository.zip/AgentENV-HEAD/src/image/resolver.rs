use std::future::Future;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use anyhow::{anyhow, bail, Context, Result};
use serde::Deserialize;
use serde_json::{json, Value};
use tracing::{debug, info, trace, warn};

use super::cache::{local_image_services_from_app_config, CachedImageConfig, SourceImageStore};
use super::oci_image::{self, RegistryAuth, ResolvedImage};
use super::reference::{image_ref_candidates, registry_host_of};
use super::{
    ImageBaseContext, ImageCatalog, ImageError, ImageResolutionMetadata, ImageResult,
    IMAGE_TAG_PREFIX,
};
use crate::cfg::AppConfig;
use crate::image::oci_image::ImageFormat;
use crate::prometheus::MetricGuard;
use crate::types::{ImageTag, OverlaybdLayerRef};

const IMAGE_RESOLVE_STAGE_DURATION: &str = "agentenv_image_resolve_stage_duration_seconds";

/// artifactType published by accelerated-container-image (`obdconv`) for
/// overlaybd-native images.
const OVERLAYBD_NATIVE_ARTIFACT_TYPE: &str = "application/vnd.containerd.overlaybd.native.v1+json";

/// artifactType published by Azure Container Registry artifact streaming.
///
/// ACR converts an image to overlaybd and attaches the result as an OCI
/// referrer, but labels it with its own artifactType instead of
/// [`OVERLAYBD_NATIVE_ARTIFACT_TYPE`]. The referrer manifest itself is an
/// ordinary overlaybd-native manifest: each layer carries a tar `mediaType`
/// plus a `containerd.io/snapshot/overlaybd/blob-digest` annotation equal to
/// the layer's own digest, which [`ImageFormat::OverlaybdNative`] already
/// recognises. Only the discovery label differs, so accepting this
/// artifactType is enough to stream ACR images.
const ACR_ARTIFACT_STREAMING_ARTIFACT_TYPE: &str = "application/vnd.azure.artifact.streaming.v1";

/// artifactTypes that may front an overlaybd-native referrer, in preference
/// order. The referrer manifest is always re-validated by
/// [`try_resolve_overlaybd_referrer`] before it is used, so this list only
/// controls discovery.
const OVERLAYBD_REFERRER_ARTIFACT_TYPES: &[&str] = &[
    OVERLAYBD_NATIVE_ARTIFACT_TYPE,
    ACR_ARTIFACT_STREAMING_ARTIFACT_TYPE,
];

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ResolvedBlockImage {
    pub image_ref: String,
    pub overlaybd_config_path: PathBuf,
    pub base_context: ImageBaseContext,
    /// Raw source image config JSON, `None` when the image source has no config
    /// (e.g. bare overlaybd config path) or when loaded from a legacy cache entry.
    pub raw_config: Option<serde_json::Value>,
}

pub struct ImageResolver {
    repository: Option<Arc<dyn crate::repository::Repository>>,
    store: Arc<dyn SourceImageStore>,
    overlaybd_install_root: PathBuf,
    overlaybd_convert_global_config: PathBuf,
    overlaybd_oci_converter_id: String,
    regctl_binary: PathBuf,
    default_image: String,
    search_registries: Vec<String>,
    allowed_registries: Option<Vec<String>>,
    try_referrers_overlaybd_prefixes: Vec<String>,
    convert_standard_oci: bool,
}

impl std::fmt::Debug for ImageResolver {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ImageResolver").finish_non_exhaustive()
    }
}

impl ImageResolver {
    pub fn new(config: &AppConfig) -> Self {
        let store = local_image_services_from_app_config(config).source_images;
        Self {
            repository: None,
            store,
            overlaybd_install_root: config.deps_path.join("overlaybd"),
            overlaybd_convert_global_config: config.resolved_overlaybd_convert_global_config_path(),
            overlaybd_oci_converter_id: config.resolved_overlaybd_oci_converter_id(),
            regctl_binary: config.resolved_regctl_binary(),
            default_image: config.image.resolver.default_image.clone(),
            search_registries: config.image.resolver.search_registries.clone(),
            allowed_registries: config.image.resolver.allowed_registries.clone(),
            try_referrers_overlaybd_prefixes: config
                .image
                .resolver
                .try_referrers_overlaybd_prefixes
                .clone(),
            convert_standard_oci: config.image.resolver.convert_standard_oci,
        }
    }

    pub fn default_image(&self) -> &str {
        &self.default_image
    }

    pub(crate) async fn resolve_buildkit(
        &self,
        content: &super::buildkit::BuildkitContent,
        digest: &str,
    ) -> Result<ResolvedBlockImage> {
        anyhow::ensure!(
            self.convert_standard_oci,
            "standard OCI conversion is disabled"
        );
        let (fetched, metadata) =
            oci_image::fetch_content_manifest(content, digest, &detect_arch()?).await?;
        let source = self.store.open(&fetched.manifest_digest, None).await?;
        if let CachedImageConfig::Found {
            image_config_path, ..
        } = source.cached_config().await?
        {
            return Ok(resolved_from_cached_config(
                &fetched.manifest_digest,
                image_config_path,
                metadata,
            ));
        }
        let mut conversion = source.begin_conversion().await?;
        let image = oci_image::convert_content_image(
            content,
            &fetched,
            oci_image::OverlaybdConversionEnv {
                install_root: &self.overlaybd_install_root,
                global_config: &self.overlaybd_convert_global_config,
                converter_id: &self.overlaybd_oci_converter_id,
                regctl_binary: &self.regctl_binary,
                registry_config: None,
            },
            &mut *conversion,
        )
        .await?;
        let path = source
            .publish_config(
                &overlaybd_image_config_json(&image),
                metadata.clone(),
                conversion,
            )
            .await?;
        Ok(resolved_from_cached_config(
            &fetched.manifest_digest,
            path,
            metadata,
        ))
    }

    pub(crate) async fn resolve_tools(
        mut self,
        image_ref: &str,
    ) -> ImageResult<Option<ResolvedBlockImage>> {
        // System dependencies use their configured release source, independently
        // of the admission policy and conversion settings for user images.
        let arch = detect_arch()?;
        let mut fetched =
            oci_image::fetch_oci_manifest(&self.regctl_binary, image_ref, &arch, None).await?;
        if fetched.format() != ImageFormat::OverlaybdNative {
            let metadata = oci_image::fetch_oci_image_config_metadata(
                &self.regctl_binary,
                &fetched.selected_image_ref,
                fetched.config_digest(),
                None,
            )
            .await?;
            match metadata
                .base_context
                .labels
                .get("io.agentenv.tools-drive.format")
                .map(String::as_str)
            {
                None => return Ok(None),
                Some("oci-rootfs-v1") => {}
                Some(format) => {
                    return Err(ImageError::UnsupportedImage {
                        reason: format!("unsupported tools image format '{format}'"),
                    })
                }
            }
            // v1 is part of the immutable tools release contract, independently
            // of runtime upgrades and the conversion policy for user images.
            const _: () = assert!(oci_image::LAYER_VIRTUAL_SIZE_GIB == 64);
            let deps = self
                .overlaybd_install_root
                .parent()
                .context("overlaybd dependency root")?;
            self.overlaybd_install_root =
                crate::deps::overlaybd_tools::ensure_tools_converter_v1(deps).await?;
            self.overlaybd_oci_converter_id = "tools-oci-rootfs-v1:overlaybd-v1.0.18-aenv.1".into();
            self.convert_standard_oci = true;
            self.try_referrers_overlaybd_prefixes.clear();
            fetched.repository_scope = Some("tools-oci-rootfs-v1".into());
        }
        self.resolve_fetched_manifest(image_ref, &arch, fetched, None)
            .await
            .map(Some)
    }

    pub fn with_repository(mut self, repository: Arc<dyn crate::repository::Repository>) -> Self {
        self.repository = Some(repository);
        self
    }

    pub(crate) async fn publish_image<'a, F, Fut>(
        &'a self,
        image: &'a ResolvedBlockImage,
        store_layers: F,
    ) -> Result<String>
    where
        F: FnOnce(&'a dyn crate::repository::Repository, &'a Path) -> Fut,
        Fut: Future<Output = crate::repository::RepositoryResult<Vec<OverlaybdLayerRef>>>,
    {
        let repository = self
            .repository
            .as_ref()
            .context("image repository is not configured")?;
        // Capacity eviction takes this same source-image lock. Keep the local
        // converted layers rooted until the repository has committed them.
        let source = self.store.open(&image.image_ref, None).await?;
        let _source_lock = source.begin_conversion().await?;
        let config = image
            .raw_config
            .clone()
            .context("built image configuration is missing")?;
        let layers =
            store_layers(repository.as_ref(), image.overlaybd_config_path.as_path()).await?;
        let description = super::PublishedImage::new(
            oci_image::host_arch_to_oci(&detect_arch()?)?.into(),
            layers,
            config,
        );
        Ok(repository.put_image(&description).await?)
    }

    async fn resolve_published(&self, digest: &str) -> ImageResult<ResolvedBlockImage> {
        super::buildkit::validate_digest(digest).map_err(|error| ImageError::InvalidReference {
            reason: error.to_string(),
        })?;
        let repository = self
            .repository
            .as_ref()
            .context("image repository is not configured")?;
        let image = repository
            .get_image(digest)
            .await
            .map_err(anyhow::Error::from)?
            .ok_or_else(|| ImageError::NotFound {
                reason: format!("published OverlayBD image '{digest}' was not found"),
            })?;
        if image.architecture != oci_image::host_arch_to_oci(&detect_arch()?)? {
            return Err(ImageError::UnsupportedImage {
                reason: format!("image requires {}", image.architecture),
            });
        }
        let metadata = oci_image::parse_oci_image_config(
            &serde_json::to_string(&json!({"config": image.config}))
                .map_err(anyhow::Error::from)?,
        )?;
        let source = self
            .store
            .open(digest, Some("published-overlaybd-v1"))
            .await?;
        if let CachedImageConfig::Found {
            image_config_path, ..
        } = source.cached_config().await?
        {
            return Ok(resolved_from_cached_config(
                digest,
                image_config_path,
                metadata,
            ));
        }
        let conversion = source.begin_conversion().await?;
        let work = tempfile::tempdir().context("materialize published image")?;
        let path = crate::repository::materialize_volume_backing(
            repository.as_ref(),
            &image.layers,
            &work.path().join("image.json"),
        )
        .await
        .map_err(anyhow::Error::from)?;
        let config: Value =
            serde_json::from_slice(&tokio::fs::read(path).await.map_err(anyhow::Error::from)?)
                .map_err(anyhow::Error::from)?;
        let path = source
            .publish_config(&config, metadata.clone(), conversion)
            .await?;
        Ok(resolved_from_cached_config(digest, path, metadata))
    }

    /// Resolves a tag to the digest it points to now. The result carries only
    /// the digest, so moving the tag later never changes this resolution.
    async fn resolve_tag(&self, reference: &str) -> ImageResult<ResolvedBlockImage> {
        let tag = ImageTag::parse(reference).map_err(|error| ImageError::InvalidReference {
            reason: error.to_string(),
        })?;
        let repository = self
            .repository
            .as_ref()
            .context("image repository is not configured")?;
        let digest = repository
            .get_image_tag(&tag)
            .await
            .map_err(anyhow::Error::from)?
            .ok_or_else(|| ImageError::NotFound {
                reason: format!("image tag '{tag}' was not found"),
            })?;
        debug!(%tag, %digest, "resolved image tag");
        self.resolve_published(&digest)
            .await
            .map_err(|error| error.context(format_args!("image tag '{tag}'")))
    }

    pub async fn resolve(&self, image_ref: &str) -> ImageResult<ResolvedBlockImage> {
        self.resolve_with_registry_auth(image_ref, None).await
    }

    pub(crate) async fn resolve_with_registry_auth(
        &self,
        image_ref: &str,
        auth: Option<&RegistryAuth>,
    ) -> ImageResult<ResolvedBlockImage> {
        // Bare digests identify repository-owned OverlayBD descriptions, not
        // OCI manifests or node-local conversion cache entries.
        let trimmed = image_ref.trim();
        if let Some(reference) = trimmed.strip_prefix(IMAGE_TAG_PREFIX) {
            if auth.is_some() {
                return Err(ImageError::InvalidReference {
                    reason: "fromImageRegistry cannot be used with AgentENV published images"
                        .into(),
                });
            }
            return self.resolve_tag(reference).await;
        }
        if trimmed.starts_with("sha256:") {
            if auth.is_some() {
                return Err(ImageError::InvalidReference {
                    reason: "fromImageRegistry cannot be used with AgentENV published images"
                        .into(),
                });
            }
            return self.resolve_published(trimmed).await;
        }
        let candidates = image_ref_candidates(
            image_ref,
            &self.search_registries,
            self.allowed_registries.as_deref(),
        )?;
        if auth.is_some() && candidates.len() != 1 {
            return Err(ImageError::InvalidReference {
                reason: "fromImageRegistry requires an unambiguous image registry; use a fully-qualified fromImage".into(),
            });
        }
        let registry_config = match auth {
            Some(auth) => Some(
                auth.config(registry_host_of(&candidates[0]).context("image registry host")?)
                    .await?,
            ),
            None => None,
        };
        let config_path = registry_config.as_ref().map(|config| config.path());
        let arch = detect_arch()?;
        let mut manifest_failures = Vec::new();
        // Track whether every candidate failed specifically because the
        // registry returned HTTP 404. If so, the overall failure is a user
        // error (the image does not exist) rather than a server error, and we
        // return a typed `NotFound` so the API layer can map it to a 4xx.
        let mut all_not_found = true;

        for candidate in candidates {
            // The manifest fetch is the only "wrong registry, try the next one"
            // stage. Once a manifest is fetched, any later failure is fatal and
            // aborts the whole resolve.
            let mut metric = MetricGuard::stage(IMAGE_RESOLVE_STAGE_DURATION, "manifest_fetch");
            let fetched =
                oci_image::fetch_oci_manifest(&self.regctl_binary, &candidate, &arch, config_path)
                    .await;
            metric.finish(&fetched);
            let fetched = match fetched {
                Ok(fetched) => fetched,
                Err(ImageError::NotFound { reason }) => {
                    warn!(
                        image = %candidate,
                        error = %reason,
                        "image resolver candidate does not exist; trying next candidate"
                    );
                    manifest_failures.push(format!("{candidate}: {reason}"));
                    continue;
                }
                // The manifest was fetched successfully but describes an image
                // AgentENV cannot run (e.g. overlaybd turbo-OCI). The image
                // exists, so trying other registries is pointless; surface the
                // typed error directly so the API maps it to a 4xx.
                Err(err @ ImageError::UnsupportedImage { .. }) => {
                    return Err(err.context(format!("resolve image '{candidate}'")));
                }
                Err(err) => {
                    warn!(
                        image = %candidate,
                        error = %format_args!("{err:#}"),
                        "image resolver candidate manifest fetch failed; trying next candidate"
                    );
                    all_not_found = false;
                    manifest_failures.push(format!("{candidate}: {err:#}"));
                    continue;
                }
            };
            return self
                .resolve_fetched_manifest(&candidate, &arch, fetched, config_path)
                .await;
        }

        let message = format!(
            "resolve image '{}' to overlaybd: all registry candidates failed during manifest fetch: {}",
            image_ref.trim(),
            manifest_failures.join("; ")
        );
        if all_not_found {
            Err(ImageError::NotFound { reason: message })
        } else {
            Err(ImageError::Other(anyhow!(message)))
        }
    }

    /// Resolve a successfully-fetched manifest into a block image. Failures
    /// here are fatal: the manifest already proved the registry has the image.
    async fn resolve_fetched_manifest(
        &self,
        image_ref: &str,
        arch: &str,
        fetched: oci_image::FetchedManifest,
        registry_config: Option<&std::path::Path>,
    ) -> ImageResult<ResolvedBlockImage> {
        let source_image_ref = fetched.selected_image_ref.clone();
        // Config metadata comes from the source image even when layer
        // resolution is redirected to an overlaybd referrer below.
        let source_config_digest = fetched.config_digest().to_string();
        let mut overlaybd_image_ref = source_image_ref.clone();
        let fetched = if should_try_overlaybd_referrers(
            &source_image_ref,
            &self.try_referrers_overlaybd_prefixes,
        ) && fetched.format() != ImageFormat::OverlaybdNative
        {
            match try_resolve_overlaybd_referrer(
                &self.regctl_binary,
                &source_image_ref,
                arch,
                registry_config,
            )
            .await
            {
                Ok(Some((referrer, artifact_type))) => {
                    overlaybd_image_ref = referrer.selected_image_ref.clone();
                    info!(
                        image = %image_ref,
                        subject = %source_image_ref,
                        overlaybd_referrer = %overlaybd_image_ref,
                        artifact_type,
                        "using overlaybd-native OCI referrer instead of source image"
                    );
                    referrer
                }
                Ok(None) => {
                    trace!(
                        image = %image_ref,
                        subject = %source_image_ref,
                        artifact_types = ?OVERLAYBD_REFERRER_ARTIFACT_TYPES,
                        "no overlaybd-native OCI referrer found; continuing with source image"
                    );
                    fetched
                }
                Err(err) => {
                    warn!(
                        image = %image_ref,
                        subject = %source_image_ref,
                        error = %err,
                        "failed to use overlaybd OCI referrer; continuing with source image"
                    );
                    fetched
                }
            }
        } else {
            fetched
        };
        validate_registry_auth_for_format(fetched.format(), registry_config.is_some())?;
        if fetched.format() == ImageFormat::StandardOci && !self.convert_standard_oci {
            return Err(ImageError::InvalidReference {
                reason: format!(
                    "image '{image_ref}' is standard OCI, but AgentENV standard OCI to overlaybd conversion is disabled by image.resolver.convert_standard_oci=false; publish an overlaybd-native image or enable conversion"
                ),
            });
        }
        let manifest_digest = fetched.manifest_digest.clone();
        let repository_scope = fetched.repository_scope.clone();
        let scope = repository_scope.as_deref();
        let source = self.store.open(&manifest_digest, scope).await?;

        match source.cached_config().await? {
            CachedImageConfig::Found {
                image_config_path,
                metadata: Some(metadata),
            } => {
                metrics::counter!(
                    "agentenv_image_resolve_cache_total",
                    "result" => "hit",
                    "image_format" => fetched.format().to_string(),
                    "registry" => registry_label(&source_image_ref),
                )
                .increment(1);
                return Ok(resolved_from_cached_config(
                    &source_image_ref,
                    image_config_path,
                    *metadata,
                ));
            }
            CachedImageConfig::Found {
                image_config_path,
                metadata: None,
            } => {
                metrics::counter!(
                    "agentenv_image_resolve_cache_total",
                    "result" => "hit",
                    "image_format" => fetched.format().to_string(),
                    "registry" => registry_label(&source_image_ref),
                )
                .increment(1);
                let metadata = oci_image::fetch_oci_image_config_metadata(
                    &self.regctl_binary,
                    &source_image_ref,
                    &source_config_digest,
                    registry_config,
                )
                .await
                .map_err(|e| e.context(format!("fetch image metadata for '{source_image_ref}'")))?;
                source.write_metadata(metadata.clone()).await?;
                return Ok(resolved_from_cached_config(
                    &source_image_ref,
                    image_config_path,
                    metadata,
                ));
            }
            CachedImageConfig::Missing => {}
        }
        metrics::counter!(
            "agentenv_image_resolve_cache_total",
            "result" => "miss",
            "image_format" => fetched.format().to_string(),
            "registry" => registry_label(&source_image_ref),
        )
        .increment(1);

        let mut conversion = source.begin_conversion().await?;

        let mut metric = MetricGuard::stage(IMAGE_RESOLVE_STAGE_DURATION, "config_fetch");
        let image_config_metadata = oci_image::fetch_oci_image_config_metadata(
            &self.regctl_binary,
            &source_image_ref,
            &source_config_digest,
            registry_config,
        )
        .await
        .map_err(|e| e.context(format!("fetch image metadata for '{source_image_ref}'")));
        metric.finish(&image_config_metadata);
        let image_config_metadata = image_config_metadata?;

        let mut metric = MetricGuard::stage(IMAGE_RESOLVE_STAGE_DURATION, "layer_convert");
        let resolved = oci_image::convert_fetched_oci_image_to_overlaybd(
            &overlaybd_image_ref,
            fetched,
            oci_image::OverlaybdConversionEnv {
                install_root: &self.overlaybd_install_root,
                global_config: &self.overlaybd_convert_global_config,
                converter_id: &self.overlaybd_oci_converter_id,
                regctl_binary: &self.regctl_binary,
                registry_config,
            },
            &mut *conversion,
            arch,
        )
        .await
        .map_err(|e| e.context(format!("resolve image '{image_ref}' to overlaybd")));
        metric.finish(&resolved);
        let resolved = resolved?;
        let overlaybd_config = overlaybd_image_config_json(&resolved);
        let image_config_path = source
            .publish_config(&overlaybd_config, image_config_metadata.clone(), conversion)
            .await?;

        info!(
            image = %image_ref,
            source_image = %source_image_ref,
            resolved_image = %overlaybd_image_ref,
            manifest_digest = %manifest_digest,
            repository_scope = ?scope,
            config = %image_config_path.display(),
            "image resolved to overlaybd config"
        );

        Ok(resolved_from_cached_config(
            &source_image_ref,
            image_config_path,
            image_config_metadata,
        ))
    }
}

/// Validate the final selected format, including any OverlayBD referrer,
/// before accessing the image cache or fetching config/layer blobs.
fn validate_registry_auth_for_format(
    format: ImageFormat,
    has_registry_auth: bool,
) -> ImageResult<()> {
    if format == ImageFormat::OverlaybdNative && has_registry_auth {
        return Err(ImageError::UnsupportedImage {
            reason: "fromImageRegistry is not supported for OverlayBD images (including OverlayBD referrers); use a standard OCI image or omit fromImageRegistry and configure server-side registry credentials".into(),
        });
    }
    Ok(())
}

fn resolved_from_cached_config(
    source_image_ref: &str,
    image_config_path: PathBuf,
    metadata: ImageResolutionMetadata,
) -> ResolvedBlockImage {
    ResolvedBlockImage {
        image_ref: source_image_ref.to_string(),
        overlaybd_config_path: image_config_path,
        base_context: metadata.base_context,
        raw_config: metadata.raw_config,
    }
}

fn should_try_overlaybd_referrers(image_ref: &str, prefixes: &[String]) -> bool {
    prefixes.iter().any(|prefix| image_ref.starts_with(prefix))
}

async fn try_resolve_overlaybd_referrer(
    regctl_binary: &std::path::Path,
    subject_ref: &str,
    arch: &str,
    registry_config: Option<&std::path::Path>,
) -> Result<Option<(oci_image::FetchedManifest, &'static str)>> {
    let Some((referrer_digest, artifact_type)) =
        discover_overlaybd_referrer(regctl_binary, subject_ref, registry_config).await?
    else {
        return Ok(None);
    };
    let referrer_ref = oci_image::image_ref_with_digest(subject_ref, &referrer_digest)
        .with_context(|| format!("build overlaybd referrer reference for {subject_ref}"))?;
    let referrer =
        oci_image::fetch_oci_manifest(regctl_binary, &referrer_ref, arch, registry_config)
            .await
            .with_context(|| format!("fetch overlaybd referrer manifest for {referrer_ref}"))?;
    if referrer.format() != ImageFormat::OverlaybdNative {
        bail!(
            "OCI referrer {referrer_ref} advertised artifactType {artifact_type} but its manifest is not overlaybd-native"
        );
    }
    Ok(Some((referrer, artifact_type)))
}

async fn discover_overlaybd_referrer(
    regctl_binary: &std::path::Path,
    subject_ref: &str,
    registry_config: Option<&std::path::Path>,
) -> Result<Option<(String, &'static str)>> {
    oci_image::ensure_regctl_binary(regctl_binary)
        .context("regctl is required to query OCI referrers")?;

    // The referrers index is fetched unfiltered and matched locally against
    // OVERLAYBD_REFERRER_ARTIFACT_TYPES: `regctl artifact list` takes a single
    // `--filter-artifact-type`, which cannot express "any of these types" in
    // one call.
    let output = oci_image::regctl_command(regctl_binary, registry_config)
        .arg("artifact")
        .arg("list")
        .arg("--format")
        .arg("body")
        .arg(subject_ref)
        .output()
        .await
        .context("spawn regctl artifact list")?;

    if !output.status.success() {
        bail!(
            "regctl artifact list failed for {subject_ref}: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        );
    }

    let body = String::from_utf8(output.stdout).context("regctl output is not UTF-8")?;
    parse_overlaybd_referrer(&body)
        .with_context(|| format!("parse regctl referrers response for {subject_ref}"))
}

fn parse_overlaybd_referrer(body: &str) -> Result<Option<(String, &'static str)>> {
    let index: ReferrersIndex = serde_json::from_str(body).context("parse referrers index JSON")?;
    for &artifact_type in OVERLAYBD_REFERRER_ARTIFACT_TYPES {
        let mut matches = index
            .manifests
            .iter()
            .filter(|descriptor| descriptor.artifact_type.as_deref() == Some(artifact_type));
        let Some(selected) = matches.next() else {
            continue;
        };
        let candidates = matches.count() + 1;
        if candidates > 1 {
            warn!(
                artifact_type,
                selected_digest = %selected.digest,
                candidates,
                "multiple overlaybd-native OCI referrers found; using first"
            );
        }
        return Ok(Some((selected.digest.clone(), artifact_type)));
    }
    Ok(None)
}

#[derive(Debug, Deserialize)]
struct ReferrersIndex {
    #[serde(default)]
    manifests: Vec<ReferrerDescriptor>,
}

#[derive(Debug, Deserialize)]
struct ReferrerDescriptor {
    digest: String,
    #[serde(rename = "artifactType", default)]
    artifact_type: Option<String>,
}

fn detect_arch() -> Result<String> {
    match std::env::consts::ARCH {
        "x86_64" => Ok("x86_64".into()),
        "aarch64" => Ok("aarch64".into()),
        other => bail!("unsupported architecture: {other}"),
    }
}

/// Registry-host label for resolve metrics. Falls back to `"unknown"` when the
/// reference has no recognizable host segment, keeping cardinality bounded.
fn registry_label(image_ref: &str) -> String {
    registry_host_of(image_ref).unwrap_or("unknown").to_string()
}

fn overlaybd_image_config_json(resolved: &ResolvedImage) -> Value {
    let (repo_blob_url, lowers_json): (&str, Vec<serde_json::Value>) = match resolved {
        ResolvedImage::Local(paths) => {
            let lowers = paths
                .iter()
                .map(|layer| {
                    json!({
                        "file": layer.path.to_string_lossy().into_owned(),
                        "digest": layer.digest.clone(),
                        "size": layer.size
                    })
                })
                .collect();
            ("", lowers)
        }
        ResolvedImage::Remote {
            repo_blob_url,
            layers,
        } => {
            let lowers = layers
                .iter()
                .map(|l| {
                    json!({
                        "digest": l.digest,
                        "size": l.size,
                        "dir": l.dir.to_string_lossy().into_owned()
                    })
                })
                .collect();
            (repo_blob_url.as_str(), lowers)
        }
    };
    json!({
        "repoBlobUrl": repo_blob_url,
        "lowers": lowers_json,
        "upper": {},
        "resultFile": ""
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cfg::{ImageConfig, ImageResolverConfig};
    use crate::image::cache::ImageCacheService;
    use tempfile::TempDir;

    fn test_resolver_with_search(temp: &TempDir, search_registries: Vec<&str>) -> ImageResolver {
        let mut config = AppConfig {
            image: ImageConfig {
                resolver: ImageResolverConfig {
                    search_registries: search_registries
                        .into_iter()
                        .map(ToString::to_string)
                        .collect(),
                    ..ImageResolverConfig::default()
                },
                ..ImageConfig::default()
            },
            ..AppConfig::default()
        };
        ImageConfig::normalize(&mut config.image, temp.path(), temp.path());
        ImageResolver::new(&config)
    }

    #[tokio::test]
    async fn registry_auth_rejects_ambiguous_search_before_access() {
        let temp = tempfile::tempdir().unwrap();
        let resolver = test_resolver_with_search(&temp, vec!["one.example", "two.example"]);
        let auth = RegistryAuth::General {
            username: "reader".into(),
            password: "secret".into(),
        };
        let error = resolver
            .resolve_with_registry_auth("team/base", Some(&auth))
            .await
            .unwrap_err();
        assert!(error.is_user_error());
        assert!(error.to_string().contains("unambiguous"));
    }

    #[test]
    fn registry_auth_validates_selected_image_format() {
        for (format, has_auth, rejected) in [
            (ImageFormat::StandardOci, false, false),
            (ImageFormat::StandardOci, true, false),
            (ImageFormat::OverlaybdNative, false, false),
            (ImageFormat::OverlaybdNative, true, true),
        ] {
            let result = validate_registry_auth_for_format(format, has_auth);
            if rejected {
                assert!(matches!(result, Err(ImageError::UnsupportedImage { .. })));
                assert!(result.unwrap_err().is_user_error());
            } else {
                result.unwrap();
            }
        }
    }

    #[tokio::test]
    async fn registry_auth_rejects_published_images_before_repository_access() {
        let temp = tempfile::tempdir().unwrap();
        // No repository is configured: rejection must precede tag/digest lookup.
        let resolver = test_resolver_with_search(&temp, vec!["registry.example"]);
        let auth = RegistryAuth::General {
            username: "reader".into(),
            password: "secret".into(),
        };
        let digest = crate::digest::sha256_digest(b"published image");
        for reference in [" aenv/web:v1 ", digest.as_str()] {
            let error = resolver
                .resolve_with_registry_auth(reference, Some(&auth))
                .await
                .unwrap_err();
            assert!(matches!(error, ImageError::InvalidReference { .. }));
            assert!(error
                .to_string()
                .contains("fromImageRegistry cannot be used with AgentENV published images"));
        }
    }

    #[test]
    fn image_config_normalize_resolver_fields() {
        let temp = tempfile::tempdir().expect("tempdir");
        let mut config = ImageConfig {
            resolver: ImageResolverConfig {
                default_image: " ghcr.io/example/base:latest ".to_string(),
                search_registries: vec![
                    " registry.internal:5000/team/ ".to_string(),
                    "ghcr.io".to_string(),
                ],
                try_referrers_overlaybd_prefixes: vec![
                    " registry.example.com/team/ ".to_string(),
                    "".to_string(),
                    "registry.example.com/".to_string(),
                ],
                ..ImageResolverConfig::default()
            },
            ..ImageConfig::default()
        };
        ImageConfig::normalize(&mut config, temp.path(), temp.path());

        assert_eq!(config.resolver.default_image, "ghcr.io/example/base:latest");
        assert_eq!(
            config.resolver.search_registries,
            vec![
                "registry.internal:5000/team".to_string(),
                "ghcr.io".to_string()
            ]
        );
        assert_eq!(
            config.resolver.try_referrers_overlaybd_prefixes,
            vec![
                "registry.example.com/team/".to_string(),
                "registry.example.com/".to_string()
            ]
        );
    }

    #[test]
    fn image_config_normalize_allowed_registries_distinguishes_unset_and_empty() {
        let temp = tempfile::tempdir().expect("tempdir");

        // Unset key => None (no restriction).
        let mut unset = ImageConfig::default();
        ImageConfig::normalize(&mut unset, temp.path(), temp.path());
        assert_eq!(unset.resolver.allowed_registries, None);

        // Explicit empty list => Some([]) (deny all), distinct from None.
        let mut empty = ImageConfig {
            resolver: ImageResolverConfig {
                allowed_registries: Some(vec![]),
                ..ImageResolverConfig::default()
            },
            ..ImageConfig::default()
        };
        ImageConfig::normalize(&mut empty, temp.path(), temp.path());
        assert_eq!(empty.resolver.allowed_registries, Some(vec![]));

        // Non-empty list is trimmed, trailing slashes stripped, empties dropped.
        let mut set = ImageConfig {
            resolver: ImageResolverConfig {
                allowed_registries: Some(vec![
                    " registry.example.com/ ".to_string(),
                    "".to_string(),
                    "   ".to_string(),
                    "ghcr.io".to_string(),
                ]),
                ..ImageResolverConfig::default()
            },
            ..ImageConfig::default()
        };
        ImageConfig::normalize(&mut set, temp.path(), temp.path());
        assert_eq!(
            set.resolver.allowed_registries,
            Some(vec![
                "registry.example.com".to_string(),
                "ghcr.io".to_string()
            ])
        );
    }

    #[test]
    fn image_config_normalize_blank_default_image_to_schema_default() {
        let temp = tempfile::tempdir().expect("tempdir");
        let mut config = ImageConfig {
            resolver: ImageResolverConfig {
                default_image: "   ".to_string(),
                ..ImageResolverConfig::default()
            },
            ..ImageConfig::default()
        };
        ImageConfig::normalize(&mut config, temp.path(), temp.path());

        assert_eq!(
            config.resolver.default_image,
            ImageResolverConfig::default().default_image
        );
    }

    #[test]
    fn resolver_uses_normalized_config_fields() {
        let temp = tempfile::tempdir().expect("tempdir");
        let mut config = AppConfig {
            image: ImageConfig {
                resolver: ImageResolverConfig {
                    default_image: " ghcr.io/example/base:latest ".to_string(),
                    ..ImageResolverConfig::default()
                },
                ..ImageConfig::default()
            },
            ..AppConfig::default()
        };
        ImageConfig::normalize(&mut config.image, temp.path(), temp.path());
        let resolver = ImageResolver::new(&config);

        assert_eq!(resolver.default_image(), "ghcr.io/example/base:latest");
    }

    #[test]
    fn should_try_overlaybd_referrers_matches_domain_or_namespace_prefixes() {
        let prefixes = vec![
            "registry.example.com/team/".to_string(),
            "other.example.com/".to_string(),
        ];

        assert!(should_try_overlaybd_referrers(
            "registry.example.com/team/app:tag",
            &prefixes
        ));
        assert!(should_try_overlaybd_referrers(
            "registry.example.com/team/app@sha256:abc",
            &prefixes
        ));
        assert!(should_try_overlaybd_referrers(
            "other.example.com/app:tag",
            &prefixes
        ));
        assert!(!should_try_overlaybd_referrers(
            "registry.example.com/team2/app:tag",
            &prefixes
        ));
    }

    #[test]
    fn parse_overlaybd_referrer_picks_matching_artifact() {
        let body = json!({
            "schemaVersion": 2,
            "mediaType": "application/vnd.oci.image.index.v1+json",
            "manifests": [
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:other",
                    "size": 10,
                    "artifactType": "application/vnd.example.other"
                },
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:overlaybd",
                    "size": 20,
                    "artifactType": "application/vnd.containerd.overlaybd.native.v1+json"
                }
            ]
        });

        assert_eq!(
            parse_overlaybd_referrer(&body.to_string())
                .expect("parse")
                .map(|(digest, _)| digest),
            Some("sha256:overlaybd".to_string())
        );
    }

    #[test]
    fn parse_overlaybd_referrer_keeps_first_matching_artifact() {
        let body = json!({
            "schemaVersion": 2,
            "mediaType": "application/vnd.oci.image.index.v1+json",
            "manifests": [
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:first",
                    "size": 10,
                    "artifactType": "application/vnd.containerd.overlaybd.native.v1+json"
                },
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:second",
                    "size": 20,
                    "artifactType": "application/vnd.containerd.overlaybd.native.v1+json"
                }
            ]
        });

        assert_eq!(
            parse_overlaybd_referrer(&body.to_string())
                .expect("parse")
                .map(|(digest, _)| digest),
            Some("sha256:first".to_string())
        );
    }

    #[test]
    fn parse_overlaybd_referrer_returns_none_without_match() {
        let body = json!({
            "schemaVersion": 2,
            "mediaType": "application/vnd.oci.image.index.v1+json",
            "manifests": []
        });

        assert_eq!(
            parse_overlaybd_referrer(&body.to_string()).expect("parse"),
            None
        );
    }

    #[test]
    fn parse_overlaybd_referrer_accepts_acr_artifact_streaming() {
        // Shape emitted by `az acr artifact-streaming create`, annotations
        // included. Only the artifactType differs from
        // accelerated-container-image: the referrer it points at is an ordinary
        // overlaybd-native manifest whose layers carry a tar mediaType plus a
        // blob-digest annotation equal to the layer's own digest.
        let body = json!({
            "schemaVersion": 2,
            "mediaType": "application/vnd.oci.image.index.v1+json",
            "manifests": [
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:0a21030948e9223e054ab830dd82b0ad85f921df34f11c5bf769bb0ed636d72a",
                    "size": 1234,
                    "artifactType": "application/vnd.azure.artifact.streaming.v1",
                    "annotations": {
                        "streaming.format": "overlaybd",
                        "streaming.version": "v1",
                        "streaming.platform.os": "linux",
                        "streaming.platform.arch": "amd64"
                    }
                }
            ]
        });

        assert_eq!(
            parse_overlaybd_referrer(&body.to_string()).expect("parse"),
            Some((
                "sha256:0a21030948e9223e054ab830dd82b0ad85f921df34f11c5bf769bb0ed636d72a"
                    .to_string(),
                "application/vnd.azure.artifact.streaming.v1"
            ))
        );
    }

    #[test]
    fn parse_overlaybd_referrer_selects_first_of_acr_per_platform_referrers() {
        // Captured from `regctl artifact list --format body` against a real ACR
        // registry, using a multi-arch *tag* as the subject, with the generic
        // `org.opencontainers.image.*` annotations elided for readability.
        //
        // ACR attaches one streaming referrer per platform, all sharing the same
        // artifactType, so an index subject yields several matches. The resolver
        // never passes an index: `resolve_fetched_manifest` hands
        // `FetchedManifest::selected_image_ref` to discovery, which is already
        // pinned to the platform-resolved manifest digest, and such a subject
        // carries exactly one referrer. This multi-match shape is therefore a
        // defensive lock on first-match selection rather than the common path.
        let body = json!({
            "schemaVersion": 2,
            "mediaType": "application/vnd.oci.image.index.v1+json",
            "manifests": [
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:1bdbcce5b02202d0c4c204da05e6ffbb8605bb178f441ff2990b9924c046a69f",
                    "size": 2817,
                    "artifactType": "application/vnd.azure.artifact.streaming.v1",
                    "annotations": {
                        "streaming.format": "overlaybd",
                        "streaming.version": "v1",
                        "streaming.platform.os": "linux",
                        "streaming.platform.arch": "amd64"
                    }
                },
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:3a5ae9547e3ed4d44f435db3ca286f9655e9fcb43ba36b0f5a6cf7da409ce0b8",
                    "size": 2819,
                    "artifactType": "application/vnd.azure.artifact.streaming.v1",
                    "annotations": {
                        "streaming.format": "overlaybd",
                        "streaming.version": "v1",
                        "streaming.platform.os": "linux",
                        "streaming.platform.arch": "arm64"
                    }
                }
            ]
        });

        assert_eq!(
            parse_overlaybd_referrer(&body.to_string()).expect("parse"),
            Some((
                "sha256:1bdbcce5b02202d0c4c204da05e6ffbb8605bb178f441ff2990b9924c046a69f"
                    .to_string(),
                "application/vnd.azure.artifact.streaming.v1"
            ))
        );
    }

    #[test]
    fn parse_overlaybd_referrer_prefers_containerd_native_over_acr_streaming() {
        let body = json!({
            "schemaVersion": 2,
            "mediaType": "application/vnd.oci.image.index.v1+json",
            "manifests": [
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:acr",
                    "size": 10,
                    "artifactType": "application/vnd.azure.artifact.streaming.v1"
                },
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:native",
                    "size": 20,
                    "artifactType": "application/vnd.containerd.overlaybd.native.v1+json"
                }
            ]
        });

        assert_eq!(
            parse_overlaybd_referrer(&body.to_string()).expect("parse"),
            Some((
                "sha256:native".to_string(),
                "application/vnd.containerd.overlaybd.native.v1+json"
            ))
        );
    }

    #[test]
    fn parse_overlaybd_referrer_ignores_unrelated_artifact_types() {
        // Turbo-OCI in particular must never be selected: AgentENV's overlaybd
        // runtime does not implement the turbo read path.
        let body = json!({
            "schemaVersion": 2,
            "mediaType": "application/vnd.oci.image.index.v1+json",
            "manifests": [
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:sbom",
                    "size": 10,
                    "artifactType": "application/spdx+json"
                },
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:turbo",
                    "size": 20,
                    "artifactType": "application/vnd.containerd.overlaybd.turbo.v1+json"
                }
            ]
        });

        assert_eq!(
            parse_overlaybd_referrer(&body.to_string()).expect("parse"),
            None
        );
    }

    #[test]
    fn overlaybd_referrer_artifact_types_match_published_wire_values() {
        // These are registry wire values, not internal identifiers: they must
        // match byte-for-byte what accelerated-container-image and ACR publish.
        // Asserting the literals here means a typo in the constants fails with
        // a readable diff instead of only surfacing as a missed referrer.
        assert_eq!(
            OVERLAYBD_NATIVE_ARTIFACT_TYPE,
            "application/vnd.containerd.overlaybd.native.v1+json"
        );
        assert_eq!(
            ACR_ARTIFACT_STREAMING_ARTIFACT_TYPE,
            "application/vnd.azure.artifact.streaming.v1"
        );
        // Preference order is part of the contract: an image carrying both
        // referrers must resolve to the accelerated-container-image one.
        assert_eq!(
            OVERLAYBD_REFERRER_ARTIFACT_TYPES.to_vec(),
            vec![
                "application/vnd.containerd.overlaybd.native.v1+json",
                "application/vnd.azure.artifact.streaming.v1",
            ]
        );
    }

    /// Install a fake `regctl` that records its argv (one entry per line) into
    /// `<dir>/argv`, replays `stdout`/`stderr`, and exits with `exit_code`.
    ///
    /// This covers the half of discovery that fixture-only tests cannot: the
    /// argv actually handed to `regctl`.
    #[cfg(unix)]
    fn fake_regctl(
        dir: &std::path::Path,
        stdout: &str,
        stderr: &str,
        exit_code: i32,
    ) -> std::path::PathBuf {
        let stdout_path = dir.join("stdout");
        let stderr_path = dir.join("stderr");
        std::fs::write(&stdout_path, stdout).expect("write stdout fixture");
        std::fs::write(&stderr_path, stderr).expect("write stderr fixture");

        // The script locates its fixtures relative to `$0` rather than
        // embedding absolute paths, so a TMPDIR containing shell
        // metacharacters cannot break or inject into the generated script.
        let script = format!(
            "#!/bin/sh\ndir=\"$(cd \"$(dirname \"$0\")\" && pwd)\"\nprintf '%s\\n' \"$@\" > \"$dir/argv\"\ncat \"$dir/stdout\"\ncat \"$dir/stderr\" >&2\nexit {exit_code}\n",
        );

        // Write in a child and wait for it to exit. Writing in this test process
        // lets concurrent forks inherit the writable fd and cause ETXTBSY even
        // after we close it and rename the file; CLOEXEC only closes it at exec.
        let binary = dir.join("regctl");
        let status = std::process::Command::new("/bin/sh")
            .arg("-c")
            .arg("printf '%s' \"$2\" > \"$1\" && chmod 755 \"$1\"")
            .arg("install-fake-regctl")
            .arg(&binary)
            .arg(script)
            .status()
            .expect("install fake regctl");
        assert!(status.success(), "install fake regctl: {status}");
        binary
    }

    #[cfg(unix)]
    fn recorded_argv(dir: &std::path::Path) -> Vec<String> {
        std::fs::read_to_string(dir.join("argv"))
            .expect("fake regctl did not run")
            .lines()
            .map(ToString::to_string)
            .collect()
    }

    #[tokio::test]
    #[cfg(unix)]
    async fn discover_overlaybd_referrer_lists_referrers_unfiltered_and_finds_acr_streaming() {
        let temp = TempDir::new().expect("tempdir");
        let subject = "demo.azurecr.io/python:3.11-slim";
        // Literal referrers index as returned by ACR for an image processed by
        // `az acr artifact-streaming create`.
        let body = json!({
            "schemaVersion": 2,
            "mediaType": "application/vnd.oci.image.index.v1+json",
            "manifests": [
                {
                    "mediaType": "application/vnd.oci.image.manifest.v1+json",
                    "digest": "sha256:0a21030948e9223e054ab830dd82b0ad85f921df34f11c5bf769bb0ed636d72a",
                    "size": 1234,
                    "artifactType": "application/vnd.azure.artifact.streaming.v1",
                    "annotations": {
                        "streaming.format": "overlaybd",
                        "streaming.version": "v1",
                        "streaming.platform.os": "linux",
                        "streaming.platform.arch": "amd64"
                    }
                }
            ]
        });
        let regctl = fake_regctl(temp.path(), &body.to_string(), "", 0);

        let discovered = discover_overlaybd_referrer(&regctl, subject, None)
            .await
            .expect("discover referrer");

        assert_eq!(
            discovered,
            Some((
                "sha256:0a21030948e9223e054ab830dd82b0ad85f921df34f11c5bf769bb0ed636d72a"
                    .to_string(),
                "application/vnd.azure.artifact.streaming.v1"
            ))
        );

        let argv = recorded_argv(temp.path());
        // The listing must stay unfiltered. `regctl artifact list` accepts only
        // one `--filter-artifact-type`, so reintroducing it would pin discovery
        // to a single artifactType and silently drop ACR referrers while every
        // parse-level test stayed green.
        assert!(
            !argv.iter().any(|arg| arg == "--filter-artifact-type"),
            "referrers must be listed unfiltered and matched locally, got argv: {argv:?}"
        );
        assert_eq!(
            argv,
            vec!["artifact", "list", "--format", "body", subject],
            "unexpected regctl invocation"
        );
    }

    #[tokio::test]
    #[cfg(unix)]
    async fn discover_overlaybd_referrer_surfaces_regctl_failure() {
        let temp = TempDir::new().expect("tempdir");
        let regctl = fake_regctl(
            temp.path(),
            "",
            "unauthorized: authentication required\n",
            1,
        );

        let error = discover_overlaybd_referrer(&regctl, "demo.azurecr.io/python:3.11-slim", None)
            .await
            .expect_err("regctl failure must not be reported as 'no referrer'");

        // A registry error has to fail loudly: swallowing it into `Ok(None)`
        // would silently downgrade to a local pull-and-convert.
        let rendered = format!("{error:#}");
        assert!(
            rendered.contains("regctl artifact list failed"),
            "unexpected error: {rendered}"
        );
        assert!(
            rendered.contains("unauthorized: authentication required"),
            "regctl stderr must be preserved: {rendered}"
        );
    }

    #[tokio::test]
    async fn resolve_rejects_empty_configured_search_list_for_shortnames() {
        let temp = TempDir::new().expect("tempdir");
        let resolver = test_resolver_with_search(&temp, vec![]);

        let err = resolver
            .resolve("ubuntu")
            .await
            .expect_err("empty search list should fail");

        assert!(matches!(err, ImageError::InvalidReference { .. }));
        assert!(err.is_user_error());
        assert!(err.to_string().contains("search registry list"));
    }

    #[test]
    fn image_resolve_error_classifies_user_vs_server_errors() {
        // InvalidReference is covered by the resolve() test above; here we check
        // the NotFound (user) vs Other (server) classification.
        assert!(ImageError::NotFound {
            reason: "missing".to_string(),
        }
        .is_user_error());
        assert!(
            !ImageError::Other(anyhow!("network down")).is_user_error(),
            "Other should be a server error"
        );
    }

    #[test]
    fn overlaybd_image_config_json_preserves_local_layer_descriptor() {
        let temp = TempDir::new().expect("tempdir");
        let layer_path = temp.path().join("layer.commit");
        let resolved = ResolvedImage::Local(vec![crate::image::local_layer::LocalLayer {
            path: layer_path.clone(),
            digest: "sha256:commit".to_string(),
            size: 123,
        }]);

        let config = overlaybd_image_config_json(&resolved);
        let expected_file = layer_path.display().to_string();
        assert_eq!(
            config["lowers"][0]["file"].as_str(),
            Some(expected_file.as_str())
        );
        assert_eq!(
            config["lowers"][0]["digest"].as_str(),
            Some("sha256:commit")
        );
        assert_eq!(config["lowers"][0]["size"].as_u64(), Some(123));
    }

    #[test]
    fn overlaybd_image_config_json_emits_remote_layer_dir() {
        let temp = TempDir::new().expect("tempdir");
        let layer_dir = temp.path().join("commits/sha256-abc");
        let resolved = ResolvedImage::Remote {
            repo_blob_url: "https://registry.example/v2/repo/blobs".to_string(),
            layers: vec![crate::image::oci_image::RemoteLayer {
                digest: "sha256:abc".to_string(),
                size: 123,
                dir: layer_dir.clone(),
            }],
        };

        let config = overlaybd_image_config_json(&resolved);
        let expected_layer_dir = layer_dir.display().to_string();
        assert_eq!(
            config["lowers"][0]["dir"].as_str(),
            Some(expected_layer_dir.as_str())
        );
        assert!(config["lowers"][0].get("cacheFile").is_none());
    }

    fn local_resolver(temp: &TempDir) -> (ImageResolver, Arc<ImageCacheService>) {
        let mut config = AppConfig::default();
        ImageConfig::normalize(&mut config.image, temp.path(), temp.path());
        let cache = ImageCacheService::shared_from_app_config(&config);
        (ImageResolver::new(&config), cache)
    }

    #[tokio::test]
    async fn published_image_survives_source_removal_and_resolves_on_another_node() -> Result<()> {
        use crate::image::test_support::{store_layers, write_built_image};
        use crate::repository::backends::PosixFsRepository;
        let shared = TempDir::new()?;
        let source = TempDir::new()?;
        let node_a = TempDir::new()?;
        let node_b = TempDir::new()?;
        let repository: Arc<dyn crate::repository::Repository> =
            Arc::new(PosixFsRepository::new(shared.path().join("repository")));
        let (publisher, _) = local_resolver(&node_a);
        let publisher = publisher.with_repository(repository.clone());
        let raw = json!({"Env": ["A=B"], "Entrypoint": ["/app"], "Cmd": ["serve"], "Healthcheck": {"Test": ["CMD", "true"]}});
        let built = ResolvedBlockImage {
            image_ref: crate::digest::sha256_digest(b"original OCI manifest"),
            overlaybd_config_path: write_built_image(source.path())?,
            base_context: ImageBaseContext::default(),
            raw_config: Some(raw.clone()),
        };
        let digest = publisher.publish_image(&built, store_layers).await?;
        assert_ne!(digest, built.image_ref);
        assert_eq!(publisher.publish_image(&built, store_layers).await?, digest);
        let mut changed = built.clone();
        changed.raw_config = Some(json!({"Cmd": ["different"]}));
        assert_ne!(
            publisher.publish_image(&changed, store_layers).await?,
            digest
        );
        drop(source);
        drop(node_a);
        let (reader, _) = local_resolver(&node_b);
        let reader = reader.with_repository(repository);
        let resolved = reader.resolve(&digest).await?;
        assert_eq!(resolved.image_ref, digest);
        assert_eq!(resolved.raw_config, Some(raw));
        assert_eq!(
            resolved.base_context.env_vars.get("A").map(String::as_str),
            Some("B")
        );
        let config: Value =
            serde_json::from_slice(&tokio::fs::read(&resolved.overlaybd_config_path).await?)?;
        assert!(config["lowers"]
            .as_array()
            .unwrap()
            .iter()
            .all(|layer| { std::path::Path::new(layer["file"].as_str().unwrap()).is_file() }));
        tokio::fs::remove_file(&resolved.overlaybd_config_path).await?;
        assert!(reader
            .resolve(&digest)
            .await?
            .overlaybd_config_path
            .is_file());
        let unknown = crate::digest::sha256_digest(b"unknown");
        assert!(matches!(
            reader.resolve(&unknown).await,
            Err(ImageError::NotFound { .. })
        ));
        assert!(matches!(
            reader.resolve("sha256:invalid").await,
            Err(ImageError::InvalidReference { .. })
        ));
        let key = crate::repository::DocumentKey::image(&digest)?.path();
        let path = shared.path().join("repository").join(key);
        let mut description: Value = serde_json::from_slice(&std::fs::read(&path)?)?;
        description["config"]["Cmd"] = json!(["tampered"]);
        std::fs::write(path, serde_json::to_vec(&description)?)?;
        assert!(
            format!("{:#}", reader.resolve(&digest).await.unwrap_err()).contains("digest mismatch")
        );
        Ok(())
    }

    #[tokio::test]
    async fn image_tags_resolve_to_the_digest_they_point_to_now() -> Result<()> {
        use crate::image::test_support::{store_layers, write_built_image};
        use crate::image::ImageCatalog;
        use crate::repository::backends::PosixFsRepository;
        let shared = TempDir::new()?;
        let node = TempDir::new()?;
        let repository: Arc<dyn crate::repository::Repository> =
            Arc::new(PosixFsRepository::new(shared.path().join("repository")));
        let (resolver, _) = local_resolver(&node);
        let mut resolver = resolver.with_repository(repository.clone());
        let mut built = ResolvedBlockImage {
            image_ref: crate::digest::sha256_digest(b"source manifest"),
            overlaybd_config_path: write_built_image(&shared.path().join("build"))?,
            base_context: ImageBaseContext::default(),
            raw_config: Some(json!({"Cmd": ["v1"]})),
        };
        let first = resolver.publish_image(&built, store_layers).await?;
        built.raw_config = Some(json!({"Cmd": ["v2"]}));
        let second = resolver.publish_image(&built, store_layers).await?;

        let tag = ImageTag::parse("web:v1")?;
        repository.put_image_tag(&tag, &first).await?;
        let resolved = resolver.resolve(" aenv/web:v1 ").await?;
        assert_eq!(resolved.image_ref, first);
        assert_eq!(resolved.raw_config, Some(json!({"Cmd": ["v1"]})));

        // The node cache is keyed by digest, so a moved tag is never served stale.
        repository.put_image_tag(&tag, &second).await?;
        let resolved = resolver.resolve("aenv/web:v1").await?;
        assert_eq!(resolved.image_ref, second);
        assert_eq!(resolved.raw_config, Some(json!({"Cmd": ["v2"]})));

        assert!(matches!(
            resolver.resolve("aenv/web").await,
            Err(ImageError::NotFound { .. })
        ));
        let gone = ImageTag::parse("web:gone")?;
        repository
            .put_image_tag(&gone, &crate::digest::sha256_digest(b"deleted"))
            .await?;
        let error = resolver.resolve("aenv/web:gone").await.unwrap_err();
        assert!(matches!(error, ImageError::NotFound { .. }));
        assert!(error.to_string().contains("image tag 'web:gone'"));
        for invalid in [
            "aenv/Web:v1",
            "aenv/",
            "aenv/web:v1:extra",
            "aenv/team/web:v1",
        ] {
            assert!(matches!(
                resolver.resolve(invalid).await,
                Err(ImageError::InvalidReference { .. })
            ));
        }
        // With a registry host, an `aenv` namespace still names an OCI image;
        // denying every registry proves the reference took the OCI path.
        resolver.allowed_registries = Some(Vec::new());
        assert!(matches!(
            resolver.resolve("docker.io/aenv/web:v1").await,
            Err(ImageError::InvalidReference { reason }) if reason.contains("allowed registr")
        ));
        assert!(repository
            .put_image_tag(&tag, "sha256:short")
            .await
            .is_err());

        let path = shared
            .path()
            .join("repository")
            .join(crate::repository::DocumentKey::ImageTag(tag).path());
        std::fs::write(path, b"\"not-a-digest\"")?;
        assert!(matches!(
            resolver.resolve("aenv/web:v1").await,
            Err(ImageError::Other(_))
        ));
        Ok(())
    }
}
