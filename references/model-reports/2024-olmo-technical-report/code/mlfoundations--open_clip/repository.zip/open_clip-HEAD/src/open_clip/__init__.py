from .version import __version__

from .coca_model import CoCa
from .mammut_model import MaMMUT
from .naflex_genlip_model import NaFlexGenLip
from .naflex_genlap_model import NaFlexGenLap
from .constants import OPENAI_DATASET_MEAN, OPENAI_DATASET_STD
from .factory import (
    create_model,
    create_model_and_transforms,
    create_model_from_pretrained,
    get_tokenizer,
    create_loss,
    create_task,
)
from .factory import list_models, add_model_config, get_model_config, load_checkpoint
from .model_traits import ModelFamily, InputMode, ModelTraits, get_model_traits, traits_from_config
from .loss import ClipLoss, DistillClipLoss, CoCaLoss, GenLipLoss
from .task import (
    TrainingTask,
    ImageTextTask,
    CLIPTask,
    SigLIPTask,
    CoCaTask,
    GenLipTask,
    GenLapTask,
    DistillCLIPTask,
    get_model_from_task,
)
from .clap_model import CLAP
from .model import (
    CLIP,
    CustomTextCLIP,
    CLIPTextCfg,
    CLIPVisionCfg,
    ModernTextTransformer,
    convert_weights_to_lp,
    convert_weights_to_fp16,
    get_cast_dtype,
    get_input_dtype,
    get_model_tokenize_cfg,
    get_model_preprocess_cfg,
    set_model_preprocess_cfg,
)
from .pretrained import (
    list_pretrained,
    list_pretrained_models_by_tag,
    list_pretrained_tags_by_model,
    get_pretrained_url,
    download_pretrained_from_url,
    is_pretrained_cfg,
    get_pretrained_cfg,
    download_pretrained,
)
from .push_to_hf_hub import push_pretrained_to_hf_hub, push_to_hf_hub
from .tokenizer import Tokenizer, SimpleTokenizer, tokenize, decode, batch_decode
from .transform import image_transform, AugmentationCfg
from .zero_shot_classifier import build_zero_shot_classifier, build_zero_shot_classifier_legacy
from .zero_shot_metadata import OPENAI_IMAGENET_TEMPLATES, SIMPLE_IMAGENET_TEMPLATES, IMAGENET_CLASSNAMES

from .audio import AUDIO_AVAILABLE, AudioAugmentationCfg, AudioTower, CLIPAudioCfg, audio_transform_v2, require_audio
