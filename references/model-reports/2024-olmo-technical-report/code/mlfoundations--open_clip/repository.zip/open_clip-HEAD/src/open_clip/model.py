""" CLIP Model

Adapted from https://github.com/openai/CLIP. Originally MIT License, Copyright (c) 2021 OpenAI.
"""
import copy
import logging
import math

_logger = logging.getLogger(__name__)
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn
from functools import partial

from .model_traits import CLIP_TRAITS
from .hf_model import HFTextEncoder
from .modified_resnet import ModifiedResNet
from .timm_model import TimmModel
from .transformer import (
    LayerNormFp32,
    LayerNorm,
    QuickGELU,
    Attention,
    VisionTransformer,
    TextTransformer,
    ModernTextTransformer,
    MultimodalTransformer,
    MultimodalDecoder,
    text_global_pool,
    lock_text_tower,
)
from .utils import to_2tuple


@dataclass
class CLIPVisionCfg:
    layers: Union[Tuple[int, int, int, int], int] = 12
    width: int = 768
    head_width: int = 64
    mlp_ratio: float = 4.0
    patch_size: int = 16
    image_size: Union[Tuple[int, int], int] = 224
    image_seq_len: Optional[int] = None

    ls_init_value: Optional[float] = None  # layer scale initial value
    patch_dropout: float = 0.  # what fraction of patches to dropout during training (0 would mean disabled and no patches dropped) - 0.5 to 0.75 recommended in the paper for optimal results
    attentional_pool: bool = False  # whether to use attentional pooler in the last embedding layer (overrides pool_type)
    attn_pooler_queries: int = 256  # n_queries for attentional pooler
    attn_pooler_heads: int = 8  # n heads for attentional_pooling
    no_ln_pre: bool = False  # disable pre transformer LayerNorm
    pos_embed_type: str = 'learnable'
    final_ln_after_pool: bool = False  # apply final LayerNorm after pooling
    pool_type: str = 'tok'
    output_tokens: bool = False
    act_kwargs: Optional[dict] = None
    norm_kwargs: Optional[dict] = None

    # Custom attention block settings
    block_type: Optional[str] = None  # attention block type ('default', 'custom'), auto-selects 'custom' if any below features enabled
    qk_norm: bool = False  # apply layer norm to q and k in attention
    scaled_cosine_attn: bool = False  # use scaled cosine attention
    scale_heads: bool = False  # learnable head-specific scale applied to attention logits
    scale_attn_inner: bool = False  # apply layer norm on attention context, before output projection
    scale_attn: bool = False  # apply layer norm after full attention block
    scale_fc: bool = False  # apply layer norm in MLP block

    timm_model_name: Optional[str] = None  # a valid model name overrides layers, width, patch_size
    timm_model_pretrained: bool = False  # use (imagenet) pretrained weights for named model
    timm_pool: str = 'avg'  # feature pooling for timm model ('abs_attn', 'rot_attn', 'avg', '')
    timm_proj: str = 'linear'  # linear projection for timm model output ('linear', 'mlp', '')
    timm_proj_bias: bool = False  # enable bias final projection
    timm_drop: float = 0.  # head dropout
    timm_drop_path: Optional[float] = None  # backbone stochastic depth
    timm_model_kwargs: Optional[dict] = None  # additional kwargs forwarded to timm.create_model()
    # NaFlexVit towers only: enable timm's parameter-free patch-embed weight interpolator so the tower accepts
    # patches at sizes other than its base patch size (variable-patch NaFlex training / eval). Off by default and
    # state-dict compatible; declare it in the config of a model trained with variable patch sizes so plain
    # loading works, or override at creation with `force_naflex_patch_interp`.
    naflex_patch_interp: bool = False


@dataclass
class CLIPTextCfg:
    text_arch: str = "clip"  # "clip" (native/HF) or "modern" (dedicated text tower only)
    context_length: int = 77
    variable_text: bool = False
    vocab_size: int = 49408
    hf_tokenizer_name: Optional[str] = None
    tokenizer_mode: Optional[str] = None
    tokenizer_kwargs: Optional[dict] = None
    tokenizer_type: str = ''
    # Tokenizer-side packaging metadata for exported tiktoken models. Not used by model itself.
    tiktoken_name: str = 'cl100k_base'
    tiktoken_bpe_path: Optional[str] = None
    tiktoken_config_path: Optional[str] = None

    width: int = 512
    heads: int = 8
    layers: int = 12
    mlp_ratio: float = 4.0
    ls_init_value: Optional[float] = None  # layer scale initial value
    embed_cls: bool = False
    # correct cls/pad additive-mask construction for CoCa (legacy False = historical off-by-one where the
    # mask is built as if the cls token were at the front while it is appended at the end)
    correct_cls_mask: bool = False
    use_pad_mask: bool = False  # mask pad keys in bi-directional (no_causal_mask) mode
    # id that fills padding positions (tower masking, caption-loss ignore_index, generation default).
    # 0 is the historical CLIP/SimpleTokenizer fill convention (no reserved pad token; 0 is a real vocab
    # token). Tokenizers with a reserved pad (roberta=1, tiktoken=100278, ...) require this to match;
    # generative configs must set it explicitly then (validated in get_tokenizer).
    pad_id: int = 0
    bos_id: Optional[int] = None
    # Only used for pool_type == 'eos' (and the modern text arch 'argmax' remap). No default on purpose: it must
    # match the tokenizer's eos/eot id (e.g. 1 for mt5, 2 for xlm-v, 50257 for the GenLIP tiktoken vocab), so
    # configs that pool on eos are required to set it explicitly and it is validated against the tokenizer.
    eos_id: Optional[int] = None
    no_causal_mask: bool = False  # disable causal masking
    final_ln_after_pool: bool = False  # apply final LayerNorm after pooling
    pool_type: str = 'argmax'
    proj_bias: bool = False
    proj_type: str = 'linear'  # control final text projection, 'none' forces no projection
    output_tokens: bool = False
    act_kwargs: dict = None
    norm_kwargs: dict = None

    # Custom attention block settings
    block_type: Optional[str] = None  # attention block type ('default', 'custom'), auto-selects 'custom' if any custom features enabled
    qk_norm: bool = False  # apply layer norm to q and k in attention
    scaled_cosine_attn: bool = False  # use scaled cosine attention
    scale_heads: bool = False  # learnable head-specific scale applied to attention logits
    scale_attn_inner: bool = False  # apply layer norm on attention context, before output projection
    scale_attn: bool = False  # apply layer norm after full attention block
    scale_fc: bool = False  # apply layer norm in MLP block

    # ModernTextTransformer settings (text_arch == "modern")
    attention_mode: str = "causal"  # "causal" or "bidirectional"
    # Zero-init + gradient-freeze the pad row of the token embedding (nn.Embedding padding_idx). Tri-state:
    # None = arch default (True, matching existing modern text runs). Set False when the pad id collides
    # with a real vocab token (SimpleTokenizer fills with 0 == '!'), where freezing would corrupt it.
    freeze_pad_embed: Optional[bool] = None
    pos_embed: str = "rope"
    rope_temperature: float = 10000.0
    mlp_type: str = "swiglu"  # "swiglu", "mlp" (GELU), or "relu2" (squared-ReLU)
    # Norm flavor, tri-state (drop-in LayerNorm<->RMSNorm): None = arch default (modern -> rmsnorm, legacy -> layernorm).
    norm_type: Optional[str] = None
    norm_eps: float = 1e-6
    attn_gated: bool = False
    pre_norm: bool = False  # normalize embeddings (after register concat) before block 0 (timm ViT norm_pre)
    # "pre" or "sandwich" (extra norm on sublayer outputs, Gemma-2 style). Sandwich also switches block init
    # to flat N(0, 0.02) (OLMo2-style): the post-norms renormalize sublayer outputs, undoing depth scaling.
    norm_placement: str = "pre"
    zero_init_residual: bool = False  # zero the residual out-projs (attn proj, mlp out): blocks start as identity
    reg_tokens: int = 0  # learned register tokens prepended to the sequence and excluded from pooling
    value_residual: bool = False  # mix each layer's V with layer-0 V via a learned per-layer scalar (ResFormer)
    # Linear biases, tri-state: None = arch default (modern -> off per LLaMA/PaLM, legacy -> on for pretrained).
    # attention_bias: qkv, attn out-proj, gate, MAP-pool q/kv. mlp_bias: the MLP. (text_projection bias is `proj_bias`.)
    attention_bias: Optional[bool] = None
    mlp_bias: Optional[bool] = None
    # Gate-bias override (gated attention only): None inherits attention_bias; True/False force it on/off. Lets the
    # mostly-open gate init (sigmoid(1)~=0.73) survive attention_bias=False -- the one bias worth keeping there.
    gate_bias: Optional[bool] = None

    # HuggingFace specific text tower config
    hf_model_name: Optional[str] = None
    hf_model_pretrained: bool = True
    hf_proj_type: str = 'mlp'
    hf_pooler_type: str = 'mean_pooler'  # attentional pooling for HF models
    hf_model_config: Optional[dict] = None  # HF config overrides, e.g. {"hidden_dropout_prob": 0.0}


def get_cast_dtype(precision: str):
    cast_dtype = None
    if precision == 'bf16':
        cast_dtype = torch.bfloat16
    elif precision == 'fp16':
        cast_dtype = torch.float16
    return cast_dtype


def get_input_dtype(precision: str):
    input_dtype = None
    if precision in ('bf16', 'pure_bf16'):
        input_dtype = torch.bfloat16
    elif precision in ('fp16', 'pure_fp16'):
        input_dtype = torch.float16
    return input_dtype


def _build_vision_tower(
        embed_dim: int,
        vision_cfg: CLIPVisionCfg,
        quick_gelu: bool = False,
        cast_dtype: Optional[torch.dtype] = None
):
    if isinstance(vision_cfg, dict):
        vision_cfg = CLIPVisionCfg(**vision_cfg)

    # OpenAI models are pretrained w/ QuickGELU but native nn.GELU is both faster and more
    # memory efficient in recent PyTorch releases (>= 1.10).
    # NOTE: timm models always use native GELU regardless of quick_gelu flag.
    act_layer = QuickGELU if quick_gelu else nn.GELU

    if vision_cfg.timm_model_name:
        timm_model_kwargs = dict(vision_cfg.timm_model_kwargs or {})
        if vision_cfg.naflex_patch_interp:
            is_naflex_tower = (
                vision_cfg.timm_model_name.startswith('naflexvit') or timm_model_kwargs.get('use_naflex', False))
            if not is_naflex_tower:
                raise ValueError(
                    "naflex_patch_interp requires a timm NaFlexVit vision tower "
                    f"(got timm_model_name={vision_cfg.timm_model_name!r}); use force_naflex_vision to convert a "
                    "compatible timm EVA/ViT tower."
                )
            timm_model_kwargs['enable_patch_interpolator'] = True
        visual = TimmModel(
            vision_cfg.timm_model_name,
            pretrained=vision_cfg.timm_model_pretrained,
            pool=vision_cfg.timm_pool,
            proj=vision_cfg.timm_proj,
            proj_bias=vision_cfg.timm_proj_bias,
            drop=vision_cfg.timm_drop,
            drop_path=vision_cfg.timm_drop_path,
            patch_drop=vision_cfg.patch_dropout if vision_cfg.patch_dropout > 0 else None,
            embed_dim=embed_dim,
            image_size=vision_cfg.image_size,
            model_kwargs=timm_model_kwargs or None,
            output_tokens=vision_cfg.output_tokens,
        )
    elif vision_cfg.naflex_patch_interp:
        raise ValueError(
            "naflex_patch_interp requires a timm NaFlexVit vision tower; use force_naflex_vision to convert a "
            "compatible native ViT tower."
        )
    elif isinstance(vision_cfg.layers, (tuple, list)):
        vision_heads = vision_cfg.width * 32 // vision_cfg.head_width
        visual = ModifiedResNet(
            layers=vision_cfg.layers,
            output_dim=embed_dim,
            heads=vision_heads,
            image_size=vision_cfg.image_size,
            width=vision_cfg.width,
        )
    else:
        vision_heads = vision_cfg.width // vision_cfg.head_width
        norm_layer = LayerNormFp32 if cast_dtype in (torch.float16, torch.bfloat16) else LayerNorm
        if vision_cfg.norm_kwargs:
            norm_layer = partial(norm_layer, **vision_cfg.norm_kwargs)
        if vision_cfg.act_kwargs is not None:
            act_layer = partial(act_layer, **vision_cfg.act_kwargs)

        visual = VisionTransformer(
            image_size=vision_cfg.image_size,
            patch_size=vision_cfg.patch_size,
            width=vision_cfg.width,
            layers=vision_cfg.layers,
            heads=vision_heads,
            mlp_ratio=vision_cfg.mlp_ratio,
            ls_init_value=vision_cfg.ls_init_value,
            patch_dropout=vision_cfg.patch_dropout,
            attentional_pool=vision_cfg.attentional_pool,
            attn_pooler_queries=vision_cfg.attn_pooler_queries,
            attn_pooler_heads=vision_cfg.attn_pooler_heads,
            pos_embed_type=vision_cfg.pos_embed_type,
            no_ln_pre=vision_cfg.no_ln_pre,
            final_ln_after_pool=vision_cfg.final_ln_after_pool,
            pool_type=vision_cfg.pool_type,
            output_tokens=vision_cfg.output_tokens,
            output_dim=embed_dim,
            act_layer=act_layer,
            norm_layer=norm_layer,
            block_type=vision_cfg.block_type,
            qk_norm=vision_cfg.qk_norm,
            scaled_cosine_attn=vision_cfg.scaled_cosine_attn,
            scale_heads=vision_cfg.scale_heads,
            scale_attn_inner=vision_cfg.scale_attn_inner,
            scale_attn=vision_cfg.scale_attn,
            scale_fc=vision_cfg.scale_fc,
        )

    if vision_cfg.image_seq_len is not None:
        visual.image_seq_len = int(vision_cfg.image_seq_len)

    return visual


def _pooled_image_features(output: Any) -> torch.Tensor:
    """Select the pooled feature from vision towers that optionally expose token sidecars."""
    if isinstance(output, dict):
        try:
            return output['pooled']
        except KeyError as ex:
            raise KeyError("vision tower dictionary output must contain a 'pooled' tensor.") from ex
    if isinstance(output, (tuple, list)):
        if not output:
            raise ValueError("vision tower returned an empty output sequence.")
        return output[0]
    return output


def _build_text_tower(
        embed_dim: int,
        text_cfg: CLIPTextCfg,
        quick_gelu: bool = False,
        cast_dtype: Optional[torch.dtype] = None,
):
    if isinstance(text_cfg, dict):
        text_cfg = CLIPTextCfg(**text_cfg)

    # eos pooling is keyed on a token id; there is deliberately no eos_id default (a wrong id pools silently
    # wrong positions), so require it here. The modern arch remaps 'argmax' to 'eos' and re-checks internally.
    if text_cfg.pool_type == 'eos' and text_cfg.eos_id is None:
        raise ValueError("pool_type='eos' requires text_cfg.eos_id (must match the tokenizer eos/eot token id).")

    if text_cfg.text_arch == "modern":
        if text_cfg.hf_model_name:
            raise ValueError("text_arch='modern' cannot be combined with hf_model_name.")
        text = ModernTextTransformer(text_cfg, output_dim=embed_dim)
    elif text_cfg.hf_model_name:
        text = HFTextEncoder(
            text_cfg.hf_model_name,
            output_dim=embed_dim,
            proj_type=text_cfg.hf_proj_type,
            pooler_type=text_cfg.hf_pooler_type,
            pretrained=text_cfg.hf_model_pretrained,
            output_tokens=text_cfg.output_tokens,
            model_config=text_cfg.hf_model_config,
        )
    else:
        act_layer = QuickGELU if quick_gelu else nn.GELU
        norm_layer = LayerNormFp32 if cast_dtype in (torch.float16, torch.bfloat16) else LayerNorm
        if text_cfg.norm_kwargs:
            norm_layer = partial(norm_layer, **text_cfg.norm_kwargs)
        if text_cfg.act_kwargs is not None:
            act_layer = partial(act_layer, **text_cfg.act_kwargs)

        text = TextTransformer(
            context_length=text_cfg.context_length,
            vocab_size=text_cfg.vocab_size,
            width=text_cfg.width,
            heads=text_cfg.heads,
            layers=text_cfg.layers,
            mlp_ratio=text_cfg.mlp_ratio,
            ls_init_value=text_cfg.ls_init_value,
            output_dim=embed_dim,
            embed_cls=text_cfg.embed_cls,
            correct_cls_mask=text_cfg.correct_cls_mask,
            no_causal_mask=text_cfg.no_causal_mask,
            use_pad_mask=text_cfg.use_pad_mask,
            pad_id=text_cfg.pad_id,
            bos_id=text_cfg.bos_id,
            eos_id=text_cfg.eos_id,
            pool_type=text_cfg.pool_type,
            proj_type=text_cfg.proj_type,
            proj_bias=text_cfg.proj_bias,
            output_tokens=text_cfg.output_tokens,
            act_layer=act_layer,
            norm_layer=norm_layer,
            block_type=text_cfg.block_type,
            qk_norm=text_cfg.qk_norm,
            scaled_cosine_attn=text_cfg.scaled_cosine_attn,
            scale_heads=text_cfg.scale_heads,
            scale_attn_inner=text_cfg.scale_attn_inner,
            scale_attn=text_cfg.scale_attn,
            scale_fc=text_cfg.scale_fc,
        )
    text.variable_text = bool(text_cfg.variable_text)
    return text


def _compute_logits(image_features, text_features, logit_scale, logit_bias=None):
    image_logits = logit_scale * image_features @ text_features.T
    if logit_bias is not None:
        image_logits += logit_bias
    return image_logits, image_logits.T


def _pack_clip_output(image_features, text_features, logit_scale, logit_bias, output_dict):
    if output_dict:
        output = dict(image_features=image_features, text_features=text_features, logit_scale=logit_scale)
        if logit_bias is not None:
            output['logit_bias'] = logit_bias.clone()
        return output
    if logit_bias is not None:
        return image_features, text_features, logit_scale, logit_bias.clone()
    return image_features, text_features, logit_scale


def _forward_tower_intermediates(tower, inputs, feature_key, normalize, **kwargs):
    output = tower.forward_intermediates(inputs, **kwargs)
    if normalize and feature_key in output:
        output[feature_key] = F.normalize(output[feature_key], dim=-1)
    return output


def _add_intermediate_logits(output, logit_scale, logit_bias, output_logits, output_logit_scale_bias):
    if output_logits or output_logit_scale_bias:
        logit_scale = logit_scale.exp()
    if output_logits:
        output['image_logits'], output['text_logits'] = _compute_logits(
            output['image_features'], output['text_features'], logit_scale, logit_bias)
    if output_logit_scale_bias:
        output['logit_scale'] = logit_scale
        if logit_bias is not None:
            output['logit_bias'] = logit_bias.clone()
    return output


class CLIP(nn.Module):
    traits = CLIP_TRAITS  # family-level defaults; the factory attaches the resolved instance

    def __init__(
            self,
            embed_dim: int,
            vision_cfg: CLIPVisionCfg,
            text_cfg: CLIPTextCfg,
            quick_gelu: bool = False,
            init_logit_scale: float = np.log(1 / 0.07),
            init_logit_bias: Optional[float] = None,
            nonscalar_logit_scale: bool = False,
            cast_dtype: Optional[torch.dtype] = None,
            output_dict: bool = False,
    ):
        super().__init__()
        text_arch = (
            text_cfg.get("text_arch", "clip") if isinstance(text_cfg, dict) else getattr(text_cfg, "text_arch", "clip")
        )
        variable_text = (
            text_cfg.get("variable_text", False)
            if isinstance(text_cfg, dict)
            else getattr(text_cfg, "variable_text", False)
        )
        if text_arch == "modern":
            raise ValueError("text_arch='modern' requires CustomTextCLIP or CLAP; pass custom_text=True.")
        if variable_text:
            raise ValueError("variable_text=True requires CustomTextCLIP or CLAP; pass custom_text=True.")
        self.output_dict = output_dict
        self.embed_dim = embed_dim

        self.visual = _build_vision_tower(embed_dim, vision_cfg, quick_gelu, cast_dtype)

        text = _build_text_tower(embed_dim, text_cfg, quick_gelu, cast_dtype)
        self.transformer = text.transformer
        self.context_length = text.context_length
        self.vocab_size = text.vocab_size
        self.token_embedding = text.token_embedding
        self.positional_embedding = text.positional_embedding
        self.ln_final = text.ln_final
        self.text_projection = text.text_projection
        self.text_pool_type = text.pool_type
        self.text_eos_id = text.eos_id
        self.register_buffer('attn_mask', text.attn_mask, persistent=False)

        lshape = [1] if nonscalar_logit_scale else []
        self.logit_scale = nn.Parameter(torch.ones(lshape) * init_logit_scale)
        if init_logit_bias is not None:
            self.logit_bias = nn.Parameter(torch.ones(lshape) * init_logit_bias)
        else:
            self.logit_bias = None

    def lock_image_tower(self, unlocked_groups=0, freeze_bn_stats=False):
        # lock image tower as per LiT - https://arxiv.org/abs/2111.07991
        self.visual.lock(unlocked_groups=unlocked_groups, freeze_bn_stats=freeze_bn_stats)

    def lock_text_tower(self, unlocked_layers: int = 0, freeze_layer_norm: bool = True, pooler_in_head: bool = True):
        assert freeze_layer_norm, 'Unfreezing LayerNorm is not supported. LayerNorm treated like other weights.'
        lock_text_tower(self, unlocked_layers, pooler_in_head)

    def set_grad_checkpointing(self, enable: bool = True, impl: str = 'inline'):
        self.visual.set_grad_checkpointing(enable, impl=impl)
        self.transformer.set_grad_checkpointing(enable, impl=impl)

    def no_weight_decay(self):
        # for timm optimizers, 1d params like logit_scale, logit_bias, ln/bn scale, biases are excluded by default
        no_wd = {'positional_embedding'}
        if hasattr(self.visual, 'no_weight_decay'):
            for n in self.visual.no_weight_decay():
                no_wd.add('visual.' + n)
        return no_wd

    def _encode_image(self, image, normalize: bool = False):
        features = _pooled_image_features(self.visual(image))
        return F.normalize(features, dim=-1) if normalize else features

    def encode_image(self, image, normalize: bool = False):
        return self._encode_image(image, normalize=normalize)

    def _encode_text(self, text, normalize: bool = False):
        cast_dtype = self.transformer.get_cast_dtype()

        x = self.token_embedding(text).to(cast_dtype)  # [batch_size, n_ctx, d_model]

        x = x + self.positional_embedding.to(cast_dtype)
        x = self.transformer(x, attn_mask=self.attn_mask)
        x = self.ln_final(x)  # [batch_size, n_ctx, transformer.width]
        x = text_global_pool(x, text, self.text_pool_type, eos_token_id=getattr(self, "text_eos_id", None))
        if self.text_projection is not None:
            if isinstance(self.text_projection, nn.Linear):
                x = self.text_projection(x)
            else:
                x = x @ self.text_projection

        return F.normalize(x, dim=-1) if normalize else x

    def encode_text(self, text, normalize: bool = False):
        return self._encode_text(text, normalize=normalize)

    def get_logits(self, image, text):
        image_features = self._encode_image(image, normalize=True)
        text_features = self._encode_text(text, normalize=True)
        return _compute_logits(image_features, text_features, self.logit_scale.exp(), self.logit_bias)

    def forward_intermediates(
            self,
            image: Optional[torch.Tensor] = None,
            text: Optional[torch.Tensor] = None,
            image_indices: Optional[Union[int, List[int]]] = None,
            text_indices: Optional[Union[int, List[int]]] = None,
            stop_early: bool = False,
            normalize: bool = True,
            normalize_intermediates: bool = False,
            intermediates_only: bool = False,
            image_output_fmt: str = 'NCHW',
            image_output_extra_tokens: bool = False,
            text_output_fmt: str = 'NLC',
            text_output_extra_tokens: bool = False,
            output_logits: bool = False,
            output_logit_scale_bias: bool = False,
    ) -> Dict[str, Union[torch.Tensor, List[torch.Tensor]]]:
        """ Forward features that returns intermediates.

        Args:
            image: Input image tensor
            text: Input text tensor
            image_indices: For image tower, Take last n blocks if int, all if None, select matching indices if sequence
            text_indices: Take last n blocks if int, all if None, select matching indices if sequence
            stop_early: Stop iterating over blocks when last desired intermediate hit
            normalize_intermediates: Apply final norm layer to all intermediates
            normalize: L2 Normalize final features
            intermediates_only: Only return intermediate features, do not return final features
            image_output_fmt: Shape of intermediate image feature outputs
            image_output_extra_tokens: Return both prefix and spatial intermediate tokens
            text_output_fmt: Shape of intermediate text feature outputs (ignored for this model)
            text_output_extra_tokens: Return both prefix and spatial intermediate tokens (ignored for this model)
            output_logits: Include logits in output
            output_logit_scale_bias: Include the logit scale bias in the output
        Returns:

        """
        output = {}
        if intermediates_only:
            # intermediates only disables final feature normalization, and include logits
            normalize = False
            output_logits = False
        if output_logits:
            assert image is not None and text is not None, 'Both image and text inputs are required to compute logits'

        if image is not None:
            output.update(_forward_tower_intermediates(
                self.visual, image, 'image_features', normalize,
                indices=image_indices,
                stop_early=stop_early,
                normalize_intermediates=normalize_intermediates,
                intermediates_only=intermediates_only,
                output_fmt=image_output_fmt,
                output_extra_tokens=image_output_extra_tokens,
            ))

        if text is not None:
            cast_dtype = self.transformer.get_cast_dtype()
            x = self.token_embedding(text).to(cast_dtype)  # [batch_size, n_ctx, d_model]
            x = x + self.positional_embedding.to(cast_dtype)
            x, intermediates = self.transformer.forward_intermediates(
                x,
                attn_mask=self.attn_mask,
                indices=text_indices
            )
            if normalize_intermediates:
                intermediates = [self.ln_final(xi) for xi in intermediates]

            # NOTE this model doesn't support cls embed in text transformer, no need for extra intermediate tokens
            output["text_intermediates"] = intermediates

            if not intermediates_only:
                x = self.ln_final(x)  # [batch_size, n_ctx, transformer.width]
                x = text_global_pool(x, text, self.text_pool_type, eos_token_id=getattr(self, "text_eos_id", None))
                if self.text_projection is not None:
                    if isinstance(self.text_projection, nn.Linear):
                        x = self.text_projection(x)
                    else:
                        x = x @ self.text_projection
                if normalize:
                    x = F.normalize(x, dim=-1)
                output["text_features"] = x

        return _add_intermediate_logits(
            output, self.logit_scale, self.logit_bias, output_logits, output_logit_scale_bias)

    def forward(
            self,
            image: Optional[torch.Tensor] = None,
            text: Optional[torch.Tensor] = None,
    ):
        image_features = self._encode_image(image, normalize=True) if image is not None else None
        text_features = self._encode_text(text, normalize=True) if text is not None else None
        return _pack_clip_output(
            image_features, text_features, self.logit_scale.exp(), self.logit_bias, self.output_dict)


class CustomTextCLIP(nn.Module):
    traits = CLIP_TRAITS

    def __init__(
            self,
            embed_dim: int,
            vision_cfg: CLIPVisionCfg,
            text_cfg: CLIPTextCfg,
            quick_gelu: bool = False,
            init_logit_scale: float = np.log(1 / 0.07),
            init_logit_bias: Optional[float] = None,
            nonscalar_logit_scale: bool = False,
            cast_dtype: Optional[torch.dtype] = None,
            output_dict: bool = False,
    ):
        super().__init__()
        self.output_dict = output_dict
        self.embed_dim = embed_dim
        self.visual = _build_vision_tower(embed_dim, vision_cfg, quick_gelu, cast_dtype)
        self.text = _build_text_tower(embed_dim, text_cfg, quick_gelu, cast_dtype)
        self.context_length = self.text.context_length
        self.vocab_size = self.text.vocab_size

        lshape = [1] if nonscalar_logit_scale else []
        self.logit_scale = nn.Parameter(torch.ones(lshape) * init_logit_scale)
        if init_logit_bias is not None:
            self.logit_bias = nn.Parameter(torch.ones(lshape) * init_logit_bias)
        else:
            self.logit_bias = None

    def lock_image_tower(self, unlocked_groups=0, freeze_bn_stats=False):
        # lock image tower as per LiT - https://arxiv.org/abs/2111.07991
        self.visual.lock(unlocked_groups=unlocked_groups, freeze_bn_stats=freeze_bn_stats)

    def lock_text_tower(self, unlocked_layers: int = 0, freeze_layer_norm: bool = True, pooler_in_head: bool = True):
        self.text.lock(unlocked_layers, freeze_layer_norm, pooler_in_head)

    def set_grad_checkpointing(self, enable: bool = True, impl: str = 'inline'):
        self.visual.set_grad_checkpointing(enable, impl=impl)
        self.text.set_grad_checkpointing(enable, impl=impl)

    def no_weight_decay(self):
        # for timm optimizers, 1d params like logit_scale, logit_bias, ln/bn scale, biases are excluded by default
        no_wd = set()
        if hasattr(self.visual, 'no_weight_decay'):
            for n in self.visual.no_weight_decay():
                no_wd.add('visual.' + n)
        if hasattr(self.text, 'no_weight_decay'):
            for n in self.text.no_weight_decay():
                no_wd.add('text.' + n)
        return no_wd

    def _encode_image(self, image, normalize: bool = False):
        features = _pooled_image_features(self.visual(image))
        return F.normalize(features, dim=-1) if normalize else features

    def encode_image(self, image, normalize: bool = False):
        return self._encode_image(image, normalize=normalize)

    def _encode_text(self, text, normalize: bool = False):
        features = self.text(text)
        return F.normalize(features, dim=-1) if normalize else features

    def encode_text(self, text, normalize: bool = False):
        return self._encode_text(text, normalize=normalize)

    def get_logits(self, image, text):
        image_features = self._encode_image(image, normalize=True)
        text_features = self._encode_text(text, normalize=True)
        return _compute_logits(image_features, text_features, self.logit_scale.exp(), self.logit_bias)

    def forward_intermediates(
            self,
            image: Optional[torch.Tensor] = None,
            text: Optional[torch.Tensor] = None,
            image_indices: Optional[Union[int, List[int]]] = None,
            text_indices: Optional[Union[int, List[int]]] = None,
            stop_early: bool = False,
            normalize: bool = True,
            normalize_intermediates: bool = False,
            intermediates_only: bool = False,
            image_output_fmt: str = 'NCHW',
            image_output_extra_tokens: bool = False,
            text_output_fmt: str = 'NLC',
            text_output_extra_tokens: bool = False,
            output_logits: bool = False,
            output_logit_scale_bias: bool = False,
    ) -> Dict[str, Union[torch.Tensor, List[torch.Tensor]]]:
        """ Forward features that returns intermediates.

        Args:
            image: Input image tensor
            text: Input text tensor
            image_indices: For image tower, Take last n blocks if int, all if None, select matching indices if sequence
            text_indices: Take last n blocks if int, all if None, select matching indices if sequence
            stop_early: Stop iterating over blocks when last desired intermediate hit
            normalize: L2 Normalize final image and text features (if present)
            normalize_intermediates: Apply final encoder norm layer to all intermediates (if possible)
            intermediates_only: Only return intermediate features, do not return final features
            image_output_fmt: Shape of intermediate image feature outputs
            image_output_extra_tokens: Return both prefix and spatial intermediate tokens
            text_output_fmt: Shape of intermediate text feature outputs
            text_output_extra_tokens: Return both prefix and spatial intermediate tokens
            output_logits: Include logits in output
            output_logit_scale_bias: Include the logit scale bias in the output
        Returns:

        """
        output = {}
        if intermediates_only:
            # intermediates only disables final feature normalization, and include logits
            normalize = False
            output_logits = False
        if output_logits:
            assert image is not None and text is not None, 'Both image and text inputs are required to compute logits'

        if image is not None:
            output.update(_forward_tower_intermediates(
                self.visual, image, 'image_features', normalize,
                indices=image_indices,
                stop_early=stop_early,
                normalize_intermediates=normalize_intermediates,
                intermediates_only=intermediates_only,
                output_fmt=image_output_fmt,
                output_extra_tokens=image_output_extra_tokens,
            ))

        if text is not None:
            output.update(_forward_tower_intermediates(
                self.text, text, 'text_features', normalize,
                indices=text_indices,
                stop_early=stop_early,
                normalize_intermediates=normalize_intermediates,
                intermediates_only=intermediates_only,
                output_fmt=text_output_fmt,
                output_extra_tokens=text_output_extra_tokens,
            ))

        return _add_intermediate_logits(
            output, self.logit_scale, self.logit_bias, output_logits, output_logit_scale_bias)

    def forward(
            self,
            image: Optional[torch.Tensor] = None,
            text: Optional[torch.Tensor] = None,
    ):
        image_features = self._encode_image(image, normalize=True) if image is not None else None
        text_features = self._encode_text(text, normalize=True) if text is not None else None
        return _pack_clip_output(
            image_features, text_features, self.logit_scale.exp(), self.logit_bias, self.output_dict)


def convert_weights_to_lp(model: nn.Module, dtype=torch.float16):
    """Convert applicable model parameters to low-precision (bf16 or fp16)"""

    def _convert_weights(l):
        if isinstance(l, (nn.Conv1d, nn.Conv2d, nn.Linear)):
            l.weight.data = l.weight.data.to(dtype)
            if l.bias is not None:
                l.bias.data = l.bias.data.to(dtype)

        if isinstance(l, Attention):
            for attr in [*[f"{s}_proj_weight" for s in ["in", "q", "k", "v"]], "in_proj_bias", "bias_k", "bias_v"]:
                tensor = getattr(l, attr, None)
                if tensor is not None:
                    tensor.data = tensor.data.to(dtype)

        if isinstance(l, (CLIP, TextTransformer, MultimodalTransformer, MultimodalDecoder)):
            # convert text nn.Parameter projections / heads (nn.Linear variants are handled above)
            for attr_name in ("text_projection", "lm_head"):
                attr = getattr(l, attr_name, None)
                if attr is not None and isinstance(attr, nn.Parameter):
                    attr.data = attr.data.to(dtype)

        if isinstance(l, VisionTransformer):
            # convert vision nn.Parameter projections
            attr = getattr(l, "proj", None)
            if attr is not None:
                attr.data = attr.data.to(dtype)

        # MaMMUT model-level image->text kv projection (raw nn.Parameter)
        attr = getattr(l, "map_viz2txt_kv", None)
        if attr is not None:
            attr.data = attr.data.to(dtype)

    model.apply(_convert_weights)


convert_weights_to_fp16 = convert_weights_to_lp  # backwards compat


# used to maintain checkpoint compatibility
def convert_to_custom_text_state_dict(state_dict: dict):
    if 'text_projection' in state_dict:
        # old format state_dict, move text tower -> .text
        new_state_dict = {}
        for k, v in state_dict.items():
            if any(k.startswith(p) for p in (
                'text_projection',
                'positional_embedding',
                'token_embedding',
                'transformer',
                'ln_final',
            )):
                k = 'text.' + k
            new_state_dict[k] = v
        return new_state_dict
    return state_dict


def resize_pos_embed(state_dict, model, interpolation: str = 'bicubic', antialias: bool = True):
    # Rescale the grid of position embeddings when loading from state_dict
    old_pos_embed = state_dict.get('visual.positional_embedding', None)
    if old_pos_embed is None or not hasattr(model.visual, 'grid_size'):
        return
    grid_size = to_2tuple(model.visual.grid_size)
    extra_tokens = 1  # FIXME detect different token configs (ie no class token, or more)
    new_seq_len = grid_size[0] * grid_size[1] + extra_tokens
    if new_seq_len == old_pos_embed.shape[0]:
        return

    if extra_tokens:
        pos_emb_tok, pos_emb_img = old_pos_embed[:extra_tokens], old_pos_embed[extra_tokens:]
    else:
        pos_emb_tok, pos_emb_img = None, old_pos_embed
    old_grid_size = to_2tuple(int(math.sqrt(len(pos_emb_img))))

    _logger.info('Resizing position embedding grid-size from %s to %s', old_grid_size, grid_size)
    pos_emb_img = pos_emb_img.reshape(1, old_grid_size[0], old_grid_size[1], -1).permute(0, 3, 1, 2)
    pos_emb_img = F.interpolate(
        pos_emb_img,
        size=grid_size,
        mode=interpolation,
        antialias=antialias,
        align_corners=False,
    )
    pos_emb_img = pos_emb_img.permute(0, 2, 3, 1).reshape(1, grid_size[0] * grid_size[1], -1)[0]
    if pos_emb_tok is not None:
        new_pos_embed = torch.cat([pos_emb_tok, pos_emb_img], dim=0)
    else:
        new_pos_embed = pos_emb_img
    state_dict['visual.positional_embedding'] = new_pos_embed


def resize_text_pos_embed(state_dict, model, interpolation: str = 'linear', antialias: bool = False):
    pos_embed_key = 'positional_embedding' if 'positional_embedding' in state_dict else 'text.positional_embedding'
    old_pos_embed = state_dict.get(pos_embed_key, None)
    if old_pos_embed is None:
        return
    # FIXME add support for text cls_token
    model_pos_embed = getattr(model, 'positional_embedding', None)
    if model_pos_embed is None:
        model_pos_embed = getattr(model.text, 'positional_embedding', None)

    old_num_pos = old_pos_embed.shape[0]
    old_width = old_pos_embed.shape[1]
    num_pos = model_pos_embed.shape[0]
    width = model_pos_embed.shape[1]
    assert old_width == width, 'text pos_embed width changed!'
    if old_num_pos == num_pos:
        return

    _logger.info('Resizing text position embedding num_pos from %s to %s', old_num_pos, num_pos)
    old_pos_embed = old_pos_embed.reshape(1, old_num_pos, old_width).permute(0, 2, 1)
    old_pos_embed = F.interpolate(
        old_pos_embed,
        size=num_pos,
        mode=interpolation,
        antialias=antialias,
        align_corners=False,
    )
    old_pos_embed = old_pos_embed.permute(0, 2, 1)[0]
    new_pos_embed = old_pos_embed

    state_dict[pos_embed_key] = new_pos_embed


def get_model_preprocess_cfg(model):
    module = getattr(model, 'visual', model)
    preprocess_cfg = getattr(module, 'preprocess_cfg', {})
    if not preprocess_cfg:
        # use separate legacy attributes if preprocess_cfg dict not found
        size = getattr(module, 'image_size')
        if size is not None:
            preprocess_cfg['size'] = size
        mean = getattr(module, 'image_mean', None)
        if mean is not None:
            preprocess_cfg['mean'] = mean
        std = getattr(module, 'image_std', None)
        if std is not None:
            preprocess_cfg['std'] = std
    return preprocess_cfg


def set_model_preprocess_cfg(model, preprocess_cfg: Dict[str, Any]):
    module = getattr(model, 'visual', model)
    module.image_mean = preprocess_cfg['mean']  # legacy attribute, keeping for bwd compat
    module.image_std = preprocess_cfg['std']  # legacy attribute, keeping for bwd compat
    module.preprocess_cfg = copy.deepcopy(preprocess_cfg)  # new attr, package all pp cfg as dict


def get_model_tokenize_cfg(model):
    module = getattr(model, 'text', model)
    cfg = {}
    context_length = getattr(module, 'context_length', None)
    if context_length is not None:
        cfg['context_length'] = context_length
    vocab_size = getattr(module, 'vocab_size', None)
    if vocab_size is not None:
        cfg['vocab_size'] = vocab_size
    return cfg
