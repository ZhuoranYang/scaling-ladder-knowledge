import logging
import math
import time

import torch
import torch.nn.functional as F

try:
    import wandb
except ImportError:
    wandb = None

from open_clip import get_input_dtype
from open_clip.utils import cat_padded_sequences
from open_clip.task import unwrap_model
from open_clip_train.distributed import is_master
from open_clip_train import eval_utils
from open_clip_train.metrics import DEFAULT_RETRIEVAL_CHUNK_SIZE
from open_clip_train.metrics import get_clip_metrics
from open_clip_train.zero_shot import zero_shot_eval
from open_clip_train.precision import get_autocast
from open_clip_train.utils import (
    AverageMeter, backward, pop_accum_scalars, postprocess_clip_output as postprocess_clip_output,
)


def _coca_apply_ar_shift(model_out, texts):
    """Apply autoregressive shift for CoCa caption loss.

    The CoCa model used to do this internally, but the shift logic moved into
    ``CoCaTask`` for the task-based pipeline. This shim restores the old
    contract for the legacy train/eval path: when ``logits`` is present and
    ``labels`` is not, shift logits by [:, :-1] and add labels = text[:, 1:].
    Non-CoCa outputs are returned unchanged.
    """
    if "logits" in model_out and "labels" not in model_out:
        model_out["logits"] = model_out["logits"][:, :-1]
        model_out["labels"] = texts[:, 1:]
    return model_out


def train_one_epoch(model, data, loss, epoch, optimizer, scaler, scheduler, dist_model, args, tb_writer=None):
    device = torch.device(args.device)
    autocast = get_autocast(args.precision, device_type=device.type)
    input_dtype = get_input_dtype(args.precision)

    model.train()
    if args.distill:
        dist_model.eval()

    data['train'].set_epoch(epoch)  # set epoch in process safe manner via sampler or shared_epoch
    dataloader = data['train'].dataloader
    num_batches_per_epoch = dataloader.num_batches // args.accum_freq
    sample_digits = math.ceil(math.log(dataloader.num_samples + 1, 10))

    if args.accum_freq > 1:
        accum_images, accum_texts, accum_features = [], [], {}

    losses_m = {}
    batch_time_m = AverageMeter()
    data_time_m = AverageMeter()
    end = time.time()
    for i, batch in enumerate(dataloader):
        i_accum = i // args.accum_freq
        step = num_batches_per_epoch * epoch + i_accum

        if not args.skip_scheduler:
            scheduler(step)

        images, texts = batch["image"], batch["text"]
        images = images.to(device=device, dtype=input_dtype, non_blocking=True)
        texts = texts.to(device=device, non_blocking=True)

        data_time_m.update(time.time() - end)
        optimizer.zero_grad()

        if args.accum_freq == 1:
            with autocast():
                model_out = model(images, texts)
                model_out = _coca_apply_ar_shift(model_out, texts)
                logit_scale = model_out["logit_scale"]
                if args.distill:
                    with torch.no_grad():
                        dist_model_out = dist_model(images, texts)
                    model_out.update({f'dist_{k}': v for k, v in dist_model_out.items()})
                losses = loss(**model_out, output_dict=True)

                total_loss = sum(losses.values())
                losses["loss"] = total_loss

            backward(total_loss, scaler)
        else:
            # First, cache the features without any gradient tracking.
            with torch.no_grad():
                with autocast():
                    model_out = model(images, texts)
                    model_out = _coca_apply_ar_shift(model_out, texts)

                    for f in ("logit_scale", "logit_bias"):
                        model_out.pop(f, None)

                    for key, val in model_out.items():
                        if key in accum_features:
                            accum_features[key].append(val)
                        else:
                            accum_features[key] = [val]

                accum_images.append(images)
                accum_texts.append(texts)

            # If (i + 1) % accum_freq is not zero, move on to the next batch.
            if ((i + 1) % args.accum_freq) > 0:
                # FIXME this makes data time logging unreliable when accumulating
                continue

            # Now, ready to take gradients for the last accum_freq batches.
            # Re-do the forward pass for those batches, and use the cached features from the other batches as negatives.
            # Call backwards each time, but only step optimizer at the end.
            optimizer.zero_grad()
            for j in range(args.accum_freq):
                images = accum_images[j]
                texts = accum_texts[j]
                is_last_step = j == args.accum_freq - 1
                with autocast():
                    model_out = model(images, texts)
                    model_out = _coca_apply_ar_shift(model_out, texts)

                    inputs_no_accum = pop_accum_scalars(model_out, is_last_step)
                    logit_scale = inputs_no_accum["logit_scale"]

                    inputs = {}
                    for key, val in accum_features.items():
                        accumulated = accum_features[key]
                        values = accumulated[:j] + [model_out[key]] + accumulated[j + 1:]
                        if key in ("logits", "labels"):
                            # Caption outputs are already AR-shifted. Added label padding must be ignored
                            # by CoCaLoss, including for models with a nonzero tokenizer pad id.
                            inputs[key] = cat_padded_sequences(values, padding_value=-100 if key == "labels" else 0)
                        else:
                            inputs[key] = torch.cat(values)

                    losses = loss(**inputs, **inputs_no_accum, output_dict=True)
                    del inputs
                    del inputs_no_accum
                    total_loss = sum(losses.values())
                    losses["loss"] = total_loss

                backward(total_loss, scaler)

        if scaler is not None:
            if args.grad_clip_norm is not None:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip_norm, norm_type=2.0)
            scaler.step(optimizer)
            scaler.update()
        else:
            if args.grad_clip_norm is not None:
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip_norm, norm_type=2.0)
            optimizer.step()

        # reset gradient accum, if enabled
        if args.accum_freq > 1:
            accum_images, accum_texts, accum_features = [], [], {}

        # Note: we clamp to 4.6052 = ln(100), as in the original paper.
        with torch.no_grad():
            unwrap_model(model).logit_scale.clamp_(0, math.log(100))

        batch_time_m.update(time.time() - end)
        end = time.time()
        batch_count = i_accum + 1
        if is_master(args) and (i_accum % args.log_every_n_steps == 0 or batch_count == num_batches_per_epoch):
            batch_size = len(images)
            num_samples = batch_count * batch_size * args.accum_freq * args.world_size
            samples_per_epoch = dataloader.num_samples
            percent_complete = 100.0 * batch_count / num_batches_per_epoch

            # NOTE loss is coarsely sampled, just master node and per log update
            for key, val in losses.items():
                if key not in losses_m:
                    losses_m[key] = AverageMeter()
                losses_m[key].update(val.item(), batch_size)

            logit_scale_scalar = logit_scale.item()
            loss_log = " ".join(
                [
                    f"{loss_name.capitalize()}: {loss_m.val:#.5g} ({loss_m.avg:#.5g})"
                    for loss_name, loss_m in losses_m.items()
                ]
            )
            samples_per_second = args.accum_freq * args.batch_size * args.world_size / batch_time_m.val
            samples_per_second_per_gpu = args.accum_freq * args.batch_size / batch_time_m.val
            logging.info(
                f"Train Epoch: {epoch} [{num_samples:>{sample_digits}}/{samples_per_epoch} ({percent_complete:.0f}%)] "
                f"Data (t): {data_time_m.avg:.3f} "
                f"Batch (t): {batch_time_m.avg:.3f}, {samples_per_second:#g}/s, {samples_per_second_per_gpu:#g}/s/gpu "
                f"LR: {optimizer.param_groups[0]['lr']:5f} "
                f"Logit Scale: {logit_scale_scalar:.3f} " + loss_log
            )

            # Save train loss / etc. Using non avg meter values as loggers have their own smoothing
            log_data = {
                "data_time": data_time_m.val,
                "batch_time": batch_time_m.val,
                "samples_per_second": samples_per_second,
                "samples_per_second_per_gpu": samples_per_second_per_gpu,
                "logit_scale": logit_scale_scalar,
                "lr": optimizer.param_groups[0]["lr"]
            }
            log_data.update({name:val.val for name,val in losses_m.items()})

            log_data = {"train/" + name: val for name, val in log_data.items()}

            if tb_writer is not None:
                for name, val in log_data.items():
                    tb_writer.add_scalar(name, val, step)

            if args.wandb:
                assert wandb is not None, 'Please install wandb.'
                log_data['step'] = step  # for backwards compatibility
                wandb.log(log_data, step=step)

            # resetting batch / data time meters per log window
            batch_time_m.reset()
            data_time_m.reset()
    # end for


def evaluate(model, data, epoch, args, tb_writer=None, tokenizer=None):
    metrics = {}
    if not is_master(args):
        return metrics
    device = torch.device(args.device)
    model.eval()
    # unwrap DDP once here so zero_shot_eval and the imagenet-val / imagenet-v2
    # paths below all run on the bare module on rank 0 (#1155).
    if args.distributed and hasattr(model, 'module'):
        model = model.module

    zero_shot_metrics = zero_shot_eval(model, data, epoch, args, tokenizer=tokenizer)
    metrics.update(zero_shot_metrics)

    autocast = get_autocast(args.precision, device_type=device.type)
    input_dtype = get_input_dtype(args.precision)

    if 'val' in data and (args.val_frequency and ((epoch % args.val_frequency) == 0 or epoch == args.epochs)):
        dataloader = data['val'].dataloader
        num_samples = 0
        samples_per_val = dataloader.num_samples

        # Retrieval metrics are computed in score chunks below, but feature
        # accumulation and exact pair scoring remain O(N * D) memory and O(N^2)
        # compute respectively.
        cumulative_loss = 0.0
        cumulative_gen_loss = 0.0
        all_image_features, all_text_features = [], []
        with torch.inference_mode():
            for i, batch in enumerate(dataloader):
                images, texts = batch["image"], batch["text"]
                images = images.to(device=device, dtype=input_dtype, non_blocking=True)
                texts = texts.to(device=device, non_blocking=True)

                with autocast():
                    model_out = model(images, texts)
                    image_features = model_out["image_features"]
                    text_features = model_out["text_features"]
                    logit_scale = model_out["logit_scale"]
                    # Features are accumulated as CPU tensors to keep GPU memory
                    # bounded; this remains O(N * D) system RAM.
                    all_image_features.append(image_features.cpu())
                    all_text_features.append(text_features.cpu())
                    logit_scale = logit_scale.mean()
                    logits_per_image = logit_scale * image_features @ text_features.t()
                    logits_per_text = logits_per_image.t()

                    batch_size = images.shape[0]
                    labels = torch.arange(batch_size, device=device).long()
                    total_loss = (
                        F.cross_entropy(logits_per_image, labels) +
                        F.cross_entropy(logits_per_text, labels)
                    ) / 2

                    gen_loss = maybe_compute_generative_loss(
                        model_out, texts=texts, pad_id=getattr(unwrap_model(model), 'pad_id', 0))

                cumulative_loss += total_loss * batch_size
                num_samples += batch_size
                if gen_loss is not None:
                    cumulative_gen_loss += gen_loss * batch_size
                if is_master(args) and (i % 100) == 0:
                    logging.info(
                        f"Eval Epoch: {epoch} [{num_samples} / {samples_per_val}]\t"
                        f"Clip Loss: {cumulative_loss / num_samples:.6f}\t")

                    if gen_loss is not None:
                        logging.info(
                            f"Generative Loss: {cumulative_gen_loss / num_samples:.6f}\t")

            retrieval_chunk_size = getattr(
                args,
                "val_retrieval_chunk_size",
                DEFAULT_RETRIEVAL_CHUNK_SIZE,
            )
            retrieval_precision = getattr(args, "val_retrieval_precision", "fp32")
            retrieval_device = device if retrieval_chunk_size and retrieval_chunk_size > 0 else None
            val_metrics = get_clip_metrics(
                image_features=all_image_features,
                text_features=all_text_features,
                logit_scale=logit_scale.cpu(),
                retrieval_chunk_size=retrieval_chunk_size,
                retrieval_device=retrieval_device,
                retrieval_dtype="model" if retrieval_precision == "model" else torch.float32,
            )
            loss = cumulative_loss / num_samples
            metrics.update(
                {**val_metrics, "clip_val_loss": loss.item(), "epoch": epoch, "num_samples": num_samples}
            )
            if gen_loss is not None:
                gen_loss = cumulative_gen_loss / num_samples
                metrics.update({"val_generative_loss": gen_loss.item()})

    if not metrics:
        return metrics

    if args.wandb:
        assert wandb is not None, "Please install wandb."
    eval_utils.log_eval_metrics(metrics, data, epoch, args, logging, tb_writer, wandb if args.wandb else None)

    return metrics

def maybe_compute_generative_loss(model_out, texts=None, pad_id=0):
    # Preserve the legacy third positional argument (the current trainer also accepts text_valid).
    return eval_utils.maybe_compute_generative_loss(model_out, texts=texts, pad_id=pad_id)
