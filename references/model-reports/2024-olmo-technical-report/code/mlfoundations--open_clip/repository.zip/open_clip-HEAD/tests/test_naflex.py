import io
import tarfile
import types

import pytest
import torch
from PIL import Image
from torchvision import transforms

import open_clip
from open_clip.model_traits import CLIP_TRAITS
from open_clip.naflex_config import NaFlexDataConfig
from open_clip.transform import NaFlexEvalTransformFactory, PreprocessCfg, image_transform
from open_clip_train.data import get_imagenet, get_wds_dataset
from open_clip_train.naflex_data import (
    NAFLEX_AVAILABLE,
    NaFlexBatcher,
    SampleDecodeError,
    collate_naflex_dicts,
    collate_naflex_tuples,
    create_naflex_data_config_from_args,
    create_naflex_eval_transform,
)
from open_clip_train.params import parse_args
from open_clip_train.train import make_loss_scale_fn


pytestmark = pytest.mark.skipif(not NAFLEX_AVAILABLE, reason="timm NaFlex data support is not available")


def _transform_factory(max_seq_len, patch_size):
    return transforms.ToTensor()


_transform_factory.is_naflex_transform_factory = True


def _samples(num_samples=4):
    return [
        {
            "image": Image.new("RGB", (32, 32), color=(idx, idx, idx)),
            "text": torch.tensor([idx], dtype=torch.long),
        }
        for idx in range(num_samples)
    ]


class _MaskTokenizer:
    """Fixed-length tokenizer whose validity cannot be inferred from token values."""

    def __call__(self, text, output_mask=False):
        value = int(text.strip())
        tokens = torch.tensor([[value, 0, 2, 0]], dtype=torch.long)
        valid = torch.tensor([[True, True, True, False]])
        return (tokens, valid) if output_mask else tokens


def _write_tar(path, num_samples=4):
    with tarfile.open(path, "w") as tar:
        for idx in range(num_samples):
            image = Image.new("RGB", (32, 32), color=(idx, idx, idx))
            image_file = io.BytesIO()
            image.save(image_file, format="PNG")
            image_file.seek(0)
            image_info = tarfile.TarInfo(f"{idx}.png")
            image_info.size = len(image_file.getbuffer())
            tar.addfile(image_info, image_file)

            text_file = io.BytesIO(str(idx).encode("utf-8"))
            text_info = tarfile.TarInfo(f"{idx}.txt")
            text_info.size = len(text_file.getbuffer())
            tar.addfile(text_info, text_file)


def test_naflex_batcher_returns_dict_batches():
    batcher = NaFlexBatcher(
        train_num_samples=4,
        patch_size=16,
        seq_lens=(4,),
        max_tokens_per_batch=8,
        transform_factory=_transform_factory,
        batch_divisor=1,
        shuffle=False,
    )

    batches = list(batcher.run(_samples()))

    assert len(batches) == 2
    batch = batches[0]
    assert set(batch.keys()) == {"image", "text"}
    assert set(batch["image"].keys()) == {"patches", "patch_coord", "patch_valid", "seq_len"}
    assert batch["image"]["patches"].shape == (2, 4, 16 * 16 * 3)
    assert batch["image"]["patch_coord"].shape == (2, 4, 2)
    assert batch["image"]["patch_valid"].all()
    assert batch["text"].shape == (2, 1)


def test_naflex_batcher_preserves_fixed_text_valid():
    samples = _samples(2)
    expected = []
    for idx, sample in enumerate(samples):
        sample["text"] = torch.tensor([idx, 0, 2, 0], dtype=torch.long)
        sample["text_valid"] = torch.tensor([True, True, True, False])
        expected.append(sample["text_valid"])

    batcher = NaFlexBatcher(
        train_num_samples=2,
        patch_size=16,
        seq_lens=(4,),
        max_tokens_per_batch=8,
        transform_factory=_transform_factory,
        batch_divisor=1,
        shuffle=False,
    )
    batch = next(batcher.run(samples))

    torch.testing.assert_close(batch["text_valid"], torch.stack(expected))


def test_collate_naflex_dicts_preserves_fixed_text_valid():
    batch = [
        {
            "image": {
                "patches": torch.randn(4, 16 * 16 * 3),
                "patch_coord": torch.zeros(4, 2, dtype=torch.long),
                "patch_valid": torch.ones(4, dtype=torch.bool),
            },
            "text": torch.tensor([idx, 0, 2, 0], dtype=torch.long),
            "text_valid": torch.tensor([True, True, True, False]),
        }
        for idx in range(2)
    ]

    output = collate_naflex_dicts(batch, max_seq_len=4)

    assert output["text_valid"].shape == (2, 4)
    assert output["text_valid"].tolist() == [[True, True, True, False]] * 2


# --- decode-in-loop (deferred decode + skip-and-replenish) ----------------------------------------------------
_POISON = object()


def _decode_to_pil(raw):
    """Fake per-modality decode: a raw int token -> PIL; the poison sentinel raises like a corrupt byte stream."""
    if raw is _POISON:
        raise ValueError("corrupt bytes")
    v = raw % 256
    return Image.new("RGB", (32, 32), color=(v, v, v))


def test_naflex_batcher_decode_fn_in_loop_matches_predecoded():
    """Decoding raw samples via `decode_fn` inside the batcher loop yields the same batches as feeding
    already-decoded PILs with `decode_fn=None` (the refactor is behavior-preserving)."""
    common = dict(
        train_num_samples=4, patch_size=16, seq_lens=(4,), max_tokens_per_batch=8,
        transform_factory=_transform_factory, batch_divisor=1, shuffle=False,
    )
    raw = [{"image": i, "text": torch.tensor([i], dtype=torch.long)} for i in range(4)]
    decoded = [{"image": _decode_to_pil(i), "text": torch.tensor([i], dtype=torch.long)} for i in range(4)]

    b_in_loop = list(NaFlexBatcher(**common, decode_fn=_decode_to_pil).run(iter(raw)))
    b_predecoded = list(NaFlexBatcher(**common).run(iter(decoded)))

    assert len(b_in_loop) == len(b_predecoded) == 2
    for a, b in zip(b_in_loop, b_predecoded):
        assert torch.equal(a["image"]["patches"], b["image"]["patches"])
        assert torch.equal(a["text"], b["text"])


def test_naflex_batcher_skips_and_replenishes_decode_failures():
    """A SampleDecodeError is skipped and replenished so every batch stays exactly `batch_size`, and the
    decode_error_handler is invoked once per skipped sample."""
    skipped = []
    batcher = NaFlexBatcher(
        train_num_samples=4, patch_size=16, seq_lens=(4,), max_tokens_per_batch=8,
        transform_factory=_transform_factory, batch_divisor=1, shuffle=False,
        decode_fn=_decode_to_pil, decode_error_handler=lambda ex: skipped.append(ex) or True,  # truthy -> skip
    )

    def src():  # infinite source; every 3rd sample is poison
        i = 0
        while True:
            i += 1
            yield {"image": (_POISON if i % 3 == 0 else i), "text": torch.tensor([i % 7], dtype=torch.long)}

    batches = list(batcher.run(src()))
    assert len(batches) == 2
    for batch in batches:
        assert batch["image"]["patches"].shape[0] == 2  # exactly batch_size despite the skipped poison
    assert len(skipped) >= 1 and all(isinstance(ex, SampleDecodeError) for ex in skipped)


def test_naflex_batcher_raises_after_consecutive_decode_failures(monkeypatch):
    """A fully-failing decode trips the consecutive-failure guard (no infinite spin against the infinite source)."""
    from open_clip_train import naflex_data as nd
    monkeypatch.setattr(nd, "_MAX_CONSECUTIVE_DECODE_FAILURES", 3)

    def always_fail(raw):
        raise ValueError("decode always fails")

    batcher = nd.NaFlexBatcher(
        train_num_samples=4, patch_size=16, seq_lens=(4,), max_tokens_per_batch=8,
        transform_factory=_transform_factory, batch_divisor=1, shuffle=False,
        decode_fn=always_fail, decode_error_handler=lambda ex: True,  # keep skipping -> accumulate to the guard
    )

    def src():
        i = 0
        while True:
            i += 1
            yield {"image": i, "text": torch.tensor([0], dtype=torch.long)}

    with pytest.raises(SampleDecodeError):
        list(batcher.run(src()))


def test_naflex_batcher_decode_error_handler_false_reraises():
    """A decode_error_handler returning a falsy value re-raises immediately (webdataset handler convention),
    instead of skipping -- so a caller can opt into fail-fast on bad data."""
    batcher = NaFlexBatcher(
        train_num_samples=4, patch_size=16, seq_lens=(4,), max_tokens_per_batch=8,
        transform_factory=_transform_factory, batch_divisor=1, shuffle=False,
        decode_fn=_decode_to_pil, decode_error_handler=lambda ex: False,
    )
    src = iter([{"image": _POISON, "text": torch.tensor([0], dtype=torch.long)}])
    with pytest.raises(SampleDecodeError):
        list(batcher.run(src))


def test_naflex_batcher_drop_last_governs_trailing_partial_batch():
    """On source exhaustion mid-batch, drop_last=True (train default) drops the short batch so DDP never sees an
    uneven shape; drop_last=False (eval) keeps it. Full batches always yield."""
    common = dict(
        train_num_samples=4, patch_size=16, seq_lens=(4,), max_tokens_per_batch=8,  # schedule = 2 batches of 2
        transform_factory=_transform_factory, batch_divisor=1, shuffle=False,
    )

    def three_samples():  # only 3 -> batch 0 full (2), batch 1 partial (1)
        return iter([{"image": _decode_to_pil(i), "text": torch.tensor([i], dtype=torch.long)} for i in range(3)])

    dropped = list(NaFlexBatcher(**common, drop_last=True).run(three_samples()))
    assert len(dropped) == 1 and dropped[0]["image"]["patches"].shape[0] == 2  # partial 2nd batch dropped

    kept = list(NaFlexBatcher(**common, drop_last=False).run(three_samples()))
    assert len(kept) == 2 and kept[1]["image"]["patches"].shape[0] == 1  # partial 2nd batch kept


def test_naflex_batcher_token_schedule_handles_distributed_padding():
    batcher = NaFlexBatcher(
        train_num_tokens=17,
        patch_size=16,
        seq_lens=(4,),
        max_tokens_per_batch=8,
        transform_factory=_transform_factory,
        batch_divisor=1,
        distributed=True,
        rank=0,
        world_size=2,
        shuffle=False,
    )

    assert batcher.num_batches == 2
    assert batcher.num_samples == 6


def test_naflex_batcher_pads_schedule_to_worker_count():
    batcher = NaFlexBatcher(
        train_num_samples=1,
        patch_size=16,
        seq_lens=(4,),
        max_tokens_per_batch=8,
        transform_factory=_transform_factory,
        batch_divisor=1,
        shuffle=False,
    )

    assert batcher.num_batches == 1
    assert batcher.num_batches_for_workers(4) == 4
    assert batcher.num_samples_for_workers(4) == 4


def test_naflex_batcher_worker_padded_sample_count_matches_shuffled_epochs():
    """Padding before shuffling keeps the advertised worker-padded sample count stable across epochs."""
    batcher = NaFlexBatcher(
        train_num_samples=17,
        patch_size=16,
        seq_lens=(4, 8, 16),
        seq_len_choice_probs=(1, 2, 1),
        max_tokens_per_batch=32,
        transform_factory=_transform_factory,
        batch_divisor=1,
        seed=7,
        shuffle=True,
    )

    expected_samples = batcher.num_samples_for_workers(4)
    expected_batches = batcher.num_batches_for_workers(4)
    for epoch in range(5):
        schedule = batcher.scheduler.epoch_schedule(epoch, num_workers=4)
        assert len(schedule) == expected_batches
        assert sum(batch_size for _, batch_size in schedule) == expected_samples


def test_image_transform_naflex_returns_timm_transform_factory():
    factory = image_transform(
        32,
        is_train=True,
        aug_cfg={"use_timm": True, "naflex": True, "scale": (1.0, 1.0), "ratio": (1.0, 1.0)},
    )

    transform = factory(max_seq_len=4, patch_size=16)
    image = transform(Image.new("RGB", (32, 32)))

    assert getattr(factory, "is_naflex_transform_factory")
    assert isinstance(image, torch.Tensor)
    assert image.shape[-2:] == (32, 32)


def test_image_transform_timm_non_naflex_remains_image_callable():
    transform = image_transform(
        32,
        is_train=True,
        aug_cfg={"use_timm": True, "scale": (1.0, 1.0), "ratio": (1.0, 1.0)},
    )

    image = transform(Image.new("RGB", (32, 32)))

    assert isinstance(image, torch.Tensor)
    assert image.shape == (3, 32, 32)


def test_timm_transforms_accept_list_image_size():
    # Sizes parsed from JSON configs or `--force-image-size H W` arrive as lists, not tuples.
    transform = image_transform(
        [32, 48],
        is_train=True,
        aug_cfg={"use_timm": True, "scale": (1.0, 1.0), "ratio": (1.0, 1.0)},
    )
    image = transform(Image.new("RGB", (48, 32)))
    assert image.shape == (3, 32, 48)

    assert PreprocessCfg(size=[32, 48]).input_size == (3, 32, 48)


def test_parse_naflex_args():
    args = parse_args([
        "--use-naflex",
        "--naflex-num-train-image-tokens",
        "1024",
        "--naflex-patch-sizes",
        "16",
        "32",
        "--naflex-patch-size-probs",
        "0.25",
        "0.75",
        "--naflex-seq-lens",
        "128",
        "256",
        "--naflex-max-tokens-per-batch",
        "4096",
        "--naflex-batch-divisor",
        "4",
        "--naflex-loss-scale",
        "sqrt",
    ])

    assert args.use_naflex
    assert args.force_naflex_patch_interp is True  # auto-enabled: more than one patch size listed
    assert args.naflex_num_train_image_tokens == 1024
    assert args.naflex_patch_sizes == [16, 32]
    assert args.naflex_patch_size_probs == [0.25, 0.75]
    assert args.naflex_seq_lens == [128, 256]
    assert args.naflex_max_tokens_per_batch == 4096
    assert args.naflex_batch_divisor == 4
    assert args.naflex_loss_scale == "sqrt"


def test_naflex_patchify_flattens_per_model_base_patch_size():
    multi = NaFlexBatcher(
        train_num_samples=1,
        patch_size_choices=(16, 32),
        model_patch_size=16,
        seq_lens=(4,),
        max_tokens_per_batch=4,
        transform_factory=_transform_factory,
        batch_divisor=1,
        shuffle=False,
    )
    image = torch.randn(3, 64, 64)

    base = multi.scheduler.patchifiers[0](image)["patches"]
    non_base = multi.scheduler.patchifiers[1](image)["patches"]

    assert base.shape == (16, 16 * 16 * 3)
    assert non_base.shape == (4, 32, 32, 3)

    fixed_non_base = NaFlexBatcher(
        train_num_samples=1,
        patch_size=32,
        model_patch_size=16,
        seq_lens=(4,),
        max_tokens_per_batch=4,
        transform_factory=_transform_factory,
        batch_divisor=1,
        shuffle=False,
    )
    assert fixed_non_base.scheduler.patchifiers[0](image)["patches"].shape == (4, 32, 32, 3)


def test_naflex_eval_keeps_non_base_patch_dimensions():
    factory = NaFlexEvalTransformFactory(
        input_size=(3, 64, 64),
        mean=(0.5, 0.5, 0.5),
        std=(0.5, 0.5, 0.5),
        interpolation="bilinear",
    )
    config = NaFlexDataConfig.resolve(
        patch_sizes=[32],
        seq_lens=[4],
        model_patch_size=16,
        supports_patch_interpolation=True,
    )

    transform, max_seq_len, patch_size = create_naflex_eval_transform(factory, config)
    image = transform(Image.new("RGB", (64, 64)))

    assert max_seq_len == 4
    assert patch_size == (32, 32)
    assert image["patches"].shape == (4, 32, 32, 3)


def test_naflex_loss_scale_defaults_to_none():
    args = parse_args([])

    assert args.naflex_loss_scale == "none"
    assert args.naflex_max_tokens_per_batch is None


def test_naflex_loss_scale_relative_to_reference():
    def make(mode, reference):
        return make_loss_scale_fn(
            types.SimpleNamespace(naflex_loss_scale=mode), types.SimpleNamespace(naflex_mean_batch_size=reference))

    assert make("none", 4.0) is None
    assert make("linear", 4.0)(8, 1) == 2.0
    assert make("sqrt", 2.0)(8, 1) == 2.0
    # An accum window is scaled as one step: summed batch size against num_batches * reference.
    assert make("linear", 4.0)(12, 2) == 1.5
    # Dense loaders carry no schedule mean; asking for NaFlex scaling there is a config error.
    with pytest.raises(ValueError, match="NaFlex train loader"):
        make("linear", None)


def test_naflex_mean_batch_size_follows_seq_len_probs():
    def make(probs):
        return NaFlexBatcher(
            train_num_samples=4096, patch_size=16, seq_lens=[64, 256], seq_len_choice_probs=probs,
            transform_factory=lambda **kw: (lambda x: x), max_tokens_per_batch=1024, batch_divisor=1,
        )

    short_heavy, long_heavy = make([0.9, 0.1]), make([0.1, 0.9])
    for batcher in (short_heavy, long_heavy):
        # Mean of the trained (worker-padded) schedule, i.e. the loader's own sample / batch counts.
        assert batcher.mean_batch_size_for_workers(3) == (
            batcher.num_samples_for_workers(3) / batcher.num_batches_for_workers(3))
    # Row batch sizes are 16 (seq 64) and 4 (seq 256); the mean tracks the per-batch seq-len probs.
    assert 14.0 < short_heavy.mean_batch_size_for_workers(1) < 16.0
    assert 4.0 < long_heavy.mean_batch_size_for_workers(1) < 6.0


def test_naflex_eval_config_rejects_non_positive_values():
    args = types.SimpleNamespace(naflex_patch_sizes=[16], naflex_seq_lens=[0, 4])
    with pytest.raises(ValueError, match="sequence lengths"):
        create_naflex_data_config_from_args(args)

    args = types.SimpleNamespace(naflex_patch_sizes=[0], naflex_seq_lens=[4])
    with pytest.raises(ValueError, match="patch size"):
        create_naflex_data_config_from_args(args)


def test_naflex_data_config_uses_model_eval_seq_len_default():
    args = types.SimpleNamespace(naflex_patch_sizes=[16], naflex_seq_lens=None)
    config = create_naflex_data_config_from_args(args, default_eval_seq_len=576)

    assert config.train_seq_lens == (128, 256, 576, 784, 1024)
    assert config.eval_seq_len == 576


def test_naflex_seq_lens_override_model_eval_seq_len_default():
    args = types.SimpleNamespace(naflex_patch_sizes=[16], naflex_seq_lens=[64])
    config = create_naflex_data_config_from_args(args, default_eval_seq_len=576)

    assert config.train_seq_lens == (64,)
    assert config.eval_seq_len == 64


def test_get_wds_dataset_naflex_keeps_dictionary_contract(tmp_path):
    tar_path = tmp_path / "samples.tar"
    _write_tar(tar_path)

    args = types.SimpleNamespace(
        train_data=str(tar_path),
        val_data=None,
        dataset_resampled=False,
        train_data_upsampling_factors=None,
        train_num_samples=4,
        val_num_samples=None,
        use_naflex=True,
        naflex_num_train_image_tokens=None,
        naflex_patch_sizes=[16],
        naflex_patch_size_probs=None,
        naflex_seq_lens=[4],
        naflex_batch_divisor=1,
        seed=0,
        workers=0,
        batch_size=2,
        distributed=False,
        rank=0,
        world_size=1,
        text_attention_mask=True,
    )
    tokenizer = _MaskTokenizer()

    info = get_wds_dataset(
        args,
        _transform_factory,
        is_train=True,
        tokenizer=tokenizer,
        naflex_data_config=create_naflex_data_config_from_args(args),
        model_traits=CLIP_TRAITS,
    )
    batch = next(iter(info.dataloader))

    assert set(batch.keys()) == {"image", "text", "text_valid"}
    assert batch["image"]["patches"].shape == (2, 4, 16 * 16 * 3)
    assert batch["text"].shape == (2, 4)
    assert batch["text_valid"].tolist() == [[True, True, True, False]] * 2


def test_get_wds_dataset_naflex_rolls_over_non_resampled_input(tmp_path):
    tar_path = tmp_path / "samples.tar"
    _write_tar(tar_path, num_samples=2)

    args = types.SimpleNamespace(
        train_data=str(tar_path),
        val_data=None,
        dataset_resampled=False,
        train_data_upsampling_factors=None,
        train_num_samples=6,
        val_num_samples=None,
        use_naflex=True,
        naflex_num_train_image_tokens=None,
        naflex_patch_sizes=[16],
        naflex_patch_size_probs=None,
        naflex_seq_lens=[4],
        naflex_max_tokens_per_batch=8,
        naflex_batch_divisor=1,
        seed=0,
        workers=0,
        batch_size=2,
        distributed=False,
        rank=0,
        world_size=1,
    )
    tokenizer = lambda text: [torch.tensor([int(text.strip())], dtype=torch.long)]

    info = get_wds_dataset(
        args,
        _transform_factory,
        is_train=True,
        tokenizer=tokenizer,
        naflex_data_config=create_naflex_data_config_from_args(args),
        model_traits=CLIP_TRAITS,
    )
    batches = list(info.dataloader)

    assert len(batches) == 3
    assert sum(batch["image"]["patches"].shape[0] for batch in batches) == 6


def test_create_model_and_transforms_returns_naflex_eval_factory():
    _, _, preprocess_val = open_clip.create_model_and_transforms(
        "naflex_ViT-B-16",
        pretrained=None,
        device="cpu",
        aug_cfg={"use_timm": True, "naflex": True},
    )

    transform = preprocess_val(max_seq_len=4, patch_size=16)
    image = transform(Image.new("RGB", (32, 32)))

    assert getattr(preprocess_val, "is_naflex_eval_transform_factory")
    assert set(image.keys()) == {"patches", "patch_coord", "patch_valid"}
    assert image["patches"].shape == (4, 16 * 16 * 3)
    assert image["patch_coord"].shape == (4, 2)
    assert image["patch_valid"].all()


def test_get_wds_dataset_naflex_eval_outputs_patched_image_dict(tmp_path):
    tar_path = tmp_path / "samples.tar"
    _write_tar(tar_path)
    _, _, preprocess_val = open_clip.create_model_and_transforms(
        "naflex_ViT-B-16",
        pretrained=None,
        device="cpu",
        aug_cfg={"use_timm": True, "naflex": True},
    )
    args = types.SimpleNamespace(
        train_data=None,
        val_data=str(tar_path),
        dataset_resampled=False,
        train_data_upsampling_factors=None,
        train_num_samples=None,
        val_num_samples=4,
        use_naflex=True,
        naflex_patch_sizes=[16],
        naflex_patch_size_probs=None,
        naflex_seq_lens=[4],
        naflex_max_tokens_per_batch=8,
        naflex_batch_divisor=1,
        seed=0,
        workers=0,
        batch_size=2,
        distributed=False,
        rank=0,
        world_size=1,
        text_attention_mask=True,
    )
    tokenizer = _MaskTokenizer()

    info = get_wds_dataset(
        args,
        preprocess_val,
        is_train=False,
        tokenizer=tokenizer,
        naflex_data_config=create_naflex_data_config_from_args(args),
        model_traits=CLIP_TRAITS,
    )
    batch = next(iter(info.dataloader))

    assert set(batch.keys()) == {"image", "text", "text_valid"}
    assert batch["image"]["patches"].shape == (2, 4, 16 * 16 * 3)
    assert batch["image"]["patch_coord"].shape == (2, 4, 2)
    assert batch["image"]["patch_valid"].all()
    assert batch["text"].shape == (2, 4)
    assert batch["text_valid"].tolist() == [[True, True, True, False]] * 2


def test_get_imagenet_naflex_eval_outputs_patched_image_dict(tmp_path):
    class_dir = tmp_path / "imagenet" / "class0"
    class_dir.mkdir(parents=True)
    for idx in range(2):
        Image.new("RGB", (32, 32), color=(idx, idx, idx)).save(class_dir / f"{idx}.png")

    _, preprocess_train, preprocess_val = open_clip.create_model_and_transforms(
        "naflex_ViT-B-16",
        pretrained=None,
        device="cpu",
        aug_cfg={"use_timm": True, "naflex": True},
    )
    args = types.SimpleNamespace(
        imagenet_train=None,
        imagenet_val=str(tmp_path / "imagenet"),
        imagenet_v2=None,
        use_naflex=True,
        naflex_patch_sizes=[16],
        naflex_seq_lens=[4],
        batch_size=2,
        workers=0,
    )

    info = get_imagenet(
        args,
        (preprocess_train, preprocess_val),
        "val",
        naflex_data_config=create_naflex_data_config_from_args(args),
    )
    images, targets = next(iter(info.dataloader))

    assert images["patches"].shape == (2, 4, 16 * 16 * 3)
    assert images["patch_coord"].shape == (2, 4, 2)
    assert images["patch_valid"].all()
    assert targets.tolist() == [0, 0]


def test_get_imagenet_naflex_train_raises_clear_error():
    args = types.SimpleNamespace(use_naflex=True)

    with pytest.raises(ValueError, match="--imagenet-train"):
        get_imagenet(
            args,
            (_transform_factory, _transform_factory),
            "train",
            naflex_data_config=create_naflex_data_config_from_args(args),
        )


def test_naflex_model_forward_accepts_eval_transform_image_dict():
    model, _, preprocess_val = open_clip.create_model_and_transforms(
        "naflex_ViT-B-16",
        pretrained=None,
        device="cpu",
        aug_cfg={"use_timm": True, "naflex": True},
    )
    transform = preprocess_val(max_seq_len=4, patch_size=16)
    images, _ = collate_naflex_tuples(
        [(transform(Image.new("RGB", (32, 32))), torch.tensor(0)) for _ in range(2)],
        max_seq_len=4,
    )
    text = torch.zeros(2, 77, dtype=torch.long)

    with torch.inference_mode():
        image_features, text_features, _ = model(images, text)

    assert image_features.shape == (2, 512)
    assert text_features.shape == (2, 512)


def test_naflex_model_forward_accepts_batcher_image_dict():
    samples = [
        {
            "image": Image.new("RGB", (32, 32), color=(idx, idx, idx)),
            "text": torch.zeros(77, dtype=torch.long),
        }
        for idx in range(2)
    ]
    batcher = NaFlexBatcher(
        train_num_samples=2,
        patch_size=16,
        seq_lens=(4,),
        max_tokens_per_batch=8,
        transform_factory=_transform_factory,
        batch_divisor=1,
        shuffle=False,
    )
    batch = next(iter(batcher.run(samples)))
    model = open_clip.create_model("naflex_ViT-B-16", pretrained=None, device="cpu")

    with torch.inference_mode():
        image_features, text_features, _ = model(batch["image"], batch["text"])

    assert image_features.shape == (2, 512)
    assert text_features.shape == (2, 512)


def test_naflex_model_forward_accepts_dense_image_tensor():
    model = open_clip.create_model("naflex_ViT-B-16", pretrained=None, device="cpu")
    image = torch.randn(2, 3, 32, 32)
    text = torch.zeros(2, 77, dtype=torch.long)

    with torch.inference_mode():
        image_features, text_features, _ = model(image, text)

    assert image_features.shape == (2, 512)
    assert text_features.shape == (2, 512)
