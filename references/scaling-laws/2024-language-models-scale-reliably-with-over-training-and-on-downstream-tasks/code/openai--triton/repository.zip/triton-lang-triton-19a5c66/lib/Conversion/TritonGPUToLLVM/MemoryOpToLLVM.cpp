#include "mlir/Conversion/LLVMCommon/Pattern.h"
#include "mlir/Conversion/LLVMCommon/TypeConverter.h"
#include "mlir/Dialect/GPU/IR/GPUDialect.h"
#include "mlir/IR/PatternMatch.h"
#include "triton/Analysis/Utility.h"
#include "triton/Conversion/TritonGPUToLLVM/PatternTritonGPUOpToLLVM.h"
#include "triton/Conversion/TritonGPUToLLVM/TargetInfoBase.h"
#include "triton/Conversion/TritonGPUToLLVM/Utility.h"
#include "triton/Dialect/TritonGPU/IR/Dialect.h"
#include "triton/Tools/LayoutUtils.h"

namespace ttg = mlir::triton::gpu;

namespace {

using namespace mlir;
using namespace mlir::triton;
using namespace mlir::triton::gpu;

// Helper for LocalGather/ScatterOpConversion.
// For gather: storeVals is empty, returns loaded values.
// For scatter: storeVals contains values to store, returns empty.
SmallVector<Value> lowerLocalScGt(Location loc, MemDescType memDescTy,
                                  SharedMemoryObject smemObj, Type llvmElemTy,
                                  const LinearLayout &regLayout,
                                  ArrayRef<Value> idxValues, unsigned axis,
                                  ArrayRef<Value> storeVals,
                                  RewriterBase &rewriter,
                                  const TargetInfoBase &targetInfo) {
  auto b = TritonLLVMOpBuilder(loc, rewriter);
  bool isScatter = !storeVals.empty();
  auto offsetAndBlock = computeBlockLocalOffsets(
      loc, memDescTy, regLayout, idxValues, axis, rewriter, targetInfo);
  SmallVector<LocalSharedMemoryAddress> addrs = materializeLocalAddrs(
      loc, memDescTy, smemObj, llvmElemTy, offsetAndBlock, rewriter);

  SmallVector<Value> results;
  if (!isScatter)
    results.resize(idxValues.size());

  for (auto [i, addr] : llvm::enumerate(addrs)) {
    if (isScatter) {
      targetInfo.storeDShared(rewriter, loc, addr.ptr, addr.ctaId, storeVals[i],
                              b.true_val());
    } else {
      results[i] = targetInfo.loadDShared(rewriter, loc, addr.ptr, addr.ctaId,
                                          llvmElemTy, b.true_val());
    }
  }

  return results;
}

LogicalResult lowerLocalStore(Location loc, MLIRContext *ctx,
                              const LinearLayout &regLayout,
                              MemDescType memDescTy, SharedMemoryObject smemObj,
                              SmallVector<Value> &inVals,
                              const LLVMTypeConverter *typeConverter,
                              ConversionPatternRewriter &rewriter,
                              const TargetInfoBase &targetInfo) {
  auto kReg = str_attr("register");
  assert(regLayout.getFreeVariableMasks().lookup(kReg) == 0 &&
         "expected register broadcasting to be removed by the caller");
  auto llvmElemTy = typeConverter->convertType(memDescTy.getElementType());
  auto b = TritonLLVMOpBuilder(loc, rewriter);

  auto sharedLayout = toLinearLayoutIgnoringPadding(memDescTy);
  auto cvt = invertAndComposeStore(sharedLayout, regLayout);
  // Extra high register bits select CTA replicas, so repeat the source values.
  // reg = {register=[], block=[[1]]}, shmem = {offset=[[1]], block=[[0]]}.
  // CTA i repeats x[i] to store it at offset i in both CTAs.
  int numStoreRegs = cvt.getInDimSize(kReg);
  if (numStoreRegs != regLayout.getInDimSize(kReg))
    inVals = broadcastAs(inVals, regLayout.resizeInDim(kReg, numStoreRegs));

  lowerLocalLdSt(loc, ctx, cvt, inVals, llvmElemTy, memDescTy, smemObj,
                 rewriter, targetInfo,
                 makeSharedStoreEmitter(targetInfo, b.true_val()));

  return success();
}

struct GlobalScratchAllocOpConversion
    : public ConvertOpToLLVMPattern<triton::gpu::GlobalScratchAllocOp> {
  const TargetInfoBase *targetInfo;

  GlobalScratchAllocOpConversion(LLVMTypeConverter &converter,
                                 const TargetInfoBase &targetInfo,
                                 PatternBenefit benefit)
      : ConvertOpToLLVMPattern(converter, benefit), targetInfo(&targetInfo) {}

  LogicalResult
  matchAndRewrite(triton::gpu::GlobalScratchAllocOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    Location loc = op.getLoc();
    auto b = TritonLLVMOpBuilder(loc, rewriter);

    auto opOffsetAttr = op->getAttrOfType<mlir::IntegerAttr>(
        "ttg.global_scratch_memory_offset");
    assert(opOffsetAttr);
    auto opOffset = opOffsetAttr.getValue().getZExtValue();

    auto funcOp = op->getParentOfType<LLVM::LLVMFuncOp>();
    if (!funcOp) {
      return failure();
    }
    Value ptr = op.getThirdPartyAllocation()
                    ? LLVM::getProfileScratchPtr(loc, rewriter, *targetInfo,
                                                 funcOp, b.i32_val(opOffset),
                                                 !op.getSharedClusterState())
                    : LLVM::getGlobalScratchPtr(loc, rewriter, *targetInfo,
                                                funcOp, b.i32_val(opOffset));

    rewriter.replaceOp(op, ptr);
    return success();
  }
};

struct LocalAllocOpConversion
    : public ConvertOpToLLVMPattern<triton::gpu::LocalAllocOp> {
  LocalAllocOpConversion(const LLVMTypeConverter &converter,
                         const TargetInfoBase &targetInfo,
                         PatternBenefit benefit = 1)
      : ConvertOpToLLVMPattern<triton::gpu::LocalAllocOp>(converter, benefit),
        targetInfo(targetInfo) {}

  LogicalResult
  matchAndRewrite(triton::gpu::LocalAllocOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    if (!op.isSharedMemoryAlloc())
      return failure();
    Location loc = op->getLoc();
    // Get all shared memory bases (one for non-partitioned, multiple for
    // partitioned tensors)
    SmallVector<Value> smemBases = LLVM::getSharedMemoryBases(
        loc, rewriter, targetInfo, op.getOperation());
    auto memDescTy = cast<MemDescType>(op.getType());
    auto typeConverter = getTypeConverter();

    auto llvmElemTy = typeConverter->convertType(memDescTy.getElementType());
    auto smemObj = SharedMemoryObject(smemBases, llvmElemTy,
                                      memDescTy.getRank(), loc, rewriter);
    // If there is an initial tensor, store it into the shared memory.
    if (op.getSrc()) {
      auto *ctx = op.getContext();
      auto regTy = cast<RankedTensorType>(op.getSrc().getType());
      auto regLayout =
          toLinearLayout(regTy).removeZeroBasesAlongDim(str_attr("register"));
      auto inVals = unpackUniqueTensorElements(loc, adaptor.getSrc(), rewriter);
      if (failed(lowerLocalStore(loc, ctx, regLayout, memDescTy, smemObj,
                                 inVals, typeConverter, rewriter,
                                 targetInfo))) {
        return failure();
      }
    }
    auto retVal = getStructFromSharedMemoryObject(loc, smemObj, rewriter);
    rewriter.replaceOp(op, retVal);
    return success();
  }

private:
  const TargetInfoBase &targetInfo;
};

struct LocalDeallocOpConversion
    : public ConvertOpToLLVMPattern<triton::gpu::LocalDeallocOp> {
  using ConvertOpToLLVMPattern<
      triton::gpu::LocalDeallocOp>::ConvertOpToLLVMPattern;

  LogicalResult
  matchAndRewrite(triton::gpu::LocalDeallocOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    rewriter.eraseOp(op);
    return success();
  }
};

struct LocalLoadOpConversion : public ConvertOpToLLVMPattern<LocalLoadOp> {
public:
  LocalLoadOpConversion(LLVMTypeConverter &typeConverter,
                        const TargetInfoBase &targetInfo,
                        PatternBenefit benefit = 1)
      : ConvertOpToLLVMPattern(typeConverter, benefit), targetInfo(targetInfo) {
  }

  LogicalResult
  matchAndRewrite(LocalLoadOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    auto loc = op.getLoc();
    auto *ctx = op.getContext();
    auto memDescVal = op.getSrc();
    auto regVal = op.getResult();
    auto memDescTy = cast<MemDescType>(memDescVal.getType());
    auto regTy = cast<RankedTensorType>(regVal.getType());
    auto typeConverter = getTypeConverter();

    auto llvmElemTy = typeConverter->convertType(memDescTy.getElementType());
    auto smemObj = LLVM::getSharedMemoryObjectFromStruct(loc, adaptor.getSrc(),
                                                         llvmElemTy, rewriter);

    auto regLayout =
        toLinearLayout(regTy).removeZeroBasesAlongDim(str_attr("register"));
    auto sharedLayout = toLinearLayoutIgnoringPadding(memDescTy);
    auto kBlock = str_attr("block");
    auto cvt = invertAndComposeLocal(sharedLayout, regLayout, {kBlock});

    auto outVals = lowerLocalLdSt(loc, ctx, cvt, {}, llvmElemTy, memDescTy,
                                  smemObj, rewriter, targetInfo,
                                  makeSharedLoadEmitter(targetInfo, op));

    Value result =
        packUniqueTensorElements(loc, typeConverter, outVals, rewriter, regTy);
    rewriter.replaceOp(op, result);

    return success();
  }

private:
  const TargetInfoBase &targetInfo;
};

struct LocalStoreOpConversion
    : public ConvertOpToLLVMPattern<triton::gpu::LocalStoreOp> {
public:
  using ConvertOpToLLVMPattern<
      triton::gpu::LocalStoreOp>::ConvertOpToLLVMPattern;

  LocalStoreOpConversion(const LLVMTypeConverter &converter,
                         const TargetInfoBase &targetInfo,
                         PatternBenefit benefit = 1)
      : ConvertOpToLLVMPattern<triton::gpu::LocalStoreOp>(converter, benefit),
        targetInfo(targetInfo) {}

  LogicalResult
  matchAndRewrite(triton::gpu::LocalStoreOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    auto loc = op.getLoc();
    auto *ctx = op.getContext();
    Value memDescVal = op.getDst();
    auto typeConverter = getTypeConverter();
    auto regTy = cast<RankedTensorType>(op.getSrc().getType());
    auto memDescTy = cast<MemDescType>(memDescVal.getType());
    auto llvmElemTy = typeConverter->convertType(memDescTy.getElementType());
    auto smemObj = LLVM::getSharedMemoryObjectFromStruct(loc, adaptor.getDst(),
                                                         llvmElemTy, rewriter);
    auto regLayout =
        toLinearLayout(regTy).removeZeroBasesAlongDim(str_attr("register"));
    auto inVals = unpackUniqueTensorElements(loc, adaptor.getSrc(), rewriter);
    if (failed(lowerLocalStore(loc, ctx, regLayout, memDescTy, smemObj, inVals,
                               typeConverter, rewriter, targetInfo))) {
      return failure();
    }

    rewriter.eraseOp(op);
    return success();
  }

private:
  const TargetInfoBase &targetInfo;
};

struct ThreadPredicateOpConversion
    : public ConvertOpToLLVMPattern<ThreadPredicateOp> {
  ThreadPredicateOpConversion(LLVMTypeConverter &converter,
                              const TargetInfoBase &targetInfo,
                              PatternBenefit benefit)
      : ConvertOpToLLVMPattern(converter, benefit), targetInfo(targetInfo) {}

  LogicalResult
  matchAndRewrite(ThreadPredicateOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    Value predicate =
        emitThreadPredicate(op.getDomain(), rewriter, op.getLoc(), targetInfo);
    rewriter.replaceOp(op, predicate);
    return success();
  }

private:
  const TargetInfoBase &targetInfo;
};

struct ThreadHandoffOpConversion
    : public ConvertOpToLLVMPattern<ThreadHandoffOp> {
  ThreadHandoffOpConversion(LLVMTypeConverter &converter,
                            const TargetInfoBase &targetInfo,
                            PatternBenefit benefit)
      : ConvertOpToLLVMPattern(converter, benefit), targetInfo(targetInfo) {}

  LogicalResult
  matchAndRewrite(ThreadHandoffOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    Value result = adaptor.getSrc();
    auto source = op.getSource();
    auto destination = op.getDestination();
    if (source == destination) {
      rewriter.replaceOp(op, result);
      return success();
    }

    auto loc = op.getLoc();
    // Work around https://github.com/llvm/llvm-project/issues/224146:
    // peeling can split convergent handoffs into owner/non-owner loops.
    // noduplicate also blocks valid unrolling. Revisit this workaround once
    // LLVM preserves convergence through peeling.
    auto boundary = appendOrGetExternFuncOp(
        rewriter, op, "llvm.sideeffect",
        LLVM::LLVMFunctionType::get(LLVM::LLVMVoidType::get(op.getContext()),
                                    {}));
    auto call = LLVM::CallOp::create(rewriter, loc, boundary, ValueRange{});
    call.setNoduplicate(true);
    call.setConvergent(true);
    if (source.hasSameWarpAndBlock(destination)) {
      shuffleFromCanonicalLane(loc, MutableArrayRef<Value>(result),
                               source.getLane(), rewriter, targetInfo);
    } else {
      // Publish from lane zero of warp zero in each source CTA.
      auto publisher = ThreadDomainAttr::get(
          op.getContext(), lookupThreadsPerWarp(rewriter) - 1,
          lookupNumWarps(op) - 1, source.getBlock());
      Value predicate =
          emitThreadPredicate(publisher, rewriter, loc, targetInfo);
      result =
          broadcastScalarResult(op, result, rewriter, predicate, targetInfo);
    }
    rewriter.replaceOp(op, result);
    return success();
  }

private:
  const TargetInfoBase &targetInfo;
};

class BarrierOpConversion
    : public ConvertOpToLLVMPattern<triton::gpu::BarrierOp> {
public:
  BarrierOpConversion(const LLVMTypeConverter &converter,
                      const TargetInfoBase &targetInfo, PatternBenefit benefit)
      : ConvertOpToLLVMPattern<triton::gpu::BarrierOp>(converter, benefit),
        targetInfo(targetInfo) {}
  using OpAdaptor = typename triton::gpu::BarrierOp::Adaptor;

  LogicalResult
  matchAndRewrite(triton::gpu::BarrierOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    if (op.isWarp()) {
      targetInfo.warpSync(op.getLoc(), rewriter);
      rewriter.eraseOp(op);
      return success();
    }
    rewriter.replaceOpWithNewOp<mlir::gpu::BarrierOp>(op);
    return success();
  }

private:
  const TargetInfoBase &targetInfo;
};

struct LocalGatherOpConversion : public ConvertOpToLLVMPattern<LocalGatherOp> {
public:
  LocalGatherOpConversion(LLVMTypeConverter &typeConverter,
                          const TargetInfoBase &targetInfo,
                          PatternBenefit benefit = 1)
      : ConvertOpToLLVMPattern(typeConverter, benefit), targetInfo(targetInfo) {
  }

  LogicalResult
  matchAndRewrite(LocalGatherOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    auto loc = op.getLoc();
    auto *ctx = op.getContext();
    auto memDescTy = cast<MemDescType>(op.getSrc().getType());
    // TODO: PartitionedSharedEncoding lowering will be enabled in subsequent
    // PRs.
    if (isa<triton::gpu::PartitionedSharedEncodingAttr>(
            memDescTy.getEncoding())) {
      return rewriter.notifyMatchFailure(
          op, "PartitionedSharedEncoding not yet supported in lowering");
    }
    auto regTy = cast<RankedTensorType>(op.getType());
    auto typeConverter = getTypeConverter();

    auto llvmElemTy = typeConverter->convertType(memDescTy.getElementType());
    auto smemObj = LLVM::getSharedMemoryObjectFromStruct(loc, adaptor.getSrc(),
                                                         llvmElemTy, rewriter);

    SmallVector<Value> idxValues =
        unpackUniqueTensorElements(loc, adaptor.getIndices(), rewriter);
    auto regLayout =
        toLinearLayout(regTy).removeZeroBasesAlongDim(str_attr("register"));

    auto results = lowerLocalScGt(loc, memDescTy, smemObj, llvmElemTy,
                                  regLayout, idxValues, op.getAxis(),
                                  /*storeVals=*/{}, rewriter, targetInfo);

    Value result =
        packUniqueTensorElements(loc, typeConverter, results, rewriter, regTy);
    rewriter.replaceOp(op, result);

    return success();
  }

private:
  const TargetInfoBase &targetInfo;
};

struct LocalScatterOpConversion
    : public ConvertOpToLLVMPattern<LocalScatterOp> {
public:
  LocalScatterOpConversion(LLVMTypeConverter &typeConverter,
                           const TargetInfoBase &targetInfo,
                           PatternBenefit benefit = 1)
      : ConvertOpToLLVMPattern(typeConverter, benefit), targetInfo(targetInfo) {
  }

  LogicalResult
  matchAndRewrite(LocalScatterOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    auto loc = op.getLoc();
    auto *ctx = op.getContext();
    auto memDescTy = cast<MemDescType>(op.getDst().getType());
    // TODO: PartitionedSharedEncoding lowering will be enabled in subsequent
    // PRs.
    if (isa<triton::gpu::PartitionedSharedEncodingAttr>(
            memDescTy.getEncoding())) {
      return rewriter.notifyMatchFailure(
          op, "PartitionedSharedEncoding not yet supported in lowering");
    }
    auto valuesTy = cast<RankedTensorType>(op.getValues().getType());
    auto typeConverter = getTypeConverter();

    auto llvmElemTy = typeConverter->convertType(memDescTy.getElementType());
    auto smemObj = LLVM::getSharedMemoryObjectFromStruct(loc, adaptor.getDst(),
                                                         llvmElemTy, rewriter);

    SmallVector<Value> values =
        unpackUniqueTensorElements(loc, adaptor.getValues(), rewriter);
    SmallVector<Value> idxValues =
        unpackUniqueTensorElements(loc, adaptor.getIndices(), rewriter);
    auto regLayout =
        toLinearLayout(valuesTy).removeZeroBasesAlongDim(str_attr("register"));

    lowerLocalScGt(loc, memDescTy, smemObj, llvmElemTy, regLayout, idxValues,
                   op.getAxis(), values, rewriter, targetInfo);

    rewriter.eraseOp(op);
    return success();
  }

private:
  const TargetInfoBase &targetInfo;
};

struct AtomicPollOpConversion
    : public ConvertOpToLLVMPattern<triton::AtomicPollOp> {
  AtomicPollOpConversion(LLVMTypeConverter &converter,
                         const TargetInfoBase &targetInfo,
                         PatternBenefit benefit)
      : ConvertOpToLLVMPattern<triton::AtomicPollOp>(converter, benefit),
        targetInfo(targetInfo) {}

  LogicalResult
  matchAndRewrite(triton::AtomicPollOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    auto loc = op.getLoc();
    auto b = TritonLLVMOpBuilder(loc, rewriter);
    int numCTAs = lookupNumCTAs(op);
    if (numCTAs != 1 && !targetInfo.isCuda())
      return rewriter.notifyMatchFailure(
          op, "multi-CTA atomic_poll requires cross-CTA shared memory");

    auto ptrs = unpackUniqueTensorElements(loc, adaptor.getPtr(), rewriter);
    auto expected =
        unpackUniqueTensorElements(loc, adaptor.getExpected(), rewriter);
    auto freeVarMasks = getFreeVariableMasks(op.getPtr().getType());
    Value threadPred =
        emitRedundantThreadPredicate(freeVarMasks, rewriter, loc, targetInfo);
    if (!threadPred)
      threadPred = b.true_val();

    Value start;
    if (adaptor.getTimeout())
      start = targetInfo.getGlobalTimer(rewriter, loc);
    SmallVector<Value> results;
    for (auto [ptr, value] : llvm::zip_equal(ptrs, expected))
      results.push_back(emitPoll(op, ptr, value, start, adaptor.getTimeout(),
                                 threadPred, rewriter));

    auto rendezvous = [&] {
      if (numCTAs == 1)
        targetInfo.barrier(loc, rewriter, AddrSpace::Local);
      else
        targetInfo.clusterBarrier(loc, rewriter, op);
    };

    // All elements have completed before the block continues, even when the
    // result is unused. Without a timeout every element's result is known.
    if (!adaptor.getTimeout() || op.getResult().use_empty()) {
      rendezvous();
      results.assign(ptrs.size(), b.true_val());
    } else if (op->hasAttr("allocation.offset")) {
      // Reuse the existing atomic result transport for physical replicas.
      if (isa<RankedTensorType>(op.getType())) {
        for (Value &result : results)
          result = b.zext(i8_ty, result);
        results = broadcastTensorResult(op, rewriter, results, threadPred,
                                        targetInfo);
        for (Value &result : results)
          result = b.trunc(i1_ty, result, LLVM::IntegerOverflowFlags::nuw);
        if (numCTAs != 1 && !atomicResultHasCTABroadcast(op))
          rendezvous();
      } else {
        results.front() = broadcastScalarResult(op, results.front(), rewriter,
                                                threadPred, targetInfo);
      }
    } else {
      rendezvous();
    }

    rewriter.replaceOp(op, packUniqueTensorElements(loc, getTypeConverter(),
                                                    results, rewriter,
                                                    op.getType()));
    return success();
  }

private:
  // Emit the polling state machine for one logical element. Both successful
  // and timed-out polls use this path regardless of the input's shape.
  Value emitPoll(triton::AtomicPollOp op, Value ptr, Value expected,
                 Value start, Value timeout, Value threadPred,
                 ConversionPatternRewriter &rewriter) const {
    auto loc = op.getLoc();
    auto b = TritonLLVMOpBuilder(loc, rewriter);
    StringRef syncScope = targetInfo.getAtomicSyncScope(op.getScope());

    Block *currentBlock = rewriter.getInsertionBlock();
    Block *doneBlock = currentBlock->splitBlock(rewriter.getInsertionPoint());
    Region *region = currentBlock->getParent();
    Block *pollLoopBlock =
        rewriter.createBlock(region, Region::iterator(doneBlock));
    Block *pollSuccessBlock =
        rewriter.createBlock(region, Region::iterator(doneBlock));
    Block *timeoutCheckBlock =
        timeout ? rewriter.createBlock(region, Region::iterator(doneBlock))
                : nullptr;
    BlockArgument matched = doneBlock->addArgument(i1_ty, loc);

    rewriter.setInsertionPointToEnd(currentBlock);
    LLVM::BrOp::create(rewriter, loc, ValueRange{}, pollLoopBlock);

    rewriter.setInsertionPointToEnd(pollLoopBlock);
    Value loaded = targetInfo.loadRelaxed(
        rewriter, loc, ptr, expected.getType(), threadPred, op.getScope());
    // Inactive replicas leave the loop without accessing memory. Use select
    // so their unspecified load result cannot affect the loop condition.
    Value pollMatched = b.icmp_eq(loaded, expected);
    pollMatched = b.select(threadPred, pollMatched, b.true_val());
    if (timeout) {
      LLVM::CondBrOp::create(rewriter, loc, pollMatched, pollSuccessBlock,
                             timeoutCheckBlock);

      rewriter.setInsertionPointToEnd(timeoutCheckBlock);
      Value elapsed = b.sub(targetInfo.getGlobalTimer(rewriter, loc), start);
      Value timedOut = b.icmp_uge(elapsed, timeout);
      LLVM::CondBrOp::create(rewriter, loc, timedOut, doneBlock,
                             ValueRange{b.false_val()}, pollLoopBlock,
                             ValueRange{});
    } else {
      LLVM::CondBrOp::create(rewriter, loc, pollMatched, pollSuccessBlock,
                             pollLoopBlock);
    }

    rewriter.setInsertionPointToEnd(pollSuccessBlock);
    if (op.getSem() == triton::MemSemantic::ACQUIRE)
      LLVM::FenceOp::create(rewriter, loc, LLVM::AtomicOrdering::acquire,
                            syncScope);
    LLVM::BrOp::create(rewriter, loc, ValueRange{threadPred}, doneBlock);
    rewriter.setInsertionPointToStart(doneBlock);
    return matched;
  }

  const TargetInfoBase &targetInfo;
};

struct AtomicLoadOpConversion
    : public ConvertOpToLLVMPattern<triton::AtomicLoadOp> {
  AtomicLoadOpConversion(LLVMTypeConverter &converter,
                         const TargetInfoBase &targetInfo,
                         ModuleAxisInfoAnalysis &axisInfoAnalysis,
                         PatternBenefit benefit)
      : ConvertOpToLLVMPattern<triton::AtomicLoadOp>(converter, benefit),
        targetInfo(targetInfo), axisInfoAnalysis(axisInfoAnalysis) {}

  LogicalResult
  matchAndRewrite(triton::AtomicLoadOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    auto loc = op.getLoc();
    auto sem = op.getSem();
    insertAtomicOrderingBarriers(op, sem, rewriter, targetInfo);

    StringRef syncScope = targetInfo.getAtomicSyncScope(op.getScope());
    auto ptrElements =
        unpackUniqueTensorElements(loc, adaptor.getPtr(), rewriter);
    SmallVector<Value> maskElements;
    if (adaptor.getMask())
      maskElements =
          unpackUniqueTensorElements(loc, adaptor.getMask(), rewriter);
    auto resultTy = op.getResult().getType();
    Type valueElemTy =
        getTypeConverter()->convertType(getElementTypeOrSelf(resultTy));
    auto freeVarMasks = getFreeVariableMasks(op.getPtr().getType());
    Value threadPred =
        ttg::emitMemoryThreadPredicate(op, freeVarMasks, rewriter, targetInfo);
    SmallVector<Value> resultVals;
    resultVals.reserve(ptrElements.size());

    unsigned vec = getAtomicLoadStoreVectorSize(op.getPtr(), op.getMask(),
                                                axisInfoAnalysis, targetInfo);
    Type loadTy = vec == 1 ? valueElemTy : vec_ty(valueElemTy, vec);
    for (size_t i = 0; i < ptrElements.size(); i += vec) {
      Value pred =
          maskElements.empty()
              ? threadPred
              : ttg::maybeAnd(rewriter, loc, threadPred, maskElements[i]);
      Value loaded = targetInfo.loadRelaxed(rewriter, loc, ptrElements[i],
                                            loadTy, pred, op.getScope());
      auto values = unpackLLVector(loc, loaded, rewriter);
      resultVals.append(values.begin(), values.end());
    }

    if (sem == MemSemantic::ACQUIRE)
      LLVM::FenceOp::create(rewriter, loc, LLVM::AtomicOrdering::acquire,
                            syncScope);
    finalizeAtomicResults(op, rewriter, resultVals, threadPred, targetInfo,
                          getTypeConverter());
    return success();
  }

private:
  const TargetInfoBase &targetInfo;
  ModuleAxisInfoAnalysis &axisInfoAnalysis;
};

struct AtomicStoreOpConversion
    : public ConvertOpToLLVMPattern<triton::AtomicStoreOp> {
  AtomicStoreOpConversion(LLVMTypeConverter &converter,
                          const TargetInfoBase &targetInfo,
                          ModuleAxisInfoAnalysis &axisInfoAnalysis,
                          PatternBenefit benefit)
      : ConvertOpToLLVMPattern<triton::AtomicStoreOp>(converter, benefit),
        targetInfo(targetInfo), axisInfoAnalysis(axisInfoAnalysis) {}

  LogicalResult
  matchAndRewrite(triton::AtomicStoreOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override {
    auto loc = op.getLoc();
    insertAtomicOrderingBarriers(op, op.getSem(), rewriter, targetInfo);
    StringRef syncScope = targetInfo.getAtomicSyncScope(op.getScope());
    auto ptrElements =
        unpackUniqueTensorElements(loc, adaptor.getPtr(), rewriter);
    auto valueElements =
        unpackUniqueTensorElements(loc, adaptor.getValue(), rewriter);
    SmallVector<Value> maskElements;
    if (adaptor.getMask())
      maskElements =
          unpackUniqueTensorElements(loc, adaptor.getMask(), rewriter);
    auto freeVarMasks = getFreeVariableMasks(op.getPtr().getType());
    Value threadPred =
        ttg::emitMemoryThreadPredicate(op, freeVarMasks, rewriter, targetInfo);
    if (op.getSem() == MemSemantic::RELEASE)
      LLVM::FenceOp::create(rewriter, loc, LLVM::AtomicOrdering::release,
                            syncScope);

    unsigned vec = getAtomicLoadStoreVectorSize(op.getPtr(), op.getMask(),
                                                axisInfoAnalysis, targetInfo);
    for (size_t i = 0; i < ptrElements.size(); i += vec) {
      Value pred =
          maskElements.empty()
              ? threadPred
              : ttg::maybeAnd(rewriter, loc, threadPred, maskElements[i]);
      Value value =
          vec == 1 ? valueElements[i]
                   : packLLVector(loc, ArrayRef(valueElements).slice(i, vec),
                                  rewriter);
      targetInfo.storeRelaxed(rewriter, loc, ptrElements[i], value, pred,
                              op.getScope());
    }
    rewriter.eraseOp(op);
    return success();
  }

private:
  const TargetInfoBase &targetInfo;
  ModuleAxisInfoAnalysis &axisInfoAnalysis;
};

} // namespace

void mlir::triton::populateMemoryOpToLLVMPatterns(
    LLVMTypeConverter &typeConverter, const TargetInfoBase &targetInfo,
    RewritePatternSet &patterns, ModuleAxisInfoAnalysis &axisInfoAnalysis,
    PatternBenefit benefit) {
  patterns.add<GlobalScratchAllocOpConversion>(typeConverter, targetInfo,
                                               benefit);
  patterns.add<LocalAllocOpConversion>(typeConverter, targetInfo, benefit);
  patterns.add<LocalDeallocOpConversion>(typeConverter, benefit);
  patterns.add<LocalLoadOpConversion>(typeConverter, targetInfo, benefit);
  patterns.add<LocalGatherOpConversion>(typeConverter, targetInfo, benefit);
  patterns.add<LocalScatterOpConversion>(typeConverter, targetInfo, benefit);
  patterns.add<LocalStoreOpConversion>(typeConverter, targetInfo, benefit);
  patterns.add<BarrierOpConversion>(typeConverter, targetInfo, benefit);
  patterns.add<ThreadPredicateOpConversion, ThreadHandoffOpConversion>(
      typeConverter, targetInfo, benefit);
  patterns.add<AtomicLoadOpConversion>(typeConverter, targetInfo,
                                       axisInfoAnalysis, benefit);
  patterns.add<AtomicPollOpConversion>(typeConverter, targetInfo, benefit);
  patterns.add<AtomicStoreOpConversion>(typeConverter, targetInfo,
                                        axisInfoAnalysis, benefit);
}
