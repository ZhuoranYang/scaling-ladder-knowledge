LitGPT developer documentation files.
