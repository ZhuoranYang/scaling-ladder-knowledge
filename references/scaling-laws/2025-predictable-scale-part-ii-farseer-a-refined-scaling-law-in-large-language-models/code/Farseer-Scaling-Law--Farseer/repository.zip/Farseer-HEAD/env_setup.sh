# TODO: torch install
# install python dependency
pip install -e .