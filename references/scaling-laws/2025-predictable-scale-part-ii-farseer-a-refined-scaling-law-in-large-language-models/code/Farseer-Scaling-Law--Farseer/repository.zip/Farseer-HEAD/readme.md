
## News


## 🗓 Coming Soon
- [x] Fitting code
- [x] Paper
- [x] All bpc results
- [ ] Thousands of training logs
- [ ] Checkpoints

## Usage

```bash
cd ipynb; python scaling_law_end2end_fit.py
```

```bash
cd ipynb; python 0205_fit_stable_analysis.py
```

## Raw Data

Primary dataset (\~400+ samples):
`ipynb/data/1222_full.csv`

Bilingual ablation dataset (\~100+ samples):
`ipynb/data/bilingual_full.csv`, `ipynb/data/bilingual_bpc.csv`

