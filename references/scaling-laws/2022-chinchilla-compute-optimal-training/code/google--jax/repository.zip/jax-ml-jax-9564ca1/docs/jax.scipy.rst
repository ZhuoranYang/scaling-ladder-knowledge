``jax.scipy`` module
====================

jax.scipy.cluster
-----------------

.. automodule:: jax.scipy.cluster.vq

.. autosummary::
   :toctree: _autosummary

   vq

jax.scipy.fft
-------------

.. automodule:: jax.scipy.fft

.. autosummary::
  :toctree: _autosummary

   dct
   dctn
   idct
   idctn

jax.scipy.integrate
-------------------

.. automodule:: jax.scipy.integrate

.. autosummary::
  :toctree: _autosummary

   trapezoid

jax.scipy.interpolate
---------------------

.. automodule:: jax.scipy.interpolate

.. autosummary::
  :toctree: _autosummary

   RegularGridInterpolator


jax.scipy.linalg
----------------

.. automodule:: jax.scipy.linalg

.. autosummary::
  :toctree: _autosummary

   block_diag
   cho_factor
   cho_solve
   cholesky
   circulant
   companion
   convolution_matrix
   det
   dft
   eigh
   eigh_tridiagonal
   expm
   expm_frechet
   fiedler
   fiedler_companion
   funm
   hadamard
   helmert
   hessenberg
   hankel
   hilbert
   inv
   invhilbert
   invpascal
   leslie
   lu
   lu_factor
   lu_solve
   pascal
   polar
   qr
   qr_multiply
   rsf2csf
   schur
   solve
   solve_sylvester
   solve_triangular
   sqrtm
   svd
   toeplitz

jax.scipy.ndimage
-----------------

.. automodule:: jax.scipy.ndimage

.. autosummary::
  :toctree: _autosummary

   map_coordinates

jax.scipy.optimize
------------------

.. automodule:: jax.scipy.optimize

.. autosummary::
  :toctree: _autosummary

   minimize
   OptimizeResults

jax.scipy.signal
----------------

.. automodule:: jax.scipy.signal

.. autosummary::
  :toctree: _autosummary

   fftconvolve
   convolve
   convolve2d
   correlate
   correlate2d
   csd
   detrend
   istft
   stft
   welch

jax.scipy.spatial.transform
---------------------------

.. automodule:: jax.scipy.spatial.transform

.. autosummary::
  :toctree: _autosummary

   Rotation
   Slerp

jax.scipy.sparse.linalg
-----------------------

.. automodule:: jax.scipy.sparse.linalg

.. autosummary::
  :toctree: _autosummary

   bicgstab
   cg
   gmres

jax.scipy.special
-----------------

.. automodule:: jax.scipy.special

.. autosummary::
  :toctree: _autosummary

   bernoulli
   beta
   betainc
   betaln
   boxcox
   boxcox1p
   comb
   dawsn
   digamma
   entr
   erf
   erfc
   erfcinv
   erfcx
   erfinv
   exp1
   expi
   expit
   expn
   factorial
   fresnel
   gamma
   gammainc
   gammaincc
   gammainccinv
   gammaincinv
   gammaln
   gammasgn
   hyp1f1
   hyp2f1
   i0
   i0e
   i1
   i1e
   jn
   kl_div
   log_ndtr
   log_softmax
   logit
   loggamma
   logsumexp
   lpmn
   lpmn_values
   multigammaln
   ndtr
   ndtri
   owens_t
   poch
   polygamma
   rel_entr
   sici
   softmax
   spence
   sph_harm_y
   wofz
   xlog1py
   xlogy
   zeta


jax.scipy.stats
---------------

.. automodule:: jax.scipy.stats

.. autosummary::
  :toctree: _autosummary

   mode
   rankdata
   sem

jax.scipy.stats.bernoulli
~~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.bernoulli

.. autosummary::
  :toctree: _autosummary

   logpmf
   pmf
   cdf
   ppf

jax.scipy.stats.beta
~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.beta

.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf
   cdf
   logcdf
   sf
   logsf

jax.scipy.stats.betabinom
~~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.betabinom

.. autosummary::
  :toctree: _autosummary

   logpmf
   pmf

jax.scipy.stats.binom
~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.binom

.. autosummary::
  :toctree: _autosummary

   logpmf
   pmf

jax.scipy.stats.cauchy
~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.cauchy

.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf
   cdf
   logcdf
   sf
   logsf
   isf
   ppf

jax.scipy.stats.chi2
~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.chi2

.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf
   cdf
   logcdf
   sf
   logsf


jax.scipy.stats.dirichlet
~~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.dirichlet

.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf

jax.scipy.stats.expon
~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.expon
.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf
   logcdf
   cdf
   logsf
   sf
   ppf

jax.scipy.stats.gamma
~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.gamma
.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf
   cdf
   logcdf
   sf
   logsf

jax.scipy.stats.gumbel_l
~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.gumbel_l
.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf
   cdf
   logcdf
   sf
   logsf
   ppf

jax.scipy.stats.gumbel_r
~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.gumbel_r
.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf
   cdf
   logcdf
   sf
   logsf
   ppf

jax.scipy.stats.gennorm
~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.gennorm
.. autosummary::
  :toctree: _autosummary

   cdf
   logpdf
   pdf

jax.scipy.stats.geom
~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.geom

.. autosummary::
  :toctree: _autosummary

   logpmf
   pmf

jax.scipy.stats.laplace
~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.laplace
.. autosummary::
  :toctree: _autosummary

   cdf
   logpdf
   pdf

jax.scipy.stats.logistic
~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.logistic
.. autosummary::
  :toctree: _autosummary

   cdf
   isf
   logpdf
   pdf
   ppf
   sf

jax.scipy.stats.multinomial
~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.multinomial
.. autosummary::
  :toctree: _autosummary

   logpmf
   pmf

jax.scipy.stats.multivariate_normal
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.multivariate_normal
.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf

jax.scipy.stats.nbinom
~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.nbinom

.. autosummary::
  :toctree: _autosummary

   logpmf
   pmf

jax.scipy.stats.norm
~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.norm
.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf
   cdf
   logcdf
   ppf
   sf
   logsf
   isf

jax.scipy.stats.pareto
~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.pareto
.. autosummary::
  :toctree: _autosummary

   logcdf
   logpdf
   logsf
   cdf
   pdf
   ppf
   sf

jax.scipy.stats.poisson
~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.poisson
.. autosummary::
  :toctree: _autosummary

   logpmf
   pmf
   cdf
   entropy

jax.scipy.stats.t
~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.t
.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf

jax.scipy.stats.truncnorm
~~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.truncnorm
.. autosummary::
  :toctree: _autosummary

   cdf
   logcdf
   logpdf
   logsf
   pdf
   sf

jax.scipy.stats.uniform
~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.uniform
.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf
   cdf
   ppf

jax.scipy.stats.gaussian_kde
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. currentmodule:: jax.scipy.stats
.. autosummary::
  :toctree: _autosummary

   gaussian_kde
   gaussian_kde.evaluate
   gaussian_kde.integrate_gaussian
   gaussian_kde.integrate_box_1d
   gaussian_kde.integrate_kde
   gaussian_kde.resample
   gaussian_kde.pdf
   gaussian_kde.logpdf

jax.scipy.stats.vonmises
~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.vonmises
.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf

jax.scipy.stats.wrapcauchy
~~~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: jax.scipy.stats.wrapcauchy
.. autosummary::
  :toctree: _autosummary

   logpdf
   pdf
