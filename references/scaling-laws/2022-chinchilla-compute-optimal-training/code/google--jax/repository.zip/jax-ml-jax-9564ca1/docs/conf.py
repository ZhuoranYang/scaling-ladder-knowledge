# Copyright 2018 The JAX Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# -*- coding: utf-8 -*-
#
# Configuration file for the Sphinx documentation builder.
#
# This file does only contain a selection of the most common options. For a
# full list see the documentation:
# http://www.sphinx-doc.org/en/master/config

# -- Path setup --------------------------------------------------------------

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.
#
import inspect
import operator
import os
from pathlib import Path
import sys
from typing import ForwardRef
import urllib.request

sys.path.insert(0, os.path.abspath('..'))

# Workaround to avoid expanding type aliases. See:
# https://github.com/sphinx-doc/sphinx/issues/6518#issuecomment-589613836

def _do_not_evaluate_in_jax(
    self, globalns, *args, _evaluate=ForwardRef._evaluate, **kwargs,
):
  if globalns.get('__name__', '').startswith('jax'):
    return self
  return _evaluate(self, globalns, *args, **kwargs)

ForwardRef._evaluate = _do_not_evaluate_in_jax

# -- Project information -----------------------------------------------------

project = 'JAX'
copyright = '2024, The JAX Authors'
author = 'The JAX authors'

# The short X.Y version
version = ''
# The full version, including alpha/beta/rc tags
release = ''


# -- General configuration ---------------------------------------------------

# If your documentation needs a minimal Sphinx version, state it here.
#
needs_sphinx = '2.1'

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
sys.path.append(os.path.abspath('sphinxext'))
extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.autosummary',
    'sphinx.ext.intersphinx',
    'sphinx.ext.linkcode',
    'sphinx.ext.mathjax',
    'sphinx.ext.napoleon',
    'matplotlib.sphinxext.plot_directive',
    'myst_nb',
    'sphinx_remove_toctrees',
    'sphinx_copybutton',
    'jax_extensions',
    'jax_list_config_options',
    'sphinx_design',
    'sphinxext.rediraffe',
    'source_include',
    'sphinxcontrib.mermaid'
]

# Define local cache paths
cache_dir = os.path.join(os.path.dirname(__file__), 'intersphinx_cache')

intersphinx_mapping = {
    'array_api': ('https://data-apis.org/array-api/2023.12/', (os.path.join(cache_dir, 'array_api.inv'), None)),
    'python': ('https://docs.python.org/3/', (os.path.join(cache_dir, 'python.inv'), None)),
    'numpy': ('https://numpy.org/doc/stable/', (os.path.join(cache_dir, 'numpy.inv'), None)),
    # TODO(phawkins,jakevdp): revert to stable scipy docs when it is up again.
    'scipy': ('https://scipy.github.io/devdocs/', (os.path.join(cache_dir, 'scipy.inv'), None)),
}

os.makedirs(cache_dir, exist_ok=True)
for name, (url, (inv_path, _)) in intersphinx_mapping.items():
  if not os.path.exists(inv_path):
    print(f"Intersphinx cache miss for '{name}': downloading from {url}...")
    try:
      req = urllib.request.Request(
          url + 'objects.inv',
          headers={'User-Agent': 'Mozilla/5.0 (compatible; JAX-docs/1.0)'},
      )
      with urllib.request.urlopen(req) as resp, open(inv_path, 'wb') as out:
        out.write(resp.read())
    except Exception as e:
      print(f"Warning: failed to download intersphinx inventory for {name}: {e}")
  else:
    print(f"Intersphinx cache hit for '{name}': using local inventory file at {inv_path}")

suppress_warnings = [
    'ref.citation',  # Many duplicated citations in numpy/scipy docstrings.
    'ref.footnote',  # Many unreferenced footnotes in numpy/scipy docstrings
    'myst.header',
    # TODO(jakevdp): remove this suppression once issue is fixed.
    'misc.highlighting_failure', # https://github.com/ipython/ipython/issues/14142
]

# Add any paths that contain templates here, relative to this directory.
templates_path = ['_templates']

# The suffix(es) of source filenames.
# Note: important to list ipynb before md here: we have both md and ipynb
# copies of each notebook, and myst will choose which to convert based on
# the order in the source_suffix list. Notebooks which are not executed have
# outputs stored in ipynb but not in md, so we must convert the ipynb.
source_suffix = ['.rst', '.ipynb', '.md']

# The main toctree document.
main_doc = 'index'

# The language for content autogenerated by Sphinx. Refer to documentation
# for a list of supported languages.
#
# This is also used if you do content translation via gettext catalogs.
# Usually you set "language" from the command line for these cases.
language = 'en'

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = [
    # Sometimes sphinx reads its own outputs as inputs!
    'build/html',
    'build/jupyter_execute',
    'notebooks/README.md',
    'README.md',
    # Ignore markdown source for notebooks; myst-nb builds from the ipynb
    # These are kept in sync using the jupytext pre-commit hook.
    'notebooks/*.md',
    'pallas/quickstart.md',
    'pallas/gpu/quickstart.md',
    'pallas/tpu/quickstart.md',
    'pallas/pipelining.md',
    'pallas/gpu/pipelining.md',
    'pallas/tpu/pipelining.md',
    'pallas/tpu/distributed.md',
    'pallas/tpu/sparse.md',
    'pallas/tpu/matmul.md',
    'pallas/tpu/core_map.md',
    'pallas/tpu/sparsecore.md',
    'pallas/tpu/fuser.md',
    'jep/9407-type-promotion.md',
    'autodidax.md',
    'autodidax2_part1.md',
    'array_refs.md',
    'hijax_custom_derivatives.md',
    'hijax_types.md',
    'parallel.md',
    'ffi.ipynb',
]

# The name of the Pygments (syntax highlighting) style to use.
pygments_style = None


autosummary_generate = True
napolean_use_rtype = False

# mathjax_config = {
#     'TeX': {'equationNumbers': {'autoNumber': 'AMS', 'useLabelIds': True}},
# }

# Additional files needed for generating LaTeX/PDF output:
# latex_additional_files = ['references.bib']

# -- Options for HTML output -------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
#
html_theme = 'sphinx_book_theme'

# Theme options are theme-specific and customize the look and feel of a theme
# further.  For a list of options available for each theme, see the
# documentation.
html_theme_options = {
    'show_toc_level': 2,
    'repository_url': 'https://github.com/jax-ml/jax',
    'use_repository_button': True,     # add a "link to repository" button
    'navigation_with_keys': False,
    'article_header_start': ['toggle-primary-sidebar.html', 'breadcrumbs'],
}

# The name of an image file (relative to this directory) to place at the top
# of the sidebar.
html_logo = '_static/jax_logo_250px.png'

html_favicon = '_static/favicon.png'

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
html_static_path = ['_static']

html_css_files = [
    'style.css',
]

# Custom sidebar templates, must be a dictionary that maps document names
# to template names.
#
# The default sidebars (for documents that don't match any pattern) are
# defined by theme itself.  Builtin themes are using these templates by
# default: ``['localtoc.html', 'relations.html', 'sourcelink.html',
# 'searchbox.html']``.
#
# html_sidebars = {}

# -- Options for myst ----------------------------------------------
myst_heading_anchors = 3  # auto-generate 3 levels of heading anchors
myst_enable_extensions = ['dollarmath']
myst_ref_domains = ["py"]
myst_all_links_external = False
nb_execution_mode = "force"
nb_execution_allow_errors = False
nb_merge_streams = True
nb_execution_show_tb = True

# Notebook cell execution timeout; defaults to 30.
nb_execution_timeout = 100

# List of patterns, relative to source directory, that match notebook
# files that will not be executed.
nb_execution_excludepatterns = [
    # Slow notebook: long time to load tf.ds
    'notebooks/neural_network_with_tfds_data.*',
    # Slow notebook
    'notebooks/Neural_Network_and_Data_Loading.*',
    # Has extra requirements: networkx, pandas, pytorch, tensorflow, etc.
    'jep/9407-type-promotion.*',
    'notebooks/autodiff_remat.*',
    # Example only gives the specific output demonstrated on some platforms
    'notebooks/layout.*',
    # Requires accelerators
    'pallas/quickstart.*',
    'pallas/pipelining.*',
    'pallas/gpu/pipelining.*',
    'pallas/tpu/pipelining.*',
    'pallas/tpu/distributed.*',
    'pallas/tpu/sparse.*',
    'pallas/tpu/matmul.*',
    'pallas/tpu/core_map.*',
    'pallas/tpu/sparsecore.*',
    'pallas/tpu/fuser.*',
    'distributed_data_loading.*',
    'notebooks/cute_dsl_jax.*',
    '401/cute-dsl.*',
]

# -- Options for HTMLHelp output ---------------------------------------------

# Output file base name for HTML help builder.
htmlhelp_basename = 'JAXdoc'


# -- Options for LaTeX output ------------------------------------------------

latex_elements = {
    # The paper size ('letterpaper' or 'a4paper').
    #
    # 'papersize': 'letterpaper',

    # The font size ('10pt', '11pt' or '12pt').
    #
    # 'pointsize': '10pt',

    # Additional stuff for the LaTeX preamble.
    #
    # 'preamble': '',

    # Latex figure (float) alignment
    #
    # 'figure_align': 'htbp',
}

# Grouping the document tree into LaTeX files. List of tuples
# (source start file, target name, title,
#  author, documentclass [howto, manual, or own class]).
latex_documents = [
    (main_doc, 'JAX.tex', 'JAX Documentation',
     'The JAX authors', 'manual'),
]


# -- Options for manual page output ------------------------------------------

# One entry per manual page. List of tuples
# (source start file, name, description, authors, manual section).
man_pages = [
    (main_doc, 'jax', 'JAX Documentation',
     [author], 1)
]


# -- Options for Texinfo output ----------------------------------------------

# Grouping the document tree into Texinfo files. List of tuples
# (source start file, target name, title, author,
#  dir menu entry, description, category)
texinfo_documents = [
    (main_doc, 'JAX', 'JAX Documentation',
     author, 'JAX', 'One line description of project.',
     'Miscellaneous'),
]


# -- Options for Epub output -------------------------------------------------

# Bibliographic Dublin Core info.
epub_title = project

# The unique identifier of the text. This can be a ISBN number
# or the project homepage.
#
# epub_identifier = ''

# A unique identification for the text.
#
# epub_uid = ''

# A list of files that should not be packed into the epub file.
epub_exclude_files = ['search.html']


# -- Extension configuration -------------------------------------------------
# Define prompt text pattern to be removed for copybutton
# See  https://sphinx-copybutton.readthedocs.io/en/latest/use.html#using-regexp-prompt-identifiers
copybutton_prompt_text = r">>> |\.\.\. |\$ |In \[\d*\]: | {2,5}\.\.\.: | {5,8}: "
copybutton_prompt_is_regexp = True

# Tell sphinx autodoc how to render type aliases.
autodoc_typehints = "description"
autodoc_typehints_description_target = "all"
autodoc_type_aliases = {
    'ArrayLike': 'jax.typing.ArrayLike',
    'DTypeLike': 'jax.typing.DTypeLike',
}

# Remove auto-generated API docs from sidebars. They take too long to build.
remove_from_toctrees = ["_autosummary/*"]

# Customize code links via sphinx.ext.linkcode

def linkcode_resolve(domain, info):
  import jax

  if domain != 'py':
    return None
  if not info['module']:
    return None
  if not info['fullname']:
    return None
  if info['module'].split(".")[0] != 'jax':
     return None
  try:
    mod = sys.modules.get(info['module'])
    obj = operator.attrgetter(info['fullname'])(mod)
    if isinstance(obj, property):
        obj = obj.fget
    while hasattr(obj, '__wrapped__'):  # decorated functions
        obj = obj.__wrapped__
    filename = inspect.getsourcefile(obj)
    source, linenum = inspect.getsourcelines(obj)
  except:
    return None
  try:
    filename = Path(filename).relative_to(Path(jax.__file__).parent)
  except ValueError:
    # Source file is not a relative to jax; this must be a re-exported function.
    return None
  lines = f"#L{linenum}-L{linenum + len(source)}" if linenum else ""
  return f"https://github.com/jax-ml/jax/blob/main/jax/{filename}{lines}"

# Generate redirects from deleted files to new sources
rediraffe_redirects = {
  "rank_promotion_warning.rst": "101/rank_promotion_warning.rst",
  "notes.rst": "index.rst",
  "type_promotion.rst": "101/type_promotion.rst",
  "default_dtypes.md": "101/default_dtypes.md",
  "notebooks/host-offloading.ipynb": "201/memory-spaces.md",
  "notebooks/convolutions.ipynb": "101/convolutions.md",
  "custom_pytrees.md": "101/pytrees.md",
  "jax-primitives.md": "601/jax-primitives.md",
  "jaxpr.md": "601/jaxpr.md",
  "jax-101/01-jax-basics.md": "key-concepts.md",
  "jax-101/02-jitting.md": "jit-compilation.md",
  "jax-101/03-vectorization.md": "automatic-vectorization.md",
  "jax-101/04-advanced-autodiff.md": "automatic-differentiation.md",
  "jax-101/05-random-numbers.md": "random-numbers.md",
  "jax-101/05.1-pytrees.md": "pytrees.md",
  "jax-101/06-parallelism.md": "parallel.md",
  "jax-101/07-state.md": "stateful-computations.md",
  "jax-101/08-pjit.rst": "parallel.md",
  "jax-101/index.rst": "jax-101.rst",
  "tutorials.rst": "jax-101.rst",
  "notebooks/external_callbacks.md": "external-callbacks.md",
  "notebooks/How_JAX_primitives_work.md": "601/jax-primitives.md",
  "jax.extend.ffi.rst": "jax.ffi.rst",
  "Custom_Operation_for_GPUs.md": "ffi.md",
  "notebooks/quickstart.md": "quickstart.md",
  "quickstart.md": "notebooks/thinking_in_jax.md",
  "advanced_guide.rst": "advanced_guides.rst",
  "user_guides.rst": "advanced_guides.rst",
  "working_with_pytrees.md": "pytrees.md",
  "notebooks/Distributed_arrays_and_automatic_parallelization.md": "parallel.md",
  "notebooks/explicit-sharding.md": "parallel.md",
  "sharded-computation.md": "parallel.md",
  "new_docs/101/arrays.md": "101/arrays.md",
  "new_docs/101/errors.rst": "101/errors.rst",
  "new_docs/101/index.rst": "101/index.rst",
  "new_docs/101/pytrees.md": "101/pytrees.md",
  "new_docs/101/random.md": "101/random.md",
  "new_docs/101/state.md": "101/state.md",
  "new_docs/101/transformations.md": "101/transformations.md",
  "new_docs/201/aot.md": "201/aot.md",
  "new_docs/201/callbacks.md": "201/callbacks.md",
  "new_docs/201/control-flow.md": "201/control-flow.md",
  "new_docs/201/controlling-xla.md": "201/controlling-xla.md",
  "new_docs/201/debugging.md": "201/debugging.md",
  "new_docs/201/gpu-memory.md": "201/gpu-memory.md",
  "new_docs/201/index.rst": "201/index.rst",
  "new_docs/201/jit.md": "201/jit.md",
  "new_docs/201/placement.md": "201/placement.md",
  "new_docs/201/precision.md": "201/precision.md",
  "new_docs/201/profiling.md": "201/profiling.md",
  "new_docs/201/shard-map.md": "201/shard-map.md",
  "new_docs/201/sharding.md": "201/sharding.md",
  "new_docs/201/slow-compilation.md": "201/slow-compilation.md",
  "new_docs/301/cookbook.md": "301/cookbook.md",
  "new_docs/301/custom-derivatives.md": "301/custom-derivatives.md",
  "new_docs/301/custom-jvp-vjp.md": "301/custom-jvp-vjp.md",
  "new_docs/301/hijax-types.md": "301/hijax-types.md",
  "new_docs/301/index.rst": "301/index.rst",
  "new_docs/301/refs.md": "301/refs.md",
  "new_docs/301/remat.md": "301/remat.md",
  "new_docs/301/sharding-ad.md": "301/sharding-ad.md",
  "new_docs/301/vjp-objects.md": "301/vjp-objects.md",
  "new_docs/401/cute-dsl.md": "401/cute-dsl.md",
  "new_docs/401/ffi.md": "401/ffi.md",
  "new_docs/401/index.rst": "401/index.rst",
  "new_docs/401/pallas.md": "401/pallas.md",
  "new_docs/501/compilation-cache.md": "501/compilation-cache.md",
  "new_docs/501/data-loading.md": "501/data-loading.md",
  "new_docs/501/export.md": "501/export.md",
  "new_docs/501/fault-tolerance.rst": "501/fault-tolerance.rst",
  "new_docs/501/index.rst": "501/index.rst",
  "new_docs/501/multiprocess.md": "501/multiprocess.md",
  "new_docs/501/security.md": "501/security.md",
  "new_docs/501/shape-polymorphism.md": "501/shape-polymorphism.md",
  "new_docs/501/transfer-guard.rst": "501/transfer-guard.rst",
  "new_docs/index.rst": "index.rst",
}

from jupyter_client.provisioning import KernelProvisionerFactory
from importlib.metadata import EntryPoint

KernelProvisionerFactory.provisioners["portpicker-provisioner"] = EntryPoint(
    name="portpicker-provisioner",
    value="jax_portpicker:PortpickerProvisioner",
    group="jupyter_client.kernel_provisioners"
)
KernelProvisionerFactory.default_provisioner_name = "portpicker-provisioner"


# -- Superseded-page banner ---------------------------------------------------
# Pages replaced by the leveled docs (101-501) stay at their original URLs but
# carry a banner pointing at their replacement. Keys are docnames; values are
# the replacement docname (linked in the banner).
_superseded_pages = {
    'jax-101': '101/index',
    'key-concepts': '101/index',
    'notebooks/thinking_in_jax': '101/index',
    'beginner_guide': '101/index',
    'jit-compilation': '201/jit',
    'automatic-vectorization': '101/transformations',
    'automatic-differentiation': '101/transformations',
    'pytrees': '101/pytrees',
    'random-numbers': '101/random',
    'parallel': '201/sharding',
    'control-flow': '201/control-flow',
    'tracing': '101/transformations',
    'stateful-computations': '101/state',
    'notebooks/shard_map': '201/shard-map',
    'notebooks/layout': '201/sharding',
    'multi_process': '501/multiprocess',
    'fault_tolerance': '501/fault-tolerance',
    'security': '501/security',
    'distributed_data_loading': '501/data-loading',
    'notebooks/autodiff_cookbook': '301/cookbook',
    'notebooks/autodiff_remat': '301/remat',
    'advanced_autodiff': '301/index',
    'higher-order': '301/cookbook',
    'jacobian-vector-products': '301/cookbook',
    'complex-differentiation': '301/cookbook',
    'notebooks/Custom_derivative_rules_for_Python_code': '301/custom-jvp-vjp',
    'hijax_custom_derivatives': '301/custom-derivatives',
    'hijax_types': '301/hijax-types',
    'debugging': '201/debugging',
    'debugging/index': '201/debugging',
    'debugging/checkify_guide': '201/debugging',
    'debugging/flags': '201/debugging',
    'debugging/print_breakpoint': '201/debugging',
    'debugging/slow_tracing_compilation': '201/slow-compilation',
    'debugging/xla_metadata': '201/controlling-xla',
    'transfer_guard': '501/transfer-guard',
    'persistent_compilation_cache': '501/compilation-cache',
    'buffer_donation': '201/jit',
    'benchmarking': '201/profiling',
    'profiling': '201/profiling',
    'device_memory_profiling': '201/profiling',
    'array_refs': '101/state',
    'external-callbacks': '201/callbacks',
    'ffi': '401/ffi',
    'notebooks/cute_dsl_jax': '401/cute-dsl',
    'gradient-checkpointing': '301/remat',
    'aot': '201/aot',
    'export/index': '501/export',
    'export/export': '501/export',
    'export/shape_poly': '501/shape-polymorphism',
    'xla_flags': '201/controlling-xla',
    'async_dispatch': '201/jit',
    'concurrency': '501/index',
    'gpu_memory_allocation': '201/gpu-memory',
    'errors': '101/errors',
    'export/jax2tf': '501/export',
    'notebooks/neural_network_with_tfds_data': '101/index',
    'notebooks/Neural_Network_and_Data_Loading': '101/index',
    'notebooks/vmapped_log_probs': '101/transformations',
}


def _superseded_banner(app, pagename, templatename, context, doctree):
    target = _superseded_pages.get(pagename)
    if target is not None:
        depth = pagename.count('/')
        context['superseded_target'] = '../' * depth + target + '.html'


def setup(app):
    app.connect('html-page-context', _superseded_banner)
