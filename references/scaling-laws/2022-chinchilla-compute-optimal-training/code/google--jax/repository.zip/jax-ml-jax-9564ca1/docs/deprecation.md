(version-support-policy)=
# Python and NumPy version support policy

<!--* freshness: { reviewed: '2024-05-02' } *-->

For NumPy and SciPy version support, JAX follows the Python scientific community's
[SPEC 0](https://scientific-python.org/specs/spec-0000/).

For Python version support, we have heard from users that a 36-month support window can
be too short, for example due to the delays in propagation of new CPython releases
to Linux vendor releases. For this reason JAX supports Python versions for at least
nine months longer than SPEC-0 recommends.

This means we support at least:

* All Python feature releases in the 45 months prior to each JAX release. For example:

  * **Python 3.12** was released October 2023, and will be supported in new JAX releases at least until **July 2027**.
  * **Python 3.13** was released October 2024, and will be supported in new JAX releases at least until **July 2028**.
  * **Python 3.14** was released October 2025, and will be supported in new JAX releases at least until **July 2029**.
  * **Python 3.15** will be released October 2026, and will be supported in new JAX releases at least until **July 2030**.

* All NumPy feature releases in the 24 months prior to each JAX release. For example:

  * **NumPy 2.2** was released December 2024, and will be supported in new JAX releases at least until **December 2026**.
  * **NumPy 2.3** was released June 2025, and will be supported in new JAX releases at least until **June 2027**.
  * **NumPy 2.4** was released December 2025, and will be supported in new JAX releases at least until **December 2027**.
  * **NumPy 2.5** was released June 2026, and will be supported in new JAX releases at least until **June 2028**.

* All SciPy feature releases in the 24 months prior to each JAX release. For example:

  * **SciPy 1.15** was released January 2025, and will be supported in new JAX releases at least until **January 2027**.
  * **SciPy 1.16** was released June 2025, and will be supported in new JAX releases at least until **June 2027**.
  * **SciPy 1.17** was released January 2026, and will be supported in new JAX releases at least until **January 2028**.
  * **SciPy 1.18** was released June 2026, and will be supported in new JAX releases at least until **June 2028**.

JAX releases may support older versions of Python, NumPy, and SciPy than strictly required
by this policy, but support for older versions may be dropped at any time beyond the listed
dates.
