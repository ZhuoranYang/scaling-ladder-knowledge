try:
    import torch
    from transformers import pipeline
except ImportError:
    # No installation required if not using this function
    pass

from nlpaug.model.lang_models import LanguageModels


class FmTransformers(LanguageModels):
    def __init__(self, model_path='bert-base-uncased', model_type='bert', top_k=None, device='cuda', 
        max_length=300, batch_size=32, silence=True):
        super().__init__(device, model_type=model_type, top_k=top_k, silence=silence)
        try:
            from transformers import pipeline
        except ModuleNotFoundError:
            raise ModuleNotFoundError('Missed transformers library. Install transfomers by `pip install transformers`')

        self.max_length = max_length
        self.batch_size = batch_size
        self.model_path = model_path
        device = self.convert_device(device)
        top_k = top_k if top_k else 5

        self.model = self._load_with_optional_silence(
            lambda: pipeline("fill-mask", model=model_path, device=device, top_k=top_k),
            silence=silence,
        )

    def to(self, device):
        self.model.model.to(device)

    def get_device(self):
        return str(self.model.device)

    def get_tokenizer(self):
        return self.model.tokenizer

    def get_model(self):
        return self.model.model

    def get_max_num_token(self):
        return self.model.model.config.max_position_embeddings - 2 * 5

    def is_skip_candidate(self, candidate):
        return candidate.startswith(self.get_subword_prefix())

    def predict(self, texts, target_words=None, n=1):
        results = []

        predict_results = []
        with torch.no_grad():
            for i in range(0, len(texts), self.batch_size):
                # Issue #330: num_workers=1 spawns DataLoader workers which crash
                # on macOS (RuntimeError: DataLoader worker exited unexpectedly).
                # Use single-process loading.
                predict_result = self.model(texts[i:i+self.batch_size], num_workers=0)
                if isinstance(predict_result, list) and len(predict_result) > 0:
                    if isinstance(predict_result[0], list):
                        predict_results.extend(predict_result)
                    else:
                        predict_results.extend([predict_result])

        for result in predict_results:
            temp_results = []
            for r in result:
                token = r['token_str']
                if self.model_type in ['bert'] and token.startswith('##'):
                    continue
                # subword came without space for roberta but not normal subowrd prefix
                if self.model_type in ['roberta', 'bart', 'xlm-roberta'] and not token.startswith(' '):
                    continue

                temp_results.append(token)

            results.append(temp_results)
    
        return results
