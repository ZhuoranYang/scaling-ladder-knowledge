try:
    import torch
    from transformers import AutoModelForMaskedLM, AutoTokenizer
except ImportError:
    # No installation required if not using this function
    pass

from nlpaug.model.lang_models import LanguageModels
from nlpaug.util.selection.filtering import *


class Roberta(LanguageModels):
    # https://arxiv.org/pdf/1907.11692.pdf
    START_TOKEN = '<s>'
    SEPARATOR_TOKEN = '</s>'
    MASK_TOKEN = '<mask>'
    PAD_TOKEN = '<pad>'
    UNKNOWN_TOKEN = '<unk>'
    SUBWORD_PREFIX = 'Ġ'

    def __init__(self, model_path='roberta-base', temperature=1.0, top_k=None, top_p=None, batch_size=32, 
        device='cuda', silence=True):
        super().__init__(device, temperature=temperature, top_k=top_k, top_p=top_p, batch_size=batch_size, silence=True)
        try:
            from transformers import AutoModelForMaskedLM, AutoTokenizer
        except ModuleNotFoundError:
            raise ModuleNotFoundError('Missed transformers library. Install transfomers by `pip install transformers`')
            
        self.model_path = model_path

        self.tokenizer = AutoTokenizer.from_pretrained(model_path)
        self.mask_id = self.token2id(self.MASK_TOKEN)
        self.pad_id = self.token2id(self.PAD_TOKEN)
        self.model = self._load_with_optional_silence(
            lambda: AutoModelForMaskedLM.from_pretrained(model_path),
            silence=silence,
        )

        self.model.to(self.device)
        self.model.eval()

    def get_max_num_token(self):
        return self.model.config.max_position_embeddings - 2 * 5

    def get_model(self):
        return self.model

    def get_tokenizer(self):
        return self.tokenizer

    def get_subword_prefix(self):
        return self.SUBWORD_PREFIX

    def get_mask_token(self):
        return self.MASK_TOKEN

    def predict(self, texts, target_words=None, n=1):
        results = []
        # Prepare inputs
        for start in range(0, len(texts), self.batch_size):
            batch_texts = texts[start:start+self.batch_size]
            batch_target_words = (
                target_words[start:start+self.batch_size] if target_words is not None
                else [None] * len(batch_texts)
            )
            encoded = self._encode_batch(batch_texts, padding=True, truncation=False, return_tensors='pt')
            target_poses = []
            for tokens in encoded['input_ids'].tolist():
                target_poses.append(tokens.index(self.mask_id))
            batch = self._batch_to_device(encoded)

            # Prediction
            with torch.no_grad():
                outputs = self.model(**batch)
            logits = self._model_logits(outputs)

            # Selection
            for output, target_pos, target_token in zip(logits, target_poses, batch_target_words):
                target_token_logits = output[target_pos]

                seed = {'temperature': self.temperature, 'top_k': self.top_k, 'top_p': self.top_p}
                target_token_logits = self.control_randomness(target_token_logits, seed)
                target_token_logits, target_token_idxes = self.filtering(target_token_logits, seed)
                if len(target_token_idxes) != 0:
                    new_tokens = self.pick(target_token_logits, target_token_idxes, target_word=target_token, n=10)
                    results.append([t[0] for t in new_tokens if self.get_subword_prefix() in t[0]])
                else:
                    results.append([''])

        return results
