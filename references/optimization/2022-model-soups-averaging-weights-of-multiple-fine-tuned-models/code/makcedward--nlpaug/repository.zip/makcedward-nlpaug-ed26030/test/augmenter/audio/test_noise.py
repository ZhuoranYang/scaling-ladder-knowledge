import unittest
import os
import numpy as np
from dotenv import load_dotenv

import nlpaug.augmenter.audio as naa
from nlpaug.util import AudioLoader


class TestNoise(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        env_config_path = os.path.abspath(os.path.join(
            os.path.dirname(__file__), '..', '..', '..', '.env'))
        load_dotenv(env_config_path)
        # https://freewavesamples.com/yamaha-v50-rock-beat-120-bpm
        cls.sample_wav_file = os.path.join(
            os.environ.get("TEST_DIR"), 'res', 'audio', 'Yamaha-V50-Rock-Beat-120bpm.wav'
        )
        # https://en.wikipedia.org/wiki/Colors_of_noise
        cls.noise_wav_file = os.path.join(
            os.environ.get("TEST_DIR"), 'res', 'audio', 'Pink_noise.ogg'
        )
        cls.audio, cls.sampling_rate = AudioLoader.load_audio(cls.sample_wav_file)
        cls.noise, cls.noise_sampling_rate = AudioLoader.load_audio(cls.noise_wav_file)

    def test_empty_input(self):
        audio = np.array([])
        aug = naa.NoiseAug()
        augmented_data = aug.augment(audio)

        self.assertTrue(np.array_equal(audio, augmented_data))

    def test_substitute(self):
        aug = naa.NoiseAug()
        augmented_data = aug.augment(self.audio)
        augmented_audio = augmented_data[0]

        self.assertFalse(np.array_equal(self.audio, augmented_audio))
        self.assertTrue(len(self.audio), len(augmented_audio))
        self.assertTrue(self.sampling_rate > 0)

    def test_color_noise(self):
        colors = naa.NoiseAug().model.COLOR_NOISES

        for color in colors:
            aug = naa.NoiseAug(color=color)
            augmented_data = aug.augment(self.audio)
            augmented_audio = augmented_data[0]

            self.assertFalse(np.array_equal(self.audio, augmented_audio))
            self.assertTrue(len(self.audio), len(augmented_audio))
            self.assertTrue(self.sampling_rate > 0)

    def test_background_noise(self):
        # noise > audio
        aug = naa.NoiseAug(noises=[self.noise])
        augmented_data = aug.augment(self.audio)
        augmented_audio = augmented_data[0]
        self.assertTrue(augmented_audio is not None)

    def test_target_snr(self):
        signal = np.linspace(-1.0, 1.0, 1000, dtype=np.float64)
        noise = np.ones_like(signal)
        aug = naa.NoiseAug(
            zone=(0, 1), coverage=1, noises=[noise], snr_db=20
        )

        augmented = aug.augment(signal)[0]
        injected_noise = augmented - signal
        measured_snr = 20 * np.log10(
            np.sqrt(np.mean(signal ** 2))
            / np.sqrt(np.mean(injected_noise ** 2))
        )

        self.assertAlmostEqual(measured_snr, 20, places=10)

    def test_negative_target_snr_makes_noise_louder_than_signal(self):
        signal = np.linspace(-1.0, 1.0, 1000, dtype=np.float64)
        noise = np.ones_like(signal)

        scaled_noise = naa.NoiseAug().model.scale_noise(signal, noise, snr_db=-6)
        measured_snr = 20 * np.log10(
            np.sqrt(np.mean(signal ** 2))
            / np.sqrt(np.mean(scaled_noise ** 2))
        )

        self.assertAlmostEqual(measured_snr, -6, places=10)

    def test_scale_noise_returns_silence_for_zero_energy_inputs(self):
        model = naa.NoiseAug().model
        signal = np.ones(8, dtype=np.float64)
        silence = np.zeros(8, dtype=np.float64)

        np.testing.assert_array_equal(model.scale_noise(silence, signal, 10), silence)
        np.testing.assert_array_equal(model.scale_noise(signal, silence, 10), silence)

    def test_target_snr_only_changes_configured_zone(self):
        signal = np.linspace(1.0, 2.0, 12, dtype=np.float64)
        noise = np.ones(6, dtype=np.float64)
        aug = naa.NoiseAug(zone=(0.25, 0.75), coverage=1, noises=[noise], snr_db=10)

        augmented = aug.augment(signal)[0]

        np.testing.assert_array_equal(augmented[:3], signal[:3])
        np.testing.assert_array_equal(augmented[9:], signal[9:])
        self.assertFalse(np.array_equal(augmented[3:9], signal[3:9]))

    def test_default_noise_amplitude_is_unchanged(self):
        signal = np.ones(8, dtype=np.float64)
        noise = np.full(8, 0.25, dtype=np.float64)
        aug = naa.NoiseAug(zone=(0, 1), coverage=1, noises=[noise])

        np.testing.assert_array_equal(aug.augment(signal)[0], signal + noise)

    def test_invalid_snr(self):
        for snr_db in ['20', np.inf, np.nan]:
            with self.subTest(snr_db=snr_db):
                with self.assertRaises(ValueError):
                    naa.NoiseAug(snr_db=snr_db)

        # audio > noise
        aug = naa.NoiseAug(noises=[self.audio])
        augmented_data = aug.augment(self.audio)
        augmented_audio = augmented_data[0]
        self.assertTrue(augmented_audio is not None)
