# Copyright 2022 MosaicML Composer authors
# SPDX-License-Identifier: Apache-2.0

"""The Composer Version."""

__version__ = '0.33.0.dev0'
