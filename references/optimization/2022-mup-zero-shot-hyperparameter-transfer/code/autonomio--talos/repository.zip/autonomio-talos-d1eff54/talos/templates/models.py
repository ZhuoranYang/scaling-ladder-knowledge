"""Provide legacy model callback examples with lazy framework imports."""


def breast_cancer(x_train, y_train, x_val, y_val, params):

    from tensorflow.keras.layers import Dense, Dropout
    from tensorflow.keras.models import Sequential

    from talos.metrics.keras_metrics import f1score, matthews, precision, recall
    from talos.model import early_stopper, hidden_layers, lr_normalizer

    model = Sequential()
    model.add(Dense(params['first_neuron'],
                    input_dim=x_train.shape[1],
                    activation='relu'))

    model.add(Dropout(params['dropout']))

    hidden_layers(model, params, 1)

    model.add(Dense(1, activation=params['last_activation']))

    model.compile(optimizer=params['optimizer']
                  (learning_rate=lr_normalizer(params['lr'],
                                    params['optimizer'])),
                  loss=params['losses'],
                  metrics=['acc',
                           f1score, recall,
                           precision,
                           matthews])

    results = model.fit(x_train, y_train,
                        batch_size=params['batch_size'],
                        epochs=params['epochs'],
                        verbose=0,
                        validation_data=(x_val, y_val),
                        callbacks=[early_stopper(params['epochs'],
                                                 mode='moderate',
                                                 monitor='val_f1score')])

    return results, model


def cervical_cancer(x_train, y_train, x_val, y_val, params):

    from tensorflow.keras.layers import Dense, Dropout
    from tensorflow.keras.models import Sequential

    from talos.metrics.keras_metrics import f1score, matthews, precision, recall
    from talos.model import early_stopper, hidden_layers, lr_normalizer

    model = Sequential()
    model.add(Dense(params['first_neuron'],
                    input_dim=x_train.shape[1],
                    activation='relu'))

    model.add(Dropout(params['dropout']))

    hidden_layers(model, params, 1)

    model.add(Dense(1, activation=params['last_activation']))

    model.compile(optimizer=params['optimizer']
                  (learning_rate=lr_normalizer(params['lr'],
                                    params['optimizer'])),
                  loss=params['losses'],
                  metrics=['acc',
                           f1score,
                           recall,
                           precision,
                           matthews])

    results = model.fit(x_train, y_train,
                        batch_size=params['batch_size'],
                        epochs=params['epochs'],
                        verbose=0,
                        validation_data=(x_val, y_val),
                        callbacks=[early_stopper(params['epochs'],
                                                 mode='moderate',
                                                 monitor='val_f1score')])

    return results, model


def titanic(x_train, y_train, x_val, y_val, params):

    from tensorflow.keras.layers import Dense, Dropout
    from tensorflow.keras.models import Sequential

    from talos.model import lr_normalizer

    # note how instead of passing the value, we pass a dictionary entry
    model = Sequential()
    model.add(Dense(params['first_neuron'],
                    input_dim=x_train.shape[1],
                    activation='relu'))

    # same here, just passing a dictionary entry
    model.add(Dropout(params['dropout']))

    # again, instead of the activation name, we have a dictionary entry
    model.add(Dense(1, activation=params['last_activation']))

    # here are using a learning rate boundary
    optimizer = params['optimizer']
    if isinstance(optimizer, type):
        optimizer = optimizer(learning_rate=lr_normalizer(params['lr'], optimizer))
    model.compile(optimizer=optimizer,
                  loss=params['losses'],
                  metrics=['acc'])

    # here we are also using the early_stopper function for a callback
    out = model.fit(x=x_train.astype('float32'),
                    y=y_train.astype('float32'),
                    batch_size=params['batch_size'],
                    epochs=params['epochs'],
                    verbose=0,
                    validation_data=(x_val.astype('float32'),
                                     y_val.astype('float32')))

    return out, model


def iris(x_train, y_train, x_val, y_val, params):

    from tensorflow.keras.layers import Dense, Dropout
    from tensorflow.keras.models import Sequential

    from talos.model import early_stopper, hidden_layers, lr_normalizer

    # note how instead of passing the value, we pass a dictionary entry
    model = Sequential()
    model.add(Dense(params['first_neuron'],
                    input_dim=x_train.shape[1],
                    activation='relu'))

    # same here, just passing a dictionary entry
    model.add(Dropout(params['dropout']))

    # with this call we can create any number of hidden layers
    hidden_layers(model, params, x_train.shape[1])

    # again, instead of the activation name, we have a dictionary entry
    model.add(Dense(y_train.shape[1],
                    activation=params['last_activation']))

    # using a learning rate boundary
    model.compile(optimizer=params['optimizer']
                  (learning_rate=lr_normalizer(params['lr'],
                                    params['optimizer'])),
                  loss=params['losses'],
                  metrics=['acc'])

    # here we are also using the early_stopper function for a callback
    out = model.fit(x_train, y_train,
                    batch_size=params['batch_size'],
                    epochs=params['epochs'],
                    verbose=0,
                    validation_data=(x_val, y_val),
                    callbacks=[early_stopper(params['epochs'], mode=[1, 1])])

    return out, model
