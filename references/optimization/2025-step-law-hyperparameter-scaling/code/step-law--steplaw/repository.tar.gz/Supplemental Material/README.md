Supplemental Material For ICDE
