# Model config transforms

A model config transform rewrites a complete model config tree. `build_model_config`
builds the base model before transforms run.

Transforms are one supported way to build and maintain configs. They are
optional, and users may build recipes with their own utilities.

## Using transforms

Set all training options first. Then call `apply_transforms` once.

```python
config = muse_glimmer_30b()
config.parallelism.context_parallel_degree = 8

config = apply_transforms(
    config,
    [
        ContextParallelTransform(
            inner_attention_map={
                FlexInnerAttention: AllGatherKVFlexInnerAttention,
                SlidingWindowFlexInnerAttention: (
                    AllGatherKVSlidingWindowFlexInnerAttention
                ),
            }
        )
    ],
)
```

Common attention and feed-forward configs contain synchronous tensor-parallel
projection roles by default. To overlap those collectives with their adjacent
GEMMs, select the asynchronous implementations with a transform:

```python
config.parallelism.tensor_parallel_degree = 8
config = apply_transforms(
    config,
    [
        AsyncTensorParallelTransform(
            enable_sequence_parallel=config.parallelism.enable_sequence_parallel
        )
    ],
)
```

Without a TP mesh, the synchronous projection classes behave as ordinary
linear modules.

The async TP transform matches projection owner classes exactly. It converts
`ColumnParallelLinear` and `RowParallelLinear`, but leaves arbitrary subclasses
unchanged because replacing one with an async base class would discard its
specialized forward behavior. With sequence parallelism disabled, constructing
the async TP transform is an error before any conversion occurs.

Transforms run on a model config that is already sharded for its parallelism
(`build_model_config(..., parallelism=...)`). A transform that replaces a config
keeps its `sharding_config`, or sets the sharding its replacement needs; it
never re-derives sharding for the whole model.

`apply_transforms` deep-copies the trainer config. It orders and applies the
transforms, then validates the result. It returns the changed copy. The input
config stays unchanged if a transform fails.

Legacy `ModelConfigConverter` instances passed to `build_model_config` run before
all model config transforms. In particular, apply quantization in
`build_model_config` before applying `LoRATransform`; running a converter over a
LoRA-transformed tree can replace an adapter config.

NOTE: With quantization followed by LoRA, LoRA freezes the original weights,
but the current quantized linear implementations still regenerate quantized
weight operands on every forward or FSDP unshard. This is avoidable work for
frozen weights. TODO: Cache their quantized operands across forwards.

Synchronous tensor-parallel boundaries compose with quantization and LoRA.
Their converters replace the projection computation while preserving its
column- or row-parallel role. Async tensor parallelism does not yet support
converted projections; it conflicts with `LoRATransform` and rejects
quantized projection configs.

Use `transform_model_config_` when there is no trainer config. It rewrites the
model config in place and returns the root. It does not copy or validate the
config.

```python
model_config = build_model_config(
    "0.6B", attn_backend="varlen", parallelism=ParallelismConfig()
)
model_config = transform_model_config_(
    model_config, [LoRATransform(handlers=(LinearLoRAHandler(),))]
)
```

## What belongs here

Use `build_model_config` to select the base architecture, attention algorithm, and
attention metadata format. For example, FlexInnerAttention consumes a `BlockMask`,
while VarlenInnerAttention consumes cumulative sequence offsets.

Use a transform for options that replace or wrap configs in the built tree.
Context parallelism, TP GEMM backends, MoE communication backends,
quantization, and LoRA belong in transforms. Quantized modules, tensors, and
kernels live in `torchtitan/quantization`.

A CP transform specializes the selected attention for distributed execution.
It may change input sharding and preprocessing, but it preserves the selected
attention algorithm and metadata format.

Graph-safe varlen K/V all-gather supports contiguous and head-tail sharding.
Set `context_parallel_load_balancer=None` for one varlen call per rank.
Head-tail uses two calls to balance long causal documents. It also works for
sliding-only models because it does not need attention metadata. PTRR is not
supported by these varlen backends.

## Dependency direction

This package may import other `torchtitan` packages. Those packages must not
import this package. Recipes import and apply transforms.

Model config builders temporarily violate this direction while they accept
and apply the legacy `ModelConfigConverter` interface. This dependency will be
removed when converters are
replaced by `ModelConfigTransform`.

Keep shared types outside this package. For example, `CPInnerAttention` lives
with the attention code. Only the transform that installs it belongs here.

## Writing a transform

Subclass `ModelConfigTransform`. Use a keyword-only dataclass for transform options.
Implement `transform`, rewrite configs in place, and return the model root. Return
a different config only when replacing the root.

```python
from dataclasses import dataclass

from torchtitan.config.transform import ModelConfigTransform, TransformRelations
from torchtitan.models.base.module import Module


class ExternalPrerequisiteTransform(ModelConfigTransform):
    def transform(self, model: Module.Config) -> Module.Config:
        return model


@dataclass(kw_only=True, slots=True)
class MyTransform(ModelConfigTransform):
    setting: int

    @classmethod
    def contribute_relations(cls, relations: TransformRelations) -> None:
        relations.add_precedence(
            before=ExternalPrerequisiteTransform,
            after=cls,
        )

    def transform(self, model: Module.Config) -> Module.Config:
        ...
        return model
```

A transform sees only the model config. Pass any value that depends on how the
model runs as a transform option, e.g. `TokenDispatcherTransform`'s
`num_max_tokens_per_rank`, which a trainer derives from its microbatch and an
inference engine from its per-step token budget. `apply_transforms(config, ...)`
works on any config that owns a `model`, such as a trainer or RL generator config.

Use `convert_config_type` to replace one config implementation with another.
The replacement config must inherit from the current config type. This preserves
fields and wrappers from earlier transforms.

## Ordering and conflicts

Relations for built-in TorchTitan transforms that can be safely imported from
`relations.py` are declared there. Transforms that cannot be imported there,
such as transforms that eagerly import optional dependencies or downstream
transforms defined outside TorchTitan, should override `contribute_relations`.
Use `add_precedence(before=A, after=B)` to run `A` before `B`, and use
`add_conflict(A, B)` to reject an incompatible pair.

Each application builds a fresh graph from the central relations and the
selected external transforms. Relations apply to subclasses. Conflict and
ordering checks finish before any transform runs, and only the graph induced by
the selected transforms must be acyclic. Unrelated transforms retain their
input order.

Use config validation, rather than relations, for instance-specific
requirements.

## Validation

See [Configuration validation](../README.md#validation) for where validation
belongs. `apply_transforms` validates the final trainer config after the last
transform. The trainer validates it again after command-line overrides.

`__post_init__` also runs when a config is constructed. Set related training
options before calling `apply_transforms`. It can then validate the final
config.

## TODO

The `model.traverse` logic used in many transforms and config conversion
does not behave nicely with model configs that share the same `Config` object
at different places.
