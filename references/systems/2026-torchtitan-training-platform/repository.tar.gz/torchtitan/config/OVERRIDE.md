# Configurable Override Mechanism

Swap any `Configurable` in a torchtitan training config — a model component,
optimizer, loss, dataloader, and so on — for an alternative implementation
without editing in-repo code, by importing a module that registers an override.
This is the reference for how the mechanism works and how to write overrides.

## Motivation

Torchtitan has a config-driven build system: every component defines a nested
`Config` dataclass and `config.build()` constructs the owning object. Swapping a
component currently works through model config converters and transforms,
which traverse the model config tree and replace `Config` nodes before model
construction.

That works well for in-repo, first-class features, but it requires editing the
repo for *every* alternative implementation. The override mechanism removes that
requirement for three classes of work:

1. **Hardware-specific kernels.** Efficient Triton/CUDA kernels for rotary
   embeddings, fused attention, or custom norms that target specific hardware.
   These are valuable for performance but are (a) hardware-specific, (b) harder
   to maintain, and (c) reasonably held to a lower code-quality bar than core.
   We want to offer vendors a clean extension point rather than either lowering
   the core bar or saying "no".

2. **Larger fused regions.** An efficient MoE may fuse dispatch–compute–combine
   with custom routing, communication, and quantization. This spans several
   `Config` nodes and is best expressed as a single replacement at a higher
   scope (e.g. replace `MoE.Config` wholesale).

3. **Team experimentation.** Trying a non-trivial implementation without
   threading intrusive changes through core, then keeping or discarding it
   cheaply.

### In-repo vs. external

The same mechanism serves both in-repo examples (`torchtitan_recipes/overrides/`) and
external packages, and the decision of where an implementation lives maps onto
the goals above:

- **In-repo (`torchtitan_recipes/overrides/`)** -- illustrative examples and broadly
  useful kernels we are willing to maintain at a lower bar than core. They are
  opt-in and never run unless requested, so they cannot regress default
  behavior.
- **External package** — vendor- or hardware-specific code, or anything we do
  not want to maintain in-tree. It lives in the vendor's namespace and is
  activated by listing its module path.

**Non-goals.** An operator-override API in TorchTitan. To replace or add an op,
use PyTorch's custom-operator path and wrap the op in a `Module` — see
[Custom kernels and `torch.compile`](#custom-kernels-and-torchcompile).
TorchTitan does not provide an op-level override surface.

## Design Overview

Override authors register a factory against a `Configurable.Config` class. After
config construction and before any `build()`, the mechanism traverses the config
tree and replaces matching nodes with the factory's output.

### Core principles

- **Explicit opt-in.** Nothing happens unless the user lists targets in
  `override.imports`. No auto-detection from hardware or installed packages.
- **Strictly scoped to the request.** Each target names exactly one override as
  `module.function` (the module plus the `@override` factory's function name), so
  only the named overrides are applied — never the whole global table. A module
  that defines several overrides is activated by listing each function.
- **Per-instance targeting, per-node conflicts.** An override selects *which*
  matched nodes it claims via `fqns` (FQN globs). Two overrides conflict only
  when they claim the *same node* (or one claims an ancestor of the other's
  node) — not merely the same Config class. So two vendors' norm kernels on
  different layers, or A/B-ing a kernel per layer, compose cleanly; genuine
  collisions error out.
- **Any `Configurable`.** Overrides apply across the entire `Trainer.Config`
  tree — model components, optimizer, loss, dataloader, etc. — not just the
  model.
- **Minimal surface.** The whole mechanism lives in
  `torchtitan/config/override.py`, reusing the `Configurable.Config.traverse()` +
  replace pattern that quantization converters and the LoRA transform already use.

## How It Works

### Registration

An override module defines a replacement and registers a factory with
`@override`:

`TritonRoPE` below is **illustrative** (a compact subclass-adds-one-field
example); no `triton_rope.py` is shipped. It is a valid override: each attention
module owns a `rope` submodule (a `RoPE.Config`), so swapping in a custom RoPE is
an ordinary component override.

```python
from dataclasses import dataclass

from torchtitan.config import derive, override
from torchtitan.models.common.rope import RoPE


class TritonRoPE(RoPE):
    """RoPE applied with a Triton kernel (illustrative)."""

    @dataclass(kw_only=True, slots=True)
    class Config(RoPE.Config):
        block_size: int = 128

    def __init__(self, config: Config): ...
    def forward(self, query, key, positions=None): ...


@override(target=RoPE.Config,
          description="Triton rotary embedding, ~2x faster on A100+")
def triton_rope(cfg: RoPE.Config, *, block_size: int = 128) -> TritonRoPE.Config:
    # `derive` copies every field shared with RoPE.Config; the factory states
    # only its deltas. See "Deriving the replacement config" below. `block_size`
    # defaults to 128 but can be tuned per config tree via a per-entry kwarg
    # (see "Optional per-entry kwargs" below).
    return derive(cfg, TritonRoPE.Config, block_size=block_size)
```

The factory receives the matched config as its first positional argument and
returns its replacement. It may declare keyword parameters (like `block_size`
above) that callers fill via a `(module_path, kwargs)` import entry; a bare
module-path entry uses their defaults. *Which* instances the factory applies to
is controlled declaratively by `fqns` (see
[per-instance targeting](#per-instance-targeting)), not by inspecting fields
inside the factory.

### Deriving the replacement config

Prefer `derive(cfg, NewConfig, **deltas)` over hand-copying each field. It builds
`NewConfig` by copying fields shared by name with `cfg`, applying `deltas` on
top; the factory states only what it actually changes.

This matters for version-robustness. Hand-copying couples a factory to the
target's field set at the time it was written:

```python
# Fragile: RoPE.Config has many fields (theta, scaling, rope_factor, beta_fast,
# ...); hand-copying only some silently drops the rest to their defaults — and a
# field added later would be dropped too, with no error.
return TritonRoPE.Config(
    dim=cfg.dim, max_context_length=cfg.max_context_length,
                         theta=cfg.theta, scaling=cfg.scaling)

# Robust: every RoPE.Config field (including ones added later, inherited by the
# subclass TritonRoPE.Config) is copied automatically; only block_size is a delta.
return derive(cfg, TritonRoPE.Config, block_size=128)
```

Semantics: fields on both `cfg` and `NewConfig` are copied from `cfg`; fields
only on `NewConfig` come from `deltas` (else their declared default); fields only
on `cfg` are dropped; a delta naming a field that doesn't exist on `NewConfig`
raises. Copying is shallow (like `dataclasses.replace`), which is fine because
the matched node is being replaced and detached. `derive` is most valuable when
the replacement subclasses the target (the common drop-in case), where new core
fields are inherited and thus carried over for free.

**Configuration is code.** By default the override module *is* its
configuration: the factory bakes in sensible defaults (above, `block_size=128`),
so a bare `override.imports` entry needs no other input.

**Optional per-entry kwargs.** When two config trees need the *same* override
configured *differently*, a factory can expose keyword parameters and each
`override.imports` entry can supply them as a `(target, kwargs)` tuple instead of
a bare string; the `kwargs` are forwarded to the override the target names.
For `triton_rope` above, two trees can pick different block sizes without a
second module:

```python
# one tree tunes block_size=128 (the default), another 256:
OverrideConfig(imports=["my_pkg.triton_rope.triton_rope"])                       # -> 128
OverrideConfig(imports=[("my_pkg.triton_rope.triton_rope", {"block_size": 256})])
```

The factory declares the keyword parameters it accepts (or `**kwargs`); a kwarg
it does not accept raises rather than silently no-op'ing. On the CLI, attach
kwargs to the target as `target=<json-object>` (quote it as a single shell token;
`my_pkg.triton_rope.triton_rope` is a placeholder for your own override):

```bash
python -m torchtitan.train --module torchtitan_recipes.models.llama3 --config llama3_8b \
    --override 'my_pkg.triton_rope.triton_rope={"block_size": 256}'
```

JSON keeps the values typed (numbers, `null`, strings, nesting), so the same
entry works from Python or the CLI. We still avoid a typed override-`Config`
parsed at config-construction time, which would re-couple the recipe to
the override package and defeat the no-touch goal.

### Activation

```bash
# Replace the torch-native SwiGLU activation with the Triton implementation:
python -m torchtitan.train --module torchtitan_recipes.models.llama3 --config llama3_8b \
    --override torchtitan_recipes.overrides.fused_swiglu.fused_swiglu

# Async tensor-parallel linear subclasses are preserved by the same override:
python -m torchtitan.train --module torchtitan_recipes.tests.models.llama3 --config llama3_debugmodel_dist_gemm \
    --override torchtitan_recipes.overrides.fused_swiglu.fused_swiglu

# A target with per-entry kwargs -- attached as target=<json>, quoted as one
# shell token (my_pkg.triton_rope.triton_rope is a placeholder for your override):
python -m torchtitan.train --module torchtitan_recipes.models.llama3 --config llama3_8b \
    --override 'my_pkg.triton_rope.triton_rope={"block_size": 256}'
```

### Application

In `Trainer.__init__`, before any component is built:

1. Copy the structural model config and set its sharding from the consumer's
   parallelism config.
2. Import each target's module — this triggers its `@override` decorators.
3. Resolve the *active* set: for each `module.function` target, the single
   override that function registers (matched by the factory's defining module and
   its name).
4. Collect claims: traverse the original tree and record every `(override,
   node)` pair, filtered by each override's `fqns` selector.
5. Check for per-node conflicts (two overrides claiming the same node, or one
   claiming an ancestor of another's node).
6. Apply: build each replacement and swap it in. Because claims are gathered
   before any mutation, application is order-independent (replacements are never
   re-traversed). An override that changes a module's sharding contract must set
   the replacement's `sharding_config`; `derive()` preserves it when the contract
   is unchanged.
7. Log every replacement.

```
INFO: [Override] fused_swiglu: model.layers.0.feed_forward DenseFeedForward.Config -> DenseFeedForward.Config
INFO: [Override] fused_swiglu: model.layers.1.feed_forward DenseFeedForward.Config -> DenseFeedForward.Config
...
INFO: Applied 32 override(s)
```

The model config is a `Configurable.Config` nested directly at `model` in the
trainer config. FQNs are kept as full paths from the `Trainer.Config` root, so a
component is `model.layers.0.feed_forward`. An RL `Controller.Config` holds an
`override` field too, applied to its whole tree before actors spawn; there the
same component is both `trainer.model.layers.0.feed_forward` and
`generator.model.layers.0.feed_forward`, so an override changes both models.
Settings that must differ between the RL trainer and generator (for example the
MoE token dispatcher) belong in per-role model config transforms instead. Preserving the full path (rather
than resetting to bare model names) lets per-node conflict detection recognize
a whole-model override as an ancestor of a component override. (This differs
from converter `filter_fqns`, which are bare because converters traverse the
model config directly.)

### External packages

```python
# vendor_x/overrides.py
from torchtitan.config import override
from torchtitan.models.common.moe import MoE


@override(target=MoE.Config,
          description="Vendor X fused MoE for XPU")
def vendor_x_moe(cfg: MoE.Config) -> "VendorXFusedMoE.Config":
    return VendorXFusedMoE.Config(num_experts=cfg.num_experts, ...)
```

```bash
pip install torchtitan-vendor-x
python -m torchtitan.train --module torchtitan_recipes.models.deepseek_v3 --config deepseek_v3_671b \
    --override vendor_x.overrides.vendor_x_moe
```

### Version compatibility

An override depends on the internal `Config` shapes it reads and the modules it
imports, so external packages should:

- **Pin a torchtitan version range** they have validated against. The override
  contract is the public `Configurable.Config` fields of the targets; these can
  change across releases.
- **Align their pytorch-nightly expectation** with the torchtitan version they
  pin, since hardware kernels are typically nightly-sensitive. Document the
  tested torchtitan × pytorch pair in the package.

## Per-instance Targeting

Targeting is first-class, not an afterthought: many motivating cases collide by
design (two vendors with norm kernels, or A/B-ing a kernel per layer). The
`fqns` selector on `@override` says *which* matched nodes an override claims,
declaratively — no field-sniffing inside the factory.

`fqns` is one of:

- `None` (default) — every instance of `target`.
- a list of FQN globs — `fnmatch` style, where `*` also crosses `.`; a node is
  claimed if any glob matches its FQN.

By default, `target` matches instances of the target config class and its
subclasses. If a replacement only implements the concrete target contract, pass
`exact=True` to `@override`; subclass configs are then not claimed, so they are
not logged as replacements and can still be handled by a subclass-specific
override.

The FQN is the full path from the `Trainer.Config` root, e.g. a model component
is `model.layers.0.feed_forward` and the optimizer is `optimizer`.
Globs with `*` (which crosses `.`) keep selectors readable.

```python
# NVFP4 on every in-layer linear, leaving the top-level LM head ("...output")
# untouched (required for NVFP4; useful for MXFP8)
@override(target=Linear.Config,
          fqns=["*.layers.*.attention.*", "*.layers.*.feed_forward.*"])
def nvfp4_linear(cfg: Linear.Config) -> "NVFP4Linear.Config":
    return NVFP4Linear.Config(in_features=cfg.in_features, ...)

# Fused MoE only on the later layers
@override(target=MoE.Config, fqns=["*.layers.1[0-9].feed_forward"])
def vendor_moe(cfg: MoE.Config) -> "VendorMoE.Config":
    return VendorMoE.Config(num_experts=cfg.num_experts, ...)
```

`fqns` accepts globs only. A general predicate selector (`(fqn, cfg) -> bool`),
which would also enable field/type-based selection (e.g. "skip already-quantized
linears"), is listed under [Future work](#future-work).

### Per-node conflict detection

Conflicts are detected per *node*, not per *class*. Two overrides may target the
same Config class freely as long as their claimed nodes are disjoint — so one
norm kernel on `*.layers.0.*` and another on `*.layers.1.*` coexist, and A/B-ing
a kernel across layers works. An error is raised only when two different overrides
claim the **same node**, or when one claims an **ancestor** of another's node
(nested replacement, which would be order-dependent). The fix in both cases is
to narrow the `fqns` selectors so the claims are disjoint.

Claims are gathered from the **original** tree before any mutation, and a
replacement is never re-traversed, so application is order-independent — one
override can never silently affect what another matches.

#### Parent- and child-class overrides

This same rule answers the parent/child question directly. Say override A
targets a parent Config (e.g. `MoE.Config`) and override B targets a Config
nested inside it (e.g. `GroupedLinear.Config`):

- **Disjoint subtrees** (A on `...layers.0.feed_forward`, B on
  `...layers.1.feed_forward.routed_experts.w13`) — the claimed nodes are
  unrelated, so both apply.
- **Overlapping** (A on `...layers.0.feed_forward`, B on
  `...layers.0.feed_forward.routed_experts.w13`) — B's node is inside A's, the
  ancestor case above, so we **error**.

We error rather than pick one of the two plausible behaviors implicitly:

1. *Apply the parent, then override a child in the new parent.* Only meaningful
   if A's replacement still exposes a matching child, and it reintroduces
   ordering (parent-before-child) and re-traversal — which we deliberately avoid.
2. *Silently drop the child override* (when A's replacement has a different
   structure with no such child). A silent no-op is exactly the kind of
   surprise that hides bugs.

Because claims are collected on the original tree, we can't even tell at
check time which case a given pair would fall into — so instead of guessing, we
ask the author to disambiguate: narrow `fqns` so the claims are disjoint, or drop
one override (e.g. let the parent override subsume the child).

## Scope: any `Configurable`

Overrides traverse the whole `Trainer.Config`, so the optimizer, loss,
dataloader, and validator configs are overridable too — not only model
components. For example, an emerging or mixed-precision optimizer can be swapped
in by targeting `OptimizersContainer.Config` without editing a recipe
function. The model config itself is a valid target for a whole-model swap
because it is a `Configurable.Config` subclass.

## Interaction with Converters and Transforms

In-repo quantization converters run first inside `build_model_config()` during
config construction. Model config transforms such as LoRA run afterward when
the recipe calls `apply_transforms`. Overrides run later in `Trainer.__init__`
and see the post-converter, post-transform tree. The order is deliberate:
in-repo conversions run against known core configs, and overrides layer on top.

Conversely, converter-style transforms *can* be expressed as overrides (a
factory that rewrites a `Config`), so external code does not need the converter
machinery.

| Override Target | Conflicts with a converter? | Notes |
|-----------------|------------------------------|-------|
| RoPE / DenseFeedForward / MoE / RMSNorm / inner attention | No | Converters don't touch these |
| GroupedLinear.Config | Possibly | Quantization converters can rewrite this |
| Linear.Config | Yes | Quantization and LoRA can replace these |

Where a converter already rewrote a node, target that node by location with
`fqns` so the override only claims the instances you intend (e.g. specific
layers the converter left as plain `Linear.Config`). Field/type-based exclusion
-- "skip instances already turned into a quantized config" -- is not expressible
with FQN globs alone and motivates the future predicate selector.

### Override vs. converter: which to use

Converters are the right home for **core, broadly-applicable transforms that
preserve a property we guarantee** (e.g. batch-invariance, which is largely
op-level and must hold across the model). Overrides exist for an *unblocking*
purpose: swapping in an alternative implementation. By design we make **no
promise that any core property survives an arbitrary override** — that is the
override author's responsibility. So features like batch-invariant mode stay
converters, not overrides.

## Checkpoint Compatibility

An override that changes a module's parameter layout changes its native
checkpoint FQNs. By default an override checkpoints whatever real parameters it
defines. Keep format-specific layout conversion in a model-level
`BaseStateDictAdapter` (for example, `Llama3StateDictAdapter` converts native
`w13.weight` into Hugging Face `gate_proj.weight` and `up_proj.weight`). This
keeps native DCP checkpoints and per-step RL model state dict pushes in the
model's physical layout without hook-produced copies.

## Parallelism

Parallelism is expressed entirely through the `Module` protocol: a replacement
satisfies `init_states` and declares a `ShardingConfig` for the states and
activations it wants sharded. The matched config is already sharded for its
parallelism (`build_model_config(..., parallelism=...)`), so a replacement keeps
the matched `sharding_config` (`derive` copies it) or sets the sharding it needs. `Module._parallelize()` reads that `ShardingConfig`
exactly as it does for core modules, so an override composes with TP/FSDP by
declaring its own sharding — nothing model-specific is required, and the
mechanism deliberately stays config-driven rather than depending on imperative
per-model parallelization code.

One thing worth stating plainly:

- **Fusion under TP.** Fusing weights can interact subtly with tensor
  parallelism -- the fused tensor's row order must admit a correct shard.
  The default `DenseFeedForward` stores a `Linear` weight
  `(2, hidden, dim)`. Sharding dimension 1 gives each TP rank matching feature
  slices of the gate and up projections while keeping their rows in separate
  contiguous slabs. The output retains the same `(2, hidden)` structure. This
  also keeps block-quantization scales from spanning the two projections.

## Custom kernels and `torch.compile`

An override that wraps a custom CUDA or Triton kernel should be registered as a
first-class PyTorch custom operator when it needs to compose with `torch.compile`
or export:

- **`torch.library.custom_op`** — wrap a Python/CUDA-extension kernel as an op
  with a stable schema and a clear functional/mutation contract.
- **`torch.library.triton_op`** — register a Triton-kernel-backed op so the
  kernel is visible to (and traceable by) `torch.compile` rather than a black
  box.
- **fake / meta kernel** (`register_fake`) — a shape/dtype-only implementation
  so tracing, `torch.compile`, and export can propagate metadata without running
  the kernel.
- **autograd registration** (`register_autograd`) — supply the backward so the
  op works in training, not only inference.
- **`torch.library.opcheck`** — test schema / fake / autograd consistency; a
  good unit test to ship in the override package.

The override module then wraps the registered op in its replacement `Module`,
and TorchTitan's mechanism keeps operating purely at the `Configurable` / Module
level. See PyTorch's "Custom Operators" landing page and the Triton-op tutorial
for the full recipe.

## Composability Notes

- **Context parallelism** is applied on the Attention module. An override of the
  attention block (or its inner attention) must remain compatible with that
  application point; this is a composability surface to respect.
- **Agentic / automated search.** Making model impls, optimizers, and kernels
  uniformly swappable at config time is a building block for automated
  hill-climbing over implementations. This mechanism, the GraphTrainer recipes,
  and kernel-fusion prototypes are complementary; keeping the override surface
  small and declarative is what makes programmatic swapping tractable.

## Worked Examples

- `torchtitan_recipes/overrides/fused_swiglu.py` -- **the custom Triton activation
  example.** It replaces the default torch-native SiLU and multiply operations
  while retaining the core `DenseFeedForward` parameter layout and checkpoint
  behavior. Because the override targets `SwiGLU.Config`, it also applies to
  grouped experts and dist-GEMM feed-forwards that use that activation.
- `torchtitan_recipes/overrides/higher_precision_rms_norm.py` -- **a
  higher-precision norm example.** It replaces every exact `RMSNorm.Config`
  (decoder norms and QK norms) with `HigherPrecisionRMSNorm`, which keeps the
  `nn.RMSNorm` parameter layout and accumulates the sum of squares with
  compensated FP32 summation (FP64 with `use_kahan_summation=False`). The Triton
  kernels are registered as `torch.library.custom_op`s with fake and autograd
  registrations. It runs as a local SPMD region typed by the norm's own
  `ShardingConfig`.
The `TritonRoPE` snippets above are illustrative — no `triton_rope.py` is
shipped — but RoPE is a fully valid override target: each attention module owns a
`rope` submodule (`RoPE.Config`), so a custom RoPE is an ordinary component override.

## Code map

| File | Role |
|------|------|
| `torchtitan/config/override.py` | The mechanism: `OverrideConfig`, `Override`, `override`, `derive`, `apply_overrides`, `clear_overrides`. |
| `torchtitan/config/__init__.py` | Re-exports the override API. |
| `torchtitan/models/base/model.py` | `BaseModel` owns the model-level lifecycle and its nested config participates directly in traversal. |
| `torchtitan/trainer.py` | Holds the `override` config field and applies recipe-provided overrides before builds. |
| `torchtitan/rl/controller/controller.py` | Holds the RL `override` field and applies it to the trainer and generator models before spawning actors. |
| `torchtitan_recipes/overrides/` | In-repo example implementations (`fused_swiglu.py`). |
| `tests/unit_tests/cpu/config/test_override.py` | Unit tests: registration, provenance, FQN / exact targeting, per-node conflicts, per-entry kwargs, `derive`. |

Overriding a component requires no changes to a recipe or model package; that
is the point of the design.

## At a Glance

- **Activation.** Explicit opt-in via `override.imports`; only overrides
  registered by the listed modules (provenance-checked) are applied. An entry
  may carry kwargs (a `(module_path, kwargs)` tuple in Python, or
  `module=<json>` on the CLI) to configure the same module differently per
  config tree.
- **Conflicts.** Per-node, not per-class: overrides may share a target class as
  long as their claimed nodes are disjoint; same-node or ancestor/descendant
  claims error.
- **Per-instance targeting.** Via `fqns` (FQN globs) on `@override`; the factory
  is pure construction.
- **Subclass matching.** Targets match subclasses by default; use `exact=True`
  when a replacement only supports the concrete target config.
- **Scope.** Any `Configurable` in the `Trainer.Config` tree.
- **Config construction.** Use `derive(cfg, NewConfig, **deltas)` so factories
  don't silently drop fields added to the target later.
- **Override-specific config.** Via a small custom module; no new config surface.
- **Checkpoint.** Layout-changing overrides can stay stock-interoperable by
  bridging FQNs with `register_state_dict_post_hook` /
  `register_load_state_dict_pre_hook` (see Checkpoint Compatibility).

## Future Work

- **Predicate `fqns` selector.** A `(fqn, cfg) -> bool` selector to complement
  the glob strings, enabling field/type-based selection (e.g. skipping linears a
  converter already turned into a quantized config).
