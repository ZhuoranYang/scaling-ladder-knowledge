# Tests

This directory contains tests for the torchtitan project, including unit tests and integration tests.

## Test Structure

- `unit_tests/cpu/`: Unit tests that run without a GPU
- `unit_tests/gpu/`: Tests that require GPUs; multi-GPU tests use the
  `multi_gpu` pytest marker

  Both mirror the source tree: a test for `torchtitan/<path>/<module>.py` lives
  under `unit_tests/{cpu,gpu}/<path>/` (e.g. `models/common/`,
  `components/data/`, `distributed/flex_shard/`). `recipes/` covers
  `torchtitan_recipes` (overrides and recipe sanity) and `scripts/` covers
  `scripts/`. Tests of the trainer as a whole stay at the top level.
- `rl/unit_tests/cpu/`: RL unit tests that run without a GPU
- `rl/unit_tests/gpu/`: RL tests that require GPUs; multi-GPU tests use the
  `multi_gpu` pytest marker and each runs under its own `torchrun` launch
- `integration_tests/`: End-to-end tests, one module per suite. Each module
  holds the suite's run configurations next to the test definitions that name
  them, so adding a test edits one file.
  - `features.py`: Tests for torchtitan features and composability
  - `models.py`: Tests for model architectures
  - `flux.py`: Tests for the FLUX model (training, then image generation)
  - `h100.py`: Tests cases for H100 GPUs
  - `b200.py`: Test cases that require SM100 or SM103 GPUs
  - `rl.py`: RL end-to-end suites (`rl`, `rl_h100`, `rl_b200`)
  - `run_tests.py`: The runner for every suite
- `assets/`: Contains test assets and fixtures used by the tests
  - `losses/`: Golden loss and gradient norm curves for the numerics guards
  - `tokenizer/`: Tokenizer configuration and vocabulary files for testing
  - `custom_schedule.csv`: Custom PP schedule for testing

## TorchTitan CI Design

### Integration tests (Goal: E2E composability)

#### Principle

Use Fake PG as much as possible on pull requests for fast, broad functional
coverage. Every enabled test runs before landing: tests compatible with Fake PG
use one physical GPU, while tests marked `use_real_pg=True` use eight physical
GPUs. The same complete set of tests runs with Real PG after the PR is merged
into `main`. Scheduled runs also execute the complete suite with Real PG.

#### Cadence

- 1 GPU Fake PG cadence: ready, non-draft pull requests, whether they target
  `main` directly or belong to a ghstack stack.
  - The `.github/labeler.yml` file automatically applies the
    `ciflow/fake-pg` label, and PyTorch Probot manages a
    `ciflow/fake-pg/*` tag that points to the PR head SHA. This allows stacked
    PRs to run independently of their base branch. The tag starts both the
    Fake-PG suite and the Real-PG required subset. Reusable workflow callers
    run only Fake PG by default.
  - Tests that cannot run with Fake PG (`use_real_pg=True`) run with Real PG in
    the separate `required subset - features` and `required subset - models`
    jobs triggered by the same tag.
- 8 GPU Real PG cadence:
  - Pushes and merges to `main` run both full-suite jobs with Real PG.
  - Six-hour schedules and manual dispatches also run both full-suite jobs with
    Real PG.
  - Opt-in trigger during the PR stage: adding the `ciflow/real-pg` pull request
    label creates a `ciflow/real-pg/*` tag and runs separate
    `full suite - features` and `full suite - models` jobs with Real PG.
- H100 cadence: opt-in pull requests carrying the `ciflow/h100.8` label.
  The lane always uses Real PG; updates and reopened events rerun it while the
  label remains attached.
- B200 cadence: opt-in pull requests carrying the `ciflow/b200` label and
  pushes affecting Kimi K3 on `main`. The lane uses Real PG and currently runs
  Kimi K3 multimodal coverage across FSDP, TP, EP, PP, and VPP, plus an
  FSDP+EP numerical regression.

Feature tests provide depth of infrastructure composability. Fake-PG runs check
that feature combinations configure, transform, and complete training, while
Real-PG runs additionally cover real collectives and distributed state. Model
tests provide width across supported implementations. Their definitions remain
separate for clarity. Each 8 GPU Real-PG suite runs as its own CI job with an
independent timeout. The fake-pg job runs the FLUX suite together with
`features,models`; the real-pg models job runs it in a second `run_tests` call,
including when the first failed, and the job still fails if either suite failed.

### Numerics tests (Goal: deterministic regression coverage)

Selected model integration tests also check numerics by setting
`golden_numerics_path`. The runner derives metrics and step count from that file,
creates a seed checkpoint for A10G Real-PG execution, and runs the integration
case through `loss_compare.py`. Fake-PG execution skips seed-checkpoint creation
and uses its fixed initialization path.

- A10G cases run on one physical GPU with Fake PG for pull requests and eight
  physical A10Gs with Real PG after merge, on schedule, or when triggered by
  the `ciflow/real-pg` label. Their golden paths can use `{execution_mode}` to
  select the `fake_pg/` or `real_pg/` directory.
  Shared numerical cases use the same configuration in both modes.
- Fake-PG goldens guard PyTorch FakeProcessGroup's deterministic synthetic
  numerical contract. They do not validate remote-rank values or EP load
  balance.
- Large Fake-PG gradient norms may still be deterministic under that synthetic
  contract. Non-finite gradients are not accepted: training stops before the
  optimizer update. A golden catches changes to finite synthetic values; it
  does not establish that the simulated gradients are numerically
  representative.
- Golden directories identify the PG mode, filenames identify the model and
  hardware tier, and the exact parallelism plan is recorded in the header.
- Qwen3.5 MoE FSDP 4 x TP 2, EP 4 does not have a numerical golden. Its A10G
  Real-PG results are not bitwise deterministic, so the case provides
  end-to-end coverage only.
- DeepSeek V4 FSDP 2 x TP 2, EP 2 is end-to-end coverage only and does
  not have a numerical golden. It runs on a real PG only (`use_real_pg=True`):
  under Fake PG its sequence-parallel collectives return activations that alias
  their inputs, corrupting a saved-for-backward tensor and exploding grad_norm
  at step 1. The same config trains cleanly on a real 4-GPU PG.

| A10G model | Topology (Fake-PG and Real-PG) |
| --- | --- |
| Llama 3 | FSDP 2 x TP 2 x CP 2 |
| Llama 3 SFT | FSDP 2 |
| DeepSeek V3 | FSDP 8, EP 8 |
| DeepSeek V4 | FSDP 2 x TP 2, EP 2 (Real-PG only) |
| GPT-OSS | FSDP 4 x TP 2, EP 4 |
| Qwen3 | FSDP 2 x TP 2 x CP 2, EP 8 |
| Muse Glimmer text | FSDP 8 |
| Qwen3.5 MoE multimodal | FSDP 4 x TP 2, EP 4 |
| Kimi K2.5 DistMuon | FSDP 8, EP 8 |

Kimi K2.5 DistMuon FSDP+EP and Kimi K2.7 DistMuon PP+FSDP+EP both run on A10G.
The K2.5 multimodal backward uses bicubic upsampling, whose CUDA backward has no
deterministic implementation, so the FSDP+EP case does not carry a numerical
golden. For manual comparisons, `loss_compare.py` can create the model-only seed
checkpoint with a model-equivalent AdamW config while the measured run continues
to use DistMuon.

Additional A10G Real-PG-only cases exercise CP and pipeline communication:

| A10G model | Pipeline-parallel topology |
| --- | --- |
| DeepSeek V3 | FSDP 2 x CP 2 x PP 2, EP 4, Interleaved1F1B |
| Llama 3 | FSDP 2 x TP 2 x PP 2, 1F1B |
| GPT-OSS | FSDP 2 x CP 2 x PP 2, EP 4, Interleaved1F1B |
| Kimi K2.7 DistMuon | FSDP 2 x PP 2, EP 2, Interleaved1F1B |

On pull requests, the Fake-PG lane and the `real_pg_required` Real-PG scope
partition the enabled A10G tests without overlap. Post-merge and scheduled
Real-PG lanes run the complete selected suite. A selected configuration fails
validation if it uses checkpointing, pipeline parallelism, an explicit non-Fake
communication backend, or another known incompatibility without
`use_real_pg=True`. Hardware is encoded by suite: `features` and `models` run in
A10G lanes, while `h100` and `b200` run only with Real PG in their
hardware-specific workflows.

### Unit tests (Goal: module functionality)

- CPU versus GPU requirements are encoded by the `unit_tests/cpu/` and
  `unit_tests/gpu/` directories.
- GPU tests that require multiple physical devices use the `multi_gpu` pytest
  marker. The 1-GPU lane selects `not multi_gpu`, while the multi-GPU lane
  selects `multi_gpu` from the same GPU directory.
- RL unit tests run in a separate 1-GPU CUDA lane with the RL image, which
  includes vLLM, Monarch, TorchStore, and the example dependencies. Multi-GPU
  RL parity tests and the RL training loop run in the RL integration lane.

## Running Tests

### Prerequisites

Ensure you have all development dependencies installed:

```bash
pip install -r requirements-dev.txt
pip install -r requirements.txt
```

### Running Integration Tests

To run the integration tests:

```bash
python -m tests.integration_tests.run_tests <output_dir> [--test_suite TEST_SUITE[,TEST_SUITE...]] [--execution_mode {fake_pg,real_pg}] [--test_scope {all,real_pg_required}] [--test_name TEST_NAME] [--ngpu NGPU]
```

Arguments:
- `output_dir`: (Required) Directory where test outputs will be stored
- `--test_suite`: (Optional) Comma-separated test suites to run (default: "features")
- `--execution_mode`: (Optional) Run with Fake PG or Real PG (default: `real_pg`)
- `--test_scope`: (Optional) Run all selected tests or only tests marked
  `use_real_pg=True` (default: `all`)
- `--test_name`: (Optional) Specific test to run by name (default: "all")
- `--ngpu`: (Optional) Number of GPUs to use for testing (default: 8)
- `--export-numerics`: (Optional) Export results for numerical tests instead of
  comparing against their `golden_numerics_path` files
- `--hf_assets_path`: (Optional) HF checkpoint exported to configs as
  `TORCHTITAN_TEST_HF_ASSETS_PATH` (used by RL tests that need real weights)

Each test names the full configurations it runs, one per run. By default each
configuration runs `torchtitan.train` through `run_train.sh`, which receives the
`MODULE`, `CONFIG` and `ENTRYPOINT` env vars. A test can set `entrypoints` to
launch another module per configuration (e.g. Flux image generation). RL tests
use `torchtitan.rl.train`, which places its own processes with Monarch, so the
runner starts it with `python -m` and runs RL suites sequentially. Suite
configurations live in the suite module itself; reusable model debug
configurations live in [torchtitan_recipes/tests](../torchtitan_recipes/tests/).

Examples:
```bash
# Run all feature integration tests (features is the default suite)
python -m tests.integration_tests.run_tests test_output

# Run the complete A10G matrix with Fake PG on one physical GPU
python -m tests.integration_tests.run_tests test_output --test_suite features,models --execution_mode fake_pg --ngpu 1

# Run the complete A10G matrix with real process groups
python -m tests.integration_tests.run_tests test_output --test_suite features,models --execution_mode real_pg --ngpu 8

# Run only cases that explicitly require real process groups
python -m tests.integration_tests.run_tests test_output --test_suite features,models --execution_mode real_pg --test_scope real_pg_required --ngpu 8

# Run H100-only cases with real process groups
python -m tests.integration_tests.run_tests test_output --test_suite h100 --execution_mode real_pg --ngpu 8

# Run B200-only cases with real process groups
python -m tests.integration_tests.run_tests test_output --test_suite b200 --execution_mode real_pg --ngpu 8

# Run the RL end-to-end suite (requires the RL dependencies)
python -m tests.integration_tests.run_tests test_output --test_suite rl --ngpu 8
```

### Running Unit Tests

To run only the unit tests:

```bash
pytest -s tests/unit_tests/cpu/

# Single-GPU tests
pytest -s tests/unit_tests/gpu/ -m "not multi_gpu"

# Multi-GPU tests
pytest -s tests/unit_tests/gpu/ -m multi_gpu

# RL unit tests (require the RL dependencies)
pytest -s tests/rl/unit_tests/cpu/
pytest -s tests/rl/unit_tests/gpu/ -m "not multi_gpu"

# RL multi-GPU unit tests run one torchrun launch per test, for example
torchrun --nproc-per-node=2 -m pytest tests/rl/unit_tests/gpu/test_bitwise_parity.py::TestBitwiseParityVarlen
```

The RL CPU and GPU unit workflows (`unit_test_cpu_rl.yaml`, `unit_test_gpu_rl.yaml`) run
on `main` pushes, every 12 hours, and on PRs with the `ciflow/rl` label, which is added
automatically to PRs that touch RL code (see `.github/labeler.yml`). When a PR
changes `.ci/docker/`, use the existing `ciflow/docker` label to build its image;
rerun the RL unit job after that image is available.

### Running Specific Unit Test Files

To run a specific test file:

```bash
pytest -s tests/unit_tests/cpu/config/test_config_loader.py
```

### Running Specific Test Functions in Unit Tests

To run a specific test function:

```bash
pytest -s tests/unit_tests/cpu/config/test_config_loader.py::test_operational_overrides
```
