"""Tests for launch module."""
