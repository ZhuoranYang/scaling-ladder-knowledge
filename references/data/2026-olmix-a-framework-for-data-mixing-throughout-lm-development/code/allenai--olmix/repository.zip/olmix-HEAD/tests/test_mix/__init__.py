"""Tests for mix module."""
