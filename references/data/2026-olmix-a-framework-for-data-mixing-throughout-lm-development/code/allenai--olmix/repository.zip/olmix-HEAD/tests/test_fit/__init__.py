"""Tests for fit module."""
