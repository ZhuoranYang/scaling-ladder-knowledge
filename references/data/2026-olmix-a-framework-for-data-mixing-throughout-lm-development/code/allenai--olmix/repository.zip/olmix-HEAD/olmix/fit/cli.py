import hashlib
import json
import logging
import os
import pathlib
import warnings

import click

warnings.filterwarnings("ignore", category=UserWarning)

from olmix.fit.config import FitConfig
from olmix.fit.core import run_fit
from olmix.fit.loaders import load_from_csv

logger = logging.getLogger(__name__)


def _save_fit_config(cfg: FitConfig, output_dir: str) -> str:
    """Serialize FitConfig to JSON inside a hashed subdirectory of *output_dir*."""
    config_str = json.dumps(cfg.model_dump(), sort_keys=True, default=str)
    hash_str = hashlib.sha256(config_str.encode("utf-8")).hexdigest()[:16]
    folder_path = os.path.join(output_dir, hash_str)
    os.makedirs(folder_path, exist_ok=True)
    config_path = os.path.join(folder_path, "config.json")
    with open(config_path, "w") as f:
        json.dump(cfg.model_dump(), f, indent=2, default=str)
    logger.info(f"Saved config to {config_path}")
    return folder_path


@click.command()
@click.option(
    "--config",
    "config_path",
    type=click.Path(exists=True),
    required=True,
    help="Path to the YAML fit configuration file.",
)
@click.option(
    "--output-dir",
    "output_dir_arg",
    type=click.Path(),
    required=True,
    help="Directory for saving fit outputs.",
)
def fit(config_path: str, output_dir_arg: str):
    cfg = FitConfig.from_yaml(config_path)

    # ── Load CSVs ─────────────────────────────────────────────────────────
    ratios, metrics, domain_cols, metric_cols = load_from_csv(cfg.swarm.ratios, cfg.swarm.metrics)

    # ── Priors ────────────────────────────────────────────────────────────
    priors_data = cfg.priors.to_tuple()
    from copy import deepcopy

    original_priors_data = deepcopy(priors_data)

    logger.info("Source weights:")
    logger.info(priors_data[0])

    # Validate constraints
    if cfg.constraints.enabled and cfg.constraints.target_tokens is None:
        raise click.UsageError("constraints.enabled requires constraints.target_tokens")

    # Validate eval config
    if cfg.regression.aggregate_task_families and cfg.eval is None:
        raise click.UsageError("regression.aggregate_task_families requires eval config with task families")

    # Validate proposer config
    if cfg.proposer.type == "search" and cfg.regression.type != "search":
        raise click.UsageError("proposer.type 'search' only works with regression.type 'search'")
    if cfg.proposer.kl_reg is not None and cfg.proposer.type != "exact":
        raise click.UsageError("proposer.kl_reg requires proposer.type 'exact'")

    # output directory
    pathlib.Path(output_dir_arg).mkdir(parents=True, exist_ok=True)
    output_dir = _save_fit_config(cfg, output_dir_arg)

    # ── Run fit ───────────────────────────────────────────────────────────
    run_fit(
        ratios,
        metrics,
        priors_data,
        original_priors_data,
        output_dir,
        domain_cols=domain_cols,
        metric_cols=metric_cols,
        eval_metrics=cfg.eval.metric_names if cfg.eval else None,
        task_families=cfg.eval.task_families if cfg.eval else None,
        experiment_groups=None,
        launch_configs=None,
        full_group_names=None,
        regression_type=cfg.regression.type,
        train_split=cfg.regression.train_split,
        n_test=cfg.regression.n_test,
        seed=cfg.regression.seed,
        early_stopping=0.0,
        proposer_type=cfg.proposer.type,
        constrain_objective=cfg.constraints.enabled,
        temperature=cfg.proposer.temperature,
        drop_metrics=tuple(cfg.filtering.drop_metrics),
        fit_only=cfg.proposer.fit_only,
        make_worst_mix=cfg.proposer.make_worst_mix,
        kl_reg=cfg.proposer.kl_reg,
        target_tokens=cfg.constraints.target_tokens,
        repetition_factor=cfg.constraints.repetition_factor,
        token_counts=cfg.priors.token_counts,
        test_ratios_path=(),
        test_metrics_path=(),
        aggregate_task_families=cfg.regression.aggregate_task_families,
        obj_weights=cfg.filtering.obj_weights,
    )
