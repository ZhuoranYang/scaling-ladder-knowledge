# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Benchmark the production Hindi Indic Canary + Parakeet recovery pipeline."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import importlib.metadata
import importlib.util
import json
import math
import os
import statistics
import sys
import time
import traceback
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from loguru import logger
from omegaconf import OmegaConf

from nemo_curator.config.run import create_executor_from_yaml, create_pipeline_from_yaml, create_ray_client_from_yaml
from nemo_curator.stages.audio.inference.indic_canary_trtllm_runtime import _require_tensorrt_llm

_PIPELINE_CONFIG = Path(__file__).resolve().parents[2] / "tutorials/audio/granary_v2/indic_asr/pipeline.yaml"
EXPECTED_NUM_ROWS = 216_164
EXPECTED_TOTAL_DURATION_MS = 1_914_327_468
EXPECTED_MANIFEST_BYTES = 116_382_162
EXPECTED_MANIFEST_SHA256 = (
    "0a8ccc0f3ff8d4ad35b3e7e104e5e093b0de14a92542d71fa6911c8045373727"  # pragma: allowlist secret
)
CANARY_REQUIRED_FILES = (
    "encoder/encoder.plan",
    "encoder/config.json",
    "decoder/config.json",
    "decoder/rank0.engine",
    "decoder/vocab.json",
    "preprocessor/config.json",
    "preprocessor/mel_basis.pt",
)
PARAKEET_ENGINE_REQUIRED_FILES = ("encoder.plan", "metadata.json", "model.nemo")


def _load_benchmark_writer() -> Any:  # noqa: ANN401
    """Load harness-only helpers without burdening Hydra stage imports."""
    if __package__:
        from benchmarking.scripts.utils import write_benchmark_results
    else:  # Direct script execution adds only benchmarking/scripts to sys.path.
        from utils import write_benchmark_results

    return write_benchmark_results


@dataclass(frozen=True)
class InputInventory:
    """Identity and duration contract for one staged benchmark cohort."""

    manifests: tuple[Path, ...]
    audio_paths_by_id: dict[str, str]
    durations_ms_by_id: dict[str, int]
    reference_texts_by_id: dict[str, str]
    manifest_bytes: int
    manifest_sha256: str

    @property
    def num_rows(self) -> int:
        return len(self.audio_paths_by_id)

    @property
    def total_duration_s(self) -> float:
        return self.total_duration_ms / 1000

    @property
    def total_duration_ms(self) -> int:
        return sum(self.durations_ms_by_id.values())


def _normalize_input_row(
    row: object,
    manifest_path: Path,
    line_number: int,
) -> tuple[dict[str, Any], int]:
    if not isinstance(row, dict):
        msg = f"Input manifest row must be an object: {manifest_path}:{line_number}"
        raise TypeError(msg)
    try:
        audio_item_id = row["audio_item_id"]
        audio_filepath = row["audio_filepath"]
        duration = Decimal(str(row["duration"]))
        source_lang = row["source_lang"]
        text = row["text"]
    except (InvalidOperation, KeyError, TypeError, ValueError) as e:
        msg = f"Invalid input manifest row: {manifest_path}:{line_number}"
        raise RuntimeError(msg) from e
    duration_ms_decimal = duration * 1000
    if (
        not isinstance(audio_item_id, str)
        or not audio_item_id
        or not isinstance(audio_filepath, str)
        or not audio_filepath
        or not duration.is_finite()
        or duration <= 0
        or duration_ms_decimal != duration_ms_decimal.to_integral_value()
        or source_lang != "hi"
        or not isinstance(text, str)
        or not text.strip()
    ):
        msg = f"Invalid input manifest values: {manifest_path}:{line_number}"
        raise RuntimeError(msg)

    resolved_audio_path = Path(audio_filepath)
    if not resolved_audio_path.is_absolute():
        resolved_audio_path = manifest_path.parent / resolved_audio_path
    resolved_audio_path = resolved_audio_path.resolve()
    if not resolved_audio_path.is_file():
        msg = f"Input audio is missing: {resolved_audio_path}"
        raise FileNotFoundError(msg)

    normalized = dict(row)
    normalized["audio_filepath"] = str(resolved_audio_path)
    normalized["duration"] = float(duration)
    return normalized, int(duration_ms_decimal)


def _materialize_input_manifests(  # noqa: C901
    source_manifest: Path,
    scratch_dir: Path,
    num_shards: int,
) -> InputInventory:
    if num_shards <= 0:
        msg = f"num_shards must be positive, got {num_shards}"
        raise ValueError(msg)
    if not source_manifest.is_file():
        msg = f"Input manifest does not exist: {source_manifest}"
        raise FileNotFoundError(msg)

    rows: list[dict[str, Any]] = []
    audio_paths_by_id: dict[str, str] = {}
    durations_ms_by_id: dict[str, int] = {}
    reference_texts_by_id: dict[str, str] = {}
    seen_audio_paths: set[str] = set()
    manifest_digest = hashlib.sha256()
    manifest_bytes = 0
    with source_manifest.open("rb") as source_file:
        opened_manifest_bytes = os.fstat(source_file.fileno()).st_size
        for line_number, raw_line in enumerate(source_file, start=1):
            manifest_digest.update(raw_line)
            manifest_bytes += len(raw_line)
            if not raw_line.strip():
                continue
            try:
                raw_row = json.loads(raw_line, parse_float=Decimal)
            except (UnicodeDecodeError, json.JSONDecodeError) as e:
                msg = f"Invalid JSON input manifest row: {source_manifest}:{line_number}"
                raise RuntimeError(msg) from e
            row, duration_ms = _normalize_input_row(raw_row, source_manifest, line_number)
            audio_item_id = row["audio_item_id"]
            audio_path = row["audio_filepath"]
            if audio_item_id in audio_paths_by_id or audio_path in seen_audio_paths:
                msg = f"Duplicate input identity or audio path at {source_manifest}:{line_number}"
                raise RuntimeError(msg)
            audio_paths_by_id[audio_item_id] = audio_path
            durations_ms_by_id[audio_item_id] = duration_ms
            reference_texts_by_id[audio_item_id] = row["text"]
            seen_audio_paths.add(audio_path)
            rows.append(row)
    if manifest_bytes != opened_manifest_bytes:
        msg = f"Input manifest changed size while it was read: opened={opened_manifest_bytes}, read={manifest_bytes}"
        raise RuntimeError(msg)
    manifest_sha256 = manifest_digest.hexdigest()
    if not rows:
        msg = f"Input manifest contains no rows: {source_manifest}"
        raise RuntimeError(msg)

    scratch_dir.mkdir(parents=True, exist_ok=False)
    shard_paths = tuple(scratch_dir / f"manifest-{index:02d}.jsonl" for index in range(num_shards))
    shard_files = [path.open("x", encoding="utf-8") for path in shard_paths]
    try:
        for index, row in enumerate(rows):
            shard_files[index % num_shards].write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    finally:
        for shard_file in shard_files:
            shard_file.close()

    return InputInventory(
        manifests=shard_paths,
        audio_paths_by_id=audio_paths_by_id,
        durations_ms_by_id=durations_ms_by_id,
        reference_texts_by_id=reference_texts_by_id,
        manifest_bytes=manifest_bytes,
        manifest_sha256=manifest_sha256,
    )


def _require_files(root: Path, relative_paths: tuple[str, ...], label: str) -> None:
    missing = [str(root / relative_path) for relative_path in relative_paths if not (root / relative_path).is_file()]
    if missing:
        msg = f"{label} is missing required file(s): {missing}"
        raise FileNotFoundError(msg)


def _preflight_runtime_and_models(
    indic_canary_engine_dir: Path,
    parakeet_tensorrt_engine_dir: Path,
) -> None:
    if sys.version_info[:2] != (3, 12):
        msg = "Indic ASR requires Python 3.12 in the dedicated image built with docker/audio/Dockerfile.trt_llm."
        raise RuntimeError(msg)
    missing_modules = [module for module in ("tensorrt", "tensorrt_llm") if importlib.util.find_spec(module) is None]
    if missing_modules:
        msg = (
            "Indic ASR benchmark image is missing required runtime module(s): "
            f"{missing_modules}. Use the image built with docker/audio/Dockerfile.trt_llm."
        )
        raise RuntimeError(msg)
    # Loading the native bindings catches ABI failures that find_spec cannot.
    _require_tensorrt_llm()
    for module in (
        "nemo.collections.asr",
        "nemo_text_processing.text_normalization",
        "nemo_curator.models.asr.indic_parakeet_rnnt_tensorrt",
    ):
        importlib.import_module(module)
    _require_files(indic_canary_engine_dir, CANARY_REQUIRED_FILES, "Indic Canary engine")
    _require_files(parakeet_tensorrt_engine_dir, PARAKEET_ENGINE_REQUIRED_FILES, "Indic Parakeet TensorRT bundle")
    logger.info(f"Indic ASR Python: {sys.executable}")
    for package_name in ("torch", "torchaudio", "tensorrt", "tensorrt-llm", "nemo-toolkit", "transformers"):
        try:
            logger.info(f"{package_name} version: {importlib.metadata.version(package_name)}")
        except importlib.metadata.PackageNotFoundError:
            logger.info(f"{package_name} is importable but has no package metadata")


def _coverage(rows: list[dict[str, Any]], key: str) -> float:
    return sum(isinstance(row.get(key), str) and bool(row[key].strip()) for row in rows) / len(rows)


def _percentile(values: list[float], percentile: float) -> float:
    ordered = sorted(values)
    index = max(0, math.ceil(percentile * len(ordered)) - 1)
    return ordered[index]


def _validate_output_manifest(output_manifest: Path, inventory: InputInventory) -> dict[str, float | int | str]:
    if not output_manifest.is_file():
        msg = f"Indic ASR pipeline wrote no output manifest: {output_manifest}"
        raise RuntimeError(msg)
    rows = [json.loads(line) for line in output_manifest.read_text(encoding="utf-8").splitlines() if line]
    if len(rows) != inventory.num_rows:
        msg = f"Indic ASR returned {len(rows)} rows for {inventory.num_rows} input rows"
        raise RuntimeError(msg)

    output_ids: set[str] = set()
    wers: list[float] = []
    output_durations_ms: list[int] = []
    source_counts = {"primary": 0, "fallback": 0, "reference": 0, "ground_truth": 0, "other": 0}
    skipped_rows = 0
    for row_index, row in enumerate(rows):
        try:
            audio_item_id = row["audio_item_id"]
            audio_filepath = row["audio_filepath"]
            duration_s = float(row["duration"])
            duration_ms_decimal = Decimal(str(row["duration"])) * 1000
            source_lang = row["source_lang"]
            reference_text = row["reference_text"]
            granary_v1_prediction = row["granary_v1_prediction"]
            wer_pct = float(row["wer_pct"])
            source = row["best_prediction_source"]
            skip_reason = row["_skipme"]
            model_text_values = [row["primary_model_prediction"], row["fallback_model_prediction"]]
            selected_text_values = [
                row["best_prediction"],
                row["cleaned_text"],
                row["abbreviated_text"],
            ]
        except (KeyError, TypeError, ValueError) as e:
            msg = f"Invalid Indic ASR output row {row_index}"
            raise RuntimeError(msg) from e
        if (
            not isinstance(audio_item_id, str)
            or audio_item_id in output_ids
            or inventory.audio_paths_by_id.get(audio_item_id) != audio_filepath
            or not math.isfinite(duration_s)
            or duration_ms_decimal != duration_ms_decimal.to_integral_value()
            or int(duration_ms_decimal) != inventory.durations_ms_by_id.get(audio_item_id, -1)
            or source_lang != "hi"
            or reference_text != inventory.reference_texts_by_id.get(audio_item_id)
            or granary_v1_prediction != reference_text
            or not math.isfinite(wer_pct)
            or wer_pct < 0
            or source not in {"primary", "fallback"}
            or not isinstance(skip_reason, str)
            or not all(isinstance(value, str) for value in model_text_values)
            or not isinstance(selected_text_values[0], str)
            or not selected_text_values[0].strip()
            or not all(isinstance(value, str) for value in selected_text_values[1:])
            or (not skip_reason and not all(bool(value.strip()) for value in selected_text_values[1:]))
        ):
            msg = f"Invalid Indic ASR output values in row {row_index}"
            raise RuntimeError(msg)
        output_ids.add(audio_item_id)
        wers.append(wer_pct)
        output_durations_ms.append(int(duration_ms_decimal))
        skipped_rows += bool(skip_reason)
        source_counts[source if source in source_counts else "other"] += 1

    expected_ids = set(inventory.audio_paths_by_id)
    if output_ids != expected_ids:
        msg = f"Indic ASR output identity mismatch: missing={len(expected_ids - output_ids)}, extra={len(output_ids - expected_ids)}"
        raise RuntimeError(msg)
    total_duration_ms = sum(output_durations_ms)
    if total_duration_ms != inventory.total_duration_ms:
        msg = (
            f"Indic ASR output duration changed: input_ms={inventory.total_duration_ms}, output_ms={total_duration_ms}"
        )
        raise RuntimeError(msg)

    return {
        "num_input_rows": inventory.num_rows,
        "num_output_rows": len(rows),
        "input_output_coverage_ratio": len(rows) / inventory.num_rows,
        "total_audio_duration_ms": total_duration_ms,
        "total_audio_duration_hours": total_duration_ms / 3_600_000,
        "input_manifest_bytes": inventory.manifest_bytes,
        "input_manifest_sha256": inventory.manifest_sha256,
        "primary_prediction_coverage_ratio": _coverage(rows, "primary_model_prediction"),
        "fallback_prediction_coverage_ratio": _coverage(rows, "fallback_model_prediction"),
        "best_prediction_coverage_ratio": _coverage(rows, "best_prediction"),
        "cleaned_text_coverage_ratio": _coverage(rows, "cleaned_text"),
        "abbreviated_text_coverage_ratio": _coverage(rows, "abbreviated_text"),
        "wer_output_coverage_ratio": len(wers) / inventory.num_rows,
        "mean_wer_pct": statistics.fmean(wers),
        "p50_wer_pct": _percentile(wers, 0.50),
        "p90_wer_pct": _percentile(wers, 0.90),
        "num_skipped_rows": skipped_rows,
        "prediction_source_primary_rows": source_counts["primary"],
        "prediction_source_fallback_rows": source_counts["fallback"],
        "prediction_source_reference_rows": source_counts["reference"],
        "prediction_source_ground_truth_rows": source_counts["ground_truth"],
        "prediction_source_other_rows": source_counts["other"],
        "recognized_prediction_source_ratio": (source_counts["primary"] + source_counts["fallback"])
        / inventory.num_rows,
    }


def run_audio_indic_asr_benchmark(  # noqa: PLR0913
    benchmark_results_path: str,
    input_manifest: str,
    indic_canary_engine_dir: str,
    parakeet_tensorrt_engine_dir: str,
    regex_yaml: str,
    hall_phrases: str,
    executor: str = "ray_data",
    expected_num_rows: int = EXPECTED_NUM_ROWS,
    expected_total_duration_ms: int = EXPECTED_TOTAL_DURATION_MS,
    expected_manifest_bytes: int = EXPECTED_MANIFEST_BYTES,
    expected_manifest_sha256: str = EXPECTED_MANIFEST_SHA256,
    read_concurrency: int | None = None,
    prep_workers: int | None = None,
    primary_workers: int | None = None,
    fallback_workers: int | None = None,
) -> dict[str, Any]:
    """Run the pinned production processor chain over the staged Hindi cohort."""
    benchmark_path = Path(benchmark_results_path)
    scratch_dir = benchmark_path / "scratch" / "audio_indic_asr_input"
    output_manifest = benchmark_path / "results" / "audio_indic_asr_output.jsonl"
    canary_path = Path(indic_canary_engine_dir)
    parakeet_engine = Path(parakeet_tensorrt_engine_dir)
    regex_path = Path(regex_yaml)
    phrases_path = Path(hall_phrases)

    if output_manifest.exists() or scratch_dir.exists():
        msg = f"Indic ASR benchmark output already exists under {benchmark_path}"
        raise ValueError(msg)
    for config_path in (regex_path, phrases_path):
        if not config_path.is_file():
            msg = f"Indic ASR configuration file is missing: {config_path}"
            raise FileNotFoundError(msg)
    cfg = OmegaConf.load(_PIPELINE_CONFIG)
    cfg.dataset_dir = str(Path(input_manifest).resolve().parent)
    cfg.output_path = str(output_manifest.resolve())
    cfg.indic_canary_engine_dir = str(canary_path.resolve())
    cfg.parakeet_tensorrt_engine_dir = str(parakeet_engine.resolve())
    cfg.regex_yaml = str(regex_path.resolve())
    cfg.hall_phrases = str(phrases_path.resolve())
    cfg.backend = executor
    for key, value in (
        ("read_concurrency", read_concurrency),
        ("prep_workers", prep_workers),
        ("primary_workers", primary_workers),
        ("fallback_workers", fallback_workers),
    ):
        if value is not None:
            cfg[key] = value
    _preflight_runtime_and_models(canary_path, parakeet_engine)
    inventory = _materialize_input_manifests(Path(input_manifest), scratch_dir, int(cfg.read_concurrency))
    if inventory.num_rows != expected_num_rows:
        msg = f"Expected {expected_num_rows} Hindi rows, found {inventory.num_rows}"
        raise RuntimeError(msg)
    if inventory.total_duration_ms != expected_total_duration_ms:
        msg = f"Expected {expected_total_duration_ms} ms of Hindi audio, found {inventory.total_duration_ms}"
        raise RuntimeError(msg)
    if inventory.manifest_bytes != expected_manifest_bytes:
        msg = f"Expected {expected_manifest_bytes} manifest bytes, found {inventory.manifest_bytes}"
        raise RuntimeError(msg)
    if inventory.manifest_sha256 != expected_manifest_sha256.lower():
        msg = f"Expected manifest SHA-256 {expected_manifest_sha256.lower()}, found {inventory.manifest_sha256}"
        raise RuntimeError(msg)

    cfg.manifest_path = [str(path.resolve()) for path in inventory.manifests]
    pipeline = create_pipeline_from_yaml(cfg)
    logger.info(pipeline.describe())
    with create_ray_client_from_yaml(cfg):
        start_time = time.perf_counter()
        tasks = pipeline.run(create_executor_from_yaml(cfg))
        pipeline_elapsed_s = time.perf_counter() - start_time
        output_metrics = _validate_output_manifest(output_manifest, inventory)
        elapsed_s = time.perf_counter() - start_time
    del tasks
    total_audio_hours = float(output_metrics["total_audio_duration_hours"])
    logger.success(f"Processed {inventory.num_rows} unique Hindi clips in {elapsed_s:.2f}s")
    return {
        "params": {
            "pipeline_config_path": str(_PIPELINE_CONFIG),
            "pipeline_config": OmegaConf.to_container(cfg, resolve=True),
        },
        "metrics": {
            "is_success": True,
            "time_taken_s": elapsed_s,
            "pipeline_time_s": pipeline_elapsed_s,
            **output_metrics,
            "throughput_tasks_per_sec": inventory.num_rows / elapsed_s if elapsed_s > 0 else 0,
            "throughput_audio_hours_per_hour": total_audio_hours * 3600 / elapsed_s if elapsed_s > 0 else 0,
        },
        "tasks": [],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--benchmark-results-path", required=True)
    parser.add_argument("--input-manifest", required=True)
    parser.add_argument("--indic-canary-engine-dir", required=True)
    parser.add_argument("--parakeet-tensorrt-engine-dir", required=True)
    parser.add_argument("--regex-yaml", required=True)
    parser.add_argument("--hall-phrases", required=True)
    parser.add_argument("--executor", default="xenna", choices=["xenna", "ray_data"])
    parser.add_argument("--expected-num-rows", type=int, default=EXPECTED_NUM_ROWS)
    parser.add_argument("--expected-total-duration-ms", type=int, default=EXPECTED_TOTAL_DURATION_MS)
    parser.add_argument("--expected-manifest-bytes", type=int, default=EXPECTED_MANIFEST_BYTES)
    parser.add_argument("--expected-manifest-sha256", default=EXPECTED_MANIFEST_SHA256)
    parser.add_argument("--read-concurrency", type=int, help="Override the shared tutorial YAML setting")
    parser.add_argument("--prep-workers", type=int, help="Override the shared tutorial YAML setting")
    parser.add_argument("--primary-workers", type=int, help="Override the shared tutorial YAML setting")
    parser.add_argument("--fallback-workers", type=int, help="Override the shared tutorial YAML setting")
    parser.add_argument(
        "--save-tasks", action=argparse.BooleanOptionalAction, default=True, help="Save completed tasks in tasks.pkl"
    )
    args = parser.parse_args()
    save_tasks = vars(args).pop("save_tasks")

    benchmark_path = Path(args.benchmark_results_path)
    # The runner precreates params.json and an empty scratch directory.
    for name in ("params.json", "results", "scratch", "metrics.json", "tasks.pkl"):
        path = benchmark_path / name
        if name == "params.json" and path.is_file() and not path.is_symlink():
            continue
        if name == "scratch" and path.is_dir() and not path.is_symlink() and not any(path.iterdir()):
            continue
        if path.exists() or path.is_symlink():
            parser.error(f"Benchmark output already exists: {path}; choose a fresh results directory")

    params = vars(args)
    logger.info(f"Audio Indic ASR benchmark arguments: {params}")
    results: dict[str, Any] = {"params": params, "metrics": {"is_success": False}, "tasks": []}
    exit_code = 1
    try:
        result = run_audio_indic_asr_benchmark(**params)
        result["params"] = {**params, **result["params"]}
        results.update(result)
        exit_code = 0
    except Exception as e:
        logger.error(f"Indic ASR benchmark failed: {e}")
        logger.debug(f"Full traceback:\n{traceback.format_exc()}")
        results["metrics"]["error_message"] = str(e)
    finally:
        write_benchmark_results = _load_benchmark_writer()
        write_benchmark_results(results, args.benchmark_results_path, save_tasks=save_tasks)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
