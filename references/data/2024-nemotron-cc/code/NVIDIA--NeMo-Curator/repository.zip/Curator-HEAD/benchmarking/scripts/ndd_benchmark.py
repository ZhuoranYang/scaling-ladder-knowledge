# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# ruff: noqa: PLR0913

"""Nemotron-CC SDG benchmark.

Generates SDG for CommonCrawl documents via WikipediaParaphrasingStage backed by
an InferenceServer (ray-serve or dynamo) or nvidia-nim.

Key args:
  --inference-server-type  ray-serve | dynamo | nvidia-nim
  --engine-kwargs          JSON vLLM kwargs, e.g. '{"tensor_parallel_size": 4}'
  --autoscaling-config     JSON Ray Serve autoscaling, e.g. '{"min_replicas": 1, "max_replicas": 8}'
                           For ``dynamo``, autoscaling is unsupported: ``min_replicas`` must
                           equal ``max_replicas`` and is used as a static ``num_replicas``.
  --model-path             Optional absolute path to a local model snapshot dir. When set
                           (ray-serve/dynamo only), used as ``model_identifier`` so vLLM
                           loads weights from disk; ``--model-id`` is still used as the
                           served model name in /v1/models. Ignored for ``nvidia-nim``.
  --tiktoken-cache-dir     Optional absolute path to a pre-populated tiktoken/harmony vocab
                           cache dir (ray-serve/dynamo only). Avoids downloading gpt-oss's
                           harmony encoding from Azure blob storage at startup.
  --health-check-timeout-s Seconds to wait for the model server to become ready
                           (ray-serve/dynamo only). Defaults to 300s if unset.
"""

import argparse
import os
import time
from pathlib import Path
from typing import Any

from inference_server_utils import parse_json_object, start_inference_server, static_num_replicas
from loguru import logger
from utils import load_dataset_files, setup_executor, write_benchmark_results

from nemo_curator.pipeline import Pipeline
from nemo_curator.stages.synthetic.nemotron_cc.nemo_data_designer.nemotron_cc import WikipediaParaphrasingStage
from nemo_curator.stages.text.io.reader.jsonl import JsonlReader
from nemo_curator.stages.text.io.writer.jsonl import JsonlWriter
from nemo_curator.tasks.utils import TaskPerfUtils


def run_nemotron_cc_sdg_benchmark(  # noqa: PLR0915
    inference_server_type: str,
    model_id: str,
    input_path: str,
    output_path: str,
    executor: str,
    dataset_size_gb: float,
    engine_kwargs: dict[str, Any] | None = None,
    autoscaling_config: dict[str, Any] | None = None,
    model_path: str | None = None,
    tiktoken_cache_dir: str | None = None,
    health_check_timeout_s: int | None = None,
    **kwargs,  # noqa: ARG001
) -> dict[str, Any]:
    """Run the Nemotron-CC SDG benchmark and collect metrics."""
    input_path = Path(input_path)
    output_path = Path(output_path).absolute()
    output_path.mkdir(parents=True, exist_ok=True)

    logger.info(f"Inference server type: {inference_server_type}")
    logger.info(f"Model ID: {model_id}")
    logger.info(f"Input path: {input_path}")
    logger.info(f"Output path: {output_path}")
    logger.info(f"Executor: {executor}")
    logger.info(f"Dataset size: {dataset_size_gb} GB")

    input_files = load_dataset_files(input_path, dataset_size_gb, keep_extensions="jsonl")

    import data_designer.config as dd

    inference_server = None
    model_providers = None
    serve_startup_s = 0.0

    if inference_server_type in ("ray-serve", "dynamo"):
        logger.info(f"Starting local {inference_server_type} InferenceServer with engine_kwargs={engine_kwargs}")
        serve_start = time.perf_counter()
        num_replicas = static_num_replicas(autoscaling_config) if inference_server_type == "dynamo" else 1
        ray_serve_deployment_config = (
            {"autoscaling_config": autoscaling_config or {"min_replicas": 1, "max_replicas": 1}}
            if inference_server_type == "ray-serve"
            else None
        )
        inference_server = start_inference_server(
            backend=inference_server_type,
            model_id=model_id,
            model_path=model_path,
            num_replicas=num_replicas,
            engine_kwargs=engine_kwargs,
            model_runtime_env=(
                {"env_vars": {"TIKTOKEN_RS_CACHE_DIR": tiktoken_cache_dir}} if tiktoken_cache_dir else None
            ),
            ray_serve_deployment_config=ray_serve_deployment_config,
            health_check_timeout_s=health_check_timeout_s or 300,
        )
        serve_startup_s = time.perf_counter() - serve_start
        logger.info(f"InferenceServer ready at {inference_server.endpoint} (startup: {serve_startup_s:.1f}s)")

        provider_name = "local"
        model_providers = [
            dd.ModelProvider(
                name=provider_name,
                endpoint=inference_server.endpoint,
                api_key="unused",  # pragma: allowlist secret
            )
        ]
    elif inference_server_type == "nvidia-nim":
        if not os.environ.get("NVIDIA_API_KEY"):
            msg = "NVIDIA_API_KEY must be set for nvidia-nim model type"
            raise OSError(msg)
        provider_name = "nvidia"
    else:
        msg = f"Unknown inference_server_type: {inference_server_type}"
        raise ValueError(msg)

    # Build config and run pipeline
    model_alias = model_id
    model_configs = [
        dd.ModelConfig(
            alias=model_alias,
            model=model_id,
            provider=provider_name,
            skip_health_check=True,
            inference_parameters=dd.ChatCompletionInferenceParams(
                temperature=1.0,
                top_p=1.0,
                max_tokens=512,
                max_parallel_requests=128,
            ),
        )
    ]

    executor_obj = setup_executor(executor)

    pipeline = Pipeline(
        name="nemotron_cc_sdg_benchmark_pipeline",
        stages=[
            JsonlReader(file_paths=input_files),
            WikipediaParaphrasingStage(
                model_alias=model_alias,
                model_configs=model_configs,
                model_providers=model_providers,
                input_field="text",
                output_field="rephrased",
            ),
            JsonlWriter(path=str(output_path)),
        ],
    )

    logger.info("Starting Nemotron-CC SDG pipeline...")
    run_start_time = time.perf_counter()
    try:
        output_tasks = pipeline.run(executor_obj)
    finally:
        run_time_taken = time.perf_counter() - run_start_time

        if inference_server is not None:
            inference_server.stop()

    # Post-run: extract metrics from _stage_perf
    input_row_count = int(
        TaskPerfUtils.get_aggregated_stage_stat(output_tasks, "DataDesignerStage", "custom.num_input_records")
    )
    output_row_count = int(
        TaskPerfUtils.get_aggregated_stage_stat(output_tasks, "DataDesignerStage", "custom.num_output_records")
    )
    input_tokens_median_per_record = float(
        TaskPerfUtils.get_aggregated_stage_stat(
            output_tasks, "DataDesignerStage", "custom.input_tokens_median_per_record"
        )
    )
    output_tokens_median_per_record = float(
        TaskPerfUtils.get_aggregated_stage_stat(
            output_tasks, "DataDesignerStage", "custom.output_tokens_median_per_record"
        )
    )
    throughput_rows_per_sec = output_row_count / run_time_taken if run_time_taken > 0 else 0

    logger.success(f"Nemotron-CC SDG benchmark completed in {run_time_taken:.2f}s")
    logger.success(f"Input:  {input_row_count} rows")
    logger.success(f"Output: {output_row_count} rows")
    logger.success(f"Input tokens median per record: {input_tokens_median_per_record:,}")
    logger.success(f"Output tokens median per record: {output_tokens_median_per_record:,}")
    logger.success(f"Throughput: {throughput_rows_per_sec:.2f} rows/sec")

    return {
        "metrics": {
            "is_success": True,
            "time_taken_s": run_time_taken,
            "inference_server_type": inference_server_type,
            "model_id": model_id,
            "input_row_count": input_row_count,
            "output_row_count": output_row_count,
            "input_tokens_median_per_record": input_tokens_median_per_record,
            "output_tokens_median_per_record": output_tokens_median_per_record,
            "throughput_rows_per_sec": throughput_rows_per_sec,
            "serve_startup_s": serve_startup_s,
            "dataset_size_gb": dataset_size_gb,
        },
        "tasks": output_tasks,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Nemotron-CC SDG benchmark")
    parser.add_argument("--benchmark-results-path", required=True, help="Path to write benchmark results")
    parser.add_argument("--input-path", required=True, help="Path to input JSONL data (CommonCrawl)")
    parser.add_argument("--output-path", required=True, help="Path to write SDG output")
    parser.add_argument(
        "--inference-server-type",
        required=True,
        choices=["ray-serve", "dynamo", "nvidia-nim"],
        help="Model serving backend",
    )
    parser.add_argument("--model-id", default="openai/gpt-oss-20b", help="Model identifier")
    parser.add_argument(
        "--model-path",
        default=None,
        help=(
            "Optional absolute path to a local model snapshot dir (vLLM/Dynamo only). "
            "When set, vLLM loads weights from this path; --model-id remains the served name."
        ),
    )
    parser.add_argument("--executor", default="ray_data", choices=["ray_data", "xenna"], help="Pipeline executor")
    parser.add_argument("--dataset-size-gb", type=float, required=True, help="Size of dataset to process in GB")
    parser.add_argument(
        "--engine-kwargs",
        type=str,
        default=None,
        help="JSON string of vLLM engine kwargs (e.g. '{\"tensor_parallel_size\": 4}')",
    )
    parser.add_argument(
        "--autoscaling-config",
        type=str,
        default=None,
        help='JSON string of Ray Serve autoscaling config (e.g. \'{"min_replicas": 1, "max_replicas": 8}\')',
    )
    parser.add_argument(
        "--tiktoken-cache-dir",
        default=None,
        help=(
            "Optional absolute path to a pre-populated tiktoken/harmony vocab cache dir "
            "(ray-serve/dynamo only). Set to avoid downloading gpt-oss's harmony encoding "
            "from Azure blob storage at replica/worker startup; see openai/harmony#101."
        ),
    )
    parser.add_argument(
        "--health-check-timeout-s",
        type=int,
        default=None,
        help=(
            "Seconds to wait for the model server to become ready (ray-serve/dynamo only). "
            "Defaults to DEFAULT_SERVE_HEALTH_TIMEOUT_S (300s) if unset."
        ),
    )

    parser.add_argument(
        "--save-tasks", action=argparse.BooleanOptionalAction, default=True, help="Save completed tasks in tasks.pkl"
    )
    args = parser.parse_args()
    save_tasks = vars(args).pop("save_tasks")

    logger.info("=== Nemotron-CC SDG Benchmark Starting ===")
    logger.info(f"Arguments: {vars(args)}")

    engine_kwargs = parse_json_object(args.engine_kwargs, argument="--engine-kwargs")
    autoscaling_config = parse_json_object(args.autoscaling_config, argument="--autoscaling-config")

    success_code = 1
    result_dict: dict[str, Any] = {
        "params": vars(args),
        "metrics": {"is_success": False},
        "tasks": [],
    }
    try:
        result_dict.update(
            run_nemotron_cc_sdg_benchmark(
                inference_server_type=args.inference_server_type,
                model_id=args.model_id,
                input_path=args.input_path,
                output_path=args.output_path,
                executor=args.executor,
                dataset_size_gb=args.dataset_size_gb,
                engine_kwargs=engine_kwargs,
                autoscaling_config=autoscaling_config,
                model_path=args.model_path,
                tiktoken_cache_dir=args.tiktoken_cache_dir,
                health_check_timeout_s=args.health_check_timeout_s,
            )
        )
        success_code = 0 if result_dict["metrics"]["is_success"] else 1
    finally:
        write_benchmark_results(result_dict, args.benchmark_results_path, save_tasks=save_tasks)
    return success_code


if __name__ == "__main__":
    raise SystemExit(main())
