# Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Resample Audio Stage

Resamples audio files to a target sample rate and format.
Follows the exact pattern from NeMo Curator:
https://github.com/NVIDIA-NeMo/Curator/blob/main/nemo_curator/stages/audio/common.py

"""

import hashlib
import os
import shutil
import subprocess
import tempfile
import time
import uuid
from dataclasses import KW_ONLY, dataclass
from typing import ClassVar, Literal

import soundfile
from fsspec.core import url_to_fs
from loguru import logger

from nemo_curator.backends.base import NodeInfo, WorkerMetadata
from nemo_curator.stages.audio._agent._agent_ready import (
    AgentReady,
    ConditionalWrite,
    Gates,
    IOSpec,
    StageContract,
    StaticHints,
)
from nemo_curator.stages.audio._agent._residency import (
    InputResidency,
    cleanup_temp_files,
    drop_resident_audio,
    produce_audio_filepath,
    reject_sinkless_conversion,
    residency_read_specs,
    resident_sample_rate,
    resolve_audio_path,
    validate_audio_key_configuration,
    validate_input_residency,
)
from nemo_curator.stages.audio.common import get_audio_duration, load_audio_file
from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import AudioTask

_NAME_MAX_BYTES = 255


def _bounded_output_stem(stem: str, extension: str) -> str:
    """Keep a deterministic output component within the common POSIX NAME_MAX."""
    extension_suffix = f".{extension.lstrip('.')}"
    budget = _NAME_MAX_BYTES - len(extension_suffix.encode("utf-8"))
    encoded = str(stem).encode("utf-8")
    if len(encoded) <= budget:
        return str(stem)
    digest = hashlib.sha256(encoded).hexdigest()[:16]
    marker = f"~{digest}"
    encoded = encoded[: budget - len(marker)]
    while True:
        try:
            prefix = encoded.decode("utf-8")
            break
        except UnicodeDecodeError:
            encoded = encoded[:-1]
    return f"{prefix}{marker}"


def _is_usable_sample_rate(value: object) -> bool:
    """Apply the same lossless rate validation as resident audio resolution."""
    try:
        resident_sample_rate(value, sample_rate_key="sample_rate", stage_name="ResampleAudioStage")
    except ValueError:
        return False
    return True


@dataclass
class ResampleAudioStage(AgentReady, ProcessingStage[AudioTask, AudioTask]):
    """
    Stage for resampling audio files in a TTS/ALM dataset.

    Takes a manifest containing audio file paths and resamples them to
    target sample rate and format, while creating a new manifest with
    updated paths.

    ``target_codec="pcm_f32le"`` preserves floating-point samples in WAV
    intermediates; the default remains signed 16-bit PCM.

    """

    AGENT_STATIC: ClassVar[StaticHints] = StaticHints(
        gates=Gates(
            writes_to_disk=True,
            requires_ffmpeg=True,
            output_path_params=["resampled_audio_dir"],
            per_row_independent=False,
        )
    )

    # Processing parameters (legacy positional order preserved)
    resampled_audio_dir: str
    input_format: str = "wav"
    target_sample_rate: int = 16000
    target_format: str = "wav"
    target_nchannels: int = 1

    # Key names (legacy positional slots)
    audio_filepath_key: str = "audio_filepath"
    resampled_audio_filepath_key: str = "resampled_audio_filepath"
    duration_key: str = "duration"
    audio_item_id_key: str = "audio_item_id"

    # Stage metadata (legacy positional slot)
    name: str = "ResampleAudio"

    # Agent-added knobs are keyword-only (KW_ONLY sentinel) so the legacy positional
    # slots above keep their historical order and meaning.
    _: KW_ONLY
    target_codec: Literal["pcm_s16le", "pcm_f32le"] = "pcm_s16le"
    waveform_key: str = "waveform"
    sample_rate_key: str = "sample_rate"
    original_audio_filepath_key: str = "original_audio_filepath"
    input_residency: InputResidency = "file"
    keep_waveform_in_task: bool = False
    write_to_disk: bool = True
    update_audio_filepath: bool = False

    def __post_init__(self) -> None:
        if self.target_codec not in {"pcm_s16le", "pcm_f32le"}:
            msg = "target_codec must be pcm_s16le or pcm_f32le"
            raise ValueError(msg)
        validate_audio_key_configuration(
            type(self).__name__,
            input_keys={
                "waveform_key": self.waveform_key,
                "sample_rate_key": self.sample_rate_key,
            },
            output_keys={},
        )
        # New resident/provenance roles cannot overwrite legacy metadata or paths.
        legacy_keys = {
            self.audio_filepath_key,
            self.resampled_audio_filepath_key,
            self.duration_key,
            self.audio_item_id_key,
        }
        if (self.keep_waveform_in_task or self.input_residency != "file") and {
            self.waveform_key,
            self.sample_rate_key,
        } & legacy_keys:
            msg = "waveform_key and sample_rate_key must be distinct from metadata and path keys"
            raise ValueError(msg)
        if self.update_audio_filepath and self.original_audio_filepath_key in {
            *legacy_keys,
            self.waveform_key,
            self.sample_rate_key,
        }:
            msg = "original_audio_filepath_key must be distinct from active output keys"
            raise ValueError(msg)
        validate_input_residency(self.input_residency, stage_name=type(self).__name__)
        reject_sinkless_conversion(
            stage=type(self).__name__,
            keep_waveform_in_task=self.keep_waveform_in_task,
            write_to_disk=self.write_to_disk,
            update_audio_filepath=self.update_audio_filepath,
        )

    def setup_on_node(
        self, _node_info: NodeInfo | None = None, _worker_metadata: WorkerMetadata | None = None
    ) -> None:
        if not shutil.which("ffmpeg"):
            msg = (
                "ResampleAudioStage requires 'ffmpeg' on PATH on every executor node. "
                "Without root access, install it with 'conda install -c conda-forge ffmpeg' "
                "and activate that environment before starting workers."
            )
            raise RuntimeError(msg)
        if self.write_to_disk:
            fs, path = url_to_fs(self.resampled_audio_dir)
            fs.makedirs(path, exist_ok=True)

    def inputs(self) -> tuple[list[str], list[str]]:
        return [], [self.audio_filepath_key]

    def input_spec_for_task(self, task: AudioTask) -> tuple[list[str], list[str]]:
        attrs, keys = super().input_spec_for_task(task)
        if self.input_residency == "waveform" or (self.input_residency == "auto" and self._has_resident_audio(task)):
            keys = [key for key in keys if key != self.audio_filepath_key]
            keys.extend([self.waveform_key, self.sample_rate_key])
        return attrs, keys

    def _has_resident_audio(self, task: AudioTask) -> bool:
        return task.data.get(self.waveform_key) is not None and _is_usable_sample_rate(
            task.data.get(self.sample_rate_key)
        )

    def validate_input(self, task: AudioTask) -> bool:
        if not super().validate_input(task):
            return False
        if self.input_residency == "waveform":
            return self._has_resident_audio(task)
        if self.input_residency == "auto" and self._has_resident_audio(task):
            return True
        return bool(task.data.get(self.audio_filepath_key))

    def outputs(self) -> tuple[list[str], list[str]]:
        # Keep the pre-PR public tuple (audio_filepath, audio_item_id, resampled_audio_filepath,
        # duration) for the default/file-compatible route, since the runtime preserves those
        # keys, and extend it for the newer resident/rename sink modes.
        outputs = [self.audio_filepath_key, self.audio_item_id_key]
        if self.write_to_disk:
            outputs.append(self.resampled_audio_filepath_key)
        outputs.append(self.duration_key)
        if self.keep_waveform_in_task:
            outputs.extend([self.waveform_key, self.sample_rate_key])
        if self.update_audio_filepath:
            outputs.append(self.original_audio_filepath_key)
        return [], outputs

    def describe(self) -> StageContract:
        writes = [self.audio_item_id_key, self.duration_key]
        produces = []
        conditional_writes = []
        if self.write_to_disk:
            writes.append(self.resampled_audio_filepath_key)
            produces.append("disk")
        if self.keep_waveform_in_task:
            writes.extend([self.waveform_key, self.sample_rate_key])
            produces.append("tensor")
        if self.update_audio_filepath:
            writes.append(self.audio_filepath_key)
            conditional_writes.append(
                ConditionalWrite(
                    writes=IOSpec(data_keys=[self.original_audio_filepath_key]),
                    condition=(
                        f"'{self.audio_filepath_key}' exists and "
                        f"'{self.original_audio_filepath_key}' is not already present"
                    ),
                )
            )
        return StageContract(
            reads_one_of=residency_read_specs(
                self.input_residency,
                audio_filepath_key=self.audio_filepath_key,
                waveform_key=self.waveform_key,
                sample_rate_key=self.sample_rate_key,
            ),
            writes=IOSpec(data_keys=writes, produces=produces),
            # Only a resident-source config (waveform/auto) supersedes and drops the resident
            # pair. The legacy file route never touches it, so its contract stays empty.
            removes_keys=(
                [self.waveform_key, self.sample_rate_key]
                if self.write_to_disk and not self.keep_waveform_in_task and self.input_residency != "file"
                else []
            ),
            conditional_writes=conditional_writes,
            gates=Gates(
                writes_to_disk=self.write_to_disk,
                requires_ffmpeg=True,
                output_path_params=["resampled_audio_dir"] if self.write_to_disk else [],
                # Inherited ids claim a shared output namespace, so filenames can depend on
                # the other rows already processed. Memory-only conversions have no such claim.
                per_row_independent=not self.write_to_disk,
            ),
        )

    def _audio_digest(self, local_audio_path: str) -> str:
        """A short digest of this audio and the settings about to be applied to it."""
        digest = hashlib.sha256()
        # FLOAT WAV headers contain a PEAK timestamp; hash samples and their layout
        # rather than container metadata so identical resident audio stays identical.
        with soundfile.SoundFile(local_audio_path) as audio:
            digest.update(f"|{audio.samplerate}|{audio.channels}".encode())
            for chunk in audio.blocks(blocksize=(1 << 18) // audio.channels, dtype="float32", always_2d=True):
                digest.update(chunk.tobytes())
        digest.update(f"|{self.target_sample_rate}|{self.target_nchannels}|{self.target_format}".encode())
        return digest.hexdigest()[:16]

    def _item_id(self, local_audio_path: str, *, from_scratch_file: bool, source: str | None) -> str:
        """The output filename for a row that does not already carry an id.

        A real input path is stable across runs, so it can name the output. A scratch path
        materialised from a waveform is not: naming a persistent output after it made every run
        write a fresh set of files (measured: 129 on disk against 65 manifest rows). So hash the
        audio instead, which is the identity the path was standing in for -- and folding in the
        settings makes the "already converted, skip it" check below correct, not merely fast.

        The path branch uses a 128-bit suffix. The former eight-character suffix had known
        collisions, allowing two same-length recordings to share and reuse one output.
        """
        if not from_scratch_file:
            stem = os.path.splitext(os.path.basename(local_audio_path))[0]
            item_id = f"{stem}_{hashlib.sha256(local_audio_path.encode()).hexdigest()[:32]}"
            return _bounded_output_stem(item_id, self.target_format)
        # Keep the source name on the front so a clip stays traceable by eye.
        stem = os.path.splitext(os.path.basename(str(source)))[0] if source else "clip"
        return _bounded_output_stem(f"{stem}_{self._audio_digest(local_audio_path)}", self.target_format)

    def _claim_inherited_stem(self, output_stem: str, local_audio_path: str) -> str:
        """Claim the legacy stem durably, suffixing it when another source owns it."""
        os.makedirs(self.resampled_audio_dir, exist_ok=True)
        output_stem = _bounded_output_stem(output_stem, self.target_format)
        owner_name = hashlib.sha256(output_stem.encode("utf-8")).hexdigest()
        owner_path = os.path.join(self.resampled_audio_dir, f".resample-owner-{owner_name}")
        legacy_path = os.path.join(self.resampled_audio_dir, f"{output_stem}.{self.target_format}")
        source_token = hashlib.sha256(os.path.abspath(local_audio_path).encode("utf-8")).hexdigest()

        if os.path.exists(legacy_path) and not os.path.exists(owner_path):
            owner = None
        else:
            try:
                fd = os.open(owner_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            except FileExistsError:
                try:
                    with open(owner_path, encoding="utf-8") as owner_file:
                        owner = owner_file.read().strip()
                except OSError:
                    owner = None
            else:
                with os.fdopen(fd, "w", encoding="utf-8") as owner_file:
                    owner_file.write(source_token + "\n")
                    owner_file.flush()
                    os.fsync(owner_file.fileno())
                owner = source_token

        if owner == source_token:
            return output_stem
        digest = hashlib.sha256(local_audio_path.encode()).hexdigest()[:16]
        logger.warning(
            f"[{self.name}] {self.audio_item_id_key}={output_stem!r} is already owned by another "
            f"source; writing {local_audio_path!r} with source suffix {digest}"
        )
        return _bounded_output_stem(f"{output_stem}_{digest}", self.target_format)

    # Resampling may land a handful of frames off the exact ratio; anything beyond this is a
    # different recording or a truncated one, never a rounding artefact.
    _FRAME_TOLERANCE_FLOOR = 64
    _FRAME_TOLERANCE_RATIO = 0.01

    def _matches_target(self, path: str, input_audio_path: str | None = None) -> bool:
        """Whether the file at the output path really holds the conversion asked for.

        The file-route name carries the source path, never the settings, so a name hit is not
        evidence the work is done: a second run at a different ``target_sample_rate`` used to skip
        and serve the old rate, with the duration measured off the stale file. Reading the header
        is free beside spawning ffmpeg.

        The header alone is not enough either: a WAV truncated by a killed writer -- or one that
        is a complete conversion of a DIFFERENT recording that happened to claim the same output
        name -- keeps a valid header at the right rate and channel count. So when the source is
        readable, the frame count must also agree with the source's length at the target rate
        (within resampling tolerance); otherwise the file is converted again.
        """
        try:
            info = soundfile.info(path)
        except Exception:  # noqa: BLE001 - unreadable or not-audio -> convert it again
            return False
        expected_subtype = "FLOAT" if self.target_codec == "pcm_f32le" else "PCM_16"
        if info.subtype != expected_subtype:
            return False
        if info.samplerate != self.target_sample_rate or info.channels != self.target_nchannels:
            return False
        if input_audio_path is None:
            return True
        try:
            source = soundfile.info(input_audio_path)
        except Exception:  # noqa: BLE001 - a source libsndfile cannot read (e.g. mp3): header check only
            return True
        expected_frames = round(source.frames * self.target_sample_rate / source.samplerate)
        tolerance = max(self._FRAME_TOLERANCE_FLOOR, int(expected_frames * self._FRAME_TOLERANCE_RATIO))
        return abs(info.frames - expected_frames) <= tolerance

    def process(self, task: AudioTask) -> AudioTask:
        """
        Process a single task by resampling the audio file.

        Args:
            task: AudioTask with data dict containing audio_filepath and audio_item_id(optional)

        Returns:
            AudioTask with updated metadata
        """
        t0 = time.perf_counter()
        temp_paths: list[str] = []
        try:
            return self._process_with_resolved_audio(task, temp_paths=temp_paths, started_at=t0)
        finally:
            # Resolution may materialize a resident waveform before any later
            # validation, hashing, or output-path operation raises.
            cleanup_temp_files(temp_paths)

    def _process_with_resolved_audio(
        self,
        task: AudioTask,
        *,
        temp_paths: list[str],
        started_at: float,
    ) -> AudioTask:
        """Resolve, name, and convert one row while ``process`` owns scratch cleanup."""
        data_entry = task.data
        input_audio_path = resolve_audio_path(
            data_entry,
            residency=self.input_residency,  # type: ignore[arg-type]
            audio_filepath_key=self.audio_filepath_key,
            waveform_key=self.waveform_key,
            sample_rate_key=self.sample_rate_key,
            register_temp=temp_paths,
        )
        if input_audio_path is None:
            msg = "Audio file path or waveform/sample_rate is required"
            raise ValueError(msg)

        original_audio_filepath = data_entry.get(self.audio_filepath_key)
        _, local_audio_path = url_to_fs(input_audio_path)
        inherited_id = self.audio_item_id_key in data_entry
        if not inherited_id:
            data_entry[self.audio_item_id_key] = self._item_id(
                local_audio_path,
                from_scratch_file=bool(temp_paths),
                source=original_audio_filepath,
            )
        output_stem = data_entry[self.audio_item_id_key]
        if inherited_id and temp_paths:
            # A fan-out gives every child the parent's id, so an inherited id is not a filename:
            # 26 VAD segments of utt1.wav once collapsed onto one, with all 26 rows pointing at
            # the survivor. The FILE takes a digest; the row keeps the id its producer gave it,
            # which downstream stages read as the shared ``item_id`` role.
            output_stem = f"{output_stem}_{self._audio_digest(local_audio_path)}"
        elif inherited_id and self.write_to_disk:
            output_stem = self._claim_inherited_stem(str(output_stem), local_audio_path)

        output_stem = _bounded_output_stem(str(output_stem), self.target_format)

        if self.write_to_disk:
            output_audio_path = os.path.join(
                self.resampled_audio_dir,
                output_stem + "." + self.target_format,
            )
        else:
            fd, output_audio_path = tempfile.mkstemp(suffix=f".{self.target_format}")
            os.close(fd)

        if self.write_to_disk:
            return self._convert_and_update(
                task,
                input_audio_path=local_audio_path,
                output_audio_path=output_audio_path,
                original_audio_filepath=original_audio_filepath,
                started_at=started_at,
            )

        try:
            return self._convert_and_update(
                task,
                input_audio_path=local_audio_path,
                output_audio_path=output_audio_path,
                original_audio_filepath=original_audio_filepath,
                started_at=started_at,
            )
        finally:
            cleanup_temp_files([output_audio_path])

    def _convert_and_update(
        self,
        task: AudioTask,
        *,
        input_audio_path: str,
        output_audio_path: str,
        original_audio_filepath: str | None,
        started_at: float,
    ) -> AudioTask:
        """Convert one resolved input and update its task metadata."""
        data_entry = task.data

        # Convert audio file if not already done
        fs, output_path = url_to_fs(output_audio_path)
        skipped_conversion = (
            self.write_to_disk and fs.exists(output_path) and self._matches_target(output_path, input_audio_path)
        )
        if not skipped_conversion:
            # ffmpeg used to write straight to the deliverable. That was survivable while every
            # run picked a new output name, but the name is stable now, so a run killed mid-write
            # leaves a stump the NEXT run finds -- and a truncated WAV keeps a valid header, so
            # the skip above waves it through and a fragment's duration lands in the manifest.
            # Convert in the destination directory for atomic replacement. The temporary
            # basename is independent of the final name so it also fits filesystem limits.
            staging_dir = os.path.dirname(output_audio_path)
            if staging_dir:
                # setup_on_node makes this, but process() must not depend on having been through it.
                os.makedirs(staging_dir, exist_ok=True)
            output_extension = os.path.splitext(output_audio_path)[1]
            temporary_audio_path = os.path.join(staging_dir, f".resample-{uuid.uuid4().hex}.tmp{output_extension}")
            cmd = [
                "ffmpeg",
                "-y",
                "-v",
                "error",
                "-i",
                input_audio_path,
                "-ar",
                str(self.target_sample_rate),
                "-ac",
                str(self.target_nchannels),
                "-acodec",
                self.target_codec,
                temporary_audio_path,
            ]

            try:
                subprocess.run(cmd, check=True, capture_output=True, text=True)  # noqa: S603
                os.replace(temporary_audio_path, output_audio_path)
            except subprocess.CalledProcessError as e:
                msg = f"Error converting {input_audio_path}: {e}"
                raise RuntimeError(msg) from e
            finally:
                cleanup_temp_files([temporary_audio_path])

        # Update metadata — preserve original URL for cloud paths.
        if original_audio_filepath is not None:
            data_entry[self.audio_filepath_key] = original_audio_filepath
        if self.write_to_disk:
            data_entry[self.resampled_audio_filepath_key] = output_audio_path
            if self.update_audio_filepath:
                produce_audio_filepath(
                    data_entry,
                    output_audio_path,
                    key=self.audio_filepath_key,
                    original_key=self.original_audio_filepath_key,
                )
        if self.keep_waveform_in_task:
            waveform, sample_rate = load_audio_file(output_audio_path, mono=False)
            data_entry[self.waveform_key] = waveform
            data_entry[self.sample_rate_key] = sample_rate
        elif self.write_to_disk and self.input_residency != "file":
            # Auto fallback may leave an incomplete resident pair. Disk-only non-file routes
            # remove it too; the legacy file route preserves its upstream fields.
            drop_resident_audio(
                data_entry,
                waveform_key=self.waveform_key,
                sample_rate_key=self.sample_rate_key,
            )
        duration = get_audio_duration(output_audio_path)
        data_entry[self.duration_key] = duration

        self._log_metrics(
            {
                "process_time": time.perf_counter() - started_at,
                "duration": max(duration, 0.0),
                "skipped_conversion": float(skipped_conversion),
            }
        )
        return task
