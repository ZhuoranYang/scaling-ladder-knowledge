# Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""TorchSQUIM audio quality metrics stage (PESQ, STOI, SI-SDR)."""

import math
from dataclasses import dataclass, field
from typing import Any, ClassVar

import librosa
import soundfile as sf
import torch
import torchaudio.functional as torchaudio_F  # noqa: N812
from loguru import logger
from torchaudio.pipelines import SQUIM_OBJECTIVE

from nemo_curator.backends.base import NodeInfo, WorkerMetadata
from nemo_curator.stages.audio._agent._agent_ready import (
    AgentReady,
    ConditionalRead,
    ConditionalWrite,
    Gates,
    IOSpec,
    StageContract,
    StaticHints,
)
from nemo_curator.stages.audio._agent._residency import (
    InputResidency,
    residency_read_specs,
    validate_input_residency,
)
from nemo_curator.stages.audio.metrics._common import (
    metrics_mapping,
    resident_pair_is_complete,
    resident_pcm_to_mono_float32,
    resident_sample_rate,
    validate_metric_keys,
)
from nemo_curator.stages.base import ProcessingStage
from nemo_curator.stages.resources import Resources
from nemo_curator.tasks import AudioTask


@dataclass
class TorchSquimQualityMetricsStage(AgentReady, ProcessingStage[AudioTask, AudioTask]):
    """
    Stage that calculates Squim quality metrics for audio files.

    Uses a pre-trained Squim model to calculate audio quality metrics like
    PESQ, STOI, and SI-SDR for each audio segment.

    Args:
        audio_filepath_key: Key for the audio file path in the manifest. Defaults to "resampled_audio_filepath".
        target_sr: Target sample rate for SQUIM model input. Defaults to 16000.
        batch_size: Number of audio tasks to be processed at once. Defaults to 32.
        compute_batch_size: Number of waveforms to process per GPU inference call. Defaults to 32.
        segments_key: Key for the segments in the manifest. Defaults to "segments".
        metrics_key: Key for the output metrics mapping. Defaults to "metrics".
        waveform_key: Key for an in-memory waveform tensor. Defaults to "waveform".
        sample_rate_key: Key for the in-memory waveform sample rate. Defaults to "sample_rate".
        input_residency: Which input to use — "file" (audio_filepath only; default, unchanged),
            "waveform" (in-memory only), or "auto" (a complete waveform/sample-rate
            pair first, file fallback). Incomplete resident pairs are rejected.

    Returns:
        The same data as in the input data, but with Squim quality metrics added to each segment.
    """

    audio_filepath_key: str = "resampled_audio_filepath"
    target_sr: int = 16000
    batch_size: int = 32
    compute_batch_size: int = 32
    segments_key: str = "segments"
    metrics_key: str = field(default="metrics", kw_only=True)
    waveform_key: str = field(default="waveform", kw_only=True)
    sample_rate_key: str = field(default="sample_rate", kw_only=True)
    input_residency: InputResidency = field(default="file", kw_only=True)

    # Stage metadata
    name: str = "TorchSquimQualityMetrics"
    BATCH_ONLY = True  # process() raises; only process_batch is implemented (agent-discovery hint)
    AGENT_STATIC: ClassVar[StaticHints] = StaticHints(
        gates=Gates(
            requires_internet_first_run=True,
            per_row_independent=False,
        )
    )
    resources: Resources = field(default_factory=lambda: Resources(gpus=1.0))

    model: Any = field(default=None, repr=False, metadata={"agent_param": False})

    def __post_init__(self) -> None:
        validate_input_residency(self.input_residency, stage_name=self.name)
        validate_metric_keys(
            self.name,
            keys={
                "audio_filepath_key": self.audio_filepath_key,
                "segments_key": self.segments_key,
                "metrics_key": self.metrics_key,
                "waveform_key": self.waveform_key,
                "sample_rate_key": self.sample_rate_key,
            },
            strict_fields=(
                "metrics_key",
                "waveform_key",
                "sample_rate_key",
            ),
        )

    def inputs(self) -> tuple[list[str], list[str]]:
        return [], []

    def outputs(self) -> tuple[list[str], list[str]]:
        return [], [self.metrics_key]

    def describe(self) -> StageContract:
        # An audio source (file or in-memory waveform, per input_residency) is required;
        # segments only refine WHERE metrics are attached (optional, read at runtime).
        reads_one_of = residency_read_specs(
            self.input_residency,
            audio_filepath_key=self.audio_filepath_key,
            waveform_key=self.waveform_key,
            sample_rate_key=self.sample_rate_key,
        )
        conditional_reads = []
        if self.input_residency == "auto":
            resident_options = residency_read_specs(
                "waveform",
                audio_filepath_key=self.audio_filepath_key,
                waveform_key=self.waveform_key,
                sample_rate_key=self.sample_rate_key,
            )
            file_options = residency_read_specs(
                "file",
                audio_filepath_key=self.audio_filepath_key,
                waveform_key=self.waveform_key,
                sample_rate_key=self.sample_rate_key,
            )
            reads_one_of = []
            conditional_reads = [
                ConditionalRead(
                    reads_one_of=resident_options,
                    condition="a complete resident waveform/sample-rate pair is present",
                    requires_keys=[self.waveform_key, self.sample_rate_key],
                ),
                ConditionalRead(
                    reads_one_of=file_options,
                    condition="neither resident audio key is present, so file fallback is allowed",
                    forbids_keys=[self.waveform_key, self.sample_rate_key],
                ),
                ConditionalRead(
                    reads_one_of=resident_options,
                    condition="a waveform without its sample rate is invalid",
                    requires_keys=[self.waveform_key],
                    forbids_keys=[self.sample_rate_key],
                ),
                ConditionalRead(
                    reads_one_of=resident_options,
                    condition="a sample rate without its waveform is invalid",
                    requires_keys=[self.sample_rate_key],
                    forbids_keys=[self.waveform_key],
                ),
            ]
        return StageContract(
            reads_one_of=reads_one_of,
            conditional_reads=conditional_reads,
            writes=IOSpec(),
            conditional_writes=[
                ConditionalWrite(
                    writes=IOSpec(data_keys=[self.metrics_key]),
                    condition=(
                        f"'{self.segments_key}' is absent, top-level audio resolves to a waveform, "
                        "and whole-batch model inference completes"
                    ),
                    value_origin="augments_upstream_same_key",
                ),
                ConditionalWrite(
                    writes=IOSpec(segment_data_keys=[self.metrics_key]),
                    condition=(
                        f"'{self.segments_key}' is present; an individual segment is not marked no-speaker, "
                        "has non-blank text and a positive requested frame span, its waveform is collected, "
                        "and whole-batch model inference completes"
                    ),
                    value_origin="augments_upstream_same_key",
                ),
            ],
            gates=Gates(
                requires_gpu=self.resources.requires_gpu,
                requires_internet_first_run=True,
                # ``_compute_metrics_batched`` zero-pads each batch to its longest member and
                # calls the model with no lengths, so padding reads as silence and a clip's
                # scores depend on which clips sorted beside it. Pass lengths and this becomes True.
                per_row_independent=False,
            ),
        )

    def validate_input(self, task: AudioTask) -> bool:
        """An audio source is required; segments are optional refinement.

        When ``input_residency`` allows it, an in-memory ``waveform_key``+``sample_rate_key``
        satisfies the requirement; otherwise ``audio_filepath_key`` must be present (the
        default, unchanged behavior).
        """
        data = task.data
        try:
            self._segments_for_entry(data)
        except TypeError as error:
            logger.error(str(error))
            return False
        has_waveform = resident_pair_is_complete(
            data,
            residency=self.input_residency,
            waveform_key=self.waveform_key,
            sample_rate_key=self.sample_rate_key,
            stage_name=self.name,
        )
        has_file = self.audio_filepath_key in data
        if self.input_residency == "waveform":
            ok = has_waveform
        elif self.input_residency == "file":
            ok = has_file
        else:  # auto
            ok = has_waveform or has_file
        if ok:
            return True
        logger.error(
            f"Task {task.task_id} missing required audio input for input_residency={self.input_residency!r}: "
            f"need '{self.audio_filepath_key}' or '{self.waveform_key}'+'{self.sample_rate_key}' "
            f"(segments alone are not sufficient — SQUIM loads audio)"
        )
        return False

    def _segments_for_entry(self, data_entry: dict[str, Any]) -> list[Any] | None:
        """Return normalized nested segments, preserving key absence as top-level mode."""
        if self.segments_key not in data_entry:
            return None
        segments = data_entry[self.segments_key]
        if segments is None:
            return []
        if not isinstance(segments, list):
            msg = (
                f"[{self.name}] Segment container '{self.segments_key}' must be a list or null, "
                f"got {type(segments).__name__}"
            )
            raise TypeError(msg)
        return segments

    @property
    def _device(self) -> str:
        """Derive device from resources configuration."""
        if self.resources.requires_gpu:
            if not torch.cuda.is_available():
                msg = f"[{self.name}] GPU requested via resources but CUDA is not available."
                raise RuntimeError(msg)
            return "cuda"
        return "cpu"

    def setup_on_node(
        self, _node_info: NodeInfo | None = None, _worker_metadata: WorkerMetadata | None = None
    ) -> None:
        """Pre-download SQUIM model weights (cache warming, no GPU allocation)."""
        SQUIM_OBJECTIVE.get_model()

    def setup(self, _worker_metadata: WorkerMetadata | None = None) -> None:
        """Load model onto the target device. Called once per worker."""
        self.model = SQUIM_OBJECTIVE.get_model()
        if self._device == "cuda":
            self.model = self.model.cuda()
        logger.info(f"[{self.name}] Initialized SQUIM model on {self._device}")

    def _compute_metrics_batched(self, waveforms: list[torch.Tensor]) -> list[tuple[float, float, float]]:
        """Run SQUIM on a list of 1-D waveform tensors in batches."""
        results: list[tuple[float, float, float]] = []
        for i in range(0, len(waveforms), self.compute_batch_size):
            batch = waveforms[i : i + self.compute_batch_size]
            max_len = max(w.shape[0] for w in batch)
            padded = torch.zeros(len(batch), max_len)
            for j, w in enumerate(batch):
                padded[j, : w.shape[0]] = w
            padded = padded.to(self._device)
            with torch.no_grad():
                stoi, pesq, si_sdr = self.model(padded)
            for j in range(len(batch)):
                results.append(
                    (
                        round(pesq[j].item(), 3),
                        round(stoi[j].item(), 3),
                        round(si_sdr[j].item(), 3),
                    )
                )
        return results

    def _resolve_entry_audio(self, data_entry: dict) -> tuple[Any, int]:
        """Return ``(mono_1d_audio_ndarray, sample_rate)`` from a waveform or the file.

        When ``input_residency`` allows it and an in-memory ``waveform_key``+
        ``sample_rate_key`` is present, that waveform is used directly; otherwise the
        audio file is read at its native sample rate (the default, unchanged behavior).
        Per-segment slicing downstream is identical for either source.
        """
        if self.input_residency != "file":
            has_waveform = resident_pair_is_complete(
                data_entry,
                residency=self.input_residency,
                waveform_key=self.waveform_key,
                sample_rate_key=self.sample_rate_key,
                stage_name=self.name,
            )
            if has_waveform:
                audio = resident_pcm_to_mono_float32(data_entry[self.waveform_key], stage_name=self.name)
                sample_rate = resident_sample_rate(
                    data_entry[self.sample_rate_key],
                    sample_rate_key=self.sample_rate_key,
                    stage_name=self.name,
                )
                return audio, sample_rate
            if self.input_residency == "waveform":
                msg = (
                    f"[{self.name}] Missing '{self.waveform_key}'+'{self.sample_rate_key}' for entry: "
                    f"{data_entry.get('audio_item_id', 'unknown')} (input_residency='waveform')"
                )
                raise ValueError(msg)

        audio_path = data_entry.get(self.audio_filepath_key)
        if not audio_path:
            msg = (
                f"[{self.name}] Missing '{self.audio_filepath_key}' for entry: "
                f"{data_entry.get('audio_item_id', 'unknown')}"
            )
            raise ValueError(msg)
        try:
            info = sf.info(audio_path)
            sr = info.samplerate
        except Exception as ex:
            msg = f"[{self.name}] Failed to read audio info: {audio_path}"
            raise RuntimeError(msg) from ex
        try:
            audio, _ = librosa.load(path=audio_path, sr=sr)
        except Exception as ex:
            msg = f"[{self.name}] Failed to load audio: {audio_path}"
            raise RuntimeError(msg) from ex
        return audio, sr

    def _collect_waveforms_for_entry(self, task_idx: int, data_entry: dict) -> list[tuple[int, int, torch.Tensor]]:
        """Extract valid segment waveforms from a single audio entry.

        Returns a list of (task_idx, segment_idx, waveform) tuples.
        """
        segments = self._segments_for_entry(data_entry)
        audio, sr = self._resolve_entry_audio(data_entry)
        # Names the entry in the zero-length-segment warning below. Not the path directly:
        # ``_resolve_entry_audio`` also serves resident waveforms, which have no file, and the
        # binding it once shared with this method moved inside it when it was extracted --
        # leaving the warning referring to an ``audio_path`` that no longer existed here.
        source = data_entry.get(self.audio_filepath_key) or data_entry.get("audio_item_id", "unknown")

        collected: list[tuple[int, int, torch.Tensor]] = []
        if segments is not None:
            for seg_idx, segment in enumerate(segments):
                if not isinstance(segment, dict):
                    logger.warning(
                        f"[{self.name}] skipping malformed segment {seg_idx} in {source}: "
                        f"expected a mapping, got {type(segment).__name__}"
                    )
                    continue
                if segment.get("speaker") == "no-speaker" or segment.get("text", "").strip() == "":
                    continue

                start = segment.get("start", 0)
                end = segment.get("end", 0)
                start_frame = math.floor(start * sr)
                end_frame = math.floor(end * sr)

                if end_frame - start_frame <= 0:
                    logger.warning(f"[{self.name}] Zero-length segment at {start}-{end}s in {source}, skipping")
                    continue

                metrics_mapping(segment, metrics_key=self.metrics_key, stage_name=self.name)
                y = torch.from_numpy(audio[start_frame:end_frame])
                if sr != self.target_sr:
                    y = torchaudio_F.resample(y.unsqueeze(0), sr, self.target_sr).squeeze(0)

                collected.append((task_idx, seg_idx, y))
        else:
            metrics_mapping(data_entry, metrics_key=self.metrics_key, stage_name=self.name)
            y = torch.from_numpy(audio)
            if sr != self.target_sr:
                y = torchaudio_F.resample(y.unsqueeze(0), sr, self.target_sr).squeeze(0)
            collected.append((task_idx, -1, y))
        return collected

    def update_metrics(
        self, audio_segment: dict[str, Any], pesq_val: float, stoi_val: float, sisdr_val: float
    ) -> None:
        """Update the metrics for an audio segment."""
        metrics = metrics_mapping(audio_segment, metrics_key=self.metrics_key, stage_name=self.name)
        metrics["pesq_squim"] = pesq_val
        metrics["stoi_squim"] = stoi_val
        metrics["sisdr_squim"] = sisdr_val
        audio_segment[self.metrics_key] = metrics

    def process(self, task: AudioTask) -> AudioTask:
        """Delegate single-task processing to process_batch."""
        msg = f"[{self.name}] is a GPU/batched inference stage. Use process_batch() instead."
        raise NotImplementedError(msg)

    def process_batch(self, tasks: list[AudioTask]) -> list[AudioTask]:
        """Calculate Squim quality metrics across all tasks using batched GPU inference.

        Collects waveforms from every valid segment across all tasks, sorts them
        by duration so similarly-sized segments are padded together, runs SQUIM
        in batches on GPU, then scatters results back to the originating
        task's segment.
        """
        if len(tasks) == 0:
            return tasks

        # Collect all valid waveforms with their origin (task_idx, segment_idx)
        all_waveform_metadata: list[tuple[int, int, torch.Tensor]] = []
        for task_idx, task in enumerate(tasks):
            all_waveform_metadata.extend(self._collect_waveforms_for_entry(task_idx, task.data))

        if not all_waveform_metadata:
            logger.warning(
                f"[{self.name}] No valid waveforms collected from {len(tasks)} task(s). "
                "All tasks returned without SQUIM metrics."
            )
            return tasks

        # Sort by waveform length so similarly-sized segments share a batch
        sorted_indices = sorted(range(len(all_waveform_metadata)), key=lambda i: all_waveform_metadata[i][2].shape[0])
        sorted_waveforms = [all_waveform_metadata[i][2] for i in sorted_indices]

        try:
            sorted_results = self._compute_metrics_batched(sorted_waveforms)
            for rank, (pesq_val, stoi_val, sisdr_val) in enumerate(sorted_results):
                orig_idx = sorted_indices[rank]
                task_idx, seg_idx, _ = all_waveform_metadata[orig_idx]
                segments = self._segments_for_entry(tasks[task_idx].data)
                if segments is not None:
                    segment = segments[seg_idx]
                    self.update_metrics(segment, pesq_val, stoi_val, sisdr_val)
                else:
                    self.update_metrics(tasks[task_idx].data, pesq_val, stoi_val, sisdr_val)
        except Exception as e:
            torch.cuda.empty_cache()
            msg = f"[{self.name}] Failed to compute Squim metrics: {e}"
            raise RuntimeError(msg) from e

        return tasks
