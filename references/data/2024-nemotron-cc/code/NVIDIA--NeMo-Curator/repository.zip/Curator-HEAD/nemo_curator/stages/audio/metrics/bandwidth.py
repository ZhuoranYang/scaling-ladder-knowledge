# Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Bandwidth estimation stage."""

from dataclasses import dataclass, field
from typing import Any

import librosa
import numpy as np
from loguru import logger

from nemo_curator.stages.audio._agent._agent_ready import (
    AgentReady,
    ConditionalRead,
    ConditionalWrite,
    Gates,
    IOSpec,
    StageContract,
)
from nemo_curator.stages.audio._agent._residency import (
    InputResidency,
    residency_read_specs,
    validate_input_residency,
)
from nemo_curator.stages.audio.metrics._common import (
    metrics_mapping,
    resident_pair_is_complete,
    resident_pcm_to_mono_float32,
    resident_sample_rate,
    validate_metric_keys,
)
from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import AudioTask


@dataclass
class BandwidthEstimationStage(AgentReady, ProcessingStage[AudioTask, AudioTask]):
    """
    Stage that estimates audio bandwidth by analyzing power spectra.

    Analyzes audio files to estimate their effective bandwidth by examining
    the power spectrum and determining the highest frequency with significant
    energy content above a threshold.

    Args:
        n_fft: Size of FFT window. Defaults to 512.
        stride_seconds: Time between successive FFT windows in seconds. Defaults to 0.01.
        top_db: Maximum decibel value for power spectrum normalization. Defaults to 100.0.
        frequency_threshold: Threshold in dB below peak for bandwidth estimation. Defaults to -50.0.
        audio_filepath_key: Key for the audio file path in the manifest. Defaults to "audio_filepath".
        segments_key: Key for the segments in the manifest. Defaults to "segments".
        duration_key: Configurable duration fallback used when "end" is absent. Defaults to "duration".
        metrics_key: Key for the output metrics mapping. Defaults to "metrics".
        waveform_key: Key for an in-memory waveform tensor. Defaults to "waveform".
        sample_rate_key: Key for the in-memory waveform sample rate. Defaults to "sample_rate".
        input_residency: Which input to use — "file" (audio_filepath only; default, unchanged),
            "waveform" (in-memory only), or "auto" (a complete waveform/sample-rate
            pair first, file fallback). Incomplete resident pairs are rejected.

    Returns:
        The same data as in the input data, but with bandwidth estimates added to each segment.
    """

    n_fft: int = 512
    stride_seconds: float = 0.01
    top_db: float = 100.0
    frequency_threshold: float = -50.0
    audio_filepath_key: str = "audio_filepath"
    segments_key: str = "segments"
    duration_key: str = field(default="duration", kw_only=True)
    metrics_key: str = field(default="metrics", kw_only=True)
    waveform_key: str = field(default="waveform", kw_only=True)
    sample_rate_key: str = field(default="sample_rate", kw_only=True)
    input_residency: InputResidency = field(default="file", kw_only=True)

    # Stage metadata
    name: str = "BandwidthEstimation"

    def __post_init__(self) -> None:
        validate_input_residency(self.input_residency, stage_name=self.name)
        validate_metric_keys(
            self.name,
            keys={
                "audio_filepath_key": self.audio_filepath_key,
                "segments_key": self.segments_key,
                "duration_key": self.duration_key,
                "metrics_key": self.metrics_key,
                "waveform_key": self.waveform_key,
                "sample_rate_key": self.sample_rate_key,
            },
            strict_fields=(
                "duration_key",
                "metrics_key",
                "waveform_key",
                "sample_rate_key",
            ),
        )

    def inputs(self) -> tuple[list[str], list[str]]:
        return [], [self.audio_filepath_key]

    def outputs(self) -> tuple[list[str], list[str]]:
        return [], [self.audio_filepath_key, self.metrics_key]

    def describe(self) -> StageContract:
        # An audio source (file or in-memory waveform, per input_residency) AND
        # (segments OR duration). Each audio-source shape is paired with both refinements.
        def with_refinements(specs: list[IOSpec]) -> list[IOSpec]:
            options = []
            for spec in specs:
                options.append(IOSpec(data_keys=[*spec.data_keys, self.segments_key], accepts=list(spec.accepts)))
                options.append(IOSpec(data_keys=[*spec.data_keys, self.duration_key], accepts=list(spec.accepts)))
            return options

        reads_one_of = with_refinements(
            residency_read_specs(
                self.input_residency,
                audio_filepath_key=self.audio_filepath_key,
                waveform_key=self.waveform_key,
                sample_rate_key=self.sample_rate_key,
            )
        )
        conditional_reads = []
        if self.input_residency == "auto":
            resident_options = with_refinements(
                residency_read_specs(
                    "waveform",
                    audio_filepath_key=self.audio_filepath_key,
                    waveform_key=self.waveform_key,
                    sample_rate_key=self.sample_rate_key,
                )
            )
            file_options = with_refinements(
                residency_read_specs(
                    "file",
                    audio_filepath_key=self.audio_filepath_key,
                    waveform_key=self.waveform_key,
                    sample_rate_key=self.sample_rate_key,
                )
            )
            reads_one_of = []
            conditional_reads = [
                ConditionalRead(
                    reads_one_of=resident_options,
                    condition="a complete resident waveform/sample-rate pair is present",
                    requires_keys=[self.waveform_key, self.sample_rate_key],
                ),
                ConditionalRead(
                    reads_one_of=file_options,
                    condition="neither resident audio key is present, so file fallback is allowed",
                    forbids_keys=[self.waveform_key, self.sample_rate_key],
                ),
                ConditionalRead(
                    reads_one_of=resident_options,
                    condition="a waveform without its sample rate is invalid",
                    requires_keys=[self.waveform_key],
                    forbids_keys=[self.sample_rate_key],
                ),
                ConditionalRead(
                    reads_one_of=resident_options,
                    condition="a sample rate without its waveform is invalid",
                    requires_keys=[self.sample_rate_key],
                    forbids_keys=[self.waveform_key],
                ),
            ]
        return StageContract(
            reads_one_of=reads_one_of,
            conditional_reads=conditional_reads,
            writes=IOSpec(),
            conditional_writes=[
                ConditionalWrite(
                    writes=IOSpec(data_keys=[self.metrics_key]),
                    condition=(
                        f"audio resolves, '{self.segments_key}' is absent, the top-level item is not skipped "
                        "for speaker/text, its time range is valid, and bandwidth estimation completes"
                    ),
                    value_origin="augments_upstream_same_key",
                ),
                ConditionalWrite(
                    writes=IOSpec(segment_data_keys=[self.metrics_key]),
                    condition=(
                        f"audio resolves, '{self.segments_key}' is present, and an individual segment is not "
                        "skipped for speaker/text, has a valid range, and bandwidth estimation completes"
                    ),
                    value_origin="augments_upstream_same_key",
                ),
                ConditionalWrite(
                    writes=IOSpec(segment_data_keys=[self.metrics_key]),
                    condition=(
                        f"'{self.segments_key}' is present, an individual segment raises a caught ValueError, "
                        f"and '{self.metrics_key}.metric_skip_reason' is assigned"
                    ),
                    value_origin="augments_upstream_same_key",
                ),
            ],
            # The threshold is measured against the peak of this clip's own power spectrum, not
            # against a level taken over the corpus.
            gates=Gates(per_row_independent=True),
        )

    def validate_input(self, task: AudioTask) -> bool:
        """Needs an audio source AND (segments OR duration).

        The audio source is ``audio_filepath_key`` (default) or, when ``input_residency``
        allows it, an in-memory ``waveform_key``+``sample_rate_key``.
        """
        data = task.data
        try:
            segments = self._segments_for_entry(data)
        except TypeError as error:
            logger.error(str(error))
            return False
        has_waveform = resident_pair_is_complete(
            data,
            residency=self.input_residency,
            waveform_key=self.waveform_key,
            sample_rate_key=self.sample_rate_key,
            stage_name=self.name,
        )
        has_file = self.audio_filepath_key in data
        if self.input_residency == "waveform":
            has_audio = has_waveform
        elif self.input_residency == "file":
            has_audio = has_file
        else:  # auto
            has_audio = has_waveform or has_file
        if not has_audio:
            logger.error(
                f"Task {task.task_id} missing audio input for input_residency={self.input_residency!r}: "
                f"need '{self.audio_filepath_key}' or '{self.waveform_key}'+'{self.sample_rate_key}'"
            )
            return False
        if segments is not None or self.duration_key in data:
            return True
        logger.error(
            f"Task {task.task_id} missing required attributes: need '{self.segments_key}' OR '{self.duration_key}'"
        )
        return False

    def _segments_for_entry(self, data_entry: dict[str, Any]) -> list[Any] | None:
        """Return normalized nested segments, preserving key absence as top-level mode."""
        if self.segments_key not in data_entry:
            return None
        segments = data_entry[self.segments_key]
        if segments is None:
            return []
        if not isinstance(segments, list):
            msg = (
                f"[{self.name}] Segment container '{self.segments_key}' must be a list or null, "
                f"got {type(segments).__name__}"
            )
            raise TypeError(msg)
        return segments

    def _estimate_bandwidth(self, audio: "np.ndarray", sample_rate: int) -> int:
        """Estimate the bandwidth of an audio signal."""
        hop_length = int(sample_rate * self.stride_seconds)

        spec = librosa.stft(y=audio, n_fft=self.n_fft, hop_length=hop_length, window="blackmanharris")
        power_spec = np.abs(spec) ** 2
        power_spec = np.mean(power_spec, axis=1)
        power_spec = librosa.power_to_db(power_spec, ref=self.n_fft, top_db=self.top_db)

        bandwidth = 0
        peak = np.max(power_spec)
        freq_width = sample_rate / self.n_fft

        for idx in range(len(power_spec) - 1, -1, -1):
            if power_spec[idx] - peak > self.frequency_threshold:
                bandwidth = idx * freq_width
                break

        return bandwidth

    def get_bandwidth(self, audio_segment: dict[str, Any], audio: "np.ndarray", sample_rate: int) -> None:
        """Get bandwidth, using ``duration_key`` when the segment has no ``end``."""
        segment_speaker = audio_segment.get("speaker")
        segment_text = audio_segment.get("text")

        if (segment_speaker is not None and segment_speaker == "no-speaker") or (
            segment_text is not None and segment_text.strip() == ""
        ):
            return

        metrics = metrics_mapping(audio_segment, metrics_key=self.metrics_key, stage_name=self.name)
        start = audio_segment.get("start", 0.0)
        end = audio_segment.get("end", audio_segment.get(self.duration_key, 0.0))
        if end is None or start >= end:
            msg = f"[{self.name}] Invalid segment time range: start={start}, end={end}"
            raise ValueError(msg)

        segment_audio_array = audio[int(start * sample_rate) : int(end * sample_rate)]
        bandwidth = self._estimate_bandwidth(segment_audio_array, sample_rate)

        metrics["bandwidth"] = int(bandwidth)
        audio_segment[self.metrics_key] = metrics

    def _resolve_entry_audio(self, data_entry: dict[str, Any]) -> tuple["np.ndarray", int]:
        """Return ``(mono_1d_audio, sample_rate)`` from a waveform or the file.

        When ``input_residency`` allows it and an in-memory waveform is present, it is used
        directly; otherwise the audio file is loaded at its native rate (default, unchanged).
        """
        if self.input_residency != "file":
            has_waveform = resident_pair_is_complete(
                data_entry,
                residency=self.input_residency,
                waveform_key=self.waveform_key,
                sample_rate_key=self.sample_rate_key,
                stage_name=self.name,
            )
            if has_waveform:
                audio = resident_pcm_to_mono_float32(data_entry[self.waveform_key], stage_name=self.name)
                sample_rate = resident_sample_rate(
                    data_entry[self.sample_rate_key],
                    sample_rate_key=self.sample_rate_key,
                    stage_name=self.name,
                )
                return audio, sample_rate
            if self.input_residency == "waveform":
                msg = (
                    f"[{self.name}] Missing '{self.waveform_key}'+'{self.sample_rate_key}' for entry: "
                    f"{data_entry.get('audio_item_id', 'unknown')} (input_residency='waveform')"
                )
                raise ValueError(msg)
        audio_path = data_entry.get(self.audio_filepath_key)
        if not audio_path:
            msg = (
                f"[{self.name}] Missing '{self.audio_filepath_key}' for entry: "
                f"{data_entry.get('audio_item_id', 'unknown')}"
            )
            raise ValueError(msg)
        try:
            audio, sample_rate = librosa.load(path=audio_path, sr=None)
        except Exception as ex:
            msg = f"[{self.name}] Failed to load audio: {audio_path}"
            raise RuntimeError(msg) from ex
        return audio, sample_rate

    def process(self, task: AudioTask) -> AudioTask:
        """Estimate bandwidth for audio entry."""
        data_entry = task.data
        segments = self._segments_for_entry(data_entry)
        audio, sample_rate = self._resolve_entry_audio(data_entry)

        if segments is not None:
            for segment_index, segment in enumerate(segments):
                if not isinstance(segment, dict):
                    logger.warning(
                        f"[{self.name}] skipping malformed segment {segment_index} in {task.task_id}: "
                        f"expected a mapping, got {type(segment).__name__}"
                    )
                    continue
                try:
                    self.get_bandwidth(segment, audio, sample_rate)
                except ValueError as ex:
                    logger.warning(f"[{self.name}] skipping segment in {task.task_id}: {ex}")
                    segment.setdefault(self.metrics_key, {})["metric_skip_reason"] = str(ex)
        else:
            self.get_bandwidth(data_entry, audio, sample_rate)

        return task
