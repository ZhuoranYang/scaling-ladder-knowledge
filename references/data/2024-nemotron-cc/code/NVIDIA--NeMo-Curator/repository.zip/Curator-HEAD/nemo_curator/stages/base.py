# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import contextlib
import copy
import time
from abc import ABC, ABCMeta, abstractmethod
from inspect import isabstract
from types import UnionType
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
    Generic,
    TypeVar,
    Union,
    cast,
    final,
    get_args,
    get_origin,
    get_type_hints,
)

from loguru import logger

from nemo_curator.stages.resources import Resources
from nemo_curator.tasks import Task

if TYPE_CHECKING:
    from collections.abc import Callable

    from nemo_curator.backends.base import NodeInfo, WorkerMetadata

X = TypeVar("X", bound=Task)  # Input task type
Y = TypeVar("Y", bound=Task)  # Output task type
StageInputSpec = tuple[list[str], list[str]]
StageInputSpecs = StageInputSpec | dict[type[Task], StageInputSpec]
_INPUT_SPEC_LENGTH = 2

_STAGE_REGISTRY: dict[str, type[ProcessingStage]] = {}


class _UnsetType:
    __slots__ = ()


_UNSET = _UnsetType()


def _stage_spec_method(stage_spec: dict[str, Any]) -> Callable[[], dict[str, Any]]:
    def get_stage_spec() -> dict[str, Any]:
        return dict(stage_spec)

    return get_stage_spec


def _num_workers_method(num_workers: int | None) -> Callable[[], int | None]:
    def get_num_workers() -> int | None:
        return num_workers

    return get_num_workers


def _num_workers_per_node_method(
    num_workers_per_node: float | None,
) -> Callable[[], float | None]:
    def get_num_workers_per_node() -> float | None:
        return num_workers_per_node

    return get_num_workers_per_node


class StageMeta(ABCMeta):
    """Metaclass that automatically registers concrete Stage subclasses.
    A class is considered *concrete* if it directly inherits from
    :class:`ProcessingStage` **and** implements a ``name`` property.  Abstract
    helper classes (e.g. *ProcessingStage* itself) will not be added to the
    registry because they have the ``_is_abstract`` attribute set.
    """

    def __new__(mcls, name, bases, namespace, **kwargs):  # noqa: ANN001
        cls = super().__new__(mcls, name, bases, namespace, **kwargs)

        # Skip registration for the abstract roots
        if namespace.get("_is_abstract_root", False):
            return cls

        # Only register subclasses that ultimately derive from ProcessingStage
        # but are not abstract.
        if "ProcessingStage" in [base.__name__ for base in cls.mro()[1:]] and not isabstract(cls):
            # Ensure no duplicate class names (helps when reloading in notebooks)
            _STAGE_REGISTRY[cls.__name__] = cls  # type: ignore[assignment]

        return cls

    def __call__(cls, *args, **kwargs):
        """Validate worker sizing after the stage is fully constructed."""
        instance = super().__call__(*args, **kwargs)
        instance._validate_worker_sizing()
        return instance


def get_stage_class(name: str) -> type[ProcessingStage]:
    """Retrieve a registered stage class by its *class name*.
    Raises
    ------
    KeyError
        If no stage with that name is registered.
    """

    return _STAGE_REGISTRY[name]


class ProcessingStage(ABC, Generic[X, Y], metaclass=StageMeta):
    """Base class for all processing stages.
    Processing stages operate on Task objects (or subclasses like DocumentBatch).
    Each stage type can declare what type of Task it processes as input (X)
    and what type it produces as output (Y).
    Stages can return either:
    - A single task (typical for transformations)
    - A list of tasks (for stages that split work, like readers)
    - None (for filtered out tasks)
    """

    _is_abstract_root = True  # prevent base from registering itself
    name = "ProcessingStage"
    resources = Resources(cpus=1.0)
    batch_size = 1
    runtime_env: ClassVar[dict[str, Any] | None] = None

    # Source / sink role flags. User-overridable on the stage class or
    # instance. If neither is set explicitly on any stage in the pipeline,
    # ``Pipeline.build()`` defaults the first stage to source and the last
    # to sink. The source flag selects content-based ids from
    # ``Task.get_deterministic_id()`` (when the Task subclass implements
    # one) for this task's id segment; the sink flag is reserved for the
    # resumability layer to mark the counter-decrement boundary.
    is_source_stage: bool = False
    is_sink_stage: bool = False
    # Whether this stage is safe to run under resumability (``checkpoint_path``).
    # Defaults to True; set False only on stages whose input→output mapping isn't
    # source-attributable (shuffle / fan-in, e.g. the dedup shuffle/LSH/connected-
    # components stages). ``Pipeline.run(checkpoint_path=...)`` errors if any stage
    # in the pipeline is not resumable.
    is_resumable: bool = True

    @property
    @final
    def _name(self) -> str:
        return self.name

    @property
    @final
    def _resources(self) -> Resources:
        return self.resources

    @property
    @final
    def _batch_size(self) -> int | None:
        """Number of tasks to process in a batch."""
        return self.batch_size

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        for attr in ("_name", "_resources", "_batch_size"):
            if attr in cls.__dict__:
                msg = f"{cls.__name__} must not override '{attr}'"
                raise TypeError(msg)

        for worker_attr in ("num_workers", "num_workers_per_node"):
            value = cls.__dict__.get(worker_attr)
            if (value is not None and not callable(value)) or (
                value is None and worker_attr in cls.__dict__.get("__annotations__", {})
            ):
                msg = (
                    f"{cls.__name__} must not define '{worker_attr}' as a stage attribute. "
                    f"Override {worker_attr}() for backend worker sizing, or use a different field name "
                    "for stage-specific worker counts."
                )
                raise TypeError(msg)

        for attr in ("name", "resources", "batch_size", "runtime_env"):
            if isinstance(cls.__dict__.get(attr), property):
                msg = (
                    f"{cls.__name__} must not define '{attr}' as a @property. "
                    f"Use a plain class attribute or dataclass field instead, "
                    f"so that ProcessingStage.with_() can override it."
                )
                raise TypeError(msg)

    def num_workers(self) -> int | None:
        """Number of workers required. If None, then executor will determine the number of workers."""
        return None

    def num_workers_per_node(self) -> float | None:
        """Number of workers required per Ray node. If None, executor default sizing is used."""
        return None

    def _validate_worker_sizing(self) -> None:
        """Reject ambiguous combinations of backend worker-sizing options."""
        from nemo_curator.backends.utils import (
            get_configured_actor_pool_sizing_keys,
            get_stage_num_workers_per_node,
        )

        configured = [
            name
            for name, value in (
                ("num_workers()", self.num_workers()),
                ("num_workers_per_node()", get_stage_num_workers_per_node(self)),
            )
            if value is not None
        ]

        if get_configured_actor_pool_sizing_keys(self.ray_stage_spec()):
            configured.append("actor-pool sizing keys (min/max/initial_workers)")

        if len(configured) > 1:
            msg = (
                f"Stage {self.name} sets multiple worker-sizing options ({', '.join(configured)}); "
                "use only one of num_workers, num_workers_per_node, or actor-pool sizing keys."
            )
            raise ValueError(msg)

    def validate_input(self, task: Task) -> bool:
        """Validate input task meets requirements.
        Args:
            task: Task to validate
        Returns:
            True if valid, False otherwise
        """
        try:
            required_top_level_attrs, required_data_attrs = self.input_spec_for_task(task)
        except TypeError as e:
            logger.error(str(e))
            return False

        # Check required attributes exist
        missing_top_level_attrs = []
        for attr in required_top_level_attrs:
            if not hasattr(task, attr):
                missing_top_level_attrs.append(attr)

        # Check required columns exist
        missing_data_attrs = []
        get_columns = getattr(task, "get_columns", None)
        data_columns = get_columns() if callable(get_columns) else getattr(task.data, "column_names", ())
        for attr in required_data_attrs:
            if not hasattr(task.data, attr) and attr not in data_columns:
                missing_data_attrs.append(attr)

        # Log warning with missing attributes
        if missing_top_level_attrs or missing_data_attrs:
            logger.error(
                f"Task {task.task_id} missing required attributes: {missing_top_level_attrs} {missing_data_attrs}"
            )

        return not missing_top_level_attrs and not missing_data_attrs

    def input_spec_for_task(self, task: Task) -> StageInputSpec:
        """Return the input requirements that apply to ``task``.

        Stages may return either the legacy single input spec or a mapping from
        supported task type to spec. For mappings, the most specific task type in
        the task's MRO wins.
        """
        input_specs = self.inputs()
        if isinstance(input_specs, tuple):
            return self._validate_input_spec(input_specs, "inputs()")
        if not isinstance(input_specs, dict):
            msg = f"Stage {self.name} inputs() must return an input spec tuple or dict of task type to input spec"
            raise TypeError(msg)

        # Search the task's MRO from most to least specific. For example, given
        # CustomDocumentBatch -> DocumentBatch -> Task, look for an input spec
        # for CustomDocumentBatch first, then DocumentBatch, and finally Task.
        for candidate_type in type(task).mro():
            if candidate_type in input_specs:
                return self._validate_input_spec(input_specs[candidate_type], f"inputs()[{candidate_type.__name__}]")

        supported_task_types = ", ".join(supported_type.__name__ for supported_type in input_specs) or "<none>"
        msg = (
            f"Stage {self.name} does not support input task type {type(task).__name__}. "
            f"Supported input task types: {supported_task_types}"
        )
        raise TypeError(msg)

    def _validate_input_spec(self, input_spec: object, source: str) -> StageInputSpec:
        if not isinstance(input_spec, tuple) or len(input_spec) != _INPUT_SPEC_LENGTH:
            msg = f"Stage {self.name} {source} must be a tuple of (required_attributes, required_columns)"
            raise TypeError(msg)
        return cast("StageInputSpec", input_spec)

    @abstractmethod
    def process(self, task: X) -> Y | list[Y]:
        """Process a task and return the result.
        Args:
            task (X): Input task to process
        Returns (Y | list[Y]):
            - Single task: For 1-to-1 transformations
            - List of tasks: For 1-to-many transformations (e.g., readers)
            - None: If the task should be filtered out
        """

    def process_batch(self, tasks: list[X]) -> list[Y]:
        """Process a batch of tasks and return results.
        Override this method to enable batch processing for your stage.
        If not overridden, the stage will only support single-task processing.
        Args:
            tasks (list[X]): List of input tasks to process
        Returns (list[Y]):
            List of results, where each result can be:
            - Single task: For 1-to-1 transformations
            - List of tasks: For 1-to-many transformations
            - None: If the task should be filtered out
        Note: The returned list should have the same length as the input list,
        with each element corresponding to the result of processing the task
        at the same index.

        ``task_id`` is framework-owned: stages must NOT set it. The executor
        adapter (``BaseStageAdapter._post_process_task_ids``) assigns a
        deterministic id to every emitted task — regardless of whether
        a stage uses this default or overrides ``process_batch``. Where the
        input→output mapping is ambiguous (e.g. a batch aggregation), the
        adapter falls back to a random ``"r"``-prefixed id (see
        ``Task.task_id``); there is no way for a stage to supply its own.
        """
        # Default implementation: process tasks one by one
        # This is only used as a fallback if a stage doesn't override this method
        results = []
        for task in tasks:
            if not self.validate_input(task):
                msg = f"Task {task!s} failed validation for stage {self}"
                raise ValueError(msg)

            result = self.process(task)
            if isinstance(result, list):
                results.extend(result)
            else:
                results.append(result)
        return results

    def setup_on_node(self, node_info: NodeInfo | None = None, worker_metadata: WorkerMetadata | None = None) -> None:
        """Setup method called once per node in distributed settings.
        Override this method to perform node-level initialization.
        Args:
            node_info (NodeInfo, optional): Information about the node (provided by some backends)
            worker_metadata (WorkerMetadata, optional): Information about the worker (provided by some backends)
        """

    def setup(self, worker_metadata: WorkerMetadata | None = None) -> None:
        """Setup method called once before processing begins.
        Override this method to perform any initialization that should
        happen once per worker.
        Args:
            worker_metadata (WorkerMetadata, optional): Information about the worker (provided by some backends)
        """

    def teardown(self) -> None:
        """Teardown method called once after processing ends.
        Override this method to perform any cleanup.
        """

    def supports_batch_processing(self) -> bool:
        """Whether this stage supports vectorized batch processing.
        This is automatically determined by checking if the stage has
        overridden the process_batch method from the base class.
        """
        # Check if process_batch has been overridden
        return type(self).process_batch is not ProcessingStage.process_batch

    def __repr__(self) -> str:
        """String representation of the stage."""
        return f"{self.__class__.__name__}"

    def inputs(self) -> StageInputSpecs:
        """Define stage input requirements.

        Returns:
            Either a single tuple of (required_attributes, required_columns), or
            a mapping from supported task type to that tuple. In each tuple:
            - required_top_level_attributes: List of task attributes that must be present
            - required_data_attributes: List of attributes within the data that must be present
        """
        return [], []

    def outputs(self) -> tuple[list[str], list[str]]:
        """Define stage output specification.

        Returns (tuple[list[str], list[str]]):
            Tuple of (output_attributes, output_columns) where:
            - output_top_level_attributes: List of task attributes this stage adds/modifies
            - output_data_attributes: List of attributes within the data that this stage adds/modifies
        """
        return [], []

    def xenna_stage_spec(self) -> dict[str, Any]:
        """Get Xenna configuration for this stage.

        Returns (dict[str, Any]):
            Dictionary containing Xenna-specific configuration
        """
        return {}

    def with_(  # noqa: PLR0913
        self,
        name: str | None = None,
        resources: Resources | None = None,
        batch_size: int | None = None,
        runtime_env: dict[str, Any] | None = None,
        ray_stage_spec: dict[str, Any] | None = None,
        xenna_stage_spec: dict[str, Any] | None = None,
        num_workers: int | None | _UnsetType = _UNSET,
        num_workers_per_node: float | None | _UnsetType = _UNSET,
    ) -> ProcessingStage:
        """Apply configuration changes to this stage with overridden properties.

        Note: This method uses class-level attributes and instance attributes interchangeably which can sometimes
        lead to unexpected behavior. Please see https://github.com/NVIDIA-NeMo/Curator/pull/764 for more details.
        Args:
            name: Override the name property
            resources: Override the resources property
            batch_size: Override the batch_size property
            runtime_env: Override the runtime_env (Ray runtime environment dict)
            ray_stage_spec: Merge overrides into the Ray stage spec. User-provided keys win.
            xenna_stage_spec: Merge overrides into the Xenna stage spec. User-provided keys win.
                Use num_workers instead of setting num_workers in xenna_stage_spec.
            num_workers: Override the num_workers() result. Passing None explicitly resets to executor default behavior.
            num_workers_per_node: Override the num_workers_per_node() result. Passing None explicitly resets to
                executor default behavior.
        """
        new_instance = copy.deepcopy(self)

        # Override the instance attributes directly
        if name is not None:
            new_instance.name = name
        if resources is not None:
            new_instance.resources = resources
        if batch_size is not None:
            new_instance.batch_size = batch_size
        if runtime_env is not None:
            new_instance.runtime_env = runtime_env

        if ray_stage_spec is not None:
            new_instance.ray_stage_spec = _stage_spec_method(
                {
                    **new_instance.ray_stage_spec(),
                    **dict(ray_stage_spec),
                }
            )

        if xenna_stage_spec is not None:
            xenna_stage_spec = dict(xenna_stage_spec)
            if "num_workers" in xenna_stage_spec:
                msg = "Use with_(num_workers=...) instead of setting num_workers in xenna_stage_spec."
                raise ValueError(msg)
            new_instance.xenna_stage_spec = _stage_spec_method(
                {
                    **new_instance.xenna_stage_spec(),
                    **xenna_stage_spec,
                }
            )

        if num_workers is not _UNSET:
            new_instance.num_workers = _num_workers_method(cast("int | None", num_workers))
        if num_workers_per_node is not _UNSET:
            new_instance.num_workers_per_node = _num_workers_per_node_method(
                cast("float | None", num_workers_per_node)
            )

        new_instance._validate_worker_sizing()

        return new_instance

    def get_config(self) -> dict[str, Any]:
        """Get configuration for this stage.
        Returns (dict[str, Any]):
            Dictionary containing configuration for this stage
        """
        return {
            "name": self.name,
            "resources": self.resources,
            "batch_size": self.batch_size,
            "supports_batch_processing": self.supports_batch_processing(),
        }

    def ray_stage_spec(self) -> dict[str, Any]:
        """Get Ray configuration for this stage.
        Note : This is only used for Ray Data backend.
        The keys are defined in RayStageSpecKeys in backends/ray_data/utils.py

        Returns (dict[str, Any]):
            Dictionary containing Ray-specific configuration
        """
        return {"is_fanout_stage": self.is_fanout_stage()}

    def is_fanout_stage(self) -> bool:
        """Infer whether `process()` can fan out one input task into many outputs."""
        try:
            process_hints = get_type_hints(type(self).process)
        except (AttributeError, NameError, TypeError) as exc:
            logger.debug(
                "Could not resolve type hints for {}.process; defaulting is_fanout_stage to False: {}",
                type(self).__name__,
                exc,
            )
            return False

        return self._annotation_contains_list(process_hints.get("return"))

    @classmethod
    def _annotation_contains_list(cls, annotation: object) -> bool:
        if annotation is None:
            return False

        if get_origin(annotation) is list:
            return True

        if get_origin(annotation) in (UnionType, Union):
            return any(cls._annotation_contains_list(arg) for arg in get_args(annotation))

        return False

    # --- Custom per-stage metrics helpers ---
    def _log_metrics(self, metrics: dict[str, float]) -> None:
        """Record custom metrics for this stage (e.g., sub-stage timings)."""
        if not hasattr(self, "_custom_metrics") or self._custom_metrics is None:
            self._custom_metrics = {}
        for name, value in metrics.items():
            if isinstance(value, (int, float)):
                self._custom_metrics[name] = float(value)
            else:
                msg = f"Can't record non-numeric metric {name} value={value} for stage {self.name}"
                logger.warning(msg)

    def _log_metric(self, name: str, value: float) -> None:
        return self._log_metrics({name: value})

    @contextlib.contextmanager
    def _time_metric(self, name: str) -> contextlib.AbstractContextManager[None]:
        """Record elapsed time for a code block as a custom stage metric."""
        start = time.perf_counter()
        try:
            yield
        finally:
            self._log_metric(name, time.perf_counter() - start)

    def _consume_custom_metrics(self) -> dict[str, float]:
        """Return and clear metrics recorded during the last process call."""
        if not hasattr(self, "_custom_metrics") or self._custom_metrics is None:
            self._custom_metrics = {}
        metrics: dict[str, float] = dict(self._custom_metrics)
        del self._custom_metrics
        return metrics


class CompositeStage(ProcessingStage[X, Y], ABC):
    """Base class for high-level composite stages.

    Composite stages are user-facing stages that decompose into multiple
    low-level execution stages during pipeline planning. They provide a
    simplified API while maintaining fine-grained control at execution time.

    Composite stages never actually execute - they only exist to be decomposed
    into their constituent execution stages.
    """

    def __init__(self):
        self._with_operations = []

    def inputs(self) -> StageInputSpecs:
        """Get the inputs for this stage."""
        return self.decompose()[0].inputs()

    def outputs(self) -> tuple[list[str], list[str]]:
        """Get the outputs for this stage."""
        return self.decompose()[-1].outputs()

    @abstractmethod
    def decompose(self) -> list[ProcessingStage]:
        """Decompose into execution stages.

        This method must be implemented by composite stages to define
        what low-level stages they represent.

        Returns (list[ProcessingStage]):
            List of execution stages that will actually run
        """

    def with_(self, stage_with_dict: dict[str, Any]) -> CompositeStage:
        """Apply configuration changes to this stage."""
        # Probably should return a new CompositeStage object
        self._with_operations.append(stage_with_dict)
        return self

    def decompose_and_apply_with(self) -> list[ProcessingStage]:
        """Decompose and apply configuration changes to this stage."""
        return self._apply_with_(self.decompose())

    def _apply_with_(self, stages: list[ProcessingStage]) -> list[ProcessingStage]:
        """Apply configuration changes to this stage."""
        for stage_with_dict in self._with_operations:
            stage_name_to_stage = {stage.name: stage for stage in stages}

            # Verify that all stages have unique names
            if len(stage_name_to_stage) != len(stages):
                err = "All stages must have unique names in composite stage to apply configuration changes using with_()."
                raise ValueError(err)

            # Ensure that we can cover all the keys in stage_with_dict
            for stage_name in stage_with_dict:
                if stage_name not in stage_name_to_stage:
                    err = f"Stage {stage_name} not found in composite stage to apply configuration changes using with_()."
                    raise ValueError(err)

            new_stages = []
            # Apply configuration changes to each stage
            for stage in stages:
                if stage.name in stage_with_dict:
                    new_stages.append(stage.with_(**stage_with_dict[stage.name]))
                else:
                    new_stages.append(stage)

            stages = new_stages

        return stages

    def process(self, task: X) -> Y | list[Y]:  # noqa: ARG002
        """Composite stages should never be executed directly."""
        msg = f"Composite stage '{self.name}' should not be executed directly. "
        msg += "It should be decomposed into execution stages during planning."
        raise RuntimeError(msg)

    def get_description(self) -> str:
        """Get a description of what this composite stage does.

        Override this to provide user-friendly documentation.
        """
        return f"Composite stage: {self.name}"
