# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Pipeline-level validation for agent-composed audio pipelines.

``validate_pipeline([stageA, stageB, ...])`` walks an ordered list of configured
stages and checks they actually compose — each stage's required inputs must be
produced by an upstream stage or be present in the initial task. It also surfaces
resource-gate problems (GPU needed but none available).

A read is satisfied by matching *either* the literal key it names or the semantic
*role* behind it. Both routes are needed: role matching tolerates a producer that
writes ``resampled_audio_filepath`` where the consumer reads ``audio_filepath``,
and key matching covers the reverse, where the names agree but the two sides file
that name under different roles. Requiring both would report breaks in pipelines
that run.

Composites are expanded (see :mod:`nemo_curator.stages.audio._agent._composite`) so the
stages inside them are checked too — the requirements of the stages that do the
work, rather than the empty contract the composite advertises. Missing reads inside
composites remain advisory; a proven incompatible live value is an error. A composite that cannot be expanded, or whose children
include something with no contract at all, falls back to being treated as opaque:
it is reported, and reads after it are no longer judged by role.

Two levels of confidence, deliberately separated:

* ``report.ok`` certifies a *role-level necessary condition* — every required
  input role is available. This is rename-tolerant by design and is the gate.
* ``report.keys_ok`` adds the stronger *literal-key-identity* check: each
  role-satisfied read's actual key *value* is produced upstream (or seeded). A
  ``True`` ``ok`` with ``False`` ``keys_ok`` means the roles line up but a
  producer key was renamed away from what the consumer reads — the pipeline
  would validate yet yield zero rows at runtime. It is surfaced as a WARNING
  (not an error) so that legitimate reads of source-manifest columns are not
  false-rejected.

This is advisory and read-only — it never executes a stage. ``ok`` is a
necessary, not sufficient, condition for a pipeline to run.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from nemo_curator.stages.audio._agent._agent_registry import build_contract
from nemo_curator.stages.audio._agent._composite import expand_composites
from nemo_curator.stages.audio._agent._roles import role_for_value

if TYPE_CHECKING:
    from nemo_curator.stages.audio._agent._agent_ready import StageContract

Severity = Literal["error", "warning"]

# Roles a typical audio task carries at the start (a manifest row with a file path).
_DEFAULT_INITIAL_ROLES: frozenset[str] = frozenset({"audio_filepath"})
# Key VALUES a typical audio task carries at the start (the conventional path key).
_DEFAULT_INITIAL_KEYS: frozenset[str] = frozenset({"audio_filepath"})

# The role of the key a tensor producer parks its waveform under. Tracking the carrier
# rather than a bare "a tensor is resident" flag is what lets a stage that DROPS that key
# end the residency, instead of only a stage flagged ``sanitizes_output``.
_TENSOR_ROLE = "waveform"
# Stand-in for a producer that declares ``produces=["tensor"]`` without naming a
# waveform-roled key. Its residency is still tracked, but no key removal can match it, so
# only an explicit sanitizer clears it -- deliberately the pre-existing behaviour.
_UNNAMED_TENSOR = "<unnamed tensor>"


@dataclass(frozen=True)
class PipelineIssue:
    """A single problem found while validating a pipeline."""

    stage_index: int
    stage_name: str
    severity: Severity
    code: str
    message: str


@dataclass(frozen=True)
class PipelineReport:
    """Result of :func:`validate_pipeline`."""

    issues: list[PipelineIssue] = field(default_factory=list)
    produced_roles: set[str] = field(default_factory=set)  # roles available after the last stage
    produced_keys: set[str] = field(default_factory=set)  # key VALUES available after the last stage

    @property
    def ok(self) -> bool:
        """True when there are no error-severity issues (role-level composability).

        This is a *necessary* condition, not a guarantee the pipeline runs — see
        :attr:`keys_ok` for the stronger literal-key check.
        """
        return not any(i.severity == "error" for i in self.issues)

    @property
    def keys_ok(self) -> bool:
        """True when no ``dangling_key`` warnings — every role-satisfied read's
        actual key *value* is produced upstream or seeded. ``ok and keys_ok`` is
        the strong signal that the pipeline will actually flow data end-to-end.
        """
        return not any(i.code == "dangling_key" for i in self.issues)

    @property
    def errors(self) -> list[PipelineIssue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> list[PipelineIssue]:
        return [i for i in self.issues if i.severity == "warning"]

    def summary(self) -> str:
        if not self.issues:
            return (
                "pipeline mechanically composable (all reads satisfied by role); "
                "this does not certify intent or field meaning"
            )
        lines = [f"{len(self.errors)} error(s), {len(self.warnings)} warning(s):"]
        for i in self.issues:
            lines.append(f"  [{i.severity}] stage {i.stage_index} {i.stage_name}: {i.message}")
        return "\n".join(lines)


def _read_role(contract: StageContract, spec: Any, key: str) -> str:  # noqa: ANN401 - IOSpec
    # A conversion can read a path and replace that same literal key with a waveform.
    # The contract's shared key_roles describes the output; the file-only read form
    # establishes the input role for its sole carrier.
    if set(spec.accepts) == {"file"} and len(spec.data_keys) + len(spec.segment_data_keys) == 1:
        return "audio_filepath"
    return contract.key_roles.get(key, "unknown")


def _required_roles(contract: StageContract) -> set[str]:
    keys = [*contract.reads.data_keys, *contract.reads.segment_data_keys]
    return {_read_role(contract, contract.reads, key) for key in keys}


def _requirement_str(contract: StageContract, available: set[str]) -> str:
    """Human-readable "what this stage needs" for an unsatisfied-reads message.

    Renders top-level ``reads`` (all required) and ``reads_one_of`` (any one), so a
    stage whose reads live entirely in ``reads_one_of`` (e.g. a residency-derived
    contract) no longer renders a misleading empty ``role(s) []``.
    """
    missing = _required_roles(contract) - (available | {"unknown"})
    reqs: list[str] = []
    if missing:
        reqs.append(f"role(s) {sorted(missing)}")
    if contract.reads_one_of:
        reqs.append(f"one of {[sorted(_roles_of(o, contract)) for o in contract.reads_one_of]}")
    for branch in contract.conditional_reads:
        reqs.append(
            f"when {branch.condition}: one of "
            f"{[sorted(_roles_of(option, contract)) for option in branch.reads_one_of]}"
        )
    return "; ".join(reqs) or f"role(s) {sorted(_required_roles(contract))}"


def _write_key_values(contract: StageContract) -> set[str]:
    """The literal top-level key VALUES a stage writes."""
    return set(contract.writes.data_keys)


def _segment_write_key_values(contract: StageContract) -> set[str]:
    """The literal key VALUES a stage writes inside nested-list items."""
    return set(contract.writes.segment_data_keys)


def _roles_for_keys(contract: StageContract, keys: set[str] | list[str]) -> set[str]:
    """Known semantic roles for key values in one task-data scope."""
    return {contract.key_roles.get(key, "unknown") for key in keys} - {"unknown"}


def _spec_satisfied_by_role(  # noqa: PLR0913 -- task and nested scopes each need roles plus literal keys
    spec: Any,  # noqa: ANN401 - IOSpec, kept loose to avoid a runtime-only import
    contract: StageContract,
    available_roles: set[str],
    available_segment_roles: set[str],
    available_keys: set[str],
    available_segment_keys: set[str],
) -> bool:
    """Whether known roles or exact unknown-role keys satisfy each scope."""

    def scope_satisfied(keys: list[str], roles: set[str], literal_keys: set[str]) -> bool:
        return all(
            key in literal_keys if (role := _read_role(contract, spec, key)) == "unknown" else role in roles
            for key in keys
        )

    return scope_satisfied(spec.data_keys, available_roles, available_keys) and scope_satisfied(
        spec.segment_data_keys,
        available_segment_roles,
        available_segment_keys,
    )


def _reachable_conditional_reads(
    contract: StageContract,
    available_keys: set[str],
    possible_keys: set[str] | None = None,
) -> list[Any]:
    """Read branches that runtime can select from the current top-level schema."""
    possible = possible_keys or set()
    reachable_keys = available_keys | possible
    return [
        branch
        for branch in contract.conditional_reads
        if set(branch.requires_keys).issubset(reachable_keys) and not (set(branch.forbids_keys) & available_keys)
    ]


def _read_option_groups(
    contract: StageContract,
    available_keys: set[str],
    possible_keys: set[str] | None = None,
) -> list[list[Any]]:
    """Alternative groups whose runtime branch is reachable for this input."""
    groups = [contract.reads_one_of] if contract.reads_one_of else []
    groups.extend(
        branch.reads_one_of for branch in _reachable_conditional_reads(contract, available_keys, possible_keys)
    )
    return groups


def _reads_satisfied_by_role(  # noqa: PLR0913 -- task/segment roles and keys are distinct planner state
    contract: StageContract,
    available_roles: set[str],
    available_segment_roles: set[str],
    available_keys: set[str],
    available_segment_keys: set[str],
    possible_keys: set[str] | None = None,
) -> bool:
    """Role-level read check with literal fallback for unknown roles."""
    if not _spec_satisfied_by_role(
        contract.reads,
        contract,
        available_roles,
        available_segment_roles,
        available_keys,
        available_segment_keys,
    ):
        return False
    return all(
        any(
            _spec_satisfied_by_role(
                option,
                contract,
                available_roles,
                available_segment_roles,
                available_keys,
                available_segment_keys,
            )
            for option in group
        )
        for group in _read_option_groups(contract, available_keys, possible_keys)
    )


def _key_family(key: str) -> str:
    """The trailing token of a key name -- ``diar_segments`` and ``segments`` share ``segments``.

    A crude but load-bearing notion of "these two keys hold the same KIND of thing". Producers
    qualify a shared noun with a prefix (``diar_``, ``vad_``, ``pred_``), so the bare noun and
    its qualified siblings are exactly the set a consumer might have meant.
    """
    return key.rsplit("_", 1)[-1]


def _ambiguous_default_reads(
    stage: Any,  # noqa: ANN401 - any built stage
    contract: StageContract,
    available_keys: set[str],
    key_producer: dict[str, str],
) -> list[tuple[str, str, list[tuple[str, str]]]]:
    """``(key, attribute, rivals)`` for read keys left at a default while a sibling key exists.

    The failure this catches is silence. ``MergeAlignmentDiarizationStage`` documents itself as
    merging into DIARIZATION segments, yet its ``segments_key`` defaults to ``"segments"`` --
    the key VAD writes. In a VAD+diarization pipeline both keys exist, so the read is satisfied
    and every other check passes: transcripts get merged into the wrong segments and the output
    is plausible, complete, and wrong.

    Deliberately narrow, because a warning nobody trusts is worse than none. It fires only when
    the key is still at its CLASS DEFAULT (an explicit setting is a decision, not an accident),
    the key IS available (an unavailable one is already reported as dangling), and some other
    available key of the same family was written by a DIFFERENT upstream stage -- so a real
    choice existed and was made by a default rather than by anyone.
    """
    fields = getattr(type(stage), "__dataclass_fields__", {})
    reads = {*contract.reads.data_keys, *contract.reads.segment_data_keys}
    found: list[tuple[str, str, list[tuple[str, str]]]] = []
    for attr, spec in fields.items():
        value = getattr(stage, attr, None)
        if not (isinstance(value, str) and value in reads and value in available_keys and value == spec.default):
            continue
        rivals = sorted(
            (k, key_producer[k])
            for k in available_keys
            if k != value
            # If the consumer reads both siblings (for example reference
            # ``text`` and ASR ``pred_text`` for WER), they are independent
            # operands rather than competing choices.
            and k not in reads
            and k in key_producer
            and _key_family(k) == _key_family(value)
            and key_producer[k] != key_producer.get(value)
        )
        if rivals:
            found.append((value, attr, rivals))
    return found


@dataclass(frozen=True)
class _Site:
    """The stage being checked right now, and how to name it to whoever wrote the recipe."""

    index: int
    """Index of the RECIPE stage, so an inner stage points at something the caller can edit."""

    name: str
    stage: Any
    composite: Any | None = None
    """The recipe-level composite this was expanded from, when it is not a stage in its own right."""


def _gate_issues(
    site: _Site,
    contract: StageContract,
    available_gpus: float | None,
    *,
    tensor_resident: bool,
) -> list[PipelineIssue]:
    """Environment/serialization gate problems for one stage.

    These reason about GPUs and serialization rather than roles, so they apply to every concrete
    stage even downstream of a composite that hides its writes.
    """
    out = []
    if available_gpus is not None and contract.gates.requires_gpu and available_gpus <= 0:
        out.append(
            PipelineIssue(
                site.index,
                site.name,
                "warning",
                "gpu_unavailable",
                "declares requires_gpu but available_gpus <= 0",
            )
        )
    # A resident tensor (e.g. a waveform) reaching a serialize-as-is sink (raw json.dumps)
    # crashes at runtime. A sanitizing stage upstream clears the flag before we get here.
    if contract.gates.requires_serializable_input and tensor_resident:
        out.append(
            PipelineIssue(
                site.index,
                site.name,
                "error",
                "tensor_into_sink",
                "a resident tensor/audio blob from an upstream stage reaches this "
                "serialize-as-JSON sink; it WILL fail at json.dumps — drop the tensor "
                "upstream (e.g. keep_segment_waveform_in_task=False) or route through "
                "a sanitizing stage before the sink",
            )
        )
    return out


def _ambiguity_issues(
    site: _Site,
    contract: StageContract,
    available_keys: set[str],
    key_producer: dict[str, str],
) -> list[PipelineIssue]:
    """``ambiguous_default_key`` warnings for this stage, naming who wrote each candidate."""
    out = []
    for key, attr, rivals in _ambiguous_default_reads(site.stage, contract, available_keys, key_producer):
        others = ", ".join(f"{k!r} from {p}" for k, p in rivals)
        out.append(
            PipelineIssue(
                site.index,
                site.name,
                "warning",
                "ambiguous_default_key",
                f"reads {key!r} (the default for {attr}), but upstream also produced {others}. "
                f"The default silently picks {key!r} "
                f"({key_producer.get(key, 'the source manifest')}); if you meant the other, "
                f"set {attr} explicitly.",
            )
        )
    return out


def _missing_read_keys(
    contract: StageContract,
    available_keys: set[str],
    available_segment_keys: set[str],
) -> set[str]:
    """Read key VALUES this stage wants that nothing upstream produced or seeded."""
    return {
        *{key for key in contract.reads.data_keys if key not in available_keys},
        *{key for key in contract.reads.segment_data_keys if key not in available_segment_keys},
    }


def _spec_satisfied_by_key(
    spec: Any,  # noqa: ANN401 - IOSpec, kept loose to avoid a runtime-only import
    available_keys: set[str],
    available_segment_keys: set[str],
) -> bool:
    """Whether one I/O alternative's literal keys exist in their declared scopes."""
    return not (set(spec.data_keys) - available_keys) and not (set(spec.segment_data_keys) - available_segment_keys)


def _reads_satisfied_by_key(
    contract: StageContract,
    available_keys: set[str],
    available_segment_keys: set[str],
    possible_keys: set[str] | None = None,
) -> bool:
    """Whether every read is met by the LITERAL key it names.

    A stage reads ``task.data[self.segments_key]`` at runtime -- a key string, never a role. So
    a diarizer that writes ``diar_segments`` does satisfy a consumer configured to read
    ``diar_segments``, even though the producer registers that key under the role
    ``diar_segments`` while the consumer's contract calls the same slot ``segments``. Judging
    that pairing only by role reports a break in a pipeline that runs, and the caller's options
    are then to distrust the validator or to rename a key to appease it -- both worse than the
    check not existing.

    Role matching stays as the rename-tolerant fallback for the opposite case, where the key
    names differ but mean the same thing (a producer writing ``resampled_audio_filepath``
    satisfying a consumer reading ``audio_filepath``). A read is satisfied by either route.
    """
    if not _spec_satisfied_by_key(contract.reads, available_keys, available_segment_keys):
        return False
    return all(
        any(_spec_satisfied_by_key(option, available_keys, available_segment_keys) for option in group)
        for group in _read_option_groups(contract, available_keys, possible_keys)
    )


def _forwarding_param(inner: Any, composite: Any, missing: set[str]) -> str | None:  # noqa: ANN401
    """The composite parameter to set so an inner stage stops reading the wrong key.

    A caller who configured ``SplitASRAlignJoinStage`` has never heard of ``SplitLongAudioStage``
    and cannot configure it directly, so naming the inner stage alone leaves them stuck. The
    remedy is always a parameter the composite forwards down, and it is identifiable rather than
    guessable: the attribute exists on both classes and its current value IS the key that went
    missing. Returns ``None`` when no such parameter exists, in which case the inner stage's
    requirement genuinely cannot be reached from the recipe.
    """
    inner_fields = getattr(type(inner), "__dataclass_fields__", {})
    composite_fields = getattr(type(composite), "__dataclass_fields__", {})
    for attr in inner_fields:
        if attr not in composite_fields:
            continue
        value = getattr(inner, attr, None)
        # ``missing`` holds key names, so only a string can ever match -- and testing anything
        # else against a set hashes it, which raises TypeError on the list and dict parameters
        # real stages carry (``file_extensions``, ``storage_options``). That exception escapes
        # ``run_checks`` and kills the whole verb, so the recipe gets a traceback instead of a
        # verdict over a remedy hint that was never going to apply.
        if isinstance(value, str) and value in missing:
            return attr
    return None


def _unreadable_child(group: list[Any]) -> str | None:
    """Why this composite's expansion cannot be reasoned about, or ``None`` if it can.

    Composites may contain unannotated plumbing such as FilePartitioningStage. Its
    unknown effects require advisory handling, while known siblings remain checkable.
    """
    for item in group:
        if not item.composite_ref:
            continue  # a top-level stage that cannot describe itself is the caller's own error
        try:
            build_contract(item.stage)
        except Exception as e:  # noqa: BLE001 - any failure to describe means the same thing here
            return f"{type(item.stage).__name__} does not describe its I/O ({type(e).__name__})"
    return None


def _describes_itself(stage: Any) -> bool:  # noqa: ANN401 - any child stage
    """Whether a contract can be built for this stage at all."""
    try:
        build_contract(stage)
    except Exception:  # noqa: BLE001 - any failure to describe means the same thing here
        return False
    return True


def _missing_literal_role_keys(
    contract: StageContract,
    spec: Any,  # noqa: ANN401 - IOSpec, kept loose to avoid a runtime-only import
    available_keys: set[str],
    available_segment_keys: set[str],
) -> set[str]:
    """Role-bearing key VALUES in one spec whose exact value is absent from its scope.

    ``unknown``/internal bookkeeping keys are excluded — a separate value-identity check for
    those is tracked in the backlog. Empty means every role-bearing key in ``spec`` is present,
    i.e. this alternative is literally complete.
    """
    missing: set[str] = set()
    for key, scope_keys in (
        *[(k, available_keys) for k in spec.data_keys],
        *[(k, available_segment_keys) for k in spec.segment_data_keys],
    ):
        if contract.key_roles.get(key, "unknown") != "unknown" and key not in scope_keys:
            missing.add(key)
    return missing


def _dangling_read_keys(
    contract: StageContract,
    available_keys: set[str],
    available_segment_keys: set[str],
    possible_keys: set[str] | None = None,
) -> set[str]:
    """Read key VALUES whose role is known but whose exact value was not
    produced upstream nor seeded — the renamed-producer dangle the role check misses.

    Covers primary ``reads`` (always mandatory) plus ``reads_one_of``:

    * a *single* alternative is not a choice, so its keys are as mandatory as a primary read
      (this is how a residency-derived contract expresses ``input_residency="file"``);
    * a genuine *multi-way* ``reads_one_of`` is satisfied by ANY one complete literal
      alternative. When NO alternative is literally complete — every branch has a role-bearing
      key that was only satisfied by a renamed/role-level producer — the read dangles even
      though a role check passed, so the union of each branch's missing keys is reported.

    Role-bearing keys only (``unknown``/internal bookkeeping keys are excluded).
    """
    dangling = _missing_literal_role_keys(contract, contract.reads, available_keys, available_segment_keys)
    for options in _read_option_groups(contract, available_keys, possible_keys):
        per_option = [
            _missing_literal_role_keys(contract, option, available_keys, available_segment_keys) for option in options
        ]
        if all(missing for missing in per_option):
            dangling |= set().union(*per_option)
    return dangling


@dataclass
class _Walk:
    """What the pipeline carries from one stage to the next while being validated."""

    available: set[str]  # top-level roles produced so far
    available_keys: set[str]  # literal top-level key VALUES produced so far
    segment_available: set[str] = field(default_factory=set)  # nested-item roles produced so far
    segment_available_keys: set[str] = field(default_factory=set)  # literal nested-item key VALUES
    # Tensor residency is tracked per scope: a top-level carrier and a nested (segment) carrier
    # are distinct to a serializer, so a stage dropping one must not be credited with clearing
    # the other. ``tensor_keys`` holds top-level carriers; ``segment_tensor_keys`` nested ones.
    tensor_keys: set[str] = field(default_factory=set)
    segment_tensor_keys: set[str] = field(default_factory=set)
    # Keys/roles a stage MAY have written (``conditional_writes`` whose ``requires_keys`` were
    # reachable). Never folded into the guaranteed sets above: a read met only from here is a
    # ``conditional_read`` warning, not a satisfied read and not an ``unsatisfied_reads`` error.
    possible_keys: set[str] = field(default_factory=set)
    possible_segment_keys: set[str] = field(default_factory=set)
    possible_roles: set[str] = field(default_factory=set)
    possible_segment_roles: set[str] = field(default_factory=set)
    key_roles: dict[str, set[str]] = field(default_factory=dict)
    segment_key_roles: dict[str, set[str]] = field(default_factory=dict)
    possible_key_roles: dict[str, set[str]] = field(default_factory=dict)
    possible_segment_key_roles: dict[str, set[str]] = field(default_factory=dict)
    unkeyed_roles: set[str] = field(default_factory=set)
    unkeyed_segment_roles: set[str] = field(default_factory=set)
    removed_roles: set[str] = field(default_factory=set)
    key_producer: dict[str, str] = field(default_factory=dict)
    segment_key_producer: dict[str, str] = field(default_factory=dict)
    past_composite: bool = False  # an UNEXPANDABLE composite hid its writes; reads past it can't be judged
    task_type: str | None = None  # task type the previous stage produces; None == not known


def _forget_role_provenance(walk: _Walk) -> None:
    """Unknown writes invalidate earlier role evidence; later known writes remain usable."""
    walk.past_composite = True
    walk.key_roles.clear()
    walk.segment_key_roles.clear()
    walk.possible_key_roles.clear()
    walk.possible_segment_key_roles.clear()
    walk.unkeyed_roles.clear()
    walk.unkeyed_segment_roles.clear()
    walk.available.clear()
    walk.segment_available.clear()
    walk.possible_roles.clear()
    walk.possible_segment_roles.clear()


def _read_role_accepts(expected: str, actual: str) -> bool:
    """Generic list/text readers accept their specialized role variants."""
    variants = {
        "segments": {"diar_segments", "vad_segments", "overlap_segments"},
        "text": {"pred_text", "reference_text"},
    }
    return expected == actual or actual in variants.get(expected, set())


def _preferred_read_is_known(walk: _Walk, contract: StageContract) -> bool:
    """A preferred resident input is selected only with proven companion roles."""
    spec = contract.preferred_reads
    if spec is None:
        return False
    for keys, available, roles in (
        (spec.data_keys, walk.available_keys, walk.key_roles),
        (spec.segment_data_keys, walk.segment_available_keys, walk.segment_key_roles),
    ):
        for key in keys:
            actual = roles.get(key, set())
            expected = _read_role(contract, spec, key)
            if key not in available or not actual or "unknown" in actual:
                return False
            # A bad rate can make auto fall back; a known non-waveform value with a valid
            # rate instead reaches the preferred branch and fails there.
            if expected != "waveform" and actual != {expected}:
                return False
    return True


def _literal_role_issues(walk: _Walk, site: _Site, contract: StageContract) -> list[PipelineIssue]:
    """A live literal key must carry the role of its current producer, not a stale role."""

    def check(spec: Any) -> list[PipelineIssue]:  # noqa: ANN401 - IOSpec
        issues = []
        for keys, live_roles, possible_roles, scope in (
            (spec.data_keys, walk.key_roles, walk.possible_key_roles, "task"),
            (spec.segment_data_keys, walk.segment_key_roles, walk.possible_segment_key_roles, "nested"),
        ):
            for key in keys:
                expected = _read_role(contract, spec, key)
                actual = live_roles.get(key, set()) | possible_roles.get(key, set())
                if expected == "unknown" or not actual or all(_read_role_accepts(expected, role) for role in actual):
                    continue
                uncertain = any(_read_role_accepts(expected, role) for role in actual) or "unknown" in actual
                issues.append(
                    PipelineIssue(
                        site.index,
                        site.name,
                        "warning" if uncertain else "error",
                        "conditional_role" if uncertain else "key_role_conflict",
                        f"{scope} key {key!r} requires role {expected!r}, but its current "
                        f"producer can supply {sorted(actual)}",
                    )
                )
        return issues

    issues = check(contract.reads)
    if _preferred_read_is_known(walk, contract):
        issues.extend(check(contract.preferred_reads))
    for group in _read_option_groups(contract, walk.available_keys, walk.possible_keys):
        alternatives = [
            check(option)
            for option in group
            if set(option.data_keys) <= walk.available_keys | walk.possible_keys
            and set(option.segment_data_keys) <= walk.segment_available_keys | walk.possible_segment_keys
        ]
        if alternatives and all(alternatives):
            issues.extend(alternatives[0])
    return issues


def _refresh_role_provenance(  # noqa: C901 - independent task and nested provenance updates
    walk: _Walk,
    contract: StageContract,
    written: set[str],
    segment_written: set[str],
    conditionals: list[Any],
) -> None:
    """Rebuild role sets from live keys after writes, removals, and conditional overwrites."""
    previous = set(walk.available)
    if not contract.preserves_upstream_keys:
        walk.key_roles.clear()
        walk.possible_key_roles.clear()
        walk.unkeyed_roles.clear()
    if not contract.preserves_upstream_keys or not contract.preserves_upstream_segment_keys:
        walk.segment_key_roles.clear()
        walk.possible_segment_key_roles.clear()
        walk.unkeyed_segment_roles.clear()
    scopes = (
        (
            written,
            walk.available_keys,
            walk.key_roles,
            walk.possible_key_roles,
            walk.possible_keys,
            walk.unkeyed_roles,
            "data_keys",
        ),
        (
            segment_written,
            walk.segment_available_keys,
            walk.segment_key_roles,
            walk.possible_segment_key_roles,
            walk.possible_segment_keys,
            walk.unkeyed_segment_roles,
            "segment_data_keys",
        ),
    )
    for writes, live_keys, live_map, possible_map, possible_keys, unkeyed, attr in scopes:
        for key in writes:
            role = contract.key_roles.get(key, role_for_value(key))
            live_map[key] = {role} if role != "unknown" else set()
            possible_map.pop(key, None)
            possible_keys.discard(key)
            unkeyed.discard(role)
        for conditional in conditionals:
            for key in getattr(conditional.writes, attr):
                if key not in live_keys and key not in possible_keys:
                    continue
                role = contract.key_roles.get(key, role_for_value(key))
                if role != "unknown":
                    mapping = live_map if key in live_keys else possible_map
                    prior = mapping.setdefault(key, set())
                    if key in live_keys and not prior:
                        prior.add("unknown")
                    prior.add(role)
        for key in set(live_map) - live_keys:
            live_map.pop(key)
        for key in set(possible_map) - possible_keys:
            possible_map.pop(key)
    walk.available = walk.unkeyed_roles | {
        role for values in walk.key_roles.values() if len(values) == 1 for role in values
    }
    walk.segment_available = walk.unkeyed_segment_roles | {
        role for values in walk.segment_key_roles.values() if len(values) == 1 for role in values
    }
    walk.possible_roles = {
        role
        for values in [
            *walk.possible_key_roles.values(),
            *(values for values in walk.key_roles.values() if len(values) > 1),
        ]
        for role in values
    }
    walk.possible_segment_roles = {
        role
        for values in [
            *walk.possible_segment_key_roles.values(),
            *(values for values in walk.segment_key_roles.values() if len(values) > 1),
        ]
        for role in values
    }
    walk.removed_roles |= previous - walk.available
    walk.removed_roles -= walk.available


def _read_issues(walk: _Walk, site: _Site, contract: StageContract) -> list[PipelineIssue]:  # noqa: PLR0911 - one return per verdict
    """Whether this stage's reads are met, and how loudly to say so if not.

    Severity is graded by how sure we are, because a wrong hard error is worse than a wrong
    warning: it stops the caller with no recourse and invites them to fake a value to get past
    the gate rather than fix anything. A read that fails on a stage the caller wrote is certain,
    so it is an error. A read that fails inside an expanded composite is reported as a warning
    for now -- the expansion is new, and it earns the right to block only once it has been shown
    not to false-positive on pipelines known to work.
    """
    conflicts = _literal_role_issues(walk, site, contract)
    if conflicts:
        return conflicts
    role_satisfied = _reads_satisfied_by_role(
        contract,
        walk.available,
        walk.segment_available,
        walk.available_keys,
        walk.segment_available_keys,
        walk.possible_keys,
    )
    key_satisfied = _reads_satisfied_by_key(
        contract,
        walk.available_keys,
        walk.segment_available_keys,
        walk.possible_keys,
    )
    if not (role_satisfied or key_satisfied) and not walk.past_composite and site.composite is None:
        conditional = _conditional_read_issue(walk, site, contract)
        if conditional is not None:
            return [conditional]
    if role_satisfied or key_satisfied:
        if walk.past_composite:
            return []
        out: list[PipelineIssue] = []
        dangling = _dangling_read_keys(
            contract,
            walk.available_keys,
            walk.segment_available_keys,
            walk.possible_keys,
        )
        if dangling:
            out.append(
                PipelineIssue(
                    site.index,
                    site.name,
                    "warning",
                    "dangling_key",
                    f"reads key(s) {sorted(dangling)} satisfied by role but not produced upstream "
                    f"under that key value in the required task/nested scope nor seeded "
                    f"(renamed producer key?); available keys: "
                    f"{sorted(walk.available_keys | walk.segment_available_keys)}",
                )
            )
        out.extend(
            _ambiguity_issues(
                site,
                contract,
                walk.available_keys | walk.segment_available_keys,
                walk.key_producer | walk.segment_key_producer,
            )
        )
        return out

    if site.composite is not None:
        composite_name = type(site.composite).__name__
        missing = _missing_read_keys(contract, walk.available_keys, walk.segment_available_keys)
        param = _forwarding_param(site.stage, site.composite, missing)
        remedy = (
            f"set {param} on {composite_name} (it forwards the value to this inner stage)"
            if param
            else "produce the missing key upstream"
        )
        return [
            PipelineIssue(
                site.index,
                site.name,
                "warning",
                "unsatisfied_reads_in_composite",
                f"this stage runs inside {composite_name} and requires "
                f"{_requirement_str(contract, walk.available)}"
                + (f" (key(s) {sorted(missing)})" if missing else "")
                + f", not produced upstream; {remedy}. Available keys: "
                + f"{sorted(walk.available_keys | walk.segment_available_keys)}",
            )
        ]

    if walk.past_composite:
        return [
            PipelineIssue(
                site.index,
                site.name,
                "warning",
                "unsatisfied_reads_after_composite",
                f"requires {_requirement_str(contract, walk.available)} "
                f"not visibly produced — but an upstream composite hides its writes; "
                f"decompose it to validate this read",
            )
        ]

    option_groups = _read_option_groups(contract, walk.available_keys, walk.possible_keys)
    needed = {_read_role(contract, contract.reads, key) for key in contract.reads.data_keys} | {
        _read_role(contract, option, key) for group in option_groups for option in group for key in option.data_keys
    }
    removed_hit = (needed & walk.removed_roles) - walk.available
    if removed_hit:
        return [
            PipelineIssue(
                site.index,
                site.name,
                "error",
                "key_removed_upstream",
                f"reads role(s) {sorted(removed_hit)} that an upstream stage removed "
                f"(removes_keys) and no stage re-produced; available so far: {sorted(walk.available)}",
            )
        ]
    return [
        PipelineIssue(
            site.index,
            site.name,
            "error",
            "unsatisfied_reads",
            f"requires {_requirement_str(contract, walk.available)} "
            f"not produced upstream; available so far: {sorted(walk.available)}",
        )
    ]


def _reads_possibly_satisfied(walk: _Walk, contract: StageContract) -> bool:
    """Whether every read is met once keys upstream MAY write are counted as present.

    Possible keys are credited by LITERAL key only, never by role: a conditional pass-through of
    some other key that happens to share the read's role is too weak a basis to compose on.
    Guaranteed state keeps its normal role-or-literal tolerance.
    """

    def key_ok(key: str, keys: set[str], possible: set[str], roles: set[str], role: str) -> bool:
        if key in keys or key in possible:
            return True
        return role != "unknown" and role in roles

    def spec_ok(spec: Any) -> bool:  # noqa: ANN401 - IOSpec
        return all(
            key_ok(key, walk.available_keys, walk.possible_keys, walk.available, _read_role(contract, spec, key))
            for key in spec.data_keys
        ) and all(
            key_ok(
                key,
                walk.segment_available_keys,
                walk.possible_segment_keys,
                walk.segment_available,
                _read_role(contract, spec, key),
            )
            for key in spec.segment_data_keys
        )

    if not spec_ok(contract.reads):
        return False
    return all(
        any(spec_ok(option) for option in group)
        for group in _read_option_groups(contract, walk.available_keys, walk.possible_keys)
    )


def _conditional_read_issue(walk: _Walk, site: _Site, contract: StageContract) -> PipelineIssue | None:
    """A warning when a read is met only by keys an upstream stage MAY write.

    Metric and hydration stages declare data-dependent outputs as ``conditional_writes`` so the
    planner never advances them as guaranteed. Refusing every consumer of such a key outright
    would make the ordinary ``ComputeWER -> PreserveByValue`` or ``ASR -> Join -> Merge`` chain
    un-plannable, so a read satisfied by the union of guaranteed and possible keys is reported
    as ``conditional_read`` (warning): the pipeline composes, but the consumer must tolerate the
    key being absent on rows where the producing branch did not run. ``report.ok`` stays True;
    callers wanting only guaranteed flow can check ``report.warnings`` for this code.
    """
    if not _reads_possibly_satisfied(walk, contract):
        return None
    option_groups = _read_option_groups(contract, walk.available_keys, walk.possible_keys)
    only_possible = sorted(
        (
            {
                *contract.reads.data_keys,
                *(k for group in option_groups for option in group for k in option.data_keys),
            }
            & walk.possible_keys
        )
        - walk.available_keys
    ) + sorted(
        (
            {
                *contract.reads.segment_data_keys,
                *(k for group in option_groups for option in group for k in option.segment_data_keys),
            }
            & walk.possible_segment_keys
        )
        - walk.segment_available_keys
    )
    return PipelineIssue(
        site.index,
        site.name,
        "warning",
        "conditional_read",
        f"reads key(s) {only_possible} that upstream stages write only conditionally "
        f"(data-dependent branch); rows where that branch does not run will lack the key, so this "
        f"stage must tolerate its absence. Guaranteed keys so far: {sorted(walk.available_keys)}",
    )


def _declared_produces(stage: Any) -> str | None:  # noqa: ANN401 - any recipe stage
    """The task type a stage says it produces, or None if it cannot say.

    Used for a composite the expander could not open: what it is opaque about is the inner
    stages and their writes, not the ``ProcessingStage[X, Y]`` it is declared over. Keeping
    that one fact is what lets the task-type check survive an opaque reader at the head of
    a recipe instead of switching itself off for everything after it.
    """
    try:
        return build_contract(stage).produces_task_type
    except Exception:  # noqa: BLE001 - a stage that cannot describe itself declares nothing
        return None


def _task_types_compatible(produced: str, accepted: str) -> bool:
    """Whether a task of type ``produced`` may be handed to a stage accepting ``accepted``.

    Three ways to be compatible, in the order they cost anything to check:

    * the same name;
    * ``accepted`` is a union (``AudioTask|DocumentBatch``) and ``produced`` is one of its
      members -- a stage that takes either really does take either;
    * ``accepted`` names a BASE of ``produced``. A stage declared over ``Task`` accepts every
      task, and one declared over ``SentinelTask`` accepts ``EmptyTask``; refusing those would
      make the check fire on pipelines that run correctly today, which is the one outcome a
      hard error cannot afford.

    A name that resolves to no task class is treated as incompatible only if the other side
    resolves and disagrees -- see the caller, which skips the check entirely when either side
    is unknown.
    """
    accepted_names = accepted.split("|")
    if produced in accepted_names:
        return True
    produced_cls = _task_class(produced)
    if produced_cls is None:
        return False
    return any((cls := _task_class(name)) is not None and issubclass(produced_cls, cls) for name in accepted_names)


def _task_class(name: str) -> type | None:
    """The task class for a declared type name, or None if it names no known task."""
    from nemo_curator import tasks

    cls = getattr(tasks, name, None)
    return cls if isinstance(cls, type) else None


def _task_type_issue(walk: _Walk, site: _Site, contract: StageContract) -> list[PipelineIssue]:
    """The stage cannot accept the task the one before it produces.

    This is a certainty rather than an inference -- the types come off the ``ProcessingStage[X, Y]``
    generic, not from a heuristic -- so it is an error. It catches the class of recipe that reads
    perfectly at the key level and dies immediately at runtime: a folder source produces an
    ``AudioTask``, ``ManifestReaderStage`` accepts a ``FileGroupTask``, and handed the former it
    treats the row's dict keys as manifest paths and raises ``FileNotFoundError``.

    Skipped whenever either side is unknown -- an unparametrized generic. Unlike the read check
    this survives a composite nobody could expand: what such a composite hides is its inner
    WRITES, while its task types are declared on the class itself. Dropping the check there
    would disable it for most real recipes, which begin at a composite reader.
    """
    produced, accepted = walk.task_type, contract.accepts_task_type
    if not produced or not accepted or _task_types_compatible(produced, accepted):
        return []
    return [
        PipelineIssue(
            site.index,
            site.name,
            "error",
            "task_type_mismatch",
            f"accepts {accepted} but the stage before it produces {produced}; "
            f"insert a stage that converts {produced} to {accepted}, or reorder so the task "
            f"types line up",
        )
    ]


def _revoke_prior_writes(walk: _Walk, contract: StageContract) -> None:
    scopes = (
        (
            contract.invalidates_prior_writes.data_keys,
            walk.available_keys,
            walk.possible_keys,
            walk.key_roles,
            walk.possible_key_roles,
            walk.key_producer,
            walk.unkeyed_roles,
            walk.tensor_keys,
        ),
        (
            contract.invalidates_prior_writes.segment_data_keys,
            walk.segment_available_keys,
            walk.possible_segment_keys,
            walk.segment_key_roles,
            walk.possible_segment_key_roles,
            walk.segment_key_producer,
            walk.unkeyed_segment_roles,
            walk.segment_tensor_keys,
        ),
    )
    for keys, live, possible, roles, possible_roles, producers, unkeyed, tensors in scopes:
        for key in keys:
            unkeyed.difference_update(roles.get(key, set()))
            unkeyed.discard(contract.key_roles.get(key, role_for_value(key)))
            live.discard(key)
            possible.discard(key)
            roles.pop(key, None)
            possible_roles.pop(key, None)
            producers.pop(key, None)
            tensors.discard(key)
    _refresh_role_provenance(walk, contract, set(), set(), [])


def _advance(walk: _Walk, contract: StageContract, name: str) -> None:  # noqa: C901, PLR0915
    """Fold one stage's writes, removals and tensor residency into the running state."""
    produced = _roles_for_keys(contract, contract.writes.data_keys)
    segment_produced = _roles_for_keys(contract, contract.writes.segment_data_keys)
    written = _write_key_values(contract)
    segment_written = _segment_write_key_values(contract)
    # Judged against the INPUT state, before this stage's own possible writes are folded in:
    # a branch must not be made reachable by the key it would itself write.
    reachable_conditionals = _reachable_conditional_writes(walk, contract)
    if contract.invalidates_prior_writes.data_keys or contract.invalidates_prior_writes.segment_data_keys:
        _revoke_prior_writes(walk, contract)
    # Explicit removals/invalidation dominate conditional writes. Rebuilding a row clears
    # inherited keys below, but its declared conditional outputs remain possible outputs.
    blocked_keys = set(contract.removes_keys) | set(contract.invalidates_keys)
    if not contract.preserves_upstream_keys:
        # A stage that rebuilds the task rather than adding to it: whatever it does not write
        # is not downstream. Folding its writes into the inherited state would keep every
        # upstream key alive in the model while the runtime task has already dropped them --
        # the failure mode is a downstream read validating clean and raising on contact.
        # Cleared BEFORE the writes are folded in, so a key this stage re-writes survives on
        # its own authority rather than on the vanished producer's.
        dropped_keys = walk.available_keys - written
        dropped_roles = walk.available - produced
        walk.available_keys -= dropped_keys
        walk.available -= dropped_roles
        walk.possible_keys.clear()
        walk.possible_roles.clear()
        walk.removed_roles |= dropped_roles
        for key in dropped_keys:
            walk.key_producer.pop(key, None)
        # Tensor residency deliberately survives this. The flag is coarser than it looks:
        # ALMDataBuilderStage sets it because SOME branch rebuilds task.data, while still
        # carrying the waveform on the ordinary path. Clearing residency here would retract
        # the ``tensor_into_sink`` block on a pipeline that really does hand a resident
        # waveform to a JSON sink -- a safety gate whose false NEGATIVE is the expensive
        # direction. A stage that genuinely ends residency says so through ``removes_keys``
        # or ``sanitizes_output``, both handled below.
    if not contract.preserves_upstream_keys or not contract.preserves_upstream_segment_keys:
        dropped_segment_keys = walk.segment_available_keys - segment_written
        walk.segment_available_keys -= dropped_segment_keys
        walk.segment_available &= segment_produced
        if contract.preserves_upstream_keys:
            walk.segment_tensor_keys.clear()
        walk.possible_segment_keys.clear()
        walk.possible_segment_roles.clear()
        for key in dropped_segment_keys:
            walk.segment_key_producer.pop(key, None)
    walk.available |= produced
    walk.removed_roles -= produced  # a re-produced role is no longer "removed"
    walk.segment_available |= segment_produced
    # Most recent writer wins -- that is who a downstream reader would actually get.
    walk.key_producer.update(dict.fromkeys(written, name))
    walk.available_keys |= written
    walk.segment_key_producer.update(dict.fromkeys(segment_written, name))
    walk.segment_available_keys |= segment_written
    for reachable in reachable_conditionals:
        # Possible, not guaranteed: kept in the ``possible_*`` sets so a downstream read met
        # only from here surfaces as a ``conditional_read`` warning.
        possible = set(reachable.writes.data_keys) - blocked_keys
        possible_segment = set(reachable.writes.segment_data_keys)
        walk.possible_keys |= possible
        walk.possible_segment_keys |= possible_segment
        walk.possible_roles |= _roles_for_keys(contract, possible)
        walk.possible_segment_roles |= _roles_for_keys(contract, possible_segment)
    for rk in [*contract.removes_keys, *contract.invalidates_keys]:
        walk.available_keys.discard(rk)
        walk.possible_keys.discard(rk)
        if rk in contract.removes_keys:
            # ``removes_keys`` names TOP-LEVEL task keys, so dropping the carrier ends only the
            # top-level tensor residency; a nested (segment) carrier of the same name survives.
            walk.tensor_keys.discard(rk)
        role = contract.key_roles.get(rk, role_for_value(rk))
        if role != "unknown" and not any(role_for_value(k) == role for k in walk.possible_keys):
            walk.possible_roles.discard(role)
        if (
            role != "unknown"
            and role not in produced
            and not any(role_for_value(k) == role for k in walk.available_keys)
        ):
            walk.available.discard(role)
            walk.removed_roles.add(role)
    _advance_tensor_residency(walk, contract, written, segment_written, reachable_conditionals)
    _refresh_role_provenance(walk, contract, written, segment_written, reachable_conditionals)


def _reachable_conditional_writes(walk: _Walk, contract: StageContract) -> list[Any]:
    """The ``conditional_writes`` whose ``requires_keys`` the input so far can actually meet.

    ``requires_keys`` names literal keys, in the write's own scope, that must already exist for
    the branch to run. A file-hydration branch that only REPLACES an incomplete resident pair
    cannot fire on a plain manifest, so its tensor write must neither seed residency (a
    spurious ``tensor_into_sink`` on ``UTMOSFilterStage() -> ManifestWriterStage``) nor be
    credited as a possible output. A write with no ``requires_keys`` is always reachable.
    Reachability is judged against guaranteed AND possible keys -- a possible key can enable a
    possible branch -- which is the conservative direction for the tensor gate.
    """
    task_keys = walk.available_keys | walk.possible_keys
    segment_keys = walk.segment_available_keys | walk.possible_segment_keys
    reachable = []
    for conditional in contract.conditional_writes:
        required = set(getattr(conditional, "requires_keys", ()) or ())
        if not required:
            reachable.append(conditional)
            continue
        scope_keys = (
            segment_keys if conditional.writes.segment_data_keys and not conditional.writes.data_keys else task_keys
        )
        if required <= scope_keys:
            reachable.append(conditional)
    return reachable


def _discard_overwritten_tensor_carriers(
    walk: _Walk, contract: StageContract, written: set[str], segment_written: set[str]
) -> None:
    # Guaranteed scalar/path writes replace that literal's previous tensor. Other carriers
    # and conditional tensor branches survive; an unknown role is not proof of cleanup.
    scalar_roles = {"duration", "sample_rate", "num_samples", "audio_filepath"}
    if "tensor" not in contract.writes.produces:
        for keys, tensor_keys in ((written, walk.tensor_keys), (segment_written, walk.segment_tensor_keys)):
            for key in keys:
                if contract.key_roles.get(key, role_for_value(key)) in scalar_roles:
                    tensor_keys.discard(key)


def _advance_tensor_residency(
    walk: _Walk,
    contract: StageContract,
    written: set[str],
    segment_written: set[str],
    reachable_conditionals: list[Any] | None = None,
) -> None:
    """Fold one stage's tensor writes/sanitization into the per-scope residency sets."""
    _discard_overwritten_tensor_carriers(walk, contract, written, segment_written)
    task_tensor_writes = set(written)
    segment_tensor_writes = set(segment_written)
    has_possible_tensor_write = "tensor" in contract.writes.produces
    if reachable_conditionals is None:
        reachable_conditionals = _reachable_conditional_writes(walk, contract)
    for conditional in reachable_conditionals:
        if "tensor" in conditional.writes.produces:
            has_possible_tensor_write = True
            task_tensor_writes.update(conditional.writes.data_keys)
            segment_tensor_writes.update(conditional.writes.segment_data_keys)
    if has_possible_tensor_write:
        # The stage's OWN key_roles first, global names only as fallback. A custom
        # ``waveform_key`` still declares its role in the contract, but the global lookup
        # returned "unknown", so residency tracked ``_UNNAMED_TENSOR`` instead of the real
        # carrier -- and a downstream stage dropping that carrier still looked resident,
        # raising a spurious ``tensor_into_sink`` on a recipe that had cleaned up correctly.
        task_carriers = {
            key for key in task_tensor_writes if contract.key_roles.get(key, role_for_value(key)) == _TENSOR_ROLE
        }
        segment_carriers = {
            key for key in segment_tensor_writes if contract.key_roles.get(key, role_for_value(key)) == _TENSOR_ROLE
        }
        if task_carriers or segment_carriers:
            walk.tensor_keys |= task_carriers
            walk.segment_tensor_keys |= segment_carriers
        else:
            # ``produces=["tensor"]`` but no waveform-roled key names the carrier: keep the
            # pre-split behaviour of tracking it as a top-level unnamed tensor only a
            # sanitizer can clear.
            walk.tensor_keys |= {_UNNAMED_TENSOR}
    if contract.gates.sanitizes_output:
        walk.tensor_keys.clear()
        walk.segment_tensor_keys.clear()


def _seed_key_roles(keys: set[str], roles: set[str] | None) -> dict[str, set[str]]:
    mapped = {
        key: {role_for_value(key)}
        for key in keys
        if role_for_value(key) != "unknown" and (roles is None or role_for_value(key) in roles)
    }
    if roles is not None and len(keys) == len(roles) == 1 and "unknown" not in roles:
        mapped[next(iter(keys))] = set(roles)
    return mapped


def _seed_walk(  # noqa: PLR0913 -- top-level and nested seeds describe one input task
    initial_roles: set[str] | None,
    initial_keys: set[str] | None,
    initial_tensor_keys: set[str] | None,
    initial_task_type: str | None,
    *,
    initial_segment_roles: set[str] | None = None,
    initial_segment_keys: set[str] | None = None,
    initial_segment_tensor_keys: set[str] | None = None,
) -> _Walk:
    """The state the first stage is handed: what the input task already carries."""
    if initial_keys is not None:
        seed_keys = set(initial_keys)
    elif initial_roles is not None:
        # Both seeds describe ONE task, so they cannot default independently: "no roles" does
        # not also mean "the default columns". Seed only the roles that ARE their own key name --
        # roles and key values coincide for ``audio_filepath`` and diverge immediately after, so
        # seeding ``transcript`` as a literal column invents a key the task does not carry.
        seed_keys = {r for r in initial_roles if role_for_value(r) == r}
    else:
        seed_keys = set(_DEFAULT_INITIAL_KEYS)
    if initial_segment_keys is not None:
        segment_seed_keys = set(initial_segment_keys)
    elif initial_segment_roles is not None:
        # Match top-level inference: only a semantic role that is also its
        # canonical literal key can safely imply a key value.
        segment_seed_keys = {r for r in initial_segment_roles if role_for_value(r) == r}
    else:
        segment_seed_keys = set()
    seed_role_map = _seed_key_roles(seed_keys, initial_roles)
    segment_seed_role_map = _seed_key_roles(segment_seed_keys, initial_segment_roles)
    # An input that arrives carrying a waveform is exactly as resident as one a stage
    # produced, so the serialization gate has to see it. Only writes used to seed this,
    # which left the gate blind to the resident-input case validate_pipeline documents:
    # ``initial_keys={"waveform"}`` into a JSON sink validated clean and then raised
    # ``TypeError: Object of type Tensor is not JSON serializable``.
    if initial_tensor_keys is not None:
        seed_tensors = set(initial_tensor_keys)
    else:
        seed_tensors = {
            key
            for key in seed_keys
            if role_for_value(key) == _TENSOR_ROLE
            and not (initial_roles is not None and seed_role_map.get(key) and _TENSOR_ROLE not in seed_role_map[key])
        }
    if initial_segment_tensor_keys is not None:
        seed_segment_tensors = set(initial_segment_tensor_keys)
    else:
        seed_segment_tensors = {
            key
            for key in segment_seed_keys
            if role_for_value(key) == _TENSOR_ROLE
            and not (
                initial_segment_roles is not None
                and segment_seed_role_map.get(key)
                and _TENSOR_ROLE not in segment_seed_role_map[key]
            )
        }
    return _Walk(
        available=set(initial_roles) if initial_roles is not None else set(_DEFAULT_INITIAL_ROLES),
        available_keys=seed_keys,
        key_roles=seed_role_map,
        segment_key_roles=segment_seed_role_map,
        unkeyed_roles=(set(initial_roles) if initial_roles is not None else set(_DEFAULT_INITIAL_ROLES))
        - {role for values in seed_role_map.values() for role in values},
        unkeyed_segment_roles=set(initial_segment_roles or ())
        - {role for values in segment_seed_role_map.values() for role in values},
        segment_available=set(initial_segment_roles or ()),
        segment_available_keys=segment_seed_keys,
        tensor_keys=seed_tensors,
        segment_tensor_keys=seed_segment_tensors,
        task_type=initial_task_type,
    )


def validate_pipeline(  # noqa: PLR0913 -- keyword-only seeds of one input task, not unrelated knobs
    stages: list[Any],
    *,
    initial_roles: set[str] | None = None,
    initial_keys: set[str] | None = None,
    initial_segment_roles: set[str] | None = None,
    initial_segment_keys: set[str] | None = None,
    initial_tensor_keys: set[str] | None = None,
    initial_segment_tensor_keys: set[str] | None = None,
    initial_task_type: str | None = None,
    available_gpus: float | None = None,
) -> PipelineReport:
    """Validate that an ordered list of configured stages composes.

    Args:
        stages: Configured stage instances in execution order.
        initial_roles: Semantic roles present in the input task. Defaults to
            ``{"audio_filepath"}`` (a manifest row). Pass an explicit set when the
            first stage is a source/reader or the input already carries waveforms.
        initial_keys: Literal key VALUES present in the input task (e.g. the
            columns of the source manifest: ``{"audio_filepath", "text"}``).
            Defaults to ``{"audio_filepath"}``. Seeding this lets the
            literal-key check (``keys_ok``) recognize reads satisfied by the
            input rather than by an upstream producer.
        initial_segment_roles: Semantic roles present inside the input task's
            segment dictionaries. Defaults to an empty nested state.
        initial_segment_keys: Literal key VALUES present inside the input
            task's segment dictionaries. Defaults to an empty nested state.
            When omitted with explicit ``initial_segment_roles``, canonical
            role-as-literal key values are inferred using the top-level policy.
        initial_tensor_keys: Which seeded keys hold a resident tensor. ``None`` --
            the default -- infers them from top-level and segment seed keys by
            role, which covers the canonical ``waveform``. Pass this when the
            input carries a tensor under a name whose role cannot be inferred
            (e.g. ``audio_tensor``).
            Pass an empty set when a schema contains a waveform-named column but
            the input values are known not to be resident tensors.
        initial_segment_tensor_keys: The nested (segment-scope) equivalent of
            ``initial_tensor_keys``. ``None`` -- the default -- infers resident
            segment tensors from the segment seed keys by role. Pass this when a
            segment carries a tensor under a name whose role cannot be inferred.
        initial_task_type: Class name of the task the first stage will be handed
            (e.g. ``"EmptyTask"`` for a pipeline that starts at a source, ``"AudioTask"``
            for a suffix resumed from a manifest). ``None`` -- the default -- leaves the
            first stage's input unchecked rather than guessing at it.
        available_gpus: If given, stages whose contract declares ``requires_gpu``
            while this is ``<= 0`` raise a warning.

    Returns:
        A :class:`PipelineReport`. ``report.ok`` is True when no errors were
        found (role-level); ``report.keys_ok`` additionally confirms literal-key
        identity (see the class docstring).
    """
    walk = _seed_walk(
        initial_roles,
        initial_keys,
        initial_tensor_keys,
        initial_task_type,
        initial_segment_roles=initial_segment_roles,
        initial_segment_keys=initial_segment_keys,
        initial_segment_tensor_keys=initial_segment_tensor_keys,
    )
    expansion = expand_composites(stages)
    leaves = expansion.by_recipe_index()
    opaque = dict(expansion.opaque)
    # A composite with one illegible child is not a composite nobody could open. Discarding the
    # whole group left an eight-stage composite unchecked because one piece of plumbing lacks
    # describe(). Keep child order so only evidence preceding an unknown child is invalidated.
    partly_opaque = {index: reason for index, group in leaves.items() if (reason := _unreadable_child(group))}
    issues: list[PipelineIssue] = []

    for index, recipe_stage in enumerate(stages):
        if index in expansion.unrunnable:
            issues.append(
                PipelineIssue(
                    index,
                    type(recipe_stage).__name__,
                    "error",
                    "composite_unrunnable",
                    f"the executor will refuse this stage: {expansion.unrunnable[index]}",
                )
            )
            _forget_role_provenance(walk)
            walk.task_type = _declared_produces(recipe_stage)
            continue
        if index in opaque:
            issues.append(
                PipelineIssue(
                    index,
                    type(recipe_stage).__name__,
                    "warning",
                    "composite",
                    f"composite stage — its data flow could not be resolved ({opaque[index]}), "
                    f"so reads after it cannot be judged by role",
                )
            )
            _forget_role_provenance(walk)
            walk.task_type = _declared_produces(recipe_stage)
            continue
        if index in partly_opaque:
            issues.append(
                PipelineIssue(
                    index,
                    type(recipe_stage).__name__,
                    "warning",
                    "composite",
                    f"composite stage — part of it is unreadable ({partly_opaque[index]}), "
                    f"so reads after it cannot be judged by role; its remaining stages are "
                    f"still checked",
                )
            )

        for item in leaves.get(index, []):
            stage = item.stage
            if item.composite_ref and not _describes_itself(stage):
                # Invalidate at the actual unknown child, preserving its siblings' order.
                _forget_role_provenance(walk)
                walk.task_type = None
                continue
            try:
                contract = build_contract(stage)
            except Exception as e:  # noqa: BLE001 - a stage that can't describe itself is an error
                issues.append(PipelineIssue(index, item.label, "error", "contract_error", f"describe() failed: {e}"))
                # Its output type is unknown too, so the chain restarts here rather than
                # carrying the last KNOWN type across it and judging the next stage against
                # a task two stages stale.
                walk.task_type = None
                continue
            site = _Site(
                index=index,
                name=item.label if item.composite_ref else (contract.stage_id or type(stage).__name__),
                stage=stage,
                composite=recipe_stage if item.composite_ref else None,
            )

            if not contract.wrappable:
                # It calls itself a composite yet arrived here unexpanded, so it is not a
                # CompositeStage the expander could open. Its real I/O stays unknown and the
                # pre-expansion caution applies: warn, and judge nothing downstream by role.
                issues.append(
                    PipelineIssue(
                        site.index,
                        site.name,
                        "warning",
                        "composite",
                        "composite stage — decompose before validating its data flow",
                    )
                )
                _forget_role_provenance(walk)
                walk.task_type = contract.produces_task_type
                continue

            issues.extend(_read_issues(walk, site, contract))
            issues.extend(_task_type_issue(walk, site, contract))
            # Serialization / GPU gates reason about the environment rather than about roles, so
            # they run for every concrete stage even downstream of a composite nobody could expand.
            issues.extend(
                _gate_issues(
                    site,
                    contract,
                    available_gpus,
                    tensor_resident=bool(walk.tensor_keys or walk.segment_tensor_keys),
                )
            )
            _advance(walk, contract, site.name)
            # An undeclared output type is not "unchanged": it is unknown, and carrying the
            # previous stage's type past it would judge the next stage against a task that is
            # two stages stale.
            walk.task_type = contract.produces_task_type

    return PipelineReport(
        issues=issues,
        produced_roles=walk.available | walk.segment_available,
        produced_keys=walk.available_keys | walk.segment_available_keys,
    )


def _roles_of(spec: Any, contract: StageContract) -> set[str]:  # noqa: ANN401
    keys = [*spec.data_keys, *spec.segment_data_keys]
    return {_read_role(contract, spec, k) for k in keys}
