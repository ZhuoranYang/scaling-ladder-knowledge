# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Audio Data Filter Stage -- CompositeStage that decomposes into independent
pipeline stages for extracting clean single-speaker segments.

Pipeline (when all filters + speaker separation enabled)::

    1. MonoConversion (1:1)
    2. VAD batch mode (1:1, items = N segments)
    3. BandFilter (1:1, filter items)
    4. UTMOS (1:1, filter items)
    5. SIGMOS (1:1, filter items)
    6. SegmentConcatenation (1:1, M items -> 1 item + timestamp mappings)
    7. SpeakerSeparation (1:N fan-out)
    8-11. Per-speaker: VAD + Band + UTMOS + SIGMOS
    12. TimestampMapper (1:1, resolve to original file positions)

Usage::

    # Using default config
    pipeline.add_stage(AudioDataFilterStage())

    # Using custom YAML config
    pipeline.add_stage(AudioDataFilterStage(config_path="/path/to/config.yaml"))
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pathlib import Path

from loguru import logger

from nemo_curator.stages.audio._agent._agent_ready import AgentReady, Gates, StageContract, StaticHints
from nemo_curator.stages.audio.filtering import BandFilterStage, SIGMOSFilterStage, UTMOSFilterStage
from nemo_curator.stages.audio.postprocessing import TimestampMapperStage
from nemo_curator.stages.audio.preprocessing import MonoConversionStage, SegmentConcatenationStage
from nemo_curator.stages.audio.segmentation import SpeakerSeparationStage, VADSegmentationStage
from nemo_curator.stages.base import CompositeStage, ProcessingStage
from nemo_curator.stages.resources import Resources
from nemo_curator.tasks import AudioTask

from .config import _deep_merge, _validate, get_enabled_stages, load_config


class AudioDataFilterStage(AgentReady, CompositeStage[AudioTask, AudioTask]):
    """Complete audio data filtering and curation pipeline (CompositeStage).

    Decomposes into independent stages that the executor can schedule with
    cross-file parallelism.  Each stage owns its own default resource
    allocation.  Use ``.with_()`` to override individual stage resources.

    Supports four pipeline topologies based on which features are enabled:

    - **Combo 1** (VAD=off, Speaker=off): MonoConversion → Filters → TimestampMapper
    - **Combo 2** (VAD=on, Speaker=off): MonoConversion → VAD(fan-out) → Filters → TimestampMapper
    - **Combo 3** (VAD=off, Speaker=on): MonoConversion → Filters → SpeakerSep → Filters → TimestampMapper
    - **Combo 4** (VAD=on, Speaker=on): Full pipeline with SegmentConcat + TimestampMapper

    Args:
        config_path: Path to a YAML config file.  When *None* the
            built-in ``default_config.yaml`` is used.
        config: Pre-loaded config dict (alternative to *config_path*).
            When both are given, *config* values override the YAML file.
        name: Name for this composite stage instance.
    """

    # A configurable VAD adapter may depend on other rows; only an instance can resolve this.
    AGENT_STATIC = StaticHints(gates=Gates(per_row_independent=False))

    def __init__(
        self,
        config_path: str | Path | None = None,
        config: dict[str, Any] | None = None,
        name: str = "AudioDataFilter",
    ) -> None:
        super().__init__()
        self.name = name
        self._cfg = load_config(config_path)
        if config:
            self._cfg = _deep_merge(self._cfg, config)
        _validate(self._cfg)

    def describe(self) -> StageContract:
        per_row_independent = True
        if self._cfg.get("vad", {}).get("enable", True):
            vad = self._make_vad(
                self._cfg,
                suffix="",
                nested=self._cfg.get("speaker_separation", {}).get("enable", True),
            )
            per_row_independent = vad.describe().gates.per_row_independent
        return StageContract(
            wrappable=False,
            # The other delegates are row-local and in-memory. Both VAD passes use the same
            # adapter configuration, so its declaration also covers the per-speaker pass.
            gates=Gates(per_row_independent=per_row_independent),
        )

    def decompose(self) -> list[ProcessingStage]:
        """Build a self-consistent pipeline topology based on enabled features."""
        cfg = self._cfg

        enable_vad = cfg.get("vad", {}).get("enable", True)
        enable_speaker = cfg.get("speaker_separation", {}).get("enable", True)

        if enable_vad and enable_speaker:
            stages = self._build_full_pipeline(cfg)
        elif enable_vad:
            stages = self._build_vad_only_pipeline(cfg)
        elif enable_speaker:
            stages = self._build_speaker_only_pipeline(cfg)
        else:
            stages = self._build_filters_only_pipeline(cfg)

        enabled = get_enabled_stages(cfg)
        logger.info(
            f"AudioDataFilterStage decomposed into {len(stages)} stages "
            f"(enabled: {enabled}, speaker_sep: {enable_speaker})"
        )
        return stages

    # ------------------------------------------------------------------
    # Topology builders (one per feature combination)
    # ------------------------------------------------------------------

    def _build_full_pipeline(self, cfg: dict) -> list[ProcessingStage]:
        """Combo 4: VAD=on, Speaker=on.  Identical to the original design."""
        stages: list[ProcessingStage] = [self._make_mono(cfg)]

        stages.append(self._make_vad(cfg, suffix="", nested=True))
        self._append_quality_filters(stages, cfg, suffix="")

        concat = cfg.get("concatenation", {})
        stages.append(
            SegmentConcatenationStage(
                silence_duration_sec=concat.get("silence_duration_sec", 0.5),
                name="SegmentConcat",
                resources=Resources(cpus=concat.get("cpus", 1.0)),
            )
        )

        stages.append(self._make_speaker_sep(cfg))

        stages.append(self._make_vad(cfg, suffix="_Speaker", nested=False))
        self._append_quality_filters(stages, cfg, suffix="_Speaker")

        stages.append(self._make_timestamp_mapper(cfg))
        return stages

    def _build_vad_only_pipeline(self, cfg: dict) -> list[ProcessingStage]:
        """Combo 2: VAD=on, Speaker=off.  VAD fans out, OutputNormalizer cleans up."""
        stages: list[ProcessingStage] = [self._make_mono(cfg)]

        stages.append(self._make_vad(cfg, suffix="", nested=False))
        self._append_quality_filters(stages, cfg, suffix="")

        stages.append(self._make_timestamp_mapper(cfg))
        return stages

    def _build_speaker_only_pipeline(self, cfg: dict) -> list[ProcessingStage]:
        """Combo 3: VAD=off, Speaker=on.  SpeakerSep fans out with diar_segments."""
        stages: list[ProcessingStage] = [self._make_mono(cfg)]

        self._append_quality_filters(stages, cfg, suffix="")

        stages.append(self._make_speaker_sep(cfg))

        self._append_quality_filters(stages, cfg, suffix="_Speaker")

        stages.append(self._make_timestamp_mapper(cfg))
        return stages

    def _build_filters_only_pipeline(self, cfg: dict) -> list[ProcessingStage]:
        """Combo 1: VAD=off, Speaker=off.  Filters only, TimestampMapper cleans up."""
        stages: list[ProcessingStage] = [self._make_mono(cfg)]

        self._append_quality_filters(stages, cfg, suffix="")

        stages.append(self._make_timestamp_mapper(cfg))
        return stages

    # ------------------------------------------------------------------
    # Stage factories
    # ------------------------------------------------------------------

    @staticmethod
    def _make_mono(cfg: dict) -> MonoConversionStage:
        mc = cfg.get("mono_conversion", {})
        return MonoConversionStage(
            output_sample_rate=mc.get("output_sample_rate", 48000),
            strict_sample_rate=mc.get("strict_sample_rate", True),
            name="MonoConversion",
            resources=Resources(cpus=mc.get("cpus", 1.0)),
        )

    @staticmethod
    def _make_vad(cfg: dict, *, suffix: str, nested: bool) -> VADSegmentationStage:
        vad = cfg.get("vad", {})
        stage = VADSegmentationStage(
            adapter_target=vad.get(
                "adapter_target",
                "nemo_curator.models.audio.vad.silero.SileroVADAdapter",
            ),
            adapter_kwargs=vad.get("adapter_kwargs", {}),
            min_duration_sec=vad.get("min_duration_sec", 2.0),
            max_duration_sec=vad.get("max_duration_sec", 60.0),
            threshold=vad.get("threshold", 0.5),
            min_interval_ms=vad.get("min_interval_ms", 500),
            speech_pad_ms=vad.get("speech_pad_ms", 300),
            nested=nested,
            name=f"VAD{suffix}",
            batch_size=vad.get("batch_size", 1),
            resources=Resources(
                cpus=vad.get("cpus", 1.0),
                gpus=vad.get("gpus", 0.0),
            ),
        )
        num_workers = vad.get("num_workers")
        return stage.with_(num_workers=num_workers) if num_workers is not None else stage

    @staticmethod
    def _make_speaker_sep(cfg: dict) -> SpeakerSeparationStage:
        speaker = cfg.get("speaker_separation", {})
        return SpeakerSeparationStage(
            exclude_overlaps=speaker.get("exclude_overlaps", True),
            min_duration=speaker.get("min_duration", 0.8),
            gap_threshold=speaker.get("gap_threshold", 0.1),
            buffer_time=speaker.get("buffer_time", 0.5),
            name="SpeakerSeparation",
            resources=Resources(
                cpus=speaker.get("cpus", 1.0),
                gpus=speaker.get("gpus", 1.0),
            ),
        )

    @staticmethod
    def _make_timestamp_mapper(cfg: dict) -> TimestampMapperStage:
        ts = cfg.get("timestamp_mapper", {})
        return TimestampMapperStage(
            passthrough_keys=ts.get("passthrough_keys"),
            name="TimestampMapper",
            resources=Resources(cpus=ts.get("cpus", 1.0)),
        )

    # ------------------------------------------------------------------
    # Quality filter helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _append_quality_filters(
        stages: list[ProcessingStage],
        cfg: dict,
        *,
        suffix: str,
    ) -> None:
        """Append quality filter stages (Band, UTMOS, SIGMOS) to *stages*."""
        band = cfg.get("band_filter", {})
        utmos = cfg.get("utmos", {})
        sigmos = cfg.get("sigmos", {})

        if band.get("enable", True):
            stages.append(
                BandFilterStage(
                    band_value=band.get("band_value", "full_band"),
                    name=f"BandFilter{suffix}",
                    resources=Resources(
                        cpus=band.get("cpus", 1.0),
                        gpus=band.get("gpus", 0.0),
                    ),
                )
            )

        if utmos.get("enable", True):
            stages.append(
                UTMOSFilterStage(
                    mos_threshold=utmos.get("mos_threshold", 3.5),
                    name=f"UTMOS{suffix}",
                    resources=Resources(
                        cpus=utmos.get("cpus", 1.0),
                        gpus=utmos.get("gpus", 0.5),
                    ),
                )
            )

        if sigmos.get("enable", True):
            stages.append(
                SIGMOSFilterStage(
                    noise_threshold=sigmos.get("noise_threshold", 4.0),
                    ovrl_threshold=sigmos.get("ovrl_threshold", 3.5),
                    sig_threshold=sigmos.get("sig_threshold"),
                    col_threshold=sigmos.get("col_threshold"),
                    disc_threshold=sigmos.get("disc_threshold"),
                    loud_threshold=sigmos.get("loud_threshold"),
                    reverb_threshold=sigmos.get("reverb_threshold"),
                    name=f"SIGMOS{suffix}",
                    resources=Resources(
                        cpus=sigmos.get("cpus", 1.0),
                        gpus=sigmos.get("gpus", 0.5),
                    ),
                )
            )
