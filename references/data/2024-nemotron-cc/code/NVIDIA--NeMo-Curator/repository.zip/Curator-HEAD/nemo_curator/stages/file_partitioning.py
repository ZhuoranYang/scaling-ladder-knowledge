# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dataclasses import dataclass
from typing import Any

from loguru import logger

from nemo_curator.stages.base import ProcessingStage
from nemo_curator.stages.resources import Resources
from nemo_curator.tasks import EmptyTask, FileGroupTask
from nemo_curator.utils.file_utils import (
    _split_files_as_per_blocksize,
    get_all_file_paths_and_size_under,
    infer_dataset_name_from_path,
    parse_bytes_string_to_int,
)


@dataclass
class FilePartitioningStage(ProcessingStage[EmptyTask, FileGroupTask]):
    """Stage that partitions input file paths into FileGroupTasks.

    This stage runs as a dedicated processing stage (not on the driver)
    and creates file groups based on the partitioning strategy.

    Parameters
    ----------
    file_paths: str | list[str]
        Path to the input files.
    files_per_partition: int | None = None
        Number of files per partition.
        If both files_per_partition and blocksize are not provided,
        then default to files_per_partition = 1 and enforce a blocksize <= 512 MB per partition safeguard.
        Errors if both files_per_partition and blocksize are provided.
    blocksize: int | str | None = None
        Target size of the partitions. A blocksize of 512 MB or less is recommended.
        Errors if both files_per_partition and blocksize are provided.
        Note: For compressed files, the compressed size is used for blocksize estimation.
    file_extensions: list[str] | None = None
        File extensions to filter.
    storage_options: dict[str, Any] | None = None
        Storage options to pass to the file system.
    limit: int | None = None
        Maximum number of partitions to create.
    include_file_size: bool = False
        Include each partition's total file size as ``task_weight`` metadata.
    """

    file_paths: str | list[str]
    files_per_partition: int | None = None
    blocksize: int | str | None = None
    file_extensions: list[str] | None = None
    storage_options: dict[str, Any] | None = None
    limit: int | None = None
    name: str = "file_partitioning"
    include_file_size: bool = False

    def __post_init__(self):
        """Initialize default values."""
        if self.files_per_partition is not None and self.blocksize is not None:
            msg = "Both 'files_per_partition' and 'blocksize' were specified, but only one is allowed"
            raise ValueError(msg)
        if self.file_extensions is None:
            self.file_extensions = [".jsonl", ".json", ".parquet"]
        if self.storage_options is None:
            self.storage_options = {}

        # self.blocksize is the value set by the user
        # self._blocksize is the value used internally
        if self.blocksize is not None:
            self._blocksize = parse_bytes_string_to_int(self.blocksize)
        else:
            self._blocksize = parse_bytes_string_to_int("512MB")

        if self._blocksize > parse_bytes_string_to_int("512MB"):
            msg = (
                f"Blocksize is greater than 512 MB, which is not recommended: {self.blocksize} "
                "Consider using a smaller blocksize to avoid potential memory issues."
            )
            logger.warning(msg)

        self.resources = Resources(cpus=0.5)

    def inputs(self) -> tuple[list[str], list[str]]:
        return [], []

    def outputs(self) -> tuple[list[str], list[str]]:
        return [], []

    def num_workers(self) -> int | None:
        return 1

    def process(self, _: EmptyTask) -> list[FileGroupTask]:
        """Process the initial task to create file group tasks.

        This stage expects a simple Task with file paths information
        and outputs multiple FileGroupTasks for parallel processing.
        """
        sort_by_size = self.blocksize is not None
        files_with_sizes = self._get_file_list_with_sizes(sort_by_size)
        # Extract list[str] from list[tuple[str, int]]
        files = [file[0] for file in files_with_sizes]

        logger.info(f"Found {len(files)} files")
        if len(files) == 0:
            logger.warning(f"No files found under {self.file_paths}")
            return []

        # Partition files
        if self.files_per_partition:
            partitions = self._partition_by_count(files, self.files_per_partition)
        elif self.blocksize:
            partitions = self._partition_by_size(files_with_sizes, self._blocksize)
        else:
            # Default to one file per partition
            logger.info("No partitions specified, defaulting to one file per partition")
            partitions = self._partition_by_count(files, 1)

        # Build a dictionary of path: size of all files
        path_to_size: dict[str, int] = dict(files_with_sizes)

        # Check that no files have size less than 0 (since -1 is used to indicate unknown size)
        has_unknown_sizes = any(size < 0 for size in path_to_size.values())
        if has_unknown_sizes:
            msg = "Skipping storage limit check because some files have unknown size"
            logger.warning(msg)
        else:
            # Verify storage size of input files is not greater than self._blocksize (512 MB by default)
            # This should be a very quick check per file, so we do it first before reading the data
            for partition in partitions:
                total_storage_size = sum(path_to_size[path] for path in partition)
                # Scenario 1: The user specified blocksize and the partition created is too large
                # This means at least one file is larger than the blocksize
                if self.blocksize is not None and total_storage_size > self._blocksize:
                    msg = (
                        f"File group task has exceeded the storage limit per partition: {partition}. "
                        f"Total storage size is {total_storage_size} bytes (limit {self._blocksize} bytes). "
                        "Please increase blocksize if possible (the maximum recommended blocksize is 512 MB). "
                        "Any individual file(s) larger than the storage limit should be split into smaller chunks using nemo_curator.utils.split_large_files."
                    )
                    logger.warning(msg)
                # Scenario 2: The user did not specify blocksize and the partition created is too large
                elif total_storage_size > self._blocksize:
                    msg = (
                        f"File group task has exceeded the storage limit per partition: {partition}. "
                        f"Total storage size is {total_storage_size} bytes (limit {self._blocksize} bytes). "
                        "Please reduce files_per_partition if possible, or set blocksize instead (the maximum recommended blocksize is 512 MB). "
                        "Any individual file(s) larger than the storage limit should be split into smaller chunks using nemo_curator.utils.split_large_files."
                    )
                    logger.warning(msg)

        # Create FileGroupTask for each partition
        tasks = []
        dataset_name = self._get_dataset_name(files)

        for i, file_group in enumerate(partitions):
            if self.limit is not None and len(tasks) >= self.limit:
                # We should revisit this behavior.
                # https://github.com/NVIDIA-NeMo/Curator/issues/948
                logger.info(f"Reached limit of {self.limit} file groups")
                break
            partition_sizes = [path_to_size[path] for path in file_group]
            task_weight = (
                sum(partition_sizes) if self.include_file_size and all(size >= 0 for size in partition_sizes) else None
            )
            metadata = {
                "partition_index": i,
                "total_partitions": len(partitions),
                "source_files": file_group,  # Add source files for deterministic naming during write stage
                **({"task_weight": task_weight} if task_weight is not None else {}),
            }
            file_task = FileGroupTask(
                dataset_name=dataset_name,
                data=file_group,
                _metadata=metadata,
                reader_config={},  # Empty - will be populated by reader stage
            )
            tasks.append(file_task)

        logger.info(f"Created {len(tasks)} file groups from {len(files)} files")
        return tasks

    def _get_file_list_with_sizes(self, sort_by_size: bool = True) -> list[tuple[str, int]]:
        """
        Get the list of files to process.
        """
        logger.debug(f"Getting file list with sizes for {self.file_paths}")
        if isinstance(self.file_paths, str):
            # Directory: list contents (recursively) and filter extensions
            output_ls = get_all_file_paths_and_size_under(
                self.file_paths,
                recurse_subdirectories=True,
                keep_extensions=self.file_extensions,
                storage_options=self.storage_options,
                sort_by_size=sort_by_size,
            )
        elif isinstance(self.file_paths, list):
            output_ls = []
            for path in self.file_paths:
                output_ls.extend(
                    get_all_file_paths_and_size_under(
                        path,
                        recurse_subdirectories=False,
                        keep_extensions=self.file_extensions,
                        storage_options=self.storage_options,
                        sort_by_size=sort_by_size,
                    )
                )
        else:
            msg = f"Invalid file paths: {self.file_paths}, must be a string or list of strings"
            raise TypeError(msg)
        return sorted(output_ls, key=lambda x: x[1] if sort_by_size else x[0])

    def _get_dataset_name(self, files: list[str]) -> str:
        """Extract dataset name from file paths (fsspec-compatible)."""
        if not files:
            return "dataset"

        return infer_dataset_name_from_path(files[0])

    def _partition_by_count(self, files: list[str], count: int) -> list[list[str]]:
        """Partition files by count."""
        partitions = []
        for i in range(0, len(files), count):
            partitions.append(files[i : i + count])
        return partitions

    def _partition_by_size(self, files: list[tuple[str, int]], blocksize: int | str) -> list[list[str]]:
        """Partition files by target size.
        Args:
            files: A list of tuples (file_path, file_size)
            blocksize: The target size of the partitions
        Returns:
            A list of lists, where each inner list contains the file paths of the files in the partitionN
        """
        sorted_files = sorted(files, key=lambda x: x[1])
        return _split_files_as_per_blocksize(sorted_files, blocksize)
