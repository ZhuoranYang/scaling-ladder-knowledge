# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Rule-based detection of common ASR hallucination patterns.

No model and no GPU: these are cheap lexical heuristics meant to run over
transcripts that an ASR stage already produced, flagging rows that look
confabulated rather than transcribed.
"""

from dataclasses import dataclass, field
from typing import Any

from loguru import logger

from nemo_curator.stages.audio.text_filtering.scriptio_continua import is_scriptio_continua
from nemo_curator.stages.base import ProcessingStage
from nemo_curator.stages.resources import Resources
from nemo_curator.tasks import AudioTask

# Languages that legitimately produce very long single words, either by
# agglutination or by compounding. The relative long-word check is disabled
# for these languages, and they use a separate absolute threshold.
AGGLUTINATIVE_COMPOUNDING_LANGS: frozenset[str] = frozenset(
    {
        "fi",
        "hu",
        "et",  # Uralic agglutinative
        "de",
        "nl",
        "da",
        "sv",
        "no",  # Germanic compounding
    }
)


@dataclass
class WhisperHallucinationStage(ProcessingStage[AudioTask, AudioTask]):
    """Flag transcripts that show common ASR hallucination patterns.

    Four independent checks run, and any single hit flags the row:

    - **Repeated n-grams**: the unique-word ratio falls to or below
      ``unique_words_threshold``, the signature of a decoder stuck in a loop.
    - **Long word**: a word at or over the language-appropriate absolute length
      bar, or one much longer than the next-longest word by
      ``long_word_rel_threshold``.
    - **Phrase match**: the transcript is a known hallucination phrase or an
      approved continuation from ``common_hall_file`` (think "Thank you for
      watching" over silence).
    - **High char rate**: characters per second exceed ``max_char_rate``, an
      impossible speaking rate, which catches dense text confabulated over a
      very short clip.

    Repeated-word and long-word checks are disabled for languages written
    without word-separating spaces because whitespace tokenization treats an
    entire utterance as one word. Phrase and character-rate checks remain
    active for those languages.

    When flagged, ``skip_me_key`` is set to ``"Hallucination:{name}"`` so the
    originating instance stays identifiable. An existing non-hallucination flag
    from some other filter is never clobbered. Setting ``overwrite=True`` turns
    the stage into a re-check that can also *clear* a previous hallucination
    flag when a second-pass transcript now looks clean, which is how an ASR
    recovery pass promotes its result.

    ``recovery_value`` is a caller-selected note written only when
    ``overwrite=True`` clears an existing hallucination flag. For example,
    ``recovery_value="Recovered:ASR"`` produces the note ``"recovered:asr"``.
    Leaving it empty produces ``"recovered"``.

    Run the bundled YAML from the Curator repository root over a JSONL manifest
    that already contains ``pred_text``, ``_skipme``, and ``duration``:

    .. code-block:: bash

        python nemo_curator/config/run.py \\
            --config-path ../../tutorials/audio/whisper_hallucination \\
            --config-name pipeline \\
            manifest_path=tests/fixtures/audio/text_filtering/whisper_hallucination_input.jsonl \\
            output_path=/tmp/whisper_hallucination_output.jsonl
    """

    common_hall_file: str
    unique_words_threshold: float = 0.4
    long_word_threshold: int = 25
    agglutinative_long_word_threshold: int = 35
    long_word_rel_threshold: float = 3.0
    max_char_rate: float = 40.0
    language_key: str = "language"
    duration_key: str = "duration"
    text_key: str = "pred_text"
    skip_me_key: str = "_skipme"
    notes_key: str = "additional_notes"
    overwrite: bool = False
    recovery_value: str = ""
    name: str = "WhisperHallucination"
    resources: Resources = field(default_factory=lambda: Resources(cpus=1.0))

    _phrases: set[str] = field(default_factory=set, init=False, repr=False)
    _n_processed: int = field(default=0, init=False, repr=False)
    _n_flagged: int = field(default=0, init=False, repr=False)

    # Long phrases such as "Thank you" intentionally match their common
    # Whisper-generated continuations.
    _PREFIX_MATCH_MIN_LEN: int = 8

    def _set_note(self, task_data: dict[str, Any], value: str) -> None:
        notes = task_data.get(self.notes_key)
        if not isinstance(notes, dict):
            notes = {}
            task_data[self.notes_key] = notes
        notes[self.name] = value

    @staticmethod
    def _normalize_corpus_phrase(text: str) -> str:
        return text.strip().replace(".", "").replace("?", "").replace("!", "").replace(",", "")

    @staticmethod
    def _transcript_candidates(text: str) -> set[str]:
        cleaned = text.strip().replace(".", "").replace("?", "").replace("!", "").replace(",", "")
        candidates = {cleaned}
        if "-" in cleaned:
            candidates.add(cleaned.replace("-", " "))
        return candidates

    def setup(self, _worker_metadata: object | None = None) -> None:
        with open(self.common_hall_file, encoding="utf-8") as f:
            phrases = {self._normalize_corpus_phrase(line) for line in f if line.strip()}
        self._phrases = phrases
        logger.info(f"WhisperHallucinationStage: loaded {len(phrases)} phrases from {self.common_hall_file}")

    def inputs(self) -> tuple[list[str], list[str]]:
        return [], [self.text_key, self.duration_key]

    def outputs(self) -> tuple[list[str], list[str]]:
        return [], [self.skip_me_key, self.notes_key]

    def _repeated_ngrams(self, words: list[str]) -> bool:
        if not words:
            return False
        return len(set(words)) / len(words) <= self.unique_words_threshold

    def _long_word(self, words: list[str], threshold: int | None = None, skip_relative: bool = False) -> bool:
        if not words:
            return False
        effective_threshold = threshold if threshold is not None else self.long_word_threshold
        lengths = sorted(len(w) for w in words)
        if lengths[-1] >= effective_threshold:
            return True
        if skip_relative:
            return False
        if len(lengths) > 1 and lengths[-2] > 0:
            return (lengths[-1] - lengths[-2]) / lengths[-2] >= self.long_word_rel_threshold
        return False

    def _frequent_single_word(self, text: str) -> bool:
        candidates = self._transcript_candidates(text)
        if candidates & self._phrases:
            return True
        return any(
            len(phrase) >= self._PREFIX_MATCH_MIN_LEN and candidate.startswith(phrase)
            for phrase in self._phrases
            for candidate in candidates
        )

    def _high_char_rate(self, words: list[str], duration: float) -> bool:
        if duration <= 0:
            return False
        chars = sum(len(w) for w in words)
        return chars / duration > self.max_char_rate

    def _is_agglutinative(self, task: AudioTask) -> bool:
        lang = str(task.data.get(self.language_key, "")).lower().strip()
        return lang in AGGLUTINATIVE_COMPOUNDING_LANGS

    def _is_scriptio_continua(self, task: AudioTask) -> bool:
        return is_scriptio_continua(task.data.get(self.language_key))

    def process(self, task: AudioTask) -> AudioTask:
        current_flag = str(task.data.setdefault(self.skip_me_key, ""))
        if not self.overwrite and current_flag:
            self._set_note(task.data, "skipped (flagged)")
            return task
        text = task.data[self.text_key]
        if not isinstance(text, str) or not text.strip():
            self._set_note(task.data, "skipped (empty text)")
            return task
        words = text.split()
        duration = task.data.get(self.duration_key, 0.0) or 0.0

        is_agglutinative = self._is_agglutinative(task)
        long_word_thresh = self.agglutinative_long_word_threshold if is_agglutinative else self.long_word_threshold
        word_checks_apply = not self._is_scriptio_continua(task)
        repeated = self._repeated_ngrams(words) if word_checks_apply else False
        long_w = (
            self._long_word(words, threshold=long_word_thresh, skip_relative=is_agglutinative)
            if word_checks_apply
            else False
        )
        phrase = self._frequent_single_word(text)
        high_rate = self._high_char_rate(words, duration)

        self._n_processed += 1
        is_hallucinated = repeated or long_w or phrase or high_rate
        was_flagged = current_flag.startswith("Hallucination")
        if is_hallucinated:
            self._n_flagged += 1
            reasons = [
                name
                for name, hit in [
                    ("repeated_ngrams", repeated),
                    ("long_word", long_w),
                    ("phrase_match", phrase),
                    ("high_char_rate", high_rate),
                ]
                if hit
            ]
            logger.debug(f"[{self.name}] flagged ({','.join(reasons)}) dur={duration:.2f}s: {text[:80]!r}")
            if was_flagged or not current_flag:
                task.data[self.skip_me_key] = f"Hallucination:{self.name}"
            self._set_note(task.data, f"hallucination ({', '.join(reasons)})")
        elif self.overwrite and was_flagged:
            task.data[self.skip_me_key] = ""
            recovery_note = self.recovery_value.lower() if self.recovery_value else "recovered"
            self._set_note(task.data, recovery_note)
        else:
            self._set_note(task.data, "passed")
        return task

    def teardown(self) -> None:
        logger.info(f"[{self.name}] done — processed={self._n_processed}, flagged={self._n_flagged}")
