# Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Chinese text conversion stage (Traditional -> Simplified, etc.)."""

from dataclasses import KW_ONLY, dataclass, field
from typing import Any

from loguru import logger
from opencc import OpenCC

from nemo_curator.backends.base import WorkerMetadata
from nemo_curator.stages.audio._agent._agent_ready import (
    AgentReady,
    ConditionalWrite,
    Gates,
    IOSpec,
    StageContract,
)
from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import AudioTask


@dataclass
class ChineseConversionStage(AgentReady, ProcessingStage[AudioTask, AudioTask]):
    """Convert Traditional Chinese text to Simplified Chinese (or other OpenCC conversions).

    Iterates over the ``segments`` list of each entry and writes the converted
    text to ``{text_key}_simplified``.  If conversion fails for a segment the
    original text is kept as a fallback.

    Args:
        text_key:     Manifest key holding the text to convert.
        convert_type: OpenCC conversion type (e.g. ``"t2s"``, ``"s2t"``).
    """

    # Legacy positional slots (pre-agent order preserved).
    text_key: str = "text"
    convert_type: str = "t2s"

    # Stage metadata
    name: str = "ChineseConversion"

    # Internal state
    _converter: Any = field(default=None, repr=False)

    # Agent-added knobs are keyword-only (KW_ONLY sentinel) so the legacy positional slots
    # above keep their historical order and meaning.
    _: KW_ONLY
    segments_key: str = "segments"
    output_suffix: str = "_simplified"

    def inputs(self) -> tuple[list[str], list[str]]:
        return [], [self.segments_key]

    def outputs(self) -> tuple[list[str], list[str]]:
        return [], [self.segments_key]

    def describe(self) -> StageContract:
        return StageContract(
            reads=IOSpec(data_keys=[self.segments_key]),
            optional_reads=IOSpec(segment_data_keys=[self.text_key]),
            key_roles={f"{self.text_key}{self.output_suffix}": "text"},
            conditional_writes=[
                ConditionalWrite(
                    writes=IOSpec(segment_data_keys=[f"{self.text_key}{self.output_suffix}"]),
                    requires_keys=[self.text_key],
                    condition=f"an item in '{self.segments_key}' contains '{self.text_key}'",
                )
            ],
            # The OpenCC mapping is fixed by ``convert_type``; each segment's text converts alone.
            gates=Gates(per_row_independent=True),
        )

    def setup(self, _worker_metadata: WorkerMetadata | None = None) -> None:
        """Setup stage."""
        if self._converter is None:
            self._converter = OpenCC(self.convert_type)
        logger.info(f"[{self.name}] Using conversion type: {self.convert_type}")

    def process(self, task: AudioTask) -> AudioTask:
        data_entry = task.data
        output_key = f"{self.text_key}{self.output_suffix}"
        for segment in data_entry.get(self.segments_key, []):
            if self.text_key in segment:
                try:
                    segment[output_key] = self._converter.convert(segment[self.text_key])
                except Exception:  # noqa: BLE001
                    logger.warning(f"[{self.name}] Chinese conversion failed, keeping original")
                    segment[output_key] = segment[self.text_key]

        return task
