"""Audio model implementations."""
