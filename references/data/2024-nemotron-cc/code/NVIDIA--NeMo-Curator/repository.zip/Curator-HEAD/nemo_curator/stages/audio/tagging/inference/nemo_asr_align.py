# Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
NeMo ASR Aligner Stage.

Contains BaseASRProcessorStage (shared config and segment preparation)
and NeMoASRAlignerStage (forced alignment via NeMo FastConformer).

These stages are tagging-pipeline-specific because they operate on
tagging manifest keys like ``split_filepaths``, ``split_metadata``,
and ``segments``.
"""

import time
from dataclasses import KW_ONLY, dataclass, field
from typing import Any, ClassVar

import nemo.collections.asr as nemo_asr
import torch
import torchaudio
from loguru import logger
from nemo.collections.asr.parts.submodules.ctc_decoding import CTCDecodingConfig
from nemo.collections.asr.parts.submodules.rnnt_decoding import RNNTDecodingConfig

from nemo_curator.backends.base import NodeInfo, WorkerMetadata
from nemo_curator.stages.audio._agent._agent_ready import (
    AgentReady,
    ConditionalWrite,
    Gates,
    IOSpec,
    StageContract,
    StaticHints,
)
from nemo_curator.stages.base import ProcessingStage
from nemo_curator.stages.resources import Resources
from nemo_curator.tasks import AudioTask


@dataclass
class BaseASRProcessorStage(AgentReady, ProcessingStage[AudioTask, AudioTask]):
    """Base class for ASR stages with shared config and segment preparation.

    Provides common fields and _prepare_segment_batch_with_metadata for
    segment-only inference. Subclasses must implement setup() and process().

    Args:
        min_len: Minimum length of audio segments to process (seconds).
        max_len: Maximum length of audio segments to process (seconds).
        dataloader_num_workers: Number of workers for data loading.
        split_batch_size: Max entries/paths per batch when chunking.
        infer_segment_only: If True, process segments only; else full audio / meta-entries.
        text_key: Key for predicted text in manifest.
        words_key: Key for word alignments in manifest (same as SDP alignment_key).
        compute_timestamps: Whether to compute word-level timestamps.
        segments_key: Key for segments list in manifest.
    """

    # Legacy positional slots (pre-agent order preserved).
    # Length constraints
    min_len: float = 1.0
    max_len: float = 40.0

    # Processing parameters
    batch_size: int = 32
    dataloader_num_workers: int = 10
    split_batch_size: int = 5000
    infer_segment_only: bool = False

    # Output keys
    text_key: str = "text"
    words_key: str = "words"

    compute_timestamps: bool = True
    segments_key: str = "segments"

    # Stage metadata (subclasses can override)
    name: str = "BaseASRProcessor"
    resources: Resources = field(default_factory=lambda: Resources(gpus=1))

    # Agent-added knobs are keyword-only (KW_ONLY sentinel) so the legacy positional slots
    # above keep their historical order and meaning.
    _: KW_ONLY
    alignment_key: str = "alignment"
    audio_filepath_key: str = "audio_filepath"
    resampled_audio_filepath_key: str = "resampled_audio_filepath"
    split_filepaths_key: str = "split_filepaths"
    split_metadata_key: str = "split_metadata"

    @property
    def _device(self) -> str:
        """Derive device from resources configuration."""
        return "cuda" if self.resources.requires_gpu else "cpu"

    def _prepare_segment_batch_with_metadata(
        self,
        metadata_batch: list[dict],
        cut_audio_segments: bool = False,
        segments_key: str = "segments",
    ) -> list[dict]:
        """Prepare segment metadata for a batch.

        Collects segment metadata with indices for later processing. Mirrors
        generic_sdp BaseASRProcessor._prepare_segment_batch_with_metadata.

        Args:
            metadata_batch: List of metadata dicts, each with a segments list.
            cut_audio_segments: If True, load audio and cut segments (numpy);
                if False, only collect resampled_audio_filepath from segments.
            segments_key: Key for the segments list in each metadata dict.

        Returns:
            List of segment metadata dicts with metadata_idx, segment_idx, and
            either "audio_segment" (numpy) or "resampled_audio_filepath".
        """
        segment_metadata_list: list[dict] = []

        if cut_audio_segments:
            for metadata_idx, metadata in enumerate(metadata_batch):
                audio_path = metadata.get(self.resampled_audio_filepath_key, metadata.get(self.audio_filepath_key))
                if not audio_path:
                    continue
                audio, sr = torchaudio.load(audio_path)
                for segment_idx, segment in enumerate(metadata.get(segments_key, [])):
                    duration = segment.get("end", 0) - segment.get("start", 0)
                    if duration >= self.min_len:
                        start = int(segment["start"] * sr)
                        end = int(segment["end"] * sr)
                        audio_segment = audio[:, start:end].squeeze(0)
                        if len(audio_segment) > 0:
                            segment_metadata_list.append(
                                {
                                    "audio_segment": audio_segment.numpy(),
                                    "metadata_idx": metadata_idx,
                                    "segment_idx": segment_idx,
                                }
                            )
        else:
            for metadata_idx, metadata in enumerate(metadata_batch):
                for segment_idx, segment in enumerate(metadata.get(segments_key, [])):
                    if self.resampled_audio_filepath_key in segment:
                        segment_metadata_list.append(
                            {
                                self.resampled_audio_filepath_key: segment[self.resampled_audio_filepath_key],
                                "metadata_idx": metadata_idx,
                                "segment_idx": segment_idx,
                            }
                        )

        return segment_metadata_list


@dataclass
class NeMoASRAlignerStage(BaseASRProcessorStage):
    """
    Stage that aligns text and audio using NeMo ASR models.

    Uses a pre-trained ASR model to transcribe audio files and generate
    word-level alignments with timestamps. Supports both CTC and RNNT decoders and
    can process either full audio files or just specific segments.

    Args:
        model_name (str): Name of pretrained model to use. Defaults to "nvidia/parakeet-tdt_ctc-1.1b"
        model_path (str, Optional): Path to local model file. If provided, overrides model_name
        is_fastconformer (bool): Whether model's encoder is FastConformer
        decoder_type (str): Type of decoder ('ctc' or 'rnnt'). Defaults to "rnnt"
        transcribe_batch_size (int): Batch size for transcribing. Defaults to 32
        use_cuda_graphs (bool): Whether decoding may use CUDA graphs. Defaults to True
        timestamp_type (str): Type of timestamp ('word' or 'char')
        disable_word_confidence (bool): Whether to disable word confidence score computation
    """

    # Conservative instance-free superset: the default checkpoint downloads on first run and
    # decodes on a GPU, so static discovery must not advertise a network/GPU-free stage.
    AGENT_STATIC: ClassVar[StaticHints] = StaticHints(gates=Gates(requires_internet_first_run=True, requires_gpu=True))

    # Legacy positional slots (pre-agent order preserved).
    # Model configuration
    model_name: str = "nvidia/parakeet-tdt_ctc-1.1b"
    model_path: str | None = None

    # Length constraints
    min_len: float = 1.0
    max_len: float = 40.0

    # Model settings
    is_fastconformer: bool = True
    decoder_type: str = "rnnt"
    use_cuda_graphs: bool = True

    # Processing parameters
    transcribe_batch_size: int = 32
    dataloader_num_workers: int = 10
    batch_size: int = 100

    # Timestamp settings
    compute_timestamps: bool = True
    timestamp_type: str = "word"

    # Processing mode
    infer_segment_only: bool = False

    # input keys
    segments_key: str = "segments"

    # Output keys
    text_key: str = "text"
    words_key: str = "words"
    disable_word_confidence: bool = False

    # Stage metadata
    name: str = "NeMoASRAligner"
    _asr_model: Any = field(default=None, repr=False)
    _override_cfg: Any = field(default=None, repr=False)

    # Agent-added knobs are keyword-only (KW_ONLY sentinel) so the legacy positional slots
    # above keep their historical order and meaning.
    _: KW_ONLY
    split_filepaths_key: str = "split_filepaths"
    split_metadata_key: str = "split_metadata"
    alignment_key: str = "alignment"

    def __post_init__(self) -> None:
        """Validate config."""
        if self.decoder_type not in ["ctc", "rnnt"]:
            msg = f"decoder_type must be 'ctc' or 'rnnt', got {self.decoder_type}"
            raise ValueError(msg)

    def load_model(self) -> None:
        if self.model_path:
            self._asr_model = nemo_asr.models.ASRModel.restore_from(restore_path=self.model_path)
        else:
            self._asr_model = nemo_asr.models.ASRModel.from_pretrained(
                model_name=self.model_name, map_location=torch.device(self._device)
            )

    def setup_on_node(
        self, _node_info: NodeInfo | None = None, _worker_metadata: WorkerMetadata | None = None
    ) -> None:
        """Download model weights without loading into memory (called once per node)."""
        if self._asr_model is None:
            if self.model_path:
                return
            try:
                nemo_asr.models.ASRModel.from_pretrained(model_name=self.model_name, return_model_file=True)
            except Exception as e:
                msg = f"[{self.name}] Failed to download model {self.model_name}"
                raise RuntimeError(msg) from e

    def setup(self, _: WorkerMetadata | None = None) -> None:
        """Load model to device and configure decoding (called per replica)."""
        if self._asr_model is None:
            self.load_model()

        self._asr_model.to(self._device)
        self._asr_model.eval()

        if self.is_fastconformer:
            self._asr_model.change_attention_model(
                self_attention_model="rel_pos_local_attn", att_context_size=[128, 128]
            )
            self._asr_model.change_subsampling_conv_chunking_factor(1)

        decoding_cfg = CTCDecodingConfig() if self.decoder_type == "ctc" else RNNTDecodingConfig()

        if self.decoder_type == "ctc":
            decoding_cfg.strategy = "greedy_batch"
            decoding_cfg.greedy.allow_cuda_graphs = self.use_cuda_graphs
        else:
            decoding_cfg.rnnt_timestamp_type = self.timestamp_type
            decoding_cfg.greedy.use_cuda_graph_decoder = self.use_cuda_graphs

        decoding_cfg.preserve_alignments = self.compute_timestamps
        decoding_cfg.confidence_cfg.preserve_word_confidence = not self.disable_word_confidence
        decoding_cfg.compute_timestamps = self.compute_timestamps
        decoding_cfg.greedy.compute_timestamps = self.compute_timestamps

        self._asr_model.change_decoding_strategy(decoding_cfg=decoding_cfg)

        self._override_cfg = self._asr_model.get_transcribe_config()
        self._override_cfg.batch_size = self.transcribe_batch_size
        self._override_cfg.num_workers = self.dataloader_num_workers
        self._override_cfg.return_hypotheses = True
        self._override_cfg.timestamps = self.compute_timestamps

        logger.info(f"[{self.name}] Initialized ASR model on {self._device}")

    def inputs(self) -> tuple[list[str], list[str]]:
        if self.infer_segment_only:
            return ["data"], [self.resampled_audio_filepath_key, self.segments_key]
        return ["data"], ["duration", self.segments_key, self.split_filepaths_key, self.split_metadata_key]

    def outputs(self) -> tuple[list[str], list[str]]:
        if self.infer_segment_only:
            return ["data"], [self.resampled_audio_filepath_key, self.segments_key]
        return ["data"], ["duration", self.segments_key, self.split_filepaths_key, self.split_metadata_key]

    def describe(self) -> StageContract:
        if self.infer_segment_only:
            # Segment audio is resolved as resampled_audio_filepath OR an audio_filepath fallback.
            reads = IOSpec(data_keys=[self.segments_key])
            reads_one_of = [
                IOSpec(data_keys=[self.resampled_audio_filepath_key], accepts=["file"]),
                IOSpec(data_keys=[self.audio_filepath_key], accepts=["file"]),
            ]
            # Nothing is written unconditionally: a segment shorter than min_len (or with empty cut
            # audio) gets no text/word write, and words are only written when timestamps are on.
            writes = IOSpec()
            iteration_key = self.segments_key
            conditional_writes = [
                ConditionalWrite(
                    writes=IOSpec(segment_data_keys=[self.text_key]),
                    condition=(
                        f"a segment's duration >= min_len and its cut audio is non-empty; "
                        f"its transcript is written to '{self.text_key}'"
                    ),
                )
            ]
            if self.compute_timestamps:
                conditional_writes.append(
                    ConditionalWrite(
                        writes=IOSpec(segment_data_keys=[self.words_key]),
                        condition=(
                            f"compute_timestamps is True and a segment's duration >= min_len with "
                            f"non-empty cut audio; word alignments are written to '{self.words_key}'"
                        ),
                    )
                )
        else:
            # Full-mode only consumes the split keys (duration/segments are never read here).
            reads = IOSpec(data_keys=[self.split_filepaths_key, self.split_metadata_key])
            reads_one_of = []
            writes = IOSpec()
            iteration_key = self.split_metadata_key
            conditional_writes = [
                ConditionalWrite(
                    writes=IOSpec(segment_data_keys=[self.text_key, self.alignment_key]),
                    condition=(
                        f"a transcribed split has a corresponding item in '{self.split_metadata_key}'; "
                        f"its text and alignment are written into that split entry"
                    ),
                ),
                ConditionalWrite(
                    writes=IOSpec(data_keys=[self.text_key, self.alignment_key]),
                    condition=(
                        f"'{self.split_filepaths_key}' is an empty list (top-level fallback of empty "
                        f"text and alignment), or a transcribed split has no corresponding item in "
                        f"'{self.split_metadata_key}'; a None or missing '{self.split_filepaths_key}' "
                        f"writes neither"
                    ),
                ),
            ]
        return StageContract(
            reads=reads,
            reads_one_of=reads_one_of,
            writes=writes,
            cardinality="1:1 nested-list",
            iteration_key=iteration_key,
            gates=Gates(
                requires_gpu=self.resources.requires_gpu,
                requires_internet_first_run=self.model_path is None,
                # Batched for GPU throughput, but each row is transcribed and aligned on its own.
                per_row_independent=True,
            ),
            conditional_writes=conditional_writes,
        )

    def get_alignments_text(self, hypotheses: Any) -> tuple[list, str]:  # noqa: ANN401
        """Extract word alignments and text from model hypotheses."""
        if not self.compute_timestamps:
            return [], hypotheses.text

        timestamp_dict = hypotheses.timestamp

        if self.is_fastconformer:
            time_stride = 8 * self._asr_model.cfg.preprocessor.window_stride
        else:
            time_stride = 4 * self._asr_model.cfg.preprocessor.window_stride

        word_timestamps = timestamp_dict[self.timestamp_type]

        alignments = []
        for i, stamp in enumerate(word_timestamps):
            conf = None
            if hypotheses.word_confidence is not None and i < len(hypotheses.word_confidence):
                conf = hypotheses.word_confidence[i]
                if isinstance(conf, torch.Tensor):
                    conf = conf.item()
                conf = round(conf, 4)

            if self.decoder_type == "ctc":
                start = stamp["start_offset"] * time_stride
                end = stamp["end_offset"] * time_stride
            else:
                start = max(0, stamp["start_offset"] * time_stride - 0.08)
                end = max(0, stamp["end_offset"] * time_stride - 0.08)

            word = stamp.get("word", stamp.get("char", ""))
            alignments.append(
                {
                    "word": word,
                    "start": round(start, 3),
                    "end": round(end, 3),
                    "confidence": conf,
                }
            )

        text = " ".join(w["word"] for w in alignments)
        text = text.replace("⁇", "")

        return alignments, text

    def process(self, task: AudioTask) -> AudioTask:
        results = self.process_batch([task])
        return results[0] if results else task

    def process_batch(self, tasks: list[AudioTask]) -> list[AudioTask]:
        """Process a batch of AudioTasks for ASR alignment."""
        if len(tasks) == 0:
            return []
        t0 = time.perf_counter()
        results = self.process_segments(tasks) if self.infer_segment_only else self.process_full_audio(tasks)

        self._log_metrics(
            {
                "process_time": time.perf_counter() - t0,
                "entries_processed": len(tasks),
            }
        )
        return results

    def process_full_audio(self, tasks: list[AudioTask]) -> list[AudioTask]:  # noqa: C901, PLR0912, PLR0915
        """Process entries as full audio (or meta-entries with split_filepaths)."""
        entries = [task.data for task in tasks]
        skip_indices = []
        meta_indices = []
        for i, data in enumerate(entries):
            split_filepaths = data.get(self.split_filepaths_key)
            has_splits = isinstance(split_filepaths, list) and len(split_filepaths) > 0
            if has_splits or split_filepaths is None:
                meta_indices.append(i)
            else:
                skip_indices.append(i)

        for i in skip_indices:
            entries[i][self.text_key] = ""
            entries[i][self.alignment_key] = []

        # collect all split paths of all entries in the batch
        all_paths = []
        path_to_entry_and_split = []
        for entry_idx in meta_indices:
            meta_entry = entries[entry_idx]
            split_filepaths = meta_entry.get(self.split_filepaths_key)
            if not split_filepaths:
                logger.warning(f"[{self.name}] Entry at index {entry_idx} has no split_filepaths, skipping.")
                continue
            for split_idx, path in enumerate(split_filepaths):
                all_paths.append(path)
                path_to_entry_and_split.append((entry_idx, split_idx))

        if not all_paths:
            return tasks

        try:
            with torch.no_grad():
                hypotheses_list = self._asr_model.transcribe(all_paths, override_config=self._override_cfg)
            if isinstance(hypotheses_list, tuple) and len(hypotheses_list) == 2:  # noqa: PLR2004
                hypotheses_list = hypotheses_list[0]
        except Exception as e:  # noqa: BLE001
            logger.error(
                f"[{self.name}] Exception for meta-entries batch: {e!s} for paths: {all_paths}, transcribing one by one"
            )
            hypotheses_list = []
            for path in all_paths:
                try:
                    with torch.no_grad():
                        hyp = self._asr_model.transcribe([path], override_config=self._override_cfg)
                    if isinstance(hyp, tuple) and len(hyp) == 2:  # noqa: PLR2004
                        hyp = hyp[0]
                    hypotheses_list.append(hyp[0] if hyp else None)
                except Exception as e2:  # noqa: BLE001
                    logger.error(f"[{self.name}] Exception for {path}: {e2}")
                    hypotheses_list.append(None)

        for path_idx, hyp in enumerate(hypotheses_list):
            if path_idx >= len(path_to_entry_and_split):
                break
            entry_idx, split_idx = path_to_entry_and_split[path_idx]
            meta_entry = entries[entry_idx]
            if hyp is not None:
                alignments, text = self.get_alignments_text(hyp)
            else:
                alignments, text = [], ""

            split_metadata = meta_entry.get(self.split_metadata_key)
            if split_metadata and split_idx < len(split_metadata):
                split_metadata[split_idx][self.text_key] = text
                split_metadata[split_idx][self.alignment_key] = alignments
            else:
                meta_entry[self.text_key] = text
                meta_entry[self.alignment_key] = alignments

        return tasks

    def process_segments(self, tasks: list[AudioTask]) -> list[AudioTask]:
        """Process entries in segment-only mode (infer per segment)."""
        entries = [task.data for task in tasks]
        if not entries:
            return []

        segment_metadata_list = self._prepare_segment_batch_with_metadata(
            entries,
            cut_audio_segments=True,
            segments_key=self.segments_key,
        )
        all_segments = [seg["audio_segment"] for seg in segment_metadata_list]

        if len(all_segments) == 0:
            return tasks

        try:
            with torch.no_grad():
                hypotheses_list = self._asr_model.transcribe(all_segments, override_config=self._override_cfg)
        except Exception as e:
            files_list = [x.get(self.resampled_audio_filepath_key, x.get(self.audio_filepath_key)) for x in entries]
            msg = f"[{self.name}] Exception for audio list: {files_list}, error: {e}"
            raise ValueError(msg) from e

        if isinstance(hypotheses_list, tuple) and len(hypotheses_list) == 2:  # noqa: PLR2004
            hypotheses_list = hypotheses_list[0]

        for segment_metadata, hypotheses in zip(segment_metadata_list, hypotheses_list, strict=True):
            alignments, text = self.get_alignments_text(hypotheses)
            metadata_idx = segment_metadata["metadata_idx"]
            segment_idx = segment_metadata["segment_idx"]
            segment = entries[metadata_idx][self.segments_key][segment_idx]
            segment[self.text_key] = text
            if self.compute_timestamps:
                seg_start = segment.get("start", 0)
                for word in alignments:
                    word["start"] = round(word["start"] + seg_start, 3)
                    word["end"] = round(word["end"] + seg_start, 3)
                segment[self.words_key] = alignments

        return tasks
