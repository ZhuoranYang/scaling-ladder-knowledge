# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import contextlib
import json
import os
from dataclasses import dataclass
from typing import TYPE_CHECKING, ClassVar

import pandas as pd
from fsspec.core import url_to_fs
from loguru import logger

from nemo_curator.stages.audio._agent._agent_ready import AgentReady, Gates, IOSpec, StageContract, StaticHints
from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import AudioTask, DocumentBatch

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from nemo_curator.backends.base import NodeInfo, WorkerMetadata

_NON_SERIALIZABLE_KEYS = frozenset(
    {
        "waveform",
        "audio",
        "audio_data",
        "audio_array",
        "segments",
    }
)
_DROP_VALUE = object()


class _DefaultBatchSize(int):
    """Sentinel that remains an ordinary integer to signature/card consumers."""


_DEFAULT_BATCH_SIZE = _DefaultBatchSize(64)


def _is_tensor(v: object) -> bool:
    """Check if a value is a torch.Tensor without importing torch at module level."""
    return type(v).__name__ == "Tensor" and type(v).__module__.startswith("torch")


class AudioToDocumentStage(AgentReady, ProcessingStage[AudioTask, DocumentBatch]):
    """Convert AudioTask entries into DocumentBatch DataFrames.

    Overrides ``process_batch`` to aggregate an entire batch of
    ``AudioTask`` objects into a single multi-row ``DocumentBatch``,
    avoiding the overhead of many single-row DataFrames.  Set
    ``batch_size`` to control how many audio entries land in each
    DataFrame (default 64).

    Non-serializable keys (torch tensors, raw audio arrays) are
    stripped before building the DataFrame as a safety net, even if
    upstream stages failed to clean them up.

    Args:
        batch_size: Optional instance override for the inherited batch size.
        keep_keys: Optional allowlist of task-data keys to retain. Selected columns
            remain present with null values when missing or rejected by sanitization;
            drop_keys and excluded audio carriers are still omitted.
        drop_keys: Additional task-data keys to remove.
        serialize_segments: Retain and recursively sanitize ``segments_key``.
        segments_key: Configurable key containing segment metadata.
        strict_json: Also drop values rejected by ``json.dumps``. Disabled by
            default to preserve the historical DataFrame conversion behavior
            for datetime, Decimal, pathlib paths, tuples, and custom scalars.
    """

    name = "AudioToDocumentStage"
    BATCH_ONLY = True  # process() raises; only process_batch is implemented (agent-discovery hint)
    batch_size: int = 64
    keep_keys: list[str] | None = None
    drop_keys: tuple[str, ...] = ()
    serialize_segments: bool = False
    segments_key: str = "segments"
    strict_json: bool = False

    def __init__(  # noqa: PLR0913
        self,
        batch_size: int = _DEFAULT_BATCH_SIZE,
        keep_keys: list[str] | None = None,
        drop_keys: tuple[str, ...] = (),
        serialize_segments: bool = False,
        segments_key: str = "segments",
        strict_json: bool = False,
    ) -> None:
        if batch_size is not _DEFAULT_BATCH_SIZE:
            self.batch_size = batch_size
        self.keep_keys = keep_keys
        self.drop_keys = drop_keys
        self.serialize_segments = serialize_segments
        self.segments_key = segments_key
        self.strict_json = strict_json

    def process(self, task: AudioTask) -> DocumentBatch:
        msg = "AudioToDocumentStage only supports process_batch"
        raise NotImplementedError(msg)

    def _removed_keys(self) -> set[str]:
        removed = set(_NON_SERIALIZABLE_KEYS)
        if self.serialize_segments:
            removed.discard(self.segments_key)
        else:
            removed.add(self.segments_key)
        removed.update(self.drop_keys)
        return removed

    def _projected_keys(self) -> list[str]:
        if self.keep_keys is None:
            return []
        removed = self._removed_keys()
        return [key for key in dict.fromkeys(self.keep_keys) if key not in removed]

    def describe(self) -> StageContract:
        projected_keys = self._projected_keys()
        return StageContract(
            optional_reads=IOSpec(data_keys=projected_keys),
            writes=IOSpec(data_keys=projected_keys),
            preserves_upstream_keys=self.keep_keys is None,
            removes_keys=sorted(self._removed_keys()),
            cardinality="N:1",
            # Tensor/audio carriers are always stripped, but legacy scalar and
            # container values are intentionally preserved unless strict mode is
            # enabled. Only strict mode therefore establishes the general JSON
            # serialization boundary advertised to downstream sinks.
            gates=Gates(sanitizes_output=self.strict_json, per_row_independent=True),
            description="Aggregate AudioTasks into a DocumentBatch while stripping tensors/audio blobs.",
        )

    def _sanitize_nested(  # noqa: C901, PLR0911, PLR0912
        self,
        value: object,
        *,
        path: str,
        active: set[int],
    ) -> object:
        """Remove tensors/cycles while preserving legacy values unless strict JSON is requested."""
        if _is_tensor(value):
            logger.warning(f"[AudioToDocumentStage] Dropping {path}: torch.Tensor is not JSON serializable")
            return _DROP_VALUE

        if isinstance(value, dict):
            identity = id(value)
            if identity in active:
                logger.warning(f"[AudioToDocumentStage] Dropping {path}: recursive mapping is not JSON serializable")
                return _DROP_VALUE
            active.add(identity)
            try:
                cleaned: dict[object, object] = {}
                for key, item in value.items():
                    if self.strict_json:
                        try:
                            json.dumps({key: None})
                        except (TypeError, ValueError, OverflowError):
                            logger.warning(
                                f"[AudioToDocumentStage] Dropping {path}[{key!r}]: "
                                "mapping key is not JSON serializable"
                            )
                            continue
                    nested = self._sanitize_nested(item, path=f"{path}[{key!r}]", active=active)
                    if nested is not _DROP_VALUE:
                        cleaned[key] = nested
                return cleaned
            finally:
                active.remove(identity)

        if isinstance(value, (list, tuple)):
            identity = id(value)
            if identity in active:
                logger.warning(f"[AudioToDocumentStage] Dropping {path}: recursive sequence is not JSON serializable")
                return _DROP_VALUE
            active.add(identity)
            try:
                cleaned_list = []
                for index, item in enumerate(value):
                    nested = self._sanitize_nested(item, path=f"{path}[{index}]", active=active)
                    if nested is not _DROP_VALUE:
                        cleaned_list.append(nested)
                return cleaned_list if isinstance(value, list) or self.strict_json else tuple(cleaned_list)
            finally:
                active.remove(identity)

        if (
            self.strict_json
            and type(value).__module__.startswith("numpy")
            and callable(item := getattr(value, "item", None))
        ):
            normalized = self._sanitize_numpy(value, item, path=path, active=active)
            if normalized is not _DROP_VALUE:
                return normalized

        if self.strict_json:
            try:
                json.dumps(value)
            except (TypeError, ValueError, OverflowError):
                logger.warning(
                    f"[AudioToDocumentStage] Dropping {path}: {type(value).__name__} is not JSON serializable"
                )
                return _DROP_VALUE
        return value

    def _sanitize_numpy(self, value: object, item: Callable[[], object], *, path: str, active: set[int]) -> object:
        if id(value) in active:
            return _DROP_VALUE
        try:
            scalar = item()
        except ValueError:
            return _DROP_VALUE
        # Extended-precision scalars can return their own NumPy type
        # from item(); that conversion makes no progress toward JSON.
        if type(scalar) is type(value):
            return _DROP_VALUE
        active.add(id(value))
        try:
            return self._sanitize_nested(scalar, path=path, active=active)
        finally:
            active.remove(id(value))

    def _sanitize(self, data: dict) -> dict:
        """Remove non-serializable keys and any remaining tensor values."""
        cleaned = {}
        keys = self.keep_keys if self.keep_keys is not None else data.keys()
        for k, v in data.items():
            if k not in keys or k in self.drop_keys:
                continue
            if k in _NON_SERIALIZABLE_KEYS or k == self.segments_key:
                if k == self.segments_key and self.serialize_segments:
                    nested = self._sanitize_nested(v, path=k, active=set())
                    if nested is not _DROP_VALUE:
                        cleaned[k] = nested
                continue
            nested = self._sanitize_nested(v, path=k, active=set())
            if nested is not _DROP_VALUE:
                cleaned[k] = nested
        if self.keep_keys is not None:
            for key in self._projected_keys():
                cleaned.setdefault(key, None)
        return cleaned

    def process_batch(self, tasks: list[AudioTask]) -> list[DocumentBatch]:
        if len(tasks) == 0:
            return []
        df = pd.DataFrame([self._sanitize(t.data) for t in tasks])
        if len(df) and not len(df.columns):
            msg = (
                f"AudioToDocumentStage: the configured projection kept no columns, so "
                f"{len(df)} row(s) would be written as nothing "
                f"(keep_keys={self.keep_keys!r}, drop_keys={self.drop_keys!r})."
            )
            raise ValueError(msg)
        perf = []
        for t in tasks:
            perf.extend(t._stage_perf)
        return [
            DocumentBatch(
                data=df,
                dataset_name=",".join(dict.fromkeys(t.dataset_name for t in tasks)),
                _stage_perf=perf,
            )
        ]


@dataclass
class DocumentBatchJsonlWriterStage(AgentReady, ProcessingStage[DocumentBatch, DocumentBatch]):
    """Append every row in a DocumentBatch to one JSONL manifest.

    This is the task-type-compatible terminal sink for
    :class:`AudioToDocumentStage`. Ordinary ``Pipeline.run()`` execution appends to
    existing output, including across reruns. Explicit driver preparation replaces
    the output once before workers are serialized. The input ``DocumentBatch``
    is returned unchanged so its dataset name, metadata, and performance records
    are preserved.

    ``num_workers() == 1`` is a correctness requirement: appends are not locked,
    so overriding it can interleave rows. This stage creates one fixed manifest,
    unlike the existing text ``JsonlWriter``, which writes per-batch shards and
    returns a ``FileGroupTask``.

    Supports local and cloud paths via fsspec.

    Args:
        output_path: Destination JSONL path (local or cloud).
    """

    output_path: str
    name: str = "document_batch_jsonl_writer"
    # The Audio Agent redirects these fixed-file outputs to a run-owned sibling
    # and publishes them only after the whole pipeline succeeds.
    AGENT_ATOMIC_OUTPUT_PARAMS: ClassVar[tuple[str, ...]] = ("output_path",)
    # A retried source can encounter a partially appended shared file. Until this
    # sink writes source-attributable atomic shards, checkpointed execution must
    # fail before setup rather than silently duplicate or truncate rows.
    is_resumable = False

    AGENT_STATIC: ClassVar[StaticHints] = StaticHints(
        gates=Gates(
            writes_to_disk=True,
            output_path_params=["output_path"],
            lifecycle_side_effects=True,
            requires_serializable_input=True,
            per_row_independent=True,
        ),
        description="Write each DocumentBatch row to one JSONL manifest",
    )

    def __post_init__(self) -> None:
        if not self.output_path:
            msg = "output_path is required for DocumentBatchJsonlWriterStage"
            raise ValueError(msg)

    def prepare_on_driver(self, *, checkpoint_path: str | Path | None = None) -> None:
        """Reserve and replace the manifest once before workers are serialized."""
        from nemo_curator.stages.audio.common import ManifestWriterStage

        lifecycle = ManifestWriterStage(self.output_path)
        lifecycle.prepare_on_driver(checkpoint_path=checkpoint_path)
        self._writer_lifecycle = lifecycle

    def _verify_output_ownership(self) -> None:
        lifecycle = getattr(self, "_writer_lifecycle", None)
        if lifecycle is not None and getattr(lifecycle, "_run_token", None) is not None:
            lifecycle.setup_on_node()
        elif self._fs.exists(f"{self._path}._RUN"):
            msg = "DocumentBatchJsonlWriterStage cannot append to output owned by an active pipeline run"
            raise RuntimeError(msg)

    def setup(self, _worker_metadata: WorkerMetadata | None = None) -> None:
        """Open for appending; replacement actors must preserve committed rows.

        Callers may explicitly call prepare_on_driver to replace output and must
        finalize or abort their reservation. Ordinary Pipeline.run use appends.
        """
        self._fs, self._path = url_to_fs(self.output_path)
        parent_dir = "/".join(self._path.split("/")[:-1])
        if parent_dir:
            self._fs.makedirs(parent_dir, exist_ok=True)
        self._verify_output_ownership()
        with contextlib.suppress(FileExistsError), self._fs.open(self._path, "x", encoding="utf-8"):
            pass
        logger.info(f"DocumentBatchJsonlWriterStage: writing to {self.output_path}")

    def setup_on_node(
        self,
        _node_info: NodeInfo | None = None,
        _worker_metadata: WorkerMetadata | None = None,
    ) -> None:
        self.setup(_worker_metadata)

    def finalize(self) -> None:
        lifecycle = getattr(self, "_writer_lifecycle", None)
        if lifecycle is not None:
            lifecycle.finalize()

    def reset_for_retry(self) -> None:
        self.abort_on_driver()

    def abort_on_driver(self) -> None:
        lifecycle = getattr(self, "_writer_lifecycle", None)
        if lifecycle is not None:
            lifecycle.abort_on_driver()

    def process(self, task: DocumentBatch) -> DocumentBatch:
        dataframe = task.to_pandas()
        if len(dataframe.index) and not len(dataframe.columns):
            msg = "DocumentBatchJsonlWriterStage cannot write a nonempty batch with no columns"
            raise ValueError(msg)
        lifecycle = getattr(self, "_writer_lifecycle", None)
        if not dataframe.empty:
            self._verify_output_ownership()
        if not dataframe.empty and lifecycle is not None:
            lifecycle.write_jsonl_batch(dataframe.to_json(orient="records", lines=True, force_ascii=False))
        elif not dataframe.empty:
            records = dataframe.to_json(orient="records", lines=True, force_ascii=False)
            separator = ""
            if self._fs.size(self._path):
                with self._fs.open(self._path, "rb") as existing:
                    existing.seek(-1, os.SEEK_END)
                    if existing.read(1) != b"\n":
                        separator = "\n"
            with self._fs.open(self._path, "a", encoding="utf-8") as stream:
                stream.write(separator + records)
        return task

    def num_workers(self) -> int | None:
        return 1

    def describe(self) -> StageContract:
        return StageContract(
            gates=Gates(
                writes_to_disk=True,
                output_path_params=["output_path"],
                lifecycle_side_effects=True,
                requires_serializable_input=True,
                # Appends each batch's rows as they arrive; a row's line is its own contents.
                # Which lines the manifest ends up holding is a fact about the run, and a delta
                # merge rewrites exactly that. Also stated in AGENT_STATIC above -- describe()
                # was the view a delta reads, and it was the one left silent.
                per_row_independent=True,
            ),
        )
