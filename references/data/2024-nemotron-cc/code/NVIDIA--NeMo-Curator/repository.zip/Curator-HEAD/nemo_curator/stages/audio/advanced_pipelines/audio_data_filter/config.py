# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Configuration loader for the Audio Data Filter pipeline.

Loads pipeline parameters from a YAML config file organised by stage.
Users edit the YAML to override defaults without touching code.

Example:
    from nemo_curator.stages.audio.advanced_pipelines.audio_data_filter.config import (
        load_config,
    )

    # Load defaults
    cfg = load_config()

    # Load user overrides (only specified values override defaults)
    cfg = load_config("/path/to/my_config.yaml")
"""

import copy
from collections.abc import Mapping
from pathlib import Path
from typing import Any

import yaml
from loguru import logger

_DEFAULT_CONFIG_PATH = Path(__file__).parent / "default_config.yaml"
_MOS_MAX = 5.0


def _deep_merge(base: Mapping[str, Any], overrides: Mapping[str, Any]) -> dict[str, Any]:
    """Recursively merge *overrides* into *base*, returning a new dict."""
    merged = copy.deepcopy(base)
    for key, value in overrides.items():
        if key in merged and isinstance(merged[key], Mapping) and isinstance(value, Mapping):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_config(config_path: str | Path | None = None) -> dict[str, Any]:
    """Load pipeline configuration from YAML.

    Loads the shipped default config and deep-merges any user overrides
    on top.  Only the values explicitly set in the user file override
    defaults; everything else keeps its default value.

    Args:
        config_path: Path to a user YAML config file.  When *None*,
            the built-in ``default_config.yaml`` is used as-is.

    Returns:
        A nested dict keyed by stage name with parameter values.

    Raises:
        FileNotFoundError: If *config_path* does not exist.
        yaml.YAMLError: If either YAML file is malformed.
    """
    with open(_DEFAULT_CONFIG_PATH) as fh:
        defaults = yaml.safe_load(fh)

    if config_path is None:
        return defaults

    user_path = Path(config_path)
    if not user_path.is_file():
        msg = f"Config file not found: {user_path}"
        raise FileNotFoundError(msg)

    with open(user_path) as fh:
        user_cfg = yaml.safe_load(fh)

    if not user_cfg:
        logger.warning(f"User config file is empty, using defaults: {user_path}")
        return defaults

    unknown_sections = set(user_cfg) - set(defaults)
    if unknown_sections:
        logger.warning(f"Unknown config sections (ignored): {unknown_sections}")

    merged = _deep_merge(defaults, user_cfg)

    _validate(merged)

    return merged


def _validate_vad(vad: dict[str, Any]) -> None:
    if not vad.get("enable", True):
        return
    mn = vad.get("min_duration_sec", 0)
    mx = vad.get("max_duration_sec", float("inf"))
    if mn >= mx:
        msg = f"vad.min_duration_sec ({mn}) must be less than vad.max_duration_sec ({mx})"
        raise ValueError(msg)
    threshold = vad.get("threshold", 0.5)
    if not 0.0 <= threshold <= 1.0:
        msg = f"vad.threshold must be in [0, 1], got {threshold}"
        raise ValueError(msg)
    adapter_target = vad.get("adapter_target")
    if not isinstance(adapter_target, str) or not adapter_target.strip():
        msg = f"vad.adapter_target must be a non-empty import path, got {adapter_target!r}"
        raise ValueError(msg)
    adapter_kwargs = vad.get("adapter_kwargs", {})
    if not isinstance(adapter_kwargs, Mapping):
        msg = f"vad.adapter_kwargs must be a mapping, got {type(adapter_kwargs).__name__}"
        raise TypeError(msg)
    batch_size = vad.get("batch_size", 1)
    if isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size <= 0:
        msg = f"vad.batch_size must be a positive integer, got {batch_size!r}"
        raise ValueError(msg)
    if batch_size != 1:
        msg = (
            "vad.batch_size must be 1 in AudioDataFilterStage because its VAD-only and "
            "post-speaker topologies use source-attributed fan-out"
        )
        raise ValueError(msg)
    num_workers = vad.get("num_workers")
    if num_workers is not None and (
        isinstance(num_workers, bool) or not isinstance(num_workers, int) or num_workers <= 0
    ):
        msg = f"vad.num_workers must be a positive integer or null, got {num_workers!r}"
        raise ValueError(msg)


def _validate(cfg: dict[str, Any]) -> None:
    """Validate cross-field constraints after merge."""
    _validate_vad(cfg.get("vad", {}))

    utmos = cfg.get("utmos", {})
    if utmos.get("enable", True):
        mos = utmos.get("mos_threshold", 3.5)
        if mos is not None and not 0.0 <= mos <= _MOS_MAX:
            msg = f"utmos.mos_threshold must be in [0, {_MOS_MAX}] (MOS scale), got {mos}"
            raise ValueError(msg)

    sigmos = cfg.get("sigmos", {})
    if sigmos.get("enable", True):
        for key in (
            "noise_threshold",
            "ovrl_threshold",
            "sig_threshold",
            "col_threshold",
            "disc_threshold",
            "loud_threshold",
            "reverb_threshold",
        ):
            val = sigmos.get(key)
            if val is not None and not 0.0 <= val <= _MOS_MAX:
                msg = f"sigmos.{key} must be in [0, {_MOS_MAX}] (MOS scale), got {val}"
                raise ValueError(msg)

    speaker = cfg.get("speaker_separation", {})
    if speaker.get("enable", True):
        min_dur = speaker.get("min_duration", 0.8)
        if min_dur <= 0:
            msg = f"speaker_separation.min_duration must be positive, got {min_dur}"
            raise ValueError(msg)

    mc = cfg.get("mono_conversion", {})
    sr = mc.get("output_sample_rate", 48000)
    if not isinstance(sr, int) or sr <= 0:
        msg = f"mono_conversion.output_sample_rate must be a positive integer, got {sr}"
        raise ValueError(msg)

    concat = cfg.get("concatenation", {})
    silence = concat.get("silence_duration_sec", 0)
    if silence < 0:
        msg = f"concatenation.silence_duration_sec must be non-negative, got {silence}"
        raise ValueError(msg)


def get_enabled_stages(cfg: dict[str, Any]) -> list[str]:
    """Return a list of enabled stage names from a loaded config."""
    stages: list[str] = ["mono_conversion"]
    if cfg.get("vad", {}).get("enable", True):
        stages.append("vad")
    if cfg.get("band_filter", {}).get("enable", True):
        stages.append("band_filter")
    if cfg.get("utmos", {}).get("enable", True):
        stages.append("utmos")
    if cfg.get("sigmos", {}).get("enable", True):
        stages.append("sigmos")
    if cfg.get("speaker_separation", {}).get("enable", True):
        stages.append("concatenation")
        stages.append("speaker_separation")
    stages.append("timestamp_mapper")
    return stages
