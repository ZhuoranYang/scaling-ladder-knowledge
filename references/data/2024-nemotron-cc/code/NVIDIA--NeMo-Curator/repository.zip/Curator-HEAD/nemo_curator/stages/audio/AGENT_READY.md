# Making an Audio Stage Agent-Ready

This is the **short** checklist for stage owners. "Agent-ready" means an LLM agent can
**discover** your stage, **configure** it, and **chain** it with others to build a pipeline —
without reading your source. The design goal is **minimal burden**: you declare a small core,
the framework auto-derives the rest, and one test tells you if anything is missing.

> **Golden rule:** every new knob defaults to today's behavior. Agent-readiness must not change
> how your stage runs in existing pipelines.

---

## TL;DR — the mechanical contract is 3 things

1. Inherit `AgentReady` and implement **`describe()`** returning a `StageContract` with
   **`reads`, `writes`, `cardinality`** (+ honest **`gates`**).
2. Make every `task.data` key you read/write a **`*_key` constructor field** (no bare key
   literals in `process()`).
3. Add one test: **`assert_agent_ready(MyStage(...), fixture_factory=...)`**.

Define `describe()` on the concrete stage class itself. Inheriting a parent's
contract alone does not enroll a subclass in agent discovery; review the subclass's
configuration and behavior before explicitly declaring its contract.

Those three items make the stage mechanically composable. Also document the meaning of
externally consumed outputs, especially filterable fields and anything crossing a
fan-out/aggregation boundary. `assert_agent_ready` can prove keys and cardinality; it
cannot prove that a reasoner will interpret a value correctly.

---

## What you MUST declare (only you know these)

```python
from dataclasses import dataclass
from nemo_curator.stages.audio._agent._agent_ready import (
    AgentReady,
    ConditionalWrite,
    Gates,
    IOSpec,
    StageContract,
)
from nemo_curator.stages.base import ProcessingStage

@dataclass
class MyStage(AgentReady, ProcessingStage[AudioTask, AudioTask]):
    """One-line summary becomes the agent-facing description.

    Args:
        audio_filepath_key: Path to the input audio.   # docstring Args -> param descriptions
        score_key: Where the score is written.
    """
    audio_filepath_key: str = "audio_filepath"
    score_key: str = "my_score"
    name: str = "MyStage"

    def describe(self) -> StageContract:
        return StageContract(
            reads=IOSpec(data_keys=[self.audio_filepath_key], accepts=["file"]),
            writes=IOSpec(data_keys=[self.score_key]),
            cardinality="1:1",                       # see "Cardinality" below
            gates=Gates(requires_gpu=self.resources.requires_gpu),
        )
```

- **`reads` / `writes`** — the `task.data` keys consumed/produced. Use `segment_data_keys` for keys
  written *inside* `segments[]` items. Use `reads_one_of=[IOSpec(...), ...]` if input can take more
  than one shape (e.g. waveform **or** file).
- **`cardinality`** — one of `"1:1"`, `"1:1 nested-list"`, `"1:N fan-out"`, `"N:1"`, `"filter"`.
  (`"filter"` = `process` may return `None`/`[]` to drop items.)
- **`gates`** — be honest about side effects: `requires_gpu`, `writes_to_disk`,
  `requires_internet_first_run`, `requires_ffmpeg`. Serializability (both exist on `Gates`): a sink
  that `json.dumps` `task.data` as-is must set `requires_serializable_input=True`; a converter that
  strips tensors/audio blobs sets `sanitizes_output=True`. A stage that derives durable filenames,
  member names, or row identity from framework `task.task_id` sets
  `requires_stable_task_id=True`; metadata-manifest resume boundaries cannot restore that identity
  and will reject the suffix.

Use `conditional_reads` when runtime selects a mutually exclusive read scope
from literal top-level key presence. Each `ConditionalRead` supplies one
`reads_one_of` group plus `requires_keys` and/or `forbids_keys` matching that
branch selector. The planner validates every reachable branch independently;
an unrelated task-level waveform therefore cannot satisfy a nested-audio branch
selected by the presence of `segments_key`.

### Conditional/data-dependent writes

Use `invalidates_prior_writes=IOSpec(...)` when processing clears an inherited field
before trying to replace it. Declare task and segment keys in their respective scopes;
the planner retracts the old guarantee before accounting for the stage's own writes.

Keep `writes` as the existing mechanical output declaration. When a listed
field is only written on a runtime branch—or a non-preserving stage may copy an
upstream field only when it is present—add factual possibility metadata:

```python
return StageContract(
    writes=IOSpec(data_keys=[self.score_key], segment_data_keys=[self.score_key]),
    conditional_writes=[
        ConditionalWrite(
            writes=IOSpec(data_keys=[self.score_key]),
            condition=f"'{self.segments_key}' is absent, so the task-level branch runs",
        ),
        ConditionalWrite(
            writes=IOSpec(segment_data_keys=[self.score_key]),
            condition=f"'{self.segments_key}' is present, so the per-segment branch runs",
        ),
        ConditionalWrite(
            writes=IOSpec(data_keys=list(self.passthrough_keys)),
            condition="the same input key is present, non-null, and allowed by the output whitelist",
            value_origin="upstream_same_key",
        ),
        ConditionalWrite(
            metadata_writes=[self.metadata_key],
            condition="the metadata value is computed and attached to the emitted task",
        ),
    ],
)
```

`ConditionalWrite` does not execute a predicate and does not change processing,
defaults, or the validator's legacy mechanical interpretation of `writes`. It
labels output possibility and value provenance for `validate.semantic_review`.
The `upstream_same_key` origin is important for allowlist/rebuild stages: it
keeps the original producer's meaning visible instead of falsely presenting the
copier as a new metric producer.

The planner does read `conditional_writes`, in two bounded ways. A downstream
read that is met only by a conditional key is reported as a `conditional_read`
*warning* (the pipeline composes, `report.ok` stays true, but the key is never
added to `produced_keys`); a read nothing even possibly writes remains an
`unsatisfied_reads` error. And a conditional write with `produces=["tensor"]`
seeds tensor residency for the JSON-sink gate. Set `requires_keys` on a
`ConditionalWrite` when its branch can only run if some literal key already
exists upstream (in the write's own scope): the planner then ignores the branch
-- for both purposes -- on inputs that cannot reach it. File hydration that only
*replaces* an incomplete resident waveform/sample-rate pair is the canonical
case: without the hint, a file-backed scorer followed by `ManifestWriterStage`
could be refused for a tensor the runtime never introduces.

Use `metadata_writes` for a conditional `task._metadata` output. Unconditional
metadata inputs/outputs remain declared through
`StageContract.metadata_reads`/`metadata_writes`; semantic review traces all
three scopes (`task`, `segment`, and `metadata`) independently.

Use `augments_upstream_same_key` when the stage adds entries to an existing
mapping (for example a shared metrics mapping), and
`transforms_upstream_same_key` when it replaces the same key with a derived
value. These are objective lineage facts, not claims about whether the value is
appropriate for the user's goal.

Conditions must describe actual code branches using configured key values. They
are not an intent checker, a module-specific validator, or a centralized
field-scope ontology. The host LLM still decides whether a conditional field's
meaning and granularity fit the request.

### Preferred resident inputs

A configured `auto` consumer can declare `preferred_reads` as one of its
`reads_one_of` alternatives. It describes the resident pair selected before the
file fallback. Validation checks conflicts in this pair when upstream role
evidence establishes its selection inputs; missing, conditional, or unknown
inputs remain subject to the ordinary alternative checks. Explicit file mode
must not declare a resident preference.

### `gates.per_row_independent` — usually nothing to do

This one decides whether a *delta run* (reprocessing only the files that changed, instead of the
whole corpus) may include your stage. **Most stages declare nothing and are handled
automatically.**

`delta.region()` refuses to assume anything about a stage that could see a row other than the one
it was handed. It checks three things, and if **none** of them is true your stage is treated as
independent with no declaration from you:

- you override `process_batch` (you are handed several rows at once)
- `gates.writes_to_disk=True`
- `gates.lifecycle_side_effects=True`

**If one of those IS true**, the delta refuses your stage by name until you answer this question:

> If I ran this stage over file `X` alone, versus over `X` plus 999 others, would `X`'s output row
> be identical?

- **Yes** → `per_row_independent=True`, with a comment saying *why* it survives batching.
- **No** → `per_row_independent=False`. Nothing is lost: the delta simply stops at your stage, and
  every stage above it still reprocesses only the changed files.

The reference pair — both batch, opposite answers:

| Stage | | Why |
|---|---|---|
| `ASRStage` with `NeMoASRAdapter` | `True` | prepares each waveform independently and passes the batch to NeMo with lengths preserved |
| `TorchSquimQualityMetricsStage` | `False` | pads to the batch max with **no lengths**, so padding reads as silence and scores move |

Typical reasons for `False`: a corpus statistic or percentile threshold, a running counter that
picks output names, appending to a file shared across rows, an unseeded RNG advanced per row,
batch padding without lengths.

Three more rules:

- **Declare per instance when the unsafety is conditional.** `SplitLongAudioStage` is independent
  only while no shared `output_dir` flattens every source's splits into one namespace, so it
  declares `per_row_independent=(self.output_dir is None)` rather than a flat `False` that would
  cost the default configuration — the safe one — its delta. `SplitASRAlignJoinStage` and
  `InferenceSortformerStage` do the same with their own output directories.
- **A source accepting `include_files` MUST declare**, `True` or `False` — silence is a conformance
  error. That parameter is how a delta narrows a source, so it has to be answerable.
- **Getting it wrong is asymmetric.** `False` when you were safe costs a full rerun — annoying and
  harmless. `True` when you were not silently produces rows a full run would never have produced,
  and republishes them as the corpus's reusable result. **When unsure, declare `False`.**
- **Selectable adapters fail closed.** A stage may declare `True` only for adapter targets whose
  batching contract it has reviewed; unknown plug-ins remain `False` even when the built-in
  adapter is independent.

`CreateInitialManifestAudioFolderStage` is the reference for a conditionally safe
source. Its unbounded scan is per-row independent, but `max_samples` truncates the
sorted listing, so adding an earlier path can change which rows are emitted. It
therefore declares `per_row_independent=False` for bounded instances and `True` only
for unbounded ones. Follow that per-instance pattern for any bounded source.

## What is AUTO-DERIVED — do NOT hand-write these

| Field | Derived from |
|---|---|
| `params` (names, types, defaults, `choices` from `Literal[...]`) | your dataclass fields / `__init__` |
| param `description`s | your class docstring `Args:` section |
| key `role`s | your `*_key` field names (shared `_roles.KEY_ROLES`) |
| `dispatch` | whether you override `process_batch` |
| `description`, `stage_id` | class docstring / class name |

You never put `params` in `describe()`.

Use `optional_reads=IOSpec(...)` for keys a stage consults when present but can
correctly run without. Optional reads are visible to discovery and semantic
review, but they never make validation reject a fallback path. Do not put a
fallback key in `reads` or legacy `inputs()` merely to advertise it.

Use `invalidates_keys=[...]` when compatibility requires retaining a key in
`task.data`, but its prior semantic role is no longer safe for downstream
planning. This differs from `removes_keys`: the runtime value remains available
as legacy provenance, while the planner treats it as unavailable until a later
stage writes a current value for that role.

When compatibility requires retaining a constructor default that runtime validation rejects,
declare the field with `metadata={"agent_required": True}`. Discovery then requires an explicit
value without changing the Python constructor or its default. Use this only for values that the
stage cannot run without; ordinary defaults remain optional.

## What is OPTIONAL — set only if it's obvious

Declared via one class attribute, `AGENT_STATIC = StaticHints(...)`, or on the contract:

- **StaticHints-settable** (instance-free): `cardinality_options` (e.g. `["fan_out", "nested"]`),
  `gates`, `dispatch`, `error_policy` (`"skip" | "fail" | "annotate"` — default `"unknown"`; set
  only if your stage has a clear, uniform policy), `description`, `stage_id`.
- **Contract-only** (return them from `describe()`; StaticHints has no such fields):
  `iteration_key`, `size_envelope`.
- `BATCH_ONLY = True` — only if your `process()` raises and just `process_batch` works.

If you're unsure, leave them. The agent treats missing optionals safely.

---

## Naming rule: config-knobs-only

Keep **today's default key names**. Do **not** rename keys to a global vocabulary. Just expose a
`*_key` field for each so an agent can remap when wiring two stages. Compatibility comes from
**semantic roles** (below), not from everyone using the same strings.

## Semantic roles — the compatibility contract

An agent chains a producer's output to a consumer's input by **role**, not key string. Roles are
resolved automatically from your `*_key` **field name** via `nemo_curator/stages/audio/_agent/_roles.py`.

- If your key fields use existing names (`audio_filepath_key`, `waveform_key`, `score_key`,
  `text_key`, `segments_key`, …) you get the right role for free.
- If you add a **brand-new** `*_key` concept, add one line to `KEY_ROLES` in `_roles.py` (or, for a
  truly stage-internal key, list it in `INTERNAL_KEY_FIELDS`). The conformance test fails if you
  forget — it won't let a key silently fall through.

## Output meaning — the reasoning contract

Roles answer “can these stages connect?” They do not answer “what does this
value mean here?” A pipeline can connect perfectly and still apply a valid
filter to the wrong entity. Put that semantic knowledge in the stage's durable
documentation, where a host can reason over it; do not add a per-field rule or a
hard `field_scope` ontology to the Python core.

For each output that another stage may select, aggregate, compare or filter,
document:

- **meaning** — what the value actually represents, not merely “the key where it
  is written”;
- **unit/range** — seconds, Hz, speakers, MOS range, category vocabulary, etc.;
- **provenance** — which input/entity and computation produced it;
- **scope/granularity** — file, original parent item, emitted child, segment,
  speaker, batch or corpus, written as factual prose rather than an enum;
- **propagation** — whether fan-out copies a parent value to every child, nesting
  moves it into segments, aggregation summarizes many rows, or a transform
  recomputes it;
- **counterexample** — at least one plausible but wrong interpretation and its
  pipeline consequence.

For example, if a speaker-separation stage computes the original clip's
detected-speaker count once and copies it to every per-speaker child, say so
explicitly: filtering that child field to `== 1` selects children whose **parent
source** had one detected speaker; it does not test whether each already-separated
child track is single-speaker.

Only document facts grounded in code, a measured run or an authoritative model
source. Missing meaning should remain an explicit TODO; the host must ask rather
than invent it.

## Discovery — how the agent finds your stage

Nothing to do: your stage auto-registers (via `StageMeta`) and appears in the catalog. Consumers
go through the public entry point — `agent.py` is the sanctioned public surface; don't import the
private `_catalog` module directly:
```python
from nemo_curator.stages.audio import agent

agent.list_agent_ready_stages()  # -> [... "MyStage" ...]
agent.describe_stage("MyStage")  # -> StageContract (static, instance-free)
agent.catalog_as_json()          # -> JSON the agent/UI consumes
```

---

## The safety net: `assert_agent_ready`

Add one test. It runs the static checks (contract shape, valid roles, JSON-serializable, reads
satisfiable by role) and — with a fixture — runs your stage and verifies declared writes appear,
no undeclared top-level keys leak, and cardinality matches runtime:

```python
from nemo_curator.stages.audio._agent._conformance import assert_agent_ready

def test_my_stage_is_agent_ready(tmp_path):
    def fixture():
        return AudioTask(data={"audio_filepath": str(_write_wav(tmp_path / "a.wav"))})
    assert_agent_ready(MyStage(), fixture, expected_cardinality="1:1", available_keys={"audio_filepath"})
```

For GPU/model stages, keep the conformance test CPU-only by reusing the fake-model
or stub setup in that stage's test module. You don't need to memorize the mechanical
rules — if the test passes, the contract is internally consistent.

---

## Checklist (copy into your PR)

- [ ] `AgentReady` + `describe()` with `reads`, `writes`, `cardinality`, honest `gates`
- [ ] every read/written `task.data` key is a `*_key` constructor field (no bare literals)
- [ ] adapter/model payload field names remain protocol-owned; only `task.data` schema keys become knobs
- [ ] new `*_key` concepts have a `_roles.KEY_ROLES` entry (or `INTERNAL_KEY_FIELDS`)
- [ ] branch-only outputs, including audit placeholders, are `ConditionalWrite`s rather than guaranteed writes
- [ ] durable stage documentation explains each externally consumed output's meaning,
      unit, provenance, scope/granularity, propagation and a counterexample
- [ ] new `AudioTask`s preserve `_metadata` and `list(_stage_perf)` (manual — not covered by `assert_agent_ready`)
- [ ] if you override `process_batch`, write to disk, or set `lifecycle_side_effects` — decided
      `gates.per_row_independent` (`True`/`False`, per instance if conditional); otherwise left it
      alone and let the delta derive it
- [ ] `assert_agent_ready(...)` test added and green
- [ ] defaults unchanged → existing pipelines behave exactly as before

Auto-derivation handles params/roles/dispatch/description; stage documentation supplies
meaning only the author knows. Neither documentation step changes runtime defaults.


## Driver lifecycle for durable agent outputs

Before serializing workers, an audio-agent execution wrapper must call
`prepare_on_driver(checkpoint_path=...)` on stages that implement it. For
`ManifestWriterStage`, also pass `pipeline_identity=agent.pipeline_identity(pipeline.stages)`
after building the pipeline. A manifest can be appended only when its provenance
matches the checkpoint state, pipeline configuration, and output content from a
successfully finalized run. Unproven or interrupted runs require fresh output and
checkpoint paths; preparation refuses rather than retaining unrelated rows or
discarding rows whose sources would be skipped. Driver-prepared manifests require
local file identity or remote object version/creation metadata; size alone does
not establish ownership. Standalone writer setup retains its legacy behavior. This reserves
shared manifest and checkpoint state, including for runs with no output rows.
Worker and node setup adopt and verify that state without truncating committed rows.
After successful execution, call every stage's `finalize()` on the original driver
objects. Do not finalize checkpoints when the executor records failed tasks.
On preparation or execution failure, call `abort_on_driver()` where available to
release owned run bookkeeping while preserving partial output. A retry must use
`reset_for_retry()` for checkpoints before preparing them again.

These stage-specific hooks belong to the separate audio-agent execution wrapper;
they are not part of the generic `ProcessingStage` lifecycle. This Foundation slice
provides the hooks but does not ship the wrapper. Generic pipelines do not implicitly own these stage-specific hooks. A caller or
an explicitly opted-in driver lifecycle must prepare shared outputs before workers
are serialized and finalize them only after verified success.
Outside agent execution, ManifestWriter's standalone worker `setup()` retains
its legacy truncation behavior. Checkpoint completion requires durable ownership
and artifact identity; absent driver-visible state must never imply empty input.

Folder-source item IDs include escaped relative paths and extensions, and source
resume IDs derive from canonical absolute file paths. Existing checkpoints produced
with earlier identities should be regenerated before resuming a changed file listing.
